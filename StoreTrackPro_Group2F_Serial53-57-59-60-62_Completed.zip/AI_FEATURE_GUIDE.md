# StoreTrack Pro AI Features
> **Repository alignment (2026-09-19):** This documentation is aligned with the security-fixed and performance-tuned StoreTrack Central Server build. Target Windows certificate, firewall, ACL, backup-restore, and hardware validation remain deployment-site checks.


## AI Daily Operation Summary

The Daily Operation Summary is an operational snapshot for supervisors. It combines the day’s material receipts, issues or replacements, stock alerts, pending workflow items, and notable exceptions into one summary. It is useful at shift handover and daily review; it is not required for stock entry, stock verification, or Shank Mapping transactions.

## AI Report Builder

The Report Builder creates a custom report from selected StoreTrack data sources, columns, filters, sorting, and export options. It is intended for management or audit reporting when the standard reports are insufficient. It does not change inventory or transaction data and is optional for normal store operations.

## AI Import Summary

The Import Summary explains what an imported workbook or CSV contains before or after commit. It reports rows scanned, accepted rows, skipped or invalid rows, duplicate/source-only rows, selected sheets, and mapping warnings. It is a validation and traceability aid; it does not replace the import preview or the final commit confirmation.

## Why the modules are loaded globally

The desktop application loads feature modules centrally so shared event wiring, permissions, and lazy initialization work consistently. Loading a module does not mean that every AI screen is shown or required in every workflow. The feature’s menu visibility remains controlled by the Developer menu settings. When a Developer enables a menu item, it is visible to all authenticated users under the updated access model.

## Recommended use

Use Daily Operation Summary for daily review, Report Builder for optional custom reporting, and Import Summary for import verification. Users who do not need these workflows may leave the corresponding menu items disabled in Developer settings without affecting Material IN/OUT, Physical Stock Verification, or Shank Mapping.
