StoreTrack Pro — Shank Receiving Enter Shortcut Update
तारीख: 2026-11-06

या ZIP मध्ये Shank Receiving मधील सुधारणा आणि संबंधित दस्तऐवज आहेत. Part No. dropdown मध्ये Arrow Down + Enter ने निवडल्यावर focus Total Received Quantity मध्ये जातो. ZIP project root वर extract करा आणि folders/files overwrite करा (उदा. modules/, tests/, docs/).

बदल:
- Auto-bin allocation तयार झाल्यावर confirmation सूचना दिसते.
- Quantity field वर focus असताना Enter दाबल्यास Receive Stock by Kit Allocation action चालते. यशस्वी receipt नंतर तोच Part No. field मध्ये भरलेला व selected/focused राहतो; Qty रिकामी ठेवली जाते.
- Invalid allocation साठी shortcut बंद राहतो आणि rapid duplicate submit रोखण्यासाठी guard आहे.
- Regression test, Marathi handover manual आणि 51-case UAT workbook अपडेट केले आहेत.

चाचणी: Jest 53 suites / 491 tests पास; lint 0 errors (401 warnings). Windows installer/build या package मध्ये नाही; packaged build आणि प्रत्यक्ष UAT वेगळे तपासणे आवश्यक आहे.

हा update package आहे; तो standalone installer किंवा पूर्ण project archive नाही. Existing project copy चा backup घेऊन मग files replace करा.
