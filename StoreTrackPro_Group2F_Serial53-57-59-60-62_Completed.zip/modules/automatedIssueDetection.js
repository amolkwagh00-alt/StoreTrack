/**
 * Automated Issue Detection Module
 * Automatically detects and categorizes system issues
 */

class AutomatedIssueDetection {
  constructor() {
    this.detectedIssues = new Map();
    this.issuePatterns = new Map();
    this.rules = new Map();
    this.config = {
      checkInterval: 30000, // 30 seconds
      maxIssues: 1000,
      autoResolveTimeout: 3600000, // 1 hour
      severityThresholds: {
        critical: 90,
        high: 70,
        medium: 50,
        low: 30
      }
    };
    this.checkTimer = null;
    this.eventBus = null;
  }

  /**
   * Initialize issue detection
   * @param {Object} config - Configuration options
   * @param {Object} eventBus - Event bus for notifications
   */
  initialize(config = {}, eventBus = null) {
    this.config = { ...this.config, ...config };
    this.eventBus = eventBus;
    this.loadDefaultRules();
    this.startDetection();
  }

  /**
   * Load default detection rules
   */
  loadDefaultRules() {
    // Performance degradation rules
    this.addRule('high_response_time', {
      type: 'performance',
      condition: (data) => data.responseTime > 5000,
      severity: 'high',
      category: 'performance',
      message: 'High response time detected'
    });
    
    this.addRule('memory_leak', {
      type: 'performance',
      condition: (data) => data.memoryUsage > 0.9,
      severity: 'critical',
      category: 'performance',
      message: 'Potential memory leak detected'
    });
    
    // Error rate rules
    this.addRule('high_error_rate', {
      type: 'error',
      condition: (data) => data.errorRate > 0.05,
      severity: 'critical',
      category: 'error',
      message: 'High error rate detected'
    });
    
    // Database rules
    this.addRule('database_slow_query', {
      type: 'database',
      condition: (data) => data.queryTime > 1000,
      severity: 'medium',
      category: 'database',
      message: 'Slow database query detected'
    });
    
    this.addRule('database_connection_failed', {
      type: 'database',
      condition: (data) => data.connectionFailed === true,
      severity: 'critical',
      category: 'database',
      message: 'Database connection failed'
    });
    
    // Sync rules
    this.addRule('sync_failure', {
      type: 'sync',
      condition: (data) => data.syncFailed === true,
      severity: 'high',
      category: 'sync',
      message: 'Synchronization failure detected'
    });
    
    this.addRule('sync_lag', {
      type: 'sync',
      condition: (data) => data.syncLag > 60000,
      severity: 'medium',
      category: 'sync',
      message: 'Synchronization lag detected'
    });
    
    // Storage rules
    this.addRule('storage_full', {
      type: 'storage',
      condition: (data) => data.usagePercent > 95,
      severity: 'critical',
      category: 'storage',
      message: 'Storage nearly full'
    });
    
    // Network rules
    this.addRule('network_timeout', {
      type: 'network',
      condition: (data) => data.timeout === true,
      severity: 'high',
      category: 'network',
      message: 'Network timeout detected'
    });
  }

  /**
   * Add detection rule
   * @param {string} ruleId - Rule identifier
   * @param {Object} rule - Rule configuration
   */
  addRule(ruleId, rule) {
    this.rules.set(ruleId, {
      id: ruleId,
      ...rule,
      enabled: true,
      triggerCount: 0,
      lastTriggered: null
    });
  }

  /**
   * Remove detection rule
   * @param {string} ruleId - Rule identifier
   */
  removeRule(ruleId) {
    this.rules.delete(ruleId);
  }

  /**
   * Enable/disable rule
   * @param {string} ruleId - Rule identifier
   * @param {boolean} enabled - Enable state
   */
  setRuleEnabled(ruleId, enabled) {
    const rule = this.rules.get(ruleId);
    if (rule) {
      rule.enabled = enabled;
    }
  }

  /**
   * Check data against rules
   * @param {Object} data - Data to check
   * @param {string} category - Data category
   */
  checkData(data, category) {
    const issues = [];
    
    for (const [ruleId, rule] of this.rules) {
      if (!rule.enabled || rule.category !== category) {continue;}
      
      try {
        if (rule.condition(data)) {
          const issue = this.createIssue(rule, data);
          issues.push(issue);
          
          rule.triggerCount++;
          rule.lastTriggered = Date.now();
        }
      } catch (error) {
        console.error(`[IssueDetection] Rule ${ruleId} failed:`, error.message);
      }
    }
    
    return issues;
  }

  /**
   * Create issue from rule
   * @param {Object} rule - Detection rule
   * @param {Object} data - Triggering data
   */
  createIssue(rule, data) {
    const issueId = this.generateIssueId();
    const issue = {
      id: issueId,
      ruleId: rule.id,
      type: rule.type,
      category: rule.category,
      severity: rule.severity,
      message: rule.message,
      data: this.sanitizeData(data),
      detectedAt: Date.now(),
      status: 'open',
      acknowledged: false,
      resolved: false,
      resolution: null,
      occurrences: 1
    };
    
    // Check if similar issue already exists
    const existingIssue = this.findSimilarIssue(issue);
    if (existingIssue) {
      existingIssue.occurrences++;
      existingIssue.lastDetectedAt = Date.now();
      return existingIssue;
    }
    
    this.detectedIssues.set(issueId, issue);
    
    // Emit event
    if (this.eventBus) {
      this.eventBus.emit('ISSUE_DETECTED', issue);
    }
    
    return issue;
  }

  /**
   * Find similar existing issue
   * @param {Object} issue - Issue to match
   */
  findSimilarIssue(issue) {
    for (const [, existing] of this.detectedIssues) {
      if (existing.status === 'open' && 
          existing.ruleId === issue.ruleId &&
          existing.category === issue.category) {
        return existing;
      }
    }
    return null;
  }

  /**
   * Sanitize data for storage
   * @param {Object} data - Data to sanitize
   */
  sanitizeData(data) {
    const sanitized = { ...data };
    
    // Remove sensitive fields
    const sensitiveFields = ['password', 'token', 'apiKey', 'secret'];
    sensitiveFields.forEach(field => {
      if (sanitized[field]) {
        sanitized[field] = '[REDACTED]';
      }
    });
    
    // Limit object size
    const json = JSON.stringify(sanitized);
    if (json.length > 10000) {
      return { message: 'Data too large', size: json.length };
    }
    
    return sanitized;
  }

  /**
   * Start automated detection
   */
  startDetection() {
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
    }
    
    this.checkTimer = setInterval(() => {
      this.performDetection();
    }, this.config.checkInterval);
  }

  /**
   * Stop automated detection
   */
  stopDetection() {
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
      this.checkTimer = null;
    }
  }

  /**
   * Collect current state from modules already tracking application health.
   * @returns {Array<{data: Object, category: string}>} Detection inputs
   */
  collectCurrentData() {
    const inputs = [];
    const performanceMonitor = typeof window !== 'undefined' ? window.performanceMonitor : null;
    const recentMetrics = performanceMonitor && typeof performanceMonitor.getRecentMetrics === 'function'
      ? performanceMonitor.getRecentMetrics(100)
      : [];
    const latestMetric = (names) => recentMetrics
      .filter(metric => names.includes(metric.name) && Number.isFinite(Number(metric.value)))
      .sort((a, b) => Number(b.timestamp || 0) - Number(a.timestamp || 0))[0];

    const responseMetric = latestMetric(['resource_load_time', 'response_time', 'api_response_time']);
    if (responseMetric) {
      inputs.push({ category: 'performance', data: { responseTime: Number(responseMetric.value), source: responseMetric.name } });
    }

    const memoryUsed = latestMetric(['memory_used']);
    const memoryLimit = latestMetric(['memory_limit']);
    if (memoryUsed && memoryLimit && Number(memoryLimit.value) > 0) {
      inputs.push({ category: 'performance', data: { memoryUsage: Number(memoryUsed.value) / Number(memoryLimit.value), source: 'performanceMonitor' } });
    }

    const queryMetric = latestMetric(['db_benchmark_read', 'db_benchmark_bulk_read', 'database_query_time']);
    if (queryMetric) {
      inputs.push({ category: 'database', data: { queryTime: Number(queryMetric.value), source: queryMetric.name } });
    }

    const centralHealth = typeof window !== 'undefined' ? window.centralHealth : null;
    if (centralHealth) {
      if (centralHealth.online === false || centralHealth.state === 'offline') {
        inputs.push({ category: 'sync', data: { syncFailed: true, source: 'centralHealth' } });
      }
      if (Number.isFinite(Number(centralHealth.syncLag))) {
        inputs.push({ category: 'sync', data: { syncLag: Number(centralHealth.syncLag), source: 'centralHealth' } });
      }
    }

    const errorHandler = typeof window !== 'undefined' ? window.errorHandler : null;
    if (errorHandler && typeof errorHandler.getErrorLog === 'function') {
      const recentErrors = errorHandler.getErrorLog().filter(error => Date.parse(error.timestamp) >= Date.now() - this.config.checkInterval);
      recentErrors.filter(error => error.name === 'NetworkError' || error.name === 'TimeoutError').forEach(error => {
        inputs.push({ category: 'network', data: { timeout: true, source: 'errorHandler', error: error.message } });
      });
      const statistics = typeof errorHandler.getStatistics === 'function' ? errorHandler.getStatistics() : {};
      if (Number.isFinite(Number(errorHandler.errorRate))) {
        inputs.push({ category: 'error', data: { errorRate: Number(errorHandler.errorRate), source: 'errorHandler' } });
      } else if (Number.isFinite(Number(statistics.errorRate))) {
        inputs.push({ category: 'error', data: { errorRate: Number(statistics.errorRate), source: 'errorHandler' } });
      }
    }

    return inputs;
  }

  /**
   * Perform detection cycle
   */
  performDetection() {
    this.collectCurrentData().forEach(({ data, category }) => this.checkData(data, category));
    this.autoResolveIssues();
    this.cleanupOldIssues();
  }

  /**
   * Auto-resolve old issues
   */
  autoResolveIssues() {
    const now = Date.now();
    
    for (const [issueId, issue] of this.detectedIssues) {
      if (issue.status === 'open' && 
          now - issue.detectedAt > this.config.autoResolveTimeout) {
        this.resolveIssue(issueId, 'auto_resolved', 'Issue auto-resolved after timeout');
      }
    }
  }

  /**
   * Clean up old resolved issues
   */
  cleanupOldIssues() {
    const now = Date.now();
    const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 days
    
    for (const [issueId, issue] of this.detectedIssues) {
      if (issue.resolved && now - issue.resolvedAt > maxAge) {
        this.detectedIssues.delete(issueId);
      }
    }
    
    // Keep total under max
    if (this.detectedIssues.size > this.config.maxIssues) {
      const entries = Array.from(this.detectedIssues.entries());
      entries.sort((a, b) => a[1].detectedAt - b[1].detectedAt);
      
      const toRemove = entries.slice(0, entries.length - this.config.maxIssues);
      toRemove.forEach(([id]) => this.detectedIssues.delete(id));
    }
  }

  /**
   * Get all issues
   * @param {Object} filters - Issue filters
   */
  getIssues(filters = {}) {
    let issues = Array.from(this.detectedIssues.values());
    
    if (filters.status) {
      issues = issues.filter(i => i.status === filters.status);
    }
    
    if (filters.severity) {
      issues = issues.filter(i => i.severity === filters.severity);
    }
    
    if (filters.category) {
      issues = issues.filter(i => i.category === filters.category);
    }
    
    if (filters.type) {
      issues = issues.filter(i => i.type === filters.type);
    }
    
    return issues.sort((a, b) => b.detectedAt - a.detectedAt);
  }

  /**
   * Get issue by ID
   * @param {string} issueId - Issue ID
   */
  getIssue(issueId) {
    return this.detectedIssues.get(issueId);
  }

  /**
   * Acknowledge issue
   * @param {string} issueId - Issue ID
   */
  acknowledgeIssue(issueId) {
    const issue = this.detectedIssues.get(issueId);
    if (issue) {
      issue.acknowledged = true;
      issue.acknowledgedAt = Date.now();
      
      if (this.eventBus) {
        this.eventBus.emit('ISSUE_ACKNOWLEDGED', issue);
      }
    }
  }

  /**
   * Resolve issue
   * @param {string} issueId - Issue ID
   * @param {string} resolution - Resolution type
   * @param {string} notes - Resolution notes
   */
  resolveIssue(issueId, resolution = 'manual', notes = '') {
    const issue = this.detectedIssues.get(issueId);
    if (issue) {
      issue.status = 'resolved';
      issue.resolved = true;
      issue.resolvedAt = Date.now();
      issue.resolution = resolution;
      issue.resolutionNotes = notes;
      
      if (this.eventBus) {
        this.eventBus.emit('ISSUE_RESOLVED', issue);
      }
    }
  }

  /**
   * Reopen issue
   * @param {string} issueId - Issue ID
   */
  reopenIssue(issueId) {
    const issue = this.detectedIssues.get(issueId);
    if (issue) {
      issue.status = 'open';
      issue.resolved = false;
      issue.occurrences++;
      issue.lastDetectedAt = Date.now();
      
      if (this.eventBus) {
        this.eventBus.emit('ISSUE_REOPENED', issue);
      }
    }
  }

  /**
   * Get issue statistics
   */
  getStatistics() {
    const issues = Array.from(this.detectedIssues.values());
    
    const byStatus = {
      open: 0,
      resolved: 0,
      acknowledged: 0
    };
    
    const bySeverity = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0
    };
    
    const byCategory = {};
    
    issues.forEach(issue => {
      byStatus[issue.status]++;
      bySeverity[issue.severity]++;
      
      byCategory[issue.category] = (byCategory[issue.category] || 0) + 1;
    });
    
    return {
      total: issues.length,
      byStatus,
      bySeverity,
      byCategory,
      rulesActive: Array.from(this.rules.values()).filter(r => r.enabled).length
    };
  }

  /**
   * Generate issue ID
   */
  generateIssueId() {
    return `issue_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Set configuration
   * @param {Object} config - Configuration options
   */
  setConfig(config) {
    this.config = { ...this.config, ...config };
    
    if (config.checkInterval) {
      this.startDetection();
    }
  }

  /**
   * Get configuration
   */
  getConfig() {
    return { ...this.config };
  }

  /**
   * Export issues
   */
  exportIssues() {
    return {
      timestamp: Date.now(),
      issues: Array.from(this.detectedIssues.values()),
      statistics: this.getStatistics()
    };
  }

  /**
   * Reset all data
   */
  reset() {
    this.detectedIssues.clear();
    this.issuePatterns.clear();
  }
}

// Create singleton instance
const automatedIssueDetection = new AutomatedIssueDetection();

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { AutomatedIssueDetection, automatedIssueDetection };
}
