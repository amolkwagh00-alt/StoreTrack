// Accessibility Module - ARIA labels, keyboard navigation, and screen reader support

/**
 * Accessibility Manager class
 */
class AccessibilityManager {
  constructor() {
    this.focusStack = [];
    this.skipLinks = [];
    this.liveRegions = [];
    this.keyboardShortcuts = new Map();
    this.initialized = false;
    this.initScheduled = false;
    this.init();
  }

  /**
   * Initialize accessibility features
   */
  init() {
    if (this.initialized) return;
    if (document.readyState === 'loading' || !document.body) {
      if (!this.initScheduled) {
        this.initScheduled = true;
        document.addEventListener('DOMContentLoaded', () => {
          this.initScheduled = false;
          this.init();
        }, { once: true });
      }
      return;
    }
    this.initialized = true;
    this.setupSkipLinks();
    this.setupFocusManagement();
    this.setupKeyboardShortcuts();
    this.setupSidebarKeyboardActivation();
    this.setupInteractiveKeyboardSupport();
    this.setupLiveRegions();
    this.setupAriaLabels();
    this.setupDialogSemantics();
    this.setupFocusTraps();
    this.setupLandmarks();
    this.setupFocusVisible();
    this.respectMotionPreference();
  }

  /**
   * Setup skip links for keyboard navigation
   */
  setupSkipLinks() {
    if (!document.body) {return;} // Wait for DOM to be ready
    
    const skipLink = document.createElement('a');
    skipLink.href = '#main-content';
    skipLink.className = 'skip-link';
    skipLink.textContent = 'Skip to main content';
    skipLink.setAttribute('aria-label', 'Skip to main content');
    
    if (document.body.firstChild) {
      document.body.insertBefore(skipLink, document.body.firstChild);
    } else {
      document.body.appendChild(skipLink);
    }
    
    // Target the shared content region, not the first .sec: changing that
    // section's ID would break nav('dash') when returning to the dashboard.
    const mainContent = document.getElementById('main-content') ||
      document.querySelector('.content') || document.querySelector('main') || document.body;
    if (mainContent) {
      if (!mainContent.id) {mainContent.id = 'main-content';}
      skipLink.href = `#${mainContent.id}`;
      mainContent.setAttribute('tabindex', '-1');
    }
    
    this.skipLinks.push(skipLink);
  }

  /**
   * Setup focus management
   */
  setupFocusManagement() {
    document.addEventListener('focusin', (e) => {
      this.lastFocusedElement = e.target;
    });
    
    document.addEventListener('modal-closed', () => {
      const opener = this.activeDialogOpener || this.lastFocusedElement;
      if (opener && document.contains(opener)) {
        opener.focus();
      }
      this.activeDialogOpener = null;
    });
  }

  /**
   * Setup keyboard shortcuts
   */
  setupKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) {
        return;
      }
      
      if (e.altKey && e.key === 's') {
        e.preventDefault();
        const searchInput = document.querySelector('.topbar-search input, #search, [aria-label*="search"]');
        if (searchInput) {searchInput.focus();}
      }
      
      if (e.altKey && e.key === 'm') {
        e.preventDefault();
        const mainContent = document.getElementById('main-content');
        if (mainContent) {mainContent.focus();}
      }
      
      if (e.altKey && e.key === 'n') {
        e.preventDefault();
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
          const firstLink = sidebar.querySelector('a, button');
          if (firstLink) {firstLink.focus();}
        }
      }
      
      if (e.key === 'Escape') {
        this.closeOpenModals();
      }
    });
  }

  /** Enable Enter/Space activation for sidebar role=button controls using delegated events. */
  setupSidebarKeyboardActivation() {
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      const target = e.target;
      if (!target || target.isContentEditable || /^(INPUT|TEXTAREA|SELECT|BUTTON|A)$/.test(target.tagName)) return;
      const control = target.closest('.sidebar [role="button"][data-onclick]');
      if (!control || control.hasAttribute('data-onkeydown')) return;
      e.preventDefault();
      // Dispatch the same delegated click path used by pointer activation.
      control.click();
    });
  }

  /** Make every custom data-onclick control keyboard reachable and operable. */
  setupInteractiveKeyboardSupport() {
    const native = /^(A|BUTTON|INPUT|TEXTAREA|SELECT|SUMMARY)$/;
    const enhance = (root) => {
      if (!root || !root.querySelectorAll) return;
      const controls = root.matches?.('[data-onclick]') ? [root, ...root.querySelectorAll('[data-onclick]')] : [...root.querySelectorAll('[data-onclick]')];
      controls.forEach(control => {
        if (native.test(control.tagName) || control.hasAttribute('disabled')) return;
        if (!control.hasAttribute('tabindex')) control.setAttribute('tabindex', '0');
        if (!control.getAttribute('role')) control.setAttribute('role', control.classList.contains('tab') ? 'tab' : 'button');
        if (!control.getAttribute('aria-label')) {
          const label = String(control.textContent || '').replace(/\s+/g, ' ').trim();
          if (label) control.setAttribute('aria-label', label);
        }
      });
    };
    enhance(document.body);
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      const target = e.target;
      if (!target || native.test(target.tagName) || target.isContentEditable) return;
      const control = target.closest?.('[data-onclick]');
      if (!control || control.hasAttribute('disabled') || control.hasAttribute('data-onkeydown') || control.closest('.sidebar [role="button"][data-onclick]')) return;
      e.preventDefault();
      control.click();
    });
    if (document.body && typeof MutationObserver !== 'undefined') {
      const observer = new MutationObserver(mutations => mutations.forEach(mutation =>
        mutation.addedNodes.forEach(node => { if (node.nodeType === 1) enhance(node); })
      ));
      observer.observe(document.body, { childList: true, subtree: true });
    }
  }

  /**
   * Setup ARIA live regions for dynamic content
   */
  setupLiveRegions() {
    if (!document.body) {return;} // Wait for DOM to be ready
    
    const liveRegion = document.createElement('div');
    liveRegion.id = 'aria-live-region';
    liveRegion.setAttribute('role', 'status');
    liveRegion.setAttribute('aria-live', 'polite');
    liveRegion.setAttribute('aria-atomic', 'true');
    liveRegion.className = 'sr-only';
    document.body.appendChild(liveRegion);
    
    this.liveRegions.push(liveRegion);
  }

  /**
   * Setup ARIA labels for common elements
   */
  setupAriaLabels() {
    document.querySelectorAll('button:not([aria-label])').forEach(btn => {
      if (!btn.textContent.trim() && !btn.querySelector('img[alt]')) {
        const icon = btn.querySelector('i, svg');
        if (icon) {
          btn.setAttribute('aria-label', this.getIconLabel(icon));
        }
      }
    });
    
    document.querySelectorAll('input:not([aria-label]):not([aria-labelledby]), select:not([aria-label]):not([aria-labelledby]), textarea:not([aria-label]):not([aria-labelledby])').forEach(input => {
      if (!input.id) input.id = `accessible-input-${Math.random().toString(36).slice(2, 9)}`;
      const label = document.querySelector(`label[for="${input.id}"]`) || input.closest('label');
      if (label) {
        if (!label.id) label.id = `label-${input.id}`;
        input.setAttribute('aria-labelledby', label.id);
      } else {
        const fallback = input.getAttribute('placeholder') || input.getAttribute('name');
        if (fallback) input.setAttribute('aria-label', fallback);
      }
    });
    
    document.querySelectorAll('table:not([aria-label])').forEach(table => {
      const caption = table.querySelector('caption');
      if (caption) {
        table.setAttribute('aria-label', caption.textContent);
      } else {
        table.setAttribute('aria-label', 'Data table');
      }
    });
  }

  /** Add consistent names and hidden-state semantics to application dialogs. */
  setupDialogSemantics() {
    const enhance = (root) => {
      if (!root?.querySelectorAll) return;
      const dialogs = root.matches?.('.ov, .modal') ? [root, ...root.querySelectorAll('.ov, .modal')] : [...root.querySelectorAll('.ov, .modal')];
      dialogs.forEach(dialog => {
        if (dialog.classList.contains('modal') && dialog.closest('.ov')) return;
        dialog.setAttribute('role', 'dialog');
        dialog.setAttribute('aria-modal', 'true');
        const heading = dialog.querySelector('h1, h2, h3, h4, [data-dialog-title]');
        if (heading) {
          if (!heading.id) heading.id = `dialog-title-${Math.random().toString(36).slice(2, 9)}`;
          dialog.setAttribute('aria-labelledby', heading.id);
        } else if (!dialog.getAttribute('aria-label')) {
          dialog.setAttribute('aria-label', 'Dialog');
        }
        dialog.querySelectorAll('.modal-x, .close-modal, button[title="Close"]').forEach(button => {
          if (!button.getAttribute('aria-label')) button.setAttribute('aria-label', 'Close dialog');
        });
        if (dialog.classList.contains('ov')) dialog.setAttribute('aria-hidden', dialog.classList.contains('on') ? 'false' : 'true');
      });
    };
    enhance(document.body);
    if (document.body && typeof MutationObserver !== 'undefined') {
      const observer = new MutationObserver(mutations => mutations.forEach(mutation => {
        if (mutation.type === 'attributes' && mutation.target.classList?.contains('ov')) {
          mutation.target.setAttribute('aria-hidden', mutation.target.classList.contains('on') ? 'false' : 'true');
        }
        mutation.addedNodes.forEach(node => { if (node.nodeType === 1) enhance(node); });
      }));
      observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    }
  }

  /**
   * Setup focus traps for modals
   */
  setupFocusTraps() {
    const attach = () => {
      const observer = new MutationObserver((mutations) => {
        mutations.forEach(mutation => {
          mutation.addedNodes.forEach(node => {
            if (node.nodeType === 1) {
              if (node.classList && node.classList.contains('modal') && node.style.display !== 'none') {
                this.trapFocus(node);
              }
              const modals = node.querySelectorAll ? node.querySelectorAll('.modal') : [];
              modals.forEach(modal => {
                if (modal.style.display !== 'none') {
                  this.trapFocus(modal);
                }
              });
            }
          });
        });
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    };

    // Scripts load in <head>, so document.body may not exist yet
    if (document.body) {
      attach();
    } else {
      document.addEventListener('DOMContentLoaded', attach, { once: true });
    }
  }

  /**
   * Trap focus within an element
   */
  trapFocus(element) {
    const focusableElements = element.querySelectorAll(
      'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
    );
    
    if (focusableElements.length === 0) {return;}
    
    const opener = document.activeElement && !element.contains(document.activeElement) ? document.activeElement : this.lastFocusedElement;
    element.__a11yOpener = opener;
    this.activeDialogOpener = opener;
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];
    
    firstElement.focus();
    
    element.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        if (e.shiftKey) {
          if (document.activeElement === firstElement) {
            e.preventDefault();
            lastElement.focus();
          }
        } else {
          if (document.activeElement === lastElement) {
            e.preventDefault();
            firstElement.focus();
          }
        }
      }
    });
  }

  /**
   * Close open modals
   */
  closeOpenModals() {
    const modals = document.querySelectorAll('.ov.on .modal, .modal.widget-settings-modal');
    modals.forEach(modal => {
      const closeBtn = modal.querySelector('.close-modal, [aria-label*="close"], button.close');
      if (closeBtn) {
        closeBtn.click();
      }
    });
  }

  /**
   * Announce message to screen readers
   */
  announce(message, priority = 'polite') {
    const liveRegion = document.getElementById('aria-live-region');
    if (liveRegion) {
      liveRegion.setAttribute('aria-live', priority);
      liveRegion.textContent = '';
      setTimeout(() => {
        liveRegion.textContent = message;
      }, 100);
    }
  }

  /**
   * Get label for icon based on class names
   */
  getIconLabel(icon) {
    const className = icon.className || '';
    
    if (className.includes('close') || className.includes('times')) {return 'Close';}
    if (className.includes('menu') || className.includes('bars')) {return 'Menu';}
    if (className.includes('search') || className.includes('magnify')) {return 'Search';}
    if (className.includes('edit') || className.includes('pencil')) {return 'Edit';}
    if (className.includes('delete') || className.includes('trash')) {return 'Delete';}
    if (className.includes('add') || className.includes('plus')) {return 'Add';}
    if (className.includes('save') || className.includes('check')) {return 'Save';}
    if (className.includes('print')) {return 'Print';}
    if (className.includes('download')) {return 'Download';}
    if (className.includes('upload')) {return 'Upload';}
    if (className.includes('refresh')) {return 'Refresh';}
    if (className.includes('filter')) {return 'Filter';}
    if (className.includes('sort')) {return 'Sort';}
    
    return 'Button';
  }

  /**
   * Setup landmark roles
   */
  setupLandmarks() {
    const main = document.querySelector('.sec, main');
    if (main && !main.getAttribute('role')) {
      main.setAttribute('role', 'main');
    }
    
    const nav = document.querySelector('.sidebar, nav');
    if (nav && !nav.getAttribute('role')) {
      nav.setAttribute('role', 'navigation');
      nav.setAttribute('aria-label', 'Main navigation');
    }
    
    const header = document.querySelector('.topbar, header');
    if (header && !header.getAttribute('role')) {
      header.setAttribute('role', 'banner');
    }
    
    const footer = document.querySelector('footer');
    if (footer && !footer.getAttribute('role')) {
      footer.setAttribute('role', 'contentinfo');
    }
  }

  /**
   * Setup focus visible indicator
   */
  setupFocusVisible() {
    const attach = () => {
      document.body.addEventListener('keydown', (e) => {
        if (e.key === 'Tab') {
          document.body.classList.add('using-keyboard');
        }
      });

      document.body.addEventListener('mousedown', () => {
        document.body.classList.remove('using-keyboard');
      });
    };

    if (document.body) {
      attach();
    } else {
      document.addEventListener('DOMContentLoaded', attach, { once: true });
    }
  }

  /**
   * Respect reduced motion preference
   */
  respectMotionPreference() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      document.documentElement.style.setProperty('--animation-duration', '0ms');
      document.documentElement.style.setProperty('--transition-duration', '0ms');
    }
  }
}

const accessibilityManager = new AccessibilityManager();

if (typeof window !== 'undefined') {
  window.Accessibility = {
    manager: accessibilityManager,
    announce: (msg, priority) => accessibilityManager.announce(msg, priority)
  };
}
