// Push Notifications Module - Mobile push notification management

/**
 * Push Notification class
 */
class PushNotification {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.userId = config.userId || '';
    this.deviceId = config.deviceId || '';
    this.type = config.type || 'info'; // info, warning, error, success
    this.category = config.category || 'general'; // general, inventory, order, alert, system
    this.title = config.title || '';
    this.message = config.message || '';
    this.data = config.data || {};
    this.priority = config.priority || 'normal'; // low, normal, high
    this.sentAt = config.sentAt || new Date().toISOString();
    this.deliveredAt = config.deliveredAt || null;
    this.readAt = config.readAt || null;
    this.status = config.status || 'pending'; // pending, sent, delivered, failed
    this.expiresAt = config.expiresAt || null;
    this.actionUrl = config.actionUrl || '';
    this.actionLabel = config.actionLabel || '';
  }

  generateId() {
    return `notification-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Mark as delivered
   */
  markAsDelivered() {
    this.status = 'delivered';
    this.deliveredAt = new Date().toISOString();
  }

  /**
   * Mark as read
   */
  markAsRead() {
    this.readAt = new Date().toISOString();
  }

  /**
   * Is expired
   * @returns {boolean} - Is expired
   */
  isExpired() {
    if (!this.expiresAt) {return false;}
    return new Date() >= new Date(this.expiresAt);
  }
}

/**
 * Device Subscription class
 */
class DeviceSubscription {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.userId = config.userId || '';
    this.deviceId = config.deviceId || '';
    this.platform = config.platform || 'web'; // web, ios, android
    this.subscriptionToken = config.subscriptionToken || '';
    this.enabled = config.enabled !== false;
    this.preferences = config.preferences || {};
    this.subscribedAt = config.subscribedAt || new Date().toISOString();
    this.lastActive = config.lastActive || new Date().toISOString();
  }

  generateId() {
    return `subscription-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Has permission for category
   * @param {string} category - Category to check
   * @returns {boolean} - Has permission
   */
  hasPermission(category) {
    if (!this.preferences.categories) {return true;}
    return this.preferences.categories.includes(category) !== false;
  }
}

/**
 * Notification Template class
 */
class PushNotificationTemplate {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.name = config.name || '';
    this.category = config.category || 'general';
    this.type = config.type || 'info';
    this.titleTemplate = config.titleTemplate || '';
    this.messageTemplate = config.messageTemplate || '';
    this.priority = config.priority || 'normal';
    this.actionUrlTemplate = config.actionUrlTemplate || '';
    this.actionLabelTemplate = config.actionLabelTemplate || '';
    this.enabled = config.enabled !== false;
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `template-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Render template with data
   * @param {object} data - Template data
   * @returns {object} - Rendered notification
   */
  render(data) {
    const renderString = (template) => {
      return template.replace(/\{\{(\w+)\}\}/g, (match, key) => data[key] || match);
    };

    return {
      title: renderString(this.titleTemplate),
      message: renderString(this.messageTemplate),
      actionUrl: renderString(this.actionUrlTemplate),
      actionLabel: renderString(this.actionLabelTemplate)
    };
  }
}

/**
 * Push Notifications Manager
 */
class PushNotificationsManager {
  constructor() {
    this.notifications = new Map();
    this.subscriptions = new Map();
    this.templates = new Map();
    this.config = {
      enabled: true,
      batchSize: 100,
      retryAttempts: 3,
      retryDelay: 60000
    };
    this.init();
  }

  /**
   * Initialize push notifications manager
   */
  async init() {
    await this.loadNotifications();
    await this.loadSubscriptions();
    await this.loadTemplates();
    this.requestPermission();
  }

  /**
   * Load notifications from storage
   */
  async loadNotifications() {
    try {
      const notifications = await gAll('push_notifications');
      notifications.forEach(n => {
        this.notifications.set(n.id, new PushNotification(n));
      });
    } catch (err) {
      console.error('Failed to load push notifications:', err);
    }
  }

  /**
   * Load subscriptions from storage
   */
  async loadSubscriptions() {
    try {
      const subscriptions = await gAll('device_subscriptions');
      subscriptions.forEach(s => {
        this.subscriptions.set(s.id, new DeviceSubscription(s));
      });
    } catch (err) {
      console.error('Failed to load device subscriptions:', err);
    }
  }

  /**
   * Load templates from storage
   */
  async loadTemplates() {
    try {
      const templates = await gAll('notification_templates');
      templates.forEach(t => {
        this.templates.set(t.id, new PushNotificationTemplate(t));
      });
    } catch (err) {
      console.error('Failed to load notification templates:', err);
    }
  }

  /**
   * Request notification permission
   */
  async requestPermission() {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'default') {
        await Notification.requestPermission();
      }
    }
  }

  /**
   * Register device
   * @param {object} subscriptionData - Subscription data
   * @returns {DeviceSubscription} - Created subscription
   */
  async registerDevice(subscriptionData) {
    const subscription = new DeviceSubscription(subscriptionData);
    this.subscriptions.set(subscription.id, subscription);
    await this.saveSubscription(subscription);
    return subscription;
  }

  /**
   * Unregister device
   * @param {string} deviceId - Device ID
   */
  async unregisterDevice(deviceId) {
    const subscription = this.getSubscriptionByDeviceId(deviceId);
    if (subscription) {
      this.subscriptions.delete(subscription.id);
      await dDel('device_subscriptions', subscription.id);
    }
  }

  /**
   * Save subscription to storage
   * @param {DeviceSubscription} subscription - Subscription to save
   */
  async saveSubscription(subscription) {
    try {
      await dPut('device_subscriptions', subscription);
    } catch (err) {
      console.error('Failed to save device subscription:', err);
    }
  }

  /**
   * Send notification
   * @param {object} notificationData - Notification data
   * @returns {Promise<PushNotification>} - Sent notification
   */
  async sendNotification(notificationData) {
    const notification = new PushNotification(notificationData);
    this.notifications.set(notification.id, notification);
    await this.saveNotification(notification);

    // Send to browser if available
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      this.displayBrowserNotification(notification);
    }

    // Log activity
    if (typeof window !== 'undefined' && window.ActivityTracking) {
      await window.ActivityTracking.logActivity('notification_sent', 'notification', notification.id, {
        type: notification.type,
        category: notification.category,
        userId: notification.userId
      });
    }

    return notification;
  }

  /**
   * Send notification using template
   * @param {string} templateName - Template name
   * @param {object} data - Template data
   * @param {object} overrides - Notification overrides
   * @returns {Promise<PushNotification>} - Sent notification
   */
  async sendFromTemplate(templateName, data, overrides = {}) {
    const template = this.getTemplateByName(templateName);
    
    if (!template) {
      throw new Error(`Template not found: ${templateName}`);
    }

    const rendered = template.render(data);
    
    return this.sendNotification({
      ...overrides,
      ...rendered,
      type: template.type,
      category: template.category,
      priority: template.priority
    });
  }

  /**
   * Send to user
   * @param {string} userId - User ID
   * @param {object} notificationData - Notification data
   * @returns {Promise<Array>} - Sent notifications
   */
  async sendToUser(userId, notificationData) {
    const userSubscriptions = this.getSubscriptionsByUser(userId);
    const sent = [];

    for (const subscription of userSubscriptions) {
      if (!subscription.enabled) {continue;}
      if (!subscription.hasPermission(notificationData.category)) {continue;}

      const notification = await this.sendNotification({
        ...notificationData,
        userId,
        deviceId: subscription.deviceId
      });

      sent.push(notification);
    }

    return sent;
  }

  /**
   * Send broadcast
   * @param {object} notificationData - Notification data
   * @returns {Promise<Array>} - Sent notifications
   */
  async sendBroadcast(notificationData) {
    const enabledSubscriptions = Array.from(this.subscriptions.values()).filter(s => s.enabled);
    const sent = [];

    for (const subscription of enabledSubscriptions) {
      if (!subscription.hasPermission(notificationData.category)) {continue;}

      const notification = await this.sendNotification({
        ...notificationData,
        userId: subscription.userId,
        deviceId: subscription.deviceId
      });

      sent.push(notification);
    }

    return sent;
  }

  /**
   * Display browser notification
   * @param {PushNotification} notification - Notification to display
   */
  displayBrowserNotification(notification) {
    const browserNotification = new Notification(notification.title, {
      body: notification.message,
      icon: 'assets/icon.png',
      tag: notification.id,
      data: notification.data
    });

    browserNotification.onclick = () => {
      if (notification.actionUrl) {
        window.open(notification.actionUrl, '_blank');
      }
      browserNotification.close();
    };
  }

  /**
   * Save notification to storage
   * @param {PushNotification} notification - Notification to save
   */
  async saveNotification(notification) {
    try {
      await dPut('push_notifications', notification);
    } catch (err) {
      console.error('Failed to save push notification:', err);
    }
  }

  /**
   * Mark as delivered
   * @param {string} id - Notification ID
   */
  async markAsDelivered(id) {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.markAsDelivered();
      await this.saveNotification(notification);
    }
  }

  /**
   * Mark as read
   * @param {string} id - Notification ID
   */
  async markAsRead(id) {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.markAsRead();
      await this.saveNotification(notification);
    }
  }

  /**
   * Create template
   * @param {object} config - Template configuration
   * @returns {PushNotificationTemplate} - Created template
   */
  async createTemplate(config) {
    const template = new PushNotificationTemplate(config);
    this.templates.set(template.id, template);
    await this.saveTemplate(template);
    return template;
  }

  /**
   * Save template to storage
   * @param {PushNotificationTemplate} template - Template to save
   */
  async saveTemplate(template) {
    try {
      await dPut('notification_templates', template);
    } catch (err) {
      console.error('Failed to save notification template:', err);
    }
  }

  /**
   * Get notification
   * @param {string} id - Notification ID
   * @returns {PushNotification} - Notification
   */
  getNotification(id) {
    return this.notifications.get(id);
  }

  /**
   * Get notifications by user
   * @param {string} userId - User ID
   * @returns {Array} - Notifications
   */
  getNotificationsByUser(userId) {
    return Array.from(this.notifications.values()).filter(n => n.userId === userId);
  }

  /**
   * Get unread notifications
   * @param {string} userId - User ID
   * @returns {Array} - Unread notifications
   */
  getUnreadNotifications(userId) {
    return this.getNotificationsByUser(userId).filter(n => !n.readAt);
  }

  /**
   * Get subscription
   * @param {string} id - Subscription ID
   * @returns {DeviceSubscription} - Subscription
   */
  getSubscription(id) {
    return this.subscriptions.get(id);
  }

  /**
   * Get subscription by device ID
   * @param {string} deviceId - Device ID
   * @returns {DeviceSubscription} - Subscription
   */
  getSubscriptionByDeviceId(deviceId) {
    return Array.from(this.subscriptions.values()).find(s => s.deviceId === deviceId);
  }

  /**
   * Get subscriptions by user
   * @param {string} userId - User ID
   * @returns {Array} - Subscriptions
   */
  getSubscriptionsByUser(userId) {
    return Array.from(this.subscriptions.values()).filter(s => s.userId === userId);
  }

  /**
   * Get template
   * @param {string} id - Template ID
   * @returns {PushNotificationTemplate} - Template
   */
  getTemplate(id) {
    return this.templates.get(id);
  }

  /**
   * Get template by name
   * @param {string} name - Template name
   * @returns {PushNotificationTemplate} - Template
   */
  getTemplateByName(name) {
    return Array.from(this.templates.values()).find(t => t.name === name);
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const notifications = Array.from(this.notifications.values());
    const subscriptions = Array.from(this.subscriptions.values());

    return {
      totalNotifications: notifications.length,
      byStatus: this.getStatusCounts(notifications),
      byCategory: this.getCategoryCounts(notifications),
      byType: this.getTypeCounts(notifications),
      unread: notifications.filter(n => !n.readAt).length,
      totalSubscriptions: subscriptions.length,
      activeSubscriptions: subscriptions.filter(s => s.enabled).length,
      byPlatform: this.getPlatformCounts(subscriptions),
      totalTemplates: this.templates.size,
      enabledTemplates: Array.from(this.templates.values()).filter(t => t.enabled).length
    };
  }

  /**
   * Get status counts
   * @param {Array} notifications - Notifications
   * @returns {object} - Status counts
   */
  getStatusCounts(notifications) {
    const counts = {};
    notifications.forEach(n => {
      counts[n.status] = (counts[n.status] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get category counts
   * @param {Array} notifications - Notifications
   * @returns {object} - Category counts
   */
  getCategoryCounts(notifications) {
    const counts = {};
    notifications.forEach(n => {
      counts[n.category] = (counts[n.category] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get type counts
   * @param {Array} notifications - Notifications
   * @returns {object} - Type counts
   */
  getTypeCounts(notifications) {
    const counts = {};
    notifications.forEach(n => {
      counts[n.type] = (counts[n.type] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get platform counts
   * @param {Array} subscriptions - Subscriptions
   * @returns {object} - Platform counts
   */
  getPlatformCounts(subscriptions) {
    const counts = {};
    subscriptions.forEach(s => {
      counts[s.platform] = (counts[s.platform] || 0) + 1;
    });
    return counts;
  }
}

/**
 * Global push notifications manager instance
 */
const pushNotificationsManager = new PushNotificationsManager();

/**
 * Initialize push notifications
 */
async function initPushNotifications() {
  await pushNotificationsManager.init();
  return pushNotificationsManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.PushNotifications = {
    manager: pushNotificationsManager,
    init: initPushNotifications,
    registerDevice: (data) => pushNotificationsManager.registerDevice(data),
    unregisterDevice: (deviceId) => pushNotificationsManager.unregisterDevice(deviceId),
    send: (data) => pushNotificationsManager.sendNotification(data),
    sendFromTemplate: (templateName, data, overrides) => pushNotificationsManager.sendFromTemplate(templateName, data, overrides),
    sendToUser: (userId, data) => pushNotificationsManager.sendToUser(userId, data),
    sendBroadcast: (data) => pushNotificationsManager.sendBroadcast(data),
    markAsDelivered: (id) => pushNotificationsManager.markAsDelivered(id),
    markAsRead: (id) => pushNotificationsManager.markAsRead(id),
    createTemplate: (config) => pushNotificationsManager.createTemplate(config),
    getNotification: (id) => pushNotificationsManager.getNotification(id),
    getNotificationsByUser: (userId) => pushNotificationsManager.getNotificationsByUser(userId),
    getUnreadNotifications: (userId) => pushNotificationsManager.getUnreadNotifications(userId),
    getSubscription: (id) => pushNotificationsManager.getSubscription(id),
    getSubscriptionByDeviceId: (deviceId) => pushNotificationsManager.getSubscriptionByDeviceId(deviceId),
    getSubscriptionsByUser: (userId) => pushNotificationsManager.getSubscriptionsByUser(userId),
    getTemplate: (id) => pushNotificationsManager.getTemplate(id),
    getTemplateByName: (name) => pushNotificationsManager.getTemplateByName(name),
    getStats: () => pushNotificationsManager.getStatistics()
  };
}
