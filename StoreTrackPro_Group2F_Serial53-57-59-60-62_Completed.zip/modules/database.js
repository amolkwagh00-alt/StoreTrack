// ── IndexedDB Module ──
// Use a fresh database identity for the rollback-clean release. The previous
// StoreTrackDB database is intentionally not reused because it can contain
// imported Shank Mapping rows from an older build and IndexedDB is shared by
// Electron file:// app launches, even when the project is exported to a new
// folder. This keeps a new export empty before the first import.
const DB = 'StoreTrackDB_ShankMapping_Clean_20260825';
const VER = 23; // v23: atomic Shank allocation batch history and undo snapshots. // v22: Shank Mapping BI approval workflow, report schedules, and recommendation feedback stores. // v21: historical Shank consumption imports must not mutate current stock.
  // v16→v17: add printer profiles and QR scan audit records.
  // v15→v16: add Shank Consumption Analytics configuration and label tracking stores.
                // v6→v7: added automated_alerts, alert_rules, archive_policies, archive_records,
                // stock_predictions, recommendations, material_photos, notifications,
                // notification_preferences, notification_channels, notification_templates.
                // MUST bump this whenever a store is added, or existing installs (already
                // at a lower version) never get onupgradeneeded and the new stores never
                // get created — this is exactly what caused the "object store not found" errors.
                //
                // Cleanup note (no VER bump needed for this): removed 57 stores from STORES
                // below that were declared but never read/written by any module (tenants/
                // billing/RFID/sensor-shelf/ERP-ecommerce-connector/API-token style entries
                // that don't correspond to any feature this app actually has). Removing an
                // entry from STORES is safe without bumping VER since onupgradeneeded only
                // ever *creates* stores that are missing -- it never deletes ones that already
                // exist on a given install, so this only affects what fresh installs create.
let db = null;

const STORES = [
  'materials',
  'transactions',
  'users',
  'audit',
  'approvals',
  'adjustments',
  'suppliers',
  'departments',
  'config',
  'indents',
  'cyclecount',
  'returns',
  'grn',
  'locations',
  'movements',
  'machine_spares',
  'pm_schedules',
  'pm_checklists',
  // ── Added for Batch 3 core/ integration work: automatedAlerts.js,
  // dataArchiving.js, predictiveAnalytics.js, smartRecommendations.js, and
  // imageRecognition.js all needed real backing stores that didn't exist ──
  'automated_alerts',
  'alert_rules',
  'archive_policies',
  'archive_records',
  'stock_predictions',
  'recommendations',
  'notifications',
  'notification_preferences',
  'notification_channels',
  'notification_templates',
  'cache_entries',
  'device_subscriptions',
  'push_notifications',
  // ── Added in VER 6: twoFactorAuth.js reads/writes these two stores but they
  // were never declared, causing "NotFoundError: object store not found" on
  // every app startup when loading 2FA secrets / backup codes ──
  '2fa_secrets',
  '2fa_backup_codes',
  // ── Added in VER 5: stores required by feature modules that were
  // previously missing from the schema, causing "object store not found" errors ──
  'activity_feed',
  'activity_logs',
  'audit_logs',
  'audit_settings',
  'bin_locations',
  'cache_layer',
  'collaborative_documents',
  'collaborative_operations',
  'dashboards',
  'demand_forecasts',
  'encryption_fields',
  'encryption_key',
  'encryption_settings',
  'index_hints',
  'packages',
  'packing_lists',
  'pick_orders',
  'pick_routes',
  'purchase_orders',
  'query_plans',
  'report_run_history',
  'report_templates',
  'return_inspections',
  'return_items',
  'return_requests',
  'saved_filters',
  'saved_sorts',
  'scheduled_exports',
  'scheduled_reports',
  'search_history',
  'sessions',
  'shipments',
  'supplier_contacts',
  'supplier_evaluations',
  'supplier_items',
  'supplier_performance_metrics',
  'user_activity_feeds',
  'user_groups',
  'warehouse_zones',
  'widget_configs',
  'central_queue',
  'central_meta',
  // Component Management domain
  'component_parts',
  'component_mappings',
  'component_bins',
  'component_stock',
  'component_stock_transactions',
  'component_repair_scrap',
  'component_import_history',
  'component_audit_log',
  'maintenance_people',
  'component_replacements',
  'component_import_snapshots',
  'component_mapping_revisions',
  'component_station_aliases',
  'component_import_configs',
  'component_month_end_closes',
  'component_station_merge_history',
  'component_gun_rows',
  'component_gun_counts',
  'component_analytics_config',
  'component_label_versions',
  'component_printer_profiles',
  'component_qr_audit',
  // v19: Consumption Analytics & Procurement stores
  'component_part_forecast_configs',
  'component_procurement_orders',
  // v21: historical Shank consumption imports must not mutate current stock
  'component_historical_consumption',
  // v23: atomic shank receiving allocation batches and undo snapshots
  'component_allocation_batches',
  // v22: Shank Mapping BI production workflow stores
  'component_bi_approvals',
  'component_bi_schedules',
  'component_bi_feedback'
];

// ── Optimized Index Configuration ──
// Defines indexes for each store based on typical query patterns
const INDEX_CONFIG = {
  materials: ['name', 'category', 'location', 'barcode', 'status', 'createdAt'],
  transactions: ['type', 'materialId', 'date', 'userId', 'status'],
  users: ['username', 'role', 'active', 'email'],
  audit: ['userId', 'action', 'timestamp', 'entity'],
  suppliers: ['name', 'status', 'category'],
  locations: ['name', 'type', 'zone'],
  movements: ['materialId', 'fromLocation', 'toLocation', 'date'],
  notifications: ['userId', 'read', 'type', 'createdAt'],
  sessions: ['userId', 'createdAt', 'expiresAt'],
  purchase_orders: ['supplierId', 'status', 'createdAt', 'expectedDate'],
  stock_predictions: ['materialId', 'date', 'modelType'],
  anomalies: ['materialId', 'type', 'severity', 'detectedAt'],
  demand_forecasts: ['materialId', 'period', 'modelType'],
  maintenance_people: ['name', 'department', 'active'],
  component_replacements: ['maintenancePersonId', 'stationNo', 'partNo', 'replacementDateTime', 'loggedInUser'],
  component_parts: ['partNo', 'componentType', 'active', 'status', 'minimumStock'],
  component_mappings: ['stationNo', 'gunReferenceNo', 'position', 'partNo', 'sourceSheet'],
  component_bins: ['stationNo', 'binId', 'active', 'location'],
  component_stock: ['partNo', 'binId', 'quantity', 'minimumStock', 'status'],
  component_stock_transactions: ['partNo', 'binId', 'type', 'date', 'stationNo', 'gunReferenceNo', 'userId'],
  component_repair_scrap: ['partNo', 'status', 'stationNo', 'gunReferenceNo', 'date', 'userId'],
  component_import_history: ['importedAt', 'sourceFile', 'status', 'userId'],
  component_audit_log: ['action', 'timestamp', 'userId', 'entityId'],
  component_import_snapshots: ['importId', 'createdAt', 'userId'],
  component_mapping_revisions: ['mappingId', 'changedAt', 'stationNo', 'gunReferenceNo', 'userId'],
  component_station_aliases: ['canonicalStation', 'alias', 'status'],
  component_import_configs: ['importId', 'sheetName', 'columnMappings', 'userId'],
  component_month_end_closes: ['month', 'closedAt', 'userId'],
  component_station_merge_history: ['source', 'target', 'createdAt', 'userId'],
  component_gun_rows: ['sourceKey', 'sourceFile', 'sourceSheet', 'sourceRow', 'stationNo', 'gunReferenceNo'],
  component_gun_counts: ['scope', 'stationNo', 'gunCount', 'calculatedAt'],
  component_analytics_config: ['updatedAt'],
  component_label_versions: ['stationNo', 'binId', 'mappingVersion', 'printedAt', 'outdated'],
  component_printer_profiles: ['name', 'width', 'height', 'dpi', 'updatedAt'],
  component_qr_audit: ['stationNo', 'binId', 'scannedAt', 'userId'],
  component_part_forecast_configs: ['partNo', 'updatedAt'],
  component_procurement_orders: ['partNo', 'binId', 'orderStatus', 'orderDate', 'expectedArrivalDate'],
  component_historical_consumption: ['partNo', 'replacementDate', 'date', 'stationNo', 'gunReferenceNo', 'sourceFile', 'importedAt'],
  component_allocation_batches: ['partNo', 'status', 'createdAt', 'username'],
  component_bi_approvals: ['type', 'status', 'partNo', 'createdAt', 'updatedAt'],
  component_bi_schedules: ['reportType', 'frequency', 'status', 'updatedAt'],
  component_bi_feedback: ['type', 'userId', 'createdAt']
};

/**
 * Add optimized indexes to a store based on its type
 * @param {IDBObjectStore} store - The object store to add indexes to
 * @param {string} storeName - Name of the store
 */
function addOptimizedIndexes(store, storeName) {
  const indexes = INDEX_CONFIG[storeName] || [];
  
  indexes.forEach(indexName => {
    if (!store.indexNames.contains(indexName)) {
      store.createIndex(indexName, indexName, { unique: false });
    }
  });
  
  // Add compound indexes for frequently queried combinations
  addCompoundIndexes(store, storeName);
}

/**
 * Add compound indexes for complex queries
 * @param {IDBObjectStore} store - The object store
 * @param {string} storeName - Name of the store
 */
function addCompoundIndexes(store, storeName) {
  const compoundIndexes = {
    transactions: [
      { name: 'type_date', keyPath: ['type', 'date'] },
      { name: 'materialId_date', keyPath: ['materialId', 'date'] }
    ],
    movements: [
      { name: 'materialId_date', keyPath: ['materialId', 'date'] },
      { name: 'fromLocation_toLocation', keyPath: ['fromLocation', 'toLocation'] }
    ],
    audit: [
      { name: 'userId_timestamp', keyPath: ['userId', 'timestamp'] },
      { name: 'action_timestamp', keyPath: ['action', 'timestamp'] }
    ],
    notifications: [
      { name: 'userId_read', keyPath: ['userId', 'read'] },
      { name: 'type_createdAt', keyPath: ['type', 'createdAt'] }
    ]
  };
  
  const indexes = compoundIndexes[storeName] || [];
  indexes.forEach(({ name, keyPath }) => {
    if (!store.indexNames.contains(name)) {
      store.createIndex(name, keyPath, { unique: false });
    }
  });
}

// ── DB-ready gate ──
// Every module in /modules/*.js instantiates its manager singleton as soon as its
// <script> tag loads (e.g. `const foo = new FooManager()`), which happens well
// before initDB() resolves at the bottom of app.js. Previously gAll/dPut/gOne/dClr
// checked `if (!db)` and immediately warned + returned empty/rejected, so every one
// of those ~140 managers logged "Database not initialized yet" on first load.
// Fix: these functions now AWAIT readiness instead of failing when called early.
let _dbReadyResolve;
const _dbReadyPromise = new Promise(resolve => { _dbReadyResolve = resolve; });

function _waitForDB() {
  if (db) {return Promise.resolve(db);}
  return _dbReadyPromise;
}

/**
 * Initialize IndexedDB database
 * @returns {Promise<void>}
 */
function initDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB, VER);
    r.onupgradeneeded = e => {
      const d = e.target.result;
      STORES.forEach(s => {
        const store = d.objectStoreNames.contains(s)
          ? e.target.transaction.objectStore(s)
          : d.createObjectStore(s, { keyPath: 'id', autoIncrement: true });
        // Index creation is idempotent and therefore also runs for existing stores.
        addOptimizedIndexes(store, s);
      });
    };
    // FIX: without this handler, a version upgrade (VER bump) blocks silently
    // forever whenever another tab/window/renderer still has an older-version
    // connection open — indexedDB.open() then never fires onsuccess OR onerror,
    // so initDB()'s promise hangs and every caller awaiting databaseReady
    // (doLogin, etc.) freezes with no error shown at all.
    r.onblocked = e => {
      console.error('[initDB] Upgrade blocked — another open tab/window/instance of this app is still holding an older version of the database. Close all other windows/instances of StoreTrack Pro V8 and reload.');
      rej(new Error('Database upgrade blocked by another open connection. Please close all other windows/instances of this app and reload.'));
    };
    r.onsuccess = e => {
      db = e.target.result;
      db.onversionchange = () => {
        db.close();
        window.databaseReady = false;
        document.dispatchEvent(new Event('databaseVersionChanged'));
      };
      window.databaseReady = true;
      document.dispatchEvent(new Event('databaseReady'));
      _dbReadyResolve(db);
      res();
    };
    r.onerror = rej;
  });
}

/**
 * Get all records from a store
 * @param {string} storeName - Name of the object store
 * @returns {Promise<Array>}
 */
function assertStoreName(storeName) {
  if (!STORES.includes(storeName)) {throw new Error(`Unknown database store: ${storeName}`);}
}

function invalidateStockForecastCache(storeNames) {
  const changedStores = Array.isArray(storeNames) ? storeNames : [storeNames];
  if (!changedStores.some(store => store === 'materials' || store === 'transactions')) return;
  if (typeof window !== 'undefined' && typeof window.cacheManager?.delete === 'function') {
    window.cacheManager.delete('stock-forecast');
  }
}

function localSaveStart() {
  try { return performance.now(); } catch (_) { return Date.now(); }
}
function localSaveEnd(startedAt) {
  try {
    const endedAt = performance.now();
    window.performanceMonitor?.record('indexeddb-save', endedAt - startedAt, { category: 'localSave' });
  } catch (_) { /* Performance instrumentation must never affect persistence. */ }
}

async function gAll(storeName) {
  assertStoreName(storeName);
  await _waitForDB();
  return new Promise((res, rej) => {
    const r = db.transaction(storeName, 'readonly').objectStore(storeName).getAll();
    r.onsuccess = async () => {
      try {
        const rows = r.result || [];
        if (window.DataEncryption?.manager?.restoreFromStorage) {
          res(await Promise.all(rows.map(row => window.DataEncryption.manager.restoreFromStorage(storeName, row))));
        } else res(rows);
      } catch (error) { rej(error); }
    };
    r.onerror = rej;
  });
}

/**
 * Put or update a record in a store
 * @param {string} storeName - Name of the object store
 * @param {Object} obj - Object to store
 * @returns {Promise<number>} - The key of the stored record
 */
async function dPut(storeName, obj) {
  const saveStartedAt = localSaveStart();
  assertStoreName(storeName);
  await _waitForDB();
  const write = window.DataEncryption?.manager?.prepareForStorage
    ? await window.DataEncryption.manager.prepareForStorage(storeName, obj)
    : obj;
  return new Promise((res, rej) => {
    const r = db.transaction(storeName, 'readwrite').objectStore(storeName).put(write);
    r.onsuccess = () => {
      invalidateStockForecastCache(storeName);
      localSaveEnd(saveStartedAt);
      res(r.result);
    };
    r.onerror = error => { localSaveEnd(saveStartedAt); rej(error); };
  });
}

/**
 * Put or update multiple records in a store in a single transaction
 * @param {string} storeName - Name of the object store
 * @param {Array<Object>} objs - Objects to store
 * @returns {Promise<void>}
 */
async function batchPut(storeName, objs) {
  const saveStartedAt = localSaveStart();
  assertStoreName(storeName);
  await _waitForDB();
  const prepared = await Promise.all((objs || []).map(obj =>
    window.DataEncryption?.manager?.prepareForStorage
      ? window.DataEncryption.manager.prepareForStorage(storeName, obj)
      : obj
  ));
  return new Promise((res, rej) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    prepared.forEach(obj => store.put(obj));
    tx.oncomplete = () => {
      invalidateStockForecastCache(storeName);
      localSaveEnd(saveStartedAt);
      res();
    };
    tx.onerror = () => { localSaveEnd(saveStartedAt); rej(tx.error); };
  });
}

/**
 * Atomically put or delete records across one or more stores.
 * Put entries use { store, obj }; delete entries use { store, operation: 'delete', key }.
 * @param {Array<Object>} writes - Store mutations to commit in one transaction
 * @returns {Promise<void>}
 */
async function dPutMany(writes) {
  const saveStartedAt = localSaveStart();
  const entries = Array.isArray(writes) ? writes : [];
  const stores = [...new Set(entries.map(write => write?.store).filter(Boolean))];
  stores.forEach(assertStoreName);
  if (!stores.length) {return [];}
  await _waitForDB();
  const preparedEntries = await Promise.all(entries.map(async write => {
    if (write?.operation === 'delete') { return write; }
    return {
      ...write,
      obj: window.DataEncryption?.manager?.prepareForStorage
        ? await window.DataEncryption.manager.prepareForStorage(write.store, write.obj)
        : write.obj
    };
  }));
  return new Promise((resolve, reject) => {
    const tx = db.transaction(stores, 'readwrite');
    const results = [];
    try {
      preparedEntries.forEach(write => {
        if (write.operation === 'delete') {
          tx.objectStore(write.store).delete(write.key);
          return;
        }
        const request = tx.objectStore(write.store).put(write.obj);
        request.onsuccess = () => results.push(request.result);
      });
    } catch (error) {
      try { tx.abort(); } catch (_) { /* transaction already closed */ }
      reject(error);
      return;
    }
    tx.oncomplete = () => {
      invalidateStockForecastCache(stores);
      localSaveEnd(saveStartedAt);
      resolve(results);
    };
    tx.onerror = () => { localSaveEnd(saveStartedAt); reject(tx.error || new Error('Atomic IndexedDB write failed')); };
    tx.onabort = () => { localSaveEnd(saveStartedAt); reject(tx.error || new Error('Atomic IndexedDB write aborted')); };
  });
}

/** Read, derive and persist records with encryption-aware optimistic CAS.
 * derive(current, guards) is synchronous and returns {record, writes:[{store,obj}]}.
 * Reads/decryption and encryption happen before the write transaction; every raw
 * snapshot is rechecked inside that transaction before any write is queued.
 */
async function atomicReadModifyWrite(storeName, key, derive, options = {}) {
  const saveStartedAt = localSaveStart();
  assertStoreName(storeName);
  if (typeof derive !== 'function') throw new TypeError('derive must be a function');
  await _waitForDB();
  const guards = Array.isArray(options.guards) ? options.guards : [];
  guards.forEach(guard => assertStoreName(guard.store));
  const reads = [{ store: storeName, key, name: '$record' }, ...guards.map((guard, index) => ({
    store: guard.store, key: guard.key, name: guard.name || `${guard.store}:${String(guard.key)}:${index}`
  }))];
  const readStores = [...new Set(reads.map(read => read.store))];
  const encryption = typeof window !== 'undefined' ? window.DataEncryption?.manager : null;
  const stable = value => {
    try { return JSON.stringify(value === undefined ? null : value); }
    catch (_) { return null; }
  };

  for (let attempt = 0; attempt < 5; attempt++) {
    const rawSnapshot = await new Promise((resolve, reject) => {
      const tx = db.transaction(readStores, 'readonly');
      const values = new Array(reads.length);
      reads.forEach((read, index) => {
        const request = tx.objectStore(read.store).get(read.key);
        request.onsuccess = () => { values[index] = request.result || null; };
        request.onerror = () => { try { tx.abort(); } catch (_) {} };
      });
      tx.oncomplete = () => resolve(values);
      tx.onerror = () => reject(tx.error || new Error('Atomic IndexedDB read failed'));
      tx.onabort = () => reject(tx.error || new Error('Atomic IndexedDB read aborted'));
    });
    const plainSnapshot = await Promise.all(rawSnapshot.map((record, index) =>
      record && encryption?.restoreFromStorage
        ? encryption.restoreFromStorage(reads[index].store, record)
        : record
    ));
    const guardRecords = {};
    guards.forEach((guard, index) => { guardRecords[reads[index + 1].name] = plainSnapshot[index + 1]; });
    const outcome = derive(plainSnapshot[0], guardRecords);
    if (!outcome || !outcome.record) throw new Error('Atomic mutation returned no record');
    guards.forEach((guard, index) => {
      if (typeof guard.validate === 'function' && !guard.validate(plainSnapshot[index + 1])) {
        throw new Error(guard.errorMessage || 'Atomic mutation precondition failed');
      }
    });

    const writes = [{ store: storeName, obj: outcome.record }, ...(outcome.writes || [])];
    writes.forEach(write => assertStoreName(write.store));
    const prepared = await Promise.all(writes.map(async write => ({
      store: write.store,
      obj: encryption?.prepareForStorage
        ? await encryption.prepareForStorage(write.store, write.obj)
        : write.obj
    })));
    const writeStores = [...new Set([...readStores, ...prepared.map(write => write.store)])];
    const commit = await new Promise((resolve, reject) => {
      const tx = db.transaction(writeStores, 'readwrite');
      let pendingChecks = reads.length;
      let conflict = false;
      let writeError = null;
      const queueWrites = () => {
        if (conflict || writeError || pendingChecks !== 0) return;
        try { prepared.forEach(write => tx.objectStore(write.store).put(write.obj)); }
        catch (error) { writeError = error; try { tx.abort(); } catch (_) {} }
      };
      reads.forEach((read, index) => {
        const request = tx.objectStore(read.store).get(read.key);
        request.onsuccess = () => {
          if (stable(request.result || null) !== stable(rawSnapshot[index])) {
            conflict = true;
            try { tx.abort(); } catch (_) {}
            return;
          }
          pendingChecks--;
          queueWrites();
        };
        request.onerror = () => { writeError = request.error || new Error('Atomic compare read failed'); try { tx.abort(); } catch (_) {} };
      });
      tx.oncomplete = () => resolve({ conflict: false });
      tx.onerror = () => reject(writeError || tx.error || new Error('Atomic IndexedDB mutation failed'));
      tx.onabort = () => conflict ? resolve({ conflict: true }) : reject(writeError || tx.error || new Error('Atomic IndexedDB mutation aborted'));
    });
    if (commit.conflict) continue;
    invalidateStockForecastCache(writeStores);
    localSaveEnd(saveStartedAt);
    return outcome.result === undefined ? outcome.record : outcome.result;
  }
  localSaveEnd(saveStartedAt);
  const conflictError = new Error('Atomic stock update conflicted repeatedly; reload and retry');
  conflictError.code = 'ATOMIC_MUTATION_CONFLICT';
  throw conflictError;
}

async function dDel(storeName, id) {
  assertStoreName(storeName);
  await _waitForDB();
  return new Promise((res, rej) => {
    const r = db.transaction(storeName, 'readwrite').objectStore(storeName).delete(id);
    r.onsuccess = () => {
      invalidateStockForecastCache(storeName);
      res();
    };
    r.onerror = rej;
  });
}

/**
 * Clear all records from a store
 * @param {string} storeName - Name of the object store
 * @returns {Promise<void>}
 */
async function dClr(storeName) {
  await _waitForDB();
  return new Promise((res, rej) => {
    const request = db.transaction(storeName, 'readwrite').objectStore(storeName).clear();
    request.onsuccess = () => {
      invalidateStockForecastCache(storeName);
      res();
    };
    request.onerror = rej;
  });
}

/**
 * Get a single record by key
 * @param {string} storeName - Name of the object store
 * @param {number} id - Key of the record
 * @returns {Promise<Object|null>}
 */
async function gOne(storeName, id) {
  await _waitForDB();
  return new Promise((res, rej) => {
    const r = db.transaction(storeName, 'readonly').objectStore(storeName).get(id);
    r.onsuccess = async () => {
      try {
        const row = r.result || null;
        res(window.DataEncryption?.manager?.restoreFromStorage
          ? await window.DataEncryption.manager.restoreFromStorage(storeName, row)
          : row);
      } catch (error) { rej(error); }
    };
    r.onerror = rej;
  });
}

/**
 * Get database instance
 * @returns {IDBDatabase}
 */
function getDB() {
  return db;
}

/**
 * Get store names
 * @returns {Array<string>}
 */
function getStoreNames() {
  return [...STORES];
}

/**
 * Report the local IndexedDB schema that actually opened. This is diagnostic
 * only: it does not run or repair migrations and does not certify central DB.
 */
function getDatabaseStatus(database = db) {
  if (!database) {
    return { ready: false, databaseName: DB, expectedVersion: VER, actualVersion: null, missingStores: [...STORES], migrationPending: true };
  }
  const actualStores = Array.from(database.objectStoreNames || []);
  const missingStores = STORES.filter(name => !actualStores.includes(name));
  const actualVersion = Number(database.version) || null;
  return {
    ready: true,
    databaseName: database.name || DB,
    expectedVersion: VER,
    actualVersion,
    storeCount: actualStores.length,
    missingStores,
    migrationPending: missingStores.length > 0 || actualVersion !== VER,
  };
}

// Export for ES6 modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    initDB,
    gAll,
    dPut,
    batchPut,
    dPutMany,
    atomicReadModifyWrite,
    dDel,
    dClr,
    gOne,
    getDB,
    getStoreNames,
    getDatabaseStatus,
    STORES
  };
}

// Also expose to window for browser usage
window.initDB = initDB;
window.gAll = gAll;
window.dPut = dPut;
window.batchPut = batchPut;
window.dPutMany = dPutMany;
window.atomicReadModifyWrite = atomicReadModifyWrite;
window.dDel = dDel;
window.dClr = dClr;
window.gOne = gOne;
window.getDB = getDB;
window.getStoreNames = getStoreNames;
window.getDatabaseStatus = getDatabaseStatus;
window.STORES = STORES;
