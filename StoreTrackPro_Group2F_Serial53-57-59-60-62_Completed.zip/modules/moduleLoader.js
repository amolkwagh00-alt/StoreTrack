// Dynamic Module Loader - Code splitting for on-demand loading

class ModuleLoader {
  constructor() {
    this.loadedModules = new Map();
    this.loadingModules = new Map();
  }
  
  /**
   * Load a module dynamically
   * @param {string} moduleName - Name of the module to load
   * @returns {Promise<Object>} - Module exports
   */
  async load(moduleName) {
    // Return cached module if already loaded
    if (this.loadedModules.has(moduleName)) {
      return this.loadedModules.get(moduleName);
    }
    
    // Return existing promise if module is currently loading
    if (this.loadingModules.has(moduleName)) {
      return this.loadingModules.get(moduleName);
    }
    
    // Create loading promise
    const loadingPromise = this._loadModule(moduleName);
    this.loadingModules.set(moduleName, loadingPromise);
    
    try {
      const module = await loadingPromise;
      this.loadedModules.set(moduleName, module);
      this.loadingModules.delete(moduleName);
      return module;
    } catch (error) {
      this.loadingModules.delete(moduleName);
      throw error;
    }
  }
  
  /**
   * Internal method to load module script
   * @param {string} moduleName - Name of the module
   * @returns {Promise<Object>}
   */
  async _loadModule(moduleName) {
    const scriptPath = `modules/${moduleName}.js`;
    
    return new Promise((resolve, reject) => {
      // Check if script is already in DOM
      const existingScript = document.querySelector(`script[src="${scriptPath}"]`);
      if (existingScript) {
        // Module already loaded via script tag
        this._resolveModuleFromGlobal(moduleName, resolve, reject);
        return;
      }
      
      // Create and append script element
      const script = document.createElement('script');
      script.src = scriptPath;
      script.async = true;
      
      script.onload = () => {
        this._resolveModuleFromGlobal(moduleName, resolve, reject);
      };
      
      script.onerror = () => {
        reject(new Error(`Failed to load module: ${moduleName}`));
      };
      
      document.head.appendChild(script);
    });
  }
  
  /**
   * Resolve module from global scope
   * @param {string} moduleName - Name of the module
   * @param {Function} resolve - Promise resolve
   * @param {Function} reject - Promise reject
   */
  _resolveModuleFromGlobal(moduleName, resolve, reject) {
    // Modules in this application are classic scripts that expose a global.
    // Resolve the real export instead of returning a fake {loaded:true} object.
    const pascalName = String(moduleName)
      .split(/[-_]/)
      .filter(Boolean)
      .map(part => part.charAt(0).toUpperCase() + part.slice(1))
      .join('');
    const aliases = {
      authHelpers: ['authBridge'],
      automatedAlerts: ['AutomatedAlerts'],
      businessIntelligence: ['BusinessIntelligence', 'businessIntelligence'],
      cacheManager: ['CacheManager', 'cacheManager'],
      centralSync: ['centralSync'],
      dataEncryption: ['DataEncryption'],
      database: ['database'],
      notificationService: ['NotificationService', 'notificationService'],
      passwordPolicy: ['PasswordPolicy', 'passwordPolicy'],
      performanceMonitor: ['PerformanceMonitor', 'performanceMonitor'],
      pushNotifications: ['PushNotifications'],
      moduleLoader: ['moduleLoader'],
      lazyLoader: ['LazyModuleLoader', 'lazyModuleLoader']
    };
    const candidates = [...(aliases[moduleName] || []), pascalName, moduleName];
    const found = candidates.map(name => window[name]).find(value => value !== undefined);
    if (found === undefined) {
      reject(new Error(`Module loaded but no global export was found: ${moduleName}`));
      return;
    }
    resolve(found);
  }
  
  /**
   * Preload multiple modules
   * @param {Array<string>} moduleNames - Array of module names to preload
   * @returns {Promise<Array>}
   */
  async preload(moduleNames) {
    const promises = moduleNames.map(name => this.load(name));
    return Promise.all(promises);
  }
  
  /**
   * Unload a module from cache
   * @param {string} moduleName - Name of the module to unload
   */
  unload(moduleName) {
    this.loadedModules.delete(moduleName);
    this.loadingModules.delete(moduleName);
  }
  
  /**
   * Clear all cached modules
   */
  clearCache() {
    this.loadedModules.clear();
    this.loadingModules.clear();
  }
}

// Create singleton instance
const moduleLoader = new ModuleLoader();

// Export for use in app
if (typeof window !== 'undefined') {
  window.ModuleLoader = ModuleLoader;
  window.moduleLoader = moduleLoader;
}
