/* global audit */
/* Consumption Analytics UI */
(function () {
  'use strict';
  const esc = value => String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const btn = (label, action, primary) => `<button class="btn ${primary ? 'btn-p' : ''}" type="button" data-onclick="${action}">${esc(label)}</button>`;
  const table = (headers, rows, empty) => `<div class="tw"><table><thead><tr>${headers.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows || `<tr><td colspan="${headers.length}">${esc(empty || 'No records found.')}</td></tr>`}</tbody></table></div>`;
  const cardMetric = (value, label) => `<div class="met"><div class="met-v">${esc(value)}</div><div class="met-l">${esc(label)}</div></div>`;
  const val = id => document.getElementById(id)?.value ?? '';
  const download = (filename, content, mime = 'text/plain') => { const blob = new Blob([content], {type: `${mime};charset=utf-8`}); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 0); };
  const csv = rows => rows.map(row => row.map(value => `"${String(value ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
  const shell = (title, body) => {
    document.querySelectorAll('.sec').forEach(section => section.classList.remove('active'));
    document.querySelectorAll('.ni').forEach(item => item.classList.remove('active'));
    document.getElementById('s-component')?.classList.add('active');
    document.getElementById('n-component')?.classList.add('active');
    const analyticsMenuItem = [...document.querySelectorAll('.ng[aria-label=\"Shank Mapping\"] .ni')].find(item => (item.getAttribute('data-onclick') || '').includes('componentConsumptionAnalyticsOpen'));
    if (analyticsMenuItem) { document.getElementById('n-component')?.classList.remove('active'); document.querySelectorAll('.ng[aria-label=\"Shank Mapping\"] .ni').forEach(item => item.classList.remove('active')); analyticsMenuItem.classList.add('active'); }
    const pageTitle = document.getElementById('pg-title');
    if (pageTitle) { pageTitle.textContent = title; }
    const host = document.getElementById('component-management-content');
    if (!host) { throw new Error('Component Management content container was not found'); }
    host.innerHTML = `<div class="card"><div class="card-hd">${esc(title)}</div>${body}</div>`;
  };
  window.shankConsumptionEsc = esc;
  function todayString() {return new Date().toISOString().slice(0, 10);}
  function n(value) {const result = Number(value); return Number.isFinite(result) ? result : 0;}
  async function load() {
    const [parts, stock, replacements, historical, mappings, config] = await Promise.all([window.gAll('component_parts'), window.gAll('component_stock'), window.gAll('component_replacements'), window.gAll('component_historical_consumption'), window.gAll('component_mappings'), window.ShankConsumptionAnalytics.loadConfig()]);
    const allConsumption = [...replacements, ...historical].map(row => ({ ...row, partNo: row.partNo || row.newPartNo, type: 'Replacement / Issue', date: row.date || row.replacementDate || row.replacementDateTime }));
    const occurrenceByPart = {}; mappings.forEach(row => { const key = String(row.partNo || '').trim(); if (key) {occurrenceByPart[key] = (occurrenceByPart[key] || 0) + 1;} });
    return { parts, stock, replacements: allConsumption, occurrenceByPart, config };
  }
  async function open() {
    if (typeof window.canShankComponent === 'function' && !window.canShankComponent('reports')) {return;}
    const api = window.ShankConsumptionAnalytics;
    if (!api) {return window.toastMsg?.('Consumption Analytics is unavailable', 'er');}
    const data = await load();
    const end = window.componentConsumptionAnalyticsState?.end || todayString();
    const periodDays = Math.max(1, Number(window.componentConsumptionAnalyticsState?.periodDays || data.config?.usagePeriodDays || 90));
    const forecasts = api.calculateForecast({ today: end, parts: data.parts, stock: data.stock, replacements: data.replacements, occurrenceByPart: data.occurrenceByPart, periodDays, config: data.config });
    window.componentConsumptionAnalyticsState = { ...(window.componentConsumptionAnalyticsState || {}), end, periodDays, forecasts };
    const orderRows = forecasts.filter(row => row.status !== 'NORMAL');
    const counts = forecasts.reduce((out, row) => {out[row.status] = (out[row.status] || 0) + 1; return out;}, {});
    const detailRows = forecasts.map(row => `<tr><td><button class="btn btn-link" type="button" data-onclick="componentConsumptionAnalyticsDetail('${esc(row.partNo)}')">${esc(row.partNo)}</button></td><td>${esc(row.componentType || '')}</td><td>${row.currentStock}</td><td>${n(row.averageDailyUsage).toFixed(2)}</td><td>${row.last7Days || 0}</td><td>${row.last30Days || 0}</td><td>${row.last60Days || 0}</td><td>${row.last90Days || 0}</td><td>${row.leadTimeDays}</td><td>${n(row.safetyStockQty).toFixed(2)}</td><td>${n(row.reorderPoint).toFixed(2)}</td><td>${esc(row.expectedZeroDate || 'NO PROJECTED STOCK-OUT')}</td><td>${esc(row.status)}</td><td>${esc(row.usageConfidence || 'LOW')}</td><td>${row.abnormalConsumption ? 'ABNORMAL USAGE' : ''}</td></tr>`).join('');
    const orderBody = orderRows.map(row => `<tr><td>${esc(row.partNo)}</td><td>${esc(row.componentType || '')}</td><td>${row.currentStock}</td><td>${n(row.averageDailyUsage).toFixed(2)}</td><td>${row.leadTimeDays}</td><td>${n(row.safetyStockQty).toFixed(2)}</td><td>${n(row.reorderPoint).toFixed(2)}</td><td>${esc(row.expectedZeroDate || 'NO PROJECTED STOCK-OUT')}</td><td>${esc(row.status)}</td><td>${esc(row.usageConfidence || 'LOW')}</td><td>${row.abnormalConsumption ? 'ABNORMAL USAGE' : ''}</td></tr>`).join('');
    const replacementRows = api.calculateConsumption(data.replacements, {end, periodDays});
    const shiftTotals = {'1st Shift': 0, '2nd Shift': 0, '3rd Shift': 0};
    const stationTotals = {};
    replacementRows.forEach(row => {Object.entries(row.shifts || {}).forEach(([shift, qty]) => {shiftTotals[shift] = (shiftTotals[shift] || 0) + n(qty);}); Object.entries(row.stations || {}).forEach(([station, qty]) => {stationTotals[station] = (stationTotals[station] || 0) + n(qty);});});
    const totalConsumption = Object.values(shiftTotals).reduce((sum, value) => sum + value, 0);
    const shiftBody = Object.entries(shiftTotals).map(([shift, qty]) => `<tr><td>${esc(shift)}</td><td>${qty}</td><td>${totalConsumption ? ((qty / totalConsumption) * 100).toFixed(1) : '0.0'}%</td></tr>`).join('');
    const stationBody = Object.entries(stationTotals).sort((a, b) => b[1] - a[1]).map(([station, qty]) => `<tr><td>${esc(station)}</td><td>${qty}</td><td>${totalConsumption ? ((qty / totalConsumption) * 100).toFixed(1) : '0.0'}%</td></tr>`).join('');
    const settings = data.config || {};
    const partConfigRows = data.parts.map(part => { const cfg = part.analytics || part.consumptionConfig || {}; return `<tr><td>${esc(part.partNo || '')}</td><td>${esc(part.componentType || '')}</td><td><input class="fi cm-part-analytics" data-part="${esc(part.partNo || '')}" data-setting="leadTimeDays" type="number" min="0" value="${n(cfg.leadTimeDays)}"></td><td><label><input class="cm-part-analytics-flag" data-part="${esc(part.partNo || '')}" type="checkbox" ${cfg.criticalFlag ? 'checked' : ''}> Critical</label></td></tr>`; }).join('');
    const settingsHtml = `<div class="card"><div class="card-hd">Forecast Configuration</div><div class="g5 cm-mobile-stack"><div class="fr"><label class="fl">Supplier Lead Time (days)</label><input class="fi" id="cm-analytics-lead-time" type="number" min="0" value="${n(settings.leadTimeDays)}"></div><div class="fr"><label class="fl">Internal PR/PO Days</label><input class="fi" id="cm-analytics-internal-days" type="number" min="0" value="${n(settings.internalProcurementDays ?? 30)}"></div><div class="fr"><label class="fl">Usage Period (days)</label><input class="fi" id="cm-analytics-usage-period" type="number" min="1" value="${n(settings.usagePeriodDays || 90)}"></div>${btn('Save Forecast Settings', 'componentSaveConsumptionSettings()', true)}</div><h4>Per-Part Overrides</h4>${table(['Part No.', 'Component Type', 'Lead Time Days', 'Critical Flag'], partConfigRows, 'No Part Master records available.')}</div>`;
    const productionHtml = window.ShankMappingBIProduction ? await window.ShankMappingBIProduction.render(forecasts, data) : '';
    shell('Shank Consumption Analytics', `<div class="cm-bi-page"><div class="cm-bi-hero"><div><div class="cm-bi-eyebrow">SHANK MAPPING · DECISION CENTER</div><h2>Consumption Analytics &amp; BI</h2><p>Monitor stock risk, usage patterns, maintenance signals, and approval actions from one source-based view.</p></div><div class="cm-bi-hero-status">${esc(end)}<span>Analysis date</span></div></div><div class="alrt alrt-b">Consumption is calculated only from saved Replacement / Issue transactions. Receive, Repair Return, Scrap, and Adjustment transactions remain separate lifecycle events.</div><div class="g4 cm-mobile-stack"><div class="fr"><label class="fl">As of Date</label><input class="fi" id="cm-consumption-end" type="date" value="${esc(end)}"></div><div class="fr"><label class="fl">Usage Period (days)</label><input class="fi" id="cm-consumption-period" type="number" min="1" value="${periodDays}"></div>${btn('Refresh Analytics', 'componentRefreshConsumptionAnalytics()', true)}${btn('Export ORDER NOW', 'componentExportConsumptionOrderNow()')}</div><div class="g5 cm-mobile-stack">${cardMetric(counts['ZERO STOCK'] || 0, 'Zero Stock')}${cardMetric(counts['STOCK-OUT RISK'] || 0, 'Stock-Out Risk')}${cardMetric(counts.REORDER || 0, 'Reorder Required')}${cardMetric(counts['LOW STOCK'] || 0, 'Low Stock')}${cardMetric(counts.NORMAL || 0, 'Normal')}</div>${productionHtml}<div class="card"><div class="card-hd">ORDER NOW</div>${table(['Part No.', 'Component Type', 'Current Stock', 'Avg Daily Usage', 'Lead Time', 'Safety Stock', 'Reorder Point', 'Expected Zero Date', 'Status', 'Confidence', 'Alert'], orderBody, 'No parts currently require procurement action.')}</div><div class="card"><div class="card-hd">Consumption and Forecast Detail</div>${table(['Part No.', 'Component Type', 'Current Stock', 'Avg Daily Usage', '7 Day', '30 Day', '60 Day', '90 Day', 'Lead Time', 'Safety Stock', 'Reorder Point', 'Expected Zero Date', 'Status', 'Confidence', 'Alert'], detailRows, 'No Shank Part Master records available.')}</div>${settingsHtml}<div class="g2 cm-mobile-stack"><div class="card"><div class="card-hd">Consumption by Shift</div>${table(['Shift', 'Quantity', 'Percentage'], shiftBody, 'No shift data.')}</div><div class="card"><div class="card-hd">Consumption by Station</div>${table(['Station', 'Quantity', 'Percentage'], stationBody, 'No station data.')}</div></div></div>`);
  }
  async function saveSettings() {
    if (typeof window.canShankComponent === 'function' && !window.canShankComponent('reports')) {return;}
    const settings = {leadTimeDays: Math.max(0, n(val('cm-analytics-lead-time'))), internalProcurementDays: Math.max(0, n(val('cm-analytics-internal-days'))), usagePeriodDays: Math.max(1, n(val('cm-analytics-usage-period')))};
    await window.ShankConsumptionAnalytics.saveConfig(settings);
    const byPart = {};
    document.querySelectorAll('.cm-part-analytics').forEach(input => { const partNo = input.dataset.part || ''; byPart[partNo] = byPart[partNo] || {}; byPart[partNo][input.dataset.setting] = Math.max(0, n(input.value)); });
    document.querySelectorAll('.cm-part-analytics-flag').forEach(input => { const partNo = input.dataset.part || ''; byPart[partNo] = byPart[partNo] || {}; byPart[partNo].criticalFlag = Boolean(input.checked); });
    for (const part of (await window.gAll('component_parts'))) { if (byPart[part.partNo]) { await window.dPut('component_parts', { ...part, analytics: { ...(part.analytics || {}), ...byPart[part.partNo] } }); } }
    window.componentConsumptionAnalyticsState = { ...(window.componentConsumptionAnalyticsState || {}), periodDays: settings.usagePeriodDays };
    window.toastMsg?.('Forecast settings saved', 'suc');
    return open();
  }
  async function refresh() {window.componentConsumptionAnalyticsState = {end: val('cm-consumption-end') || todayString(), periodDays: Math.max(1, Number(val('cm-consumption-period') || 90))}; return open();}
  async function detail(partNo) {
    const data = await load();
    const api = window.ShankConsumptionAnalytics;
    const context = window.componentConsumptionAnalyticsState || {};
    const end = context.end || todayString();
    const periodDays = Math.max(1, Number(context.periodDays || data.config?.usagePeriodDays || 90));
    const forecast = api.calculateForecast({today: end, parts: data.parts, stock: data.stock, replacements: data.replacements, occurrenceByPart: data.occurrenceByPart, periodDays, config: data.config}).find(row => row.partNo === partNo);
    const startDate = new Date(`${end}T00:00:00`); startDate.setDate(startDate.getDate() - periodDays + 1);
    const start = startDate.toISOString().slice(0, 10);
    const rows = api.transactionDrillDown(data.replacements.filter(row => String(row.date || row.replacementDate || row.replacementDateTime || '').slice(0,10) >= start && String(row.date || row.replacementDate || row.replacementDateTime || '').slice(0,10) <= end), partNo);
    const body = rows.map(row => `<tr><td>${esc(row.replacementDate || row.replacementDateTime || '')}</td><td>${esc(row.componentType || '')}</td><td>${row.quantity || 0}</td><td>${esc(row.stationNo || '')}</td><td>${esc(row.gunReferenceNo || '')}</td><td>${esc(row.shift || '')}</td><td>${esc(row.maintenancePersonName || row.loggedInUser || '')}</td><td>${row.cumulativeUsage || 0}</td></tr>`).join('');
    shell(`Why is ${esc(partNo)} stock low?`, `<div class="g4 cm-mobile-stack">${cardMetric(forecast?.currentStock ?? 0, 'Current Stock')}${cardMetric(n(forecast?.averageDailyUsage).toFixed(2), 'Average Daily Usage')}${cardMetric(forecast?.expectedZeroDate || 'NO PROJECTED STOCK-OUT', 'Expected Zero Date')}${cardMetric(forecast?.status || 'NORMAL', 'Status')}</div><div class="alrt alrt-b">Historical/live usage is shown as cumulative usage. It does not subtract from Current Stock.</div>${table(['Date', 'Component Type', 'Quantity', 'Station', 'Gun Reference', 'Shift', 'Maintenance Person', 'Cumulative Usage'], body, 'No replacement history found.')}`);
  }
  function stationKey(value) {return String(value || '').toUpperCase().replace(/[\s_-]+/g, '');}
  function fingerprint(rows) {return rows.map(row => [row.stationNo, row.gunReferenceNo, row.position, row.partNo, row.sourceSheet, row.sourceRow].map(value => String(value ?? '')).join('¦')).sort().join('¶');}
  async function openQrDetails(stationNo, binId, scannedParts = []) {
    const scannedPayload = arguments[3] || null;
    if (typeof window.addAudit === 'function') { await window.addAudit('COMPONENT_QR_SCAN', 'Station/Bin QR', `${stationNo || ''}:${binId || ''}`, { stationNo: stationNo || '', binId: binId || '', scannedAt: new Date().toISOString(), userId: window.currentUser?.id || window.user?.()?.id || null }); }
    const [mappings, bins, stock, parts, replacements, historical, transactions] = await Promise.all([window.gAll('component_mappings'), window.gAll('component_bins'), window.gAll('component_stock'), window.gAll('component_parts'), window.gAll('component_replacements'), window.gAll('component_historical_consumption'), window.gAll('component_stock_transactions')]);
    replacements.push(...historical.map(row => ({ ...row, type: 'Replacement / Issue', date: row.date || row.replacementDate || row.replacementDateTime })));
    const mappingRows = mappings.filter(row => stationKey(row.stationNo) === stationKey(stationNo));
    const selectedBin = bins.find(row => row.binId === binId) || bins.find(row => stationKey(row.stationNo) === stationKey(stationNo));
    const partNos = new Set(mappingRows.map(row => String(row.partNo || '')).filter(Boolean));
    const stockRows = stock.filter(row => (selectedBin && row.binId === selectedBin.binId) || partNos.has(String(row.partNo || '')));
    const history = replacements.filter(row => stationKey(row.stationNo) === stationKey(stationNo));
    const txRows = transactions.filter(row => (selectedBin && row.binId === selectedBin.binId) || partNos.has(String(row.partNo || '')));
    const mappingBody = mappingRows.map(row => `<tr><td>${esc(row.gunReferenceNo || '')}</td><td>${esc(row.position || '')}</td><td>${esc(row.partNo || '')}</td><td>${esc(row.sourceSheet || '')}</td><td>${esc(row.sourceRow || '')}</td></tr>`).join('');
    const stockBody = stockRows.map(row => {const part = parts.find(item => item.partNo === row.partNo); return `<tr><td>${esc(row.partNo || '')}</td><td>${esc(part?.componentType || '')}</td><td>${esc(row.binId || '')}</td><td>${row.quantity || 0}</td><td>${esc(row.status || '')}</td></tr>`;}).join('');
    const historyBody = [...history, ...txRows].sort((a, b) => String(a.date || a.replacementDate || a.replacementDateTime || '').localeCompare(String(b.date || b.replacementDate || b.replacementDateTime || ''))).map(row => `<tr><td>${esc(row.date || row.replacementDate || row.replacementDateTime || '')}</td><td>${esc(row.type || row.transactionType || 'Replacement')}</td><td>${esc(row.partNo || '')}</td><td>${row.quantity || 0}</td><td>${esc(row.gunReferenceNo || '')}</td><td>${esc(row.maintenancePersonName || row.loggedInUser || row.userId || '')}</td></tr>`).join('');
    const scannedItems = [...(scannedPayload?.fixShank || []), ...(scannedPayload?.movingShank || [])].map(item => ({ partNo: String(item.partNo || '').trim(), qty: Number(item.qty || 0) })).filter(item => item.partNo);
    const currentItems = new Map();
    mappingRows.filter(row => row.partNo).forEach(row => { const key = String(row.partNo).trim().toLowerCase(); const item = currentItems.get(key) || { partNo: String(row.partNo).trim(), occurrences: 0 }; item.occurrences += 1; currentItems.set(key, item); });
    const currentPayloadItems = [...currentItems.values()].map(item => ({ partNo: item.partNo, qty: item.occurrences * 2 }));
    const currentSourceGuns = new Set(mappingRows.map(row => String(row.gunReferenceNo || '').trim()).filter(Boolean)).size;
    const normalized = items => JSON.stringify(items.map(item => ({ partNo: item.partNo.toLowerCase(), qty: Number(item.qty) })).sort((a, b) => a.partNo.localeCompare(b.partNo)));
    const currentSnapshot = JSON.stringify({ station: String(stationNo || '').trim(), bin: String(binId || selectedBin?.binId || '').trim(), items: currentPayloadItems.map(item => ({ partNo: item.partNo, qty: item.qty })).sort((a, b) => a.partNo.localeCompare(b.partNo)), sourceGuns: currentSourceGuns });
    const shortMappingHash = value => { let hash = 2166136261; for (const character of String(value)) { hash ^= character.charCodeAt(0); hash = Math.imul(hash, 16777619); } return (hash >>> 0).toString(16).padStart(8, '0'); };
    const currentHash = shortMappingHash(currentSnapshot);
    const differences = [];
    let versionOutdated = false;
    if (scannedPayload) {
      if (String(scannedPayload.station || '').trim().toLowerCase() !== String(stationNo || '').trim().toLowerCase()) { differences.push(`Station: QR ${scannedPayload.station || '—'} / Current ${stationNo || '—'}`); }
      if (String(scannedPayload.bin || '').trim().toLowerCase() !== String(binId || selectedBin?.binId || '').trim().toLowerCase()) { differences.push(`Bin: QR ${scannedPayload.bin || '—'} / Current ${binId || selectedBin?.binId || '—'}`); }
      if (normalized(scannedItems) !== normalized(currentPayloadItems)) { differences.push('Part No. / QTY grouped mapping is different'); }
      versionOutdated = !differences.length && (String(scannedPayload.mappingHash || '') !== currentHash || Number(scannedPayload.sourceGuns || 0) !== currentSourceGuns);
    }
    // Mobile-only mode: QR scan opens readable Station/Bin/Part details; no label validation is shown.
    const scanCard = '';
    const scannedPartBody = (scannedItems.length ? scannedItems : (scannedParts || []).map(part => ({ partNo: part, qty: '' }))).map(item => `<tr><td>${esc(item.partNo)}</td><td>${esc(item.qty)}</td></tr>`).join('');
    const scannedPartCard = scannedPartBody ? `<div class="card"><div class="card-hd">Part Details from Scanned Label</div>${table(['Part No.', 'QTY'], scannedPartBody, 'No part details encoded in this label.')}</div>` : '';
    shell(`Station ${esc(stationNo || '')} / Bin ${esc(binId || selectedBin?.binId || '')}`, `${scanCard}<div class="alrt alrt-b">QR Station/Bin lookup: complete mapping, current stock, replacement history, and stock transactions.</div>${scannedPartCard}<div class="card"><div class="card-hd">Station / Gun Mapping</div>${table(['Gun Reference', 'Position', 'Part No.', 'Source Sheet', 'Source Row'], mappingBody, 'No mappings found.')}</div><div class="card"><div class="card-hd">Current Stock</div>${table(['Part No.', 'Component Type', 'Bin', 'Available Qty', 'Status'], stockBody, 'No stock records found.')}</div><div class="card"><div class="card-hd">History and Transactions</div>${table(['Date', 'Transaction', 'Part No.', 'Quantity', 'Gun Reference', 'User'], historyBody, 'No history found.')}</div>`);
    return { stationNo, binId: selectedBin?.binId || binId, mappingRows, stockRows, history, txRows };
  }
  async function labelVersionStatus(stationNo, binId, mappings) {
    const versions = await window.gAll('component_label_versions');
    const current = fingerprint((mappings || []).filter(row => stationKey(row.stationNo) === stationKey(stationNo)));
    const saved = versions.find(row => row.stationNo === stationNo && row.binId === binId);
    return {stationNo, binId, currentVersion: current, lastPrintedVersion: saved?.mappingVersion || '', outdated: !saved || saved.mappingVersion !== current};
  }
  async function recordLabelPrint(rows) {
    const mappings = await window.gAll('component_mappings');
    for (const row of rows || []) {
      const stationMappings = mappings.filter(mapping => stationKey(mapping.stationNo) === stationKey(row.stationNo));
      await window.dPut('component_label_versions', {id: `label:${row.stationNo}:${row.binId}`, stationNo: row.stationNo, binId: row.binId, mappingVersion: fingerprint(stationMappings), printedAt: new Date().toISOString(), outdated: false});
    }
  }
  async function refreshLabelStatuses(rows) {
    const panel = document.getElementById('cm-label-status-panel');
    if (!panel) {return;}
    const mappings = await window.gAll('component_mappings');
    const statuses = await Promise.all((rows || []).map(row => labelVersionStatus(row.stationNo, row.binId, mappings)));
    const outdated = statuses.filter(status => status.outdated).length;
    const current = statuses.length - outdated;
    panel.className = outdated ? 'alrt alrt-y' : 'alrt alrt-s';
    panel.innerHTML = `<strong>Label Status:</strong> ${current} Current, ${outdated} Outdated. ${outdated ? 'Reprint Outdated labels after mapping changes.' : 'All printed labels match current mapping data.'}<div>${statuses.map(status => `<span class="pill ${status.outdated ? 'pill-y' : 'pill-s'}">${esc(status.stationNo)} / ${esc(status.binId)}: ${status.outdated ? 'OUTDATED' : 'CURRENT'}</span>`).join(' ')}</div>`;
  }
  async function exportOrderNow() {
    const data = await load();
    const context = window.componentConsumptionAnalyticsState || {};
    const end = context.end || todayString();
    const periodDays = Math.max(1, Number(context.periodDays || data.config?.usagePeriodDays || 90));
    const rows = window.ShankConsumptionAnalytics.orderNowRows({today: end, parts: data.parts, stock: data.stock, replacements: data.replacements, occurrenceByPart: data.occurrenceByPart, periodDays, config: data.config});
    download(`shank-mapping-order-now-${end}.csv`, csv([['Part No.', 'Component Type', 'Current Stock', 'Average Daily Usage', 'Lead Time Days', 'Safety Stock', 'Reorder Point', 'Expected Zero Date', 'Status'], ...rows.map(row => [row.partNo, row.componentType || '', row.currentStock, row.averageDailyUsage, row.leadTimeDays, row.safetyStockQty, row.reorderPoint, row.expectedZeroDate || 'NO PROJECTED STOCK-OUT', row.status])]), 'text/csv');
    if (typeof audit === 'function') {await audit('COMPONENT_ORDER_NOW_EXPORT', 'Shank Analytics', null, {count: rows.length});}
  }
  window.componentConsumptionAnalyticsOpen = open;
  window.componentRefreshConsumptionAnalytics = refresh;
  window.componentSaveConsumptionSettings = saveSettings;
  window.componentConsumptionAnalyticsDetail = detail;
  window.componentExportConsumptionOrderNow = exportOrderNow;
  window.componentOpenStationQrDetails = openQrDetails;
  window.componentGetLabelVersionStatus = labelVersionStatus;
  window.componentRefreshLabelStatuses = refreshLabelStatuses;
  window.componentRecordLabelPrint = recordLabelPrint;
}());
