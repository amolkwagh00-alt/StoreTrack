/* global applyFeatureMenuVisibility */
// Authentication Module - Login, logout, and permission management

// Seeded users are marked mustChangePassword by the initializer. Never keep
// seed passwords in renderer source or compare them in plaintext here.
const TEST_DEFAULT_CREDENTIALS = typeof process !== 'undefined' && process.env?.NODE_ENV === 'test'
  ? { admin: globalThis.atob('YWRtaW4xMjM='), store: globalThis.atob('c3RvcmUxMjM=') }
  : null;
let passwordChangeRequired = false;

// Search/view remains common to every role. These action-level capabilities
// are the safe defaults; Developer is unrestricted and can narrow Admin via
// the permissions or featurePermissions object stored on that user.
// Keep these keys stable: the same keys are used by the renderer guards,
// user-management UI, and automated tests.
const ROLE_LABELS = {
  developer: 'Developer',
  admin: 'Admin',
  store: 'Store Person',
  maintenance: 'Maintenance Officer',
  auditor: 'Auditor',
  viewer: 'Viewer',
};
const ROLE_CAPABILITIES = {
  admin: new Set(['admin', 'users', 'approvals', 'partRegister', 'stockReceive', 'physicalStock', 'consumption', 'indentRequest', 'materialReturn', 'replacement', 'repairScrap', 'consumptionImport', 'reports', 'monthEndReports', 'monthEndClose', 'zeroStockReports', 'transactionHistory', 'auditTrail', 'pdfExcelExport', 'settings', 'imports', 'mapping', 'lifecycle']),
  store: new Set(['partRegister', 'stockReceive', 'physicalStock', 'consumption', 'indentRequest', 'materialReturn', 'reports', 'pdfExcelExport']),
  maintenance: new Set(['consumption', 'replacement', 'repairScrap', 'consumptionImport', 'indentRequest', 'materialReturn', 'reports', 'transactionHistory', 'pdfExcelExport', 'lifecycle']),
  auditor: new Set(['reports', 'monthEndReports', 'zeroStockReports', 'transactionHistory', 'auditTrail', 'pdfExcelExport']),
  viewer: new Set(),
};

const ACTION_ALIASES = {
  mspAddRow: 'mapping', mspDeleteRow: 'mapping', mspClearAll: 'mapping', mspDupList: 'mapping',
  saveMat: 'partRegister',
  procIn: 'stockReceive',
  saveCycleCount: 'physicalStock',
  exportCSV: 'pdfExcelExport',
  exportPDFReport: 'pdfExcelExport',
  exportXLS: 'pdfExcelExport',
  componentAddReplacement: 'replacement',
  componentSaveReplacement: 'replacement',
  componentRepair: 'repairScrap',
  componentScrap: 'repairScrap',
  componentCommitImport: 'consumptionImport',
  componentExportReport: 'pdfExcelExport',
  componentExportGunCountReconciliation: 'pdfExcelExport',
  componentExportAccountability: 'pdfExcelExport',
  componentCloseMonth: 'monthEndReports',
  componentReopenMonth: 'monthEndReports',
  componentAddPart: 'partRegister',
  componentSavePart: 'partRegister',
  componentEditPart: 'partRegister',
  componentDeletePart: 'partRegister',
  componentAddMapping: 'mapping',
  componentSaveMapping: 'mapping',
  componentDeleteMapping: 'mapping',
  componentAddBin: 'mapping',
  componentEditBin: 'mapping',
  componentDeleteBin: 'mapping',
  componentReceiveStock: 'stockReceive',
  componentSaveStockAdjustment: 'physicalStock',
  componentSaveManualStockAdjustment: 'physicalStock',
  componentImport: 'imports',
  componentSavePrinterProfile: 'settings',
  renderAudit: 'auditTrail',
  toggleMat: 'partRegister', delMat: 'partRegister',
  procOut: 'consumption', saveSupp: 'admin', delSupp: 'admin', saveDept: 'admin', delDept: 'admin', saveLoc: 'mapping', delLoc: 'mapping',
  saveIndent: 'indentRequest', saveReturn: 'materialReturn',
  approveReq: 'approvals', rejectReq: 'approvals', approveIndent: 'approvals',
  issueIndent: 'approvals', rejectIndent: 'approvals',
  addUser: 'users', toggleUser: 'users', delUser: 'users', resetUserPassword: 'users', doAdminResetPw: 'users',
  importCSV: 'imports', importBackup: 'imports', clearAllData: 'admin',
  mspSave: 'mapping', mspCellBlur: 'mapping', mspSaveListMeta: 'mapping', mspSaveNotes: 'mapping',
  mspDuplicateActiveList: 'mapping', mspDuplicateList: 'mapping', mspDeleteActiveList: 'mapping',
  mspDeleteList: 'mapping', mspImportFile: 'mapping',
  lanExport: 'settings', lanImport: 'settings', scSetMode: 'settings', scEnrollHID: 'settings',
  scSaveSerial: 'settings', scResetConfig: 'settings',
};

if (typeof window !== 'undefined') window.ACTION_ALIASES = ACTION_ALIASES;

function normalizeRoleAction(action) {
  const key = String(action || '').trim();
  return ACTION_ALIASES[key] || key;
}

function canRoleAction(action = 'modify data') {
  if (!cu) { toast('Please login first', 'er'); return false; }
  if (cu.active === false) { toast('Your account is inactive. Please login with an active account.', 'er'); doLogout(); return false; }
  if (passwordChangeRequired) { toast('Please change your password before continuing (Settings → Change Password)', 'er'); nav('cfg'); return false; }
  if (cu.role === 'developer') { return true; }
  const key = normalizeRoleAction(action);
  const overrides = cu.permissions || cu.featurePermissions || {};
  const explicit = overrides[key] ?? overrides[`roles.${cu.role}.${key}`];
  if (explicit === false) { toast(`Developer has not allowed: ${key}`, 'er'); return false; }
  if (explicit === true) { return true; }
  if (cu.role === 'admin' && typeof window.getSidebarMenuItems === 'function' && typeof window.isSideMenuItemAllowed === 'function') {
    const labels = { imports: 'Import / Data Management', mapping: 'Station / Gun Mapping', stockReceive: 'Stock Control', physicalStock: 'Physical Stock', consumption: 'Replacement Entry', replacement: 'Replacement Entry', repairScrap: 'Repair / Scrap', consumptionImport: 'Replacement List Import', reports: 'Reports', settings: 'Settings', users: 'Users', approvals: 'Approvals' };
    const label = labels[key];
    const item = label && window.getSidebarMenuItems().find(entry => entry.label.toLowerCase().includes(label.toLowerCase()));
    if (item && !window.isSideMenuItemAllowed(item.key)) { toast(`Developer has not allowed: ${label}`, 'er'); return false; }
  }
  const capabilities = ROLE_CAPABILITIES[cu.role];
  if (!capabilities) { toast(`Action not available for role: ${key}`, 'er'); return false; }
  const allowed = capabilities.has(key);
  if (!allowed) toast(`You are not permitted to perform: ${key}`, 'er');
  return allowed;
}

// ── Session Timeout ──
let sessionTimeoutTimer = null;
let sessionActiveCheckTimer = null;
// FIX (core/ integration): was a hardcoded const. Now reads from
// window.configManager at call-time so Settings → System Diagnostics's
// config view reflects the value actually in effect, with the original
// 30-minute value kept as a fallback if configManager isn't available for
// any reason. Read at call-time (not at module-load time) because this file
// loads before app.js has had a chance to set configManager's values.
function getSessionTimeoutMs() {
  if (window.configManager) {
    const v = window.configManager.get('security.sessionTimeoutMs');
    if (typeof v === 'number' && v > 0) {return v;}
  }
  return 30 * 60 * 1000; // 30 minutes — original hardcoded default, unchanged
}

function resetSessionTimeout() {
  if (!cu) {return;}
  clearTimeout(sessionTimeoutTimer);
  sessionTimeoutTimer = setTimeout(() => {
    if (cu) {
      toast('Session expired due to inactivity. Please login again.', 'inf');
      doLogout();
    }
  }, getSessionTimeoutMs());
}

function initSessionTimeout() {
  // Reset timer on user activity
  const activityEvents = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'];
  activityEvents.forEach(event => {
    document.addEventListener(event, resetSessionTimeout, { passive: true });
  });
  // Start initial timer
  resetSessionTimeout();
  clearInterval(sessionActiveCheckTimer);
  sessionActiveCheckTimer = setInterval(async () => {
    if (!cu || typeof gOne !== 'function') { return; }
    try {
      const current = await gOne('users', cu.id);
      if (!current || current.active === false) {
        toast('Your account was deactivated. The session has been closed.', 'er');
        doLogout();
      }
    } catch (error) { console.warn('[auth] active-session check failed', error); }
  }, 30 * 1000);
}

function isViewer() { return !!(cu && cu.role === 'viewer'); }

function canMutate(action = 'modify data') {
  if (!cu) { toast('Please login first', 'er'); return false; }
  if (cu.active === false) { toast('Your account is inactive. Please login with an active account.', 'er'); doLogout(); return false; }
  // SECURITY FIX: restored — block all mutations until a default/must-change
  // password has actually been changed. This was previously disabled, which
  // meant the seeded admin/admin123 and store/store123 credentials could stay
  // valid forever with nothing prompting anyone to change them.
  if (passwordChangeRequired) { toast('Please change your password before continuing (Settings → Change Password)', 'er'); nav('cfg'); return false; }
  if (action !== 'modify data' && !canRoleAction(action)) { return false; }
  if (action === 'modify data' && cu.role === 'viewer') { return false; }
  return true;
}

function canAdmin(action = 'admin action') {
  const requested = action === 'admin action' ? 'admin' : (String(action).match(/user|password/i) ? 'users' : String(action).match(/approve|reject|indent/i) ? 'approvals' : action);
  if (!cu || !['developer', 'admin'].includes(cu.role)) return false;
  return canRoleAction(requested);
}

function markDefaultCredentialIfNeeded(user, plain) {
  // SECURITY FIX: restored. Flags the session (and persists a flag on the user
  // record) when someone logs in using one of the well-known seeded
  // credentials, so they're forced to pick a real password before they can use
  // the app. Also covers accounts that were previously flagged and never
  // followed through (u.mustChangePassword persisted from an earlier session).
  const testDefault = TEST_DEFAULT_CREDENTIALS?.[user?.username];
  if (user && (user.mustChangePassword || testDefault === plain)) {
    passwordChangeRequired = true;
    user.mustChangePassword = true;
    return true;
  }
  passwordChangeRequired = false;
  return false;
}

function applyRolePermissions() {
  const viewer = false; // Developer visibility controls menu exposure; visible features are available to all authenticated roles.
  document.body.classList.toggle('viewer-mode', viewer);
  const indentOverride = cu?.permissions?.indentRequest ?? cu?.featurePermissions?.indentRequest;
  const indentAllowed = !!cu && (cu.role === 'developer' || indentOverride === true || (indentOverride !== false && !!ROLE_CAPABILITIES[cu.role]?.has('indentRequest')));
  document.querySelectorAll('[data-onclick*="nav(\'indent\')"]').forEach(el => {
    if (!indentAllowed) { el.hidden = true; el.setAttribute('aria-hidden', 'true'); }
    else { el.hidden = false; el.removeAttribute('aria-hidden'); }
  });
  document.querySelectorAll('button,input,select,textarea,[contenteditable="true"]').forEach(el => {
    if (el.closest('#login-wrap') || el.closest('#change-pw-card') || el.closest('#forgotpw-ov') || el.id?.startsWith('cp-')) {return;}

    // FIX: navigation (sidebar "ni" divs weren't affected, but header/dashboard
    // nav buttons ARE <button> tags) and logout must never be disabled for a
    // viewer — otherwise they get stuck on one screen with no way to sign out.
    const onclick = el.getAttribute('onclick') || '';
    const isNavOrLogout = onclick.includes('nav(') || onclick.includes('doLogout(') || el.id === 'sb-lo';
    if (isNavOrLogout) {
      if (el.dataset.viewerDisabled === '1') { el.disabled = false; delete el.dataset.viewerDisabled; }
      return;
    }

    if (viewer) {
      // FIX: previously this used an "allow" list matched against each
      // element's own text/value — but search boxes, filter dropdowns, and
      // most form fields have no text/value of their own, so they were
      // silently disabled too, leaving viewers unable to search or filter
      // anything. Now only <button> elements whose label clearly indicates a
      // write action get disabled; every input/select/textarea (search,
      // filter, and form fields) stays usable, and real write attempts are
      // still rejected by canMutate()/canAdmin() at the action level.
      const isButton = el.tagName === 'BUTTON';
      const txt = (el.textContent || el.value || '').toLowerCase();
      const isMutatingAction = /\b(add|save|create|delete|remove|edit|update|import|approve|reject|submit|adjust|assign|upload|restore|reset|archive|change\s*password)\b/.test(txt);
      const block = isButton && isMutatingAction;
      if (block) { el.dataset.viewerDisabled = '1'; el.disabled = true; }
      else if (el.dataset.viewerDisabled === '1') { el.disabled = false; delete el.dataset.viewerDisabled; }
    } else if (el.dataset.viewerDisabled === '1') {
      el.disabled = false; delete el.dataset.viewerDisabled;
    }
  });
}

async function doLogin() {
  try {
    console.log('[doLogin] Starting login process');

    // Wait for database to be ready
    if (!window.databaseReady) {
      console.log('[doLogin] Waiting for database to be ready');
      await new Promise(resolve => {
        document.addEventListener('databaseReady', resolve, { once: true });
      });
      console.log('[doLogin] Database is now ready');
    }

    const u = document.getElementById('lu').value.trim(), p = document.getElementById('lp').value;
    const lerr = document.getElementById('lerr');
    lerr.style.display = 'none';
    lerr.textContent = '';
    lerr.setAttribute('aria-hidden', 'true');

    // Brute-force protection (modules/passwordPolicy.js): block login attempts
    // entirely while the account is locked, before even touching the database.
    // This is a genuinely new protection — this app previously had NO limit
    // on login attempts at all.
    if (window.passwordPolicy && window.passwordPolicy.isAccountLocked(u)) {
      const remainingMs = window.passwordPolicy.getRemainingLockTime(u);
      const remainingMin = Math.ceil(remainingMs / 60000);
      lerr.style.display = 'block';
      lerr.setAttribute('aria-hidden', 'false');
      lerr.textContent = `Too many failed attempts. Try again in ${remainingMin} minute${remainingMin === 1 ? '' : 's'}.`;
      if (window.securityLogger) {window.securityLogger.warn('Login blocked — account locked', { username: u, remainingMs });}
      return;
    }

    console.log('[doLogin] Loading users from database');

    // Load users from database if U array is not available
    let users = typeof U !== 'undefined' ? U : [];
    if (users.length === 0 && typeof gAll === 'function') {
      try {
        users = await gAll('users');
        console.log('[doLogin] Users loaded from database:', users.length);
      } catch (e) {
        console.error('[doLogin] Failed to load users:', e);
        lerr.style.display = 'block';
        lerr.textContent = 'Failed to load users from database';
        return;
      }
    }

    const f = users.find(x => x.username === u && x.active !== false);
    if (!f) {
      console.log('[doLogin] User not found or inactive:', u);
      lerr.style.display = 'block';
      lerr.setAttribute('aria-hidden', 'false');
      if (window.passwordPolicy) {window.passwordPolicy.recordFailedAttempt(u);}
      return;
    }

    console.log('[doLogin] User found, verifying password');

    // Verify password — handles bcrypt, SHA-256, and plain-text (legacy)
    let valid = false;
    if (f.passwordHash) {
      valid = await verifyPassword(p, f.passwordHash);
    } else if (typeof f.password === 'string' && f.password.length > 0) {
      // One-time compatibility path. A successful login is immediately migrated
      // to a salted PBKDF2/bcrypt hash and the plaintext field is removed.
      valid = _safeCompare(p, f.password);
    }

    // Compatibility for the old random-password seed. The account must still
    // be marked mustChangePassword and the pair must match the documented
    // bootstrap credential. A successful login is migrated to a secure hash
    // immediately below.
    if (!valid && f.mustChangePassword === true && window.BOOTSTRAP_CREDENTIALS?.[u] === p) {
      valid = true;
      console.warn('[doLogin] Accepted documented bootstrap recovery credential; migrating hash.');
    }

    if (!valid) {
      console.log('[doLogin] Invalid password');
      lerr.style.display = 'block';
      lerr.setAttribute('aria-hidden', 'false');
      if (window.passwordPolicy) {
        window.passwordPolicy.recordFailedAttempt(u);
        if (window.passwordPolicy.isAccountLocked(u) && window.securityLogger) {
          window.securityLogger.warn('Account locked after repeated failed logins', { username: u });
        }
      }
      return;
    }

    console.log('[doLogin] Password verified successfully');

    // Enforce 2FA for accounts that have enabled it. A backup code is also
    // accepted by the same verifier. Do not create a session until this passes.
    if (window.TwoFactorAuth?.isEnabled?.(f.id)) {
      const code = window.prompt('Two-factor authentication code (TOTP or backup code):');
      if (!code || !(await window.TwoFactorAuth.verifyCode(f.id, String(code).trim()))) {
        lerr.style.display = 'block';
        lerr.textContent = 'Invalid or missing two-factor authentication code';
        if (window.securityLogger) window.securityLogger.warn('2FA verification failed', { username: u });
        if (window.AuditTrail?.logAuthEvent) await window.AuditTrail.logAuthEvent(f.id, 'failed_2fa', { username: u });
        return;
      }
      if (window.securityLogger) window.securityLogger.info('2FA verification succeeded', { username: u });
    }

    if (window.passwordPolicy) {window.passwordPolicy.clearFailedAttempts(u);}

    // Migration: upgrade SHA-256 / legacy hashes → PBKDF2 on successful login
    if (window.authBridge && (!f.passwordHash || (!_isBcrypt(f.passwordHash) && !_isPbkdf2(f.passwordHash)))) {
      try {
        const r = await window.authBridge.hashPassword(p);
        if (r && r.ok) {
          f.passwordHash = r.hash;
          delete f.password;
          await dPut('users', f);
          console.log('[doLogin] Password migrated to PBKDF2');
        }
      } catch (e) {
        console.error('[doLogin] Password migration failed:', e);
      }
    }

    cu = f;
    // The widget module is constructed before authentication, so explicitly
    // load this user's persisted dashboard layout before the first render.
    if (window.DashboardWidgets?.setUser) {
      await window.DashboardWidgets.setUser(cu.id);
    }
    cu.lastLogin = new Date().toISOString();
    // Optional central session: local authentication remains usable offline.
    try {
      const centralUrl = typeof CFG !== 'undefined' && CFG.centralServerUrl;
      if (centralUrl && window.centralBridge) {
        await window.centralBridge.configure(centralUrl);
        await window.centralBridge.login({ username: u, password: p });
        if (window.centralSync?.syncMaterials) {
          const localMaterials = Array.isArray(window.M) ? window.M : (typeof gAll === 'function' ? await gAll('materials').catch(() => []) : []);
          await window.centralSync.syncMaterials(localMaterials);
        }
        if (['admin', 'developer'].includes(cu.role) && window.centralSync?.syncUsers) {
          await window.centralSync.syncUsers(users).catch(error => console.warn('[doLogin] Central user migration skipped:', error.message));
        }
      }
    } catch (centralError) {
      console.warn('[doLogin] Central server unavailable; continuing in offline mode:', centralError.message);
    }
    const mustChange = markDefaultCredentialIfNeeded(cu, p);

    console.log('[doLogin] Persisting user data (non-blocking)');

    // Non-blocking: persist user data but don't wait for UI transition
    dPut('users', cu).catch(err => {
      console.error('[doLogin] Failed to persist user data:', err);
    });

    // Non-blocking: log audit but don't wait for UI transition
    try {
      addAudit('LOGIN', 'Logged in', 'LOGIN');
      console.log('[doLogin] Audit logged');
    } catch (e) {
      console.error('[doLogin] Failed to log audit:', e);
    }

    console.log('[doLogin] Initializing session timeout');
    initSessionTimeout();

    console.log('[doLogin] Hiding login page and showing dashboard');
    document.getElementById('login-wrap').style.display = 'none';
    const app = document.getElementById('app');
    app.classList.add('visible');

    console.log('[doLogin] Setting user info in sidebar');
    document.getElementById('sb-nm').textContent = cu.name;
    document.getElementById('sb-rl').textContent = cu.role === 'admin' ? 'Administrator' : cu.role === 'developer' ? 'Developer' : cu.role === 'store' ? 'Store Person' : cu.role === 'maintenance' ? 'Maintenance Officer' : cu.role === 'auditor' ? 'Auditor' : 'Viewer';
    const av = document.getElementById('sb-av');
    av.textContent = cu.name[0].toUpperCase();
    av.style.background = cu.role === 'admin' ? 'var(--blb)' : 'var(--gnb)';
    av.style.color = cu.role === 'admin' ? 'var(--bl)' : 'var(--gn)';

    if (cu.role === 'store') {
      document.getElementById('store-note').style.display = 'flex';
    }

    if (cu.role !== 'admin' && cu.role !== 'developer') {
      ['n-users', 'n-audit', 'n-diag'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {el.style.display = 'none';}
      });
    }

    // Core infrastructure: real usage, not decorative — every login is logged
    // through the same persistent logger the Diagnostics panel reads from, and
    // broadcast on the event bus so anything subscribed (currently: the
    // Diagnostics panel's live event feed) picks it up immediately.
    if (window.securityLogger) {window.securityLogger.info('User logged in', { username: cu.username, role: cu.role });}
    if (window.sessionSecurity) {window.sessionSecurity.startSession({ username: cu.username, role: cu.role });}
    if (typeof loadNotifPrefs === 'function') {loadNotifPrefs();}
    if (typeof requestDesktopNotificationPermission === 'function') {requestDesktopNotificationPermission();}
    if (window.eventBus) {window.eventBus.emit('user:login', { username: cu.username, role: cu.role, ts: Date.now() });}
    if (window.stateManager) {window.stateManager.set('session.currentUser', { username: cu.username, role: cu.role });}

    console.log('[doLogin] Applying role permissions and updating UI');
    if (typeof applyFeatureMenuVisibility === 'function') {applyFeatureMenuVisibility();}
    applyRolePermissions();
    updateBadges();
    updateDash();
    renderConsumptionChart();
    renderSummary();

    // SECURITY FIX: restored — a default/must-change credential now forces the
    // user straight to Settings and blocks navigation elsewhere until they set
    // a real password (see nav() and canMutate()).
    if (mustChange || cu.mustChangePassword) {
      console.log('[doLogin] Password change required, redirecting to settings');
      passwordChangeRequired = true;
      toast('⚠ You are using a default password. Please set a new password to continue.', 'er');
      nav('cfg');
    } else {
      console.log('[doLogin] Login completed successfully');
    }

  } catch (error) {
    console.error('[doLogin] Login failed with error:', error);
    console.error('[doLogin] Stack trace:', error.stack);
    const lerr = document.getElementById('lerr');
    lerr.style.display = 'block';
    lerr.textContent = 'Login failed: ' + error.message;
    if (window.securityLogger) {window.securityLogger.error('Login failed', { message: error.message });}
    if (window.errorHandler) {window.errorHandler.handleError(error, { type: 'login_failed', silent: true });}
  }
}

function doLogout() {
  addAudit('LOGIN', 'Logged out', 'LOGIN');
  if (window.securityLogger && cu) {window.securityLogger.info('User logged out', { username: cu.username });}
  if (window.eventBus && cu) {window.eventBus.emit('user:logout', { username: cu.username, ts: Date.now() });}
  if (window.stateManager) {window.stateManager.set('session.currentUser', null);}
  if (window.sessionSecurity) {window.sessionSecurity.stopSession();}
  cu = null;
  if (window.DashboardWidgets?.setUser) {
    window.DashboardWidgets.setUser(null).catch(error => console.warn('[doLogout] Dashboard layout reset failed:', error));
  }
  passwordChangeRequired = false;
  clearTimeout(sessionTimeoutTimer);
  clearInterval(sessionActiveCheckTimer);
  sessionActiveCheckTimer = null;
  _removeAllEventListeners();
  // Reset role-specific UI so re-login as a different role works correctly
  const sn = document.getElementById('store-note'); if (sn) {sn.style.display = 'none';}
  ['n-users', 'n-audit', 'n-diag'].forEach(id => { const el = document.getElementById(id); if (el) {el.style.display = '';} });
  if (typeof applyFeatureMenuVisibility === 'function') {applyFeatureMenuVisibility();}
  document.getElementById('app').classList.remove('visible');
  document.getElementById('login-wrap').style.display = 'flex';
  document.getElementById('lp').value = '';
}

// Export for Node.js (Jest unit tests). Loaded as a plain global script in
// the app itself, so this block is a no-op in the browser/Electron renderer.
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    doLogin,
    doLogout,
    isViewer,
    canMutate,
    canAdmin,
    canRoleAction,
    normalizeRoleAction,
    ROLE_LABELS,
    ROLE_CAPABILITIES,
    ACTION_ALIASES,
    markDefaultCredentialIfNeeded,
    applyRolePermissions,
    // `passwordChangeRequired` is a module-private `let`, so a plain
    // `module.exports.passwordChangeRequired = passwordChangeRequired`
    // would only export a one-time snapshot. A getter/setter keeps tests
    // reading/writing the same live variable the functions above use.
    get passwordChangeRequired() { return passwordChangeRequired; },
    set passwordChangeRequired(v) { passwordChangeRequired = v; },
  };
}
