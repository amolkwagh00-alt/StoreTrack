// Demand Forecasting Module - Predict future demand for materials

/**
 * Demand Forecasting Engine
 */
class DemandForecastingEngine {
  constructor() {
    this.forecasts = new Map();
    this.init();
  }

  /**
   * Initialize forecasting engine
   */
  init() {
    this.loadSavedForecasts();
  }

  /**
   * Load saved forecasts from storage
   */
  async loadSavedForecasts() {
    try {
      const forecasts = await gAll('demand_forecasts');
      forecasts.forEach(f => {
        this.forecasts.set(f.id, f);
      });
    } catch (err) {
      console.error('Failed to load forecasts:', err);
    }
  }

  /**
   * Save forecasts to storage
   */
  async saveForecasts() {
    try {
      await dClr('demand_forecasts');
      await batchPut('demand_forecasts', Array.from(this.forecasts.values()));
    } catch (err) {
      console.error('Failed to save forecasts:', err);
    }
  }

  /**
   * Get historical demand data
   * @param {string} materialId - Material ID
   * @param {number} days - Number of days of history
   * @returns {Promise<Array>} - Historical demand data
   */
  async getHistoricalDemand(materialId, days = 90) {
    try {
      const transactions = await gAll('transactions');
      const materialTransactions = transactions.filter(t =>
        (t.barcode === materialId || String(t.itemId) === String(materialId)) && t.type === 'OUT' &&
        !['pending', 'pending-central', 'rejected', 'cancelled', 'canceled', 'void'].includes(String(t.status || '').toLowerCase())
      );
      
      // Group by week
      const weeklyDemand = {};
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - days);

      materialTransactions.forEach(t => {
        const date = new Date(t.time || t.timestamp || t.date || t.createdAt);
        const quantity = Number(t.qty ?? t.quantity);
        if (Number.isFinite(date.getTime()) && date >= cutoffDate && Number.isFinite(quantity)) {
          const weekNumber = this.getWeekNumber(date);
          const year = date.getFullYear();
          const key = `${year}-W${weekNumber}`;
          
          weeklyDemand[key] = (weeklyDemand[key] || 0) + quantity;
        }
      });

      // Convert to array and sort
      const data = Object.entries(weeklyDemand)
        .map(([key, demand]) => ({ period: key, demand }))
        .sort((a, b) => a.period.localeCompare(b.period));

      return data;
    } catch (err) {
      console.error('Failed to get historical demand:', err);
      return [];
    }
  }

  /**
   * Get ISO week number
   * @param {Date} date - Date
   * @returns {number} - Week number
   */
  getWeekNumber(date) {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
    return weekNo;
  }

  /**
   * Forecast demand using multiple methods
   * @param {string} materialId - Material ID
   * @param {number} weeks - Number of weeks to forecast
   * @returns {Promise<object>} - Forecast result
   */
  async forecastDemand(materialId, weeks = 12) {
    const historicalData = await this.getHistoricalDemand(materialId);
    
    if (historicalData.length < 4) {
      return {
        materialId,
        error: 'Insufficient historical data (need at least 4 weeks)',
        forecasts: []
      };
    }

    const forecasts = {
      materialId,
      weeks,
      generatedAt: new Date().toISOString(),
      methods: {
        average: this.forecastAverage(historicalData, weeks),
        trend: this.forecastTrend(historicalData, weeks),
        seasonal: this.forecastSeasonal(historicalData, weeks),
        weighted: this.forecastWeighted(historicalData, weeks)
      },
      consensus: [],
      historicalData
    };

    // Calculate consensus forecast
    for (let i = 0; i < weeks; i++) {
      const weekNum = i + 1;
      const avg = forecasts.methods.average[i]?.demand || 0;
      const trend = forecasts.methods.trend[i]?.demand || 0;
      const seasonal = forecasts.methods.seasonal[i]?.demand || 0;
      const weighted = forecasts.methods.weighted[i]?.demand || 0;
      
      // Weighted average of all methods
      const consensusDemand = (avg * 0.25 + trend * 0.35 + seasonal * 0.2 + weighted * 0.2);
      
      forecasts.consensus.push({
        week: weekNum,
        demand: Math.round(consensusDemand),
        confidence: this.calculateConfidence(historicalData, i),
        range: {
          min: Math.round(consensusDemand * 0.8),
          max: Math.round(consensusDemand * 1.2)
        }
      });
    }

    // Save forecast
    const forecastId = `forecast-${materialId}-${Date.now()}`;
    this.forecasts.set(forecastId, forecasts);
    await this.saveForecasts();

    return forecasts;
  }

  /**
   * Forecast using simple average
   * @param {Array} data - Historical data
   * @param {number} weeks - Weeks to forecast
   * @returns {Array} - Forecast
   */
  forecastAverage(data, weeks) {
    const avgDemand = data.reduce((sum, d) => sum + d.demand, 0) / data.length;
    
    return Array.from({ length: weeks }, (_, i) => ({
      week: i + 1,
      demand: Math.round(avgDemand)
    }));
  }

  /**
   * Forecast using trend analysis
   * @param {Array} data - Historical data
   * @param {number} weeks - Weeks to forecast
   * @returns {Array} - Forecast
   */
  forecastTrend(data, weeks) {
    const n = data.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;

    data.forEach((d, i) => {
      sumX += i;
      sumY += d.demand;
      sumXY += i * d.demand;
      sumX2 += i * i;
    });

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;

    return Array.from({ length: weeks }, (_, i) => ({
      week: i + 1,
      demand: Math.max(0, Math.round(slope * (n + i) + intercept))
    }));
  }

  /**
   * Forecast using seasonal adjustment
   * @param {Array} data - Historical data
   * @param {number} weeks - Weeks to forecast
   * @returns {Array} - Forecast
   */
  forecastSeasonal(data, weeks) {
    // Calculate seasonal indices (simplified)
    const seasonalIndices = this.calculateSeasonalIndices(data);
    const avgDemand = data.reduce((sum, d) => sum + d.demand, 0) / data.length;

    return Array.from({ length: weeks }, (_, i) => {
      const seasonIndex = seasonalIndices[i % seasonalIndices.length] || 1;
      return {
        week: i + 1,
        demand: Math.round(avgDemand * seasonIndex)
      };
    });
  }

  /**
   * Calculate seasonal indices
   * @param {Array} data - Historical data
   * @returns {Array} - Seasonal indices
   */
  calculateSeasonalIndices(data) {
    const periods = 4; // Quarterly seasonality
    const indices = new Array(periods).fill(1);
    
    if (data.length < periods) {return indices;}

    const periodSums = new Array(periods).fill(0);
    const periodCounts = new Array(periods).fill(0);

    data.forEach((d, i) => {
      const period = i % periods;
      periodSums[period] += d.demand;
      periodCounts[period]++;
    });

    const overallAvg = data.reduce((sum, d) => sum + d.demand, 0) / data.length;

    for (let i = 0; i < periods; i++) {
      if (periodCounts[i] > 0) {
        indices[i] = (periodSums[i] / periodCounts[i]) / overallAvg;
      }
    }

    return indices;
  }

  /**
   * Forecast using weighted average
   * @param {Array} data - Historical data
   * @param {number} weeks - Weeks to forecast
   * @returns {Array} - Forecast
   */
  forecastWeighted(data, weeks) {
    const weights = [0.1, 0.2, 0.3, 0.4]; // Data are chronological: newest period gets the highest weight.
    const recentData = data.slice(-4);
    
    if (recentData.length === 0) {
      return this.forecastAverage(data, weeks);
    }

    const recentWeights = weights.slice(4 - recentData.length);
    const weightTotal = recentWeights.reduce((sum, weight) => sum + weight, 0);
    const weightedAvg = recentData.reduce((sum, period, index) => sum + (Number(period.demand) || 0) * recentWeights[index], 0) / weightTotal;

    return Array.from({ length: weeks }, (_, i) => ({
      week: i + 1,
      demand: Math.round(weightedAvg)
    }));
  }

  /**
   * Calculate confidence level
   * @param {Array} data - Historical data
   * @param {number} weekOffset - Week offset
   * @returns {number} - Confidence level (0-1)
   */
  calculateConfidence(data, weekOffset) {
    const baseConfidence = 0.8;
    const decay = 0.05; // Confidence decreases with forecast horizon
    
    // More data = higher confidence
    const dataFactor = Math.min(0.1, data.length / 100);
    
    // Variance affects confidence
    const values = data.map(d => d.demand);
    const mean = values.reduce((sum, v) => sum + v, 0) / values.length;
    const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
    const varianceFactor = Math.max(0, 0.1 - variance / (mean * mean || 1));
    
    return Math.min(1, Math.max(0, baseConfidence - (weekOffset * decay) + dataFactor + varianceFactor));
  }

  /**
   * Get forecast for material
   * @param {string} materialId - Material ID
   * @returns {object} - Latest forecast
   */
  getForecast(materialId) {
    const forecasts = Array.from(this.forecasts.values())
      .filter(f => f.materialId === materialId)
      .sort((a, b) => new Date(b.generatedAt) - new Date(a.generatedAt));
    
    return forecasts[0] || null;
  }

  /**
   * Get all forecasts
   * @returns {Array} - All forecasts
   */
  getAllForecasts() {
    return Array.from(this.forecasts.values());
  }

  /**
   * Delete forecast
   * @param {string} forecastId - Forecast ID
   */
  async deleteForecast(forecastId) {
    this.forecasts.delete(forecastId);
    await this.saveForecasts();
  }

  /**
   * Clear old forecasts
   * @param {number} daysToKeep - Days to keep
   */
  async clearOldForecasts(daysToKeep = 30) {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

    for (const [id, forecast] of this.forecasts) {
      if (new Date(forecast.generatedAt) < cutoffDate) {
        this.forecasts.delete(id);
      }
    }

    await this.saveForecasts();
  }

  /**
   * Generate demand report
   * @param {string} materialId - Material ID
   * @returns {Promise<object>} - Demand report
   */
  async generateDemandReport(materialId) {
    const forecast = await this.forecastDemand(materialId, 12);
    const material = await gOne('materials', materialId);

    return {
      material: {
        id: materialId,
        name: material?.name || 'Unknown',
        barcode: material?.barcode || '',
        currentStock: material?.currentStock || 0,
        minStock: material?.minStock || 0
      },
      forecast,
      recommendations: this.generateRecommendations(forecast, material),
      generatedAt: new Date().toISOString()
    };
  }

  /**
   * Generate recommendations based on forecast
   * @param {object} forecast - Forecast data
   * @param {object} material - Material data
   * @returns {Array} - Recommendations
   */
  generateRecommendations(forecast, material) {
    const recommendations = [];
    const currentStock = material?.currentStock || 0;
    const totalForecastedDemand = forecast.consensus.reduce((sum, w) => sum + w.demand, 0);

    // Check if stock will run out
    if (totalForecastedDemand > currentStock) {
      recommendations.push({
        type: 'stockout_risk',
        severity: 'high',
        message: `Projected stockout within ${forecast.weeks} weeks. Total forecasted demand: ${totalForecastedDemand}, Current stock: ${currentStock}`,
        suggestedAction: 'Place order immediately'
      });
    }

    // Check if stock will fall below minimum
    const minStock = material?.minStock || 0;
    if (totalForecastedDemand > (currentStock - minStock)) {
      recommendations.push({
        type: 'low_stock_risk',
        severity: 'medium',
        message: `Stock will fall below minimum level. Forecasted demand: ${totalForecastedDemand}, Buffer: ${currentStock - minStock}`,
        suggestedAction: 'Consider placing order'
      });
    }

    // Check for overstock risk
    if (currentStock > totalForecastedDemand * 2) {
      recommendations.push({
        type: 'overstock_risk',
        severity: 'low',
        message: `Current stock significantly exceeds forecasted demand. Consider reducing order quantities.`,
        suggestedAction: 'Review inventory levels'
      });
    }

    return recommendations;
  }
}

/**
 * Global forecasting instance
 */
const demandForecastingEngine = new DemandForecastingEngine();

/**
 * Initialize demand forecasting
 */
async function initDemandForecasting() {
  await demandForecastingEngine.loadSavedForecasts();
  return demandForecastingEngine;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.DemandForecasting = {
    engine: demandForecastingEngine,
    init: initDemandForecasting,
    forecast: (materialId, weeks) => demandForecastingEngine.forecastDemand(materialId, weeks),
    getForecast: (materialId) => demandForecastingEngine.getForecast(materialId),
    getAllForecasts: () => demandForecastingEngine.getAllForecasts(),
    deleteForecast: (id) => demandForecastingEngine.deleteForecast(id),
    clearOldForecasts: (days) => demandForecastingEngine.clearOldForecasts(days),
    generateReport: (materialId) => demandForecastingEngine.generateDemandReport(materialId)
  };
}
