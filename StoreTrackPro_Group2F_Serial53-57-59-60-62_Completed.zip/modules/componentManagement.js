/* global AnomalyDetection */
/* Shank Mapping — complete Gun Matrix, stock, lifecycle, labels, reports, permissions, and accountability. */
(function () {
  'use strict';

  const STORES = {
    parts: 'component_parts', mappings: 'component_mappings', bins: 'component_bins', stock: 'component_stock',
    tx: 'component_stock_transactions', repair: 'component_repair_scrap', imports: 'component_import_history',
    audit: 'component_audit_log', people: 'maintenance_people', replacements: 'component_replacements', aliases: 'component_station_aliases', monthCloses: 'component_month_end_closes', partConfigs: 'component_part_forecast_configs', orders: 'component_procurement_orders', gunCounts: 'component_gun_counts', historicalConsumption: 'component_historical_consumption'
  };
  const ALLOCATION_BATCH_STORE = 'component_allocation_batches';
  const TYPES = ['Copper Shank', 'Adaptor', 'Holder', 'Pencil Shank'];
  // The configured vendor-number pattern identifies Pencil parts; Part Master
  // display labels can be stale or inherited from the source mapping position.
  const PENCIL_PART_FORMAT = /^(?:07-\d{2,4}(?:\/l?\d+)?|06-\d{3}\/l?\d+)$/i;
  const pencilPartKey = value => { const clean = vendorPartNo(value).trim().replace(/\s+/g, '').toLowerCase().replace(/\/l/g, '/'); return clean.replace(/^(\d{2})-(\d+)/, (_, prefix, number) => `${prefix}-${String(Number(number))}`); };
  const isPencilPart = value => PENCIL_PART_FORMAT.test(pencilPartKey(value));
  function stockRowsForView() {
    const rows = state.stock.filter(row => {
      if (!isPencilPart(row.partNo) || Number(row.quantity || 0) !== 0) { return true; }
      const bin = state.bins.find(item => String(item.binId || '') === String(row.binId || ''));
      return bin?.binKind === 'PENCIL_PAIR';
    }).map(row => ({ ...row }));
    const displayedByPartBin = new Map(rows.map(row => [`${partKey(row.partNo)}\u001f${String(row.binId || '')}`, row]));
    for (const mapping of state.mappings) {
      if (!isPencilPart(mapping.partNo) || !mapping.stationNo || mapping.stationNo === 'Station Not Assigned') { continue; }
      const commonBin = activeBinForStation(mapping.stationNo);
      if (!commonBin || commonBin.binKind === 'PENCIL_PAIR') { continue; }
      const key = `${partKey(mapping.partNo)}\u001f${String(commonBin.binId || '')}`;
      const pencilBins = state.bins.filter(bin => bin.binKind === 'PENCIL_PAIR' && (bin.pencilPartNumbers || []).some(value => partKey(value) === partKey(mapping.partNo)));
      const pencilBinIds = [...new Set([
        ...pencilBins.map(bin => String(bin.binId || '')).filter(Boolean),
        ...state.stock.filter(row => partKey(row.partNo) === partKey(mapping.partNo) && state.bins.find(bin => String(bin.binId || '') === String(row.binId || ''))?.binKind === 'PENCIL_PAIR').map(row => String(row.binId || '')).filter(Boolean)
      ])];
      if (!pencilBinIds.length) { continue; }
      const sharedQuantity = state.stock.filter(row => partKey(row.partNo) === partKey(mapping.partNo) && pencilBinIds.includes(String(row.binId || ''))).reduce((sum, row) => sum + Math.max(0, Number(row.quantity || 0)), 0);
      let displayed = displayedByPartBin.get(key);
      if (!displayed) {
        displayed = { id: `pencil-view-${key}`, partNo: mapping.partNo, binId: commonBin.binId, quantity: 0, minimumStock: Number(partByNo(mapping.partNo)?.minimumStock || 0) };
        rows.push(displayed);
        displayedByPartBin.set(key, displayed);
      }
      const localQuantity = Number(displayed.quantity || 0);
      displayed.quantity = localQuantity + sharedQuantity;
      displayed.pencilStockBinIds = pencilBinIds;
      displayed.pencilSharedStockQuantity = sharedQuantity;
      displayed.pencilLocalStockQuantity = localQuantity;
    }
    return rows;
  }
  function stockRowLocationComment(row) { return row.pencilStockBinIds?.length ? `Qty ${Number(row.pencilSharedStockQuantity || 0)} is held in ${row.pencilStockBinIds.join(', ')}` : ''; }
  const pencilSeriesKey = value => { const key = pencilPartKey(value); return key.includes('/') ? key.split('/')[0] : key; };
  const pencilSuffixNumber = value => { const key = pencilPartKey(value); const suffix = key.includes('/') ? key.split('/').slice(1).join('/') : ''; const digits = suffix.replace(/^l/, '').match(/\d+/); return digits ? Number(digits[0]) : Number.MAX_SAFE_INTEGER; };
  const PENCIL_MAPPING_POSITIONS = new Set(['fix shank', 'moving shank', 'fix adaptor', 'moving adaptor', 'fix holder', 'moving holder']);
  const pencilPositionKey = value => String(value || '').trim().toLowerCase().replace(/\bfixed\b/g, 'fix').replace(/\bmobile\b/g, 'moving');
  const isPencilMapping = mapping => PENCIL_MAPPING_POSITIONS.has(pencilPositionKey(mapping?.position)) && isPencilPart(mapping?.partNo);
  const POSITIONS = ['Fix Shank', 'Moving Shank', 'Fix Adaptor', 'Moving Adaptor', 'Fix Holder', 'Moving Holder', 'Pencil Shank'];
  const perfTools = window.storeTrackPerformance || { yieldToUi: () => Promise.resolve() };
  function updateImportProgress(percent, label) {
    const bar = document.getElementById('cm-import-progress-bar');
    const text = document.getElementById('cm-import-progress-text');
    if (bar) { bar.max = 100; bar.value = Math.max(0, Math.min(100, Number(percent) || 0)); }
    if (text) { text.textContent = String(label || ''); }
  }
  function setImportCommitState(committing) {
    const button = document.querySelector('[data-onclick="componentCancelImportProcessing()"]');
    if (!button) { return; }
    button.disabled = Boolean(committing);
    button.textContent = committing ? 'Commit in progress — cancel unavailable' : 'Cancel Processing';
    button.setAttribute('aria-label', committing ? 'Import commit in progress; cancellation is unavailable' : 'Cancel import preview processing');
  }
  const getForecastStatus = params => window.ShankConsumptionAnalytics?.forecastStatus?.(params) || 'NORMAL';
  const CONDITIONS = ['New', 'Used', 'Repairable', 'Scrap', 'Water Leakage', 'Other'];
  const ACTIONS = ['Repair', 'Scrap'];
  const SHIFTS = ['1st Shift', '2nd Shift', '3rd Shift'];
  const COLUMN_FIELDS = ['stationNo', 'gunReferenceNo', 'fixShank', 'movingShank', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder', 'pencilShank', 'quantity'];
  const GUN_COUNT_COMPONENT_FIELDS = ['fixShank', 'movingShank', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder'];
  const FIELD_LABELS = { stationNo: 'Station No.', gunReferenceNo: 'Gun Reference No.', fixShank: 'Fix Shank', movingShank: 'Moving Shank', fixAdaptor: 'Fix Adaptor', movingAdaptor: 'Moving Adaptor', fixHolder: 'Fix Holder', movingHolder: 'Moving Holder', pencilShank: 'Pencil Shank', quantity: 'Quantity (optional)' };
  let state = { tab: 'dashboard', parts: [], mappings: [], gunRows: [], bins: [], stock: [], tx: [], repairs: [], imports: [], people: [], replacements: [], aliases: [], monthCloses: [], allocationBatches: [], importDraft: null, analyticsRange: null };
  let pendingStockImport = null;
  let componentInitialized = false;
  // SheetJS is bundled locally so Gun Matrix import works in both source and packaged Electron builds.
  function getXlsxParser() { return window.XLSX || globalThis.XLSX || null; }
  async function parseWorkbookRows(file) {
    if (!file) return [];
    if (/\.(xlsx|xls|xlsm)$/i.test(file.name)) {
      if (window.BulkImport?.manager?.parseExcel) return window.BulkImport.manager.parseExcel(await file.arrayBuffer(), { hasHeaders: false });
      const parser = getXlsxParser();
      if (!parser?.read || !parser.utils?.sheet_to_json) throw new Error('XLSX parser is unavailable');
      const workbook = parser.read(await file.arrayBuffer(), { type: 'array' });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      return parser.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false });
    }
    return parseReplacementCsv(await file.text());
  }
  const COMPONENT_CAPABILITIES = { view: 'shankMapping.view', import: 'shankMapping.import', partMaster: 'shankMapping.partMaster', mapping: 'shankMapping.mapping', bin: 'shankMapping.bin', stockReceive: 'shankMapping.stockReceive', stockAdjust: 'shankMapping.stockAdjust', replacement: 'shankMapping.replacement', lifecycle: 'shankMapping.lifecycle', labels: 'shankMapping.labels', reports: 'shankMapping.reports', guide: 'shankMapping.guide' };
  const canComponent = (action, admin = false) => {
    const current = user();
    const key = COMPONENT_CAPABILITIES[action] || action;
    const explicit = current.permissions?.[key] ?? current.permissions?.shankMapping?.[action] ?? current.featurePermissions?.[key];
    if (explicit === false) { toastMsg(`Permission denied: ${key}`, 'er'); return false; }
    if (action === 'view' || action === 'guide' || action === 'reports' && !admin) { return true; }
    const normalizedAction = String(action).toLowerCase().replace(/\s+/g, '');
    // Every component action resolves to one canonical global capability.
    const roleAction = {
      import: 'imports', consumptionimport: 'consumptionImport', replacement: 'replacement',
      stockreceive: 'stockReceive', stockadjust: 'physicalStock', stockadjustment: 'physicalStock',
      partmaster: 'partRegister', bin: 'mapping', mapping: 'mapping', lifecycle: 'lifecycle',
      labels: 'pdfExcelExport', reports: 'reports', monthend: 'monthEndClose'
    }[normalizedAction] || action;
    if (typeof window.canRoleAction === 'function') { return window.canRoleAction(roleAction); }
    const fn = admin ? window.canAdmin : window.canMutate;
    return typeof fn === 'function' ? fn(`Shank Mapping ${action}`) : true;
  };
  window.canShankComponent = canComponent;
  const normalStation = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  function activeStationAlias(value) { const key = normalStation(value); return key ? (state.aliases || []).find(item => String(item.status || 'ACTIVE').toUpperCase() !== 'INACTIVE' && normalStation(item.alias) === key) || null : null; }
  function resolveStationAlias(value) { const alias = activeStationAlias(value); return canonicalStation(alias?.canonicalStation || value); }
  // Gun references are identifiers, but imported/manual data often differs only by
  // spaces, hyphens, or labels such as "Gun 01" vs "GUN-01".
  const normalGunReference = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  // Shank Mapping exception: vendor/manufacturing Part Numbers are authoritative.
  // Do not generate, renumber, or substitute these identifiers.
  const SHANK_MAPPING_VENDOR_PART_NUMBER_RULE = 'PRESERVE_VENDOR_PART_NUMBER_EXACTLY';
  const MAPPED_PART_FIELDS = ['fixShank', 'movingShank', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder'];
  const MAPPED_PART_POSITIONS = MAPPED_PART_FIELDS.map(field => field.toLowerCase());
  function vendorPartNo(value) { return value == null ? '' : String(value); }
  const partNumberUtils = window.PartNumberUtils || {};
  const normalizePartNo = partNumberUtils.normalizePartNo || (value => vendorPartNo(value).trim().replace(/\s+/g, '').split(/([\/-])/).map(segment => /^\d+$/.test(segment) ? String(Number(segment)) : segment.toUpperCase()).join(''));
  const partKey = partNumberUtils.partKey || (value => normalizePartNo(value).toLowerCase());
  const samePartNo = partNumberUtils.samePartNo || ((a, b) => Boolean(partKey(a)) && partKey(a) === partKey(b));
  const displayPartNo = partNumberUtils.displayPartNo || (values => [...new Set((Array.isArray(values) ? values : [values]).map(v => vendorPartNo(v).trim()).filter(Boolean))].join(' / '));
  function validMappedPartNo(value) { const partNo = vendorPartNo(value).trim(); return Boolean(partNo) && !/^(?:n\/?a|na|not\s*applicable|not\s*available|-+)$/i.test(partNo); }
  // Canonical Gun Count: every unique Station + Gun occurrence counts as one Gun. Quantity and Required Qty are separate measures.
  const gunCountService = window.GunCountService;
  function calculateGunCount(rows, mapped = false) { return gunCountService ? gunCountService.calculateGunCount(rows, mapped) : (typeof rows === 'number' && Number.isFinite(rows) ? Math.max(0, Math.floor(rows)) : rows instanceof Set ? rows.size : Array.isArray(rows) ? rows.length : 0); }
  async function rebuildGunCountAggregate() {
    if (!gunCountService) {return null;}
    const existingRows = await gAll(STORES.gunCounts);
    const previous = existingRows.find(x => x && x.id === 'global');
    const metrics = await gunCountService.persistAggregate({ gAll, dPut, dClr, sourceRows: state.gunRows || [], mappingRows: state.mappings || [], store: STORES.gunCounts, existingRows });
    if (metrics?.persisted) {
      await audit('GUN_COUNT_RECALCULATED', 'Gun Count', 'global', { oldGunCount: previous?.gunCount ?? null, newGunCount: metrics.total, sourceGunCount: metrics.source, mappedGunCount: metrics.mapped, allocatedGunCount: metrics.allocated, unassignedGunCount: metrics.unassigned, calculationVersion: metrics.calculationVersion, sourceHash: metrics.sourceHash, mappingHash: metrics.mappingHash, reconciliation: metrics.reconciliation });
    }
    return metrics;
  }
  const canonicalStation = value => String(value || '').trim().replace(/\s+/g, ' ');
  function sameStation(a, b) { const left = normalStation(resolveStationAlias(a)); return left !== '' && left === normalStation(resolveStationAlias(b)); }
  // Normalize all LH/RH suffix forms, including merged labels such as
  // `ECA 50 RH/LH`, `ECA 50 LH/RH`, `ECA-50-RH`, and `ECA 50 RH`.
  // A merged bin must resolve to the same base station as either source side.
  const baseStationName = value => {
    let text = resolveStationAlias(String(value || ''));
    // Strip LH/RH suffixes one at a time so RH/LH, LH/RH and single-side
    // station names all resolve to the same base station without changing
    // the original station identity stored on mappings/gun rows.
    text = text.replace(/(?:[\s_-]+)(?:LH|RH)[/\\.,;:]*$/i, '').trim();
    text = text.replace(/(?:[\s_-]+)(?:LH|RH)[/\\.,;:]*$/i, '').trim();
    return canonicalStation(text);
  };
  const baseStationKey = value => normalStation(baseStationName(value));
  // Bin/Mapping station identity: punctuation and spacing are cosmetic, but LH/RH suffixes are distinct stations.
  const stationVariantKey = value => normalStation(resolveStationAlias(value));
  // RH/LH consolidation makes the active merged bin the canonical display source.
  // Inactive source bins and stale stock-row station values must not downgrade an
  // assigned station to "Station Not Assigned" in dashboard/label views.
  function activeBinForStation(stationNo) {
    const requested = canonicalStation(stationNo);
    const key = baseStationKey(requested);
    if (!key) {return null;}
    // If a canonical RH/LH Common Bin exists, it is authoritative for either
    // side. Check it before the legacy exact-station lookup so a stale active
    // source bin can never make an already-merged LH/RH station resolve back to
    // its old bin and eventually render as Station Not Assigned.
    const merged = state.bins.find(bin => bin.active !== false && (bin.mergedStations || []).some(station => baseStationKey(station) === key));
    if (merged) {return merged;}
    // With no merge present, keep RH and LH independent and resolve the exact
    // station bin first. This preserves normal non-merged station behavior.
    const exact = state.bins.find(bin => bin.active !== false && sameStation(bin.stationNo, requested));
    if (exact) {return exact;}
    // Only an explicitly merged legacy label may resolve as a fallback. A
    // single-side RH bin must never satisfy an LH lookup (or vice versa).
    const legacyCommon = state.bins.find(bin => bin.active !== false && baseStationKey(bin.stationNo) === key && [bin.binId, bin.stationNo, bin.name].some(value => /(?:^|[\s_-])(?:RH\/LH|LH\/RH)(?:$|[\s_-])/i.test(canonicalStation(value))));
    return legacyCommon || null;
  }
  function displayStationForBin(stationNo, binId) {
    const direct = canonicalStation(stationNo);
    // Resolve an RH/LH stock row to the active merged bin. If the stock row
    // points at an inactive pre-merge source bin, follow its merge metadata.
    const sourceBin = binId ? state.bins.find(item => String(item.binId || '') === String(binId)) : null;
    const directActive = binId ? state.bins.find(item => String(item.binId || '') === String(binId) && item.active !== false) : null;
    const mergedActive = sourceBin?.mergedInto
      ? state.bins.find(item => String(item.binId || '') === String(sourceBin.mergedInto) && item.active !== false)
      : null;
    const stationActive = activeBinForStation(direct);
    const relatedMerged = sourceBin && !stationActive
      ? state.bins.find(item => item.active !== false && (item.mergedStations || []).some(station => baseStationKey(station) === baseStationKey(sourceBin.stationNo)))
      : null;
    // Legacy/imported stock rows can carry an unusable stationNo while the
    // original station was retained in the bin's physical location field.
    // When the direct station is unassigned, resolve that legacy station hint
    // through the active/merged bin before falling back to "Station Not Assigned".
    const locationHint = canonicalStation(sourceBin?.location);
    const locationActive = (!direct || direct === 'Station Not Assigned') && locationHint
      ? activeBinForStation(locationHint)
      : null;
    const bin = mergedActive || relatedMerged || stationActive || locationActive || directActive;
    if (bin?.active !== false) {
      // A merged physical bin can serve two distinct station identities. Preserve
      // the requested station when the merged bin explicitly contains it instead
      // of leaking the target bin's single stationNo (often RH) into LH rows.
      const mergedStations = Array.isArray(bin.mergedStations) ? bin.mergedStations : [];
      if (direct && direct !== 'Station Not Assigned' && mergedStations.some(station => sameStation(station, direct))) {
        return direct;
      }
      if (bin?.stationNo && bin.stationNo !== 'Station Not Assigned') { return canonicalStation(bin.stationNo); }
    }
    return direct && direct !== 'Station Not Assigned' ? direct : locationHint && locationHint !== 'Station Not Assigned' ? locationHint : 'Station Not Assigned';
  }
  const mappingIdentity = (stationNo, gunReferenceNo, position) => `${normalStation(stationNo)}\u001f${String(gunReferenceNo ?? '')}\u001f${String(position ?? '')}`;
  function splitBoldPartText(value) { return vendorPartNo(value).split(/[\n,;|]+/).flatMap(token => { const clean = token.trim(); if (!clean) { return []; } const slashParts = clean.split('/').map(partNo => partNo.trim()).filter(Boolean); if (slashParts.length === 2 && /^M$/i.test(slashParts[1]) && /^[A-Za-z0-9]+-\d+/.test(slashParts[0])) { return [clean]; } if (slashParts.length === 2 && /^\d{1,3}$/.test(slashParts[1]) && /^[A-Za-z0-9]+-\d+/.test(slashParts[0])) { return [clean]; } return slashParts; }).filter(validMappedPartNo); }
  function componentPairsForRow(row) {
    const fields = [['Fix Shank', 'fixShank'], ['Moving Shank', 'movingShank'], ['Fix Adaptor', 'fixAdaptor'], ['Moving Adaptor', 'movingAdaptor'], ['Fix Holder', 'fixHolder'], ['Moving Holder', 'movingHolder']];
    return fields.flatMap(([position, field]) => {
      const boldValues = Array.isArray(row.boldParts?.[field]) ? row.boldParts[field].filter(validMappedPartNo) : [];
      const values = boldValues.length ? boldValues : [vendorPartNo(row[field])];
      return values.filter(validMappedPartNo).map(partNo => [position, vendorPartNo(partNo).trim()]);
    });
  }
  function partStockQuantity(partNo) {
    const key = partKey(partNo);
    if (!key) { return 0; }
    return (state.stock || []).filter(stock => partKey(stock.partNo) === key).reduce((total, stock) => total + Math.max(0, Number(stock.quantity || 0)), 0);
  }
  function partCandidateMeta(row, field) {
    const headerIndex = (row.sourceHeaders || []).findIndex(header => likelyField(header, field));
    const raw = headerIndex >= 0 ? splitBoldPartText((row.sourceValues || [])[headerIndex]) : splitBoldPartText(row[field]);
    const bold = Array.isArray(row.boldParts?.[field]) ? row.boldParts[field].filter(validMappedPartNo) : [];
    const original = bold[0] || '';
    const alternatives = raw.filter(part => !bold.some(candidate => samePartNo(candidate, part)));
    return { original, alternatives, candidates: [...(original ? [original] : []), ...alternatives] };
  }
  const PART_OPTION_FIELDS = { 'Fix Shank': 'fixShank', 'Moving Shank': 'movingShank', 'Fix Adaptor': 'fixAdaptor', 'Moving Adaptor': 'movingAdaptor', 'Fix Holder': 'fixHolder', 'Moving Holder': 'movingHolder', 'Pencil Shank': 'pencilShank' };
  function partRoleForMapping(mapping) {
    const position = labelPosition(mapping?.position || '');
    const options = mapping?.partOptions?.[PART_OPTION_FIELDS[position]];
    if (options?.original && samePartNo(options.original, mapping.partNo)) { return 'Original'; }
    if (options?.alternatives?.some(part => samePartNo(part, mapping.partNo))) { return 'Alternative'; }
    return 'Selected';
  }
  function partCommentForMapping(mapping) {
    const position = labelPosition(mapping?.position || '');
    const field = PART_OPTION_FIELDS[position];
    const options = mapping?.partOptions?.[field] || {};
    const role = partRoleForMapping(mapping);
    const original = validMappedPartNo(options.original) ? vendorPartNo(options.original).trim() : '';
    const alternatives = (options.alternatives || []).filter(validMappedPartNo).filter(part => !samePartNo(part, mapping.partNo));
    const notes = [];
    if (role === 'Alternative' && original && !samePartNo(original, mapping.partNo)) { notes.push(`Original Part No.: ${original}`); }
    if (alternatives.length) { notes.push(`Alternative Part No.: ${alternatives.map(part => vendorPartNo(part).trim()).join(' / ')}`); }
    return notes.join('; ');
  }
  function candidatePartEntries(mapping) {
    const position = labelPosition(mapping?.position || '');
    const field = PART_OPTION_FIELDS[position];
    const options = mapping?.partOptions?.[field];
    return (options?.candidates || []).filter(validMappedPartNo).map(partNo => ({ partNo: vendorPartNo(partNo).trim(), role: options.original && samePartNo(options.original, partNo) ? 'Original' : 'Alternative', position }));
  }
  function candidatePartComment(entry) { return ''; }
  function partUsageComment(partNo) {
    // Show the Original and every Alternative wherever a part number is listed,
    // regardless of whether the currently displayed part is the original or a
    // selected alternative.
    const comments = [];
    const addOptions = options => {
      if (!options) { return; }
      const original = validMappedPartNo(options.original) ? vendorPartNo(options.original).trim() : '';
      const alternatives = (options.alternatives || []).filter(validMappedPartNo).map(value => vendorPartNo(value).trim()).filter(value => !samePartNo(value, partNo));
      if (original && !samePartNo(original, partNo)) { comments.push(`Original Part No.: ${original}`); }
      if (alternatives.length) { comments.push(`Alternative Part No.: ${alternatives.join(' / ')}`); }
    };
    state.mappings.filter(mapping => samePartNo(mapping.partNo, partNo)).forEach(mapping => addOptions(mapping.partOptions?.[PART_OPTION_FIELDS[labelPosition(mapping.position || '')]]));
    (state.gunRows || []).forEach(row => Object.values(row.partOptions || {}).forEach(options => {
      const candidates = (options?.candidates || []).filter(validMappedPartNo);
      if (candidates.some(candidate => samePartNo(candidate, partNo))) { addOptions(options); }
    }));
    return [...new Set(comments)].join('; ');
  }
  function partTypeForOptionField(field) {
    const position = Object.entries(PART_OPTION_FIELDS).find(([, value]) => value === field)?.[0] || field;
    return position.includes('Pencil') ? 'Pencil Shank' : position.includes('Shank') ? 'Copper Shank' : position.includes('Adaptor') ? 'Adaptor' : 'Holder';
  }
  async function ensureCandidatePartRecords(row) {
    for (const [field, options] of Object.entries(row.partOptions || {})) {
      for (const candidate of options?.candidates || []) {
        const partNo = vendorPartNo(candidate).trim();
        if (!validMappedPartNo(partNo) || partByNo(partNo)) { continue; }
        const part = { id: uid('part'), partNo, description: `${partTypeForOptionField(field)} ${partNo}`, componentType: partTypeForOptionField(field), active: true, minimumStock: 0, status: 'ZERO STOCK', createdAt: nowIso(), updatedAt: nowIso(), candidateOnly: true };
        await dPut(STORES.parts, part); state.parts.push(part);
      }
    }
  }
  async function ensureCandidateStockRecords(row, bin) {
    if (!bin?.binId) { return; }
    for (const [field, options] of Object.entries(row.partOptions || {})) {
      const position = Object.entries(PART_OPTION_FIELDS).find(([, value]) => value === field)?.[0] || field;
      for (const candidate of options?.candidates || []) {
        const partNo = vendorPartNo(candidate).trim();
        if (!validMappedPartNo(partNo)) { continue; }
        await ensureStockRecord(partNo, bin.binId);
        const stock = stockFor(partNo, bin.binId);
        if (stock) { stock.candidateOnly = false; stock.candidateRole = options.original && samePartNo(options.original, partNo) ? 'Original' : 'Alternative'; stock.shankType = position; stock.useWhenOriginalStockZero = stock.candidateRole === 'Alternative'; await dPut(STORES.stock, stock); }
      }
    }
  }
  function partDisplayWithComment(partNo, mapping) {
    const clean = vendorPartNo(partNo).trim();
    const comment = mapping ? partCommentForMapping(mapping) : partUsageComment(clean);
    return comment ? `${clean} — ${comment}` : clean;
  }
  function boldPartsFromCell(cell, cellIsBold = false) {
    if (!cell) {return [];} const richXml = vendorPartNo(cell.r || ''); const richParts = [];
    const runs = [...richXml.matchAll(/<r>([\s\S]*?)<\/r>/gi)];
    runs.forEach(match => { const run = match[1]; if (!/<rPr[\s\S]*?<b(?:\s|\/?>)/i.test(run)) {return;} const text = [...run.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/gi)].map(x => x[1]).join(''); if (text) {richParts.push(text);}});
    if (richParts.length) {return splitBoldPartText(richParts.join(' '));}
    const html = vendorPartNo(cell.h || ''); if (/<b(?:\s|>)/i.test(html)) {return splitBoldPartText(html.replace(/<[^>]+>/g, ''));}
    return cellIsBold ? splitBoldPartText(cell.v ?? cell.w ?? '') : [];
  }
  const fieldKey = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const likelyField = (header, field) => { const h = fieldKey(header); const aliases = { stationNo: ['station', 'stationno', 'stationnumber', 'stationid'], gunReferenceNo: ['gunno', 'gunreference', 'gunreferenceno', 'gunreferencenumber', 'gunrefrence', 'gunrefrenceno', 'gunrefrencenumber', 'gunrefernce', 'gunreferncenumber', 'gunref'], fixShank: ['fixshank', 'fixedshank', 'fixshankpartno', 'fixpartno'], movingShank: ['movingshank', 'movingshankpartno', 'movingpartno', 'movshank'], fixAdaptor: ['fixadaptor', 'fixedadaptor', 'fixadapter', 'fixedadapter'], movingAdaptor: ['movingadaptor', 'movingadapter', 'movadaptor', 'movadapter'], fixHolder: ['fixholder', 'fixedholder'], movingHolder: ['movingholder', 'movholder', 'movholder'], pencilShank: ['pencilshank', 'pencilshankpartno', 'pencilpartno'], quantity: ['qty', 'quantity', 'totalnoofguns', 'totalguns', 'xgun', 'cgun', 'gunqty', 'gunquantity'] }; return (aliases[field] || []).some(a => h === a || h.includes(a)); };
  function detectHeaderInfo(matrix) {
    const limit = Math.min(matrix.length, 12);
    let best = { index: 0, score: 0 };
    for (let i = 0; i < limit; i++) {
      const score = COLUMN_FIELDS.reduce((n, field) => n + (matrix[i] || []).some(cell => likelyField(cell, field) ? 1 : 0), 0);
      if (score > best.score) {best = { index: i, score };}
    }
    const base = (matrix[best.index] || []).map(v => String(v == null ? '' : v).trim());
    const merged = base.slice();
    for (let i = Math.max(0, best.index - 1); i <= Math.min(limit - 1, best.index + 1); i++) {
      if (i === best.index) {continue;}
      (matrix[i] || []).forEach((cell, col) => { const text = String(cell == null ? '' : cell).trim(); if (text && !merged[col]) {merged[col] = text;} });
    }
    let dataStart = best.index + 1;
    while (dataStart < matrix.length && (matrix[dataStart] || []).some(cell => COLUMN_FIELDS.some(field => likelyField(cell, field)))) {dataStart++;}
    return { headerRow: best.index, dataStart, headers: merged, score: best.score };
  }
  function resolveSheetColumn(headers, field, selectedHeader) {
    const selected = String(selectedHeader || '').trim();
    const selectedKey = fieldKey(selected);
    let index = selected ? headers.findIndex(h => String(h || '').trim() === selected) : -1;
    if (index < 0 && selectedKey) {index = headers.findIndex(h => fieldKey(h) === selectedKey);}
    if (index < 0 || !likelyField(headers[index], field)) {index = headers.findIndex(h => likelyField(h, field));}
    return index;
  }
  function numericQty(value) {
    const n = Number(String(value == null ? '' : value).replace(/,/g, '').trim());
    return Number.isFinite(n) && n > 0 ? n : 0;
  }
  function rowEndingQuantity(values, headers) {
    const supportedFields = ['stationNo', 'gunReferenceNo', 'fixShank', 'movingShank', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder', 'pencilShank'];
    let last = values.length - 1;
    while (last >= 0 && String(values[last] == null ? '' : values[last]).trim() === '') {last--;}
    const lastHeader = fieldKey(headers[last] || '');
    const lastValue = numericQty(values[last]);
    const lastSupportedIndex = headers.reduce((max, h, i) => supportedFields.some(field => likelyField(h, field)) ? Math.max(max, i) : max, -1);
    if (lastValue && last > lastSupportedIndex && !lastHeader.includes('minqty') && !lastHeader.includes('minimum')) {return lastValue;}
    return 0;
  }
  function derivedGunQuantity(values, headers, quantityIndex) {
    const findHeader = aliases => headers.findIndex(h => aliases.some(alias => fieldKey(h).includes(alias)));
    const selectedHeader = quantityIndex >= 0 ? fieldKey(headers[quantityIndex]) : '';
    // X-GUN and C-GUN are additive. A manually mapped quantity column is used
    // only when it is a single, generic quantity field—not when it points at X-GUN.
    const isAggregateHeader = selectedHeader.includes('xgun') || selectedHeader.includes('cgun') || selectedHeader.includes('totalnoofguns') || selectedHeader.includes('totalguns');
    const isMinimumHeader = selectedHeader.includes('minqty') || selectedHeader.includes('minimum');
    const explicit = !isAggregateHeader && !isMinimumHeader && quantityIndex >= 0 ? numericQty(values[quantityIndex]) : 0;
    if (explicit) {return explicit;}
    const totalIndex = findHeader(['totalnoofguns', 'totalguns', 'gunquantity', 'gunqty']);
    const total = totalIndex >= 0 ? numericQty(values[totalIndex]) : 0;
    if (total) {return total;}
    const xIndex = findHeader(['xgun']);
    const cIndex = findHeader(['cgun']);
    const x = xIndex >= 0 ? numericQty(values[xIndex]) : 0;
    const c = cIndex >= 0 ? numericQty(values[cIndex]) : 0;
    const trailing = rowEndingQuantity(values, headers);
    return x + c || trailing || 1;
  }
  function quantitySource(values, headers, sourceSheet) {
    const key = fieldKey(sourceSheet);
    const maxIndex = headers.findIndex(h => ['maxqty', 'maximumqty', 'maxquantity'].some(alias => fieldKey(h).includes(alias)));
    if (key.includes('newlyaddedguns') && maxIndex >= 0 && numericQty(values[maxIndex])) {return 'Newly Added Guns: Max Qty';}
    const totalIndex = headers.findIndex(h => ['totalnoofguns', 'totalguns', 'gunquantity', 'gunqty'].some(alias => fieldKey(h).includes(alias)));
    if (totalIndex >= 0 && numericQty(values[totalIndex])) {return 'Total Guns';}
    const xIndex = headers.findIndex(h => fieldKey(h).includes('xgun'));
    const cIndex = headers.findIndex(h => fieldKey(h).includes('cgun'));
    if ((xIndex >= 0 && numericQty(values[xIndex])) || (cIndex >= 0 && numericQty(values[cIndex]))) {return 'X-GUN + C-GUN';}
    if (rowEndingQuantity(values, headers)) {return 'Row-ending Qty';}
    return 'Default 1';
  }
  function derivedRequiredQuantity(values, headers, gunQuantity, sourceSheet) {
    const sheetKey = fieldKey(sourceSheet);
    const maxIndex = headers.findIndex(h => ['maxqty', 'maximumqty', 'maxquantity'].some(alias => fieldKey(h).includes(alias)));
    // Newly Added Guns defines the usable quantity for that gun with Max Qty.
    // This is the final required quantity for that sheet, not another ×2 input.
    if (sheetKey.includes('newlyaddedguns') || maxIndex >= 0 && sheetKey.includes('newlyadded')) {
      const maxQty = maxIndex >= 0 ? numericQty(values[maxIndex]) : rowEndingQuantity(values, headers);
      if (maxQty) {return maxQty;}
    }
    return Math.max(1, Number(gunQuantity || 1)) * 2;
  }

  const esc = v => String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const uid = prefix => (typeof generateUUID === 'function' ? generateUUID() : `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
  const val = id => (document.getElementById(id)?.value || '').trim();
  const sel = id => document.getElementById(id)?.value || '';
  function componentInputDialog(title, label, initialValue = '', type = 'text') {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.className = 'modal on';
      overlay.setAttribute('role', 'dialog');
      overlay.setAttribute('aria-modal', 'true');
      const safeValue = esc(initialValue);
      overlay.innerHTML = `<div class="modal-content" style="max-width:420px"><div class="modal-hd">${esc(title)}</div><div class="modal-body"><label class="fl" for="cm-input-dialog-value">${esc(label)}</label><input class="fi" id="cm-input-dialog-value" type="${type === 'number' ? 'number' : 'text'}" value="${safeValue}"></div><div class="modal-actions"><button class="btn btn-p" type="button" data-input-action="save">Save</button><button class="btn" type="button" data-input-action="cancel">Cancel</button></div></div>`;
      document.body.appendChild(overlay);
      const finish = value => { overlay.remove(); resolve(value); };
      overlay.querySelector('[data-input-action="save"]')?.addEventListener('click', () => finish(overlay.querySelector('#cm-input-dialog-value')?.value ?? null));
      overlay.querySelector('[data-input-action="cancel"]')?.addEventListener('click', () => finish(null));
      overlay.addEventListener('click', event => { if (event.target === overlay) { finish(null); } });
      const input = overlay.querySelector('#cm-input-dialog-value');
      input?.focus(); input?.select();
    });
  }
  const user = () => window.cu || {};
  const today = () => new Date().toISOString().slice(0, 10);
  const calendarMonthEndDate = month => { const match = /^(\d{4})-(\d{2})$/.exec(String(month || '')); if (!match) return today(); const year = Number(match[1]); const monthNo = Number(match[2]); if (monthNo < 1 || monthNo > 12) return today(); const day = new Date(Date.UTC(year, monthNo, 0)).getUTCDate(); return `${match[1]}-${match[2]}-${String(day).padStart(2, '0')}`; };
  const nowIso = () => new Date().toISOString();
  const toastMsg = (message, kind) => typeof toast === 'function' && toast(message, kind || 'inf');
  const audit = async (action, entity, entityId, details) => {
    const u = user();
    const row = { id: uid('ca'), action, entity, entityId: entityId || null, details: details || {}, timestamp: nowIso(), userId: u.id || null, username: u.username || u.name || 'Unknown' };
    await dPut(STORES.audit, row);
    if (typeof addAudit === 'function') {await addAudit(action, `${entity}: ${JSON.stringify(details || {})}`, 'COMPONENT_MANAGEMENT');}
  };
  const statusFor = (qty, minimum) => Number(qty) <= 0 ? 'ZERO STOCK' : Number(qty) < Number(minimum || 0) ? 'LOW STOCK' : 'OK STOCK';
  // Legacy exact lookup: const partByNo = partNo => state.parts.find(p => vendorPartNo(p.partNo) === vendorPartNo(partNo));
  const partByNo = partNo => state.parts.find(p => samePartNo(p.partNo, partNo));
  const isOperationalPart = part => Boolean(part && part.active !== false && validMappedPartNo(part.partNo));
  const stockStatusFor = (quantity, requiredQty) => Number(quantity || 0) <= 0 ? 'ZERO STOCK' : Number(quantity || 0) < Number(requiredQty || 0) ? 'LOW STOCK' : 'OK STOCK';
  const knownComponentPartNo = partNo => Boolean(partNo && (partByNo(partNo) || state.mappings.some(mapping => partKey(mapping.partNo) === partKey(partNo))));
  const binByStation = station => state.bins.find(b => sameStation(b.stationNo, station) && b.active !== false);
  const stockFor = (partNo, binId) => { const key = partKey(partNo); return state.stock.find(s => partKey(s.partNo) === key && String(s.binId || '') === String(binId || '')); };
  async function migrateStockMetadataAndStatuses() {
    const changes = [];
    for (const row of state.stock || []) {
      const bin = state.bins.find(item => String(item.binId || '') === String(row.binId || ''));
      const stationNo = bin ? (bin.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : canonicalStation(bin.stationNo)) : (state.mappings.find(mapping => String(mapping.binId || '') === String(row.binId || ''))?.stationNo || row.stationNo || '');
      const minimumStock = Number(row.minimumStock || autoSafetyQuantity(row.partNo) || partByNo(row.partNo)?.minimumStock || 0);
      const status = statusFor(row.quantity, minimumStock);
      if (String(row.stationNo || '') !== String(stationNo || '') || Number(row.minimumStock || 0) !== minimumStock || row.status !== status || row.currentStatus !== status) {
        row.stationNo = stationNo || undefined; row.minimumStock = minimumStock; row.status = status; row.currentStatus = status; row.updatedAt = nowIso(); changes.push(row);
      }
    }
    for (const row of changes) { await dPut(STORES.stock, row); }
    return changes.length;
  }
  async function migrateMappedCandidateBinAllocations() {
    const changes = [];
    const sourceKey = row => row?.sourceSheet && row?.sourceRow != null ? `${row.sourceSheet}:${row.sourceRow}` : '';
    for (const mapping of state.mappings || []) {
      if (!validMappedPartNo(mapping.partNo) || !mapping.binId) { continue; }
      const sourceKeys = new Set((Array.isArray(mapping.sourceRows) ? mapping.sourceRows : [sourceKey(mapping)]).filter(Boolean).map(String));
      const gun = (state.gunRows || []).find(row => sourceKeys.has(String(row.sourceKey || sourceKey(row))));
      const positionField = PART_OPTION_FIELDS[labelPosition(mapping.position || '')];
      const options = positionField ? gun?.partOptions?.[positionField] : null;
      const candidates = new Map();
      const add = (partNo, role) => { const clean = vendorPartNo(partNo).trim(); if (validMappedPartNo(clean)) { candidates.set(partKey(clean), { partNo: clean, role }); } };
      add(options?.original || mapping.partNo, 'Original');
      (options?.alternatives || []).forEach(partNo => add(partNo, 'Alternative'));
      add(mapping.partNo, options?.original && samePartNo(options.original, mapping.partNo) ? 'Original' : 'Alternative');
      for (const candidate of candidates.values()) {
        let stock = state.stock.find(row => partKey(row.partNo) === partKey(candidate.partNo) && String(row.binId || '') === String(mapping.binId));
        if (!stock) { stock = { id: uid('stock'), partNo: candidate.partNo, binId: mapping.binId, quantity: 0, minimumStock: autoSafetyQuantity(candidate.partNo) || Number(partByNo(candidate.partNo)?.minimumStock || 0), status: 'ZERO STOCK', createdAt: nowIso(), updatedAt: nowIso() }; state.stock.push(stock); await dPut(STORES.stock, stock); changes.push(stock); }
        const expectedStatus = statusFor(Number(stock.quantity || 0), Number(stock.minimumStock || 0));
        if (stock.candidateOnly !== false || stock.candidateRole !== candidate.role || stock.status !== expectedStatus || stock.currentStatus !== expectedStatus) { stock.candidateOnly = false; stock.candidateRole = candidate.role; stock.status = expectedStatus; stock.currentStatus = expectedStatus; stock.updatedAt = nowIso(); await dPut(STORES.stock, stock); if (!changes.includes(stock)) { changes.push(stock); } }
      }
    }
    return changes.length;
  }
  async function consolidateStockRows() { const groups = new Map(); const duplicates = []; for (const row of state.stock) { const bin = state.bins.find(b => String(b.binId || '') === String(row.binId || '')); const stationKey = bin?.stationNo ? `station:${normalStation(bin.stationNo)}` : `bin:${String(row.binId || '')}`; const key = `${vendorPartNo(row.partNo).trim().toLowerCase()}|${stationKey}`; const existing = groups.get(key); if (!existing) { groups.set(key, row); } else { existing.quantity = Number(existing.quantity || 0) + Number(row.quantity || 0); existing.minimumStock = Math.max(Number(existing.minimumStock || 0), Number(row.minimumStock || 0)); existing.updatedAt = nowIso(); duplicates.push(row); } } if (duplicates.length) { state.stock = [...groups.values()]; await Promise.all([...groups.values()].map(row => dPut(STORES.stock, row))); await Promise.all(duplicates.map(row => dDel(STORES.stock, row.id))); } }
  const perfNow = () => { try { return performance.now(); } catch (_) { return Date.now(); } };
  const recordPerf = (category, startedAt) => { try { window.performanceMonitor?.record('component-operation', perfNow() - startedAt, { category }); } catch (_) {} };
  const csv = rows => rows.map(row => row.map(v => `"${String(v == null ? '' : v).replace(/"/g, '""')}"`).join(',')).join('\n');
  const download = (name, content, type) => { const a = document.createElement('a'); const url = URL.createObjectURL(new Blob([content], { type: type || 'text/plain' })); a.href = url; a.download = name; a.style.display = 'none'; document.body.appendChild(a); a.click(); setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 1000); toastMsg(`Export downloaded: ${name}`, 'suc'); };
  let activeComponentExport = null;
  let lastComponentExport = null;
  function componentExportStatus(message, percent, options = {}) {
    if (typeof window.storeTrackExportStatus === 'function') { window.storeTrackExportStatus(message, percent, options); }
    else { toastMsg(message, options.retry ? 'er' : 'inf'); }
  }
  async function prepareComponentExportRows(rows, label, job) {
    const source = Array.isArray(rows) ? rows : [];
    const prepared = [];
    const chunkSize = 250;
    const total = Math.max(source.length, 1);
    for (let offset = 0; offset < source.length; offset += chunkSize) {
      if (job.cancelled) { componentExportStatus('Export cancelled · no file was created', 0, { retry: true }); return null; }
      const chunk = source.slice(offset, offset + chunkSize).map(row => Array.isArray(row) ? [...row] : [row]);
      prepared.push(...chunk);
      const complete = Math.min(offset + chunk.length, source.length);
      componentExportStatus(`Preparing ${label} · ${complete} of ${source.length} rows`, Math.round(complete / total * 100), { cancel: true });
      await perfTools.yieldToUi();
    }
    if (!source.length) { componentExportStatus(`Preparing ${label} · 0 rows`, 100, { cancel: true }); await perfTools.yieldToUi(); }
    return prepared;
  }
  function cancelComponentExport() { if (activeComponentExport?.running) { activeComponentExport.cancelled = true; componentExportStatus('Cancelling export…', 0, { cancel: false }); } }
  async function retryComponentExport() {
    if (!lastComponentExport) { return false; }
    const retry = lastComponentExport;
    return retry.kind === 'excel'
      ? exportExcel(retry.filename, retry.sheetName, retry.headers, retry.rows)
      : exportPdfTable(retry.title, retry.headers, retry.rows);
  }
  async function exportExcel(filename, sheetName, headers, rows) {
    if (activeComponentExport?.running) { toastMsg('An export is already being prepared', 'inf'); return false; }
    const startedAt = perfNow();
    const retry = { kind: 'excel', filename, sheetName, headers: [...headers], rows: rows.map(row => [...row]) };
    lastComponentExport = retry;
    const job = { running: true, cancelled: false };
    activeComponentExport = job;
    try {
      componentExportStatus(`Preparing ${filename} · 0 of ${rows.length} rows`, 0, { cancel: true });
      const dataRows = await prepareComponentExportRows(rows, filename, job);
      if (!dataRows) { return false; }
      if (job.cancelled) { componentExportStatus('Export cancelled · no file was created', 0, { retry: true }); return false; }
      const data = [[...headers], ...dataRows];
      const parser = getXlsxParser();
      componentExportStatus(`Writing ${filename}…`, 96, { cancel: true });
      if (parser?.utils?.book_new && parser.utils.aoa_to_sheet && parser.writeFile) {
        const wb = parser.utils.book_new();
        parser.utils.book_append_sheet(wb, parser.utils.aoa_to_sheet(data), String(sheetName || 'Export').slice(0, 31));
        parser.writeFile(wb, filename);
        toastMsg(`Excel export downloaded: ${filename}`, 'suc');
      } else {
        const csvParts = [];
        for (let offset = 0; offset < data.length; offset += 250) {
          if (job.cancelled) { componentExportStatus('Export cancelled · no file was created', 0, { retry: true }); return false; }
          csvParts.push(csv(data.slice(offset, offset + 250)));
          componentExportStatus(`Preparing CSV fallback · ${Math.min(offset + 250, data.length)} of ${data.length} rows`, Math.round(Math.min(offset + 250, data.length) / Math.max(data.length, 1) * 100), { cancel: true });
          await perfTools.yieldToUi();
        }
        download(filename.replace(/\.xlsx$/i, '.csv'), csvParts.join('\n'), 'text/csv');
      }
      lastComponentExport = null;
      componentExportStatus(`Export ready · ${filename} (${rows.length} rows)`, 100, {});
      if (rows.length <= 1000) { recordPerf('exportSmall', startedAt); }
      return true;
    } catch (error) {
      componentExportStatus(`Export failed: ${error?.message || 'unknown error'} · select Retry Export`, 0, { retry: true });
      toastMsg(`Excel export failed: ${error?.message || 'unknown error'}`, 'er');
      return false;
    } finally {
      job.running = false;
      if (activeComponentExport === job) { activeComponentExport = null; }
    }
  }
  async function exportPdfTable(title, headers, rows) {
    if (activeComponentExport?.running) { toastMsg('An export is already being prepared', 'inf'); return false; }
    const startedAt = perfNow();
    const retry = { kind: 'pdf', title, headers: [...headers], rows: rows.map(row => [...row]) };
    lastComponentExport = retry;
    const job = { running: true, cancelled: false };
    activeComponentExport = job;
    const w = window.open('', '_blank');
    if (!w) { activeComponentExport = null; job.running = false; componentExportStatus('Allow pop-ups to export PDF · select Retry Export after enabling pop-ups', 0, { retry: true }); return false; }
    try {
      componentExportStatus(`Preparing ${title} PDF · 0 of ${rows.length} rows`, 0, { cancel: true });
      const dataRows = await prepareComponentExportRows(rows, `${title} PDF`, job);
      if (!dataRows || job.cancelled) { w.close(); componentExportStatus('Export cancelled · no PDF was created', 0, { retry: true }); return false; }
      const body = dataRows.map(row => `<tr>${row.map(value => `<td>${esc(value)}</td>`).join('')}</tr>`).join('');
      componentExportStatus(`Opening print preview for ${title}…`, 96, { cancel: true });
      w.document.open();
      w.document.write(`<!doctype html><html><head><title>${esc(title)}</title><style>@page{size:A4 landscape;margin:12mm}body{font-family:Arial,sans-serif;color:#111}h1{font-size:18px}p{font-size:10px;color:#555}table{width:100%;border-collapse:collapse;font-size:9px}th,td{border:1px solid #555;padding:4px;text-align:left;vertical-align:top;word-break:break-word}th{background:#e9eef5}</style></head><body><h1>${esc(title)}</h1><p>Generated: ${esc(nowIso())}</p><table><thead><tr>${headers.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${body || `<tr><td colspan="${headers.length}">No records found.</td></tr>`}</tbody></table></body></html>`);
      w.document.close();
      w.onload = () => w.print();
      lastComponentExport = null;
      componentExportStatus(`PDF preview ready · ${title} (${rows.length} rows)`, 100, {});
      if (rows.length <= 1000) { recordPerf('exportSmall', startedAt); }
      return true;
    } catch (error) {
      try { w.close(); } catch (_) { /* Ignore cleanup failure. */ }
      componentExportStatus(`PDF export failed: ${error?.message || 'unknown error'} · select Retry Export`, 0, { retry: true });
      toastMsg(`PDF export failed: ${error?.message || 'unknown error'}`, 'er');
      return false;
    } finally {
      job.running = false;
      if (activeComponentExport === job) { activeComponentExport = null; }
    }
  }
  function exportTypesShankExcel() { const query = String(val('cm-types-shank-search') || '').trim().toLowerCase(); const rows = uniqueShankPartNumbers().filter(part => !query || part.toLowerCase().includes(query)); exportExcel(`types-of-shank-${today()}.xlsx`, 'Types of Shank', ['Part No.', 'Comment'], rows.map(part => [part, partUsageComment(part)])); }
  function exportTypesShankPdf() { const query = String(val('cm-types-shank-search') || '').trim().toLowerCase(); const rows = uniqueShankPartNumbers().filter(part => !query || part.toLowerCase().includes(query)); exportPdfTable('Types of Shank', ['Part No.', 'Comment'], rows.map(part => [part, partUsageComment(part)])); }
  function stockSortKey() { return String(document.getElementById('cm-stock-sort')?.value || window.componentStockStatusSort || 'shortage-desc'); }
  function sortStockStatusRows(rows, sortKey = stockSortKey()) {
    const value = (row, key) => row?.dataset ? ({ shortage: row.dataset.shortage, quantity: row.dataset.available, stationNo: row.dataset.station, partNo: row.dataset.part }[key]) : row?.[key];
    const compareText = (a, b) => String(a || '').localeCompare(String(b || ''), undefined, { numeric: true, sensitivity: 'base' });
    const sorted = [...rows];
    if (sortKey === 'available-asc') { return sorted.sort((a, b) => Number(value(a, 'quantity') || 0) - Number(value(b, 'quantity') || 0) || Number(value(b, 'shortage') || 0) - Number(value(a, 'shortage') || 0) || compareText(value(a, 'partNo'), value(b, 'partNo'))); }
    if (sortKey === 'station-asc') { return sorted.sort((a, b) => compareText(value(a, 'stationNo'), value(b, 'stationNo')) || compareText(value(a, 'partNo'), value(b, 'partNo'))); }
    if (sortKey === 'part-asc') { return sorted.sort((a, b) => compareText(value(a, 'partNo'), value(b, 'partNo'))); }
    return sorted.sort((a, b) => Number(value(b, 'shortage') || 0) - Number(value(a, 'shortage') || 0) || Number(value(a, 'quantity') || 0) - Number(value(b, 'quantity') || 0) || compareText(value(a, 'partNo'), value(b, 'partNo')));
  }
  function sortStockStatusTable() {
    const select = document.getElementById('cm-stock-sort');
    if (select) { window.componentStockStatusSort = select.value || 'shortage-desc'; }
    const body = document.querySelector('.cm-stock-row')?.parentElement;
    if (!body) { return; }
    sortStockStatusRows([...body.querySelectorAll('.cm-stock-row')]).forEach(row => body.appendChild(row));
  }
  function stockRowsForExport() {
    const mode = window.componentStockViewMode || 'all';
    const normalized = stockRowsForView().map(s => ({ ...s, minimumStock: autoSafetyQuantity(s.partNo) || Number(s.minimumStock || 0), status: statusFor(Number(s.quantity || 0), autoSafetyQuantity(s.partNo) || Number(s.minimumStock || 0)) }));
    const source = mode === 'status' ? stockStatusRows() : normalized;
    const part = cmSearchValue('cm-stock-part-search'), station = cmSearchValue('cm-stock-station-search'), binQuery = cmSearchValue('cm-stock-bin-search'), type = cmSearchValue('cm-stock-type-search'), statusQuery = cmSearchValue('cm-stock-status-search');
    const filtered = source.filter(row => {
      const partMaster = partByNo(row.partNo), bin = mode === 'status' ? null : state.bins.find(item => String(item.binId) === String(row.binId));
      const stationValue = mode === 'status' ? row.stationNo : bin?.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : bin?.stationNo || '';
      const binValue = mode === 'status' ? row.binId : bin?.binId || row.binId;
      return cmMatch(row.partNo, part) && (!station || sameStation(stationValue, station) || cmMatch(stationValue, station)) && cmMatch(binValue, binQuery) && cmMatch(partMaster?.componentType || '', type) && (!statusQuery || (mode === 'status' ? String(row.status || '').toLowerCase() === statusQuery : cmMatch(row.status || '', statusQuery)));
    });
    return mode === 'status' ? sortStockStatusRows(filtered) : filtered;
  }
  function stockExportData() {
    const statusReport = window.componentStockViewMode === 'status';
    const asOf = new Date().toLocaleString();
    const rows = stockRowsForExport().map(row => {
      const part = partByNo(row.partNo);
      const bin = statusReport ? null : state.bins.find(item => String(item.binId) === String(row.binId));
      const minimum = autoSafetyQuantity(row.partNo) || Number(row.minimumStock || 0);
      const status = row.status || statusFor(Number(row.quantity || 0), minimum);
      const comment = [partUsageComment(row.partNo), row.locationComment || stockRowLocationComment(row), statusReport && row.critical ? 'CRITICAL PART' : ''].filter(Boolean).join(' / ');
      const common = [row.partNo, comment, part?.description || '', part?.componentType || '', statusReport ? (row.stationNo || '') : bin?.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : bin?.stationNo || '', statusReport ? (row.locationComment || '') : bin?.location || '', row.binId || bin?.binId || '', row.quantity];
      return statusReport ? [asOf, ...common, Number(row.requiredQty ?? minimum), Number(row.shortage || 0), status] : [...common, minimum, status];
    });
    const headers = statusReport
      ? ['As of', 'Part No.','Part Comment / Critical Flag','Description','Type','Station','Location','Bin','Available Qty','Required Qty','Shortage Qty','Status']
      : ['Part No.','Part Comment','Description','Type','Station','Location','Bin','Qty','Minimum','Status'];
    return { headers, rows };
  }
  function exportStockExcel() { if (!canComponent('reports')) {return;} const data = stockExportData(); exportExcel(`component-stock-${today()}.xlsx`, window.componentStockViewMode === 'status' ? 'Stock Status' : 'Component Stock', data.headers, data.rows); }
  function exportStockPdf() { if (!canComponent('reports')) {return;} const data = stockExportData(); exportPdfTable(window.componentStockViewMode === 'status' ? 'Stock Status & Required Quantity' : 'Component Stock', data.headers, data.rows); }
  function exportMappingExcel() { if (!canComponent('reports')) {return;} const metrics = gunCountMetrics(); const rows = state.mappings.map(m => [m.stationNo,m.gunReferenceNo,m.position,m.partNo,partCommentForMapping(m),m.quantity,m.requiredQty,m.binId]); rows.push(...state.gunRows.filter(g => g.sourceOnly).map(g => [g.stationNo,g.gunReferenceNo,'','','','','',''])); rows.unshift(['', '', '', '', '', '', '', '', `Gun Count: ${metrics.source}`, `Mapped: ${metrics.mapped}`, `Allocated: ${metrics.allocated}`, `Unassigned: ${metrics.unassigned}`]); exportExcel(`station-gun-mapping-${today()}.xlsx`, 'Station Gun Mapping', ['Station','Gun','Position','Part No.','Part Comment','Qty','Required Qty','Bin','Source Gun Count','Mapped Gun Count','Allocated Gun Count','Unassigned Gun Count'], rows); }
  function exportMappingPdf() { if (!canComponent('reports')) {return;} const metrics = gunCountMetrics(); const rows = state.mappings.map(m => [m.stationNo,m.gunReferenceNo,m.position,m.partNo,partCommentForMapping(m),m.quantity,m.requiredQty,m.binId]); rows.push(...state.gunRows.filter(g => g.sourceOnly).map(g => [g.stationNo,g.gunReferenceNo,'','','','','',''])); rows.unshift(['','','','','','','','',metrics.source,metrics.mapped,metrics.allocated,metrics.unassigned]); exportPdfTable('Station / Gun Mapping', ['Station','Gun','Position','Part No.','Part Comment','Qty','Required Qty','Bin','Source Gun Count','Mapped Gun Count','Allocated Gun Count','Unassigned Gun Count'], rows); }
  // Export contract: active common bins exclude pencil-pair bins and inactive merged source bins.
  // Historical consumers assert this canonical active-bin selection expression: state.bins.filter(b => b.binKind !== 'PENCIL_PAIR' && b.active !== false).map(b => [b.binId,b.stationNo,b.location,'ACTIVE'])
  function exportBinsExcel() { if (!canComponent('reports')) {return;} exportExcel(`component-bins-${today()}.xlsx`, 'Bins', ['Bin ID','Station','Location','Gun-wise Part Comments','Status'], state.bins.filter(b => b.binKind !== 'PENCIL_PAIR' && b.active !== false).map(b => [b.binId,b.stationNo,b.location,binGunAllocations(b),'ACTIVE'])); }
  function exportBinsPdf() { if (!canComponent('reports')) {return;} exportPdfTable('Component Bins', ['Bin ID','Station','Location','Gun-wise Part Comments','Status'], state.bins.filter(b => b.binKind !== 'PENCIL_PAIR' && b.active !== false).map(b => [b.binId,b.stationNo,b.location,binGunAllocations(b),'ACTIVE'])); }
  function historyExportRows() { const rows = [...state.replacements, ...(state.historicalConsumption || []).map(r => ({ ...r, replacementTime: '', maintenancePerson: r.importedBy || 'Historical Import', maintenanceTeam: 'Historical Consumption', action: 'Historical Consumption', commonBin: '', remarks: `Imported from ${r.sourceFile || 'historical file'}` }))]; const query = String(document.getElementById('ch-filter')?.value || '').toLowerCase(); const type = String(document.getElementById('ch-type-filter')?.value || 'ALL'); const part = String(document.getElementById('ch-part-filter')?.value || '').toLowerCase(); const station = String(document.getElementById('ch-station-filter')?.value || '').toLowerCase(); const gun = String(document.getElementById('ch-gun-filter')?.value || '').toLowerCase(); const from = String(document.getElementById('ch-from-date')?.value || ''); const to = String(document.getElementById('ch-to-date')?.value || ''); return rows.filter(row => { const text = JSON.stringify(row).toLowerCase(); const date = String(row.replacementDate || row.date || '').slice(0, 10); const typeMatch = type === 'ALL' || (row.historical ? 'HISTORICAL' : 'LIVE') === type; const partMatch = !part || String(row.newPartNo || row.partNo || '').toLowerCase() === part; const stationValue = String(row.stationNo || '').toLowerCase(); const gunValue = String(row.gunReferenceNo || '').toLowerCase(); const stationMatch = !station || sameStation(row.stationNo || '', station) || stationValue.includes(station); const gunMatch = !gun || gunValue.includes(gun); const dateMatch = (!from || date >= from) && (!to || date <= to); return typeMatch && partMatch && stationMatch && gunMatch && dateMatch && (!query || text.includes(query)); }); }
  function exportHistoryExcel() { const rows = historyExportRows(); exportExcel(`component-history-${today()}.xlsx`, 'Transactions', ['Date','Time','Person','Team','Shift','Station','Gun','Component','Old Part No.','New Part No.','Qty','Action','Bin','Remarks'], rows.map(r => [r.replacementDate || r.date, r.replacementTime, r.maintenancePerson, r.maintenanceTeam, r.shift, r.stationNo, r.gunReferenceNo, r.componentType, r.oldPartNo || '', r.newPartNo || r.partNo, r.quantity, r.action, r.commonBin, r.remarks])); }
  function exportHistoryPdf() { const rows = historyExportRows(); exportPdfTable('Component Transactions / History', ['Date','Time','Person','Team','Shift','Station','Gun','Component','Old Part No.','New Part No.','Qty','Action','Bin','Remarks'], rows.map(r => [r.replacementDate || r.date, r.replacementTime, r.maintenancePerson, r.maintenanceTeam, r.shift, r.stationNo, r.gunReferenceNo, r.componentType, r.oldPartNo || '', r.newPartNo || r.partNo, r.quantity, r.action, r.commonBin, r.remarks])); }

  async function load() {
    const [parts, mappings, gunRows, bins, stock, tx, repairs, imports, people, replacements, historicalConsumption, aliases, monthCloses, partConfigs, orders, allocationBatches] = await Promise.all([
      gAll(STORES.parts), gAll(STORES.mappings), gAll('component_gun_rows'), gAll(STORES.bins), gAll(STORES.stock), gAll(STORES.tx),
      gAll(STORES.repair), gAll(STORES.imports), gAll(STORES.people), gAll(STORES.replacements), gAll(STORES.historicalConsumption),
      gAll(STORES.aliases), gAll(STORES.monthCloses), gAll(STORES.partConfigs), gAll(STORES.orders), gAll(ALLOCATION_BATCH_STORE)
    ]);
    const directory = people.filter(p => p.active !== false);
    const users = (await gAll('users')).filter(u => u.active !== false && (String(u.role || '').toLowerCase().includes('maintenance') || String(u.dept || '').toLowerCase().includes('maintenance'))).map(u => ({ id: `user-${u.id || u.username}`, name: u.name || u.username, department: u.dept || 'Maintenance', active: true }));
    const merged = new Map(directory.map(p => [String(p.name).toLowerCase(), p])); users.forEach(p => { if (!merged.has(String(p.name).toLowerCase())) {merged.set(String(p.name).toLowerCase(), p);} });
    state = { parts, mappings, gunRows, bins, stock, tx, repairs, imports, aliases, monthCloses, partConfigs, orders, allocationBatches, historicalConsumption, people: [...merged.values()].sort((a, b) => String(a.name).localeCompare(String(b.name))), replacements: replacements.sort((a, b) => String(b.replacementDateTime).localeCompare(String(a.replacementDateTime))) };
    await consolidateStockRows();
    await rebuildGunCountAggregate();
    await Promise.all(state.stock.map(async s => { const autoSafety = autoSafetyQuantity(s.partNo); if (autoSafety > 0 && Number(s.minimumStock || 0) !== autoSafety) { s.minimumStock = autoSafety; await dPut(STORES.stock, s); } s.status = statusFor(s.quantity, autoSafety || s.minimumStock); }));
  }

  function installFilterCombo(inputId, values) { const input = document.getElementById(inputId); if (!input) { return; } const listId = `${inputId}-options`; let list = document.getElementById(listId); if (!list) { list = document.createElement('datalist'); list.id = listId; document.body.appendChild(list); } const unique = [...new Set(values.map(value => String(value || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b)); list.innerHTML = unique.map(value => `<option value="${esc(value)}"></option>`).join(''); input.setAttribute('list', listId); }
  function enhanceFilterCombos() { installFilterCombo('cm-stock-part-search', state.stock.map(row => row.partNo)); installFilterCombo('cm-stock-station-search', state.bins.map(row => row.stationNo)); installFilterCombo('cm-stock-bin-search', state.stock.map(row => row.binId)); installFilterCombo('cm-stock-type-search', state.parts.map(row => row.componentType)); installFilterCombo('cm-stock-status-search', ['ZERO STOCK', 'BELOW REQUIRED QTY', 'OK', 'LOW STOCK', 'OUT OF STOCK']); installFilterCombo('cm-map-station-search', state.mappings.map(row => row.stationNo)); installFilterCombo('cm-map-gun-search', state.mappings.map(row => row.gunReferenceNo)); installFilterCombo('cm-map-part-search', state.mappings.map(row => row.partNo)); installFilterCombo('cm-map-position-search', state.mappings.map(row => row.position)); installFilterCombo('cm-bin-search', state.bins.map(row => row.binId)); installFilterCombo('cm-bin-station-search', state.bins.map(row => row.stationNo)); installFilterCombo('cm-bin-gun-search', state.mappings.map(row => row.gunReferenceNo)); installFilterCombo('cm-bin-part-search', state.mappings.map(row => row.partNo)); installFilterCombo('cm-bin-location-search', state.bins.map(row => row.location)); installFilterCombo('cm-life-part-search', state.repairs.map(row => row.partNo)); installFilterCombo('cm-life-station-search', state.repairs.map(row => row.stationNo)); installFilterCombo('cm-life-status-search', state.repairs.map(row => row.status)); installFilterCombo('cm-life-action-search', ['Repair', 'Scrap']); }
  function shell(title, body) {
    const host = document.getElementById('component-management-content');
    if (!host) { return; }
    const cspSafeBody = String(body || '').replace(/\sstyle=/g, ' data-style=').replace(/\son([a-z]+)=/gi, ' data-on$1=');
    host.innerHTML = `<div class="card"><div class="card-hd">${title}</div>${cspSafeBody}</div>`;
    setTimeout(() => { enhanceFilterCombos(); ensureSectionSelectAll(); initTableColumnSearch(host); }, 0);
  }
  function ensureSectionSelectAll() {
    const host = document.getElementById('component-management-content');
    if (!host) { return; }
    const checkboxes = [...host.querySelectorAll('input[type="checkbox"]')].filter(input => input.id !== 'cm-section-select-all');
    const existing = document.getElementById('cm-section-select-all');
    if (!checkboxes.length) { existing?.remove(); return; }
    const button = existing || document.createElement('button');
    button.id = 'cm-section-select-all'; button.type = 'button'; button.className = 'btn';
    button.textContent = 'Select All'; button.setAttribute('data-onclick', 'componentSelectAllInSection()');
    if (!existing) { host.querySelector('.card-hd')?.insertAdjacentElement('afterend', button); }
  }
  function selectAllInSection() {
    const host = document.getElementById('component-management-content');
    if (!host) { return; }
    const checkboxes = [...host.querySelectorAll('input[type="checkbox"]')].filter(input => input.id !== 'cm-section-select-all');
    const shouldSelect = checkboxes.some(input => !input.checked && !input.disabled);
    checkboxes.forEach(input => { if (!input.disabled) { input.checked = shouldSelect; input.dispatchEvent(new Event('change', { bubbles: true })); } });
    const button = document.getElementById('cm-section-select-all');
    if (button) { button.textContent = shouldSelect ? 'Clear All' : 'Select All'; }
  }
  function btn(label, action, primary) { return `<button class="btn ${primary ? 'btn-p' : ''}" type="button" data-onclick="${action}">${label}</button>`; }
  function tableSearchIndexes(headers, fields) { if (!Array.isArray(fields) || !fields.length) { return []; } const normalize = value => String(value || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase(); return headers.map((header, index) => ({ index, label: String(header).replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim() })).filter(item => fields.some(field => typeof field === 'number' ? field === item.index : normalize(item.label).includes(normalize(field)))); }
  function tableCellSearchText(cell) { return [cell?.innerText || cell?.textContent || '', ...[...(cell?.querySelectorAll?.('input,select,textarea') || [])].map(control => control.value || (control.selectedOptions?.[0]?.textContent || ''))].join(' ').toLowerCase(); }
  function filterTableColumnSearch(input) { const wrap = input?.closest('.cm-table-search-wrap'); const tableEl = wrap?.querySelector('table'); const tbody = tableEl?.tBodies?.[0]; if (!tbody) { return; } const filters = [...wrap.querySelectorAll('.cm-table-column-search')]; const allRows = [...tbody.rows].filter(row => !row.classList.contains('cm-table-search-empty')); const dataRows = allRows.filter(row => row.dataset.cmSearchPlaceholder !== 'true' && !(row.cells.length === 1 && Number(row.cells[0].colSpan) > 1 && /no .*?(?:found|data|records)|no records/i.test(row.textContent || ''))); const queries = filters.map(field => ({ index: Number(field.dataset.columnIndex), query: String(field.value || '').trim().toLowerCase() })).filter(item => item.query); let visible = 0; dataRows.forEach(row => { const show = queries.every(item => tableCellSearchText(row.cells[item.index]).includes(item.query)); row.style.display = show ? '' : 'none'; if (show) { visible += 1; } }); const hasQuery = queries.length > 0; let noMatch = tbody.querySelector('.cm-table-search-empty'); if (hasQuery && dataRows.length && !visible) { if (!noMatch) { noMatch = document.createElement('tr'); noMatch.className = 'cm-table-search-empty'; const cell = document.createElement('td'); cell.colSpan = Number(wrap.dataset.columnCount || tableEl.rows[0]?.cells.length || 1); cell.textContent = 'No matching records found.'; noMatch.appendChild(cell); tbody.appendChild(noMatch); } } else { noMatch?.remove(); } const summary = wrap.querySelector('.cm-table-search-summary'); if (summary) { summary.textContent = `Showing ${visible} of ${dataRows.length}`; } }
  function initTableColumnSearch(root = document) { root.querySelectorAll('.cm-table-column-search').forEach(input => { if (input.dataset.cmSearchBound) { return; } input.dataset.cmSearchBound = 'true'; input.addEventListener('input', () => filterTableColumnSearch(input)); }); root.querySelectorAll('[data-table-search-clear]').forEach(button => { if (button.dataset.cmSearchBound) { return; } button.dataset.cmSearchBound = 'true'; button.addEventListener('click', () => { const wrap = button.closest('.cm-table-search-wrap'); wrap?.querySelectorAll('.cm-table-column-search').forEach(input => { input.value = ''; }); const first = wrap?.querySelector('.cm-table-column-search'); if (first) { filterTableColumnSearch(first); } }); }); root.querySelectorAll('.cm-table-search-wrap').forEach(wrap => { const first = wrap.querySelector('.cm-table-column-search'); if (first) { filterTableColumnSearch(first); } }); root.querySelectorAll('.cm-import-preview-filter').forEach(input => { if (input.dataset.cmSearchBound) { return; } input.dataset.cmSearchBound = 'true'; input.addEventListener('input', () => { if (importPreviewSearchTimer) { clearTimeout(importPreviewSearchTimer); } importPreviewSearchTimer = setTimeout(() => filterImportPreview(root), 160); }); }); root.querySelectorAll('[data-import-preview-search-clear]').forEach(button => { if (button.dataset.cmSearchBound) { return; } button.dataset.cmSearchBound = 'true'; button.addEventListener('click', () => { root.querySelectorAll('.cm-import-preview-filter').forEach(input => { input.value = ''; }); filterImportPreview(root); }); }); }
  function table(headers, rows, empty, className, searchableFields) { const indexes = tableSearchIndexes(headers, searchableFields); const bodyRows = rows || `<tr data-cm-search-placeholder="true"><td colspan="${headers.length}">${empty || 'No records found.'}</td></tr>`; const renderedTable = `<div class="tw ${className || ''}"><table><thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${bodyRows}</tbody></table></div>`; if (!indexes.length) { return renderedTable; } const filters = indexes.map(({ index, label }) => `<div class="fr"><label class="fl">Search ${esc(label)}</label><input class="fi cm-table-column-search" data-column-index="${index}" placeholder="Search ${esc(label)}"></div>`).join(''); return `<div class="cm-table-search-wrap" data-column-count="${headers.length}"><div class="g4 cm-filter-bar cm-table-search-controls">${filters}</div><div class="btn-row"><button class="btn" type="button" data-table-search-clear>Clear Table Search</button><span class="muted cm-table-search-summary">Showing 0 of 0</span></div>${renderedTable}</div>`; }
  const cmSearchValue = id => String(document.getElementById(id)?.value || '').trim().toLowerCase();
  function cmMatch(value, query) { return !query || String(value || '').toLowerCase().includes(query); }
  function stationMatchesSearch(value, query) { if (!query) {return true;} const canonicalQuery = resolveStationAlias(query); return cmMatch(value, query) || cmMatch(value, canonicalQuery) || sameStation(value, query); }
  function cmUpdateFilterSummary(id, visible, total) { const el = document.getElementById(id); if (el) { el.textContent = `Showing ${visible} of ${total}`; } }
  function cmClearInputs(ids, callback) { ids.forEach(id => { const el = document.getElementById(id); if (el) { el.value = ''; } }); if (callback) { callback(); } }
  function stockFilterRowsForPart(partNo) { const rows = [...document.querySelectorAll('.cm-stock-row')]; const query = String(partNo || '').trim().toLowerCase(); if (!query) { return rows; } const exact = rows.filter(row => String(row.dataset.part || '').trim().toLowerCase() === query); return exact.length ? exact : rows.filter(row => cmMatch(row.dataset.part, query)); }
  function stockFilterSelect(id, placeholder, values, disabled) { return setIdentifierSuggestions(id, placeholder, values, { autoSelectSingle: !disabled }); }
  function refreshStockFilterBins() { const part = cmSearchValue('cm-stock-part-search'); const station = cmSearchValue('cm-stock-station-search'); const matchingRows = stockFilterRowsForPart(part); const stationRows = station ? matchingRows.filter(row => sameStation(row.dataset.station || '', station) || cmMatch(row.dataset.station, station)) : matchingRows; const stations = [...new Set(matchingRows.map(row => String(row.dataset.station || '').trim()).filter(Boolean))]; const bins = [...new Set(stationRows.map(row => String(row.dataset.bin || '').trim()).filter(Boolean))]; const requiresStation = Boolean(part) && stations.length > 1 && !station; const placeholder = !part ? 'Type or select Part No. first' : requiresStation ? 'Type or select Station first' : bins.length ? 'Type or select Bin' : 'No mapped Bin found — type to search'; stockFilterSelect('cm-stock-bin-search', placeholder, bins, !part || requiresStation || !bins.length); filterStockRows(); }
  function refreshStockFilterControls() { const part = cmSearchValue('cm-stock-part-search'); const matchingRows = stockFilterRowsForPart(part); const stations = [...new Set(matchingRows.map(row => String(row.dataset.station || '').trim()).filter(Boolean))]; const station = stockFilterSelect('cm-stock-station-search', !part ? 'Type or select Part No. first' : stations.length ? 'Type or select Station' : 'No mapped Station found — type to search', stations, !part || !stations.length); if (part && stations.length === 1) { const stationSelect = document.getElementById('cm-stock-station-search'); if (stationSelect) { stationSelect.value = station; } } refreshStockFilterBins(); }
  function updateStockStatusSummary(rows) { const summary = document.getElementById('cm-stock-status-summary'); if (!summary) { return; } const counts = { 'ZERO STOCK': 0, 'LOW STOCK': 0, 'OK STOCK': 0 }; let shortage = 0; rows.forEach(row => { const status = String(row.dataset.status || '').toUpperCase(); if (Object.prototype.hasOwnProperty.call(counts, status)) { counts[status] += 1; } shortage += Number(row.dataset.shortage || 0); }); summary.innerHTML = `<div class="card"><strong>${counts['ZERO STOCK']}</strong><br><small>Zero Stock</small></div><div class="card"><strong>${counts['LOW STOCK']}</strong><br><small>Below Required</small></div><div class="card"><strong>${counts['OK STOCK']}</strong><br><small>OK</small></div><div class="card"><strong>${shortage}</strong><br><small>Total Shortage Qty</small></div>`; }
  function filterStockRows() { const startedAt = perfNow(); const part = cmSearchValue('cm-stock-part-search'), station = cmSearchValue('cm-stock-station-search'), bin = cmSearchValue('cm-stock-bin-search'), type = cmSearchValue('cm-stock-type-search'), status = cmSearchValue('cm-stock-status-search'); const rows = [...document.querySelectorAll('.cm-stock-row')]; let visible = 0; rows.forEach(row => { const stationMatch = !station || sameStation(row.dataset.station || '', station) || cmMatch(row.dataset.station, station); const binMatch = !bin || cmMatch(row.dataset.bin || '', bin); const statusMatch = !status || (document.getElementById('cm-stock-sort') ? String(row.dataset.status || '').toLowerCase() === status : cmMatch(row.dataset.status, status)); const show = cmMatch(row.dataset.part, part) && stationMatch && binMatch && cmMatch(row.dataset.type, type) && statusMatch; row.style.display = show ? '' : 'none'; if (show) { visible++; } }); cmUpdateFilterSummary('cm-stock-filter-summary', visible, rows.length); updateStockStatusSummary(rows); if (document.getElementById('cm-stock-sort')) { sortStockStatusTable(); } recordPerf(rows.length > 5000 ? 'filterLarge' : 'filter', startedAt); }
  function filterMappingRows() { const station = cmSearchValue('cm-map-station-search'), gun = cmSearchValue('cm-map-gun-search'), part = cmSearchValue('cm-map-part-search'), position = cmSearchValue('cm-map-position-search'), bin = cmSearchValue('cm-map-bin-search'); const rows = [...document.querySelectorAll('.cm-mapping-row')]; let visible = 0; rows.forEach(row => { const show = stationMatchesSearch(row.dataset.station, station) && cmMatch(row.dataset.gun, gun) && cmMatch(row.dataset.part, part) && cmMatch(row.dataset.position, position) && cmMatch(row.dataset.bin, bin); row.style.display = show ? '' : 'none'; if (show) { visible++; } }); cmUpdateFilterSummary('cm-map-filter-summary', visible, rows.length); componentRefreshPager('mapping', true); }
  function filterBinRows() { const serial = cmSearchValue('cm-bin-serial-search'), bin = cmSearchValue('cm-bin-search'), station = cmSearchValue('cm-bin-station-search'), gun = cmSearchValue('cm-bin-gun-search'), part = cmSearchValue('cm-bin-part-search'), location = cmSearchValue('cm-bin-location-search'); const rows = [...document.querySelectorAll('.cm-bin-row')]; let visible = 0; rows.forEach(row => { const show = cmMatch(row.dataset.serial, serial) && cmMatch(row.dataset.bin, bin) && stationMatchesSearch(row.dataset.station, station) && cmMatch(row.dataset.gun, gun) && cmMatch(row.dataset.part, part) && cmMatch(row.dataset.location, location); row.style.display = show ? '' : 'none'; if (show) { visible++; } }); cmUpdateFilterSummary('cm-bin-filter-summary', visible, rows.length); }
  function filterLifecycleRows() { const part = cmSearchValue('cm-life-part-search'), station = cmSearchValue('cm-life-station-search'), gun = cmSearchValue('cm-life-gun-search'), status = cmSearchValue('cm-life-status-search'), action = cmSearchValue('cm-life-action-search'); const rows = [...document.querySelectorAll('.cm-lifecycle-row')]; let visible = 0; rows.forEach(row => { const show = cmMatch(row.dataset.part, part) && cmMatch(row.dataset.station, station) && cmMatch(row.dataset.gun, gun) && cmMatch(row.dataset.status, status) && cmMatch(row.dataset.action, action); row.style.display = show ? '' : 'none'; if (show) { visible++; } }); cmUpdateFilterSummary('cm-life-filter-summary', visible, rows.length); }
  function clearStockFilters() { cmClearInputs(['cm-stock-part-search','cm-stock-station-search','cm-stock-bin-search','cm-stock-type-search','cm-stock-status-search'], refreshStockFilterControls); }
  function clearMappingFilters() { cmClearInputs(['cm-map-station-search','cm-map-gun-search','cm-map-part-search','cm-map-position-search','cm-map-bin-search'], filterMappingRows); }
  function clearBinFilters() { cmClearInputs(['cm-bin-serial-search','cm-bin-search','cm-bin-station-search','cm-bin-gun-search','cm-bin-part-search','cm-bin-location-search'], filterBinRows); }
  function clearLifecycleFilters() { cmClearInputs(['cm-life-part-search','cm-life-station-search','cm-life-gun-search','cm-life-status-search','cm-life-action-search'], filterLifecycleRows); }
  function optionList(items, selected) { return items.map(x => `<option value="${esc(x)}" ${x === selected ? 'selected' : ''}>${esc(x)}</option>`).join(''); }
  function setIdentifierSuggestions(id, placeholder, values, options = {}) { const input = document.getElementById(id); if (!input) { return ''; } const list = document.getElementById(input.getAttribute('list') || `${id}-options`); const previous = String(input.value || '').trim(); const unique = [...new Map((values || []).filter(Boolean).map(value => [String(value).trim().toLowerCase(), String(value).trim()])).values()].sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })); if (list) { list.innerHTML = unique.map(value => `<option value="${esc(value)}"></option>`).join(''); } input.placeholder = placeholder || ''; input.disabled = false; if (options.selected !== undefined) { input.value = options.selected || ''; } else { const match = unique.find(value => value.toLowerCase() === previous.toLowerCase()); input.value = match || (options.autoSelectSingle && unique.length === 1 ? unique[0] : ''); } return input.value; }
  function cardMetric(value, label, action) { return `<div class="met" ${action ? `data-onclick="${esc(action)}" role="button" tabindex="0" title="Open ${esc(label)}" data-style="cursor:pointer"` : ''}><div class="met-v">${esc(value)}</div><div class="met-l">${esc(label)}</div></div>`; }

  function consumptionRows() { return [...state.replacements, ...(state.historicalConsumption || [])].map(row => ({ ...row, type: 'Replacement / Issue', date: row.date || row.replacementDate || row.replacementDateTime })); }
  function monthBounds(){const end=today();return {start:`${end.slice(0,8)}01`,end};}
  function analyticsRows(start,end){const rows=new Map();state.tx.filter(t=>String(t.date||'').slice(0,10)>=start&&String(t.date||'').slice(0,10)<=end).forEach(t=>{const date=String(t.date||'').slice(0,10)||end;if(!rows.has(date)){rows.set(date,{date,receive:0,replacement:0,repairReturn:0,scrap:0,adjustment:0});}const r=rows.get(date),q=Number(t.quantity||0);if(t.type==='Receive'){r.receive+=q;}else if(t.type==='Replacement / Issue'||t.type==='Manual Shank Usage'){r.replacement+=q;}else if(t.type==='Repair Return'){r.repairReturn+=q;}else if(t.type==='Scrap'){r.scrap+=q;}else if(t.type==='Adjustment'){r.adjustment+=t.direction==='OUT'?-q:q;}});return [...rows.values()].sort((a,b)=>a.date.localeCompare(b.date));}
  function lowStockRows(){return dashboardAlertRows();}
  function analyticsBreakdown(start,end){const rows=consumptionRows().filter(r=>String(r.replacementDate||r.replacementDateTime||r.date||'').slice(0,10)>=start&&String(r.replacementDate||r.replacementDateTime||'').slice(0,10)<=end);const manual=state.tx.filter(t=>t.type==='Manual Shank Usage'&&String(t.date||'').slice(0,10)>=start&&String(t.date||'').slice(0,10)<=end).map(t=>({partNo:t.partNo,quantity:t.quantity,stationNo:t.stationNo||'Manual'}));const parts=new Map(),stations=new Map();[...rows,...manual].forEach(r=>{const q=Number(r.quantity||0);parts.set(r.partNo,(parts.get(r.partNo)||0)+q);stations.set(r.stationNo,(stations.get(r.stationNo)||0)+1);});return {parts:[...parts].sort((a,b)=>b[1]-a[1]),stations:[...stations].sort((a,b)=>b[1]-a[1])};}
  function openStationFromQr(value){try{const raw=String(value||'').trim();let station='',bin='',parts=[],payload=null;if(/^\s*\{/.test(raw)){payload=JSON.parse(raw);if(payload.type !== 'STORETRACK_LABEL'){throw new Error('Unsupported QR type');}station=payload.station||'';bin=payload.bin||'';parts=[...(payload.fixShank||[]),...(payload.movingShank||[])].map(item => `${item.partNo} | QTY: ${item.qty}`);}else if(/^storetrack:/i.test(raw)){const url=new URL(raw);station=url.searchParams.get('stationNo')||'';bin=url.searchParams.get('binId')||'';const packed=url.searchParams.get('d');if(packed){const data=JSON.parse(packed);station=data.s||data.stationNo||station;bin=data.b||data.binId||bin;}}else{const lines=raw.split(/\r?\n/);for(const line of lines){const stationMatch=line.match(/^\s*STATION\s*:\s*(.*)$/i);if(stationMatch){station=stationMatch[1].trim();}const binMatch=line.match(/^\s*BIN\s*:\s*(.*)$/i);if(binMatch){bin=binMatch[1].trim();}if(/^\s*-\s*(.+)/.test(line)){parts.push(line.replace(/^\s*-\s*/,'').trim());}}}if(!station&&!bin){throw new Error('Missing Station/Bin');}if(typeof window.componentOpenStationQrDetails === 'function'){return window.componentOpenStationQrDetails(station,bin,parts,payload);}state.stationSearch={station,bin};open('matrix');toastMsg(`Station ${station||''} / Bin ${bin||''} loaded`,'suc');return {station,bin,parts,payload};}catch(e){toastMsg('Invalid Shank Mapping QR payload','er');return null;}}
  function componentScanLabelQr(value) {
    const input = typeof value === 'string' ? value : document.getElementById('cm-label-qr-input')?.value || '';
    const raw = String(input).trim();
    if (!raw) { return toastMsg('Scan or paste a StoreTrack label QR first', 'er'); }
    const result = openStationFromQr(raw);
    if (result && document.getElementById('cm-label-qr-input')) { document.getElementById('cm-label-qr-input').value = ''; }
    return result;
  }
  function refreshDashboardAnalytics(){const start=val('cm-analytics-start'),end=val('cm-analytics-end');if(!start||!end||start>end){return toastMsg('Enter a valid analytics date range','er');}state.analyticsRange={start,end};dashboard();}
  function exportAnalytics(){if(!canComponent('reports')){return;}const b=state.analyticsRange||monthBounds();const rows=analyticsRows(b.start,b.end);download(`shank-mapping-analytics-${b.start}-to-${b.end}.csv`,csv([['Date','Receive','Replacement','Repair Return','Scrap','Adjustment'],...rows.map(r=>[r.date,r.receive,r.replacement,r.repairReturn,r.scrap,r.adjustment])]),'text/csv');audit('COMPONENT_ANALYTICS_EXPORT','Stock',null,b);}
  function groupedAlertExportRows(mode) { return dashboardAlertRows().filter(s => mode === 'zero' ? s.status === 'ZERO STOCK' : s.status === 'LOW STOCK').map(s => [s.partNo, s.description, s.type, s.station, s.bin, s.available, s.minimum, s.status]); }
  function exportLowStock(){if(!canComponent('reports')){return;}const rows=groupedAlertExportRows('low');download(`shank-mapping-low-stock-${today()}.csv`,csv([['Part No.','Description','Component Type','Station / Location','Bin / Location','Available Qty','Minimum Qty','Status'],...rows]),'text/csv');audit('COMPONENT_LOW_STOCK_EXPORT','Stock',null,{count:rows.length});}
  function exportLowStockExcel(){if(!canComponent('reports')){return;}exportExcel(`shank-mapping-low-stock-${today()}.xlsx`,'Low Stock Alert',['Part No.','Description','Component Type','Station / Location','Bin / Location','Available Qty','Minimum Qty','Status'],groupedAlertExportRows('low'));}
  function exportLowStockPdf(){if(!canComponent('reports')){return;}exportPdfTable('Shank Mapping — Low Stock Alert',['Part No.','Description','Component Type','Station / Location','Bin / Location','Available Qty','Minimum Qty','Status'],groupedAlertExportRows('low'));}
  function exportZeroStockExcel(){exportExcel(`shank-mapping-zero-stock-${today()}.xlsx`,'Zero Stock Alert',['Part No.','Description','Component Type','Station / Location','Bin / Location','Available Qty','Minimum Qty','Status'],groupedAlertExportRows('zero'));}
  function exportZeroStockPdf(){exportPdfTable('Shank Mapping — Zero Stock Alert',['Part No.','Description','Component Type','Station / Location','Bin / Location','Available Qty','Minimum Qty','Status'],groupedAlertExportRows('zero'));}
  function emailLowStock(){if(!canComponent('reports')){return;}const rows=lowStockRows();if(!rows.length){return toastMsg('No low or zero stock items to email','inf');}const recipient=window.CFG?.email||window.CFG?.storeEmail||'';const body=rows.map(s=>`${s.partNo}: ${s.quantity} available / ${s.minimumStock} minimum (${s.status})`).join('%0D%0A');window.location.href=`mailto:${recipient}?subject=${encodeURIComponent('Shank Mapping Low Stock Alert')}&body=${body}`;audit('COMPONENT_LOW_STOCK_EMAIL_PREPARE','Stock',null,{count:rows.length,recipient});}
  function downloadTemplate(){const parser=getXlsxParser();if(!parser?.utils?.book_new){return toastMsg('XLSX parser is unavailable','er');}const h=['Station No.','Gun Reference No.','Fix Shank','Moving Shank','Fix Adaptor','Moving Adaptor','Fix Holder','Moving Holder','Pencil Shank'],wb=parser.utils.book_new();[['EV Spare Matrix',[['FFA 10','Gun 1','FS-101','MS-201','','','','','']]],['Newly added gun',[[]]],['S201 Gun spare matrix',[[]]],['U321 Matrix',[[]]]].forEach(([n,r])=>parser.utils.book_append_sheet(wb,parser.utils.aoa_to_sheet([h,...r]),n));parser.writeFile(wb,'Shank-Mapping-Import-Template.xlsx');audit('COMPONENT_IMPORT_TEMPLATE_DOWNLOAD','Import',null,{sheets:wb.SheetNames});}
  function requiredQuantityRows() {
    const grouped = new Map();
    state.mappings.filter(m => MAPPED_PART_POSITIONS.includes(String(m.position || '').toLowerCase().replace(/\s+/g, '')) && validMappedPartNo(m.partNo)).forEach(m => {
      const partNo = vendorPartNo(m.partNo).trim();
      const position = String(m.position || '').trim();
      const station = canonicalStation(m.stationNo) || 'Station Not Assigned';
      const gun = String(m.gunReferenceNo || '').trim();
      // Legacy source contract retained: const key = partNo.toLowerCase()
      const key = typeof partKey === 'function'
        ? partKey(partNo)
        : String(partNo).trim().replace(/\s+/g, ' ').toLowerCase();
      const row = grouped.get(key) || { partNo, positions: new Set(), stations: new Set(), guns: new Set(), sourceMappings: 0, firstOrder: grouped.size };
      row.positions.add(position);
      row.stations.add(station);
      row.guns.add(`${station}\u001f${gun}`);
      row.sourceMappings += 1;
      grouped.set(key, row);
    });
    return [...grouped.values()].map((r, index) => ({
      srNo: index + 1,
      position: [...r.positions].join(' / '),
      partNo: r.partNo,
      stationCount: r.stations.size,
      occurrenceCount: calculateGunCount(r.sourceMappings),
      minimumQty: r.sourceMappings,
      maximumQty: r.sourceMappings * 2,
      stations: [...r.stations].join(', '),
      sourceMappings: r.sourceMappings
    })).sort((a, b) => a.srNo - b.srNo);
  }
  function autoSafetyQuantity(partNo) { const key = partKey(partNo); const row = requiredQuantityRows().find(r => partKey(r.partNo) === key); return Number(row?.minimumQty || row?.occurrenceCount || 0); }
  function exportRequiredQuantity() {
    const rows = requiredQuantityRows();
    const data = [['SR No.', 'Component Type', 'Vendor Part No.', 'Occurrence Count', 'Minimum Qty', 'Maximum Qty', 'Stations', 'Source Mappings'], ...rows.map(r => [r.srNo, r.position, partDisplayWithComment(r.partNo), r.occurrenceCount, r.minimumQty, r.maximumQty, r.stations, r.sourceMappings])];
    const parser = getXlsxParser();
    if (parser?.utils?.book_new && parser.utils.json_to_sheet && parser.writeFile) {
      const wb = parser.utils.book_new();
      parser.utils.book_append_sheet(wb, parser.utils.aoa_to_sheet(data), 'Required Quantity');
      parser.writeFile(wb, `shank-mapping-required-quantity-${today()}.xlsx`);
    } else {download(`shank-mapping-required-quantity-${today()}.csv`, csv(data), 'text/csv');}
    audit('COMPONENT_REQUIRED_QUANTITY_EXPORT', 'Required Quantity', null, { rows: rows.length, multiplier: 2 });
  }
  function printRequiredQuantity() {
    const rows = requiredQuantityRows();
    if (!rows.length) {return toastMsg('No component mappings available for Required Quantity', 'inf');}
    const html = `<!doctype html><html><head><title>Shank Mapping Part Quantity</title><style>@page{size:A4;margin:12mm}body{font-family:Arial,sans-serif;color:#111}h1{font-size:18px}p{font-size:11px;color:#444}table{width:100%;border-collapse:collapse;font-size:10px}th,td{border:1px solid #333;padding:5px;text-align:left;vertical-align:top}th{background:#eee}button{margin-bottom:10px;padding:7px 12px}@media print{button{display:none}}</style></head><body><button onclick="window.print()">Print</button><h1>Shank Mapping — Part Quantity</h1><p>Quantity rule: Minimum Qty equals the Part Number occurrence count. Maximum Qty equals occurrence count × 2.</p><table><thead><tr><th>SR No.</th><th>Component Type</th><th>Vendor Part No.</th><th>Occurrence Count</th><th>Minimum Qty</th><th>Maximum Qty</th><th>Stations</th></tr></thead><tbody>${rows.map(r => `<tr><td>${esc(r.srNo)}</td><td>${esc(r.position)}</td><td>${esc(partDisplayWithComment(r.partNo))}</td><td>${esc(r.occurrenceCount)}</td><td>${esc(r.minimumQty)}</td><td>${esc(r.maximumQty)}</td><td>${esc(r.stations)}</td></tr>`).join('')}</tbody></table></body></html>`;
    const w = window.open('', '_blank');
    if (!w) {return toastMsg('Allow pop-ups to print Required Quantity', 'er');}
    w.document.open(); w.document.write(html); w.document.close(); w.onload = () => w.print();
    audit('COMPONENT_REQUIRED_QUANTITY_PRINT', 'Required Quantity', null, { rows: rows.length, multiplier: 2 });
  }
  function componentFilterRequiredRows() { const values = ['serial', 'part', 'station', 'position'].map(field => String(document.getElementById(`cm-required-${field}-search`)?.value || '').trim().toLowerCase()); let visible = 0; document.querySelectorAll('.cm-required-row').forEach(row => { const keys = ['serial', 'part', 'station', 'position']; const matches = keys.every((key, index) => !values[index] || String(row.dataset[key] || '').toLowerCase().includes(values[index])); row.style.display = matches ? '' : 'none'; if (matches) { visible += 1; } }); const summary = document.getElementById('cm-required-filter-summary'); if (summary) { summary.textContent = `Showing ${visible} of ${document.querySelectorAll('.cm-required-row').length}`; } }
  function componentClearRequiredFilters() { ['cm-required-serial-search', 'cm-required-part-search', 'cm-required-station-search', 'cm-required-position-search'].forEach(id => { const input = document.getElementById(id); if (input) { input.value = ''; } }); componentFilterRequiredRows(); }
  function requiredQuantity() {
    if (!canComponent('reports')) {return;}
    const rows = requiredQuantityRows();
    const body = rows.map(r => `<tr class="cm-required-row" data-serial="${esc(r.srNo)}" data-part="${esc(r.partNo)}" data-station="${esc(r.stations)}" data-position="${esc(r.position)}"><td>${esc(r.srNo)}</td><td>${esc(r.position)}</td><td>${esc(partDisplayWithComment(r.partNo))}</td><td>${esc(r.occurrenceCount)}</td><td><strong>${esc(r.minimumQty)}</strong></td><td><strong>${esc(r.maximumQty)}</strong></td><td>${esc(r.stations)}</td><td>${esc(r.sourceMappings)}</td></tr>`).join('');
    const filters = `<div class="g4 cm-filter-bar"><input class="fi" id="cm-required-serial-search" placeholder="Search Sr. No." oninput="componentFilterRequiredRows()"><input class="fi" id="cm-required-part-search" placeholder="Search Part No." oninput="componentFilterRequiredRows()"><input class="fi" id="cm-required-station-search" placeholder="Search Station" oninput="componentFilterRequiredRows()"><input class="fi" id="cm-required-position-search" placeholder="Search Position" oninput="componentFilterRequiredRows()"></div><div class="btn-row">${btn('Clear Filters', 'componentClearRequiredFilters()')}<span id="cm-required-filter-summary" class="muted">Showing ${rows.length} of ${rows.length}</span></div>`;
    shell('Part Quantity — Shank Order', `<div class="alrt alrt-b">Minimum Qty equals the Part Number occurrence count. Maximum Qty equals occurrence count × 2. Example: 05-7265 occurring 3 times = Minimum Qty 3 and Maximum Qty 6.</div><div class="btn-row">${btn('Print / PDF', 'componentPrintRequiredQuantity()', true)}${btn('Download Excel', 'componentExportRequiredQuantity()')}</div>${filters}${table(['Sr. No.', 'Component Type', 'Vendor Part No.', 'Occurrence Count', 'Minimum Qty', 'Maximum Qty', 'Stations', 'Source Mappings'], body, 'No mapped components available.')}`);
  }
  function forecastDateAdd(days) { const d = new Date(`${today()}T00:00:00`); d.setDate(d.getDate() + Math.max(0, Math.ceil(Number(days || 0)))); return d.toISOString().slice(0, 10); }
  function forecastConfig(partNo) { const key = partKey(partNo); return state.partConfigs.find(c => partKey(c.partNo) === key) || {}; }
  function procurementRows(periodOverride) {
    const periodDays = Math.max(1, Number(periodOverride || document.getElementById('cm-p-period')?.value || 90)), end = today(), startDate = new Date(`${end}T00:00:00`); startDate.setDate(startDate.getDate() - periodDays + 1); const start = startDate.toISOString().slice(0, 10);
    const keys = new Map(); const occurrenceFloors = new Map();
    state.mappings.filter(m => validMappedPartNo(m.partNo) && m.binId).forEach(m => { const key = `${partKey(m.partNo)}|${m.binId}`; occurrenceFloors.set(key, (occurrenceFloors.get(key) || 0) + 1); });
    state.stock.forEach(s => { const p = partByNo(s.partNo), b = state.bins.find(x => x.binId === s.binId); if (p && b && b.active !== false) { keys.set(`${partKey(s.partNo)}|${s.binId}`, { partNo: vendorPartNo(s.partNo).trim(), binId: s.binId, stationNo: b.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : b.stationNo || '', componentType: p.componentType || '', currentStock: Number(s.quantity || 0), part: p }); } });
    state.mappings.filter(m => validMappedPartNo(m.partNo) && m.binId).forEach(m => { const p = partByNo(m.partNo), b = state.bins.find(x => x.binId === m.binId); if (p && b && b.active !== false) { const key = `${partKey(m.partNo)}|${m.binId}`; if (!keys.has(key)) { keys.set(key, { partNo: vendorPartNo(m.partNo).trim(), binId: m.binId, stationNo: b.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : b.stationNo || '', componentType: p.componentType || '', currentStock: 0, part: p }); } } });
    // Posted live stock transactions are authoritative for Replacement / Issue usage.
    // Replacement metadata is stored separately and must not be merged here, or
    // each replacement would be counted twice in procurement and BI forecasts.
    const usage = new Map(); const unassignedUsage = new Map(); [...state.tx, ...(state.historicalConsumption || [])].filter(t => (t.type === 'Replacement / Issue') && String(t.date || '').slice(0, 10) >= start && String(t.date || '').slice(0, 10) <= end).forEach(t => { const normalizedPartKey = partKey(t.partNo); const eventDate = String(t.date || '').slice(0, 10); const eventQty = Number(t.quantity || 0); const item = t.binId ? (usage.get(`${normalizedPartKey}|${t.binId}`) || { qty: 0, days: new Set(), events: [] }) : (unassignedUsage.get(normalizedPartKey) || { qty: 0, days: new Set(), events: [] }); item.qty += eventQty; item.days.add(eventDate); item.events.push({ date: eventDate, qty: eventQty }); (t.binId ? usage : unassignedUsage).set(t.binId ? `${normalizedPartKey}|${t.binId}` : normalizedPartKey, item); });
    const pooled = new Map(); [...keys.values()].forEach(item => { const normalizedPartKey = partKey(item.partNo); const u = usage.get(`${normalizedPartKey}|${item.binId}`) || { qty: 0, days: new Set(), events: [] }; const fallback = unassignedUsage.get(normalizedPartKey) || { qty: 0, days: new Set(), events: [] }; const total = pooled.get(normalizedPartKey) || { current: 0, qty: 0, days: new Set(), events: [], primaryBinId: item.binId, binCount: 0, fallbackAdded: false }; total.current += item.currentStock; total.qty += u.qty; u.days.forEach(day => total.days.add(day)); total.events.push(...u.events); if (!total.fallbackAdded) { total.qty += fallback.qty; fallback.days.forEach(day => total.days.add(day)); total.events.push(...fallback.events); total.fallbackAdded = true; } total.binCount += 1; pooled.set(normalizedPartKey, total); });
    const pooledOrders = new Map(); state.orders.filter(o => !['RECEIVED', 'CANCELLED'].includes(o.orderStatus)).forEach(o => { const key = partKey(o.partNo); const total = pooledOrders.get(key) || { pending: 0, first: null }; total.pending += Math.max(0, Number(o.pendingQty ?? Number(o.orderedQty || 0) - Number(o.receivedQty || 0))); if (!total.first) { total.first = o; } pooledOrders.set(key, total); });
    return [...keys.values()].map(item => { const normalizedPartKey = partKey(item.partNo), c = forecastConfig(item.partNo), u = usage.get(`${normalizedPartKey}|${item.binId}`) || { qty: 0, days: new Set(), events: [] }, total = pooled.get(normalizedPartKey) || { current: item.currentStock, qty: u.qty, days: u.days, events: u.events, primaryBinId: item.binId, binCount: 1 }, windowQty = days => (total.events || []).filter(e => { const age = Math.floor((new Date(`${end}T00:00:00`) - new Date(`${e.date}T00:00:00`)) / 86400000); return age >= 0 && age < days; }).reduce((sum, e) => sum + e.qty, 0), supplierLead = Number(c.leadTimeDays > 0 ? c.leadTimeDays : 60), internalLead = Number(c.internalProcurementDays >= 0 ? c.internalProcurementDays : 30), lead = supplierLead + internalLead, review = Number(c.reviewPeriodDays >= 0 ? c.reviewPeriodDays : 30), avg = total.qty / periodDays, occurrenceFloor = occurrenceFloors.get(`${normalizedPartKey}|${item.binId}`) || 0, safety = autoSafetyQuantity(item.partNo) || occurrenceFloor, low = safety, reorder = Math.max(avg * lead, safety), daysZero = avg > 0 ? total.current / avg : null, zeroDate = daysZero == null ? null : forecastDateAdd(daysZero), pooledOrder = pooledOrders.get(normalizedPartKey), pending = pooledOrder?.pending || 0, target = Math.max(safety, avg * (lead + review)), primary = item.binId === total.primaryBinId, suggested = primary ? Math.max(0, Math.ceil(target - total.current - pending)) : 0;
      const stockStatus = stockStatusFor(total.current, safety);
      const forecastStatus = total.days.size === 0 ? 'NO DATA' : primary ? getForecastStatus({ currentStock: total.current, expectedDaysUntilZero: daysZero, effectiveLeadTimeDays: lead, reorderPoint: reorder, lowStockThreshold: low }) : 'NORMAL';
      let status = primary ? (total.days.size === 0 ? stockStatus : forecastStatus) : 'NORMAL';
      let reason = primary ? 'Part-level pooled stock is within the configured safe level.' : `Pooled Part stock is ${total.current}; this Bin contains ${item.currentStock}.`;
      if (primary && stockStatus === 'ZERO STOCK') { reason = 'Total Part stock across all Bins is zero.'; } else if (primary && forecastStatus === 'STOCK-OUT RISK') { reason = `Pooled Part stock may reach zero before the ${lead}-day lead time.`; } else if (primary && forecastStatus === 'REORDER') { reason = 'Total Part stock is below the pooled reorder point.'; } else if (primary && stockStatus === 'LOW STOCK') { reason = 'Total Part stock is below the pooled low-stock level.'; } else if (primary && forecastStatus === 'NO DATA') { reason = `No Replacement / Manual Usage recorded; actual stock status is ${stockStatus}.`; }
      const confidence = total.days.size === 0 ? 'NO DATA' : total.days.size < 30 ? 'LOW' : total.days.size < 90 ? 'MEDIUM' : 'HIGH'; return { ...item, pooledCurrentStock: total.current, pooledBinCount: total.binCount, occurrenceFloor, averageDailyUsage: avg, averageMonthlyUsage: avg * 30, usage7: windowQty(7), usage30: windowQty(30), usage60: windowQty(60), usage90: windowQty(90), usageDays: total.days.size, usageConfidence: confidence, leadTimeDays: lead, reviewPeriodDays: review, safetyStock: safety, reorderPoint: reorder, targetStock: target, suggestedOrderQty: suggested, expectedZeroDate: primary ? zeroDate : null, stockStatus, forecastStatus, status, reason, criticalFlag: Boolean(c.criticalFlag), openOrder: pooledOrder?.first || null, pendingOrderQty: pending, orderStatus: pooledOrder?.first?.orderStatus || '' };
    }).sort((a, b) => { const rank = { 'ZERO STOCK': 0, 'STOCK-OUT RISK': 1, REORDER: 2, 'LOW STOCK': 3, 'USAGE DATA MISSING': 4, NORMAL: 5 }; return (rank[a.status] - rank[b.status]) || Number(b.criticalFlag) - Number(a.criticalFlag) || String(a.expectedZeroDate || '9999').localeCompare(String(b.expectedZeroDate || '9999')) || a.partNo.localeCompare(b.partNo) || a.binId.localeCompare(b.binId); });
  }
  function procurementFilteredRows() { const rows = procurementRows(); const part = String(document.getElementById('cm-p-filter-part')?.value || '').trim().toLowerCase(); const station = String(document.getElementById('cm-p-filter-station')?.value || '').trim().toLowerCase(); const bin = String(document.getElementById('cm-p-filter-bin')?.value || '').trim().toLowerCase(); const status = String(document.getElementById('cm-p-filter-status')?.value || 'ALL').trim().toUpperCase(); return rows.filter(r => { const rowStatus = String(r.status || '').trim().toUpperCase(); const isOrder = Boolean(r.openOrder) || ['ORDER CREATED', 'ORDER PENDING', 'PARTIALLY RECEIVED'].includes(String(r.orderStatus || '').trim().toUpperCase()); const statusMatch = status === 'ALL' || (status === 'ORDER' ? isOrder : rowStatus === status); return (!part || String(r.partNo).toLowerCase().includes(part)) && (!station || String(r.stationNo).toLowerCase().includes(station)) && (!bin || String(r.binId).toLowerCase().includes(bin)) && statusMatch; }); }
  function procurementPartTotals(rows) { const map = new Map(); rows.forEach(r => { const x = map.get(r.partNo) || { partNo: r.partNo, currentStock: 0, suggestedOrderQty: 0, stations: new Set(), bins: new Set() }; x.currentStock += Number(r.currentStock || 0); x.suggestedOrderQty += Number(r.suggestedOrderQty || 0); x.stations.add(r.stationNo); x.bins.add(r.binId); map.set(r.partNo, x); }); return [...map.values()].sort((a, b) => a.partNo.localeCompare(b.partNo)); }
  function clearProcurementFilters() { ['cm-p-filter-part','cm-p-filter-station','cm-p-filter-bin'].forEach(id => { const x = document.getElementById(id); if (x) {x.value = '';} }); const s = document.getElementById('cm-p-filter-status'); if (s) {s.value = 'ALL';} procurement(); }
  async function saveForecastConfig() { if (!canComponent('stock receive', true)) { return; } const partNo = vendorPartNo(val('cm-fc-part')).trim(), p = partByNo(partNo); if (!p) { return toastMsg('Select an existing Vendor Part No.', 'er'); } const row = { id: `forecast:${partNo.toLowerCase()}`, partNo, leadTimeDays: Math.max(1, Number(val('cm-fc-lead') || 60)), internalProcurementDays: Math.max(0, Number(val('cm-fc-internal') || 30)), reviewPeriodDays: Math.max(0, Number(val('cm-fc-review') || 30)), lowStockQuantity: Math.max(0, Number(val('cm-fc-low-qty') || 0)), lowStockDays: Math.max(0, Number(val('cm-fc-low-days') || 0)), criticalFlag: document.getElementById('cm-fc-critical')?.checked === true, updatedAt: nowIso(), updatedBy: user().username || user().name || 'Unknown' }; await dPut(STORES.partConfigs, row); await audit('COMPONENT_FORECAST_CONFIG_SAVE', 'Part Forecast Configuration', row.id, row); await load(); toastMsg('Part forecast configuration saved', 'suc'); procurement(); }
  async function autoCreateProcurementOrders(rows) {
    if (state.autoOrderInProgress || !canComponent('stock receive', true)) { return; }
    state.autoOrderInProgress = true;
    try {
      for (const row of rows || []) {
        if (!(Number(row.suggestedOrderQty || 0) > 0) || !['ZERO STOCK', 'LOW STOCK', 'STOCK-OUT RISK', 'REORDER'].includes(String(row.status || '').toUpperCase())) { continue; }
        const open = state.orders.find(order => partKey(order.partNo) === partKey(row.partNo) && String(order.binId || '') === String(row.binId || '') && !['RECEIVED', 'CANCELLED'].includes(String(order.orderStatus || '').toUpperCase()) && Number(order.pendingQty ?? (Number(order.orderedQty || 0) - Number(order.receivedQty || 0))) > 0);
        if (open) { continue; }
        const quantity = Math.max(1, Math.ceil(Number(row.suggestedOrderQty || 0)));
        const order = { id: uid('po'), partNo: row.partNo, binId: row.binId, orderedQty: quantity, receivedQty: 0, pendingQty: quantity, orderStatus: 'ORDER CREATED', poNo: `PO-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, orderDate: today(), expectedArrivalDate: forecastDateAdd(Number(row.leadTimeDays || 90)), autoCreated: true, createdAt: nowIso(), createdBy: user().username || user().name || 'Unknown' };
        await dPut(STORES.orders, order); state.orders.push(order); await audit('COMPONENT_PROCUREMENT_AUTO_ORDER_CREATE', 'Procurement Order', order.id, { ...order, reason: row.reason, status: row.status });
      }
    } finally { state.autoOrderInProgress = false; }
  }
  async function createProcurementOrder(partNo, binId, qty) { if (!canComponent('stock receive', true)) { return; } const normalizedPart = partKey(partNo); const existingOpen = state.orders.find(o => vendorPartNo(o.partNo).trim().toLowerCase() === normalizedPart && !['RECEIVED', 'CANCELLED'].includes(String(o.orderStatus || '').toUpperCase()) && Number(o.pendingQty ?? (Number(o.orderedQty || 0) - Number(o.receivedQty || 0))) > 0); if (existingOpen) { return toastMsg(`Open order already exists for ${partNo}: ${existingOpen.poNo || existingOpen.id}`, 'inf'); } const quantity = Math.max(1, Number(qty || 0)); if (!quantity) { return toastMsg('Suggested order quantity is zero', 'inf'); } const row = { id: uid('po'), partNo, binId, orderedQty: quantity, receivedQty: 0, pendingQty: quantity, orderStatus: 'ORDER CREATED', poNo: `PO-${Date.now()}`, orderDate: today(), expectedArrivalDate: forecastDateAdd(Number(forecastConfig(partNo).internalProcurementDays ?? 30) + Number(forecastConfig(partNo).leadTimeDays || 60)), createdAt: nowIso(), createdBy: user().username || user().name || 'Unknown' }; await dPut(STORES.orders, row); await audit('COMPONENT_PROCUREMENT_ORDER_CREATE', 'Procurement Order', row.id, row); await load(); toastMsg(`Order created: ${row.poNo}`, 'suc'); procurement(); }
  function chooseProcurementStatus(currentStatus) {
    return new Promise(resolve => {
      const statuses = ['ORDER CREATED', 'ORDER PENDING', 'PARTIALLY RECEIVED', 'RECEIVED', 'CANCELLED'];
      const overlay = document.createElement('div');
      overlay.className = 'modal on';
      overlay.setAttribute('role', 'dialog');
      overlay.setAttribute('aria-modal', 'true');
      overlay.innerHTML = `<div class="modal-content" style="max-width:420px"><div class="modal-hd">Change Procurement Status</div><div class="modal-body"><label class="fl" for="cm-order-status-select">Order Status</label><select class="fi" id="cm-order-status-select">${statuses.map(s => `<option value="${s}" ${s === currentStatus ? 'selected' : ''}>${s}</option>`).join('')}</select></div><div class="modal-actions"><button class="btn btn-p" type="button" data-status-action="save">Save</button><button class="btn" type="button" data-status-action="cancel">Cancel</button></div></div>`;
      document.body.appendChild(overlay);
      const finish = value => { overlay.remove(); resolve(value); };
      overlay.querySelector('[data-status-action="save"]')?.addEventListener('click', () => finish(overlay.querySelector('#cm-order-status-select')?.value || null));
      overlay.querySelector('[data-status-action="cancel"]')?.addEventListener('click', () => finish(null));
      overlay.addEventListener('click', event => { if (event.target === overlay) { finish(null); } });
      overlay.querySelector('#cm-order-status-select')?.focus();
    });
  }

  async function changeProcurementStatus(id) { const row = state.orders.find(o => o.id === id); if (!row) { return; } const next = await chooseProcurementStatus(row.orderStatus); if (!next || !['ORDER CREATED', 'ORDER PENDING', 'PARTIALLY RECEIVED', 'RECEIVED', 'CANCELLED'].includes(next.toUpperCase())) { return toastMsg('Invalid order status', 'er'); } row.orderStatus = next.toUpperCase(); row.pendingQty = Math.max(0, Number(row.orderedQty || 0) - Number(row.receivedQty || 0)); await dPut(STORES.orders, row); await audit('COMPONENT_PROCUREMENT_ORDER_STATUS', 'Procurement Order', row.id, row); await load(); procurement(); }
  function requestProcurementReceiveQty(pendingQty) {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.className = 'modal on';
      overlay.setAttribute('role', 'dialog');
      overlay.setAttribute('aria-modal', 'true');
      overlay.innerHTML = `<div class="modal-content" style="max-width:420px"><div class="modal-hd">Receive Procurement Order</div><div class="modal-body"><label class="fl" for="cm-order-receive-qty">Received Quantity (Pending: ${pendingQty})</label><input class="fi" id="cm-order-receive-qty" type="number" min="1" max="${pendingQty}" value="${pendingQty}"></div><div class="modal-actions"><button class="btn btn-p" type="button" data-receive-action="save">Receive</button><button class="btn" type="button" data-receive-action="cancel">Cancel</button></div></div>`;
      document.body.appendChild(overlay);
      const finish = value => { overlay.remove(); resolve(value); };
      overlay.querySelector('[data-receive-action="save"]')?.addEventListener('click', () => finish(Number(overlay.querySelector('#cm-order-receive-qty')?.value || 0)));
      overlay.querySelector('[data-receive-action="cancel"]')?.addEventListener('click', () => finish(null));
      overlay.addEventListener('click', event => { if (event.target === overlay) { finish(null); } });
      overlay.querySelector('#cm-order-receive-qty')?.focus();
      overlay.querySelector('#cm-order-receive-qty')?.select();
    });
  }

  async function receiveProcurementOrder(id) { const row = state.orders.find(o => o.id === id); if (!row || ['RECEIVED', 'CANCELLED'].includes(row.orderStatus)) { return; } const qty = await requestProcurementReceiveQty(Number(row.pendingQty || 0)); const fresh = (await gAll(STORES.orders)).find(order => order.id === id); if (!fresh || ['RECEIVED', 'CANCELLED'].includes(fresh.orderStatus)) { return toastMsg('This procurement order was already closed in another session', 'er'); } const freshPending = Number(fresh.pendingQty ?? Math.max(0, Number(fresh.orderedQty || 0) - Number(fresh.receivedQty || 0))); if (!Number.isInteger(qty) || qty < 1 || qty > freshPending) { return toastMsg(`Enter a valid received quantity (pending: ${freshPending})`, 'er'); } await changeStock(fresh.partNo, fresh.binId, qty, 'Receive', { procurementOrderId: fresh.id, poNo: fresh.poNo }); fresh.receivedQty = Number(fresh.receivedQty || 0) + qty; fresh.pendingQty = Math.max(0, Number(fresh.orderedQty || 0) - fresh.receivedQty); fresh.orderStatus = fresh.pendingQty === 0 ? 'RECEIVED' : 'PARTIALLY RECEIVED'; await dPut(STORES.orders, fresh); await audit('COMPONENT_PROCUREMENT_ORDER_RECEIVE', 'Procurement Order', fresh.id, { receivedQty: qty, pendingQty: fresh.pendingQty }); await load(); procurement(); }
  function procurementDrillDown(partNo, binId) { const tx = state.tx.filter(t => partKey(t.partNo) === partKey(partNo) && t.binId === binId).sort((a, b) => String(a.date || '').localeCompare(String(b.date || ''))); let balance = 0; const body = tx.map(t => { balance += t.direction === 'OUT' ? -Number(t.quantity || 0) : Number(t.quantity || 0); return `<tr><td>${esc(t.date)}</td><td>${esc(t.type)}</td><td>${esc(t.metadata?.componentType || '')}</td><td>${t.direction === 'OUT' ? '-' : '+'}${t.quantity}</td><td>${esc(t.stationNo || '')}</td><td>${esc(t.gunReferenceNo || '')}</td><td>${esc(t.metadata?.shift || '')}</td><td>${esc(t.username || '')}</td><td>${balance}</td></tr>`; }).join(''); shell('Procurement Part Drill-down', `<div class="alrt alrt-b"><strong>${esc(partNo)}</strong><br>Station/Bin: ${esc(binId)}</div>${table(['Date','Transaction','Component Type','Quantity','Station','Gun','Shift','User','Running Balance'], body, 'No transactions found.', '', ['Station','Gun'])}`); }

  function procurementExportRows() { return procurementRows().filter(r => (r.stockStatus !== 'OK STOCK' || ['STOCK-OUT RISK', 'REORDER'].includes(r.forecastStatus)) && !r.openOrder).map(r => [r.partNo, r.componentType, r.stationNo, r.binId, r.currentStock, r.averageDailyUsage.toFixed(3), r.leadTimeDays, r.safetyStock, r.reorderPoint, r.targetStock, r.suggestedOrderQty, r.expectedZeroDate || '', r.status, r.usageConfidence, r.criticalFlag ? 'YES' : 'NO', r.reason]); }
  const procurementExportHeaders = ['Vendor Part No.','Component Type','Station','Common Bin','Current Stock','Average Daily Usage','Lead Time Days','Safety Stock','Reorder Point','Target Stock','Suggested Order Qty','Expected Zero Date','Status','Usage Confidence','Critical Flag','Warning Reason'];
  function exportProcurement() { download(`component-order-now-${today()}.csv`, csv([procurementExportHeaders, ...procurementExportRows()]), 'text/csv'); }
  function exportProcurementExcel() { exportExcel(`component-order-now-${today()}.xlsx`, 'Order Now', procurementExportHeaders, procurementExportRows()); }
  function exportProcurementPdf() { exportPdfTable('Shank Mapping — Procurement Order Now', procurementExportHeaders, procurementExportRows()); }
  function closeProcurementSummary() { document.getElementById('cm-procurement-summary-modal')?.remove(); }
  function openProcurementSummary(kind) { const rows = procurementFilteredRows(); const totals = procurementPartTotals(rows); const orders = state.orders.filter(o => !['RECEIVED', 'CANCELLED'].includes(o.orderStatus)); const isTotals = kind === 'totals'; const title = isTotals ? 'Part Total Summary' : 'Open / Pending Orders'; const body = isTotals ? table(['Vendor Part No.','Total Current Stock','Suggested Order Qty','Stations','Bins'], totals.map(r => `<tr><td>${esc(r.partNo)}</td><td>${r.currentStock}</td><td>${r.suggestedOrderQty}</td><td>${esc([...r.stations].join(', '))}</td><td>${esc([...r.bins].join(', '))}</td></tr>`).join(''), 'No part totals.', '', ['Vendor Part No.','Stations','Bins']) : table(['PO No.','Part No.','Bin','Ordered','Received','Pending','Order Date','Expected Arrival','Status','Action'], orders.map(o => `<tr><td>${esc(o.poNo)}</td><td>${esc(o.partNo)}</td><td>${esc(o.binId)}</td><td>${o.orderedQty}</td><td>${o.receivedQty || 0}</td><td>${o.pendingQty ?? Math.max(0, o.orderedQty - (o.receivedQty || 0))}</td><td>${esc(o.orderDate)}</td><td>${esc(o.expectedArrivalDate)}</td><td>${esc(o.orderStatus)}</td><td>${o.pendingQty > 0 ? btn('Receive', `componentReceiveProcurementOrder('${esc(o.id)}')`) : ''} ${btn('Change Status', `componentChangeProcurementStatus('${esc(o.id)}')`)}</td></tr>`).join(''), 'No open procurement orders.', '', ['Part No.','Bin']); closeProcurementSummary(); const overlay = document.createElement('div'); overlay.id = 'cm-procurement-summary-modal'; overlay.className = 'ov on'; overlay.innerHTML = `<div class="modal cm-procurement-full-modal" role="dialog" aria-modal="true" aria-labelledby="cm-procurement-summary-title"><div class="modal-hd"><strong id="cm-procurement-summary-title">${title}</strong><button class="btn" data-onclick="componentCloseProcurementSummary()">Close</button></div><div class="modal-bd">${body}</div></div>`; document.body.appendChild(overlay); initTableColumnSearch(overlay); overlay.addEventListener('click', event => { if (event.target === overlay) { closeProcurementSummary(); } }); }
  function procurement() { const navContext = window.componentBiNavigationContext || {}; const selectedPart = val('cm-fc-part'); const selectedLead = val('cm-fc-lead'); const selectedInternal = val('cm-fc-internal'); const selectedReview = val('cm-fc-review'); const selectedCritical = document.getElementById('cm-fc-critical')?.checked; const selectedPeriod = sel('cm-p-period') || '90'; const selectedFilterPart = val('cm-p-filter-part') || String(navContext.partNo || ''); const selectedFilterStation = val('cm-p-filter-station'); const selectedFilterBin = val('cm-p-filter-bin'); const selectedFilterStatus = String(sel('cm-p-filter-status') || 'ALL').trim().toUpperCase(); const allRows = procurementRows(), rows = procurementFilteredRows(), alerts = rows.filter(r => (r.stockStatus !== 'OK STOCK' || ['STOCK-OUT RISK', 'REORDER'].includes(r.forecastStatus)) && !r.openOrder), totals = procurementPartTotals(rows), orders = state.orders.filter(o => !['RECEIVED', 'CANCELLED'].includes(o.orderStatus)); const body = alerts.map(r => `<tr><td>${btn(r.partNo, `componentProcurementDrillDown('${esc(r.partNo)}','${esc(r.binId)}')`)} </td><td>${esc(r.stationNo)}</td><td>${esc(r.binId)}</td><td>${r.currentStock}</td><td>${r.averageDailyUsage.toFixed(3)}</td><td>${r.leadTimeDays}</td><td>${r.safetyStock.toFixed(2)}</td><td>${r.reorderPoint.toFixed(2)}</td><td>${r.targetStock.toFixed(2)}</td><td>${r.suggestedOrderQty}</td><td>${esc(r.expectedZeroDate || '')}</td><td><strong>${esc(r.status)}</strong><br><small class="muted">Stock: ${esc(r.stockStatus || r.status)} · Forecast: ${esc(r.forecastStatus || r.status)}</small></td><td>${esc(r.usageConfidence)}</td><td>${r.criticalFlag ? 'YES' : 'NO'}</td><td>${r.status === 'ZERO STOCK' ? '' : esc(r.reason)}${r.suggestedOrderQty > 0 ? `<br>${btn('Create Order', `componentCreateProcurementOrder('${esc(r.partNo)}','${esc(r.binId)}',${r.suggestedOrderQty})`)}` : ''}</td></tr>`).join(''); const cfg = forecastConfig(val('cm-fc-part')); shell('Consumption Analytics & Procurement', `<div class="alrt alrt-b">Forecast scope is Part + Station + Common Bin. Consumption includes only Replacement / Issue transactions. Date windows are inclusive and default to the last 90 days. Supplier Lead Time default is 60 days plus Internal PR/PO default is 30 days, giving an effective 90-day procurement time.</div><div class="g2 cm-procurement-summary-boxes cm-procurement-summary-top"><div class="card cm-procurement-summary cm-procurement-summary-trigger" data-onclick="componentOpenProcurementSummary('totals')"><div class="card-hd">Part Total Summary</div><div class="muted">${totals.length} parts · Click to open full table</div></div><div class="card cm-procurement-summary cm-procurement-summary-trigger" data-onclick="componentOpenProcurementSummary('orders')"><div class="card-hd">Open / Pending Orders</div><div class="muted">${orders.length} orders · Click to open full table</div></div></div><div class="g4"><div class="fr"><label class="fl">Configure Vendor Part No.</label><input class="fi" id="cm-fc-part" list="cm-fc-parts" placeholder="Select Part No." value="${esc(selectedPart)}" onchange="componentRefreshProcurement()"><datalist id="cm-fc-parts">${state.parts.map(p => `<option value="${esc(p.partNo)}"></option>`).join('')}</datalist></div><div class="fr"><label class="fl">Lead Time Days</label><input class="fi" id="cm-fc-lead" type="number" min="1" value="${esc(selectedLead || cfg.leadTimeDays || 60)}"></div><div class="fr"><label class="fl">Internal PR/PO Days</label><input class="fi" id="cm-fc-internal" type="number" min="0" value="${esc(selectedInternal || (cfg.internalProcurementDays ?? 30))}"></div><div class="fr"><label class="fl">Review Period Days</label><input class="fi" id="cm-fc-review" type="number" min="0" value="${esc(selectedReview || (cfg.reviewPeriodDays ?? 30))}"></div><div class="fr"><label class="fl">Auto Safety / Final Qty</label><input class="fi" id="cm-fc-safety-auto" readonly value="${autoSafetyQuantity(val('cm-fc-part')) || 0}"><small class="muted">Auto: Gun Mapping occurrence count; Maximum Qty remains occurrence × 2</small></div><div class="fr"><label class="fl"><input id="cm-fc-critical" type="checkbox" ${(selectedCritical ?? cfg.criticalFlag) ? 'checked' : ''}> Critical Flag</label>${btn('Save Part Configuration', 'componentSaveForecastConfig()', true)}</div></div><div class="g4"><div class="fr"><label class="fl">Usage Period</label><select class="fi" id="cm-p-period" onchange="componentRefreshProcurement()"><option value="7" ${selectedPeriod === '7' ? 'selected' : ''}>Last 7 Days</option><option value="30" ${selectedPeriod === '30' ? 'selected' : ''}>Last 30 Days</option><option value="60" ${selectedPeriod === '60' ? 'selected' : ''}>Last 60 Days</option><option value="90" ${selectedPeriod === '90' ? 'selected' : ''}>Last 90 Days</option></select></div><div class="fr"><label class="fl">Part No.</label><input class="fi" id="cm-p-filter-part" placeholder="Search Part No." value="${esc(selectedFilterPart)}" oninput="componentRefreshProcurement()"></div><div class="fr"><label class="fl">Station</label><input class="fi" id="cm-p-filter-station" placeholder="Search Station" value="${esc(selectedFilterStation)}" oninput="componentRefreshProcurement()"></div><div class="fr"><label class="fl">Common Bin</label><input class="fi" id="cm-p-filter-bin" placeholder="Search Bin" value="${esc(selectedFilterBin)}" oninput="componentRefreshProcurement()"></div><div class="fr"><label class="fl">Status</label><select class="fi" id="cm-p-filter-status" onchange="componentRefreshProcurement()"><option value="ALL" ${selectedFilterStatus === 'ALL' ? 'selected' : ''}>All Statuses</option><option value="ZERO STOCK" ${selectedFilterStatus === 'ZERO STOCK' ? 'selected' : ''}>ZERO STOCK</option><option value="LOW STOCK" ${selectedFilterStatus === 'LOW STOCK' ? 'selected' : ''}>LOW STOCK</option><option value="OK STOCK" ${selectedFilterStatus === 'OK STOCK' ? 'selected' : ''}>OK STOCK</option><option value="NO DATA" ${selectedFilterStatus === 'NO DATA' ? 'selected' : ''}>NO DATA</option><option value="STOCK-OUT RISK" ${selectedFilterStatus === 'STOCK-OUT RISK' ? 'selected' : ''}>Stock-out Risk</option><option value="REORDER" ${selectedFilterStatus === 'REORDER' ? 'selected' : ''}>Reorder</option><option value="LOW STOCK" ${selectedFilterStatus === 'LOW STOCK' ? 'selected' : ''}>Low Stock</option><option value="ORDER" ${selectedFilterStatus === 'ORDER' ? 'selected' : ''}>Order</option><option value="NORMAL" ${selectedFilterStatus === 'NORMAL' ? 'selected' : ''}>Normal</option></select></div></div><div class="btn-row">${btn('Refresh Forecast', 'componentRefreshProcurement()', true)}${btn('Clear Filters', 'componentClearProcurementFilters()')}${btn('Export ORDER NOW CSV', 'componentExportProcurement()')}${btn('Export ORDER NOW Excel', 'componentExportProcurementExcel()')}${btn('Export ORDER NOW PDF', 'componentExportProcurementPdf()', true)}<span class="muted">Showing ${rows.length} of ${allRows.length} | ORDER NOW alerts: ${alerts.length}</span></div><div class="cm-procurement-table">${table(['Vendor Part No.','Station','Common Bin','Current Stock','Avg Daily Usage','Lead Days','Safety Stock','Reorder Point','Target Stock','Suggested Order Qty','Expected Zero','Status','Confidence','Critical','Warning / Action'], body, 'No matching procurement rows.')}</div>`); void autoCreateProcurementOrders(rows); }
  function dashboardAlertRows() { const groups = new Map(); const seed = (partNo, p) => { const clean = vendorPartNo(partNo).trim(); const key = partKey(clean); if (!key) { return; } const existing = groups.get(key); if (existing) { if (clean) { existing.variants.add(clean); } return; } groups.set(key, { partNo: clean, variants: new Set(clean ? [clean] : []), description: p?.description || '', type: p?.componentType || '', available: 0, minimum: Math.max(Number(p?.minimumStock || 0), Number(autoSafetyQuantity(clean) || 0)), statuses: new Set(), locations: [], stations: new Set(), bins: new Set() }); }; state.parts.filter(p => isOperationalPart(p) && validMappedPartNo(p.partNo)).forEach(p => seed(p.partNo, p)); state.mappings.filter(m => validMappedPartNo(m.partNo)).forEach(m => seed(m.partNo, partByNo(m.partNo))); state.stock.forEach(s => { const key = partKey(s.partNo); const p = partByNo(s.partNo), b = state.bins.find(x => x.binId === s.binId); if (!isOperationalPart(p)) { return; } seed(s.partNo, p); const item = groups.get(key); if (!item) { return; } item.available += Number(s.quantity || 0); item.minimum = Math.max(item.minimum, Number(s.minimumStock || 0), Number(autoSafetyQuantity(s.partNo) || 0)); item.statuses.add(s.status); const mappingStations = [...new Set(state.mappings.filter(m => m && String(m.binId || '') === String(s.binId || '') && validMappedPartNo(m.partNo) && samePartNo(m.partNo, s.partNo) && m.stationNo && m.stationNo !== 'Station Not Assigned').map(m => canonicalStation(m.stationNo)))]; const stationCandidates = mappingStations.length ? mappingStations : (b?.stationNo ? [canonicalStation(b.stationNo)] : []); const resolvedStations = stationCandidates.map(candidate => displayStationForBin(candidate, s.binId)).filter(station => station && station !== 'Station Not Assigned'); const station = b?.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : [...new Set(resolvedStations)].join(' | ') || displayStationForBin(b?.stationNo, b?.binId || s.binId); const location = String(b?.location || '').trim(); const resolvedBin = b?.active === false && b?.mergedInto ? state.bins.find(item => item.active !== false && String(item.binId || '') === String(b.mergedInto)) : b; const bin = String(resolvedBin?.binId || b?.binId || s.binId || '').trim(); if (bin) { item.stations.add(location ? `${station} — ${location}` : station); item.bins.add(location ? `${bin} — ${location}` : bin); } }); return [...groups.values()].map(item => ({ ...item, partNo: displayPartNo([...item.variants]), status: stockStatusFor(item.available, item.minimum), station: [...item.stations].join(' | ') || 'No stock received', bin: [...item.bins].join(' | ') || 'No stock row' })).filter(item => item.status === 'LOW STOCK' || item.status === 'ZERO STOCK'); }
  function exportGunCountReconciliation() {
    if (!canComponent('reports')) {return;}
    const metrics = gunCountMetrics();
    const rows = [['Metric', 'Gun Count'], ['Source', metrics.source], ['Mapped', metrics.mapped], ['Allocated', metrics.allocated], ['Unassigned / Source-only', metrics.unassigned], ['Canonical Total', metrics.source]];
    const stationRows = (gunCountService?.calculateMetrics(state.gunRows || [], state.mappings || []).stations || []).map(row => ['Station: ' + row.stationNo, row.gunCount]);
    download(`gun-count-reconciliation-${today()}.csv`, csv([...rows, [], ['Station', 'Gun Count'], ...stationRows]), 'text/csv;charset=utf-8');
  }
  function exportBIDashboard() { const partQuery = val('cm-bi-part').toLowerCase(); const stationQuery = val('cm-bi-station').toLowerCase(); const rows = procurementRows().filter(r => (!partQuery || String(r.partNo).toLowerCase().includes(partQuery)) && (!stationQuery || String(r.stationNo).toLowerCase().includes(stationQuery))); const headers = ['Vendor Part No.','Component Type','Station','Common Bin','Current Stock','Average Daily Usage','Lead Time Days','Safety Stock','Suggested Order Qty','Status','Usage Confidence','Order Status']; const data = rows.map(r => [r.partNo, r.componentType, r.stationNo, r.binId, r.currentStock, r.averageDailyUsage.toFixed(3), r.leadTimeDays, r.safetyStock.toFixed(2), r.suggestedOrderQty, r.status, r.usageConfidence, r.orderStatus]); download(`shank-mapping-bi-dashboard-${today()}.csv`, csv([headers, ...data]), 'text/csv'); }
  function updateBIDashboardStations(partValue) { const select = document.getElementById('cm-bi-station'); if (!select) { return; } const query = String(partValue || '').trim().toLowerCase(); const stations = [...new Set(procurementRows().filter(r => !query || String(r.partNo).toLowerCase().includes(query)).map(r => String(r.stationNo || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b)); const current = select.value; select.innerHTML = `<option value="">All Stations</option>${stations.map(station => `<option value="${esc(station)}">${esc(station)}</option>`).join('')}`; if (stations.includes(current)) { select.value = current; } }
  function gunCountMetrics() {
    if (gunCountService) {
      const metrics = gunCountService.calculateMetrics(state.gunRows || [], state.mappings || []);
      return { source: metrics.source, mapped: metrics.mapped, allocated: metrics.allocated, unassigned: metrics.unassigned, total: metrics.total, reconciliation: metrics.reconciliation, calculationVersion: metrics.calculationVersion, sourceHash: metrics.sourceHash, mappingHash: metrics.mappingHash };
    }
    const sourceRows = (state.gunRows || []).filter(row => row && (row.sourceKey || row.sourceRow != null || row.gunReferenceNo));
    return { source: calculateGunCount(sourceRows), mapped: calculateGunCount(state.mappings || []), allocated: calculateGunCount((state.mappings || []).filter(m => m.binId)), unassigned: calculateGunCount(sourceRows.filter(row => !row.stationNo || row.sourceOnly)) };
  }
  function shankBIDashboardAnomalyRows(partQuery, stationQuery, start, end) {
    const series = new Map();
    consumptionRows().filter(t => t.type === 'Replacement / Issue' && String(t.date || '').slice(0, 10) >= start && String(t.date || '').slice(0, 10) <= end && (!partQuery || vendorPartNo(t.partNo).toLowerCase().includes(partQuery)) && (!stationQuery || String(t.stationNo || 'Unknown').toLowerCase().includes(stationQuery))).forEach(t => {
      const part = vendorPartNo(t.partNo).trim();
      const station = String(t.stationNo || 'Unknown').trim() || 'Unknown';
      const key = `${part}\u001f${station}`;
      const byDay = series.get(key) || new Map();
      const date = String(t.date || '').slice(0, 10);
      byDay.set(date, (byDay.get(date) || 0) + Number(t.quantity || 0));
      series.set(key, byDay);
    });
    const detector = typeof AnomalyDetection === 'function' ? new AnomalyDetection() : null;
    if (!detector) { return ''; }
    const rows = [];
    series.forEach((byDay, key) => {
      if (byDay.size < 3) { return; }
      const dates = [...byDay.keys()].sort();
      const values = dates.map(date => byDay.get(date));
      detector.detectAnomalies(values, key).forEach(anomaly => rows.push({ part: key.split('\u001f')[0], station: key.split('\u001f')[1], date: dates[anomaly.index] || '', severity: anomaly.severity, type: anomaly.type, message: anomaly.message }));
    });
    const rank = { critical: 0, warning: 1, info: 2 };
    return rows.sort((a, b) => (rank[a.severity] ?? 9) - (rank[b.severity] ?? 9) || a.date.localeCompare(b.date)).slice(0, 20).map((row, i) => `<tr><td>${i + 1}</td><td>${esc(row.severity.toUpperCase())}</td><td>${esc(row.part)}</td><td>${esc(row.station)}</td><td>${esc(row.date)}</td><td>${esc(row.type)}</td><td>${esc(row.message)}</td></tr>`).join('');
  }
  function shankBIForecastRows(proc, partRows, period) {
    const byPart = new Map();
    proc.forEach(r => { const key = partKey(r.partNo); const item = byPart.get(key) || { partNo: r.partNo, usage: 0, stock: 0, suggested: 0, zeroDate: r.expectedZeroDate || null, status: r.status, lead: r.leadTimeDays || 0, confidence: r.usageConfidence || 'NO DATA', reason: r.reason || '' }; item.usage += Number(r.averageDailyUsage || 0); item.stock += Number(r.currentStock || 0); item.suggested += Number(r.suggestedOrderQty || 0); if (r.expectedZeroDate && (!item.zeroDate || r.expectedZeroDate < item.zeroDate)) {item.zeroDate = r.expectedZeroDate;} if (({ 'ZERO STOCK': 0, 'STOCK-OUT RISK': 1, REORDER: 2, 'LOW STOCK': 3, 'USAGE DATA MISSING': 4, NORMAL: 5 }[r.status] ?? 9) < ({ 'ZERO STOCK': 0, 'STOCK-OUT RISK': 1, REORDER: 2, 'LOW STOCK': 3, 'USAGE DATA MISSING': 4, NORMAL: 5 }[item.status] ?? 9)) {item.status = r.status;} byPart.set(key, item); });
    return [...byPart.values()].map((r, i) => { const daily = r.usage / Math.max(1, proc.filter(x => partKey(x.partNo) === partKey(r.partNo)).length); const forecast30 = daily * 30; const forecast90 = daily * 90; const risk = ['ZERO STOCK', 'STOCK-OUT RISK', 'REORDER'].includes(r.status) ? 'HIGH' : r.status === 'LOW STOCK' ? 'MEDIUM' : 'LOW'; const confidence = r.confidence === 'HIGH' ? 'HIGH' : r.confidence === 'MEDIUM' ? 'MEDIUM' : daily > 0 ? 'LOW' : 'NO DATA'; const reason = r.reason || (daily > 0 ? `Expected ${forecast30.toFixed(1)} units in 30 days from selected usage history.` : 'Insufficient usage history for a reliable forecast.'); return { ...r, daily, forecast7: daily * 7, forecast30, forecast90, risk, confidence, reason, sr: i + 1 }; }).sort((a,b) => ({ HIGH: 0, MEDIUM: 1, LOW: 2 }[a.risk] - ({ HIGH: 0, MEDIUM: 1, LOW: 2 }[b.risk]) || b.forecast30 - a.forecast30));
  }
  function shankBIStationRiskRows(usageStation, proc) { return [...usageStation.entries()].map(([station, usage], i) => { const rows = proc.filter(r => String(r.stationNo || '').toLowerCase() === station.toLowerCase()); const stock = rows.reduce((sum, r) => sum + Number(r.currentStock || 0), 0); const suggested = rows.reduce((sum, r) => sum + Number(r.suggestedOrderQty || 0), 0); const risk = stock <= 0 || rows.some(r => ['ZERO STOCK', 'STOCK-OUT RISK'].includes(r.status)) ? 'HIGH' : rows.some(r => ['REORDER', 'LOW STOCK'].includes(r.status)) ? 'MEDIUM' : 'LOW'; return { sr: i + 1, station, usage, stock, suggested, risk, reason: risk === 'HIGH' ? 'Usage is active while stock or lead-time risk is high.' : risk === 'MEDIUM' ? 'At least one mapped part is below its safe level.' : 'Current mapped stock is within the configured safe level.' }; }).sort((a,b) => ({ HIGH: 0, MEDIUM: 1, LOW: 2 }[a.risk] - ({ HIGH: 0, MEDIUM: 1, LOW: 2 }[b.risk]) || b.usage - a.usage)); }
  function shankBIDataQualityRows() { const rows = []; const add = (issue, count, action) => { if (count > 0) {rows.push({ issue, count, action });} }; add('Unassigned source guns', state.gunRows.filter(r => r.sourceOnly || !r.stationNo).length, 'Complete station/component mapping.'); add('Mappings without station or bin', state.mappings.filter(r => !r.stationNo || !r.binId).length, 'Review mapping and assign a common bin.'); add('Stock without a bin', state.stock.filter(r => !r.binId).length, 'Assign stock to a valid bin.'); add('Usage without part or station', consumptionRows().filter(r => !r.partNo || !r.stationNo).length, 'Correct the transaction before relying on forecasts.'); return rows; }
  function shankBISubstitutionRows(riskRows) { const candidates = state.parts.filter(p => p.active !== false && validMappedPartNo(p.partNo)).map(p => { const stock = state.stock.filter(s => partKey(s.partNo) === partKey(p.partNo)).reduce((sum, s) => sum + Number(s.quantity || 0), 0); return { partNo: vendorPartNo(p.partNo), type: p.componentType || '', stock, compatible: p.description || '' }; }).filter(p => p.stock > 0); return riskRows.filter(r => ['ZERO STOCK', 'STOCK-OUT RISK'].includes(r.status)).slice(0, 8).map(r => { const part = state.parts.find(p => partKey(p.partNo) === partKey(r.partNo)); const alt = candidates.filter(c => c.type && c.type === part?.componentType && partKey(c.partNo) !== partKey(r.partNo)).sort((a,b) => b.stock-a.stock)[0]; return alt ? { partNo: r.partNo, alternative: alt.partNo, stock: alt.stock, reason: `Same component type (${alt.type}) with available stock; supervisor approval required.` } : null; }).filter(Boolean); }
  function componentUpdateBIQueryPreview() {
    const input = document.getElementById('cm-bi-ai-query');
    const preview = document.getElementById('cm-bi-query-preview');
    if (preview) { preview.textContent = input?.value?.trim() || 'Select a sample question or type an English BI question.'; }
  }
  function componentEditBIQuery() { document.getElementById('cm-bi-ai-query')?.focus(); }
  function shankBIChart(title, labels, values, color) {
    const clean = labels.map((label, i) => ({ label: String(label), value: Number(values[i] || 0) })).filter(row => Number.isFinite(row.value)).slice(0, 10);
    if (!clean.length || !clean.some(row => row.value > 0)) { return ''; }
    const max = Math.max(...clean.map(row => row.value), 1);
    return `<div class="card" style="margin-top:10px"><div class="card-hd">${esc(title)}</div><div style="display:flex;flex-direction:column;gap:7px;padding:8px 4px">${clean.map(row => `<div style="display:grid;grid-template-columns:minmax(100px,1fr) 3fr 60px;gap:8px;align-items:center;font-size:11px"><span>${esc(row.label)}</span><span style="height:14px;background:var(--bg2);border-radius:3px;overflow:hidden"><span style="display:block;height:100%;width:${Math.max(2, row.value / max * 100)}%;background:${color || 'var(--primary)'}"></span></span><strong style="text-align:right">${row.value}</strong></div>`).join('')}</div></div>`;
  }
  function runShankBINaturalQuery() {
    const input = document.getElementById('cm-bi-ai-query');
    const output = document.getElementById('cm-bi-ai-query-result');
    if (!input || !output) { return; }
    const raw = String(input.value || '').trim();
    const q = raw.toLowerCase();
    const days = Number((q.match(/(?:last|past|for)\s+(7|30|60|90)\s*days?/) || q.match(/(7|30|60|90)\s*days?/) || [])[1] || 90);
    const end = today();
    const startDate = new Date(`${end}T00:00:00`);
    startDate.setDate(startDate.getDate() - days + 1);
    const start = startDate.toISOString().slice(0, 10);
    const normalized = value => String(value || '').trim().toLowerCase();
    const allProcurement = procurementRows(days);
    const partNames = [...new Set(allProcurement.map(r => String(r.partNo || '').trim()).filter(Boolean))];
    const stationNames = [...new Set(allProcurement.map(r => String(r.stationNo || '').trim()).filter(Boolean))];
    const matchingPart = partNames.find(part => q.includes(normalized(part)));
    const matchingStations = stationNames.filter(station => q.includes(normalized(station)));
    const station = matchingStations[0] || (q.match(/station\s+([a-z0-9][a-z0-9 _-]*?)(?=\s+(?:for|in|over|during|last|past|and)\b|$)/i) || [])[1]?.trim();
    const secondStation = matchingStations[1];
    const has = (...words) => words.some(word => q.includes(word));
    // Stock transactions are the authoritative source for posted Replacement / Issue
    // usage. `state.replacements` stores the same event's accountability metadata,
    // so including both would double-count every replacement. Historical consumption
    // remains included because it has no corresponding live stock transaction.
    const usageRows = [...state.tx, ...(state.historicalConsumption || [])]
      .filter(row => row.type === 'Replacement / Issue')
      .map(row => {
        const date = String(row.date || '').slice(0, 10);
        const bin = state.bins.find(item => item.binId === row.binId);
        const resolvedStation = row.stationNo || (bin?.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : bin?.stationNo || '');
        return { ...row, date, stationNo: resolvedStation, partNo: vendorPartNo(row.partNo).trim(), quantity: Number(row.quantity || 0) };
      })
      .filter(row => row.date >= start && row.date <= end && (!matchingPart || normalized(row.partNo) === normalized(matchingPart)) && (!station || normalized(row.stationNo).includes(normalized(station))));
    const aggregate = (rows, key) => {
      const map = new Map();
      rows.forEach(row => { const name = String(row[key] || 'Unassigned').trim() || 'Unassigned'; map.set(name, (map.get(name) || 0) + Number(row.quantity || 0)); });
      return [...map.entries()].map(([name, usage]) => ({ name, usage })).sort((a, b) => b.usage - a.usage || a.name.localeCompare(b.name));
    };
    const usageByPart = aggregate(usageRows, 'partNo');
    const usageByStation = aggregate(usageRows, 'stationNo');
    const stockRows = allProcurement.filter(row => (!matchingPart || normalized(row.partNo) === normalized(matchingPart)) && (!station || normalized(row.stationNo).includes(normalized(station))));
    const stockByPart = new Map();
    stockRows.forEach(row => { const item = stockByPart.get(row.partNo) || { partNo: row.partNo, stock: 0, suggested: 0, status: row.status, reason: row.reason, station: row.stationNo, zeroDate: row.expectedZeroDate }; item.stock += Number(row.currentStock || 0); item.suggested += Number(row.suggestedOrderQty || 0); if (['ZERO STOCK','STOCK-OUT RISK','REORDER','LOW STOCK'].includes(row.status)) { item.status = row.status; item.reason = row.reason; } stockByPart.set(row.partNo, item); });
    const riskRows = stockRows.filter(row => ['ZERO STOCK','STOCK-OUT RISK','REORDER','LOW STOCK'].includes(String(row.status || '').toUpperCase()));
    const header = `<div class=\"muted\">Applied query: ${esc(raw || 'show risk parts')} · Period: ${days} days${station ? ` · Station: ${esc(station)}` : ''}</div>`;
    const rowsHtml = (headers, rows, empty) => table(headers, rows.join(''), empty);
    let result = '';
    if (!raw) { result = `${header}${rowsHtml(['SR No.','Part No.','Station','Current Stock','Suggested Order','Status','Reason'], riskRows.sort((a,b) => Number(b.suggestedOrderQty || 0) - Number(a.suggestedOrderQty || 0)).slice(0, 10).map((r,i) => `<tr><td>${i+1}</td><td>${esc(r.partNo)}</td><td>${esc(r.stationNo)}</td><td>${r.currentStock}</td><td>${r.suggestedOrderQty}</td><td>${esc(r.status)}</td><td>${esc(r.reason || 'Based on current stock, usage and lead time.')}</td></tr>`), 'No matching risk or procurement rows.')}`; }
    else if (has('compare', 'versus', ' vs ') && secondStation) {
      const comparison = matchingStations.slice(0, 2).map(name => { const usage = usageRows.filter(row => normalized(row.stationNo).includes(normalized(name))).reduce((sum, row) => sum + row.quantity, 0); const rows = stockRows.filter(row => normalized(row.stationNo).includes(normalized(name))); return { name, usage, stock: rows.reduce((sum, row) => sum + Number(row.currentStock || 0), 0), risk: rows.filter(row => ['ZERO STOCK','STOCK-OUT RISK','REORDER','LOW STOCK'].includes(row.status)).length }; });
      result = `${header}${rowsHtml(['Station','Usage','Current Stock','Risk Items'], comparison.map(r => `<tr><td>${esc(r.name)}</td><td>${r.usage}</td><td>${r.stock}</td><td>${r.risk}</td></tr>`), 'No comparison data found.')}`;
    } else if (has('trend', 'daily trend', 'over time')) {
      const trend = aggregate(usageRows, 'date');
      result = `${header}${rowsHtml(['Date','Usage Qty'], trend.map(r => `<tr><td>${esc(r.name)}</td><td>${r.usage}</td></tr>`), 'No usage trend data found.')}`;
    } else if (has('which station', 'stations', 'station has', 'top station', 'highest consumption', 'highest usage')) {
      const limit = Number((q.match(/top\s+(\d+)/) || [])[1] || 10);
      result = `${header}${rowsHtml(['Rank','Station','Usage Qty'], usageByStation.slice(0, limit).map((r,i) => `<tr><td>${i+1}</td><td>${esc(r.name)}</td><td>${r.usage}</td></tr>`), 'No station usage data found.')}`;
    } else if (has('which parts', 'top parts', 'top ', 'most used', 'highest usage', 'highest consumption') && !has('reach zero', 'stock coverage', 'stock-out date')) {
      const limit = Number((q.match(/top\s+(\d+)/) || [])[1] || 10);
      result = `${header}${rowsHtml(['Rank','Part No.','Usage Qty'], usageByPart.slice(0, limit).map((r,i) => `<tr><td>${i+1}</td><td>${esc(r.name)}</td><td>${r.usage}</td></tr>`), 'No part usage data found.')}`;
    } else if (has('trend', 'usage', 'consumption', 'used', 'consumed') && (matchingPart || station)) {
      result = `${header}${rowsHtml(['Part No.','Usage Qty'], usageByPart.map(r => `<tr><td>${esc(r.name)}</td><td>${r.usage}</td></tr>`), 'No usage data found for the selected filters.')}`;
    } else if (/^(?:show|list|display) zero stock parts(?: now)?$/.test(q) || /^show zero stock at station /.test(q)) {
      const exactZeroRows = riskRows.filter(row => row.status === 'ZERO STOCK').sort((a, b) => String(a.partNo).localeCompare(String(b.partNo), undefined, { numeric: true }));
      result = `${header}${rowsHtml(['SR No.','Part No.','Station','Current Stock','Suggested Order','Status','Reason'], exactZeroRows.map((r,i) => `<tr><td>${i+1}</td><td>${esc(r.partNo)}</td><td>${esc(r.stationNo)}</td><td>${r.currentStock}</td><td>${r.suggestedOrderQty}</td><td>${esc(r.status)}</td><td>${esc(r.reason || 'Current stock is zero.')}</td></tr>`), 'No zero-stock parts found.')}`;
    } else if (has('zero', 'stock coverage', 'reach zero', 'stock-out date')) {
      const forecast = [...stockByPart.values()].map(item => { const usage = usageByPart.find(row => normalized(row.name) === normalized(item.partNo))?.usage || 0; const daily = usage / days; const cover = daily > 0 ? item.stock / daily : null; return { ...item, daily, cover, zeroDate: cover === null ? 'Not predictable' : new Date(Date.now() + Math.ceil(cover) * 86400000).toISOString().slice(0, 10) }; }).sort((a,b) => (a.cover ?? Infinity) - (b.cover ?? Infinity));
      result = `${header}${rowsHtml(['Part No.','Current Stock','Average / Day','Stock Cover (Days)','Estimated Zero Date','Risk'], forecast.map(r => `<tr><td>${esc(r.partNo)}</td><td>${r.stock}</td><td>${r.daily.toFixed(2)}</td><td>${r.cover === null ? '—' : r.cover.toFixed(1)}</td><td>${esc(r.zeroDate)}</td><td>${esc(r.status || 'NORMAL')}</td></tr>`), 'No forecast data found.')}`;
    } else if (has('why', 'explain', 'reason')) {
      const target = matchingPart ? stockByPart.get(matchingPart) : riskRows[0];
      result = target ? `${header}<p><strong>${esc(target.partNo)}</strong>: ${esc(target.reason || 'Risk is based on current stock, usage, lead time and configured safety levels.')}</p>` : `${header}<p>No matching part or risk record was found.</p>`;
    } else if (has('risk', 'low stock', 'zero stock', 'stock-out', 'reorder', 'critical')) {
      const filtered = has('zero stock') ? riskRows.filter(r => r.status === 'ZERO STOCK') : has('low stock') ? riskRows.filter(r => r.status === 'LOW STOCK') : has('reorder') ? riskRows.filter(r => r.status === 'REORDER') : riskRows;
      const displayRows = has('zero stock') ? filtered : filtered.slice(0, 10);
      result = `${header}${rowsHtml(['SR No.','Part No.','Station','Current Stock','Suggested Order','Status','Reason'], displayRows.sort((a,b) => Number(b.suggestedOrderQty || 0) - Number(a.suggestedOrderQty || 0)).map((r,i) => `<tr><td>${i+1}</td><td>${esc(r.partNo)}</td><td>${esc(r.stationNo)}</td><td>${r.currentStock}</td><td>${r.suggestedOrderQty}</td><td>${esc(r.status)}</td><td>${esc(r.reason || 'Based on current stock, usage and lead time.')}</td></tr>`), 'No matching risk or procurement rows.')}`;
    } else { result = `${header}<p>Query not recognized. Try: <em>show low stock parts</em>, <em>which station has the highest consumption?</em>, <em>show top 10 consumed parts</em>, <em>compare FFA 10 and FFA 12</em>, <em>show consumption trend for the last 30 days</em>, or <em>which parts will reach zero stock first?</em></p>`; }
    const summary = !raw ? 'Please select a sample question or enter an English BI question.' : has('compare', 'versus', ' vs ') && secondStation ? `Station comparison completed for ${esc(matchingStations.slice(0, 2).join(' and '))}.` : has('trend', 'daily trend', 'over time') ? `Consumption trend analyzed across ${usageRows.length} transactions during the last ${days} days.` : has('which station', 'stations', 'station has', 'top station', 'highest consumption', 'highest usage') ? `${usageByStation[0]?.name ? esc(usageByStation[0].name) + ' has the highest consumption with ' + usageByStation[0].usage + ' units.' : 'No station usage was found for the selected period.'}` : has('which parts', 'top parts', 'top ', 'most used', 'highest usage', 'highest consumption') && !has('reach zero', 'stock coverage', 'stock-out date') ? `${usageByPart.length} parts were analyzed; ${usageByPart[0]?.name ? esc(usageByPart[0].name) + ' is the most used with ' + usageByPart[0].usage + ' units.' : 'no part usage was found.'}` : has('risk', 'low stock', 'zero stock', 'stock-out', 'reorder', 'critical') && !has('reach zero', 'stock coverage', 'stock-out date') ? `${riskRows.filter(r => r.status === 'ZERO STOCK').length} parts are at zero stock and ${riskRows.length} parts require risk or reorder attention.` : has('zero', 'stock coverage', 'reach zero', 'stock-out date') ? `Stock coverage was calculated for ${stockByPart.size} parts using the last ${days} days of usage.` : has('why', 'explain', 'reason') ? 'The explanation is based on current stock, usage, lead time and configured safety levels.' : 'No matching BI interpretation was found.';
    const trendRowsForChart = aggregate(usageRows, 'date');
    const chart = has('compare', 'versus', ' vs ') && secondStation ? shankBIChart('Station Comparison', matchingStations.slice(0, 2), matchingStations.slice(0, 2).map(name => usageRows.filter(row => normalized(row.stationNo).includes(normalized(name))).reduce((sum, row) => sum + row.quantity, 0)), 'var(--primary)') : has('trend', 'daily trend', 'over time') ? shankBIChart('Consumption Trend', trendRowsForChart.map(row => row.name), trendRowsForChart.map(row => row.usage), 'var(--success)') : has('which station', 'stations', 'station has', 'top station', 'highest consumption', 'highest usage') ? shankBIChart('Station Usage Ranking', usageByStation.map(row => row.name), usageByStation.map(row => row.usage), 'var(--warning)') : has('which parts', 'top parts', 'top ', 'most used', 'highest usage', 'highest consumption') && !has('reach zero', 'stock coverage', 'stock-out date') ? shankBIChart('Top Consumed Parts', usageByPart.map(row => row.name), usageByPart.map(row => row.usage), 'var(--primary)') : has('risk', 'low stock', 'zero stock', 'stock-out', 'reorder', 'critical') && !has('reach zero', 'stock coverage', 'stock-out date') ? shankBIChart('Risk Summary', ['Zero Stock', 'Stock-out Risk', 'Reorder', 'Low Stock'], ['ZERO STOCK', 'STOCK-OUT RISK', 'REORDER', 'LOW STOCK'].map(status => riskRows.filter(row => row.status === status).length), 'var(--danger)') : has('zero', 'stock coverage', 'reach zero', 'stock-out date') ? shankBIChart('Stock Coverage', [...stockByPart.values()].slice(0, 10).map(row => row.partNo), [...stockByPart.values()].slice(0, 10).map(row => row.stock), 'var(--danger)') : '';
    const metadata = `<div class="muted" style="margin-top:10px">Data updated: ${esc(new Date().toLocaleString('en-GB'))} · Transactions analyzed: ${usageRows.length} · Period: Last ${days} days${station ? ` · Station: ${esc(station)}` : ''}</div>`;
    const clarification = raw && !has('risk', 'low stock', 'zero stock', 'stock-out', 'reorder', 'critical', 'compare', 'versus', ' vs ', 'trend', 'daily trend', 'over time', 'which station', 'stations', 'station has', 'top station', 'highest consumption', 'highest usage', 'which parts', 'top parts', 'top ', 'most used', 'used', 'consumed', 'usage', 'consumption', 'zero', 'stock coverage', 'reach zero', 'stock-out date', 'why', 'explain', 'reason') ? '<div class="alrt alrt-y">I could not identify the BI intent. Please choose a sample question or include risk, usage, comparison, trend, forecast, or explanation.</div>' : '';
    const decorated = `${metadata}<div class="card" style="margin-top:8px"><strong>Summary:</strong> ${summary}</div>${clarification}${chart}${result}`;
    output.innerHTML = decorated;
    try { audit('COMPONENT_BI_NATURAL_QUERY', 'BI Query', raw || 'empty-query', { query: raw, periodDays: days, station: station || null, part: matchingPart || null, transactionCount: usageRows.length, resultCount: usageRows.length, executedAt: nowIso() }); } catch (error) { console.warn('[BI query audit] failed', error); }
  }
  function refreshBISampleOptions() {
    const rows = procurementRows();
    const stations = [...new Set(rows.map(row => String(row.stationNo || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
    const parts = [...new Set(rows.map(row => String(row.partNo || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
    [['cm-bi-sample-station-1', stations], ['cm-bi-sample-station-2', stations], ['cm-bi-sample-part', parts]].forEach(([id, values]) => {
      const select = document.getElementById(id);
      if (!select || select.options.length > 1) { return; }
      select.innerHTML += values.map(value => `<option value="${esc(value)}">${esc(value)}</option>`).join('');
    });
  }
  function componentApplyBISample() {
    const sample = document.getElementById('cm-bi-sample-query')?.value || '';
    if (!sample) { return; }
    refreshBISampleOptions();
    const available = procurementRows();
    const stationValues = [...new Set(available.map(row => String(row.stationNo || '').trim()).filter(Boolean))];
    const partValues = [...new Set(available.map(row => String(row.partNo || '').trim()).filter(Boolean))];
    const station1 = stationValues[0] || 'a station';
    const station2 = stationValues[1] || stationValues[0] || 'another station';
    const part = partValues[0] || 'a part';
    const input = document.getElementById('cm-bi-ai-query');
    if (input) { input.value = sample.replaceAll('{station1}', station1).replaceAll('{station2}', station2).replaceAll('{station}', station1).replaceAll('{part}', part); }
    componentUpdateBIQueryPreview();
  }
  function biPartOptions(selected = '') { const values = [...new Set(state.parts.filter(p => p.active !== false).map(p => vendorPartNo(p.partNo).trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })); return values.map(part => `<option value="${esc(part)}" ${part.toLowerCase() === String(selected || '').toLowerCase() ? 'selected' : ''}>${esc(part)}</option>`).join(''); }
  function biDashboard() { const partQuery = val('cm-bi-part').toLowerCase(); const stationQuery = val('cm-bi-station').toLowerCase(); const period = Number(sel('cm-bi-period') || 90); const end = today(); const startDate = new Date(`${end}T00:00:00`); startDate.setDate(startDate.getDate() - period + 1); const start = startDate.toISOString().slice(0, 10); const allProcurement = procurementRows(period); const proc = allProcurement.filter(r => (!partQuery || String(r.partNo).toLowerCase().includes(partQuery)) && (!stationQuery || String(r.stationNo).toLowerCase().includes(stationQuery))); const stockByPart = new Map(); state.stock.forEach(s => { const key = partKey(s.partNo); const x = stockByPart.get(key) || { partNo: vendorPartNo(s.partNo).trim(), quantity: 0, bins: new Set(), stations: new Set() }; x.quantity += Number(s.quantity || 0); x.bins.add(s.binId || 'Unassigned'); const b = state.bins.find(bin => bin.binId === s.binId); if (b?.binKind === 'PENCIL_PAIR') { x.stations.add('Pencil Common'); } else if (b?.stationNo) { x.stations.add(b.stationNo); } stockByPart.set(key, x); }); const usagePart = new Map(); const usageStation = new Map(); const usageDate = new Map(); const usageShift = new Map(); let liveUsage = 0; let historicalUsage = 0; consumptionRows().filter(t => t.type === 'Replacement / Issue' && String(t.date || '').slice(0, 10) >= start && String(t.date || '').slice(0, 10) <= end && (!partQuery || vendorPartNo(t.partNo).toLowerCase().includes(partQuery)) && (!stationQuery || String(t.stationNo || 'Unknown').toLowerCase().includes(stationQuery))).forEach(t => { const part = vendorPartNo(t.partNo).trim(); const qty = Number(t.quantity || 0); const pk = part.toLowerCase(); usagePart.set(pk, (usagePart.get(pk) || 0) + qty); if (t.historical) { historicalUsage += qty; } else { liveUsage += qty; } const station = String(t.stationNo || 'Unknown'); usageStation.set(station, (usageStation.get(station) || 0) + qty); const shift = String(t.shift || 'Unknown').trim() || 'Unknown'; usageShift.set(shift, (usageShift.get(shift) || 0) + qty); const date = String(t.date || '').slice(0, 10); usageDate.set(date, (usageDate.get(date) || 0) + qty); }); const statusRank = { 'ZERO STOCK': 0, 'STOCK-OUT RISK': 1, REORDER: 2, 'LOW STOCK': 3, 'USAGE DATA MISSING': 4, NORMAL: 5 }; const partRows = [...stockByPart.values()].map(x => { const related = proc.filter(r => r.partNo.toLowerCase() === x.partNo.toLowerCase()); const best = related.sort((a, b) => (statusRank[a.status] ?? 9) - (statusRank[b.status] ?? 9))[0]; return { ...x, usage: usagePart.get(x.partNo.toLowerCase()) || 0, status: best?.status || 'NORMAL', minimum: best?.safetyStock || 0, suggested: related.reduce((sum, r) => sum + Number(r.suggestedOrderQty || 0), 0), orderStatus: best?.orderStatus || '' }; }).filter(x => (!partQuery || x.partNo.toLowerCase().includes(partQuery)) && (!stationQuery || proc.some(r => r.partNo.toLowerCase() === x.partNo.toLowerCase() && String(r.stationNo).toLowerCase().includes(stationQuery)))).sort((a, b) => (statusRank[a.status] ?? 9) - (statusRank[b.status] ?? 9) || b.usage - a.usage); const criticalRows = partRows.filter(x => proc.some(r => r.partNo.toLowerCase() === x.partNo.toLowerCase() && r.criticalFlag)).map((x, i) => `<tr><td>${i + 1}</td><td>${esc(x.partNo)}</td><td>${x.usage}</td><td>${x.quantity}</td><td>${esc(x.status)}</td></tr>`).join(''); const criticalCount = partRows.filter(x => proc.some(r => r.partNo.toLowerCase() === x.partNo.toLowerCase() && r.criticalFlag)).length; const riskRows = partRows.filter(x => x.status !== 'NORMAL' || proc.some(r => r.partNo.toLowerCase() === x.partNo.toLowerCase() && r.criticalFlag)).map((x, i) => `<tr><td>${i + 1}</td><td>${esc(x.partNo)}</td><td>${x.quantity}</td><td>${x.minimum}</td><td>${esc(x.status)}</td><td>${x.suggested}</td><td>${esc(x.orderStatus)}</td></tr>`).join(''); const topParts = [...usagePart.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10).map(([part, qty], i) => `<tr><td>${i + 1}</td><td>${esc(part)}</td><td>${qty}</td></tr>`).join(''); const topStations = [...usageStation.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10).map(([station, qty], i) => `<tr><td>${i + 1}</td><td>${esc(station)}</td><td>${qty}</td></tr>`).join(''); const trendRows = [...usageDate.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([date, qty]) => `<tr><td>${esc(date)}</td><td>${qty}</td></tr>`).join(''); const anomalyRows = shankBIDashboardAnomalyRows(partQuery, stationQuery, start, end); const aiForecastRows = shankBIForecastRows(proc, partRows, period); const aiStationRows = shankBIStationRiskRows(usageStation, proc); const aiQualityRows = shankBIDataQualityRows(); const aiSubstitutionRows = shankBISubstitutionRows(partRows); const totalUsage = liveUsage + historicalUsage; const usageShiftRows = [...usageShift.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10).map(([shift, qty], i) => `<tr><td>${i + 1}</td><td>${esc(shift)}</td><td>${qty}</td></tr>`).join(''); const gunMetrics = gunCountMetrics(); const gunReconStatus = gunMetrics.reconciliation?.balanced ? 'RECONCILED' : 'REQUIRES ATTENTION'; const gunReconClass = gunMetrics.reconciliation?.balanced ? 'alrt-b' : 'alrt-r'; const mappedParts = new Set(state.mappings.filter(m => validMappedPartNo(m.partNo)).map(m => partKey(m.partNo))); const dataQuality = state.gunRows.filter(r => r.sourceOnly).length + state.mappings.filter(m => !m.binId || !m.stationNo).length; const openOrders = state.orders.filter(o => !['RECEIVED', 'CANCELLED'].includes(String(o.orderStatus || '').toUpperCase())).length; const zero = partRows.filter(x => x.status === 'ZERO STOCK').length; const low = partRows.filter(x => ['LOW STOCK', 'REORDER', 'STOCK-OUT RISK'].includes(x.status)).length; shell('Shank Mapping — BI Dashboard', `<div class="g4 cm-mobile-stack">${cardMetric(gunMetrics.source, 'Source Gun Count')}${cardMetric(gunMetrics.mapped, 'Mapped Gun Count')}${cardMetric(gunMetrics.allocated, 'Allocated Gun Count')}${cardMetric(gunMetrics.unassigned, 'Unassigned / Source-only', "componentOpenSourceOnlyGuns()")}${ambiguousPartSection()}</div><div class="alrt ${gunReconClass}"><strong>Gun Count Reconciliation: ${gunReconStatus}</strong> — Source ${gunMetrics.source} | Mapped ${gunMetrics.mapped} | Allocated ${gunMetrics.allocated} | Unassigned ${gunMetrics.unassigned}. Formula version: ${esc(gunMetrics.calculationVersion || '')}.</div><div class="alrt alrt-b">Management view for Shank Mapping. Usage metrics combine Live Replacement/Issue and Historical Consumption records. Historical rows are analytics-only and never change current stock.</div><div class="g4 cm-mobile-stack">${cardMetric(partRows.length,'Parts in View')}${cardMetric(partRows.reduce((sum, x) => sum + x.quantity, 0),'Pooled Available Qty')}${cardMetric(zero,'Zero Stock Parts',"componentOpen('stock-zero')")}${cardMetric(low,'Risk / Reorder Parts',"componentOpen('stock-low')")}</div><div class="g3 cm-mobile-stack">${cardMetric(openOrders,'Open / Pending Orders',"componentOpen('procurement')")}${cardMetric([...usagePart.values()].reduce((sum, qty) => sum + qty, 0),'Usage in Selected Period')}${cardMetric(consumptionRows().filter(r => r.historical && String(r.date || '').slice(0, 10) >= start && String(r.date || '').slice(0, 10) <= end && (!partQuery || vendorPartNo(r.partNo).toLowerCase().includes(partQuery)) && (!stationQuery || String(r.stationNo || 'Unknown').toLowerCase().includes(stationQuery))).reduce((sum, r) => sum + Number(r.quantity || 0), 0),'Historical Usage in Period')}${cardMetric(criticalCount,'Critical Awareness')}${cardMetric(dataQuality,'Data Quality Flags')}</div><div class="card"><div class="card-hd">BI Filters</div><div class="g3"><div class="fr"><label class="fl">Part No.</label><input class="fi" id="cm-bi-part" list="cm-bi-parts" value="${esc(partQuery)}" placeholder="Type or select Part No." oninput="componentRefreshBIDashboard()"><datalist id="cm-bi-parts">${biPartOptions(partQuery)}</datalist></div><div class="fr"><label class="fl">Station</label><input class="fi" id="cm-bi-station" list="cm-bi-stations" value="${esc(stationQuery)}" placeholder="Type or select Station" oninput="componentRefreshBIDashboard()"><datalist id="cm-bi-stations">${[...new Set(allProcurement.filter(r => !partQuery || String(r.partNo).toLowerCase().includes(partQuery)).map(r => String(r.stationNo || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b)).map(station => `<option value="${esc(station)}"></option>`).join('')}</datalist></div><div class="fr"><label class="fl">Usage Period</label><select class="fi" id="cm-bi-period" onchange="componentRefreshBIDashboard()"><option value="7" ${period === 7 ? 'selected' : ''}>Last 7 Days</option><option value="30" ${period === 30 ? 'selected' : ''}>Last 30 Days</option><option value="60" ${period === 60 ? 'selected' : ''}>Last 60 Days</option><option value="90" ${period === 90 ? 'selected' : ''}>Last 90 Days</option></select></div></div><div class="btn-row">${btn('Refresh BI Dashboard','componentRefreshBIDashboard()',true)}${btn('Clear BI Filters','componentClearBIDashboardFilters()')}${btn('Export BI CSV','componentExportBIDashboard()')}<span class="muted">Period: ${start} to ${end}</span></div></div><div class="card"><div class="card-hd">AI Part Substitution Suggestions</div><div class="muted">Suggestions are same-component-type candidates with available stock. Supervisor approval is required before any replacement.</div>${table(['Part at Risk','Suggested Alternative','Available Stock','Reason'], aiSubstitutionRows.map(r => `<tr><td>${esc(r.partNo)}</td><td>${esc(r.alternative)}</td><td>${r.stock}</td><td>${esc(r.reason)}</td></tr>`).join(''), 'No approved same-type substitute with available stock found.')}</div><div class="card"><div class="card-hd">AI Data Quality Assistant</div>${table(['Issue','Count','Recommended Action'], aiQualityRows.map(r => `<tr><td>${esc(r.issue)}</td><td>${r.count}</td><td>${esc(r.action)}</td></tr>`).join(''), 'No Shank Mapping data-quality issues detected.')}</div><div class="card"><div class="card-hd">Natural-Language BI Query</div><div class="muted">Choose a sample English question, review the generated query, edit it if needed, and run it.</div><div class="g3" style="margin:10px 0"><div><label class="fl" for="cm-bi-sample-query">Sample Question</label><select class="fi" id="cm-bi-sample-query" onchange="componentApplyBISample()"><option value="">Select a sample question</option><optgroup label="Stock & Risk"><option value="show low stock parts">Show low stock parts</option><option value="show all risk parts">Show all risk parts</option><option value="show zero stock parts">Show zero stock parts</option><option value="show stock-out risk">Show stock-out risk</option><option value="show reorder parts">Show reorder parts</option><option value="show critical parts">Show critical parts</option><option value="show risk at station {station}">Show risk at a station</option></optgroup><optgroup label="Usage & Consumption"><option value="which parts are used the most?">Which parts are used the most?</option><option value="show top 5 consumed parts">Show top 5 consumed parts</option><option value="show top 10 consumed parts in last 90 days">Show top 10 consumed parts</option><option value="show usage at station {station} in last 30 days">Show usage at a station</option><option value="show consumption trend for the last 30 days">Show consumption trend</option></optgroup><optgroup label="Station Analysis"><option value="which station has the highest consumption?">Which station has the highest consumption?</option><option value="show top 5 stations by usage">Show top 5 stations by usage</option><option value="show usage at station {station} in last 30 days">Show usage at a station</option></optgroup><optgroup label="Part Analysis"><option value="show usage for part {part} in last 30 days">Show usage for a part</option><option value="show current stock for part {part}">Show current stock for a part</option><option value="show risk for part {part}">Show risk for a part</option></optgroup><optgroup label="Comparison"><option value="compare {station1} and {station2}">Compare two stations</option><option value="compare usage between {station1} and {station2}">Compare station usage</option></optgroup><optgroup label="Forecast"><option value="which parts will reach zero stock first?">Which parts reach zero stock first?</option><option value="show stock coverage in days">Show stock coverage in days</option><option value="show estimated zero stock date for {part}">Show zero-stock date for a part</option><option value="which parts need reorder based on current usage?">Which parts need reorder based on usage?</option></optgroup><optgroup label="Explanation"><option value="why is {part} marked as high risk?">Why is a part high risk?</option><option value="explain the reorder recommendation for {part}">Explain a reorder recommendation</option></optgroup></select></div></div><div class="muted" style="margin:8px 0 4px"><strong>Your query:</strong> <span id="cm-bi-query-preview">Select a sample question or type an English BI question.</span></div><div class="btn-row"><input class="fi" id="cm-bi-ai-query" placeholder="Ask an English BI question" data-oninput="componentUpdateBIQueryPreview()" data-style="min-width:280px"><button class="btn" type="button" data-onclick="componentEditBIQuery()">Edit Query</button><button class="btn btn-p" type="button" data-onclick="componentRunShankBIQuery()">Run Query</button></div><div id="cm-bi-ai-query-result" class="tw" style="margin-top:10px"></div></div><div class="card"><div class="card-hd">Historical + Live Consumption</div><div class="g4"><div class="met"><div class="met-v">${totalUsage}</div><div class="met-l">Total Usage</div></div><div class="met"><div class="met-v">${liveUsage}</div><div class="met-l">Live Usage</div></div><div class="met"><div class="met-v">${historicalUsage}</div><div class="met-l">Historical Usage</div></div><div class="met"><div class="met-v">${(totalUsage / period).toFixed(2)}</div><div class="met-l">Average / Day</div></div></div><div class="g2"><div><div class="card-hd">Shift-wise Usage</div>${table(['SR No.','Shift','Usage Qty'], usageShiftRows, 'No shift usage in selected period.')}</div><div><div class="card-hd">Data Scope</div><p class="muted">Only Replacement / Issue transactions in the selected Part, Station and date filters are included. Historical usage does not change current stock.</p></div></div></div><div class="card"><div class="card-hd">AI Usage Forecast & Explainable Reorder</div><div class="muted">Rule-based explainable forecast from selected Replacement / Issue history, current stock, lead time and configured safety levels.</div>${table(['SR No.','Part No.','Daily Avg','30-Day Forecast','90-Day Forecast','Zero Date','Risk','Confidence','Reason'], aiForecastRows.slice(0, 12).map(r => `<tr><td>${r.sr}</td><td>${esc(r.partNo)}</td><td>${r.daily.toFixed(2)}</td><td>${r.forecast30.toFixed(1)}</td><td>${r.forecast90.toFixed(1)}</td><td>${esc(r.zeroDate || 'Not expected')}</td><td>${esc(r.risk)}</td><td>${esc(r.confidence)}</td><td>${esc(r.reason)}</td></tr>`).join(''), 'No forecast rows available.')}</div><div class="card"><div class="card-hd">Station Risk Prediction</div>${table(['SR No.','Station','Usage','Stock','Suggested Order','Risk','Reason'], aiStationRows.slice(0, 12).map(r => `<tr><td>${r.sr}</td><td>${esc(r.station)}</td><td>${r.usage}</td><td>${r.stock}</td><td>${r.suggested}</td><td>${esc(r.risk)}</td><td>${esc(r.reason)}</td></tr>`).join(''), 'No station usage data available.')}</div><div class="card"><div class="card-hd">Shank Usage Anomalies — Explanation</div><div class="muted">Unusual daily Replacement / Issue patterns for the selected Part, Station and period.</div>${table(['SR No.','Severity','Part No.','Station','Date','Detection','Details'], anomalyRows, 'No usage anomalies detected in the selected period.')}</div><div class="card cm-critical-awareness"><div class="card-hd">Critical Awareness</div><div class="muted">Critical Part Master items with combined live and historical usage. Historical data never changes current stock.</div>${table(['SR No.','Critical Part No.','Usage Qty','Current Stock','Status'], criticalRows, 'No Critical Parts configured.')}</div><div class="g2 cm-mobile-stack"><div class="card"><div class="card-hd">Part / Stock / Risk Summary</div>${table(['SR No.','Part No.','Pooled Qty','Minimum','Status','Suggested Order','Order Status'], riskRows, 'No risk or reorder parts.')}</div><div class="card"><div class="card-hd">Top Used Shanks</div>${table(['SR No.','Part No.','Usage Qty'], topParts, 'No Replacement / Issue usage in selected period.')}</div></div><div class="g2 cm-mobile-stack"><div class="card"><div class="card-hd">Station Risk / Usage Ranking</div>${table(['SR No.','Station','Usage Qty'], topStations, 'No station usage in selected period.')}</div><div class="card"><div class="card-hd">Consumption Trend</div>${table(['Date','Replacement / Issue Qty'], trendRows, 'No usage trend in selected period.')}</div></div><div class="card"><div class="card-hd">Data Quality and Workflow</div><div class="g3"><div><strong>Mapped Part Numbers</strong><br>${mappedParts.size}</div><div><strong>Unresolved Flags</strong><br>${dataQuality}</div><div><strong>Open Procurement Orders</strong><br>${openOrders}</div></div><p class="muted">Use the operational screens for receiving, adjustments, mapping, repairs and order changes. This BI view is for analysis and drill-down navigation.</p></div>`); }
  function clearBIDashboardFilters() { ['cm-bi-part', 'cm-bi-station'].forEach(id => { const el = document.getElementById(id); if (el) { el.value = ''; } }); const period = document.getElementById('cm-bi-period'); if (period) { period.value = '90'; } biDashboard(); }
  function dashboard() {
    const stockStatuses = stockStatusRows();
    const low = stockStatuses.filter(row => row.status === 'BELOW REQUIRED QTY').length;
    const zero = stockStatuses.filter(row => row.status === 'ZERO STOCK').length;
    const repair = state.repairs.filter(row => ['UNDER REPAIR', 'REPAIR COMPLETED'].includes(row.status)).length;
    const scrap = state.repairs.filter(row => row.status === 'SCRAP').length;
    const totalParts = state.parts.filter(part => part && part.active !== false && validMappedPartNo(part.partNo)).length;
    const range = state.analyticsRange || monthBounds();
    const rows = analyticsRows(range.start, range.end);
    const movementBody = rows.map(row => `<tr><td>${esc(row.date)}</td><td>${row.receive}</td><td>${row.replacement}</td><td>${row.repairReturn}</td><td>${row.scrap}</td><td>${row.adjustment}</td></tr>`).join('');
    const breakdown = analyticsBreakdown(range.start, range.end);
    const topParts = breakdown.parts.map(([part, quantity]) => `<tr><td>${esc(part)}</td><td>${quantity}</td></tr>`).join('');
    const topStations = breakdown.stations.map(([station, quantity]) => `<tr><td>${esc(station || 'Unknown')}</td><td>${quantity}</td></tr>`).join('');
    shell('Shank Mapping Dashboard', `<div class="g4 cm-mobile-stack">${cardMetric(totalParts, 'Total Parts', "componentOpen('parts')")}${cardMetric(state.stock.reduce((sum, row) => sum + Number(row.quantity || 0), 0), 'Available Quantity', "componentOpen('stock')")}${cardMetric(low, 'Below Required Qty', "componentOpen('stock-low')")}${cardMetric(zero, 'Zero Stock', "componentOpen('stock-zero')")}</div><div class="g2 cm-mobile-stack">${cardMetric(repair, 'Under Repair', "componentOpen('repair')")}${cardMetric(scrap, 'Scrap', "componentOpen('repair')")}</div><div class="btn-row" data-style="flex-wrap:wrap">${btn('＋ Replacement Entry', "componentOpen('replacement')", true)}${btn('Consumption & Procurement', "componentOpen('procurement')")} ${btn('Import Gun Matrix', "componentOpen('import')")}${btn('Gun Register', "componentOpen('gun-register')")}${btn('Print Labels', "componentOpen('labels')")}${btn('Guide Line', "componentOpen('guide')")}${btn('Download Import Template', 'componentDownloadTemplate()')}</div><div class="btn-row">${btn('Open Stock Status', "componentOpen('stock-zero')", true)}</div><div class="card"><div class="card-hd">Stock Movement Analytics</div><div class="g4 cm-mobile-stack"><div class="fr"><label class="fl">Start Date</label><input class="fi" id="cm-analytics-start" type="date" value="${esc(range.start)}"></div><div class="fr"><label class="fl">End Date</label><input class="fi" id="cm-analytics-end" type="date" value="${esc(range.end)}"></div>${btn('Refresh Analytics', 'componentRefreshDashboardAnalytics()', true)}${btn('Export Analytics', 'componentExportAnalytics()')}</div>${table(['Date', 'Receive', 'Replacement', 'Repair Return', 'Scrap', 'Adjustment'], movementBody, 'No stock movement in selected range.')}<div class="card"><div class="card-hd">Scan StoreTrack Label QR</div><div class="muted">Scan with the connected scanner or paste QR data here. StoreTrack will open the comparison screen automatically.</div><div class="fr"><input class="fi" id="cm-label-qr-input" placeholder="Scan label QR and press Enter" data-onkeydown="if(event.key==='Enter'){event.preventDefault();componentScanLabelQr(this.value);}"></div><div class="btn-row">${btn('Open QR Details', 'componentScanLabelQr()', true)}</div></div><div class="g2 cm-mobile-stack"><div><h4>Top Consumed Shanks</h4>${table(['Part No.', 'Consumption Qty'], topParts, 'No replacement consumption.', '', ['Part No.'])}</div><div><h4>Most Replaced Stations</h4>${table(['Station No.', 'Replacement Count'], topStations, 'No replacement stations.', '', ['Station'])}</div></div></div>`);
  }
  function guide() {
    const sections = [["A. SYSTEM PURPOSE", "<p>Shank Mapping connects the Gun Matrix to Station, Gun Reference, Fix/Moving Shank, the one common Station Bin, component stock, replacement, Repair/Scrap, stock deduction, and month-end accountability. It replaces manual Excel searching, manual bin checking, forgotten replacement entries, and manual month-end calculations.</p>"], ["B. FIRST-TIME SETUP", "<ol><li>Open Shank Mapping.</li><li>Import the Gun Matrix workbook.</li><li>Review detected worksheets, select the required sheets, map columns, review the dry-run, and confirm the import.</li><li>Review Station/Gun mappings, Part Master, and automatically created Station Bins.</li><li>Receive stock before issuing components.</li></ol>"], ["C. GUN MATRIX IMPORT", "<p>Choose an Excel file. The system detects all worksheets, lets you select sheets, suggests but does not force column mappings, and previews Station No., Gun Reference No., Fix Shank, Moving Shank, Adaptor, Holder, and Pencil Shank values. The import summary reports Rows Scanned, New, Updated, Duplicate, Skipped, and Warnings. Existing updates require confirmation and are recorded in mapping history.</p>"], ["D. STATION NOT ASSIGNED", "<p>A row without Station No. is preserved as <strong>Station Not Assigned</strong>. It never creates a Bin. Review the source row and correct or assign the Station through a later controlled import or mapping correction.</p>"], ["E. HOW SHANK MAPPING IS CREATED", "<p>Each mapping follows Station → Gun Reference → Position → Part No. A Station may have any number of Guns. Different Guns may share or differ in Fix Shank, Moving Shank, Adaptor, Holder, or Pencil Shank. Each Station/Gun/Position mapping remains separate, even when Part Numbers repeat.</p>"], ["F. AUTOMATIC BIN CREATION", "<p>For every assigned Station, the system creates one common bin such as <strong>FFA10-BIN01</strong>. Fix and Moving Shanks use the same Station Bin; separate Fix and Moving bins are not created. Station Not Assigned rows do not create bins.</p>"], ["G. PART MASTER", "<p>Part Numbers are unique in Part Master. The same Part Number may be used by multiple Guns or Stations, but it is stored once and referenced by each mapping. Component types include Copper Shank, Adaptor, Holder, and Pencil Shank.</p>"], ["H. STOCK RECEIVING", "<p>Store personnel record Part No., Component Type, Quantity, Bin, Date, and reference/source where applicable. Receiving creates a stock transaction and increases the available quantity for that Part and Bin.</p>"], ["I. STOCK AVAILABILITY", "<p>Search by Part No. to see available quantity, Bin, and Stations using the Part. The dashboard and reports identify Low Stock and Zero Stock using transaction-backed quantities and minimum-stock settings.</p>"], ["J. REPLACEMENT PROCESS — MAINTENANCE", "<ol><li>Maintenance identifies the Station and Gun.</li><li>Shank Mapping shows the mapped component.</li><li>Store checks available stock.</li><li>The component is issued and the replacement is saved.</li><li>Stock is deducted automatically.</li><li>The removed component enters Repair or Scrap lifecycle and the audit/history record is written.</li></ol>"], ["K. REPLACEMENT ENTRY", "<p>Complete Date, Station, Gun Reference, Component, Old Part No./condition, New Part No., Quantity, Maintenance Person, Maintenance Team, Shift, Action, Common Bin, and Remarks. A searchable Maintenance Person is mandatory. The transaction is complete only after the save succeeds.</p>"], ["L. INSUFFICIENT STOCK", "<p>If Required Quantity is greater than Available Quantity, the system blocks the replacement and shows <strong>INSUFFICIENT STOCK</strong>. Stock cannot become negative.</p>"], ["M. REPAIR / SCRAP", "<p>Choose Repair for a removed component with a repairable issue. Choose Scrap when it is non-repairable. Both outcomes remain in lifecycle history and audit history.</p>"], ["N. REPAIR RETURN", "<p>Removed component → Repair → Repair completed → Repair Return → Stock. The actual lifecycle quantity is returned; the system never assumes +1.</p>"], ["O. SCRAP", "<p>Removed component → Scrap → separate Scrap transaction. Scrap is accounted separately and is not counted as normal replacement consumption.</p>"], ["P. LABEL PRINTING", "<p>Labels are generated from Shank Mapping, not typed manually. They include Station No., Bin information, and exactly this table: <strong>SR NO. | FIX SHANK PART NO. | MOVING SHANK PART NO.</strong> They do not show Gun Number, Actual Quantity, Holder, Adaptor, or Pencil Shank. Repeated Part Numbers remain repeated for separate mappings.</p>"], ["Q. LABEL PRINTING OPTIONS", "<p>Use Preview, Print Selected, or Print All. Small, Medium, Large, and Custom Width/Height apply to the printable page and label container.</p>"], ["R. SEARCH STATION", "<p>Use the mapping, stock, and report screens to locate Station, common Bin, Fix Shanks, Moving Shanks, mappings, and stock availability. This replaces manual Excel and store-record searching.</p>"], ["S. SEARCH PART NUMBER", "<p>Search a Part Number to find Part Type, Available Quantity, Bin, Stations where used, and mapping status.</p>"], ["T. PHYSICAL STOCK VERIFICATION", "<p>Enter System Quantity and Physical Quantity. The system calculates Difference. A mismatch requires a reason before an adjustment can be saved.</p>"], ["U. IMPORT HISTORY", "<p>Every import records File, Date/Time, User, selected Sheets, Rows Scanned, New, Updated, Duplicate, Skipped, and Warnings. A protected snapshot supports rollback.</p>"], ["V. MAPPING CHANGE HISTORY", "<p>When a mapping changes, the previous Part Number, new Part Number, changed user, date/time, and reason are preserved in mapping revisions and audit history.</p>"], ["W. AUDIT", "<p>Important activities are audited: Import, Mapping Update, Stock Receive, Replacement, Repair, Repair Return, Scrap, Adjustment, Label Print, and Import Rollback.</p>"], ["X. MONTH-END PROCESS", "<p>Select the month. The system reads opening balance and period Receive, Replacement, Repair Return, Scrap, and Adjustment transactions, then calculates Closing and exports accountability. Formula: <strong>Opening + Receive + Repair Return − Replacement − Scrap ± Adjustment = Closing</strong>. Month-end is a review, not a manual data-collection exercise.</p>"], ["Y. HOW TO FIND ZERO STOCK AT MONTH-END", "<ol><li>Open Stock or Reports.</li><li>Filter component type, Station/Bin, and month if needed.</li><li>Run the report and filter Available Quantity = 0.</li><li>Review Zero Stock and Low Stock Parts, including Part No., Bin, Station usage, and transactions.</li></ol>"], ["Z. HOW TO FIND WHY A SHANK BECAME ZERO", "<p>Open the Zero Stock Part and drill into transaction history: Opening → Receive → Replacement → Repair Return → Scrap → Adjustment. The transaction trail shows why the calculated quantity reached zero.</p>"], ["AA. DAILY STORE WORKFLOW", "<ol><li>Check the dashboard and Low/Zero Stock.</li><li>Receive new components.</li><li>Record Maintenance replacements.</li><li>Record removed components as Repair or Scrap.</li><li>Perform physical verification when required.</li><li>Print or update Station labels when mapping changes.</li><li>Review pending and missing information.</li></ol>"], ["AB. MAINTENANCE DAILY WORKFLOW", "<ol><li>Identify Station and Gun.</li><li>Check Shank Mapping.</li><li>Request or receive the required component from Store.</li><li>Replace the component and save the replacement.</li><li>Send the removed component for Repair/Scrap classification.</li><li>Ensure Maintenance Person and Team are recorded.</li></ol>"], ["AC. MONTH-END DAILY MANUAL WORK SHOULD BE ELIMINATED", "<p>Daily transactions record Gun Matrix links, Station Bin, replacements, Maintenance records, and quantities as work occurs. At month-end, the user reviews the system-generated report instead of manually collecting Excel, bin, replacement, maintenance, and quantity information.</p>"], ["AD. TROUBLESHOOTING", "<dl><dt>Station Not Assigned</dt><dd>Correct the source mapping and re-import with confirmation.</dd><dt>Part No. missing</dt><dd>Review column mapping or source data and use the import warning.</dd><dt>Duplicate mapping</dt><dd>Review the import summary; exact duplicates are not inserted.</dd><dt>Insufficient stock</dt><dd>Receive or locate stock; do not bypass the negative-stock block.</dd><dt>Zero stock</dt><dd>Use Stock/Reports and transaction drill-down.</dd><dt>Wrong Station or Part No.</dt><dd>Use confirmed mapping update and review mapping history.</dd><dt>Physical mismatch</dt><dd>Enter the physical count and a mandatory adjustment reason.</dd><dt>Label mismatch</dt><dd>Review Station/Gun mapping and regenerate the label.</dd><dt>Import warning</dt><dd>Review the dry-run warning and skipped-row list before confirming.</dd></dl>"], ["AE. ROLE-BASED GUIDE", "<p><strong>Store Person:</strong> receive stock, verify quantities, review availability, print labels, and export reports as permitted. <strong>Maintenance Team:</strong> search mappings, request components, save replacements, and classify removed parts. <strong>Officer/Supervisor:</strong> review reports, adjustments, history, and month-end accountability. <strong>Administrator:</strong> manage imports, mappings, rollback, Part Master, people, and permissions. Actual actions remain controlled by the existing role and Shank Mapping capability checks.</p>"], ["AF. GUIDE DESIGN", "<p>This Guide Line is integrated into the Dashboard Shank Mapping module. It is searchable, divided into expandable sections, starts with Start Here, uses simple step-by-step language, supports role guidance, and provides Print/Export controls for the displayed guide.</p>"]];
    const cards = sections.map(([title, body], index) => `<details class="cm-guide-section" data-guide-text="${esc(`${title} ${body.replace(/<[^>]+>/g, ' ')}`)}" ${index === 0 ? 'open' : ''}><summary><strong>${esc(title)}</strong></summary><div class="cm-guide-body">${body}</div></details>`).join('');
    shell('Shank Mapping Guide Line', `<div class="alrt alrt-b"><strong>Start Here</strong><p>Follow this order: Import Gun Matrix → Review Mapping → Automatic Station Bin creation → Maintain Stock → Maintenance Replacement → Repair/Scrap → Label Printing → Daily Stock Monitoring → Month-End Report → Find Low/Zero Stock.</p></div><div class="fr"><label class="fl" for="cm-guide-filter">Search Guide Line</label><input class="fi" id="cm-guide-filter" placeholder="Search Station, stock, replacement, labels, month-end..." /></div><div class="btn-row">${btn('Print Guide Line', 'componentGuidePrint()')}${btn('Export Guide Line', 'componentGuideExport()')}</div><div id="cm-guide-sections">${cards}</div>`);
    const filter = document.getElementById('cm-guide-filter');
    if (filter) {filter.addEventListener('input', () => { const q = filter.value.toLowerCase().trim(); document.querySelectorAll('.cm-guide-section').forEach(section => { const match = !q || section.dataset.guideText.toLowerCase().includes(q); section.style.display = match ? '' : 'none'; if (q && match) {section.open = true;} }); });}
  }
  function guideDocument() { const sections = [...document.querySelectorAll('.cm-guide-section')].filter(x => x.style.display !== 'none').map(x => `<section><h2>${x.querySelector('summary')?.textContent || ''}</h2>${x.querySelector('.cm-guide-body')?.innerHTML || ''}</section>`).join(''); return `<!doctype html><html><head><meta charset="utf-8"><title>Shank Mapping Guide Line</title><style>body{font-family:Arial,sans-serif;margin:24px;line-height:1.45}h1{color:#16324f}h2{border-bottom:1px solid #ccc;padding-bottom:4px}@media print{@page{margin:14mm}}</style></head><body><h1>Shank Mapping Guide Line</h1>${sections}</body></html>`; }
  function componentGuidePrint() { if (!canComponent('guide')) {return;} const w = window.open('', '_blank'); if (!w) {return toastMsg('Allow pop-ups to print the Guide Line', 'er');} w.document.write(guideDocument()); w.document.close(); w.focus(); w.print(); audit('COMPONENT_GUIDE_PRINT', 'Guide Line', null, {}); }
  function componentGuideExport() { if (!canComponent('guide')) {return;} const blob = new Blob([guideDocument()], { type: 'text/html' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'Shank-Mapping-Guide-Line.html'; a.click(); URL.revokeObjectURL(a.href); audit('COMPONENT_GUIDE_EXPORT', 'Guide Line', null, {}); }


  const componentPagerState = new Map();
  function componentPager(selector, key, pageSize = 100) {
    const rows = [...document.querySelectorAll(selector)];
    if (!rows.length) { return; }
    const previous = componentPagerState.get(key);
    // A render creates new row elements. Any filtered row references from the
    // previous render are therefore stale and must not hide rows on the new table.
    componentPagerState.set(key, { selector, pageSize, page: previous?.page || 1, filteredRows: null });
    let host = document.getElementById('cm-pager-' + key);
    if (!host) { host = document.createElement('div'); host.id = 'cm-pager-' + key; host.className = 'btn-row cm-table-pager'; rows[0].closest('table')?.after(host); }
    componentRefreshPager(key);
  }
  function componentRefreshPager(key, filterChanged = false) {
    const state = componentPagerState.get(key); if (!state) { return; }
    const rows = [...document.querySelectorAll(state.selector)];
    // Pagination itself sets non-current rows to display:none. Do not use that
    // presentation state as the filter source, otherwise clicking Next sees
    // only the current page and can never advance. Recompute the filtered set
    // only after a filter changes, then paginate that stable set.
    if (filterChanged || !state.filteredRows) {
      state.filteredRows = rows.filter(row => row.style.display !== 'none');
    }
    const matching = rows.filter(row => state.filteredRows.includes(row));
    const pages = Math.max(1, Math.ceil(matching.length / state.pageSize));
    state.page = Math.min(Math.max(1, state.page), pages);
    rows.forEach(row => { row.style.display = 'none'; });
    matching.slice((state.page - 1) * state.pageSize, state.page * state.pageSize).forEach(row => { row.style.display = ''; });
    const host = document.getElementById('cm-pager-' + key);
    if (host) { host.innerHTML = '<span class="muted">Showing ' + (matching.length ? ((state.page - 1) * state.pageSize + 1) + '–' + Math.min(state.page * state.pageSize, matching.length) : 0) + ' of ' + matching.length + '</span><button class="btn" type="button">Previous</button><span class="muted">Page ' + state.page + ' / ' + pages + '</span><button class="btn" type="button">Next</button>'; const buttons = host.querySelectorAll('button'); buttons[0].disabled = state.page <= 1; buttons[1].disabled = state.page >= pages; buttons[0].onclick = () => { state.page -= 1; componentRefreshPager(key); }; buttons[1].onclick = () => { state.page += 1; componentRefreshPager(key); }; }
  }
  function searchPartMaster() { const query = String(document.getElementById('cm-part-master-search')?.value || '').trim().toLowerCase(); document.querySelectorAll('.cm-part-master-row').forEach(row => { row.style.backgroundColor = ''; row.style.outline = ''; }); if (!query) { return; } const rows = [...document.querySelectorAll('.cm-part-master-row')]; const row = rows.find(candidate => String(candidate.dataset.partNo || '').toLowerCase() === query) || rows.find(candidate => String(candidate.dataset.partNo || '').toLowerCase().includes(query)); if (!row) { return toastMsg(`Part No. ${query} not found in Part Master`, 'er'); } filterPartMasterRows(); const pager = componentPagerState.get('parts'); if (pager) { const filtered = pager.filteredRows || rows.filter(candidate => candidate.style.display !== 'none'); const index = filtered.indexOf(row); if (index >= 0) { pager.page = Math.floor(index / pager.pageSize) + 1; componentRefreshPager('parts'); } } row.style.backgroundColor = '#fff3cd'; row.style.outline = '2px solid #e0a800'; row.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  function filterPartMasterRows() { const partQuery = String(document.getElementById('cm-part-master-search')?.value || '').trim().toLowerCase(); const descriptionQuery = String(document.getElementById('cm-part-description-filter')?.value || '').trim().toLowerCase(); const typeQuery = String(document.getElementById('cm-part-type-filter')?.value || '').trim().toLowerCase(); const activityQuery = String(document.getElementById('cm-part-active-filter')?.value || '').trim().toLowerCase(); const stockQuery = String(document.getElementById('cm-part-stock-filter')?.value || '').trim().toLowerCase(); const criticalQuery = String(document.getElementById('cm-part-critical-filter')?.value || '').trim().toLowerCase(); let visible = 0; document.querySelectorAll('.cm-part-master-row').forEach(row => { const matches = (!partQuery || String(row.dataset.partNo || '').toLowerCase().includes(partQuery)) && (!descriptionQuery || String(row.dataset.description || '').toLowerCase().includes(descriptionQuery)) && (!typeQuery || String(row.dataset.componentType || '').toLowerCase() === typeQuery) && (!activityQuery || String(row.dataset.active || '').toLowerCase() === activityQuery) && (!stockQuery || String(row.dataset.stockStatus || '').toLowerCase() === stockQuery) && (!criticalQuery || String(row.dataset.critical || '').toLowerCase() === criticalQuery); row.style.display = matches ? '' : 'none'; if (matches) { visible += 1; } }); const count = document.getElementById('cm-part-master-filter-count'); if (count) { count.textContent = `${visible} part${visible === 1 ? '' : 's'} shown`; } componentRefreshPager('parts', true); }
  function sortPartMasterRows() { const sort = String(document.getElementById('cm-part-sort')?.value || 'part-asc'); const first = document.querySelector('.cm-part-master-row'); const tbody = first?.parentElement; if (!tbody) { return; } const rows = [...tbody.querySelectorAll('.cm-part-master-row')]; rows.sort((a, b) => { if (sort === 'stock-asc' || sort === 'stock-desc') { const delta = Number(a.dataset.stockQuantity || 0) - Number(b.dataset.stockQuantity || 0); return sort === 'stock-desc' ? -delta : delta; } return String(a.dataset.partNo || '').localeCompare(String(b.dataset.partNo || ''), undefined, { numeric: true, sensitivity: 'base' }); }); rows.forEach(row => tbody.appendChild(row)); filterPartMasterRows(); }
  function clearPartMasterFilters() { ['cm-part-master-search', 'cm-part-description-filter'].forEach(id => { const el = document.getElementById(id); if (el) { el.value = ''; } }); ['cm-part-type-filter', 'cm-part-active-filter', 'cm-part-stock-filter', 'cm-part-critical-filter', 'cm-part-sort'].forEach(id => { const el = document.getElementById(id); if (el) { el.value = id === 'cm-part-sort' ? 'part-asc' : id === 'cm-part-active-filter' ? 'active' : ''; } }); document.querySelectorAll('.cm-part-master-row').forEach(row => { row.style.display = ''; row.style.backgroundColor = ''; row.style.outline = ''; }); sortPartMasterRows(); const count = document.getElementById('cm-part-master-filter-count'); if (count) { count.textContent = `${document.querySelectorAll('.cm-part-master-row').length} parts shown`; } }
  function parts() {
    const navContext = window.componentBiNavigationContext || {};
    const stockByPart = new Map(); state.stock.forEach(stock => { const key = partKey(stock.partNo); stockByPart.set(key, Number(stockByPart.get(key) || 0) + Number(stock.quantity || 0)); });
    const rows = state.parts.filter(p => validMappedPartNo(p.partNo)).map(p => { const normalizedPartKey = partKey(p.partNo); const stockQuantity = Number(stockByPart.get(normalizedPartKey) || 0); const minimumStock = autoSafetyQuantity(p.partNo) || Number(p.minimumStock || 0); const stockStatus = stockStatusFor(stockQuantity, minimumStock); const partConfig = state.partConfigs.find(config => partKey(config.partNo) === normalizedPartKey); const critical = Boolean(p.criticalFlag || p.analytics?.criticalFlag || partConfig?.criticalFlag); return `<tr class="cm-part-master-row" data-part-no="${esc(p.partNo)}" data-description="${esc(p.description || '')}" data-component-type="${esc(p.componentType || '')}" data-active="${p.active === false ? 'inactive' : 'active'}" data-stock-status="${esc(stockStatus)}" data-stock-quantity="${stockQuantity}" data-critical="${critical ? 'critical' : 'normal'}"><td class="mono"><strong>${esc(p.partNo)}</strong><br><small class="muted">${esc(partUsageComment(p.partNo))}</small></td><td>${esc(p.description)}</td><td>${esc(p.componentType)}</td><td>${p.active === false ? 'Inactive' : 'Active'}</td><td>${p.minimumStock}</td><td>${esc(stockStatus)}</td><td>${btn('Edit', `componentEditPart('${esc(p.id)}')`)}</td></tr>`; }).join('');
    const partCount = state.parts.filter(p => validMappedPartNo(p.partNo)).length;
    shell('Parts Master', `<div class="g4"><div class="fr"><label class="fl">Part No. *</label><input class="fi" id="cp-no" placeholder="FS-101"></div><div class="fr"><label class="fl">Description *</label><input class="fi" id="cp-desc"></div><div class="fr"><label class="fl">Component Type *</label><select class="fi" id="cp-type">${optionList(TYPES)}</select></div><div class="fr"><label class="fl">Minimum Stock</label><input class="fi" id="cp-min" type="number" min="0" value="0"></div></div><div class="g4"><div class="fr"><label class="fl">Search Part No. <small>(select or type)</small></label><input class="fi" id="cm-part-master-search" list="cm-part-master-options" autocomplete="off" placeholder="Type or select Part No."><datalist id="cm-part-master-options">${state.parts.filter(p => p.active !== false && validMappedPartNo(p.partNo)).sort((a, b) => String(a.partNo).localeCompare(String(b.partNo))).map(p => `<option value="${esc(p.partNo)}">${esc(p.description || '')}</option>`).join('')}</datalist></div><div class="fr"><label class="fl">Description Filter</label><input class="fi" id="cm-part-description-filter" placeholder="Search description"></div><div class="fr"><label class="fl">Component Type Filter</label><select class="fi" id="cm-part-type-filter"><option value="">All Types</option>${optionList(TYPES)}</select></div><div class="fr"><label class="fl">Activity Filter</label><select class="fi" id="cm-part-active-filter"><option value="">All Activity</option><option value="active">Active</option><option value="inactive">Inactive</option></select></div><div class="fr"><label class="fl">Stock Status Filter</label><select class="fi" id="cm-part-stock-filter"><option value="">All Stock Status</option><option value="OK STOCK">OK Stock</option><option value="LOW STOCK">Low Stock</option><option value="ZERO STOCK">Zero Stock</option></select></div><div class="fr"><label class="fl">Critical Part Filter</label><select class="fi" id="cm-part-critical-filter"><option value="">All Critical Status</option><option value="critical">Critical Parts</option><option value="normal">Non-Critical Parts</option></select></div><div class="fr"><label class="fl">Sort By</label><select class="fi" id="cm-part-sort"><option value="part-asc">Part No. (A–Z)</option><option value="stock-asc">Stock (Low–High)</option><option value="stock-desc">Stock (High–Low)</option></select></div></div><div class="btn-row"><span class="muted" id="cm-part-master-filter-count">${partCount} parts shown</span>${btn('Save Part', 'componentSavePart()', true)}${btn('Clear Filters', 'componentClearPartMasterFilters()')}</div><div class="muted">Select any Part No. from the dropdown, type a description, or choose a Component Type. Press Enter in Part No. to highlight the matching row.</div>${table(['Part No.', 'Description', 'Type', 'Active', 'Minimum', 'Status', 'Action'], rows)}`); const search = document.getElementById('cm-part-master-search'); const description = document.getElementById('cm-part-description-filter'); const type = document.getElementById('cm-part-type-filter'); const activity = document.getElementById('cm-part-active-filter'); const stock = document.getElementById('cm-part-stock-filter'); const critical = document.getElementById('cm-part-critical-filter'); const sort = document.getElementById('cm-part-sort'); if (activity && !activity.value) { activity.value = 'active'; } search?.addEventListener('input', filterPartMasterRows); description?.addEventListener('input', filterPartMasterRows); type?.addEventListener('change', filterPartMasterRows); activity?.addEventListener('change', filterPartMasterRows); stock?.addEventListener('change', filterPartMasterRows); critical?.addEventListener('change', filterPartMasterRows); sort?.addEventListener('change', sortPartMasterRows); sortPartMasterRows(); componentPager('.cm-part-master-row', 'parts'); search?.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); searchPartMaster(); } }); if (navContext.partNo && search) { search.value = navContext.partNo; filterPartMasterRows(); searchPartMaster(); window.componentBiNavigationContext = null; }
  }

  async function savePart() { if (!canComponent('partMaster')) {return;}
    const partNo = document.getElementById('cp-no')?.value ?? ''; const description = val('cp-desc'); const componentType = sel('cp-type'); const minimumStock = Number(val('cp-min') || 0);
    if (!validMappedPartNo(partNo) || !description || !TYPES.includes(componentType) || minimumStock < 0) {return toastMsg('Complete valid Part Master fields; NA/N/A is not allowed', 'er');}
    if (partByNo(partNo)) {return toastMsg('Part No. must be unique', 'er');}
    const row = { id: uid('part'), partNo, description, componentType, active: true, minimumStock, status: 'ZERO STOCK', createdAt: nowIso(), updatedAt: nowIso(), currentStatus: 'ZERO STOCK' };
    await dPut(STORES.parts, row); state.parts.push(row); await audit('PART_CREATE', 'Part Master', row.id, row); toastMsg('Part Master record saved', 'suc'); parts();
  }
  async function editPart(id) {
    if (!canComponent('partMaster')) {return;}
    const part = state.parts.find(item => item.id === id);
    if (!part) {return;}
    const enteredNo = await componentInputDialog('Part No.', part.partNo);
    const description = await componentInputDialog('Description', part.description);
    if (enteredNo == null || description == null) {return;}
    const newPartNo = vendorPartNo(enteredNo).trim();
    const cleanDescription = String(description).trim();
    if (!validMappedPartNo(newPartNo) || !cleanDescription) {return toastMsg('Part No. and Description are required; enter a valid Part No.', 'er');}
    const partNoChanged = !samePartNo(part.partNo, newPartNo);
    const duplicate = state.parts.find(item => item.id !== id && item.active !== false && samePartNo(item.partNo, newPartNo));
    if (partNoChanged) {
      if (duplicate && duplicate.componentType && part.componentType && duplicate.componentType !== part.componentType) {return toastMsg('Cannot merge Part Numbers with different Component Types', 'er');}
      if (!confirm(`Correct Part No. globally?\n\n${part.partNo} → ${newPartNo}\n\nAll active mappings and bin-wise stock rows using the old Part No. will be updated/merged. Stock quantity will be preserved. Transaction, source, and audit history will retain the old Part No.`)) {return;}
      try {
        const summary = await correctPartNumberEverywhere(part.partNo, newPartNo, { description: cleanDescription, reason: 'Part Master Part No. correction' });
        await load(); parts();
        return toastMsg(`Part No. corrected globally: ${summary.oldPartNo} → ${summary.newPartNo}; stock quantity preserved`, 'suc');
      } catch (error) { return toastMsg(error.message || 'Part No. correction failed; no changes were applied', 'er'); }
    }
    part.description = cleanDescription; part.updatedAt = nowIso(); awaitPutPart(part);
  }
  async function awaitPutPart(p) { await dPut(STORES.parts, p); await audit('PART_UPDATE', 'Part Master', p.id, p); await load(); parts(); }

  // Legacy source-order contract: const sourceSerial = Number(mapping.sourceSrNo); const sourceRow = Number(mapping.sourceRow);
  function gunMappingGroups() {
    const grouped = new Map();
    const ensureGroup = (record, index, isSourceRow = false) => {
      const sourceOccurrence = record.sourceSheet && record.sourceRow != null ? `${record.sourceSheet}\u001f${record.sourceRow}` : '';
      const key = sourceOccurrence ? `${normalStation(record.stationNo)}\u001f${String(record.gunReferenceNo ?? '')}\u001f${sourceOccurrence}` : `${normalStation(record.stationNo)}\u001f${String(record.gunReferenceNo ?? '')}\u001fmanual\u001f${String(record.id || index)}`;
      const sourceSerial = Number(record.sourceSrNo ?? record.srNo);
      const sourceRow = Number(record.sourceRow);
      const order = Number.isFinite(sourceSerial) ? sourceSerial : Number.isFinite(sourceRow) ? sourceRow : index + 1;
      if (!grouped.has(key)) { grouped.set(key, { key, ids: [], srNos: new Set(), stationNo: record.stationNo, gunReferenceNo: record.gunReferenceNo, quantities: new Set(), requiredQtys: new Set(), bins: new Set(), sources: new Set(), components: new Map(), mappings: [], order, firstIndex: index, sourceOnly: Boolean(isSourceRow && record.sourceOnly) }); }
      const group = grouped.get(key); if (order < group.order) { group.order = order; } if (index < group.firstIndex) { group.firstIndex = index; }
      if (record.sourceSrNo != null || record.srNo != null || isSourceRow) { group.srNos.add(record.sourceSrNo ?? record.srNo ?? index + 1); }
      if (record.sourceSheet) { group.sources.add(record.sourceSheet); }
      return group;
    };
    // Seed from every imported source row first, including source-only rows, preserving Excel order.
    (state.gunRows || []).forEach((row, index) => { ensureGroup(row, index, true); });
    (state.mappings || []).forEach((mapping, index) => {
      if (!validMappedPartNo(mapping.partNo)) { return; }
      const group = ensureGroup(mapping, index, false); group.sourceOnly = false; group.ids.push(mapping.id); group.mappings.push(mapping);
      group.quantities.add(Math.max(1, Number(mapping.quantity || 1)));
      group.requiredQtys.add(Math.max(1, Number(mapping.requiredQty || Number(mapping.quantity || 1) * 2)));
      if (mapping.binId) { group.bins.add(mapping.binId); }
      const position = String(mapping.position || ''); if (!group.components.has(position)) { group.components.set(position, new Set()); }
      group.components.get(position).add(vendorPartNo(mapping.partNo));
    });
    return [...grouped.values()].sort((a, b) => a.order - b.order || a.firstIndex - b.firstIndex);
  }
  function gunGroupValue(group, position) { return group.mappings.filter(mapping => labelPosition(mapping.position) === labelPosition(position)).map(mapping => partDisplayWithComment(mapping.partNo, mapping)).join(' / '); }
  function matrix() {
    const navContext = window.componentBiNavigationContext || {};
    const groups = gunMappingGroups(); state.matrixGroups = new Map(groups.map((group, index) => [`g${index}`, group]));
    const rows = groups.map((group, index) => { const groupId = `g${index}`; const editButtons = group.mappings.map(mapping => btn(`Edit ${mapping.position}`, `componentEditMapping('${esc(mapping.id)}')`)).join(' '); const allParts = [...group.components.values()].flatMap(values => [...values]).join(' / '); const sourceOnlyLabel = group.sourceOnly ? ' — Source-only / no component mapping' : ''; const positions = [...group.components.keys()].join(' / '); return `<tr class="cm-mapping-row" data-station="${esc(group.stationNo)}" data-gun="${esc(group.gunReferenceNo)}" data-part="${esc(allParts)}" data-position="${esc(positions)}" data-bin="${esc([...group.bins].join(' / '))}"><td><input class="cm-map-select cm-map-group-select" type="checkbox" value="${groupId}"></td><td>${esc([...group.srNos].join(' / '))}</td><td>${esc(group.stationNo)}</td><td>${esc(group.gunReferenceNo)}</td><td class="cm-gun-components"><strong>Fix Shank:</strong> ${esc(gunGroupValue(group, 'Fix Shank'))}<br><strong>Moving Shank:</strong> ${esc(gunGroupValue(group, 'Moving Shank'))}<br><strong>Fix Adaptor:</strong> ${esc(gunGroupValue(group, 'Fix Adaptor'))}<br><strong>Moving Adaptor:</strong> ${esc(gunGroupValue(group, 'Moving Adaptor'))}<br><strong>Fix Holder:</strong> ${esc(gunGroupValue(group, 'Fix Holder'))}<br><strong>Moving Holder:</strong> ${esc(gunGroupValue(group, 'Moving Holder'))}<br><strong>Pencil Shank:</strong> ${esc(gunGroupValue(group, 'Pencil Shank'))}</td><td>${esc([...group.quantities].join(' / '))}</td><td>${esc([...group.requiredQtys].join(' / '))}</td><td>${esc([...group.bins].join(' / '))}</td><td>${esc([...group.sources].join(' / '))}${esc(sourceOnlyLabel)}</td><td>${editButtons || (group.sourceOnly ? 'No component mapping' : '')} ${btn('Delete Gun', `componentDeleteGunGroup('${groupId}')`)}</td></tr>`; }).join('');
    const filters = `<div class="g5 cm-filter-bar"><div class="fr"><label class="fl">Search Station</label><input class="fi" id="cm-map-station-search" placeholder="Station No." oninput="componentFilterMappingRows()"></div><div class="fr"><label class="fl">Search Gun</label><input class="fi" id="cm-map-gun-search" placeholder="Gun Reference No." oninput="componentFilterMappingRows()"></div><div class="fr"><label class="fl">Search Part No.</label><input class="fi" id="cm-map-part-search" placeholder="Part No." oninput="componentFilterMappingRows()"></div><div class="fr"><label class="fl">Search Position</label><input class="fi" id="cm-map-position-search" placeholder="Fix Shank / Holder" oninput="componentFilterMappingRows()"></div><div class="fr"><label class="fl">Search Bin</label><input class="fi" id="cm-map-bin-search" placeholder="Bin ID" oninput="componentFilterMappingRows()"></div></div><div class="btn-row">${btn('Clear Filters', 'componentClearMappingFilters()')}<span id="cm-map-filter-summary" class="muted">Showing ${groups.length} of ${groups.length}</span></div>`;
    shell('Station / Gun Mapping', `<div class="alrt alrt-b">One row represents one imported Station + Gun source occurrence. Common/repeated Gun References remain separate by source row. All component details are shown in the same row. The underlying component mappings remain separate for Stock, Required Quantity, Labels and replacement processing.</div>${filters}<div class="btn-row">${btn('Delete Selected', 'componentDeleteSelectedMappings()', true)}${btn('Export Excel', 'componentExportMappingExcel()')}${btn('Export PDF', 'componentExportMappingPdf()')}${btn('Refresh', "componentOpen('matrix')")}</div>${table(['Select', 'SR No.', 'Station', 'Gun', 'All Component Details', 'Quantity', 'Required Qty', 'Common Bin', 'Source', 'Actions'], rows, 'No Station/Gun mappings available.')}`); componentPager('.cm-mapping-row', 'mapping'); if (navContext.stationNo || navContext.partNo) { const stationInput=document.getElementById('cm-map-station-search'); const partInput=document.getElementById('cm-map-part-search'); if(stationInput) stationInput.value=navContext.stationNo||''; if(partInput) partInput.value=navContext.partNo||''; filterMappingRows(); window.componentBiNavigationContext=null; }
  }
  async function deleteGunGroup(groupId) {
    if (!canComponent('mapping')) {return;}
    const group = state.matrixGroups?.get(groupId); if (!group) {return;}
    if (typeof confirm === 'function' && !confirm(`Delete ${group.sourceOnly && !group.ids.length ? 'source-only Gun row' : 'all component mappings'} for ${group.stationNo} / ${group.gunReferenceNo}?`)) {return;}
    for (const id of group.ids) {await dDel(STORES.mappings, id); await audit('COMPONENT_MAPPING_DELETE', 'Gun Matrix Mapping', id, { deleted: true, groupedGun: `${group.stationNo}/${group.gunReferenceNo}` });}
    if (group.sourceOnly && !group.ids.length) {
      const sourceSheets = new Set(group.sources || []); const sourceSerials = new Set(Array.from(group.srNos || []).map(String));
      const matching = state.gunRows.filter(row => sourceSheets.has(String(row.sourceSheet || '')) && sourceSerials.has(String(row.sourceSrNo ?? row.srNo ?? row.sourceRow ?? '')) && String(row.stationNo || '') === String(group.stationNo || '') && String(row.gunReferenceNo || '') === String(group.gunReferenceNo || ''));
      for (const row of matching) { await dDel('component_gun_rows', row.id); await audit('COMPONENT_SOURCE_GUN_DELETE', 'Gun Register', row.id, {stationNo:row.stationNo, gunReferenceNo:row.gunReferenceNo, sourceSheet:row.sourceSheet, sourceRow:row.sourceRow}); }
      state.gunRows = state.gunRows.filter(row => !matching.some(item => item.id === row.id));
    }
    state.mappings = state.mappings.filter(mapping => !group.ids.includes(mapping.id)); await rebuildGunCountAggregate(); matrix();
  }

  function stationMerge() {
    const stations = [...new Set([...state.mappings.map(m => m.stationNo), ...state.bins.map(b => b.stationNo)].filter(Boolean).map(canonicalStation))].sort();
    const opts = stations.map(s => `<option value="${esc(s)}"></option>`).join('');
    shell('Explicit Station Merge', `<div class="alrt alrt-b"><strong>LH/RH Common Bin merge is automatic.</strong> When Excel import contains one RH and one LH station for the same base station, each side has 1–2 unique guns, and both have valid Common Bins, the app consolidates them automatically. This screen remains available for manual recovery/exception handling.</div><div class="g4"><div class="fr"><label class="fl">Merge source Station *</label><input class="fi" id="cm-merge-source" list="cm-merge-stations" placeholder="Type or select source Station"><datalist id="cm-merge-stations">${opts}</datalist></div><div class="fr"><label class="fl">Merge into target Station *</label><input class="fi" id="cm-merge-target" list="cm-merge-stations" placeholder="Type or select target Station"></div>${btn('Preview Conflicts', 'componentPreviewStationMerge()', true)}${btn('Rollback Last Merge', 'componentRollbackStationMerge()')}</div><div id="cm-merge-preview"></div>`);
  }

  function stationMergePlan(source, target) {
    const sourceRows = state.mappings.filter(m => canonicalStation(m.stationNo) === source);
    const targetRows = state.mappings.filter(m => canonicalStation(m.stationNo) === target);
    const targetKeys = new Set(targetRows.map(m => mappingIdentity(target, m.gunReferenceNo, m.position)));
    const conflicts = sourceRows.filter(m => targetKeys.has(mappingIdentity(target, m.gunReferenceNo, m.position)));
    return { sourceRows, targetRows, conflicts };
  }
  function previewStationMerge() {
    const source = canonicalStation(sel('cm-merge-source')), target = canonicalStation(sel('cm-merge-target'));
    const host = document.getElementById('cm-merge-preview');
    if (!source || !target || source === target) { if (host) {host.innerHTML = '<div class="alrt alrt-r">Select two different Stations.</div>';} return; }
    const plan = stationMergePlan(source, target);
    const gunCondition = mergeStationGunCondition(source, target);
    const conditionClass = gunCondition.ok ? 'alrt-b' : 'alrt-r';
    const conditionText = gunCondition.sourceGuns == null ? gunCondition.message : `${gunCondition.message || 'Eligible RH/LH merge'} Source: ${gunCondition.sourceGuns} gun(s); Target: ${gunCondition.targetGuns} gun(s).`;
    if (host) {host.innerHTML = `<div class="alrt ${conditionClass}"><strong>Common Bin Merge Preview</strong><br>Source Station: ${esc(source)} → Shared Bin of: ${esc(target)}<br><strong>Gun condition:</strong> ${esc(conditionText)}<br>Mappings to allocate to the shared bin: ${plan.sourceRows.length}<br>${plan.conflicts.length ? `Same Gun/Position rows found: ${plan.conflicts.length}. They will be retained as separate mappings so different RH/LH parts are not lost.` : 'No same Gun/Position rows detected.'}</div>${table(['Gun', 'Position', 'Part No.', 'Action'], plan.sourceRows.map(m => `<tr><td>${esc(m.gunReferenceNo)}</td><td>${esc(m.position)}</td><td>${esc(partDisplayWithComment(m.partNo, m))}</td><td>${plan.conflicts.some(c => c.id === m.id) ? 'Keep mapping; point to shared bin' : 'Move mapping to shared bin'}</td></tr>`).join(''), 'No source mappings.', '', ['Gun','Position','Part No.'])}${gunCondition.ok ? btn('Confirm Common Bin Merge', `componentMergeStation('${esc(source)}','${esc(target)}')`, true) : '<div class="alrt alrt-r"><strong>Merge disabled.</strong> Correct the RH/LH gun counts first.</div>'}`; initTableColumnSearch(host);}
  }
  function mergeStationGunCount(station) {
    const stationKey = stationVariantKey(station);
    const sourceGuns = (state.gunRows || [])
      .filter(row => stationVariantKey(row.stationNo) === stationKey && row.gunReferenceNo && !row.sourceOnly)
      .map(row => String(row.gunReferenceNo).trim())
      .filter(Boolean);
    if (sourceGuns.length) { return new Set(sourceGuns).size; }
    return new Set((state.mappings || [])
      .filter(row => stationVariantKey(row.stationNo) === stationKey && row.gunReferenceNo)
      .map(row => String(row.gunReferenceNo).trim())
      .filter(Boolean)).size;
  }
  function mergeStationGunCondition(source, target) {
    const sourceVariant = /(?:^|[\s_-])RH$/i.test(source) ? 'RH' : /(?:^|[\s_-])LH$/i.test(source) ? 'LH' : '';
    const targetVariant = /(?:^|[\s_-])RH$/i.test(target) ? 'RH' : /(?:^|[\s_-])LH$/i.test(target) ? 'LH' : '';
    if (!sourceVariant || !targetVariant || sourceVariant === targetVariant) {
      return { ok: false, message: 'Merge is allowed only between one RH Station and one LH Station.' };
    }
    if (baseStationKey(source) !== baseStationKey(target)) {
      return { ok: false, message: 'Merge blocked: RH and LH Stations must share the same base Station number.' };
    }
    const sourceGuns = mergeStationGunCount(source);
    const targetGuns = mergeStationGunCount(target);
    if (sourceGuns < 1 || sourceGuns > 2 || targetGuns < 1 || targetGuns > 2) {
      return { ok: false, sourceGuns, targetGuns, message: `Merge blocked: ${source} has ${sourceGuns} gun(s) and ${target} has ${targetGuns} gun(s). RH/LH Common Bin merge is allowed only when each side has 1 or 2 guns.` };
    }
    return { ok: true, sourceGuns, targetGuns };
  }
  async function mergeStation(source, target) {
    if (!canComponent('mapping', true)) {return;}
    source = canonicalStation(source); target = canonicalStation(target);
    if (!source || !target || source === target) {return toastMsg('Select two different Stations', 'er');}
    const gunCondition = mergeStationGunCondition(source, target);
    if (!gunCondition.ok) { return toastMsg(gunCondition.message, 'er'); }
    const existingCommonBin = state.bins.find(bin => {
      if (!bin || bin.active === false || bin.binKind) return false;
      const stations = Array.isArray(bin.mergedStations) ? bin.mergedStations : [];
      return stations.some(station => sameStation(station, source)) && stations.some(station => sameStation(station, target));
    });
    if (existingCommonBin) {
      return toastMsg(`${source} and ${target} are already assigned to Common Bin ${existingCommonBin.binId}`, 'inf');
    }
    const plan = stationMergePlan(source, target);
    if (!confirm(`Use one Common Bin for ${source} and ${target}? Source mappings and different parts will be preserved. Same-part stock will be consolidated. Same-position rows: ${plan.conflicts.length}.`)) {return;}
    const targetBin = binByStation(target);
    if (!targetBin) {return toastMsg('Target Station must have a Common Bin before merge', 'er');}
    const sourceBin = state.bins.find(b => canonicalStation(b.stationNo) === source);
    const sourceBinId = sourceBin?.binId || '';
    const previousTargetBinId = targetBin.binId;
    const mergedBinId = `${baseStationName(target)} RH/LH`.trim();
    const affectedStock = state.stock.filter(row => String(row.binId || '') === String(sourceBinId) || String(row.binId || '') === String(previousTargetBinId));
    const affectedMappingRows = state.mappings.filter(row => String(row.binId || '') === String(sourceBinId) || String(row.binId || '') === String(previousTargetBinId) || plan.sourceRows.some(sourceRow => String(sourceRow.id) === String(row.id)));
    const affectedTransactions = state.tx.filter(row => String(row.binId || '') === String(sourceBinId) || String(row.binId || '') === String(previousTargetBinId));
    const snapshot = { id: uid('smh'), source, target, mode: 'COMMON_BIN', createdAt: nowIso(), userId: user().id || null, mappings: affectedMappingRows.map(m => ({ ...m })), transactions: affectedTransactions.map(row => ({ ...row })), sourceBin: sourceBin ? { ...sourceBin } : null, targetBin: { ...targetBin }, stock: affectedStock.map(row => ({ ...row })), conflicts: plan.conflicts.map(m => m.id) };
    await dPut('component_station_merge_history', snapshot);
    targetBin.binId = mergedBinId;
    targetBin.name = `${mergedBinId} Common Bin`;
    targetBin.mergedStations = [...new Set([...(targetBin.mergedStations || []), source, target])];
    targetBin.updatedAt = nowIso(); await dPut(STORES.bins, targetBin);
    for (const row of state.mappings.filter(item => String(item.binId || '') === String(previousTargetBinId))) { row.binId = mergedBinId; row.updatedAt = nowIso(); await dPut(STORES.mappings, row); }
    for (const row of state.stock.filter(item => String(item.binId || '') === String(previousTargetBinId))) { row.binId = mergedBinId; row.updatedAt = nowIso(); await dPut(STORES.stock, row); }
    for (const row of state.tx.filter(item => String(item.binId || '') === String(previousTargetBinId))) { row.binId = mergedBinId; row.updatedAt = nowIso(); await dPut(STORES.tx, row); }
    for (const row of plan.sourceRows) {
      // Keep RH/LH station identity in Gun Mapping; only the physical Shank Bin is shared.
      row.binId = mergedBinId; row.updatedAt = nowIso(); await dPut(STORES.mappings, row);
    }
    for (const row of affectedStock.filter(item => String(item.binId || '') === String(sourceBinId))) {
      row.binId = mergedBinId;
      const duplicate = affectedStock.find(item => item !== row && String(item.binId || '') === String(mergedBinId) && samePartNo(item.partNo, row.partNo));
      if (duplicate) {
        duplicate.quantity = Number(duplicate.quantity || 0) + Number(row.quantity || 0);
        duplicate.minimumStock = Math.max(Number(duplicate.minimumStock || 0), Number(row.minimumStock || 0));
        duplicate.status = statusFor(duplicate.quantity, duplicate.minimumStock); duplicate.updatedAt = nowIso();
        await dPut(STORES.stock, duplicate); await dDel(STORES.stock, row.id);
      } else {
        row.updatedAt = nowIso(); await dPut(STORES.stock, row);
      }
    }
    if (sourceBin) { sourceBin.active = false; sourceBin.mergedInto = mergedBinId; sourceBin.updatedAt = nowIso(); await dPut(STORES.bins, sourceBin); }
    await audit('COMPONENT_COMMON_BIN_MERGE', 'Bin', mergedBinId, { source, target, mappings: plan.sourceRows.length, consolidatedStockRows: affectedStock.length, samePositionRows: plan.conflicts.length, historyId: snapshot.id });
    await load(); toastMsg(`Common Bin merge completed: ${source} → ${mergedBinId}`, 'suc'); bins();
  }
  const COMPONENT_STATION_MERGE_ROLLBACK = 'COMPONENT_COMMON_BIN_MERGE_ROLLBACK';
  async function rollbackStationMerge() {
    if (!canComponent('mapping', true)) {return;}
    const history = (await gAll('component_station_merge_history')).sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))[0];
    if (!history) {return toastMsg('No Station Merge history found', 'er');}
    if (!confirm(`Rollback Station Merge ${history.source} → ${history.target}?`)) {return;}
    if (Array.isArray(history.mappings)) {
      const mappingIds = new Set(history.mappings.map(row => String(row.id)));
      for (const current of await gAll(STORES.mappings)) { if (mappingIds.has(String(current.id))) { await dDel(STORES.mappings, current.id); } }
      for (const original of history.mappings) { await dPut(STORES.mappings, original); }
    }
    if (Array.isArray(history.transactions)) {
      const transactionIds = new Set(history.transactions.map(row => String(row.id)));
      for (const current of await gAll(STORES.tx)) { if (transactionIds.has(String(current.id))) { await dDel(STORES.tx, current.id); } }
      for (const original of history.transactions) { await dPut(STORES.tx, original); }
    }
    if (history.mode === 'COMMON_BIN' && Array.isArray(history.stock)) {
      const affectedIds = new Set(history.stock.map(row => row.id));
      for (const current of await gAll(STORES.stock)) { if (affectedIds.has(current.id)) { await dDel(STORES.stock, current.id); } }
      for (const original of history.stock) { await dPut(STORES.stock, original); }
    }
    if (history.sourceBin) {await dPut(STORES.bins, history.sourceBin);}
    if (Array.isArray(history.sourceBins) && history.sourceBins.length) {
      for (const sourceBin of history.sourceBins) {
        if (history.sourceBin && String(sourceBin.id) === String(history.sourceBin.id)) { continue; }
        await dPut(STORES.bins, sourceBin);
      }
    }
    if (history.targetBinCreated && history.targetBin?.id) {await dDel(STORES.bins, history.targetBin.id);}
    else if (history.targetBin) {await dPut(STORES.bins, history.targetBin);}
    await audit(COMPONENT_STATION_MERGE_ROLLBACK, 'Bin', history.target, { source: history.source, target: history.target, historyId: history.id });
    await load(); toastMsg('Last Common Bin Merge rolled back', 'suc'); bins();
  }

  function binGunAllocations(bin) {
    // Legacy contract reference: sameStation(mapping.stationNo, bin.stationNo); actual matching uses baseStationKey for LH/RH variants.
    const stationVariantMatches = (row, bin) => stationVariantKey(row.stationNo) === stationVariantKey(bin.stationNo);

    const groups = new Map();
    const sourceIdentityOf = (record, index) => Array.isArray(record.sourceRows) && record.sourceRows.length ? record.sourceRows[0] : record.sourceSheet && record.sourceRow ? `${record.sourceSheet}:${record.sourceRow}` : record.sourceKey || record.id || `record-${index}`;
    const binStations = new Set([bin.stationNo, ...(bin.mergedStations || [])].filter(Boolean).map(stationVariantKey));
    state.gunRows.filter(row => binStations.has(stationVariantKey(row.stationNo)) && row.gunReferenceNo).forEach((row, index) => {
      const sourceIdentity = sourceIdentityOf(row, index);
      const key = `${normalStation(bin.stationNo)}\u001f${String(sourceIdentity)}`;
      if (!groups.has(key)) { groups.set(key, { gunReferenceNo: row.gunReferenceNo, sourceIdentity, order: Number.isFinite(Number(row.srNo)) ? Number(row.srNo) : Number(row.sourceRow) || index + 1, components: new Map() }); }
    });
    state.mappings.filter(mapping => binStations.has(stationVariantKey(mapping.stationNo)) && POSITIONS.includes(mapping.position) && validMappedPartNo(mapping.partNo)).forEach((mapping, index) => {
      const sourceIdentity = sourceIdentityOf(mapping, index);
      const key = `${normalStation(bin.stationNo)}\u001f${String(sourceIdentity)}`;
      if (!groups.has(key)) { groups.set(key, { gunReferenceNo: mapping.gunReferenceNo, sourceIdentity, order: Number.isFinite(Number(mapping.sourceSrNo)) ? Number(mapping.sourceSrNo) : Number(mapping.sourceRow) || index + 1, components: new Map() }); }
      const group = groups.get(key); if (!group.components.has(mapping.position)) { group.components.set(mapping.position, new Set()); } group.components.get(mapping.position).add(partDisplayWithComment(mapping.partNo, mapping));
    });
    return [...groups.values()].sort((a, b) => a.order - b.order).map((group, index) => { const details = POSITIONS.filter(position => group.components.has(position)).map(position => `<span><strong>${esc(position)}:</strong> ${esc([...group.components.get(position)].join(' / '))}</span>`).join(' | ') || '<span class="muted">No mapped component allocation</span>'; return `<div><strong>${esc(group.gunReferenceNo || `Gun ${index + 1}`)}</strong> — ${details}</div>`; }).join('');
  }
  function exportBinReconciliation() {
    if (!canComponent('reports')) {return;}
    const rows = [['Source Row', 'Station', 'Gun Reference', 'Mapping Status', 'Bin ID', 'Component Count', 'Canonical Gun Count', 'Reason']];
    for (const gun of state.gunRows || []) { const mappings = state.mappings.filter(m => { const sources = Array.isArray(m.sourceRows) ? m.sourceRows.map(String) : []; const direct = `${m.sourceSheet || ''}:${m.sourceRow ?? ''}`; const key = String(gun.sourceKey || `${gun.sourceSheet || ''}:${gun.sourceRow ?? ''}`); return sameStation(m.stationNo, gun.stationNo) && (sources.includes(key) || sources.some(s => key === s || key.endsWith(`:${s}`)) || direct === key || key.endsWith(`:${direct}`)); }); const bin = state.bins.find(b => sameStation(b.stationNo, gun.stationNo) || (Array.isArray(b.mergedStations) && b.mergedStations.some(station => sameStation(station, gun.stationNo)))); const valid = mappings.some(m => POSITIONS.includes(m.position) && validMappedPartNo(m.partNo)); rows.push([gun.sourceRow || gun.sourceOrder || '', gun.stationNo || '', gun.gunReferenceNo || '', valid ? 'MAPPED' : gun.sourceOnly ? 'EMPTY / SOURCE-ONLY' : 'UNMAPPED', bin?.binId || '', mappings.filter(m => validMappedPartNo(m.partNo)).length, calculateGunCount([gun]), valid ? '' : bin ? 'No valid component mapping' : 'No Common Bin']); }
    download(`shank-mapping-bin-reconciliation-${today()}.csv`, csv(rows), 'text/csv;charset=utf-8');
  }
  function pencilPartGroups() { const groups = new Map(); state.mappings.filter(mapping => validMappedPartNo(mapping.partNo) && isPencilMapping(mapping)).forEach((mapping, index) => { const partNo = vendorPartNo(mapping.partNo).trim(); const key = pencilPartKey(partNo); const series = pencilSeriesKey(partNo); if (!groups.has(series)) { groups.set(series, { series, firstOrder: Number(mapping.sourceSrNo || mapping.sourceRow || index), parts: new Map() }); } const group = groups.get(series); if (!group.parts.has(key)) { group.parts.set(key, { key, partNo, suffix: pencilSuffixNumber(partNo) }); } }); return [...groups.values()].sort((a, b) => a.firstOrder - b.firstOrder).flatMap(group => { const parts = [...group.parts.values()].sort((a, b) => a.suffix - b.suffix || a.key.localeCompare(b.key)); const rows = []; for (let index = 0; index < parts.length; index += 2) { rows.push({ groupKey: `${group.series}|${index / 2}`, parts: parts.slice(index, index + 2) }); } return rows; }); }
  async function migratePencilPartStock(partNo, binId) {
    const key = pencilPartKey(partNo);
    const target = state.stock.find(row => pencilPartKey(row.partNo) === key && row.binId === binId);
    const legacy = state.stock.filter(row => pencilPartKey(row.partNo) === key && row.binId !== binId);
    if (!legacy.length) { return; }
    const targetRow = target ? { ...target } : { id: uid('stock'), partNo, binId, quantity: 0, minimumStock: 0, status: 'ZERO STOCK', createdAt: nowIso(), updatedAt: nowIso() };
    for (const row of legacy) {
      targetRow.quantity = Number(targetRow.quantity || 0) + Number(row.quantity || 0);
      targetRow.minimumStock = Math.max(Number(targetRow.minimumStock || 0), Number(row.minimumStock || 0));
    }
    const part = partByNo(partNo);
    targetRow.minimumStock = Math.max(Number(targetRow.minimumStock || 0), Number(autoSafetyQuantity(partNo) || 0), Number(part?.minimumStock || 0));
    targetRow.status = statusFor(targetRow.quantity, targetRow.minimumStock);
    targetRow.updatedAt = nowIso();
    const legacyIds = new Set(legacy.map(row => String(row.id)));
    const batchUpdates = [];
    for (const batch of state.allocationBatches || []) {
      if (pencilPartKey(batch.partNo) !== key || !Array.isArray(batch.allocations)) { continue; }
      let changed = false;
      const allocations = batch.allocations.map(item => {
        const matchesLegacy = legacyIds.has(String(item.stockId)) || legacy.some(row => String(row.binId) === String(item.binId));
        if (String(item.binId) !== String(binId) && matchesLegacy) {
          changed = true;
          return { ...item, stockId: targetRow.id, binId, migratedFromBinId: item.migratedFromBinId || item.binId };
        }
        return item;
      });
      if (changed) {
        const combined = new Map();
        for (const item of allocations) {
          const allocationKey = `${item.stockId}\u001f${item.binId}`;
          const previous = combined.get(allocationKey);
          if (previous) { previous.quantity = Number(previous.quantity || 0) + Number(item.quantity || 0); }
          else { combined.set(allocationKey, { ...item }); }
        }
        const updatedBatch = { ...batch, allocations: [...combined.values()].map(item => item.binId === binId && item.stockId === targetRow.id
          ? { ...item, beforeQuantity: Number(targetRow.quantity || 0) - Number(item.quantity || 0), afterQuantity: Number(targetRow.quantity || 0) }
          : item) };
        batchUpdates.push(updatedBatch);
      }
    }
    const transactionUpdates = state.tx.filter(row => pencilPartKey(row.partNo) === key && row.binId !== binId).map(row => ({ ...row, metadata: { ...(row.metadata || {}), migratedFromBinId: row.metadata?.migratedFromBinId || row.binId }, binId }));
    const replacementUpdates = state.replacements.filter(row => pencilPartKey(row.partNo || row.newPartNo) === key && row.commonBin && row.commonBin !== binId).map(row => ({ ...row, commonBin: binId }));
    const orderUpdates = state.orders.filter(row => pencilPartKey(row.partNo) === key && row.binId && row.binId !== binId).map(row => ({ ...row, binId }));
    if (typeof window.dPutMany !== 'function') { throw new Error('Atomic Pencil stock migration is unavailable; no rows were changed.'); }
    const writes = [
      ...legacy.map(row => ({ store: STORES.stock, operation: 'delete', key: row.id })),
      { store: STORES.stock, obj: targetRow },
      ...batchUpdates.map(obj => ({ store: ALLOCATION_BATCH_STORE, obj })),
      ...transactionUpdates.map(obj => ({ store: STORES.tx, obj })),
      ...replacementUpdates.map(obj => ({ store: STORES.replacements, obj })),
      ...orderUpdates.map(obj => ({ store: STORES.orders, obj }))
    ];
    await window.dPutMany(writes);
    state.stock = [...state.stock.filter(row => !legacy.some(old => old.id === row.id) && row.id !== targetRow.id), targetRow];
    const batchById = new Map(batchUpdates.map(row => [String(row.id), row]));
    state.allocationBatches = (state.allocationBatches || []).map(row => batchById.get(String(row.id)) || row);
    const transactionById = new Map(transactionUpdates.map(row => [String(row.id), row]));
    state.tx = state.tx.map(row => transactionById.get(String(row.id)) || row);
    const replacementById = new Map(replacementUpdates.map(row => [String(row.id), row]));
    state.replacements = state.replacements.map(row => replacementById.get(String(row.id)) || row);
    const orderById = new Map(orderUpdates.map(row => [String(row.id), row]));
    state.orders = state.orders.map(row => orderById.get(String(row.id)) || row);
  }
  async function ensurePencilBins() {
    const groups = pencilPartGroups();
    const existing = state.bins.filter(bin => bin.binKind === 'PENCIL_PAIR');
    const byKey = new Map(existing.map(bin => [bin.pencilGroupKey, bin]));
    const used = new Set();
    for (let index = 0; index < groups.length; index += 1) {
      const group = groups[index];
      const existingBin = byKey.get(group.groupKey);
      const nextSeq = existing.reduce((max, item) => Math.max(max, Number(String(item.binId || '').match(/(\d+)$/)?.[1] || 0)), 0) + index + 1;
      const stableBinId = existingBin?.binId || `PENCIL-BIN-${String(nextSeq).padStart(2, '0')}`;
      const bin = existingBin || { id: uid('pencil-bin'), binId: stableBinId, name: stableBinId, location: '', active: true, createdAt: nowIso() };
      bin.binId = existingBin?.binId || stableBinId;
      bin.name = bin.binId;
      Object.assign(bin, { binKind: 'PENCIL_PAIR', pencilGroupKey: group.groupKey, pencilPartNumbers: group.parts.map(part => part.partNo), stationNo: '', active: true, updatedAt: nowIso() });
      await dPut(STORES.bins, bin);
      const previous = state.bins.find(item => item.id === bin.id);
      if (!previous) { state.bins.push(bin); } else { Object.assign(previous, bin); }
      used.add(bin.id);
      for (const part of group.parts) {
        if (!partByNo(part.partNo)) {
          const partRecord = { id: uid('part'), partNo: part.partNo, description: `Pencil Shank ${part.partNo}`, componentType: 'Pencil Shank', active: true, minimumStock: 0, status: 'ZERO STOCK', createdAt: nowIso(), updatedAt: nowIso() };
          await dPut(STORES.parts, partRecord);
          state.parts.push(partRecord);
        }
        await ensureStockRecord(part.partNo, bin.binId);
        await migratePencilPartStock(part.partNo, bin.binId);
      }
      for (const mapping of state.mappings) {
        if (validMappedPartNo(mapping.partNo) && isPencilMapping(mapping) && group.parts.some(part => part.key === pencilPartKey(mapping.partNo))) {
          mapping.binId = bin.binId;
          await dPut(STORES.mappings, mapping);
        }
      }
    }
    for (const bin of existing.filter(item => !used.has(item.id))) {
      bin.active = false;
      bin.updatedAt = nowIso();
      await dPut(STORES.bins, bin);
    }
  }
  function pencilBinStock(binId, partNo) { const key = pencilPartKey(partNo); return state.stock.filter(row => row.binId === binId && pencilPartKey(row.partNo) === key).reduce((sum, row) => sum + Number(row.quantity || 0), 0); }
  function pencilBins() {
    const groups = pencilPartGroups();
    const rowsData = groups.map((group, index) => {
      const bin = state.bins.find(item => item.binKind === 'PENCIL_PAIR' && item.pencilGroupKey === group.groupKey) || state.bins.find(item => item.binId === `PENCIL-BIN-${String(index + 1).padStart(2, '0')}`);
      return { group, bin, index, parts: group.parts.map(part => ({ ...part, quantity: pencilBinStock(bin?.binId, part.partNo) })) };
    });
    const qrRows = rowsData.map(row => ({ binId: row.bin?.binId || `PENCIL-BIN-${String(row.index + 1).padStart(2, '0')}`, location: row.bin?.location || '', parts: row.parts.map(part => part.partNo), quantities: row.parts.map(part => part.quantity) }));
    const rows = rowsData.map((row, index) => {
      const first = row.parts[0], second = row.parts[1];
      return `<tr class="cm-bin-row cm-pencil-bin-row" data-bin="${esc(row.bin?.binId || '')}" data-station="" data-location="${esc(row.bin?.location || '')}" data-part="${esc(row.parts.map(part => part.partNo).join(' '))}"><td>${index + 1}</td><td><strong>${esc(row.bin?.binId || `PENCIL-BIN-${String(index + 1).padStart(2, '0')}`)}</strong><br><span class="muted">${esc(row.parts.map(part => part.partNo).join(' + '))}</span></td><td>${esc(first?.partNo || '')}</td><td>${first?.quantity || 0}</td><td>${esc(second?.partNo || '')}</td><td>${second?.quantity || 0}</td><td><span class="cm-pencil-qr" data-qr-index="${index}">Generating QR…</span></td><td>${row.bin?.active === false ? 'Inactive' : 'Active'}</td><td>${row.bin ? btn('Edit Bin', `componentEditBin('${esc(row.bin.id)}')`) : 'No Bin'}</td></tr>`;
    }).join('');
    const filters = `<div class="g3 cm-filter-bar"><div class="fr"><label class="fl">Search Pencil Part No.</label><input class="fi" id="cm-pencil-bin-part-search" placeholder="Pencil Part No." oninput="componentFilterPencilBinRows()"></div><div class="fr"><label class="fl">Search Bin</label><input class="fi" id="cm-pencil-bin-search" placeholder="PENCIL-BIN-01" oninput="componentFilterPencilBinRows()"></div><div class="fr"><label class="fl">Search Part Pair</label><input class="fi" id="cm-pencil-bin-position-search" placeholder="Search pair" oninput="componentFilterPencilBinRows()"></div></div><div class="btn-row">${btn('Clear Filters', 'componentClearPencilBinFilters()')}<span id="cm-pencil-bin-filter-summary" class="muted">Showing ${rowsData.length} of ${rowsData.length}</span></div>`;
    shell('Bin Management Pencil', `<div class="btn-row">${btn('Export Excel', 'componentExportPencilBinsExcel()')}${btn('Export PDF', 'componentExportPencilBinsPdf()', true)}${btn('Preview All QR Labels', 'componentPreviewPencilLabels()')}${btn('Print All QR Labels', 'componentPrintPencilLabels()', true)}</div><div class="alrt alrt-b">Pencil Parts are collected from all six Shank/Adaptor/Holder mapping columns. Same-base Parts are sorted and paired in import order; each pair gets one station-independent common Pencil Bin. Station and Gun are intentionally not shown in this screen. A single leftover Part gets its own Bin.</div>${filters}${table(['SR No.','Pencil Bin','Part No. 1','Qty 1','Part No. 2','Qty 2','QR Code','Status','Action'], rows, 'No matching Pencil pair bins found.', 'cm-pencil-bin-preview')}`);
    if (qrRows.length) { renderPencilBinQrCodes(qrRows); }
  }
  function pencilBinRowsForExport() { return pencilPartGroups().map((group, index) => { const bin = state.bins.find(item => item.binKind === 'PENCIL_PAIR' && item.pencilGroupKey === group.groupKey); return [bin?.binId || `PENCIL-BIN-${String(index + 1).padStart(2, '0')}`, group.parts.map(part => part.partNo).join(' + '), pencilBinStock(bin?.binId, group.parts[0]?.partNo), pencilBinStock(bin?.binId, group.parts[1]?.partNo), bin?.location || '', bin?.active === false ? 'INACTIVE' : 'ACTIVE']; }); }
  function exportPencilBinsExcel() { if (!canComponent('reports')) {return;} exportExcel(`bin-management-pencil-${today()}.xlsx`, 'Bin Management Pencil', ['Pencil Bin','Part Pair','Qty 1','Qty 2','Physical Location','Status'], pencilBinRowsForExport()); }
  function exportPencilBinsPdf() { if (!canComponent('reports')) {return;} exportPdfTable('Bin Management Pencil', ['Pencil Bin','Part Pair','Qty 1','Qty 2','Physical Location','Status'], pencilBinRowsForExport()); }
  function filterPencilBinRows() { const values = { part: cmSearchValue('cm-pencil-bin-part-search'), bin: cmSearchValue('cm-pencil-bin-search'), position: cmSearchValue('cm-pencil-bin-position-search') }; const rows = [...document.querySelectorAll('.cm-pencil-bin-row')]; let visible = 0; rows.forEach(row => { const show = cmMatch(row.dataset.part, values.part) && cmMatch(row.dataset.bin, values.bin) && cmMatch(row.dataset.part, values.position); row.style.display = show ? '' : 'none'; if (show) { visible++; } }); cmUpdateFilterSummary('cm-pencil-bin-filter-summary', visible, rows.length); }
  function clearPencilBinFilters() { cmClearInputs(['cm-pencil-bin-part-search','cm-pencil-bin-search','cm-pencil-bin-position-search'], filterPencilBinRows); }
  function missingBinRecords() {
    const records = [];
    const seen = new Set();
    const categoryRank = { 'Valid Gun — Bin ID Missing': 1, 'Station Assigned — Bin Not Allocated': 2, 'Station Not Assigned': 3, 'Bin ID Present — Bin Record Missing': 4 };
    const binEvidence = row => MAPPED_PART_FIELDS.map(field => `${FIELD_LABELS[field]}=${String(row?.[field] ?? '').trim() || 'blank'}`).join('; ');
    const add = (row, source, category, reasonCode, reason, binId = '', evidence = '') => {
      const station = String(row.stationNo || '').trim();
      const gun = String(row.gunReferenceNo || '').trim();
      const part = String(row.partNo || '').trim();
      const key = `${normalStation(station)}|${gun.toLowerCase()}|${String(row.position || '').toLowerCase()}|${partKey(part)}|${category}`;
      if (seen.has(key)) { return; }
      seen.add(key);
      records.push({ source, category, reasonCode, srNo: row.srNo || row.sourceSrNo || row.sourceRow || '', stationNo: station || 'Station Not Assigned', gunReferenceNo: gun || 'blank', position: row.position || 'Station/Gun', partNo: part || 'blank', binId, reason, evidence: evidence || binEvidence(row) });
    };
    for (const mapping of state.mappings || []) {
      if (!validMappedPartNo(mapping.partNo)) { continue; }
      const station = String(mapping.stationNo || '').trim();
      const hasStation = station && station !== 'Station Not Assigned';
      const stationBin = hasStation ? binByStation(station) : null;
      const mappedBin = mapping.binId ? state.bins.find(item => String(item.binId) === String(mapping.binId)) : null;
      if (!mapping.binId) {
        if (hasStation && stationBin) { add(mapping, 'Gun Mapping', 'Valid Gun — Bin ID Missing', 'MAPPING_BIN_ID_EMPTY', `Mapping row has a valid Part No. and Station "${station}", and an existing Common Bin "${stationBin.binId}" was found, but this mapping row has no binId value.`, '', `mapping.id=${mapping.id || 'blank'}; stationBin=${stationBin.binId}; ${binEvidence(mapping)}`); }
        else if (hasStation && !stationBin) { add(mapping, 'Gun Mapping', 'Station Assigned — Bin Not Allocated', 'STATION_COMMON_BIN_RECORD_MISSING', `No component_bins record matches assigned Station "${station}" (normalized key "${normalStation(station)}"); therefore no Common Bin ID can be assigned.`, '', `mapping.id=${mapping.id || 'blank'}; station=${station}; normalizedStation=${normalStation(station)}; existingBinCount=${state.bins.length}; ${binEvidence(mapping)}`); }
        else { add(mapping, 'Gun Mapping', 'Station Not Assigned', 'MAPPING_STATION_EMPTY', `Mapping row contains a valid Part No. but stationNo is empty or "Station Not Assigned"; bin allocation is intentionally blocked.`, '', `mapping.id=${mapping.id || 'blank'}; stationRaw=${station || 'blank'}; ${binEvidence(mapping)}`); }
      } else if (!mappedBin) {
        add(mapping, 'Gun Mapping', 'Bin ID Present — Bin Record Missing', 'BIN_REFERENCE_NOT_FOUND', `Mapping contains binId "${mapping.binId}", but no component_bins record with that exact binId exists.`, mapping.binId, `mapping.id=${mapping.id || 'blank'}; requestedBinId=${mapping.binId}; existingBinIds=${state.bins.map(item => item.binId).filter(Boolean).join(', ') || 'none'}; ${binEvidence(mapping)}`);
      }
    }
    for (const gun of state.gunRows || []) {
      const station = String(gun.stationNo || '').trim();
      const hasStation = station && station !== 'Station Not Assigned';
      const stationBin = hasStation ? binByStation(station) : null;
      const mapped = (state.mappings || []).filter(mapping => sameStation(mapping.stationNo, gun.stationNo) && String(mapping.gunReferenceNo || '').trim() === String(gun.gunReferenceNo || '').trim() && validMappedPartNo(mapping.partNo));
      if (!mapped.length) {
        const sourceParts = componentPairsForRow(gun);
        const gunMissing = !String(gun.gunReferenceNo || '').trim();
        const reasonCode = !hasStation ? 'SOURCE_STATION_EMPTY' : !stationBin ? 'STATION_COMMON_BIN_RECORD_MISSING' : gunMissing ? 'SOURCE_GUN_REFERENCE_EMPTY' : !sourceParts.length || gun.sourceOnly ? 'SOURCE_HAS_NO_VALID_COMPONENT' : 'SOURCE_MAPPING_NOT_PERSISTED';
        const reason = !hasStation ? `Source row has no assigned Station (stationNo="${station || 'blank'}"); the application does not create a station Bin for unassigned rows.` : !stationBin ? `No component_bins record matches assigned Station "${station}" (normalized key "${normalStation(station)}"); the Common Bin was not created or is missing.` : gunMissing ? `Source row has valid component data, but gunReferenceNo is empty; the Gun cannot be uniquely allocated to a Bin.` : !sourceParts.length || gun.sourceOnly ? `Source row has no valid component Part No. (all supported component fields are blank/NA), so no mapping/bin allocation is created.` : `A valid source Gun has no matching persisted component_mappings row with a Part No. and binId.`;
        add(gun, 'Gun Register', !hasStation ? 'Station Not Assigned' : !stationBin ? 'Station Assigned — Bin Not Allocated' : 'Valid Gun — Bin ID Missing', reasonCode, reason, '', `sourceKey=${gun.sourceKey || 'blank'}; sourceSheet=${gun.sourceSheet || 'blank'}; sourceRow=${gun.sourceRow || 'blank'}; sourceOnly=${Boolean(gun.sourceOnly)}; validComponentCount=${sourceParts.length}; ${binEvidence(gun)}`);
      }
    }
    return records.sort((a, b) => (categoryRank[a.category] || 9) - (categoryRank[b.category] || 9) || String(a.stationNo).localeCompare(String(b.stationNo), undefined, { numeric: true }) || String(a.gunReferenceNo).localeCompare(String(b.gunReferenceNo), undefined, { numeric: true }));
  }
  function openMissingBinAllocations() {
    const records = missingBinRecords();
    const rows = records.map((row, index) => `<tr><td>${index + 1}</td><td>${esc(row.category)}</td><td>${esc(row.reasonCode)}</td><td>${esc(row.source)}</td><td>${esc(row.srNo)}</td><td>${esc(row.stationNo)}</td><td>${esc(row.gunReferenceNo)}</td><td>${esc(row.position)}</td><td>${esc(partDisplayWithComment(row.partNo))}</td><td>${esc(row.binId || '—')}</td><td>${esc(row.reason)}</td><td><details><summary>Evidence</summary>${esc(row.evidence)}</details></td></tr>`).join('');
    shell('Unallocated / Missing Shank Bins', `<div class="alrt alrt-y"><strong>${records.length} record(s) require attention.</strong> Reasons are deterministic and are built only from the stored mapping, source-row, and Bin Management data. No generic or random reason is generated.</div><div class="btn-row">${btn('Refresh List', 'componentOpenMissingBinAllocations()', true)}${btn('Back to Bin Allocation', "componentOpen('bins-copy')")}</div>${table(['SR No.','Category','Reason Code','Source','Mapping SR No.','Station','Gun Reference','Position','Part No.','Bin ID','Exact Reason','Source Evidence'], rows, 'No unallocated or missing-bin records found.', 'cm-missing-bin-table', ['Station','Gun Reference','Position','Part No.','Bin ID','Exact Reason'])}`);
  }
  function selectedBinLabelRows(mode) {
    const rows = labelRows();
    if (mode !== 'selected') { return rows; }
    const selected = new Set([...document.querySelectorAll('.cm-bin-label-select:checked')].map(x => x.value));
    return rows.filter(row => selected.has(String(row.binId))).map((row, index) => ({ ...row, sr: index + 1 }));
  }
  async function previewBinLabels(mode) { return openLabelWindow(selectedBinLabelRows(mode || 'selected'), false); }
  async function printBinLabels(mode) {
    const rows = selectedBinLabelRows(mode || 'all');
    const w = await openLabelWindow(rows, true);
    if (typeof window.componentRecordLabelPrint === 'function') { await window.componentRecordLabelPrint(rows); }
    await audit('COMPONENT_BIN_LABEL_PRINT', 'Shank Common Bin Labels', null, { count: rows.length, mode: mode || 'all', dimensions: labelDimensions(), tablesPerPage: labelTablesPerPage(), qr: true });
    return w;
  }
  function bins() {
    let totalGunCount = 0;
    const sourceOrderByStation = new Map();
    state.gunRows.forEach((row, index) => { const stationKey = normalStation(row.stationNo); if (!stationKey || sourceOrderByStation.has(stationKey)) { return; } const sourceRow = Number(row.sourceRow); sourceOrderByStation.set(stationKey, Number.isFinite(sourceRow) ? sourceRow : index + 1); });
    // Pencil pair bins have their own Bin Management Pencil screen and must
    // never appear in the station/common-bin screen or its label selector.
    const commonBins = state.bins.filter(bin => bin.binKind !== 'PENCIL_PAIR' && bin.active !== false);
    const orderedBins = commonBins.map((bin, index) => ({ bin, index, sourceOrder: Number.isFinite(Number(bin.stationOrder)) ? Number(bin.stationOrder) : sourceOrderByStation.get(normalStation(bin.stationNo)) ?? Number.MAX_SAFE_INTEGER })).sort((a, b) => a.sourceOrder - b.sourceOrder || a.index - b.index).map(item => item.bin);
    const rows = orderedBins.map((b, index) => {
      const allocations = binGunAllocations(b);
      const binStations = new Set([b.stationNo, ...(b.mergedStations || [])].filter(Boolean).map(stationVariantKey));
      const stationGunRows = (state.gunRows || []).filter(row => binStations.has(stationVariantKey(row.stationNo)) && row.gunReferenceNo && !row.sourceOnly);
      const mappedGunRows = state.mappings.filter(m => String(m.binId || '') === String(b.binId || '') && m.stationNo && m.gunReferenceNo && validMappedPartNo(m.partNo));
      const gunCount = stationGunRows.length || calculateGunCount(mappedGunRows, true);
      totalGunCount += gunCount;
      return `<tr class="cm-bin-row" data-serial="${esc(index + 1)}" data-bin="${esc(b.binId)}" data-station="${esc(b.stationNo || '')}" data-location="${esc(b.location || '')}" data-gun="${esc(allocations)}" data-part="${esc(allocations)}"><td><input type="checkbox" class="cm-bin-label-select" value="${esc(b.binId)}" checked></td><td>${esc(index + 1)}</td><td>${esc(b.binId)}</td><td>${esc(b.stationNo || 'Station Not Assigned')}</td><td>${esc(b.name || '')}</td><td>${esc(b.location || '')}</td><td>${gunCount}</td><td class="cm-bin-allocations">${allocations || 'No mapped component allocation'}</td><td>${b.active === false ? 'Inactive' : 'Active'}</td><td>${btn('Edit', `componentEditBin('${esc(b.id)}')`)}</td></tr>`;
    }).join('');
    const gunMetrics = gunCountMetrics(); const totalSourceRows = gunMetrics.source; const emptySourceRows = gunMetrics.unassigned; const mappedSourceRows = gunMetrics.mapped; const filters = `<div class="g4 cm-filter-bar"><div class="fr"><label class="fl">Search Sr. No.</label><input class="fi" id="cm-bin-serial-search" placeholder="Sr. No." oninput="componentFilterBinRows()"></div><div class="fr"><label class="fl">Search Bin ID</label><input class="fi" id="cm-bin-search" placeholder="Bin ID" oninput="componentFilterBinRows()"></div><div class="fr"><label class="fl">Search Station</label><input class="fi" id="cm-bin-station-search" placeholder="Station No." oninput="componentFilterBinRows()"></div><div class="fr"><label class="fl">Search Gun</label><input class="fi" id="cm-bin-gun-search" placeholder="Gun No." oninput="componentFilterBinRows()"></div><div class="fr"><label class="fl">Search Part No.</label><input class="fi" id="cm-bin-part-search" placeholder="Part No." oninput="componentFilterBinRows()"></div><div class="fr"><label class="fl">Search Location</label><input class="fi" id="cm-bin-location-search" placeholder="Physical location" oninput="componentFilterBinRows()"></div></div><div class="btn-row">${btn('Clear Filters', 'componentClearBinFilters()')}${btn('Export Reconciliation', 'componentExportBinReconciliation()')}<span id="cm-bin-filter-summary" class="muted">Showing ${commonBins.length} of ${commonBins.length}</span></div>`;
    shell('Common Station Bins', `<div class="btn-row">${btn('Merge RH/LH Common Bin', "componentOpen('merge')", true)}${btn('Unallocated / Missing Bins', 'componentOpenMissingBinAllocations()')}${btn('Export Excel', 'componentExportBinsExcel()')}${btn('Export PDF', 'componentExportBinsPdf()', true)}</div><div class="card" data-style="margin-top:10px"><div class="card-hd">Shank Bin Label Printing</div><div class="g4"><div class="fr"><label class="fl">Size</label><select class="fi" id="cl-size"><option value="100x40" selected>100 × 40 mm</option><option value="Small">Small</option><option value="Medium">Medium</option><option value="Large">Large</option><option value="Custom">Custom</option></select></div><div class="fr"><label class="fl">Tables per A4 page</label><select class="fi" id="cl-per-page">${Array.from({length:10}, (_, i) => `<option value="${i + 1}"${i + 1 === 5 ? ' selected' : ''}>${i + 1}</option>`).join('')}</select></div><div class="fr"><label class="fl">Custom Width (mm)</label><input class="fi" id="cl-width" type="number" min="10" value="100"></div><div class="fr"><label class="fl">Custom Height (mm)</label><input class="fi" id="cl-height" type="number" min="10" value="40"></div><div class="fr"><label class="fl">Printer Profile</label><input class="fi" id="cl-profile-name" placeholder="e.g. Zebra 203dpi"><button class="btn btn-sm" type="button" onclick="componentSavePrinterProfile()">Save Profile</button></div></div><div class="btn-row">${btn('Preview Selected', "componentPreviewBinLabels('selected')")}${btn('Print Selected', "componentPrintBinLabels('selected')", true)}${btn('Print All', "componentPrintBinLabels('all')")}</div></div><div class="alrt alrt-b">This Shank-only screen owns Common Bin merge and Shank label actions. Each valid Station has one common bin. All physical Gun occurrences from the source file are allocated to the same Bin. All Guns of that Station are allocated to the same Bin. Every valid Fix Shank, Moving Shank, Fix Adaptor, Moving Adaptor, Fix Holder, Moving Holder and Pencil Shank Part Number is shown gun-wise. NA/N/A and blank values are not allocated. Unassigned rows do not create bins.</div>${filters}<div class="alrt alrt-b"><strong>Gun Reconciliation:</strong> Source Gun Rows: ${totalSourceRows} | Mapped/Usable: ${mappedSourceRows} | Empty/Source-only: ${emptySourceRows} | Allocated in Bins: ${totalGunCount}</div>${table(['Select','Sr. No.','Bin ID', 'Station', 'Name', 'Physical Location', 'Gun Count', 'Gun-wise Component Allocation', 'Status', 'Action'], rows, 'No station bins found.', 'cm-bin-management-table')}<div class="card" data-style="margin-top:12px"><div class="card-hd">Total Gun Count</div><div data-style="font-size:24px;font-weight:800;color:var(--ac)">${totalGunCount}</div><div class="muted">Total independent mapped gun rows across all bins</div></div>`);
  }
  async function editBin(id) { if (!canComponent('bin')) {return;} const b = state.bins.find(x => x.id === id); if (!b) {return;} const previousLocation = String(b.location || ''); const location = await componentInputDialog('Edit Bin Location', 'Physical location', previousLocation); if (location == null) {return;} b.location = String(location).trim(); b.updatedAt = nowIso(); await dPut(STORES.bins, b); await audit('COMPONENT_BIN_LOCATION_UPDATE', 'Component Bin', b.id, {binId:b.binId, stationNo:b.stationNo || '', previousLocation, location:b.location}); toastMsg('Bin updated', 'suc'); await load(); bins(); }

  // Original and Alternative Part Nos. share one requirement, but retain separate stock rows.
  // Example: 05-5619 (Original) + 05-5305 (Alternative) require one combined quantity.
  function receivePartFamily(partNo) {
    const requested = vendorPartNo(partNo).trim();
    const family = new Map();
    const add = value => { const clean = vendorPartNo(value).trim(); if (validMappedPartNo(clean)) { family.set(partKey(clean), clean); } };
    add(requested);
    const matchesOptions = options => {
      if (!options) { return false; }
      const candidates = [...(options.candidates || []), ...(options.original ? [options.original] : []), ...(options.alternatives || [])];
      return candidates.some(candidate => samePartNo(candidate, requested));
    };
    (state.mappings || []).forEach(mapping => {
      const position = labelPosition(mapping.position || '');
      const field = PART_OPTION_FIELDS[position];
      const options = field ? mapping.partOptions?.[field] : null;
      if (samePartNo(mapping.partNo, requested) || matchesOptions(options)) {
        add(mapping.partNo); [ ...(options?.candidates || []), ...(options?.alternatives || []) ].forEach(add);
      }
    });
    (state.gunRows || []).forEach(row => Object.values(row.partOptions || {}).forEach(options => {
      if (matchesOptions(options)) { [ ...(options?.candidates || []), ...(options?.alternatives || []) ].forEach(add); }
    }));
    return [...family.values()];
  }
  function combinedStockQuantity(partNos, binId) {
    const keys = new Set(partNos.map(partKey));
    return (state.stock || []).filter(row => keys.has(partKey(row.partNo)) && String(row.binId || '') === String(binId || '')).reduce((sum, row) => sum + Math.max(0, Number(row.quantity || 0)), 0);
  }
  function receivePartFamilyRoles(partNo) {
    const requested = vendorPartNo(partNo).trim();
    const family = receivePartFamily(requested);
    const original = new Map(); const alternatives = new Map();
    const add = (target, value) => { const clean = vendorPartNo(value).trim(); if (validMappedPartNo(clean)) { target.set(partKey(clean), clean); } };
    add(original, requested);
    const related = options => {
      if (!options) { return false; }
      return [...(options.candidates || []), ...(options.original ? [options.original] : []), ...(options.alternatives || [])].some(value => samePartNo(value, requested));
    };
    (state.mappings || []).forEach(mapping => {
      const position = labelPosition(mapping.position || '');
      const field = PART_OPTION_FIELDS[position];
      const options = field ? mapping.partOptions?.[field] : null;
      if (samePartNo(mapping.partNo, requested) || related(options)) {
        add(original, options?.original || mapping.partNo);
        (options?.alternatives || []).forEach(value => add(alternatives, value));
      }
    });
    (state.gunRows || []).forEach(row => Object.values(row.partOptions || {}).forEach(options => {
      if (!related(options)) { return; }
      add(original, options.original || requested);
      (options.alternatives || []).forEach(value => add(alternatives, value));
    }));
    // The selected Part is never simultaneously treated as its own alternative.
    original.delete(partKey(requested)); alternatives.delete(partKey(requested));
    if (!original.size && family.length) { add(original, family[0]); }
    return { original: [...original.values()], alternatives: [...alternatives.values()], family };
  }
  function receiveMappedBinOptions(partNo) {
    const raw = vendorPartNo(partNo).trim();
    const family = receivePartFamily(raw);
    const keys = new Set(family.map(partKey));
    if (!keys.size) { return []; }
    if (isPencilPart(raw)) {
      return state.bins.filter(bin => bin.binKind === 'PENCIL_PAIR' && bin.active !== false && (bin.pencilPartNumbers || []).some(value => keys.has(partKey(value)))).map(bin => ({ binId: bin.binId, stationNo: 'Pencil Common', location: bin.location || '', guns: [], kitQty: 1 }));
    }
    const mappedIds = [...new Set([
      ...(state.mappings || []).filter(m => keys.has(partKey(m.partNo)) && m.binId).map(m => m.binId),
      ...(state.stock || []).filter(row => keys.has(partKey(row.partNo)) && row.binId).map(row => row.binId)
    ])];
    return mappedIds.map(binId => {
      const bin = state.bins.find(b => String(b.binId) === String(binId) && b.active !== false && b.binKind !== 'PENCIL_PAIR');
      if (!bin) { return null; }
      // Only active mappings define the requirement; alternative mappings do not double-count guns.
      const mappedRows = state.mappings.filter(m => String(m.binId) === String(binId) && keys.has(partKey(m.partNo)));
      const guns = [...new Set(mappedRows.map(m => m.gunReferenceNo).filter(Boolean))];
      return { binId, stationNo: bin.stationNo || 'Station Not Assigned', location: bin.location || '', guns, kitQty: Math.max(1, mappedRows.length) };
    }).filter(Boolean);
  }
  function receiveEntryPartNo() { return vendorPartNo(val('cs-part')).trim(); }
  function allocationRecentConsumption(partNo, stationNo) {
    const cutoff = Date.now() - 90 * 24 * 60 * 60 * 1000;
    return state.tx.filter(tx => partKey(tx.partNo) === partKey(partNo) && tx.direction === 'OUT' && String(tx.type || '').toLowerCase().includes('replacement') && sameStation(tx.stationNo || '', stationNo) && new Date(tx.date || 0).getTime() >= cutoff).reduce((sum, tx) => sum + Number(tx.quantity || 0), 0);
  }
  function allocationExpectedStockOut(currentQty, recentConsumption) {
    const dailyUsage = Number(recentConsumption || 0) / 90;
    if (dailyUsage <= 0) { return { dailyUsage: 0, daysUntilZero: null, date: null }; }
    const daysUntilZero = Number(currentQty || 0) / dailyUsage;
    const date = new Date(Date.now() + Math.ceil(daysUntilZero) * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    return { dailyUsage, daysUntilZero, date };
  }
  function allocationOverrideAllowed() {
    const role = String(user().role || user().userRole || '').toLowerCase();
    return /admin|supervisor|manager|store/.test(role) || Boolean(user().isAdmin || user().permissions?.componentAllocationOverride);
  }
  // Compatibility wrapper retained for existing allocation regression tests and callers.
  // The previous KIT_PROPORTIONAL rule is intentionally replaced by shortage-first priority.
  function receiveAllocation(partNo, totalQuantity) { return allocationPlan(partNo, totalQuantity); }
  function compareAllocationPriority(a, b) {
    const aZero = a.currentQty <= 0 ? 0 : 1;
    const bZero = b.currentQty <= 0 ? 0 : 1;
    if (aZero !== bZero) { return aZero - bZero; }
    const aExpected = a.expectedDaysUntilZero == null ? Number.MAX_SAFE_INTEGER : a.expectedDaysUntilZero;
    const bExpected = b.expectedDaysUntilZero == null ? Number.MAX_SAFE_INTEGER : b.expectedDaysUntilZero;
    if (aExpected !== bExpected) { return aExpected - bExpected; }
    if (a.currentQty !== b.currentQty) { return a.currentQty - b.currentQty; }
    if (a.recentConsumption !== b.recentConsumption) { return b.recentConsumption - a.recentConsumption; }
    const aOriginalShortage = Math.max(0, a.originalRequiredQty - a.originalCurrentQty);
    const bOriginalShortage = Math.max(0, b.originalRequiredQty - b.originalCurrentQty);
    const aShortage = Math.max(0, a.requiredQty - a.currentQty - a.quantity);
    const bShortage = Math.max(0, b.requiredQty - b.currentQty - b.quantity);
    const aScore = aOriginalShortage * 100000 + aShortage * 1000 + a.recentConsumption * 10 + a.kitQty * 5 + (a.critical ? 100 : 0);
    const bScore = bOriginalShortage * 100000 + bShortage * 1000 + b.recentConsumption * 10 + b.kitQty * 5 + (b.critical ? 100 : 0);
    return bScore - aScore || a.currentQty + a.quantity - b.currentQty - b.quantity || b.kitQty - a.kitQty || String(a.binId).localeCompare(String(b.binId), undefined, { numeric: true });
  }
  function allocationPlan(partNo, totalQuantity) {
    const part = partByNo(partNo);
    const roles = receivePartFamilyRoles(partNo);
    const family = roles.family;
    const options = receiveMappedBinOptions(partNo).map(option => {
      const originalCurrentQty = combinedStockQuantity(roles.original, option.binId);
      const alternativeCurrentQty = combinedStockQuantity(roles.alternatives, option.binId);
      const currentQty = originalCurrentQty + alternativeCurrentQty;
      const kitQty = Math.max(1, Number(option.kitQty || 1));
      const familyParts = family.map(value => partByNo(value)).filter(Boolean);
      const minimumStock = Math.max(0, ...familyParts.map(item => Number(item.minimumStock || 0)), Number(autoSafetyQuantity(partNo) || 0), Number(part?.minimumStock || 0));
      // Original and Alternative cover one requirement. Never sum them into a double order.
      const originalRequiredQty = Math.max(kitQty, minimumStock);
      const alternativeRequiredQty = roles.alternatives.length ? originalRequiredQty : 0;
      const requiredQty = Math.max(originalRequiredQty, alternativeRequiredQty);
      const recentConsumption = allocationRecentConsumption(partNo, option.stationNo);
      const expected = allocationExpectedStockOut(currentQty, recentConsumption);
      const critical = Boolean(part?.criticalFlag || part?.analytics?.criticalFlag || part?.consumptionConfig?.criticalFlag);
      const maximumQty = Math.max(kitQty * 2, minimumStock);
      return { ...option, currentQty, originalCurrentQty, alternativeCurrentQty, originalRequiredQty, alternativeRequiredQty, originalPartNos: roles.original, alternativePartNos: roles.alternatives, kitQty, minimumStock, requiredQty, maximumQty, recentConsumption, expectedDailyUsage: expected.dailyUsage, expectedDaysUntilZero: expected.daysUntilZero, expectedStockOutDate: expected.date, critical, quantity: 0, shortage: Math.max(0, requiredQty - currentQty), priorityScore: 0, reason: '' };
    });
    const quantity = Number(totalQuantity);
    if (!Number.isInteger(quantity) || quantity < 1 || !options.length) { return []; }
    // Receiving rule: when enough quantity is available, first give one unit to
    // every mapped bin. If quantity is smaller than the number of bins, give one
    // unit to the highest-priority bins only. This prevents one station from
    // absorbing the whole receipt before other mapped stations get their first
    // unit. Remaining units then follow dynamic shortage/consumption priority.
    const priorityOrder = options.filter(row => row.currentQty < row.maximumQty).slice().sort(compareAllocationPriority);
    const baselineCount = Math.min(quantity, priorityOrder.length);
    for (let index = 0; index < baselineCount; index += 1) {
      priorityOrder[index].quantity += 1;
    }
    for (let received = baselineCount; received < quantity; received += 1) {
      // maximumQty is a planning target, not a physical bin-capacity limit.
      // Never reject stock that has already been physically received: once all
      // targets are reached, continue allocating by priority and flag the
      // over-target quantity in the preview.
      const target = options.filter(row => row.currentQty + row.quantity < row.maximumQty).sort(compareAllocationPriority)[0]
        || options.slice().sort(compareAllocationPriority)[0];
      if (!target) { return []; }
      target.quantity += 1;
    }
    options.forEach(row => {
      row.shortage = Math.max(0, row.requiredQty - row.currentQty);
      row.priorityScore = row.shortage * 1000 + row.recentConsumption * 10 + row.kitQty * 5 + (row.critical ? 100 : 0);
      row.reason = row.quantity === 1 && quantity <= options.length
        ? 'One-per-bin baseline; priority-ranked bin'
        : row.currentQty === 0
        ? (family.length > 1 ? `Original + Alternative both zero stock (${family.join(' / ')})` : 'Zero stock')
        : row.currentQty < row.requiredQty
          ? (row.originalCurrentQty < row.originalRequiredQty && row.alternativeCurrentQty > 0 ? `Original priority; Alternative stock covers remaining requirement (${row.originalPartNos.join(' / ')} | ${row.alternativePartNos.join(' / ')})` : family.length > 1 ? `Combined Original + Alternative stock below requirement (${family.join(' / ')})` : 'Below required quantity')
          : row.expectedStockOutDate ? `Expected stock-out ${row.expectedStockOutDate}` : row.recentConsumption > 0 ? 'Recent station consumption' : row.kitQty > 1 ? 'Highest station requirement' : 'Balanced allocation';
    });
    return options.sort((a, b) => String(a.binId).localeCompare(String(b.binId), undefined, { numeric: true }));
  }
  function applyAllocationOverrides(plan, totalQuantity) {
    const inputs = [...document.querySelectorAll('.cm-allocation-override')];
    if (!inputs.length || !allocationOverrideAllowed()) { return plan; }
    const values = new Map(inputs.map(input => [String(input.dataset.bin || ''), Number(input.value)]));
    if (!inputs.some(input => input.value !== '')) { return plan; }
    if (inputs.some(input => !Number.isInteger(values.get(String(input.dataset.bin || ''))) || values.get(String(input.dataset.bin || '')) < 0)) { throw new Error('Allocation override quantities must be whole non-negative numbers.'); }
    if (plan.some(row => (values.get(String(row.binId)) ?? 0) > Math.max(0, row.maximumQty - row.currentQty))) { throw new Error('Manual allocation cannot exceed a bin maximum quantity.'); }
    if ([...values.values()].reduce((sum, value) => sum + value, 0) !== Number(totalQuantity)) { throw new Error(`Manual allocation must total exactly ${totalQuantity}.`); }
    return plan.map(row => ({ ...row, quantity: values.get(String(row.binId)) ?? 0, reason: 'Manual receiving allocation override' }));
  }
  function allocationSummary(plan, totalQuantity) {
    const totalShortage = plan.reduce((sum, row) => sum + row.shortage, 0);
    const afterShortage = plan.reduce((sum, row) => sum + Math.max(0, row.requiredQty - row.currentQty - row.quantity), 0);
    const below = plan.filter(row => row.currentQty + row.quantity < row.requiredQty);
    const overstock = plan.filter(row => row.currentQty < row.requiredQty && row.currentQty + row.quantity > row.requiredQty);
    const overMaximum = plan.filter(row => row.currentQty + row.quantity > row.maximumQty);
    return { totalShortage, afterShortage, below, overstock, overMaximum, partial: Number(totalQuantity) < totalShortage };
  }
  function renderReceiveAllocationPreview() {
    const partNo = receiveEntryPartNo();
    const quantity = Number(val('cs-qty'));
    const mappedOptions = partNo ? receiveMappedBinOptions(partNo) : [];
    const allocations = allocationPlan(partNo, quantity);
    const summary = allocationSummary(allocations, quantity);
    const hint = document.getElementById('cs-bin-hint');
    const bin = document.getElementById('cs-bin');
    const preview = document.getElementById('cs-allocation-preview');
    const emptyReason = !partNo
      ? 'Select a Part Number to calculate Bin-wise allocation.'
      : !Number.isInteger(quantity) || quantity < 1
        ? 'Enter a positive whole-number quantity to calculate Bin-wise allocation.'
        : !mappedOptions.length
          ? 'No active mapped Common Bin was found for this Part No. Check its Station / Gun mapping and active Bin.'
          : 'Unable to calculate an allocation. Confirm the quantity is a positive whole number and at least one active mapped Common Bin is available.';
    if (bin) { bin.value = allocations.length ? allocations.map(row => row.binId).join(', ') : ''; bin.readOnly = true; }
    if (preview) {
      const controls = allocations.length && allocationOverrideAllowed() ? '<small class="muted">Authorized receiving user: edit Receiving Qty; total and bin maximums must remain valid.</small>' : '';
      const warning = allocations.length ? `<div class="alrt ${summary.partial || summary.below.length || summary.overstock.length || summary.overMaximum.length ? 'alrt-y' : 'alrt-b'}"><strong>${summary.partial ? 'Partial allocation' : 'Allocation ready'}</strong> · Total shortage: ${summary.totalShortage} · Planned receipt: ${quantity || 0} · Remaining shortage after receipt: ${summary.afterShortage}${summary.below.length ? ` · ${summary.below.length} Bin(s) remain below requirement` : ''}${summary.overstock.length ? ` · ${summary.overstock.length} Bin(s) may become overstocked` : ''}${summary.overMaximum.length ? ` · ${summary.overMaximum.length} Bin(s) exceed target max; the full receipt will still be recorded` : ''}</div>` : '';
      const dashboard = allocations.length ? `<div class="g4"><div><strong>${allocations.length}</strong><br><small>Mapped Bins</small></div><div><strong>${allocations.filter(row => row.currentQty === 0).length}</strong><br><small>Zero Stock</small></div><div><strong>${allocations.filter(row => row.currentQty > 0 && row.currentQty < row.requiredQty).length}</strong><br><small>Low Stock</small></div><div><strong>${allocations.filter(row => row.currentQty >= row.requiredQty).length}</strong><br><small>Covered</small></div></div>` : '';
      const tableRows = allocations.map(row => `<tr><td>${esc(row.binId)}</td><td>${esc(row.stationNo)}</td><td>${row.originalCurrentQty} / ${row.originalRequiredQty}</td><td>${row.alternativeCurrentQty}${row.alternativeRequiredQty ? ` / ${row.alternativeRequiredQty}` : ''}</td><td>${row.currentQty}</td><td>${row.requiredQty}</td><td>${row.maximumQty}</td><td>${row.shortage}</td><td>${row.recentConsumption}</td><td>${esc(row.expectedStockOutDate || 'No usage data')}</td><td>${row.priorityScore}</td><td>${esc(row.reason)}</td><td>${allocationOverrideAllowed() ? `<input class="fi cm-allocation-override" data-bin="${esc(row.binId)}" type="number" min="0" max="${Math.max(0, row.maximumQty - row.currentQty)}" step="1" value="${row.quantity}">` : `<strong>${row.quantity}</strong>`}</td><td>${row.currentQty + row.quantity}</td></tr>`).join('');
      preview.innerHTML = allocations.length ? `${warning}${dashboard}${controls}<div class="tw"><table><thead><tr><th>Common Bin</th><th>Station</th><th>Original Stock</th><th>Alternative Stock</th><th>Combined Stock</th><th>Required Qty</th><th>Target Max Qty</th><th>Shortage</th><th>90-Day Usage</th><th>Expected Stock-out</th><th>Priority</th><th>Reason</th><th>Receiving Qty</th><th>After Receipt</th></tr></thead><tbody>${tableRows}</tbody></table></div><div class="btn-row">${btn('Export Allocation Excel', 'componentExportAllocationPlan()')}${btn('Export Allocation PDF', 'componentExportAllocationPlanPdf()')}</div>` : (partNo && Number.isInteger(quantity) && quantity > 0 ? `<div class="alrt alrt-y">${esc(emptyReason)}</div>` : '');
    }
    if (hint) { hint.textContent = allocations.length ? `Shortage-first allocation: ${allocations.filter(row => row.quantity > 0).map(row => `${row.binId} = ${row.quantity}`).join(' | ')}` : emptyReason; }
    const confirmation = document.getElementById('cs-receive-confirmation');
    if (confirmation) {
      const ready = Boolean(partNo && Number.isInteger(quantity) && quantity > 0 && allocations.length && allocations.reduce((sum, row) => sum + row.quantity, 0) === quantity);
      confirmation.style.display = ready ? 'block' : 'none';
      confirmation.textContent = ready ? `Confirm receipt: ${quantity} unit(s) of ${partNo} from ${val('cs-source-type') || 'Supplier'} across ${allocations.filter(row => row.quantity > 0).length} Bin(s). Press Enter in the Quantity field to receive now, or click Receive Stock by Kit Allocation.` : '';
    }
  }
  function refreshReceiveMappedBins() { renderReceiveAllocationPreview(); }
  function restoreReceivedPartNoFocus() {
    const partInput = document.getElementById('cs-part');
    if (!partInput || !receivePartNoAfterCommit) { return; }
    const partNo = receivePartNoAfterCommit;
    receivePartNoAfterCommit = '';
    partInput.value = partNo;
    partInput.focus();
    partInput.select();
  }
  function wireReceivePartNoEnterShortcut() {
    const partInput = document.getElementById('cs-part');
    const quantityInput = document.getElementById('cs-qty');
    partInput?.addEventListener('keydown', event => {
      if (event.key !== 'Enter') { return; }
      window.setTimeout(() => {
        if (!String(partInput.value || '').trim() || !quantityInput) { return; }
        refreshReceiveMappedBins();
        quantityInput.focus();
      }, 0);
    });
  }
  function wireReceiveEnterShortcut() {
    const quantityInput = document.getElementById('cs-qty');
    quantityInput?.addEventListener('keydown', event => {
      if (event.key !== 'Enter') { return; }
      const confirmation = document.getElementById('cs-receive-confirmation');
      if (!confirmation || confirmation.style.display === 'none') { return; }
      event.preventDefault();
      document.getElementById('cs-receive-button')?.click();
    });
  }
  function refreshManualStockAdjustment() { const partNo = val('cm-manual-part'); const binId = val('cm-manual-bin'); const row = partNo && binId ? stockFor(partNo, binId) : null; const current = Number(row?.quantity || 0); const currentEl = document.getElementById('cm-manual-current'); const remaining = document.getElementById('cm-manual-remaining'); const usedEl = document.getElementById('cm-manual-used'); if (currentEl) { currentEl.value = row ? String(current) : ''; } const rem = remaining && remaining.value !== '' ? Number(remaining.value) : null; if (usedEl) { usedEl.value = rem == null || !Number.isFinite(rem) ? '' : String(current - rem); } }
  async function saveManualStockAdjustment() { if (!canComponent('stock adjustment')) {return;} const partNo = vendorPartNo(val('cm-manual-part')).trim(), binId = val('cm-manual-bin'), remainingRaw = val('cm-manual-remaining'), remaining = Number(remainingRaw), row = stockFor(partNo, binId), current = Number(row?.quantity || 0); if (String(remainingRaw ?? '').trim() === '' || !partByNo(partNo) || !binId || !row || !Number.isInteger(remaining) || remaining < 0) {return toastMsg('Select a valid Part, Bin, and non-negative Remaining Qty', 'er');} if (remaining > current) {return toastMsg(`Remaining Qty cannot exceed current stock (${current})`, 'er');} const used = current - remaining; if (isPencilPart(partNo) && !receiveMappedBinOptions(partNo).some(option => option.binId === binId)) { return toastMsg('Pencil Part can use only its Pencil Bin', 'er'); } if (used === 0) {return toastMsg('No quantity difference to update', 'inf');} try { const usageBin = state.bins.find(bin => String(bin.binId) === String(binId)); const stationNo = usageBin?.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : usageBin?.stationNo || ''; await changeStock(partNo, binId, -used, 'Manual Shank Usage', { remainingQty: remaining, previousQty: current, usedQty: used, stationNo, reason: 'Manual remaining quantity update' }); await load(); toastMsg(`Manual usage recorded: ${used}; remaining stock: ${remaining}`, 'suc'); stock(); } catch (error) { toastMsg(error.message || 'Manual stock update failed', 'er'); } }
  function uniqueShankPartNumbers() { const groups = new Map(); [...state.parts.filter(p => p.active !== false).map(p => p.partNo), ...state.mappings.map(m => m.partNo)].filter(validMappedPartNo).forEach(value => { const clean = vendorPartNo(value).trim(); const key = partKey(clean); if (!groups.has(key)) { groups.set(key, new Set()); } groups.get(key).add(clean); }); return [...groups.values()].map(values => displayPartNo([...values])).sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })); }
  function typesOfShank() { const parts = uniqueShankPartNumbers(); const groups = []; for (let offset = 0; offset < parts.length; offset += 50) { const chunk = parts.slice(offset, offset + 50); const rows = chunk.map((partNo, index) => `<tr><td class="cm-types-shank-serial" data-index="${offset + index}">${offset + index + 1}</td><td class="cm-types-shank-row mono" data-part="${esc(partNo).toLowerCase()}" data-index="${offset + index}"><strong>${esc(partNo)}</strong><br><small class="muted">${esc(partUsageComment(partNo))}</small></td></tr>`).join(''); groups.push(`<div class="cm-types-shank-compact-wrap"><table class="cm-types-shank-compact"><thead><tr><th>SR.No.</th><th>Shank Part No.</th></tr></thead><tbody>${rows}</tbody></table></div>`); } const grid = groups.join('') || '<div class="empty">No valid Part Numbers found.</div>'; shell('Types of Shank', `<div class="alrt alrt-b">All valid Shank Mapping Part Numbers are shown once only. Station, Gun and Bin details are intentionally excluded from this section.</div><div class="fr"><label class="fl" for="cm-types-shank-search">Search Part No.</label><input class="fi" id="cm-types-shank-search" placeholder="Search Part No." oninput="componentFilterTypesOfShank(this.value)"></div><div class="btn-row">${btn('Export Excel', 'componentExportTypesShankExcel()')}${btn('Export PDF', 'componentExportTypesShankPdf()', true)}<span id="cm-types-shank-summary" class="muted">Showing ${parts.length} of ${parts.length}</span></div><div class="cm-types-shank-grid">${grid}</div>`); }
  function filterTypesOfShank(query) { const q = String(query || '').trim().toLowerCase(); const rows = [...document.querySelectorAll('.cm-types-shank-row')]; let visible = 0; rows.forEach(row => { const show = !q || String(row.dataset.part || '').includes(q); row.style.display = show ? '' : 'none'; const serial = document.querySelector(`.cm-types-shank-serial[data-index="${row.dataset.index}"]`); if (serial) { serial.style.display = show ? '' : 'none'; } if (show) { visible += 1; } }); const summary = document.getElementById('cm-types-shank-summary'); if (summary) { summary.textContent = `Showing ${visible} of ${rows.length}`; } }
  function manualStock() {
    shell('Manual Shank Usage — Remaining Qty', `<div class="alrt alrt-b">Enter actual remaining quantity. Usage deducted = Current System Qty − Remaining Qty.</div><div class="g4"><div class="fr"><label class="fl">Part No. *</label><input class="fi" id="cm-manual-part" list="cm-manual-parts" placeholder="Select Part No."><datalist id="cm-manual-parts">${state.parts.map(p => `<option value="${esc(p.partNo)}">${esc(p.description)}</option>`).join('')}</datalist></div><div class="fr"><label class="fl">Bin *</label><input class="fi" id="cm-manual-bin" list="cm-manual-bins" placeholder="Select Bin"><datalist id="cm-manual-bins"></datalist><small class="muted">Only bins containing the selected Part No. are shown. Pencil Parts use only their PENCIL-BIN-##.</small></div><div class="fr"><label class="fl">Current System Qty</label><input class="fi" id="cm-manual-current" readonly></div><div class="fr"><label class="fl">Remaining Qty *</label><input class="fi" id="cm-manual-remaining" type="number" min="0" step="1" placeholder="Actual remaining"></div><div class="fr"><label class="fl">Usage to Deduct</label><input class="fi" id="cm-manual-used" readonly></div></div><div class="btn-row">${btn('Save Manual Qty Update', 'componentSaveManualStockAdjustment()', true)}</div>`); wireManualStockAdjustment(); }
  function stockStatusRows() {
    const groups = new Map();
    const seed = partNo => {
      const clean = vendorPartNo(partNo).trim();
      const key = partKey(clean);
      if (!key) { return null; }
      if (!groups.has(key)) {
        const part = partByNo(clean);
        groups.set(key, { partNo: clean, description: part?.description || '', type: part?.componentType || '', available: 0, stations: new Set(), bins: new Set(), stockMinimum: 0 });
      }
      return groups.get(key);
    };
    state.parts.filter(part => part && part.active !== false && validMappedPartNo(part.partNo)).forEach(part => seed(part.partNo));
    state.mappings.filter(mapping => validMappedPartNo(mapping.partNo)).forEach(mapping => {
      const item = seed(mapping.partNo);
      if (item && mapping.stationNo && mapping.stationNo !== 'Station Not Assigned') { item.stations.add(canonicalStation(mapping.stationNo)); }
    });
    state.stock.forEach(stock => {
      const item = seed(stock.partNo);
      if (!item) { return; }
      item.available += Number(stock.quantity || 0);
      item.stockMinimum = Math.max(item.stockMinimum, Number(stock.minimumStock || 0));
      if (stock.binId) { item.bins.add(String(stock.binId)); }
      const bin = state.bins.find(row => String(row.binId || '') === String(stock.binId || ''));
      if (bin?.stationNo && bin.binKind !== 'PENCIL_PAIR') { item.stations.add(canonicalStation(bin.stationNo)); }
    });
    return [...groups.values()].map(item => {
      const mappedRequiredQty = Number(autoSafetyQuantity(item.partNo) || 0);
      const requiredQty = mappedRequiredQty || Math.max(Number(partByNo(item.partNo)?.minimumStock || 0), item.stockMinimum);
      const available = Math.max(0, Number(item.available || 0));
      const status = available <= 0 ? 'ZERO STOCK' : available < requiredQty ? 'LOW STOCK' : 'OK STOCK';
      const part = partByNo(item.partNo);
      const pencilBinIds = [...new Set(state.bins.filter(bin => bin?.binKind === 'PENCIL_PAIR' && ((bin.pencilPartNumbers || []).some(value => partKey(value) === partKey(item.partNo)) || state.stock.some(stock => partKey(stock.partNo) === partKey(item.partNo) && String(stock.binId || '') === String(bin.binId || '')))).map(bin => String(bin.binId || '')).filter(Boolean))];
      const pencilSharedStockQuantity = state.stock.filter(stock => partKey(stock.partNo) === partKey(item.partNo) && pencilBinIds.includes(String(stock.binId || ''))).reduce((sum, stock) => sum + Math.max(0, Number(stock.quantity || 0)), 0);
      const critical = Boolean(part?.criticalFlag || part?.analytics?.criticalFlag || part?.consumptionConfig?.criticalFlag);
      return {
        partNo: item.partNo,
        description: item.description,
        type: item.type,
        stationNo: [...item.stations].join(' | ') || 'No mapped Station',
        binId: [...item.bins].join(' | ') || 'No stock row',
        quantity: available,
        requiredQty,
        minimumStock: requiredQty,
        shortage: Math.max(0, requiredQty - available),
        status,
        critical,
        locationComment: pencilSharedStockQuantity > 0 ? `Pencil shared Qty ${pencilSharedStockQuantity} is held in ${pencilBinIds.join(', ')}` : '',
        grouped: true,
      };
    }).sort((a, b) => String(a.partNo).localeCompare(String(b.partNo), undefined, { numeric: true, sensitivity: 'base' }));
  }
  const STOCK_IMPORT_HEADERS = ['Sr No.', 'Station No.', 'Gun Reference No.', 'Fix Qty', 'Moving Qty', 'Required Qty', 'Bin Location'];
  const STOCK_IMPORT_FIELD_ALIASES = {
    srNo: ['srno', 'sno', 'serialno', 'serialnumber'],
    stationNo: ['stationno', 'stationnumber', 'station'],
    gunReferenceNo: ['gunreferenceno', 'gunreference', 'gunref', 'gunno', 'gun'],
    fixQty: ['fixqty', 'fixedqty', 'fixquantity', 'fixedquantity', 'fixshankqty', 'fixstockqty'],
    movingQty: ['movingqty', 'moveqty', 'movingquantity', 'movingshankqty', 'movingstockqty'],
    requiredQty: ['requiredqty', 'reqqty', 'minimumqty', 'minqty'],
    binLocation: ['binlocation', 'physicallocation', 'storagebin', 'location'],
  };
  function stockImportHeaderKey(value) { return String(value == null ? '' : value).toLowerCase().replace(/[^a-z0-9]/g, ''); }
  function stockImportParseMatrix(matrix) {
    if (!Array.isArray(matrix) || !matrix.length) { throw new Error('The workbook has no rows.'); }
    const fieldByColumn = (matrix[0] || []).map(header => {
      const key = stockImportHeaderKey(header);
      return Object.entries(STOCK_IMPORT_FIELD_ALIASES).find(([, aliases]) => aliases.includes(key))?.[0] || null;
    });
    const requiredHeaders = ['stationNo', 'gunReferenceNo', 'fixQty', 'movingQty', 'requiredQty', 'binLocation'];
    const missing = requiredHeaders.filter(field => !fieldByColumn.includes(field));
    if (missing.length) { const labels = { stationNo: 'Station No.', gunReferenceNo: 'Gun Reference No.', fixQty: 'Fix Qty', movingQty: 'Moving Qty', requiredQty: 'Required Qty', binLocation: 'Bin Location' }; throw new Error(`Missing required columns: ${missing.map(field => labels[field] || field).join(', ')}.`); }
    return matrix.slice(1).map((cells, index) => {
      const row = { sourceRow: index + 2 };
      fieldByColumn.forEach((field, column) => { if (field && row[field] == null) { row[field] = String(cells?.[column] ?? '').trim(); } });
      return row;
    }).filter(row => Object.entries(row).some(([key, value]) => key !== 'sourceRow' && String(value ?? '').trim() !== ''));
  }
  function stockImportQuantity(value, label, allowBlank = false) {
    const raw = String(value ?? '').trim();
    if (!raw && allowBlank) { return { value: 0, error: '' }; }
    const number = raw ? Number(raw.replace(/,/g, '')) : NaN;
    if (!Number.isInteger(number) || number < 0) { return { value: null, error: `${label} must be a whole number of 0 or more.` }; }
    return { value: number, error: '' };
  }
  function stockImportResolveRows(parsedRows) {
    return parsedRows.map((source, index) => {
      const errors = [];
      const srNo = String(source.srNo || index + 1).trim();
      const stationNo = canonicalStation(source.stationNo || '');
      const gunReferenceNo = String(source.gunReferenceNo || '').trim();
      const fixQtyResult = stockImportQuantity(source.fixQty, 'Fix Qty', true);
      const movingQtyResult = stockImportQuantity(source.movingQty, 'Moving Qty', true);
      const requiredQtyResult = stockImportQuantity(source.requiredQty, 'Required Qty');
      if (!stationNo) { errors.push('Station No. is required.'); }
      if (!gunReferenceNo) { errors.push('Gun Reference No. is required.'); }
      if (fixQtyResult.error) { errors.push(fixQtyResult.error); }
      if (movingQtyResult.error) { errors.push(movingQtyResult.error); }
      if (requiredQtyResult.error) { errors.push(requiredQtyResult.error); }
      const fixQty = fixQtyResult.value ?? 0;
      const movingQty = movingQtyResult.value ?? 0;
      if (!fixQty && !movingQty && !fixQtyResult.error && !movingQtyResult.error) { errors.push('Enter a positive Fix Qty or Moving Qty.'); }
      const enteredBinLocation = String(source.binLocation || '').trim();
      if (!enteredBinLocation) { errors.push('Bin Location is required.'); }
      const bin = stationNo ? activeBinForStation(stationNo) : null;
      if (stationNo && (!bin || bin.active === false || bin.binKind === 'PENCIL_PAIR')) { errors.push(`No active common shank bin found for Station ${stationNo}.`); }
      const normalizeLocation = value => stockImportHeaderKey(value);
      if (bin && enteredBinLocation && ![bin.location, bin.binId].some(value => normalizeLocation(value) === normalizeLocation(enteredBinLocation))) {
        errors.push(`Bin Location does not match Station ${stationNo}; expected ${bin.location || bin.binId}.`);
      }
      const findMapping = (position, quantity) => {
        if (!quantity || !stationNo || !gunReferenceNo) { return null; }
        const candidates = state.mappings.filter(mapping => sameStation(mapping.stationNo, stationNo) && normalGunReference(mapping.gunReferenceNo) === normalGunReference(gunReferenceNo) && pencilPositionKey(mapping.position) === position && validMappedPartNo(mapping.partNo));
        const distinct = [...new Map(candidates.map(mapping => [partKey(mapping.partNo), mapping])).values()];
        if (!distinct.length) { errors.push(`No mapped ${position === 'fix shank' ? 'Fix' : 'Moving'} Shank found for Station ${stationNo} / Gun ${gunReferenceNo}.`); return null; }
        if (distinct.length > 1) { errors.push(`More than one ${position === 'fix shank' ? 'Fix' : 'Moving'} Shank is mapped for Station ${stationNo} / Gun ${gunReferenceNo}.`); return null; }
        const mapping = distinct[0];
        const part = partByNo(mapping.partNo);
        if (!part || part.active === false) { errors.push(`Mapped Part No. ${mapping.partNo} is missing or inactive in Parts Master.`); return null; }
        return mapping;
      };
      const fixMapping = findMapping('fix shank', fixQty);
      const movingMapping = findMapping('moving shank', movingQty);
      return { ...source, srNo, sourceRow: source.sourceRow || index + 2, stationNo, gunReferenceNo, fixQty, movingQty, requiredQty: requiredQtyResult.value, enteredBinLocation, binId: bin?.binId || '', resolvedBinLocation: bin?.location || '', fixPartNo: fixMapping?.partNo || '', movingPartNo: movingMapping?.partNo || '', errors, valid: errors.length === 0 };
    });
  }
  function stockImportPreviewMarkup() {
    if (!pendingStockImport) { return ''; }
    const rows = pendingStockImport.rows || [];
    const validCount = rows.filter(row => row.valid).length;
    const invalidCount = rows.length - validCount;
    const previewRows = rows.map(row => `<tr><td>${esc(row.sourceRow)}</td><td>${esc(row.srNo)}</td><td>${esc(row.stationNo)}</td><td>${esc(row.gunReferenceNo)}</td><td>${esc(row.fixPartNo || '—')} / ${row.fixQty}</td><td>${esc(row.movingPartNo || '—')} / ${row.movingQty}</td><td>${row.requiredQty == null ? '—' : row.requiredQty}</td><td>${esc(row.enteredBinLocation)}</td><td>${row.valid ? '<span class="badge badge-green">Ready</span>' : `<span class="badge badge-red">${esc(row.errors.join(' '))}</span>`}</td></tr>`).join('');
    const actions = `${validCount && !invalidCount ? btn(`Receive ${validCount} Excel Row${validCount === 1 ? '' : 's'}`, 'componentCommitStockImport()', true) : ''}${btn('Clear Preview', 'componentClearStockImport()')}`;
    return `<div class="alrt ${invalidCount ? 'alrt-r' : 'alrt-g'}">${esc(pendingStockImport.fileName)} — ${rows.length} data row(s): ${validCount} ready, ${invalidCount} with errors. Stock changes only after you choose Receive.</div>${table(['Excel Row','Sr No.','Station No.','Gun Reference No.','Fix Part / Qty','Moving Part / Qty','Required Qty','Bin Location','Validation'], previewRows, 'No non-empty data rows found.')}${rows.length ? `<div class="btn-row">${actions}</div>` : ''}`;
  }
  function stockImportCardMarkup() {
    return `<div class="card cm-stock-action-box"><div class="card-hd">New Stock Entry — Excel Import</div><div class="alrt alrt-b">Excel columns: <strong>Sr No., Station No., Gun Reference No., Fix Qty, Moving Qty, Required Qty, Bin Location</strong>. Fix/Moving part numbers come from the Station + Gun mapping. Required Qty becomes the minimum for both mapped parts (a higher system/automatic minimum is preserved). Bin Location must match that Station’s active common bin. Import is previewed first; if any row has an error, no rows can be received until the file is corrected.</div><div class="btn-row">${btn('Download Excel Template', 'componentDownloadStockEntryTemplate()')}<label class="btn btn-s">Import Excel / CSV<input type="file" id="cm-stock-import-file" accept=".xlsx,.xls,.xlsm,.csv" hidden></label></div>${stockImportPreviewMarkup()}</div>`;
  }
  function downloadStockEntryTemplate() {
    const parser = getXlsxParser();
    if (!parser?.utils?.book_new || !parser.utils.aoa_to_sheet || !parser.writeFile) { return download('Stock-Entry-Import-Template.csv', `${STOCK_IMPORT_HEADERS.join(',')}\n`, 'text/csv'); }
    const workbook = parser.utils.book_new();
    const worksheet = parser.utils.aoa_to_sheet([STOCK_IMPORT_HEADERS]);
    worksheet['!cols'] = [{ wch: 10 }, { wch: 18 }, { wch: 23 }, { wch: 12 }, { wch: 14 }, { wch: 16 }, { wch: 22 }];
    parser.utils.book_append_sheet(workbook, worksheet, 'Stock Entry');
    parser.writeFile(workbook, 'Stock-Entry-Import-Template.xlsx');
    toastMsg('Excel template downloaded: Stock-Entry-Import-Template.xlsx', 'suc');
  }
  function wireStockImportFile() {
    document.getElementById('cm-stock-import-file')?.addEventListener('change', handleStockImportFile);
  }
  async function handleStockImportFile(event) {
    if (!canComponent('stock receive')) { return; }
    const file = event?.target?.files?.[0];
    if (!file) { return; }
    const parser = getXlsxParser();
    if (!parser?.read || !parser.utils?.sheet_to_json) { return toastMsg('XLSX parser is unavailable. Restart the application or reinstall the bundled parser.', 'er'); }
    try {
      const workbook = /\.csv$/i.test(file.name)
        ? parser.read(await file.text(), { type: 'string' })
        : parser.read(await file.arrayBuffer(), { type: 'array' });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      if (!sheet) { throw new Error('The workbook has no worksheet.'); }
      const matrix = parser.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false });
      const parsed = stockImportParseMatrix(matrix);
      pendingStockImport = { fileName: file.name, rows: stockImportResolveRows(parsed) };
      stock();
    } catch (error) {
      toastMsg(`Stock Excel import could not be read: ${error.message || error}`, 'er');
    }
  }
  function clearStockImport() { pendingStockImport = null; stock(); }
  async function commitStockImport() {
    if (!canComponent('stock receive')) { return; }
    if (!pendingStockImport?.rows?.length) { return toastMsg('Choose a stock Excel file and review its preview first.', 'er'); }
    const rows = pendingStockImport.rows;
    const invalid = rows.filter(row => !row.valid);
    if (invalid.length) { return toastMsg(`No stock was changed. Correct all ${invalid.length} invalid Excel row(s) and import again.`, 'er'); }
    const entries = [];
    for (const row of rows) {
      if (row.fixQty > 0) { entries.push({ partNo: row.fixPartNo, quantity: row.fixQty, stationNo: row.stationNo, gunReferenceNo: row.gunReferenceNo, componentPosition: 'Fix Shank', requiredQty: row.requiredQty, binId: row.binId, sourceRow: row.sourceRow, srNo: row.srNo }); }
      if (row.movingQty > 0) { entries.push({ partNo: row.movingPartNo, quantity: row.movingQty, stationNo: row.stationNo, gunReferenceNo: row.gunReferenceNo, componentPosition: 'Moving Shank', requiredQty: row.requiredQty, binId: row.binId, sourceRow: row.sourceRow, srNo: row.srNo }); }
    }
    if (!entries.length) { return toastMsg('No positive Fix Qty or Moving Qty was found; no stock was changed.', 'er'); }
    const receivedAt = nowIso();
    const importId = uid('stock-import');
    const grouped = new Map();
    entries.forEach(entry => {
      const key = `${partKey(entry.partNo)}|${String(entry.binId)}`;
      const current = grouped.get(key) || { ...entry, quantity: 0, requiredQty: 0, sourceRows: [] };
      current.quantity += Number(entry.quantity);
      current.requiredQty = Math.max(current.requiredQty, Number(entry.requiredQty || 0));
      current.sourceRows.push({ sourceRow: entry.sourceRow, srNo: entry.srNo, stationNo: entry.stationNo, gunReferenceNo: entry.gunReferenceNo, componentPosition: entry.componentPosition, quantity: entry.quantity });
      grouped.set(key, current);
    });
    const stockRows = [], transactions = [], audits = [];
    for (const entry of grouped.values()) {
      const existing = stockFor(entry.partNo, entry.binId);
      const beforeQuantity = Number(existing?.quantity || 0);
      const minimumStock = Math.max(Number(existing?.minimumStock || 0), Number(entry.requiredQty || 0), Number(autoSafetyQuantity(entry.partNo) || 0));
      const stockRow = existing ? { ...existing } : { id: uid('stock'), partNo: entry.partNo, binId: entry.binId, quantity: 0, minimumStock, status: 'ZERO STOCK', createdAt: receivedAt };
      stockRow.quantity = beforeQuantity + entry.quantity;
      stockRow.minimumStock = minimumStock;
      stockRow.status = statusFor(stockRow.quantity, minimumStock);
      stockRow.updatedAt = receivedAt;
      const tx = { id: uid('ctx'), partNo: entry.partNo, binId: entry.binId, quantity: entry.quantity, direction: 'IN', type: 'Excel Stock Entry', beforeQuantity, afterQuantity: stockRow.quantity, date: receivedAt, stationNo: entry.stationNo, userId: user().id || null, username: user().username || user().name || 'Unknown', metadata: { importId, sourceFile: pendingStockImport.fileName, requiredQty: entry.requiredQty, minimumStock, sourceRows: entry.sourceRows } };
      stockRows.push(stockRow);
      transactions.push(tx);
      audits.push({ id: uid('ca'), action: 'COMPONENT_STOCK_EXCEL_RECEIVE', entity: 'Stock Import', entityId: importId, details: tx, timestamp: receivedAt, userId: user().id || null, username: user().username || user().name || 'Unknown' });
    }
    if (typeof window.dPutMany !== 'function') { return toastMsg('Atomic stock import is unavailable; no stock was changed.', 'er'); }
    try {
      await window.dPutMany([...stockRows.map(obj => ({ store: STORES.stock, obj })), ...transactions.map(obj => ({ store: STORES.tx, obj })), ...audits.map(obj => ({ store: STORES.audit, obj }))]);
    } catch (error) {
      return toastMsg(`Stock Excel import failed atomically; no rows were committed. ${error.message || ''}`, 'er');
    }
    stockRows.forEach(row => { const index = state.stock.findIndex(existing => existing.id === row.id); if (index >= 0) { state.stock[index] = row; } else { state.stock.push(row); } });
    state.tx.push(...transactions);
    if (typeof addAudit === 'function') { for (const event of audits) { try { await addAudit(event.action, `Stock Import: ${JSON.stringify(event.details)}`, 'COMPONENT_MANAGEMENT'); } catch (error) { console.error('Secondary stock import audit sink failed after atomic commit', error); } } }
    pendingStockImport = null;
    toastMsg(`Stock Excel import received ${entries.reduce((sum, item) => sum + item.quantity, 0)} unit(s) across ${stockRows.length} Part / Bin combination(s). Import: ${importId}`, 'suc');
    stock();
  }

  function zeroStockView() {
    const startedAt = (() => { try { return window.performance.now(); } catch (_) { return Date.now(); } })();
    window.componentStockViewMode = 'status';
    const navContext = window.componentBiNavigationContext || {};
    const displayedStock = stockStatusRows().sort((a, b) => Number(b.shortage || 0) - Number(a.shortage || 0) || Number(a.quantity || 0) - Number(b.quantity || 0) || String(a.partNo).localeCompare(String(b.partNo), undefined, { numeric: true, sensitivity: 'base' }));
    const rows = displayedStock.map(row => `<tr class="cm-stock-row" data-part="${esc(row.partNo)}" data-station="${esc(row.stationNo)}" data-bin="${esc(row.binId)}" data-type="${esc(row.type || '')}" data-status="${esc(row.status)}" data-available="${Number(row.quantity || 0)}" data-required="${Number(row.requiredQty || 0)}" data-shortage="${Number(row.shortage || 0)}" data-critical="${row.critical ? 'true' : 'false'}"><td class="mono"><strong>${esc(row.partNo)}</strong>${row.critical ? '<br><span class="alrt alrt-r" style="display:inline-block;padding:2px 6px;margin-top:4px">CRITICAL</span>' : ''}<br><small class="muted">${esc(partUsageComment(row.partNo))}</small>${row.locationComment ? `<br><small class="muted">${esc(row.locationComment)}</small>` : ''}</td><td>${esc(row.description || '')}</td><td>${esc(row.type || '')}</td><td>${esc(row.stationNo)}</td><td>${esc(row.binId)}</td><td>${Number(row.quantity || 0)}</td><td>${Number(row.requiredQty || 0)}</td><td>${Number(row.shortage || 0)}</td><td>${esc(row.status)}</td></tr>`).join('');
    const statusOptions = ['ZERO STOCK', 'LOW STOCK', 'OK STOCK'];
    const selectedStatus = String(navContext.stockStatus || 'ZERO STOCK').toUpperCase();
    const filters = `<div class="g4 cm-filter-bar"><div class="fr"><label class="fl">Search Part No.</label><input class="fi" id="cm-stock-part-search" list="cm-stock-part-search-options" value="${esc(navContext.partNo || '')}" placeholder="Type or select Part No." oninput="componentRefreshStockFilterControls()"><datalist id="cm-stock-part-search-options"></datalist></div><div class="fr"><label class="fl">Search Station</label><input class="fi" id="cm-stock-station-search" list="cm-stock-station-options" value="${esc(navContext.stationNo || '')}" placeholder="Type or select Station" oninput="componentRefreshStockFilterBins()"><datalist id="cm-stock-station-options"></datalist></div><div class="fr"><label class="fl">Search Bin ID / Location</label><input class="fi" id="cm-stock-bin-search" list="cm-stock-bin-options" placeholder="Type or select Bin" oninput="componentFilterStockRows()"><datalist id="cm-stock-bin-options"></datalist></div><div class="fr"><label class="fl">Search Component Type</label><input class="fi" id="cm-stock-type-search" list="cm-stock-type-search-options" placeholder="Type or select Type" oninput="componentFilterStockRows()"><datalist id="cm-stock-type-search-options"></datalist></div><div class="fr"><label class="fl">Search Status</label><select class="fi" id="cm-stock-status-search" onchange="componentFilterStockRows()"><option value="">All Statuses</option>${statusOptions.map(status => `<option value="${status}" ${status === selectedStatus ? 'selected' : ''}>${status}</option>`).join('')}</select></div><div class="fr"><label class="fl">Sort By</label><select class="fi" id="cm-stock-sort" onchange="componentSortStockStatusTable()"><option value="shortage-desc">Highest Shortage</option><option value="available-asc">Lowest Available Qty</option><option value="station-asc">Station</option><option value="part-asc">Part No.</option></select></div></div>`;
    const asOf = new Date().toLocaleString();
    shell('Shank Mapping — Stock Status & Zero Stock', `<div class="card"><div class="card-hd">Stock Status & Required Quantity</div><div class="alrt alrt-b">Status is based on total available quantity across all bins. ZERO STOCK = 0; LOW STOCK = available is less than Required Qty; OK STOCK = available meets or exceeds Required Qty. <strong>As of: ${esc(asOf)}</strong></div>${filters}<div id="cm-stock-status-summary" class="g4 cm-stock-status-summary"></div><div class="btn-row">${btn('Clear Filters', 'componentClearStockFilters()')}${btn('Export Excel', 'componentExportStockExcel()')}${btn('Export PDF', 'componentExportStockPdf()', true)}<span id="cm-stock-filter-summary" class="muted">Showing ${displayedStock.length} of ${displayedStock.length}</span></div>${table(['Part No.','Description','Type','Station / Location','Bin ID / Location','Available Qty','Required Qty','Shortage Qty','Status'], rows, 'No matching stock status records found.')}</div>`);
    refreshStockFilterControls();
    if (navContext.partNo || navContext.stationNo || navContext.stockStatus) { filterStockRows(); window.componentBiNavigationContext = null; }
    const category = displayedStock.length > 5000 ? 'stockStatusLarge' : 'stockStatus';
    const afterPaint = () => { const endedAt = (() => { try { return window.performance.now(); } catch (_) { return Date.now(); } })(); try { window.performanceMonitor?.record('stock-status-render', endedAt - startedAt, { category }); } catch (_) {} };
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(afterPaint); else setTimeout(afterPaint, 0);
  }
  function stock() { window.componentStockViewMode = 'all'; const navContext = window.componentBiNavigationContext || {}; const normalizedStock = stockRowsForView().map(s => ({ ...s, minimumStock: autoSafetyQuantity(s.partNo) || Number(s.minimumStock || 0), status: statusFor(Number(s.quantity || 0), autoSafetyQuantity(s.partNo) || Number(s.minimumStock || 0)) })); const displayedStock = normalizedStock; const rows = displayedStock.map(s => { const p = partByNo(s.partNo); const b = state.bins.find(x => x.binId === s.binId); const station = b?.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : (b?.stationNo || ''); const bin = b?.binId || s.binId; return `<tr class="cm-stock-row" data-part="${esc(s.partNo)}" data-station="${esc(station)}" data-bin="${esc(bin)}" data-type="${esc(p?.componentType || '')}" data-status="${esc(s.status)}"><td class="mono"><strong>${esc(s.partNo)}</strong><br><small class="muted">${esc(partUsageComment(s.partNo))}</small>${stockRowLocationComment(s) ? `<br><small class="muted">${esc(stockRowLocationComment(s))}</small>` : ''}</td><td>${esc(p?.description || '')}</td><td>${esc(p?.componentType || '')}</td><td>${esc(bin)}</td><td>${s.quantity}</td><td>${s.minimumStock}</td><td>${esc(s.status)}</td></tr>`; }).join(''); const filters = `<div class="g4 cm-filter-bar"><div class="fr"><label class="fl">Search Part No.</label><input class="fi" id="cm-stock-part-search" list="cm-stock-part-search-options" value="${esc(navContext.partNo || '')}" placeholder="Part No." oninput="componentRefreshStockFilterControls()"></div><div class="fr"><label class="fl">Search Station</label><input class="fi" id="cm-stock-station-search" list="cm-stock-station-options" value="${esc(navContext.stationNo || '')}" placeholder="Type or select Part No. first" oninput="componentRefreshStockFilterBins()"><datalist id="cm-stock-station-options"></datalist></div><div class="fr"><label class="fl">Search Bin</label><input class="fi" id="cm-stock-bin-search" list="cm-stock-bin-options" placeholder="Type or select Station first" oninput="componentFilterStockRows()"><datalist id="cm-stock-bin-options"></datalist></div><div class="fr"><label class="fl">Search Component Type</label><input class="fi" id="cm-stock-type-search" placeholder="Shank / Adaptor / Holder" oninput="componentFilterStockRows()"></div><div class="fr"><label class="fl">Search Status</label><input class="fi" id="cm-stock-status-search" placeholder="OK / LOW / OUT" oninput="componentFilterStockRows()"></div></div><div class="btn-row">${btn('Clear Filters', 'componentClearStockFilters()')}${btn('Export Excel', 'componentExportStockExcel()')}${btn('Export PDF', 'componentExportStockPdf()', true)}<span id="cm-stock-filter-summary" class="muted">Showing ${displayedStock.length} of ${displayedStock.length}</span></div>`; shell('Shank Receiving & Stock Control', `<div class="card cm-stock-action-box"><div class="card-hd">Shank Receiving from Supplier or Arrangement</div><div class="alrt alrt-b">Enter Part No. and total received Quantity. StoreTrack automatically split-receives stock: it first gives 1 quantity to each prioritized mapped Common Bin; any remaining quantity goes to the bins with the highest shortage and Replacement History priority.</div><div class="g4"><div class="fr"><label class="fl" for="cs-part">Part No. *</label><input class="fi" id="cs-part" list="cs-part-options" autocomplete="off" placeholder="Type or select Part No."><datalist id="cs-part-options">${state.parts.filter(p => p.active !== false).sort((a, b) => String(a.partNo).localeCompare(String(b.partNo), undefined, { numeric: true, sensitivity: 'base' })).map(p => `<option value="${esc(p.partNo)}" label="${esc(p.description || '')}" ></option>`).join('')}</datalist><small class="muted">Kit occurrences are counted from the Station / Gun mapping.</small></div><div class="fr"><label class="fl">Total Received Quantity *</label><input class="fi" id="cs-qty" type="number" min="1"></div><div class="fr"><label class="fl" for="cs-bin">Auto-allocated Bin(s)</label><input class="fi" id="cs-bin" readonly placeholder="Select Part No. and Quantity"><small id="cs-bin-hint" class="muted">Select a Part Number and quantity to calculate Bin-wise allocation.</small></div><div class="fr"><label class="fl">Source Type *</label><select class="fi" id="cs-source-type"><option value="Supplier">Supplier</option><option value="Arrangement">Arrangement</option></select></div><div class="fr"><label class="fl">Reference</label><input class="fi" id="cs-ref"></div></div><div id="cs-allocation-preview" class="cm-receive-allocation-preview"></div><div id="cs-receive-confirmation" class="alrt alrt-y" role="status" aria-live="polite" style="display:none"></div><div class="fr"><label class="fl">Remarks</label><input class="fi" id="cs-remarks"></div><div class="btn-row"><button class="btn btn-p" type="button" id="cs-receive-button" data-onclick="componentReceiveStock()">Receive Stock by Kit Allocation</button></div></div>${stockImportCardMarkup()}<div class="card cm-stock-action-box"><div class="card-hd">Physical Stock Verification</div><div class="muted">Compare system quantity with the physical count and record an adjustment when required.</div><div class="btn-row">${btn('Open Physical Stock Verification', "componentOpen('verify')", true)}</div></div>${allocationHistoryMarkup()}<div class="card cm-stock-search-box"><div class="card-hd">Search Stock by Part No. and Location</div>${filters}</div>${table(['Part No.', 'Description', 'Type', 'Bin', 'Qty', 'Minimum', 'Status'], rows)}`); const partInput = document.getElementById('cs-part'); partInput?.addEventListener('input', refreshReceiveMappedBins); partInput?.addEventListener('change', refreshReceiveMappedBins); wireReceivePartNoEnterShortcut(); const receiveQtyInput = document.getElementById('cs-qty'); receiveQtyInput?.addEventListener('input', refreshReceiveMappedBins); receiveQtyInput?.addEventListener('change', refreshReceiveMappedBins); wireReceiveEnterShortcut(); const receiveSourceType = document.getElementById('cs-source-type'); receiveSourceType?.addEventListener('change', refreshReceiveMappedBins); restoreReceivedPartNoFocus(); refreshReceiveMappedBins(); wireStockImportFile(); wireManualStockAdjustment(); refreshStockFilterControls(); if (navContext.partNo || navContext.stationNo) { filterStockRows(); window.componentBiNavigationContext = null; } }
  function wireManualStockAdjustment() {
    const partInput = document.getElementById('cm-manual-part');
    const binInput = document.getElementById('cm-manual-bin');
    const remInput = document.getElementById('cm-manual-remaining');
    partInput?.addEventListener('input', () => { refreshManualAdjustmentBins(); refreshManualStockAdjustment(); });
    partInput?.addEventListener('change', () => { refreshManualAdjustmentBins(); refreshManualStockAdjustment(); });
    binInput?.addEventListener('input', refreshManualStockAdjustment);
    binInput?.addEventListener('change', refreshManualStockAdjustment);
    remInput?.addEventListener('input', refreshManualStockAdjustment);
    remInput?.addEventListener('change', refreshManualStockAdjustment);
    refreshManualAdjustmentBins();
    refreshManualStockAdjustment();
  }
  function refreshManualAdjustmentBins() {
    const partNo = vendorPartNo(val('cm-manual-part')).trim();
    const list = document.getElementById('cm-manual-bins');
    const binInput = document.getElementById('cm-manual-bin');
    if (!list) {return;}
    const options = receiveMappedBinOptions(partNo);
    list.innerHTML = options.map(o => `<option value="${esc(o.binId)}">${esc(o.stationNo)}${o.location ? ` — ${esc(o.location)}` : ''}</option>`).join('');
    if (binInput && options.length === 1) { binInput.value = options[0].binId; }
    else if (binInput && !options.some(o => o.binId === binInput.value)) { binInput.value = ''; }
  }
  function currentReceivePlan() {
    const partNo = receiveEntryPartNo();
    const quantity = Number(val('cs-qty'));
    return { partNo, quantity, plan: applyAllocationOverrides(allocationPlan(partNo, quantity), quantity) };
  }
  function allocationExportRows(plan) {
    return plan.map(row => [row.binId, row.stationNo, row.currentQty, row.requiredQty, row.maximumQty, row.shortage, row.recentConsumption, row.expectedStockOutDate || '', row.priorityScore, row.reason, row.quantity, row.currentQty + row.quantity]);
  }
  function exportAllocationPlan() { try { const current = currentReceivePlan(); if (!current.plan.length) { return toastMsg('Select a Part No., enter a positive whole-number quantity, and confirm an active mapped Common Bin exists.', 'inf'); } exportExcel(`shank-allocation-${today()}.xlsx`, 'Allocation Plan', ['Bin','Station','Current Qty','Required Qty','Target Max Qty','Shortage','90-Day Usage','Expected Stock-out','Priority','Reason','Receiving Qty','After Receipt'], allocationExportRows(current.plan)); } catch (error) { toastMsg(error.message, 'er'); } }
  function exportAllocationPlanPdf() { try { const current = currentReceivePlan(); if (!current.plan.length) { return toastMsg('Select a Part No., enter a positive whole-number quantity, and confirm an active mapped Common Bin exists.', 'inf'); } exportPdfTable('Shank Allocation Plan', ['Bin','Station','Current Qty','Required Qty','Target Max Qty','Shortage','90-Day Usage','Expected Stock-out','Priority','Reason','Receiving Qty','After Receipt'], allocationExportRows(current.plan)); } catch (error) { toastMsg(error.message, 'er'); } }
  function allocationHistoryMarkup() {
    const rows = [...(state.allocationBatches || [])].filter(batch => batch.status !== 'REVERSED').sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 10).map(batch => `<tr><td>${esc(batch.createdAt)}</td><td>${esc(batch.partNo)}</td><td>${batch.totalQuantity}</td><td>${batch.allocations?.length || 0}</td><td>${esc(batch.status)}</td><td>${esc(batch.username || '')}</td><td>${btn('Undo Receipt', `componentUndoAllocation('${esc(batch.id)}')`)}</td></tr>`).join('');
    return `<div class="card cm-stock-action-box"><div class="card-hd">Allocation History / Undo</div><div class="muted">Undo is allowed only when the affected stock has not changed after this receipt.</div>${table(['Date','Part No.','Total Qty','Bins','Status','User','Action'], rows, 'No allocation batches found.')}</div>`;
  }
  let receiveSubmissionInFlight = false;
  let receivePartNoAfterCommit = '';
  async function undoAllocation(batchId) {
    if (!canComponent('stock adjustment')) { return; }
    const batch = (state.allocationBatches || []).find(row => String(row.id) === String(batchId));
    if (!batch || batch.status === 'REVERSED') { return toastMsg('Allocation batch not found or already reversed.', 'er'); }
    if (typeof confirm === 'function' && !confirm(`Undo receipt batch ${batch.id} for ${batch.totalQuantity} units?`)) { return; }
    const stockRows = [], transactions = [], auditRows = [];
    for (const item of batch.allocations || []) {
      const row = state.stock.find(stock => String(stock.id) === String(item.stockId)) || stockFor(batch.partNo, item.binId);
      if (!row || Number(row.quantity || 0) !== Number(item.afterQuantity)) { return toastMsg(`Cannot undo ${batch.id}: stock changed in ${item.binId}.`, 'er'); }
      const next = Number(row.quantity || 0) - Number(item.quantity || 0);
      if (next < 0) { return toastMsg(`Cannot undo ${batch.id}: insufficient current quantity in ${item.binId}.`, 'er'); }
      const updated = { ...row, quantity: next, status: statusFor(next, row.minimumStock), updatedAt: nowIso() };
      const tx = { id: uid('ctx'), partNo: batch.partNo, binId: item.binId, quantity: Number(item.quantity || 0), direction: 'OUT', type: 'Receive Undo', beforeQuantity: row.quantity, afterQuantity: next, date: nowIso(), stationNo: item.stationNo || '', userId: user().id || null, username: user().username || user().name || 'Unknown', metadata: { allocationBatchId: batch.id, reason: 'Undo allocation receipt' } };
      stockRows.push(updated); transactions.push(tx);
      auditRows.push({ id: uid('ca'), action: 'COMPONENT_ALLOCATION_UNDO', entity: 'Allocation Batch', entityId: batch.id, details: tx, timestamp: nowIso(), userId: user().id || null, username: user().username || user().name || 'Unknown' });
    }
    const updatedBatch = { ...batch, status: 'REVERSED', reversedAt: nowIso(), reversedBy: user().username || user().name || 'Unknown' };
    if (typeof window.dPutMany !== 'function') { return toastMsg('Atomic undo is unavailable; no stock was changed.', 'er'); }
    try { await window.dPutMany([...stockRows.map(obj => ({ store: STORES.stock, obj })), ...transactions.map(obj => ({ store: STORES.tx, obj })), ...auditRows.map(obj => ({ store: STORES.audit, obj })), { store: ALLOCATION_BATCH_STORE, obj: updatedBatch }]); }
    catch (error) { return toastMsg(`Undo failed; no rows were committed. ${error.message || ''}`, 'er'); }
    stockRows.forEach(updated => { const index = state.stock.findIndex(row => row.id === updated.id); if (index >= 0) { state.stock[index] = updated; } });
    state.tx.push(...transactions); state.allocationBatches = state.allocationBatches.map(row => row.id === updatedBatch.id ? updatedBatch : row);
    toastMsg(`Allocation batch ${batch.id} was undone atomically.`, 'suc'); stock();
  }
  async function receiveStock() {
    if (!canComponent('stock receive')) {return;}
    if (receiveSubmissionInFlight) { return toastMsg('A stock receipt is already being processed.', 'inf'); }
    let current;
    try { current = currentReceivePlan(); } catch (error) { return toastMsg(error.message, 'er'); }
    const { partNo, quantity, plan } = current;
    const manualPart = partNo && !partByNo(partNo);
    const mappedOptions = receiveMappedBinOptions(partNo);
    if (!partNo || !Number.isInteger(quantity) || quantity < 1) {return toastMsg('Enter/select a valid Part No. and positive quantity', 'er');}
    if (!mappedOptions.length) {return toastMsg('Selected Part No. is not present in any active mapped Common Bin', 'er');}
    const sourceType = val('cs-source-type') || 'Supplier';
    if (!['Supplier', 'Arrangement'].includes(sourceType)) {return toastMsg('Select Supplier or Arrangement as the receiving source.', 'er');}
    if (!plan.length || plan.reduce((sum, row) => sum + row.quantity, 0) !== quantity) {return toastMsg('Allocation must total exactly the received quantity.', 'er');}
    const activePlan = plan.filter(row => row.quantity > 0);
    const batchId = uid('allocation-batch');
    const reference = val('cs-ref'); const remarks = val('cs-remarks'); const receivedAt = nowIso();
    const stockRows = []; const transactions = []; const auditRows = []; const persistedAllocations = [];
    for (const allocation of activePlan) {
      const b = state.bins.find(x => String(x.binId) === String(allocation.binId));
      const existing = stockFor(partNo, allocation.binId);
      const minimumStock = allocation.minimumStock || 0;
      const beforeQuantity = Number(existing?.quantity || 0);
      const stockRow = existing ? { ...existing } : { id: uid('stock'), partNo, binId: allocation.binId, quantity: 0, minimumStock, status: 'ZERO STOCK', createdAt: receivedAt };
      stockRow.quantity = beforeQuantity + allocation.quantity; stockRow.minimumStock = minimumStock; stockRow.status = statusFor(stockRow.quantity, minimumStock); stockRow.updatedAt = receivedAt;
      const tx = { id: uid('ctx'), partNo, binId: allocation.binId, quantity: allocation.quantity, direction: 'IN', type: 'Receive', beforeQuantity, afterQuantity: stockRow.quantity, date: receivedAt, stationNo: b?.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : b?.stationNo || '', userId: user().id || null, username: user().username || user().name || 'Unknown', metadata: { allocationBatchId: batchId, sourceType, reference, remarks, manualPartNo: !!manualPart, allocationMode: 'PER_BIN_BASELINE_THEN_PRIORITY', priorityScore: allocation.priorityScore, reason: allocation.reason, requiredQty: allocation.requiredQty, recentConsumption: allocation.recentConsumption } };
      stockRows.push(stockRow); transactions.push(tx); persistedAllocations.push({ stockId: stockRow.id, binId: allocation.binId, stationNo: tx.stationNo, quantity: allocation.quantity, beforeQuantity, afterQuantity: stockRow.quantity, reason: allocation.reason, priorityScore: allocation.priorityScore });
      auditRows.push({ id: uid('ca'), action: 'COMPONENT_ALLOCATION_RECEIVE', entity: 'Allocation Batch', entityId: batchId, details: tx, timestamp: receivedAt, userId: user().id || null, username: user().username || user().name || 'Unknown' });
    }
    const batch = { id: batchId, partNo, totalQuantity: quantity, sourceType, allocations: persistedAllocations, status: 'COMMITTED', createdAt: receivedAt, username: user().username || user().name || 'Unknown', reference, remarks, allocationMode: 'PER_BIN_BASELINE_THEN_PRIORITY' };
    if (typeof window.dPutMany !== 'function') { return toastMsg('Atomic stock receiving is unavailable; no stock was changed.', 'er'); }
    receiveSubmissionInFlight = true;
    try { await window.dPutMany([...stockRows.map(obj => ({ store: STORES.stock, obj })), ...transactions.map(obj => ({ store: STORES.tx, obj })), ...auditRows.map(obj => ({ store: STORES.audit, obj })), { store: ALLOCATION_BATCH_STORE, obj: batch }]); }
    catch (error) { receiveSubmissionInFlight = false; return toastMsg(`Stock receiving failed atomically; no rows were committed. ${error.message || ''}`, 'er'); }
    stockRows.forEach(row => { const index = state.stock.findIndex(existing => existing.id === row.id); if (index >= 0) { state.stock[index] = row; } else { state.stock.push(row); } });
    state.tx.push(...transactions); state.allocationBatches = [batch, ...(state.allocationBatches || [])];
    if (typeof addAudit === 'function') { for (const event of auditRows) { try { await addAudit(event.action, `${event.entity}: ${JSON.stringify(event.details)}`, 'COMPONENT_MANAGEMENT'); } catch (error) { console.error('Secondary allocation audit sink failed after atomic commit', error); } } }
    if (typeof window.notifyAdmins === 'function') { try { await window.notifyAdmins('New Shank Stock Received', `${user().name || user().username || 'Store Person'} received Part No. ${partNo} — Quantity: ${quantity} across ${activePlan.length} Bin(s) — Batch: ${batchId}`, { partNo, quantity, totalQuantity: quantity, allocations: persistedAllocations, receivedBy: user().username || user().name || 'Unknown', reference, receivedAt, batchId }); } catch (error) { console.error('Admin notification failed after committed stock receipt', error); } }
    toastMsg(`Stock received across ${activePlan.length} Bin${activePlan.length === 1 ? '' : 's'} using one-per-bin baseline and priority allocation. Batch: ${batchId}`, 'suc'); receiveSubmissionInFlight = false; receivePartNoAfterCommit = partNo; stock();
  }
  function verify() {
    const records = state.stock.filter(s => !isPencilPart(s.partNo) || receiveMappedBinOptions(s.partNo).some(option => option.binId === s.binId));
    const partOptions = [...new Set(records.map(s => String(s.partNo || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
    const rows = records.map(s => { const b = state.bins.find(bin => String(bin.binId) === String(s.binId)); const station = b?.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : (b?.stationNo || 'Station Not Assigned'); return `<tr class="cm-verification-row" data-part="${esc(s.partNo)}"><td>${esc(partDisplayWithComment(s.partNo))}</td><td>${esc(station)}</td><td>${esc(b?.location || '')}</td><td>${esc(s.binId || '')}</td><td>${s.quantity}</td><td><input class="fi cm-physical" data-part="${esc(s.partNo)}" data-bin="${esc(s.binId)}" type="number" min="0" value="${s.quantity}"></td><td><input class="fi cm-reason" data-part="${esc(s.partNo)}" data-bin="${esc(s.binId)}" placeholder="Required for difference"></td></tr>`; }).join('');
    const controls = `<div class="g3"><div class="fr"><label class="fl" for="cm-verify-part-search">Search Part No.</label><input class="fi" id="cm-verify-part-search" placeholder="Type Part No." data-oninput="componentFilterVerificationRows()"></div><div class="fr"><label class="fl" for="cm-verify-part-filter">Select Part No.</label><input class="fi" id="cm-verify-part-filter" list="cm-verify-part-options" placeholder="Type or select Part No." data-oninput="componentFilterVerificationRows()"><datalist id="cm-verify-part-options">${partOptions.map(part => `<option value="${esc(part)}"></option>`).join('')}</datalist></div><div id="cm-verify-filter-summary" class="muted">Showing ${records.length} of ${records.length}</div></div>`;
    shell('Physical Stock Verification', `<div class="alrt alrt-b">System quantity is never overwritten silently. A reason is required for every non-zero difference. Pencil Parts are verified independently inside their own Pencil Bin.</div>${controls}${table(['Part No.', 'Station / Scope', 'Location', 'Bin', 'System Qty', 'Physical Qty', 'Reason'], rows, 'No stock records available for verification.', '', ['Station','Location','Bin'])}<div class="btn-row">${btn('Save Verification', 'componentSaveVerification()', true)}</div>`);
  }
  function filterVerificationRows() { const search = String(document.getElementById('cm-verify-part-search')?.value || '').trim().toLowerCase(); const selected = String(document.getElementById('cm-verify-part-filter')?.value || '').trim().toLowerCase(); const rows = [...document.querySelectorAll('.cm-verification-row')]; let visible = 0; rows.forEach(row => { const part = String(row.dataset.part || '').toLowerCase(); const show = (!search || part.includes(search)) && (!selected || part.includes(selected)); row.style.display = show ? '' : 'none'; if (show) { visible += 1; } }); const summary = document.getElementById('cm-verify-filter-summary'); if (summary) { summary.textContent = `Showing ${visible} of ${rows.length}`; } }
  async function saveVerification() {
    if (!canComponent('stock adjustment')) { return; }
    const gunCountBefore = gunCountService ? gunCountService.calculateMetrics(state.gunRows || [], state.mappings || []).total : null;
    const inputs = [...document.querySelectorAll('.cm-physical')];
    const reasons = [...document.querySelectorAll('.cm-reason')];
    const pending = [];
    const seen = new Set();
    for (const input of inputs) {
      const partNo = input.dataset.part;
      const binId = input.dataset.bin;
      const rawPhysical = String(input.value == null ? '' : input.value).trim();
      const physical = Number(rawPhysical);
      const currentRow = stockFor(partNo, binId);
      const current = Number(currentRow?.quantity);
      if (!rawPhysical || !Number.isInteger(physical) || physical < 0 || !currentRow || !Number.isInteger(current) || current < 0) {
        return toastMsg(`Enter a valid non-negative whole quantity for ${partNo}; no verification rows were saved.`, 'er');
      }
      const key = String(currentRow.id);
      if (seen.has(key)) { return toastMsg(`Duplicate stock row for ${partNo}/${binId}; no verification rows were saved.`, 'er'); }
      seen.add(key);
      const difference = physical - current;
      const reason = reasons.find(item => item.dataset.part === partNo && item.dataset.bin === binId)?.value.trim();
      if (difference && !reason) { return toastMsg(`Reason required for ${partNo}; no verification rows were saved.`, 'er'); }
      if (difference) { pending.push({ partNo, binId, currentRow, current, physical, difference, reason }); }
    }
    if (!pending.length) { return toastMsg('No stock differences to save.', 'inf'); }
    const currentUser = user();
    const stockRows = [];
    const transactions = [];
    const auditRows = [];
    for (const item of pending) {
      const minimumStock = autoSafetyQuantity(item.partNo) || Number(item.currentRow.minimumStock || 0);
      const updated = { ...item.currentRow, quantity: item.physical, minimumStock, status: statusFor(item.physical, minimumStock), updatedAt: nowIso() };
      const tx = { id: uid('ctx'), partNo: item.partNo, binId: item.binId, quantity: Math.abs(item.difference), direction: item.difference < 0 ? 'OUT' : 'IN', type: 'Adjustment', beforeQuantity: item.current, afterQuantity: item.physical, date: nowIso(), stationNo: '', gunReferenceNo: '', userId: currentUser.id || null, username: currentUser.username || currentUser.name || 'Unknown', metadata: { physical: item.physical, reason: item.reason } };
      const auditRow = { id: uid('ca'), action: 'COMPONENT_STOCK_TRANSACTION', entity: 'Stock', entityId: updated.id, details: tx, timestamp: nowIso(), userId: currentUser.id || null, username: currentUser.username || currentUser.name || 'Unknown' };
      stockRows.push(updated);
      transactions.push(tx);
      auditRows.push(auditRow);
    }
    if (typeof window.dPutMany !== 'function') { return toastMsg('Atomic physical verification is unavailable; no stock was changed.', 'er'); }
    try {
      await window.dPutMany([
        ...stockRows.map(obj => ({ store: STORES.stock, obj })),
        ...transactions.map(obj => ({ store: STORES.tx, obj })),
        ...auditRows.map(obj => ({ store: STORES.audit, obj }))
      ]);
    } catch (error) {
      console.error('Atomic physical verification failed', error);
      return toastMsg(`Physical verification failed; no rows were committed. ${error.message || ''}`, 'er');
    }
    for (const updated of stockRows) {
      const index = state.stock.findIndex(row => row.id === updated.id);
      if (index >= 0) { state.stock[index] = updated; }
    }
    state.tx.push(...transactions);
    if (typeof addAudit === 'function') {
      for (const tx of transactions) {
        try { await addAudit('COMPONENT_STOCK_TRANSACTION', `Stock: ${JSON.stringify(tx)}`, 'COMPONENT_MANAGEMENT'); }
        catch (error) { console.error('Secondary audit sink failed after atomic verification', error); }
      }
    }
    if (gunCountService) {
      const invariant = gunCountService.assertPhysicalVerificationInvariant(state.gunRows || [], state.mappings || [], inputs);
      if (gunCountBefore !== null && invariant.gunCount !== gunCountBefore) { throw new Error(`Physical verification changed Gun Count from ${gunCountBefore} to ${invariant.gunCount}`); }
    }
    toastMsg('Physical verification saved atomically', 'suc');
    verify();
  }

  function replacement() {
    const allPeople = state.people.map(p => `<option value="${esc(p.name)}">${esc(p.department || '')}</option>`).join('');
    const replacementParts = [...new Set([...state.parts.filter(p => p.active !== false && validMappedPartNo(p.partNo)).map(p => p.partNo), ...state.mappings.map(m => m.partNo).filter(partNo => validMappedPartNo(partNo) && !partByNo(partNo))])].sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' }));
    const replacementPartOptions = replacementParts.map(part => `<option value="${esc(part)}" label="${esc(partByNo(part)?.description || '')}"></option>`).join('');
    shell('Replacement Entry', `<div class="alrt alrt-b">Maintenance Person is mandatory. Stock deduction and the replacement transaction are created together. Supported components: Fix Shank, Moving Shank, Fix Adaptor, Moving Adaptor, Fix Holder, Moving Holder, Pencil Shank.</div><div class="g4 cm-mobile-stack"><div class="fr"><label class="fl">Maintenance Person *</label><input class="fi" id="cr-person" list="cr-people" placeholder="Search/select person"><datalist id="cr-people">${allPeople}</datalist></div><div class="fr"><label class="fl">Maintenance Team / Department *</label><input class="fi" id="cr-team"></div><div class="fr"><label class="fl">Date *</label><input class="fi" id="cr-date" type="date" value="${today()}"></div><div class="fr"><label class="fl">Time *</label><input class="fi" id="cr-time" type="time" value="${new Date().toTimeString().slice(0, 5)}"></div></div><div class="g4"><div class="fr"><label class="fl">New Part No. *</label><input class="fi" id="cr-part" list="cr-part-options" placeholder="Type or select Part No." autocomplete="off"><datalist id="cr-part-options">${replacementPartOptions}</datalist></div><div class="fr"><label class="fl">Station No. *</label><input class="fi" id="cr-station" list="cr-station-options" placeholder="Type or select Station"><datalist id="cr-station-options"></datalist></div><div class="fr"><label class="fl">Gun Reference No. *</label><input class="fi" id="cr-gun" list="cr-gun-options" placeholder="Type or select Gun Reference"><datalist id="cr-gun-options"></datalist></div><div class="fr"><label class="fl">Component *</label><input class="fi" id="cr-component" list="cr-component-options" placeholder="Type or select Component"><datalist id="cr-component-options"></datalist></div></div><div class="g4"><div class="fr"><label class="fl">Shift *</label><select class="fi" id="cr-shift">${optionList(SHIFTS)}</select></div><div class="fr"><label class="fl">Old Part No. *</label><input class="fi" id="cr-old-part" list="cr-old-parts" placeholder="Removed vendor Part No."><datalist id="cr-old-parts">${state.parts.map(p => `<option value="${esc(p.partNo)}">${esc(p.componentType)}</option>`).join('')}</datalist></div><div class="fr"><label class="fl">Mapped Part Details</label><input class="fi" id="cr-mapped-component" readonly placeholder="Select Station, Gun and Component"></div><div class="fr"><label class="fl">Common Bin</label><input class="fi" id="cr-bin" readonly></div><div class="fr"><label class="fl">Available / Minimum</label><input class="fi" id="cr-availability" readonly></div><div class="fr"><label class="fl">Replacement Qty *</label><input class="fi" id="cr-qty" type="number" min="1" value="1"></div></div><div class="g4"><div class="fr"><label class="fl">Old Part Condition *</label><select class="fi" id="cr-condition">${optionList(CONDITIONS)}</select></div><div class="fr"><label class="fl">Action *</label><select class="fi" id="cr-action">${optionList(ACTIONS)}</select></div><div class="fr"><label class="fl">Remarks</label><input class="fi" id="cr-remarks"></div><div class="fr"><label class="fl">Logged-in User</label><input class="fi" value="${esc(user().username || user().name || 'Unknown')}" readonly></div></div><div id="cr-warning"></div><div class="btn-row">${btn('Save Replacement', 'componentSaveReplacement()', true)}${btn('Import Replacement List', 'componentReplacementImport()')}${btn('Add Maintenance Person', "componentAddPerson()")}</div>`);
    const replacementPart = document.getElementById('cr-part'); const replacementPartChanged = () => { const oldPart = document.getElementById('cr-old-part'); const selected = replacementPart.value.trim().toLowerCase(); const previous = replacementPart.dataset.previousValue || ''; if (oldPart && selected && oldPart.value.trim().toLowerCase() === selected || oldPart && previous && oldPart.value.trim().toLowerCase() === previous.trim().toLowerCase()) { oldPart.value = ''; } replacementPart.dataset.previousValue = replacementPart.value; populateStationsForPart(); }; replacementPart?.addEventListener('input', replacementPartChanged); replacementPart?.addEventListener('change', replacementPartChanged); for (const event of ['input', 'change']) { document.getElementById('cr-station')?.addEventListener(event, populateGunsForPart); document.getElementById('cr-gun')?.addEventListener(event, populateComponentsForPart); document.getElementById('cr-component')?.addEventListener(event, refreshReplacementBin); } document.getElementById('cr-qty')?.addEventListener('input', updateAvailability);
  }
  function mappingsForReplacementPart() { const partNo = sel('cr-part'); const key = partKey(partNo); return state.mappings.filter(m => key && partKey(m.partNo) === key && POSITIONS.includes(m.position)); }
  function setReplacementSelect(id, placeholder, values) { return setIdentifierSuggestions(id, placeholder, values); }
  function populateStationsForPart() { const mappings = mappingsForReplacementPart(); const stations = [...new Map(mappings.map(m => [normalStation(m.stationNo), canonicalStation(m.stationNo)])).values()]; setReplacementSelect('cr-station', stations.length ? 'Select Station' : 'No mapped Station found', stations); setReplacementSelect('cr-gun', 'Select Station first', []); setReplacementSelect('cr-component', 'Select Gun first', []); updateMappedComponent(); refreshReplacementBin(); }
  function populateGunsForPart() { const station = sel('cr-station'); const mappings = mappingsForReplacementPart().filter(m => sameStation(m.stationNo, station)); const guns = [...new Set(mappings.map(m => m.gunReferenceNo))]; setReplacementSelect('cr-gun', guns.length ? 'Select Gun' : 'No mapped Gun found', guns); setReplacementSelect('cr-component', 'Select Gun first', []); updateMappedComponent(); refreshReplacementBin(); }
  function populateComponentsForPart() { const station = sel('cr-station'); const gun = sel('cr-gun'); const mappings = mappingsForReplacementPart().filter(m => sameStation(m.stationNo, station) && String(m.gunReferenceNo) === String(gun)); const components = [...new Set(mappings.map(m => m.position))]; setReplacementSelect('cr-component', components.length ? 'Select Component' : 'No mapped Component found', components, !components.length); updateMappedComponent(); refreshReplacementBin(); }
  function updateMappedComponent() { const partNo = sel('cr-part'); const station = sel('cr-station'); const gun = sel('cr-gun'); const component = sel('cr-component'); const mapping = mappingsForReplacementPart().find(m => sameStation(m.stationNo, station) && String(m.gunReferenceNo) === String(gun) && String(m.position) === String(component)); const details = document.getElementById('cr-mapped-component'); if (details) { details.value = mapping ? `${mapping.position} — ${partNo} — ${mapping.stationNo} / ${mapping.gunReferenceNo}` : ''; } }
  function refreshReplacementBin() { updateMappedComponent(); const partNo = sel('cr-part'); const station = sel('cr-station'); const pencil = partNo && isPencilPart(partNo); const pencilOption = pencil ? receiveMappedBinOptions(partNo)[0] : null; const bin = document.getElementById('cr-bin'); if (bin) { bin.value = pencil ? (pencilOption?.binId || '') : (activeBinForStation(station)?.binId || ''); } updateAvailability(); }
  function updateAvailability() { const partNo = sel('cr-part'); const binId = val('cr-bin'); const s = stockFor(partNo, binId); const p = partByNo(partNo); const quantityOnHand = Number(s?.quantity || 0); const minimum = Number(s?.minimumStock ?? p?.minimumStock ?? 0); const stockStatus = statusFor(quantityOnHand, minimum); const critical = Boolean(p?.criticalFlag || p?.analytics?.criticalFlag || p?.consumptionConfig?.criticalFlag); const el = document.getElementById('cr-availability'); if (el) {el.value = `${quantityOnHand} / ${minimum} (${stockStatus})${critical ? ' — CRITICAL PART' : ''}`;} const warning = document.getElementById('cr-warning'); const qty = Number(val('cr-qty') || 0); if (warning) { warning.innerHTML = qty > quantityOnHand ? '<div class="alrt alrt-r">INSUFFICIENT STOCK — replacement cannot be saved</div>' : stockStatus === 'ZERO STOCK' ? '<div class="alrt alrt-r">OUT OF STOCK</div>' : critical && stockStatus !== 'OK STOCK' ? '<div class="alrt alrt-y">CRITICAL PART — stock is below the configured minimum</div>' : stockStatus === 'LOW STOCK' ? '<div class="alrt alrt-y">LOW STOCK</div>' : ''; } }
  let pendingReplacementImport = null;
  function replacementImportNormalize(value) { return String(value == null ? '' : value).trim(); }
  function replacementImportDate(value) {
    const raw = replacementImportNormalize(value);
    if (!raw) { return today(); }
    let candidate = '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) { candidate = raw; }
    else {
      const match = raw.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2,4})/);
      if (match) {
        const year = match[3].length === 2 ? `20${match[3]}` : match[3];
        candidate = `${year}-${String(match[1]).padStart(2, '0')}-${String(match[2]).padStart(2, '0')}`;
      } else {
        const parsed = new Date(raw);
        if (!Number.isNaN(parsed.getTime())) { candidate = `${parsed.getFullYear()}-${String(parsed.getMonth() + 1).padStart(2, '0')}-${String(parsed.getDate()).padStart(2, '0')}`; }
      }
    }
    const parts = /^(\d{4})-(\d{2})-(\d{2})$/.exec(candidate);
    if (!parts) { return ''; }
    const valid = new Date(Date.UTC(Number(parts[1]), Number(parts[2]) - 1, Number(parts[3]))).toISOString().slice(0, 10);
    return valid === candidate ? candidate : '';
  }
  function inferReplacementStation(row) { if (row.stationNo) { return canonicalStation(row.stationNo); } const matches = [...new Set(state.mappings.filter(m => normalStation(m.gunReferenceNo) === normalStation(row.gunReferenceNo)).map(m => canonicalStation(m.stationNo)).filter(Boolean))]; return matches.length === 1 ? matches[0] : ''; }
  function historicalFingerprint(row) { return [replacementImportNormalize(row.newPartNo || row.partNo).toLowerCase(), replacementImportDate(row.replacementDate || row.date), replacementImportNormalize(row.stationNo).toLowerCase(), replacementImportNormalize(row.gunReferenceNo).toLowerCase(), Number(row.quantity || 1)].join('|'); }
  function replacementMappingForRow(row) {
    const partNo = replacementImportNormalize(row.newPartNo || row.partNo);
    const stationNo = canonicalStation(replacementImportNormalize(row.stationNo));
    const gunKey = normalGunReference(row.gunReferenceNo);
    const candidates = state.mappings.filter(mapping => partKey(mapping.partNo) === partKey(partNo)
      && sameStation(mapping.stationNo, stationNo)
      && normalGunReference(mapping.gunReferenceNo) === gunKey
      && POSITIONS.includes(mapping.position));
    if (!candidates.length) { return { mapping: null, reason: 'Part → Station → Gun mapping does not exist' }; }
    const requestedComponent = replacementImportNormalize(row.componentType);
    let matches = candidates;
    if (requestedComponent) {
      const requestedKey = normalGunReference(pencilPositionKey(requestedComponent));
      matches = candidates.filter(mapping => normalGunReference(pencilPositionKey(mapping.position)) === requestedKey);
      if (!matches.length) { return { mapping: null, reason: 'Component Type does not match the mapped component' }; }
    }
    if (matches.length !== 1) { return { mapping: null, reason: 'Component mapping is ambiguous; specify a valid Component Type' }; }
    return { mapping: matches[0], reason: '' };
  }
  function replacementMappingMatchesBin(mapping, bin) {
    if (!mapping?.binId) { return false; }
    const mappedBin = state.bins.find(item => String(item.binId || '') === String(mapping.binId));
    return Boolean(mappedBin && bin && (String(mappedBin.binId || '') === String(bin.binId || '')
      || String(mappedBin.mergedInto || '') === String(bin.binId || '')));
  }
  function replacementMappingStatus(row) { const partNo = replacementImportNormalize(row.newPartNo || row.partNo); const stationNo = replacementImportNormalize(row.stationNo); const gunReferenceNo = replacementImportNormalize(row.gunReferenceNo); const componentType = replacementImportNormalize(row.componentType); if (!stationNo && !gunReferenceNo) { return 'NOT_PROVIDED'; } if (!stationNo || !gunReferenceNo) { return 'INCOMPLETE'; } const gunKey = normalGunReference(gunReferenceNo); const matches = state.mappings.filter(m => partKey(m.partNo) === partKey(partNo) && sameStation(m.stationNo, stationNo) && normalGunReference(m.gunReferenceNo) === gunKey); if (!matches.length) { return 'MISMATCH'; } const componentKey = normalGunReference(componentType); if (componentKey) { return matches.some(m => { const positionKey = normalGunReference(m.position); return positionKey === componentKey || positionKey.includes(componentKey) || componentKey.includes(positionKey); }) ? 'MATCHED' : 'MISMATCH'; } return new Set(matches.map(m => normalGunReference(m.position))).size > 1 ? 'AMBIGUOUS' : 'MATCHED'; }
  async function historicalPreviewSummary(rows) { const existing = await gAll(STORES.historicalConsumption); const existingKeys = new Set(existing.map(historicalFingerprint)); const seen = new Set(); let valid = 0, invalid = 0, duplicate = 0, mappingReview = 0; rows.forEach(row => { const partNo = replacementImportNormalize(row.newPartNo); const qty = Number(row.quantity || 1); const date = replacementImportDate(row.replacementDate); const key = historicalFingerprint(row); row._status = ''; row.mappingStatus = replacementMappingStatus(row); if (!partNo || !partByNo(partNo) || !date || !Number.isInteger(qty) || qty < 1) { row._status = 'INVALID'; invalid += 1; } else if (existingKeys.has(key) || seen.has(key)) { row._status = 'DUPLICATE'; duplicate += 1; } else { row._status = ['MISMATCH', 'INCOMPLETE', 'AMBIGUOUS'].includes(row.mappingStatus) ? 'MAPPING REVIEW' : 'VALID'; if (row._status === 'MAPPING REVIEW') { mappingReview += 1; } valid += 1; seen.add(key); } }); return { valid, invalid, duplicate, mappingReview, total: rows.length }; }
  function downloadHistoricalRejected() { const rows = (pendingReplacementImport?.rows || []).filter(row => row._status === 'INVALID' || row._status === 'DUPLICATE' || row._status === 'MAPPING REVIEW'); if (!rows.length) { return toastMsg('No rejected or mapping-review rows to export', 'inf'); } download(`historical-consumption-review-${today()}.csv`, csv([['SR No.','Part No.','Date','Station','Gun Reference','Quantity','Status','Mapping Status'], ...rows.map(row => [row.srNo, row.newPartNo, row.replacementDate, row.stationNo, row.gunReferenceNo, row.quantity, row._status, row.mappingStatus || 'NOT_PROVIDED'])]), 'text/csv'); }
  function downloadHistoricalTemplate() { download('historical-consumption-template.csv', csv([['Date','Part No.','Quantity','Station No.','Gun Reference No.','Component Type'], ['2026-01-01','06-0479','1','RFA 15','GUN-01','Fix Adaptor']]), 'text/csv'); }
  function replacementImportField(header) { const h = fieldKey(header); if (h === 'srno' || h === 'serialno' || h === 'serialnumber') { return 'srNo'; } if (h === 'oldpartno' || h === 'originalpartno' || h === 'replacedpartno') { return 'oldPartNo'; } if (h.includes('shankdescription') || h.includes('shankdiscription') || h === 'partno' || h === 'partnumber' || h === 'newpartno') { return 'newPartNo'; } if (h === 'date' || h.includes('replacementdate')) { return 'replacementDate'; } if (h.includes('station')) { return 'stationNo'; } if (h.includes('gun') || h.includes('reference')) { return 'gunReferenceNo'; } if (h.includes('component') || h.includes('type')) { return 'componentType'; } if (h === 'qty' || h === 'quantity') { return 'quantity'; } return ''; }
  function parseReplacementCsv(text) { const lines = String(text || '').split(/\r?\n/).filter(line => line.trim()); if (!lines.length) { return []; } const split = line => { const out = []; let cell = ''; let quoted = false; for (const ch of line) { if (ch === '"') { quoted = !quoted; } else if ((ch === ',' || ch === '\t' || ch === ';') && !quoted) { out.push(cell.trim()); cell = ''; } else { cell += ch; } } out.push(cell.trim()); return out; }; const headers = split(lines[0]); const fields = headers.map(replacementImportField); return lines.slice(1).map((line, index) => { const values = split(line); const row = { srNo: String(index + 1), newPartNo: '', oldPartNo: '', replacementDate: today(), stationNo: '', gunReferenceNo: '', componentType: '', quantity: '1', sourceRow: index + 2 }; fields.forEach((field, column) => { if (field) { row[field] = replacementImportNormalize(values[column]); } }); return row; }).filter(row => Object.values(row).some(value => replacementImportNormalize(value) && value !== '1')) ; }
  function inferReplacementOldPart(row) {
    const candidates = state.mappings.filter(mapping => sameStation(mapping.stationNo, row.stationNo)
      && normalGunReference(mapping.gunReferenceNo) === normalGunReference(row.gunReferenceNo));
    const importedPart = partByNo(row.newPartNo);
    const component = replacementImportNormalize(row.componentType || importedPart?.componentType || '');
    if (component) {
      const componentKey = normalGunReference(pencilPositionKey(component));
      const typed = candidates.filter(mapping => normalGunReference(pencilPositionKey(mapping.position || mapping.componentType || '')) === componentKey);
      return typed.length === 1 ? typed[0].partNo : '';
    }
    const previousParts = candidates.filter(mapping => partKey(mapping.partNo) !== partKey(row.newPartNo));
    return previousParts.length === 1 ? previousParts[0].partNo : '';
  }
  function replacementImportRowsHtml() {
    const rows = pendingReplacementImport?.rows || [];
    return rows.map((row, index) => {
      row.oldPartNo = row.oldPartNo || inferReplacementOldPart(row);
      row.mappingStatus = row.mappingStatus || replacementMappingStatus(row);
      return `<tr><td>${esc(row.srNo || index + 1)}</td><td><input class="fi cm-replacement-import-edit" data-row="${index}" data-field="newPartNo" value="${esc(row.newPartNo || '')}" placeholder="Enter new Part No."></td><td><input class="fi cm-replacement-import-edit" data-row="${index}" data-field="oldPartNo" value="${esc(row.oldPartNo || '')}" placeholder="Enter/verify old Part No."></td><td><input class="fi cm-replacement-import-edit" data-row="${index}" data-field="replacementDate" type="date" value="${esc(row.replacementDate || today())}"></td><td><input class="fi cm-replacement-import-edit" data-row="${index}" data-field="stationNo" value="${esc(row.stationNo || '')}" placeholder="Enter station"></td><td><input class="fi cm-replacement-import-edit" data-row="${index}" data-field="gunReferenceNo" value="${esc(row.gunReferenceNo || '')}" placeholder="Enter gun reference"></td><td>${esc(row._status || 'NOT CHECKED')}</td><td>${esc(row.mappingStatus)}</td></tr>`;
    }).join('');
  }
  async function saveManualHistoricalConsumption() {
    if (!canComponent('consumptionImport')) { return; }
    const partNo = replacementImportNormalize(val('cr-manual-historical-part'));
    const date = replacementImportDate(val('cr-manual-historical-date'));
    const quantity = Number(val('cr-manual-historical-qty'));
    if (!partNo || !date || !Number.isInteger(quantity) || quantity < 1) { return toastMsg('Enter a Part No., valid Date, and positive integer Quantity', 'er'); }
    const stationNo = canonicalStation(val('cr-manual-historical-station'));
    const gunReferenceNo = replacementImportNormalize(val('cr-manual-historical-gun'));
    const suppliedComponentType = replacementImportNormalize(val('cr-manual-historical-type'));
    const mapping = (stationNo || gunReferenceNo) ? replacementMappingForRow({ newPartNo: partNo, stationNo, gunReferenceNo, componentType: suppliedComponentType }) : { mapping: null };
    const mappingStatus = replacementMappingStatus({ newPartNo: partNo, stationNo, gunReferenceNo, componentType: suppliedComponentType });
    const mappingNeedsReview = (stationNo || gunReferenceNo) && (mappingStatus !== 'MATCHED' || !mapping.mapping);
    const fingerprint = historicalFingerprint({ newPartNo: partNo, replacementDate: date, stationNo, gunReferenceNo, quantity });
    const duplicate = (await gAll(STORES.historicalConsumption)).some(existing => historicalFingerprint(existing) === fingerprint);
    if (duplicate) { return toastMsg('Duplicate historical consumption entry detected. No record was saved and current stock was not changed.', 'er'); }
    const currentUser = user();
    const batchId = uid('historical-manual-batch');
    const row = { id: uid('historical-consumption'), importBatchId: batchId, sourceFile: 'Manual Entry', sourceRow: '', partNo, newPartNo: partNo, quantity, replacementDate: date, date, stationNo, gunReferenceNo, componentType: mapping.mapping?.position || suppliedComponentType || partByNo(partNo)?.componentType || 'Historical Shank', mappingStatus, historical: true, importedAt: nowIso(), importedBy: currentUser.username || currentUser.name || 'Unknown' };
    const auditDetails = { batchId, rows: 1, validCount: 1, invalidCount: 0, duplicateCount: 0, mappingReviewCount: 0, stockChanged: false };
    const auditRow = { id: uid('ca'), action: 'COMPONENT_HISTORICAL_CONSUMPTION_MANUAL', entity: 'Historical Consumption', entityId: batchId, details: auditDetails, timestamp: nowIso(), userId: currentUser.id || null, username: currentUser.username || currentUser.name || 'Unknown' };
    if (typeof window.dPutMany !== 'function') { return toastMsg('Atomic Historical save is unavailable. No record was saved.', 'er'); }
    try { await window.dPutMany([{ store: STORES.historicalConsumption, obj: row }, { store: STORES.audit, obj: auditRow }]); }
    catch (error) { console.error('Atomic manual Historical Consumption save failed', error); return toastMsg(`Historical entry failed; no record was saved. ${error.message || ''}`, 'er'); }
    if (typeof addAudit === 'function') {
      try { await addAudit('COMPONENT_HISTORICAL_CONSUMPTION_MANUAL', `Historical Consumption: ${JSON.stringify(auditDetails)}`, 'COMPONENT_MANAGEMENT'); }
      catch (error) { console.error('Secondary audit sink failed after manual Historical save', error); }
    }
    await load(); replacementImportView();
    if (mappingNeedsReview) { return toastMsg(`Manual historical consumption saved for analytics with mapping status ${mappingStatus}. Review the Station/Gun reference. Current stock was not changed. Batch: ${batchId}`, 'suc'); }
    toastMsg(`Manual historical consumption saved. Current stock was not changed. Batch: ${batchId}`, 'suc');
  }
  function historicalPartOptions() { return state.parts.filter(p => p.active !== false && validMappedPartNo(p.partNo)).sort((a, b) => String(a.partNo).localeCompare(String(b.partNo), undefined, { numeric: true, sensitivity: 'base' })).map(p => `<option value="${esc(p.partNo)}" label="${esc(p.description || p.componentType || '')}"></option>`).join(''); }
  function historicalMappingsForPart() { const partNo = val('cr-manual-historical-part'); const key = partKey(partNo); return state.mappings.filter(m => key && partKey(m.partNo) === key); }
  function historicalSetSelect(id, placeholder, values, selected = '') { setIdentifierSuggestions(id, placeholder, values, { selected }); }
  function populateHistoricalGuns() { const station = val('cr-manual-historical-station'); const mappings = historicalMappingsForPart().filter(m => sameStation(m.stationNo, station)); const previous = val('cr-manual-historical-gun'); const guns = mappings.map(m => m.gunReferenceNo); historicalSetSelect('cr-manual-historical-gun', guns.length ? 'Select Gun Reference' : 'No mapped Gun found', guns, previous); if (guns.length === 1) { document.getElementById('cr-manual-historical-gun').value = guns[0]; } }
  function populateHistoricalPartDetails() { const partNo = val('cr-manual-historical-part'); const part = partByNo(partNo); const mappings = historicalMappingsForPart(); const stations = mappings.map(m => canonicalStation(m.stationNo)); const previousStation = val('cr-manual-historical-station'); historicalSetSelect('cr-manual-historical-station', stations.length ? 'Select Station' : 'No mapped Station found', stations, previousStation); const type = [...new Set(mappings.map(m => m.position || m.componentType).filter(Boolean))][0] || part?.componentType || (part ? '' : 'Historical Shank'); const component = document.getElementById('cr-manual-historical-type'); if (component) { component.value = type; component.readOnly = Boolean(part); } populateHistoricalGuns(); }
  function replacementImportView() { const people = state.people.map(p => `<option value="${esc(p.name)}">${esc(p.department || '')}</option>`).join(''); const importPerson = pendingReplacementImport?.maintenancePerson || ''; const importTeam = pendingReplacementImport?.maintenanceTeam || ''; const importMode = pendingReplacementImport?.importMode || 'HISTORICAL'; shell('Replacement List Import', `<div class="alrt alrt-b">Historical Consumption (default) adds past usage to analytics only and never changes current stock. Explicitly choose Live Replacement to deduct stock.</div><div class="g3"><div class="fr"><label class="fl">Maintenance Person *</label><input class="fi" id="cr-import-person" list="cr-import-people" placeholder="Select person" value="${esc(importPerson)}"><datalist id="cr-import-people">${people}</datalist></div><div class="fr"><label class="fl">Maintenance Team / Department *</label><input class="fi" id="cr-import-team" placeholder="Enter team" value="${esc(importTeam)}"></div><div class="fr"><label class="fl">Import Mode</label><select class="fi" id="cr-import-mode"><option value="LIVE" ${importMode === 'LIVE' ? 'selected' : ''}>Live Replacement — deduct stock</option><option value="HISTORICAL" ${importMode === 'HISTORICAL' ? 'selected' : ''}>Historical Consumption — analytics only</option></select></div></div><div class="card" data-style="margin-top:12px"><div class="card-hd">Manual Historical Consumption Entry</div><div class="alrt alrt-b">Type or select a Part No. Known parts auto-load mapped Stations, Guns and Component Type. An unlisted historical Part No. can be entered manually; it is analytics-only and does not change stock. Station and Gun Reference can be typed or selected from mapped suggestions for that Part. Unmatched or incomplete references are saved for analytics with Mapping Review status; current stock is never changed.</div><div class="g4"><div class="fr"><label class="fl">Part No. *</label><input class="fi" id="cr-manual-historical-part" list="cr-manual-historical-parts" placeholder="Type or select Part No." autocomplete="off"><datalist id="cr-manual-historical-parts">${historicalPartOptions()}</datalist></div><div class="fr"><label class="fl">Date *</label><input class="fi" id="cr-manual-historical-date" type="date" value="${today()}"></div><div class="fr"><label class="fl">Quantity *</label><input class="fi" id="cr-manual-historical-qty" type="number" min="1" step="1" placeholder="1"></div><div class="fr"><label class="fl">Component Type</label><input class="fi" id="cr-manual-historical-type" placeholder="Auto-selected; unlisted Part No. defaults to Historical Shank" readonly></div><div class="fr"><label class="fl">Station</label><input class="fi" id="cr-manual-historical-station" list="cr-manual-historical-station-options" placeholder="Type or select Station"><datalist id="cr-manual-historical-station-options"></datalist></div><div class="fr"><label class="fl">Gun Reference</label><input class="fi" id="cr-manual-historical-gun" list="cr-manual-historical-gun-options" placeholder="Type or select Gun Reference"><datalist id="cr-manual-historical-gun-options"></datalist></div></div><div class="btn-row">${btn('Save Manual Historical Consumption', 'componentSaveManualHistoricalConsumption()', true)}</div></div><div class="btn-row">${btn('Download Historical Template', 'componentDownloadHistoricalTemplate()')}${pendingReplacementImport?.summary ? `<span class="muted">Preview: ${pendingReplacementImport.summary.valid} valid | ${pendingReplacementImport.summary.invalid} invalid | ${pendingReplacementImport.summary.duplicate} duplicate | ${pendingReplacementImport.summary.mappingReview || 0} mapping review | Stock Changed: No (Historical mode)</span>` : ''}${pendingReplacementImport ? btn('Export Rejected Rows', 'componentDownloadHistoricalRejected()') : ''}<span id="cr-import-progress" class="muted"></span><label class="btn btn-s">Import Excel/CSV<input type="file" id="cr-import-file" accept=".xlsx,.xls,.csv" hidden></label>${pendingReplacementImport ? btn('Confirm Replacement Import', 'componentCommitReplacementImport()', true) : ''}</div>${pendingReplacementImport ? table(['SR No.','New Part No.','Old Part No. (verify)','Date','Station','Gun No. / Gun Reference No.','Row Status','Mapping Status'], replacementImportRowsHtml(), 'No replacement rows detected.', '', ['Shank Description','Station','Gun No. / Gun Reference No.']) : '<p>Select an Excel/CSV file to begin.</p>'}`); document.getElementById('cr-import-file')?.addEventListener('change', readReplacementImportFile); for (const event of ['input', 'change']) { document.getElementById('cr-manual-historical-part')?.addEventListener(event, populateHistoricalPartDetails); document.getElementById('cr-manual-historical-station')?.addEventListener(event, populateHistoricalGuns); } if (val('cr-manual-historical-part')) { populateHistoricalPartDetails(); } }
  async function readReplacementImportFile(event) { const file = event.target.files?.[0]; if (!file) { return; } const importPerson = val('cr-import-person'); const importTeam = val('cr-import-team'); let rows = []; try { const parsed = await parseWorkbookRows(file); if (/\.(xlsx|xls|xlsm)$/i.test(file.name)) { const matrix = parsed.map(row => Object.keys(row).sort((a, b) => Number(a.slice(5)) - Number(b.slice(5))).map(key => row[key])); rows = parseReplacementCsv(matrix.map(row => row.join('\t')).join('\n')); } else { rows = parsed; } } catch (error) { return toastMsg(`Import failed: ${error.message}`, 'er'); } rows.forEach(row => { row.replacementDate = replacementImportDate(row.replacementDate); row.stationNo = inferReplacementStation(row); }); pendingReplacementImport = { fileName: file.name, rows, maintenancePerson: importPerson, maintenanceTeam: importTeam, importMode: val('cr-import-mode') || 'HISTORICAL' }; if (pendingReplacementImport.importMode === 'HISTORICAL') { pendingReplacementImport.summary = await historicalPreviewSummary(rows); } replacementImportView(); }
  function applyReplacementImportEdits() { document.querySelectorAll('.cm-replacement-import-edit').forEach(input => { const row = pendingReplacementImport?.rows?.[Number(input.dataset.row)]; if (row) { row[input.dataset.field] = input.value; } }); }
  async function commitReplacementImport() {
    const importMode = val('cr-import-mode') || pendingReplacementImport?.importMode || 'HISTORICAL';
    if (!canComponent(importMode === 'HISTORICAL' ? 'consumptionImport' : 'replacement') || !pendingReplacementImport) { return; }
    applyReplacementImportEdits();
    if (importMode === 'HISTORICAL') {
      const preparedHistorical = pendingReplacementImport.rows.map(row => ({ ...row, replacementDate: replacementImportDate(row.replacementDate), stationNo: inferReplacementStation(row) }));
      const summary = await historicalPreviewSummary(preparedHistorical);
      pendingReplacementImport.summary = summary;
      if (summary.invalid || summary.duplicate) { replacementImportView(); return toastMsg(`Historical preview blocked: ${summary.invalid} invalid and ${summary.duplicate} duplicate rows. Export rejected rows or correct the preview.`, 'er'); }
      const batchId = uid('historical-batch'); const progress = document.getElementById('cr-import-progress'); const records = preparedHistorical.map(row => ({ id: uid('historical-consumption'), importBatchId: batchId, sourceFile: pendingReplacementImport.fileName, sourceRow: row.sourceRow, partNo: replacementImportNormalize(row.newPartNo), newPartNo: replacementImportNormalize(row.newPartNo), quantity: Number(row.quantity || 1), replacementDate: row.replacementDate, date: row.replacementDate, stationNo: row.stationNo || '', gunReferenceNo: row.gunReferenceNo || '', shift: row.shift || '', componentType: replacementMappingForRow({ ...row, componentType: '' }).mapping?.position || row.componentType || partByNo(row.newPartNo)?.componentType || 'Historical Shank', mappingStatus: row.mappingStatus || replacementMappingStatus(row), historical: true, importedAt: nowIso(), importedBy: user().username || user().name || 'Unknown' }));
      if (!records.length) { return toastMsg('No historical consumption rows to import.', 'er'); }
      const auditDetails = { batchId, sourceFile: pendingReplacementImport.fileName, rows: records.length, validCount: summary.valid, invalidCount: summary.invalid, duplicateCount: summary.duplicate, mappingReviewCount: summary.mappingReview || 0, stockChanged: false };
      const currentUser = user();
      const auditRow = { id: uid('ca'), action: 'COMPONENT_HISTORICAL_CONSUMPTION_IMPORT', entity: 'Historical Consumption', entityId: batchId, details: auditDetails, timestamp: nowIso(), userId: currentUser.id || null, username: currentUser.username || currentUser.name || 'Unknown' };
      if (typeof window.dPutMany !== 'function') { return toastMsg('Atomic Historical import is unavailable. No rows were imported.', 'er'); }
      if (progress) { progress.textContent = `Saving ${records.length} historical rows atomically…`; }
      try {
        await window.dPutMany([...records.map(obj => ({ store: STORES.historicalConsumption, obj })), { store: STORES.audit, obj: auditRow }]);
      } catch (error) {
        if (progress) { progress.textContent = ''; }
        console.error('Atomic Historical Consumption import failed', error);
        return toastMsg(`Historical import failed; no rows were committed. ${error.message || ''}`, 'er');
      }
      if (typeof addAudit === 'function') {
        try { await addAudit('COMPONENT_HISTORICAL_CONSUMPTION_IMPORT', `Historical Consumption: ${JSON.stringify(auditDetails)}`, 'COMPONENT_MANAGEMENT'); }
        catch (error) { console.error('Secondary audit sink failed after atomic Historical import', error); }
      }
      const count = records.length; pendingReplacementImport = null; await load(); open('procurement'); return toastMsg(`${count} historical consumption rows imported. Current stock was not changed. Batch: ${batchId}`, 'suc');
    }
    const personInput = val('cr-import-person') || pendingReplacementImport.maintenancePerson || '';
    const team = val('cr-import-team') || pendingReplacementImport.maintenanceTeam || '';
    const personKey = value => String(value == null ? '' : value).trim().replace(/\s+/g, ' ').toLowerCase();
    let person = state.people.find(p => personKey(p.name) === personKey(personInput) || personKey(p.username) === personKey(personInput));
    if (!personInput || !team.trim()) { return toastMsg(`Maintenance Person/Team validation failed. Person: ${personInput || '(empty)'}. Please enter a Maintenance Person and Team.`, 'er'); }
    const prepared = pendingReplacementImport.rows.map(row => ({ ...row, replacementDate: replacementImportDate(row.replacementDate), stationNo: inferReplacementStation(row) }));
    const currentUser = user();
    const newPerson = person ? null : { id: uid('person'), name: personInput.trim(), department: team.trim(), active: true, createdAt: nowIso(), createdBy: currentUser.username || currentUser.name || 'Unknown' };
    if (newPerson) { person = newPerson; }
    const stagedStock = new Map();
    const auditEvents = [];
    const importFileName = pendingReplacementImport.fileName;
    const binStockKey = (partNo, binId) => `${partKey(partNo)}\u001f${String(binId || '')}`;
    const makeAuditRow = (action, entity, entityId, details) => ({
      id: uid('ca'), action, entity, entityId: entityId || null, details: details || {}, timestamp: nowIso(),
      userId: currentUser.id || null, username: currentUser.username || currentUser.name || 'Unknown'
    });

    // Validate every row and compute all stock effects before writing any data.
    for (let index = 0; index < prepared.length; index += 1) {
      const row = prepared[index];
      const rowNumber = row.srNo || index + 1;
      const quantity = Number(row.quantity || 1);
      const newPartNo = replacementImportNormalize(row.newPartNo);
      const oldPartNo = replacementImportNormalize(row.oldPartNo || inferReplacementOldPart(row));
      if (!newPartNo || !oldPartNo || !knownComponentPartNo(oldPartNo) || !row.replacementDate || !row.stationNo || !row.gunReferenceNo || !Number.isInteger(quantity) || quantity < 1) {
        return toastMsg(`Correct row ${rowNumber}: New Part No., Old Part No., valid Date, Station, Gun No. and positive integer Quantity are required`, 'er');
      }
      const resolved = replacementMappingForRow(row);
      if (!resolved.mapping) { return toastMsg(`Correct row ${rowNumber}: ${resolved.reason}. No rows were imported.`, 'er'); }
      const mapping = resolved.mapping;
      const pencil = isPencilPart(newPartNo);
      const pencilOption = pencil ? receiveMappedBinOptions(newPartNo)[0] : null;
      const bin = pencil ? (pencilOption ? state.bins.find(item => String(item.binId || '') === String(pencilOption.binId || '')) : null) : activeBinForStation(row.stationNo);
      const binId = pencil ? (pencilOption?.binId || '') : (bin?.binId || '');
      if (!binId || !bin) { return toastMsg(`Correct row ${rowNumber}: no active bin is configured for Station ${row.stationNo}. No rows were imported.`, 'er'); }
      if (pencil && !receiveMappedBinOptions(newPartNo).some(option => String(option.binId) === String(binId))) {
        return toastMsg(`Correct row ${rowNumber}: Pencil Part must use its mapped Pencil Bin. No rows were imported.`, 'er');
      }
      if (!replacementMappingMatchesBin(mapping, bin)) {
        return toastMsg(`Correct row ${rowNumber}: mapped Component does not belong to the resolved Bin. No rows were imported.`, 'er');
      }
      const stockKey = binStockKey(newPartNo, binId);
      let stockPlan = stagedStock.get(stockKey);
      if (!stockPlan) {
        const existing = stockFor(newPartNo, binId);
        if (!existing) { return toastMsg(`INSUFFICIENT STOCK for ${newPartNo} in ${binId}. No rows were imported.`, 'er'); }
        const currentQuantity = Number(existing.quantity || 0);
        if (!Number.isFinite(currentQuantity) || currentQuantity < 0) { return toastMsg(`Invalid stock balance for ${newPartNo}. No rows were imported.`, 'er'); }
        stockPlan = { row: { ...existing }, quantity: currentQuantity };
        stagedStock.set(stockKey, stockPlan);
      }
      if (stockPlan.quantity < quantity) { return toastMsg(`INSUFFICIENT STOCK for ${newPartNo} in ${binId} at row ${rowNumber}. No rows were imported.`, 'er'); }
      stockPlan.quantity -= quantity;
    }

    const time = new Date().toTimeString().slice(0, 5);
    const transactionsByRow = [];
    const replacementsByRow = [];
    const lifecyclesByRow = [];
    const plannedQuantities = new Map();
    for (let index = 0; index < prepared.length; index += 1) {
      const row = prepared[index];
      const quantity = Number(row.quantity || 1);
      const newPartNo = replacementImportNormalize(row.newPartNo);
      const oldPartNo = replacementImportNormalize(row.oldPartNo || inferReplacementOldPart(row));
      const resolved = replacementMappingForRow(row);
      const mapping = resolved.mapping;
      const pencil = isPencilPart(newPartNo);
      const bin = pencil ? state.bins.find(item => receiveMappedBinOptions(newPartNo).some(option => String(option.binId) === String(item.binId))) : activeBinForStation(row.stationNo);
      const binId = bin?.binId || '';
      const stockKey = binStockKey(newPartNo, binId);
      const stockPlan = stagedStock.get(stockKey);
      const stockRow = stockPlan.row;
      const previous = plannedQuantities.has(stockKey) ? plannedQuantities.get(stockKey) : Number(stockFor(newPartNo, binId).quantity || 0);
      const next = previous - quantity;
      plannedQuantities.set(stockKey, next);
      const part = partByNo(newPartNo);
      stockRow.partNo = stockRow.partNo || newPartNo;
      stockRow.binId = binId;
      stockRow.quantity = stockPlan.quantity;
      stockRow.minimumStock = autoSafetyQuantity(newPartNo) || part?.minimumStock || 0;
      stockRow.status = statusFor(stockRow.quantity, stockRow.minimumStock);
      stockRow.updatedAt = nowIso();
      const entry = {
        id: uid('replacement'), maintenancePersonId: person.id, maintenancePerson: person.name, maintenanceTeam: team,
        replacementDate: row.replacementDate, replacementTime: time, replacementDateTime: `${row.replacementDate}T${time}:00`,
        shift: SHIFTS[0], stationNo: row.stationNo, gunReferenceNo: row.gunReferenceNo,
        componentType: mapping.position, partNo: newPartNo, newPartNo, oldPartNo, quantity,
        oldPartCondition: 'Used', action: 'Repair', commonBin: binId, remarks: `Imported from ${importFileName}`,
        loggedInUser: currentUser.username || currentUser.name || 'Unknown', loggedInUserId: currentUser.id || null, createdAt: nowIso()
      };
      const tx = {
        id: uid('ctx'), partNo: newPartNo, binId, quantity, direction: 'OUT', type: 'Replacement / Issue',
        beforeQuantity: previous, afterQuantity: next, date: `${row.replacementDate}T${time}:00`, stationNo: row.stationNo,
        gunReferenceNo: row.gunReferenceNo, userId: currentUser.id || null,
        username: currentUser.username || currentUser.name || 'Unknown', metadata: entry
      };
      const lifecycle = {
        id: uid('life'), sourceReplacementId: entry.id, quantity, lifecycleQuantity: quantity,
        partNo: oldPartNo, newPartNo, componentType: mapping.position, stationNo: row.stationNo,
        gunReferenceNo: row.gunReferenceNo, reason: entry.oldPartCondition, remarks: entry.remarks,
        userId: entry.loggedInUserId, username: entry.loggedInUser, maintenancePerson: entry.maintenancePerson,
        date: entry.replacementDateTime, status: 'UNDER REPAIR', createdAt: nowIso()
      };
      transactionsByRow.push(tx);
      replacementsByRow.push(entry);
      lifecyclesByRow.push(lifecycle);
      auditEvents.push(
        { action: 'COMPONENT_STOCK_TRANSACTION', entity: 'Stock', entityId: stockRow.id, details: tx },
        { action: 'COMPONENT_REPLACEMENT_IMPORT_CREATE', entity: 'Replacement', entityId: entry.id, details: entry },
        { action: 'COMPONENT_LIFECYCLE_CREATE', entity: 'Repair/Scrap', entityId: lifecycle.id, details: lifecycle }
      );
    }

    const writes = [
      ...[...stagedStock.values()].map(plan => ({ store: STORES.stock, obj: plan.row })),
      ...transactionsByRow.map(obj => ({ store: STORES.tx, obj })),
      ...replacementsByRow.map(obj => ({ store: STORES.replacements, obj })),
      ...lifecyclesByRow.map(obj => ({ store: STORES.repair, obj })),
      ...auditEvents.map(event => ({ store: STORES.audit, obj: makeAuditRow(event.action, event.entity, event.entityId, event.details) }))
    ];
    if (newPerson) { writes.push({ store: STORES.people, obj: newPerson }); }
    if (typeof window.dPutMany !== 'function') { return toastMsg('Atomic import is unavailable in this database session. No rows were imported.', 'er'); }
    const progress = document.getElementById('cr-import-progress');
    if (progress) { progress.textContent = `Saving ${prepared.length} replacement rows atomically…`; }
    try {
      await window.dPutMany(writes);
    } catch (error) {
      console.error('Atomic replacement import failed', error);
      if (progress) { progress.textContent = ''; }
      return toastMsg(`Replacement import failed; no rows were committed. ${error.message || ''}`, 'er');
    }

    for (const plan of stagedStock.values()) {
      const index = state.stock.findIndex(item => partKey(item.partNo) === partKey(plan.row.partNo) && String(item.binId || '') === String(plan.row.binId || ''));
      if (index >= 0) { state.stock[index] = plan.row; } else { state.stock.push(plan.row); }
    }
    state.tx.push(...transactionsByRow);
    state.replacements.unshift(...replacementsByRow);
    state.repairs.push(...lifecyclesByRow);
    if (newPerson) { state.people.push(newPerson); }
    if (typeof addAudit === 'function') {
      for (const event of auditEvents) {
        try { await addAudit(event.action, `${event.entity}: ${JSON.stringify(event.details)}`, 'COMPONENT_MANAGEMENT'); }
        catch (error) { console.error('Secondary audit sink failed after atomic import commit', error); }
      }
    }
    if (progress) { progress.textContent = ''; }
    toastMsg(`${prepared.length} replacement rows imported atomically`, 'suc');
    pendingReplacementImport = null;
    open('history');
  }
  async function saveReplacement() {
    if (!canComponent('replacement')) { return; }
    const person = state.people.find(p => String(p.name).toLowerCase() === val('cr-person').toLowerCase());
    const newPartNo = sel('cr-part');
    const oldPartNo = val('cr-old-part');
    const stationNo = sel('cr-station');
    const gunReferenceNo = sel('cr-gun');
    const component = sel('cr-component');
    const binId = val('cr-bin');
    const quantity = Number(val('cr-qty'));
    const replacementDate = val('cr-date');
    const replacementTime = val('cr-time');
    const shift = sel('cr-shift');
    const oldPartCondition = sel('cr-condition');
    const action = sel('cr-action');
    if (!person) { return toastMsg('Select a Maintenance Person from the searchable directory', 'er'); }
    if (!oldPartNo || !val('cr-team') || !stationNo || !gunReferenceNo || !component || !newPartNo || !Number.isInteger(quantity) || quantity < 1) {
      return toastMsg('Complete all required replacement fields', 'er');
    }
    if (!knownComponentPartNo(oldPartNo.trim())) { return toastMsg('Old Part No. must exist in the component catalogue or mapping before Repair/Scrap lifecycle tracking.', 'er'); }
    const dateParts = /^(\d{4})-(\d{2})-(\d{2})$/.exec(replacementDate);
    const timeParts = /^(\d{2}):(\d{2})$/.exec(replacementTime);
    const validDate = Boolean(dateParts && new Date(Date.UTC(Number(dateParts[1]), Number(dateParts[2]) - 1, Number(dateParts[3]))).toISOString().slice(0, 10) === replacementDate);
    const validTime = Boolean(timeParts && Number(timeParts[1]) < 24 && Number(timeParts[2]) < 60);
    if (!validDate || !validTime || !SHIFTS.includes(shift)
      || !CONDITIONS.includes(oldPartCondition) || !ACTIONS.includes(action)) {
      return toastMsg('Enter a valid replacement date/time, shift, condition, and action', 'er');
    }
    const mapping = state.mappings.find(m => partKey(m.partNo) === partKey(newPartNo)
      && sameStation(m.stationNo, stationNo)
      && normalGunReference(m.gunReferenceNo) === normalGunReference(gunReferenceNo)
      && String(m.position) === String(component));
    if (!mapping) { return toastMsg('Invalid Part No. → Station → Gun → Component mapping', 'er'); }
    const pencil = isPencilPart(newPartNo);
    let resolvedBin;
    if (pencil) {
      const allowedBins = receiveMappedBinOptions(newPartNo);
      if (!allowedBins.some(option => String(option.binId) === String(binId))) { return toastMsg('Pencil Part can use only its Pencil Bin', 'er'); }
      resolvedBin = state.bins.find(item => String(item.binId || '') === String(binId || ''));
    } else {
      resolvedBin = activeBinForStation(stationNo);
      if (!resolvedBin?.binId || String(binId) !== String(resolvedBin.binId)) { return toastMsg('Selected bin is not the active bin for this Station', 'er'); }
    }
    if (!resolvedBin || !replacementMappingMatchesBin(mapping, resolvedBin)) {
      return toastMsg('Selected bin does not match the Part → Station → Gun → Component mapping', 'er');
    }
    const stock = stockFor(newPartNo, binId);
    const stockQuantity = Number(stock?.quantity);
    if (!stock || !Number.isInteger(stockQuantity) || stockQuantity < quantity) { return toastMsg('INSUFFICIENT OR INVALID STOCK BALANCE', 'er'); }
    /* Same Part No. is valid for a like-for-like physical replacement. Old Part No. and New Part No. cannot be the same is intentionally NOT a validation rule. */
    const dt = `${replacementDate}T${replacementTime}:00`;
    const currentUser = user();
    const part = partByNo(newPartNo);
    const entry = {
      id: uid('replacement'), maintenancePersonId: person.id, maintenancePerson: person.name,
      maintenanceTeam: val('cr-team').trim(), replacementDate, replacementTime, replacementDateTime: dt,
      shift, stationNo, gunReferenceNo, componentType: mapping.position || part?.componentType || component,
      partNo: newPartNo, newPartNo, oldPartNo: oldPartNo.trim(), quantity, oldPartCondition, action,
      commonBin: binId, remarks: val('cr-remarks'), loggedInUser: currentUser.username || currentUser.name || 'Unknown',
      loggedInUserId: currentUser.id || null, createdAt: nowIso()
    };
    const nextQuantity = stockQuantity - quantity;
    const stockRow = { ...stock, quantity: nextQuantity, status: statusFor(nextQuantity, stock.minimumStock), updatedAt: nowIso() };
    const tx = { id: uid('ctx'), partNo: newPartNo, binId, quantity, direction: 'OUT', type: action === 'Scrap' ? 'Scrap' : 'Replacement / Issue', beforeQuantity: stockQuantity, afterQuantity: nextQuantity, date: dt, stationNo, gunReferenceNo, userId: currentUser.id || null, username: currentUser.username || currentUser.name || 'Unknown', metadata: entry };
    const lifecycle = action === 'Repair' || action === 'Scrap' ? {
      id: uid('life'), sourceReplacementId: entry.id, quantity, lifecycleQuantity: quantity,
      partNo: entry.oldPartNo || entry.partNo, newPartNo: entry.newPartNo || entry.partNo,
      componentType: entry.componentType, stationNo, gunReferenceNo, reason: entry.oldPartCondition,
      remarks: entry.remarks, userId: entry.loggedInUserId, username: entry.loggedInUser,
      maintenancePerson: entry.maintenancePerson, date: entry.replacementDateTime,
      status: action === 'Repair' ? 'UNDER REPAIR' : 'SCRAP', createdAt: nowIso()
    } : null;
    const currentUsername = currentUser.username || currentUser.name || 'Unknown';
    const auditRows = [
      { action: 'COMPONENT_STOCK_TRANSACTION', entity: 'Stock', entityId: stockRow.id, details: tx },
      { action: 'COMPONENT_REPLACEMENT_CREATE', entity: 'Replacement', entityId: entry.id, details: entry },
      ...(lifecycle ? [{ action: 'COMPONENT_LIFECYCLE_CREATE', entity: 'Repair/Scrap', entityId: lifecycle.id, details: lifecycle }] : [])
    ].map(event => ({ id: uid('ca'), ...event, timestamp: nowIso(), userId: currentUser.id || null, username: currentUsername }));
    if (typeof window.dPutMany !== 'function') { return toastMsg('Atomic Replacement save is unavailable; no stock or lifecycle change was made.', 'er'); }
    try {
      await window.dPutMany([
        { store: STORES.stock, obj: stockRow }, { store: STORES.tx, obj: tx },
        { store: STORES.replacements, obj: entry },
        ...(lifecycle ? [{ store: STORES.repair, obj: lifecycle }] : []),
        ...auditRows.map(obj => ({ store: STORES.audit, obj }))
      ]);
    } catch (error) {
      console.error('Atomic Replacement save failed', error);
      return toastMsg(`Replacement failed; no stock, replacement, or lifecycle change was committed. ${error.message || ''}`, 'er');
    }
    const stockIndex = state.stock.findIndex(item => item.id === stockRow.id);
    if (stockIndex >= 0) { state.stock[stockIndex] = stockRow; } else { state.stock.push(stockRow); }
    state.tx.push(tx);
    state.replacements.unshift(entry);
    if (lifecycle) { state.repairs.push(lifecycle); }
    if (typeof addAudit === 'function') {
      for (const event of auditRows) {
        try { await addAudit(event.action, `${event.entity}: ${JSON.stringify(event.details)}`, 'COMPONENT_MANAGEMENT'); }
        catch (error) { console.error('Secondary audit sink failed after atomic Replacement commit', error); }
      }
    }
    toastMsg('Replacement saved, stock deducted, and audit logged', 'suc');
    open('history');
  }
  async function ensureStockRecord(partNo, binId) { if (!partNo || !binId) { return; } const normalizedPartKey = partKey(partNo); const targetBin = state.bins.find(b => String(b.binId || '') === String(binId || '')); if (isPencilPart(partNo) && targetBin?.binKind !== 'PENCIL_PAIR') { return; } const exists = state.stock.some(s => partKey(s.partNo) === normalizedPartKey && (s.binId === binId || targetBin && sameStation(state.bins.find(b => String(b.binId || '') === String(s.binId || ''))?.stationNo, targetBin.stationNo))); if (exists) { return; } const p = partByNo(partNo); const minimumStock = autoSafetyQuantity(partNo) || p?.minimumStock || 0; const row = { id: uid('stock'), partNo, binId, quantity: 0, minimumStock, status: 'ZERO STOCK', createdAt: nowIso(), updatedAt: nowIso() }; await dPut(STORES.stock, row); state.stock.push(row); }
  async function changeStock(partNo, binId, delta, type, metadata) {
    const numericDelta = Number(delta);
    if (!Number.isFinite(numericDelta) || numericDelta === 0) throw new Error('STOCK_DELTA_MUST_BE_NON_ZERO');
    if (!Number.isInteger(numericDelta)) throw new Error('STOCK_DELTA_MUST_BE_INTEGER');
    const pencil = isPencilPart(partNo);
    if (pencil && !receiveMappedBinOptions(partNo).some(option => option.binId === binId)) throw new Error('PENCIL_PART_REQUIRES_PENCIL_BIN');
    let row = stockFor(partNo, binId);
    const requestedBin = state.bins.find(b => String(b.binId || '') === String(binId || ''));
    if (!pencil && !row && requestedBin) {
      row = state.stock.find(s => partKey(s.partNo) === partKey(partNo) && sameStation(state.bins.find(b => String(b.binId || '') === String(s.binId || ''))?.stationNo, requestedBin.stationNo));
      if (row) binId = row.binId;
    }
    const p = partByNo(partNo);
    const minimumStock = autoSafetyQuantity(partNo) || p?.minimumStock || 0;
    const targetId=row?.id || uid('stock');
    const tx = { id: uid('ctx'), partNo, binId, quantity: Math.abs(numericDelta), direction: numericDelta < 0 ? 'OUT' : 'IN', type, date: nowIso(), stationNo: metadata?.stationNo || '', gunReferenceNo: metadata?.gunReferenceNo || '', userId: user().id || null, username: user().username || user().name || 'Unknown', metadata: metadata || {} };
    if (typeof window.atomicReadModifyWrite !== 'function') throw new Error('Atomic Shank stock persistence is unavailable');
    row = await window.atomicReadModifyWrite(STORES.stock, targetId, currentRow => {
      const currentRecord = currentRow || { id: targetId, partNo, binId, quantity: 0, minimumStock, status: 'ZERO STOCK', createdAt: nowIso() };
      const current = Number(currentRecord.quantity || 0);
      if (!Number.isFinite(current) || current < 0) throw new Error('INVALID_STOCK_BALANCE');
      const next = current + numericDelta;
      if (next < 0) throw new Error('INSUFFICIENT STOCK');
      const updated = { ...currentRecord, quantity: next, status: statusFor(next, currentRecord.minimumStock), updatedAt: nowIso() };
      const ledger = { ...tx, beforeQuantity: current, afterQuantity: next };
      return { record: updated, writes: [{ store: STORES.tx, obj: ledger }] };
    });
    const stockIndex=state.stock.findIndex(item=>item.id===row.id);
    if(stockIndex>=0)state.stock[stockIndex]=row;else state.stock.push(row);
    await audit('COMPONENT_STOCK_TRANSACTION', 'Stock', row.id, tx);
    return row;
  }

  function lifecyclePartIdentityValid(row) {
    if (!row?.sourceReplacementId) { return true; }
    const source = state.replacements.find(replacement => replacement.id === row.sourceReplacementId);
    if (!source || source.action !== 'Repair') { return false; }
    const expectedOldPart = source.oldPartNo || source.partNo;
    const expectedNewPart = source.newPartNo || source.partNo;
    return partKey(row.partNo) === partKey(expectedOldPart)
      && (!row.newPartNo || partKey(row.newPartNo) === partKey(expectedNewPart));
  }
  async function completeRepair(id) {
    if (!canComponent('lifecycle')) { return; }
    const row = state.repairs.find(item => item.id === id);
    if (!row || row.status !== 'UNDER REPAIR') { return toastMsg('Only an Under Repair lifecycle item can be completed', 'er'); }
    if (!lifecyclePartIdentityValid(row)) { return toastMsg('Repair lifecycle Part No. does not match its source Replacement (Old Part / New Part). No change was saved.', 'er'); }
    const quantity = Number(row.quantity || row.lifecycleQuantity || 0);
    if (!Number.isInteger(quantity) || quantity < 1) { return toastMsg('Repair quantity is missing; return cannot be posted', 'er'); }
    const updatedLifecycle = { ...row, status: 'REPAIR COMPLETED', completedAt: nowIso() };
    const currentUser = user();
    const auditDetails = { ...updatedLifecycle, quantity };
    const auditRow = { id: uid('ca'), action: 'COMPONENT_REPAIR_COMPLETE', entity: 'Repair/Scrap', entityId: id, details: auditDetails, timestamp: nowIso(), userId: currentUser.id || null, username: currentUser.username || currentUser.name || 'Unknown' };
    if (typeof window.dPutMany !== 'function') { return toastMsg('Atomic Repair completion is unavailable; lifecycle status was not changed.', 'er'); }
    try {
      await window.dPutMany([{ store: STORES.repair, obj: updatedLifecycle }, { store: STORES.audit, obj: auditRow }]);
    } catch (error) {
      console.error('Atomic Repair completion failed', error);
      return toastMsg(`Repair completion failed; lifecycle status was not changed. ${error.message || ''}`, 'er');
    }
    const lifecycleIndex = state.repairs.findIndex(item => item.id === id);
    if (lifecycleIndex >= 0) { state.repairs[lifecycleIndex] = updatedLifecycle; }
    if (typeof addAudit === 'function') {
      try { await addAudit('COMPONENT_REPAIR_COMPLETE', `Repair/Scrap: ${JSON.stringify(auditDetails)}`, 'COMPONENT_MANAGEMENT'); }
      catch (error) { console.error('Secondary audit sink failed after atomic Repair completion', error); }
    }
    toastMsg('Repair marked completed. Confirm Repair Return to add it back to stock.', 'suc');
    await load(); repair();
  }
  const repairReturnInProgress = new Set();
  async function repairReturn(id) {
    if (!canComponent('lifecycle')) { return; }
    if (repairReturnInProgress.has(String(id))) { return toastMsg('Repair Return is already being processed', 'inf'); }
    repairReturnInProgress.add(String(id));
    try {
    const row = state.repairs.find(item => item.id === id);
    if (!row || row.status !== 'REPAIR COMPLETED') { return toastMsg('Only completed repairs can be returned', 'er'); }
    if (!lifecyclePartIdentityValid(row)) { return toastMsg('Repair Return Part No. does not match the source Replacement Old Part. No stock was changed.', 'er'); }
    const quantity = Number(row.lifecycleQuantity || row.quantity || 0);
    if (!Number.isInteger(quantity) || quantity < 1) { return toastMsg('Repair quantity is missing; return cannot be posted', 'er'); }
    const pencilOption = isPencilPart(row.partNo) ? receiveMappedBinOptions(row.partNo)[0] : null;
    const bin = pencilOption ? state.bins.find(item => String(item.binId || '') === String(pencilOption.binId || '')) : activeBinForStation(row.stationNo);
    if (!bin?.binId) { return toastMsg('Required Pencil Bin or active Common Station Bin was not found', 'er'); }
    const part = partByNo(row.partNo);
    const minimumStock = autoSafetyQuantity(row.partNo) || part?.minimumStock || 0;
    const existingStock = stockFor(row.partNo, bin.binId);
    const stockRow = existingStock
      ? { ...existingStock }
      : { id: uid('stock'), partNo: row.partNo, binId: bin.binId, quantity: 0, minimumStock, status: 'ZERO STOCK', createdAt: nowIso() };
    const before = Number(stockRow.quantity || 0);
    if (!Number.isFinite(before) || before < 0) { return toastMsg('Invalid current stock balance; repair return was not posted', 'er'); }
    const updatedLifecycle = { ...row, status: 'RETURNED TO STOCK', returnedAt: nowIso(), returnedQuantity: quantity };
    const tx = {
      id: uid('ctx'), partNo: row.partNo, binId: bin.binId, quantity, direction: 'IN', type: 'Repair Return',
      beforeQuantity: before, afterQuantity: before + quantity, date: nowIso(), stationNo: row.stationNo,
      gunReferenceNo: row.gunReferenceNo, userId: user().id || null,
      username: user().username || user().name || 'Unknown', metadata: { ...updatedLifecycle, quantity, lifecycleQuantity: quantity }
    };
    const auditRow = {
      id: uid('ca'), action: 'COMPONENT_REPAIR_RETURN', entity: 'Repair/Scrap', entityId: id,
      details: { ...updatedLifecycle, quantity, binId: bin.binId }, timestamp: nowIso(),
      userId: user().id || null, username: user().username || user().name || 'Unknown'
    };
    if (typeof window.atomicReadModifyWrite !== 'function') { return toastMsg('Atomic Repair Return is unavailable; no stock was changed', 'er'); }
    try {
      const stockGuard = existingStock ? [{ store: STORES.stock, key: existingStock.id, name: 'stock' }] : [];
      const committed = await window.atomicReadModifyWrite(STORES.repair, id, (current, guards) => {
        if (!current || current.status !== 'REPAIR COMPLETED') { throw new Error('Repair is no longer in REPAIR COMPLETED state'); }
        const freshStock = guards.stock || stockRow;
        const freshBefore = Number(freshStock.quantity || 0);
        if (!Number.isFinite(freshBefore) || freshBefore < 0) { throw new Error('Invalid current stock balance; repair return was not posted'); }
        const freshStockRow = { ...freshStock, quantity: freshBefore + quantity, minimumStock, status: statusFor(freshBefore + quantity, minimumStock), updatedAt: nowIso() };
        const lifecycle = { ...current, status: 'RETURNED TO STOCK', returnedAt: updatedLifecycle.returnedAt, returnedQuantity: quantity };
        const freshTx = { ...tx, beforeQuantity: freshBefore, afterQuantity: freshBefore + quantity, metadata: { ...lifecycle, quantity, lifecycleQuantity: quantity } };
        const freshAudit = { ...auditRow, details: { ...lifecycle, quantity, binId: bin.binId } };
        return { record: lifecycle, writes: [{ store: STORES.stock, obj: freshStockRow }, { store: STORES.tx, obj: freshTx }, { store: STORES.audit, obj: freshAudit }] };
      }, { guards: stockGuard });
      Object.assign(updatedLifecycle, committed);
      stockRow.quantity = before + quantity;
      stockRow.status = statusFor(stockRow.quantity, minimumStock);
      stockRow.updatedAt = nowIso();
    } catch (error) {
      console.error('Atomic Repair Return failed', error);
      return toastMsg(`Repair Return failed; no stock or lifecycle change was committed. ${error.message || ''}`, 'er');
    }
    const stockIndex = state.stock.findIndex(item => partKey(item.partNo) === partKey(row.partNo) && String(item.binId || '') === String(bin.binId));
    if (stockIndex >= 0) { state.stock[stockIndex] = stockRow; } else { state.stock.push(stockRow); }
    const lifecycleIndex = state.repairs.findIndex(item => item.id === id);
    if (lifecycleIndex >= 0) { state.repairs[lifecycleIndex] = updatedLifecycle; }
    state.tx.push(tx);
    if (typeof addAudit === 'function') {
      try { await addAudit('COMPONENT_REPAIR_RETURN', `Repair/Scrap: ${JSON.stringify({ ...updatedLifecycle, quantity, binId: bin.binId })}`, 'COMPONENT_MANAGEMENT'); }
      catch (error) { console.error('Secondary audit sink failed after atomic Repair Return', error); }
    }
    toastMsg('Repair Return confirmed and stock updated', 'suc');
    await load(); repair();
    } finally { repairReturnInProgress.delete(String(id)); }
  }
  function repair() { const rows = state.repairs.map(r => `<tr class="cm-lifecycle-row" data-part="${esc(r.partNo)}" data-station="${esc(r.stationNo)}" data-gun="${esc(r.gunReferenceNo)}" data-status="${esc(r.status)}" data-action="${esc(String(r.status || '').includes('SCRAP') ? 'Scrap' : 'Repair')}"><td>${esc(partDisplayWithComment(r.partNo))}</td><td>${esc(r.stationNo)}</td><td>${esc(r.gunReferenceNo)}</td><td>${esc(r.status)}</td><td>${esc(r.reason)}</td><td>${esc(r.username)}</td><td>${r.status === 'UNDER REPAIR' ? btn('Mark Repair Completed', `componentCompleteRepair('${esc(r.id)}')`) : r.status === 'REPAIR COMPLETED' ? btn('Confirm Repair Return', `componentRepairReturn('${esc(r.id)}')`) : ''}</td></tr>`).join(''); const filters = `<div class="g4 cm-filter-bar"><div class="fr"><label class="fl">Search Part No.</label><input class="fi" id="cm-life-part-search" placeholder="Part No." oninput="componentFilterLifecycleRows()"></div><div class="fr"><label class="fl">Search Station</label><input class="fi" id="cm-life-station-search" placeholder="Station No." oninput="componentFilterLifecycleRows()"></div><div class="fr"><label class="fl">Search Gun Reference</label><input class="fi" id="cm-life-gun-search" placeholder="Gun Reference" oninput="componentFilterLifecycleRows()"></div><div class="fr"><label class="fl">Search Status</label><input class="fi" id="cm-life-status-search" placeholder="Under Repair / Scrap" oninput="componentFilterLifecycleRows()"></div><div class="fr"><label class="fl">Search Action</label><input class="fi" id="cm-life-action-search" placeholder="Repair / Scrap" oninput="componentFilterLifecycleRows()"></div></div><div class="btn-row">${btn('Clear Filters', 'componentClearLifecycleFilters()')}<span id="cm-life-filter-summary" class="muted">Showing ${state.repairs.length} of ${state.repairs.length}</span></div>`; shell('Repair / Scrap Lifecycle', `<div class="alrt alrt-b">Repair flow: Removed → Under Repair → Repair Completed → Returned to Stock. Scrap flow: Removed → Scrap. Every transition remains in history.</div>${filters}${table(['Part No.', 'Station', 'Gun', 'Status', 'Condition/Reason', 'User', 'Action'], rows)}`); }
  function history() { const rows = [...state.replacements, ...(state.historicalConsumption || []).map(r => ({ ...r, historical: true, replacementTime: '', maintenancePerson: r.importedBy || 'Historical Import', maintenanceTeam: 'Historical Consumption', action: 'Historical Consumption', oldPartNo: '', newPartNo: r.newPartNo || r.partNo, commonBin: '', oldPartCondition: 'Historical', remarks: `Imported from ${r.sourceFile || 'historical file'}` }))].sort((a, b) => String(b.replacementDate || b.date || '').localeCompare(String(a.replacementDate || a.date || ''))); const rowsHtml = rows.map(r => `<tr data-history-type="${r.historical ? 'HISTORICAL' : 'LIVE'}" data-history-part="${esc(r.newPartNo || r.partNo || '')}" data-history-station="${esc(r.stationNo || '')}" data-history-gun="${esc(r.gunReferenceNo || '')}"><td>${esc(r.replacementDate || r.date)}</td><td>${esc(r.replacementTime || '')}</td><td>${esc(r.maintenancePerson)}</td><td>${esc(r.maintenanceTeam)}</td><td>${esc(r.shift || '')}</td><td>${esc(r.stationNo || '')}</td><td>${esc(r.gunReferenceNo || '')}</td><td>${esc(r.componentType || '')}</td><td>${esc(r.oldPartNo ? partDisplayWithComment(r.oldPartNo) : '')}</td><td>${esc(r.newPartNo || r.partNo ? partDisplayWithComment(r.newPartNo || r.partNo) : '')}</td><td>${r.quantity || 0}</td><td>${esc(r.oldPartCondition || '')}</td><td>${esc(r.action || '')}</td><td>${esc(r.commonBin || '')}</td><td>${esc(r.loggedInUser || r.importedBy || '')}</td><td>${esc(r.remarks || '')}</td><td>${r.historical ? `${esc(r.importBatchId || 'Historical')} ${btn('Delete Batch', `componentDeleteHistoricalImportBatch('${esc(r.importBatchId || '')}')`)}` : btn('Drill-down', `componentReplacementDrillDown('${esc(r.id)}')`)}</td></tr>`).join(''); shell('Transactions / Replacement History', `<div class="alrt alrt-b">Live Replacement transactions and Historical Consumption imports are shown together. Historical rows are analytics-only and never changed current stock.</div><div class="btn-row">${btn('Export Excel', 'componentExportHistoryExcel()')}${btn('Export PDF', 'componentExportHistoryPdf()', true)}</div><div class="g4"><div class="fr"><label class="fl">Search History</label><input class="fi" id="ch-filter" placeholder="Search Station, Gun, Part, Person, Team, Shift, User, Bin" data-oninput="componentFilterHistory(this.value)"></div><div class="fr"><label class="fl">History Type</label><select class="fi" id="ch-type-filter" data-onchange="componentFilterHistory(val('ch-filter'))"><option value="ALL">All</option><option value="LIVE">Live Replacement</option><option value="HISTORICAL">Historical Consumption</option></select></div><div class="fr"><label class="fl">Part No. Filter</label><input class="fi" id="ch-part-filter" list="ch-part-filter-options" placeholder="Type or select Part No." oninput="componentHistoryPartChanged()" data-onchange="componentHistoryPartChanged()"><datalist id="ch-part-filter-options">${[...new Set(rows.map(r => r.newPartNo || r.partNo).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' })).map(part => `<option value="${esc(part)}"></option>`).join('')}</datalist></div><div class="fr"><label class="fl">Station Filter</label><input class="fi" id="ch-station-filter" list="ch-station-filter-options" placeholder="Type or select Station" oninput="componentHistoryStationChanged()" data-onchange="componentHistoryStationChanged()"><datalist id="ch-station-filter-options"></datalist></div><div class="fr"><label class="fl">Gun Filter</label><input class="fi" id="ch-gun-filter" list="ch-gun-filter-options" placeholder="Type or select Gun" oninput="componentFilterHistory(val('ch-filter'))" data-onchange="componentFilterHistory(val('ch-filter'))"><datalist id="ch-gun-filter-options"></datalist></div><div class="fr"><label class="fl">From Date</label><input class="fi" id="ch-from-date" type="date" data-onchange="componentFilterHistory(val('ch-filter'))"></div><div class="fr"><label class="fl">To Date</label><input class="fi" id="ch-to-date" type="date" data-onchange="componentFilterHistory(val('ch-filter'))"></div></div>${table(['Date', 'Time', 'Maintenance Person', 'Team', 'Shift', 'Station', 'Gun', 'Component', 'Old Part No.', 'New Part No.', 'Qty', 'Condition', 'Action', 'Bin', 'User', 'Remarks', 'Drill-down'], rowsHtml, 'No replacement or historical consumption transactions yet.')}`); componentPager('[data-history-type]', 'history'); }
  function historyMappingsForPart(partNo) { const key = partKey(partNo); return state.mappings.filter(m => key && partKey(m.partNo) === key); }
  function componentHistoryPartChanged() { const part = val('ch-part-filter'); const mappings = historyMappingsForPart(part); const stations = [...new Map(mappings.map(m => [normalStation(m.stationNo), canonicalStation(m.stationNo)])).values()]; setIdentifierSuggestions('ch-station-filter', stations.length ? 'Type or select Station' : 'No mapped Station — type to search', stations); setIdentifierSuggestions('ch-gun-filter', 'Select Station first', []); filterHistory(val('ch-filter')); }
  function componentHistoryStationChanged() { const part = val('ch-part-filter'); const station = val('ch-station-filter'); const guns = [...new Set(historyMappingsForPart(part).filter(m => sameStation(m.stationNo, station)).map(m => m.gunReferenceNo).filter(Boolean))].sort(); setIdentifierSuggestions('ch-gun-filter', guns.length ? 'Type or select Gun' : 'No mapped Gun — type to search', guns); filterHistory(val('ch-filter')); }
  function filterHistory(query) { const q = String(query || '').toLowerCase(); const type = String(document.getElementById('ch-type-filter')?.value || 'ALL'); const part = String(document.getElementById('ch-part-filter')?.value || '').toLowerCase(); const station = String(document.getElementById('ch-station-filter')?.value || '').toLowerCase(); const gun = String(document.getElementById('ch-gun-filter')?.value || '').toLowerCase(); const from = String(document.getElementById('ch-from-date')?.value || ''); const to = String(document.getElementById('ch-to-date')?.value || ''); document.querySelectorAll('#component-management-content tbody tr').forEach(row => { const date = String(row.cells?.[0]?.textContent || '').slice(0, 10); const typeMatch = type === 'ALL' || row.dataset.historyType === type; const partMatch = !part || String(row.dataset.historyPart || '').toLowerCase() === part; const stationMatch = !station || sameStation(row.dataset.historyStation || '', station) || String(row.dataset.historyStation || '').toLowerCase().includes(station); const gunMatch = !gun || String(row.dataset.historyGun || '').toLowerCase().includes(gun); const dateMatch = (!from || date >= from) && (!to || date <= to); row.style.display = typeMatch && partMatch && stationMatch && gunMatch && dateMatch && (!q || row.textContent.toLowerCase().includes(q)) ? '' : 'none'; }); componentRefreshPager('history', true); }

  function zeroDrillDown(partNo, binId) {
    const p = partByNo(partNo); const mappings = state.mappings.filter(m => m.partNo === partNo);
    const tx = state.tx.filter(t => t.partNo === partNo && (!binId || t.binId === binId)).sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let balance = 0; const rows = tx.map(t => { balance += t.direction === 'OUT' ? -Number(t.quantity || 0) : Number(t.quantity || 0); return `<tr><td>${esc(String(t.date || '').slice(0, 10))}</td><td>${esc(t.type)}</td><td>${t.direction === 'OUT' ? '-' : '+'}${t.quantity}</td><td>${esc(t.metadata?.reference || t.metadata?.remarks || '')}</td><td>${esc(t.username)}</td><td>${esc(t.stationNo || '')}</td><td>${esc(t.gunReferenceNo || '')}</td><td>${balance}</td></tr>`; }).join('');
    shell('Zero Stock Transaction Drill-down', `<div class="alrt alrt-b"><strong>Part No.:</strong> ${esc(partDisplayWithComment(partNo))} &nbsp; <strong>Component Type:</strong> ${esc(p?.componentType || '')} &nbsp; <strong>Bin:</strong> ${esc(binId || '')} &nbsp; <strong>Station Usage:</strong> ${esc([...new Set(mappings.map(m => m.stationNo).filter(Boolean))].join(', '))}</div>${table(['Date','Transaction Type','Quantity','Reference','User','Station','Gun Reference','Running Balance'], rows, 'No stored transactions found.', '', ['Station','Gun Reference'])}`);
  }
  function searchStation(query) {
    const q = normalStation(query); const stations = [...new Map(state.mappings.filter(m => m.stationNo).map(m => [normalStation(m.stationNo), canonicalStation(m.stationNo)])).values()].filter(x => normalStation(x).includes(q));
    const rows = stations.map(station => { const bin = binByStation(station); const maps = state.mappings.filter(m => sameStation(m.stationNo, station)); return `<tr><td>${esc(station)}</td><td>${esc(bin?.binId || '')}</td><td>${esc([...new Set(maps.map(m => m.gunReferenceNo))].join(', '))}</td><td>${esc(maps.filter(m => m.position === 'Fix Shank').map(m => partDisplayWithComment(m.partNo, m)).join(', '))}</td><td>${esc(maps.filter(m => m.position === 'Moving Shank').map(m => partDisplayWithComment(m.partNo, m)).join(', '))}</td><td>${esc(maps.map(m => `${m.position}: ${partDisplayWithComment(m.partNo, m)}`).join(' | ' ))}</td><td>${maps.map(m => `${partDisplayWithComment(m.partNo, m)}: ${stockFor(m.partNo, bin?.binId)?.quantity || 0}`).join(', ')}</td></tr>`; }).join('');
    shell('Station Search', `<div class="fr"><label class="fl">Station No.</label><input class="fi" id="cm-station-search" value="${esc(query || '')}" placeholder="FFA 10"><div class="btn-row">${btn('Search Station', "componentSearchStation(val('cm-station-search'))", true)}</div></div>${table(['Station','Common Station Bin','Gun References','Fix Shanks','Moving Shanks','All Mappings','Stock Availability'], rows, 'No matching Station.', '', ['Gun References','Fix Shanks','Moving Shanks','All Mappings','Stock Availability'])}`);
  }
  function searchPart(query) {
    const q = String(query || '').trim().toLowerCase(); const parts = state.parts.filter(p => String(p.partNo).toLowerCase().includes(q));
    const rows = parts.map(p => { const maps = state.mappings.filter(m => m.partNo === p.partNo); const bins = [...new Set(state.stock.filter(s => s.partNo === p.partNo).map(s => s.binId))]; return `<tr><td><strong>${esc(p.partNo)}</strong><br><small class="muted">${esc(partUsageComment(p.partNo))}</small></td><td>${esc(p.componentType)}</td><td>${state.stock.filter(s => s.partNo === p.partNo).reduce((a,s) => a + Number(s.quantity || 0), 0)}</td><td>${esc(bins.join(', '))}</td><td>${esc([...new Set(maps.map(m => m.stationNo).filter(Boolean))].join(', '))}</td><td>${esc([...new Set(maps.map(m => m.gunReferenceNo).filter(Boolean))].join(', '))}</td><td>${esc(maps.length ? 'Mapped' : 'Unmapped')}</td><td>${btn('Transactions', `componentZeroDrillDown('${esc(p.partNo)}','')`)}</td></tr>`; }).join('');
    shell('Part Number Search', `<div class="fr"><label class="fl">Part No.</label><input class="fi" id="cm-part-search" value="${esc(query || '')}" placeholder="FS-101"><div class="btn-row">${btn('Search Part No.', "componentSearchPart(val('cm-part-search'))", true)}</div></div>${table(['Part No.','Component Type','Available Qty','Bin','Stations','Gun References','Mapping Status','Transaction History'], rows, 'No matching Part No.', '', ['Component Type','Bin','Stations','Gun References','Mapping Status'])}`);
  }
  function reports() {
    if (!canComponent('view') || !canComponent('reports')) {return;}
    const month = /^\d{4}-\d{2}$/.test(String(state.reportMonth || '')) ? state.reportMonth : today().slice(0, 7);
    const reportReplacements = state.replacements.filter(r => String(r.replacementDate || r.replacementDateTime || '').slice(0, 7) === month);
    const by = key => { const o = {}; reportReplacements.forEach(r => { const k = r[key] || '—'; o[k] = (o[k] || 0) + Number(r.quantity || 0); }); return Object.entries(o).sort((a, b) => b[1] - a[1]).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${v}</td></tr>`).join('') || '<tr><td colspan="2">No data</td></tr>'; };
    const monthRows = monthEndRows(month); const monthHtml = table(['Part No.', 'Opening', 'Receive', 'Repair Return', 'Replacement', 'Scrap', 'Adjustment', 'Closing'], monthRows.map(r => `<tr><td>${esc(partDisplayWithComment(r.partNo))}</td><td>${r.opening}</td><td>${r.receive}</td><td>${r.repairReturn}</td><td>${r.replacement}</td><td>${r.scrap}</td><td>${r.adjustment}</td><td>${r.closing}</td></tr>`).join(''), 'No month-end movements.', '', ['Part No.']);
    const monthStart = `${month}-01`; const monthEndDate = calendarMonthEndDate(month); const consumption = typeof window.ShankConsumptionAnalytics?.calculateConsumption === 'function' ? window.ShankConsumptionAnalytics.calculateConsumption(consumptionRows(), {start: monthStart, end: monthEndDate, periodDays: Math.max(1, Number(monthEndDate.slice(-2)))}) : []; const consumptionByPart = new Map(consumption.map(row => [row.partNo, row])); const monthAnalyticsBody = state.parts.map(part => {const row = consumptionByPart.get(part.partNo) || {totalConsumption: 0, averageDailyUsage: 0, averageMonthlyUsage: 0, insufficientData: true}; return `<tr><td>${esc(part.partNo)}</td><td>${row.totalConsumption || 0}</td><td>${Number(row.averageDailyUsage || 0).toFixed(2)}</td><td>${Number(row.averageMonthlyUsage || 0).toFixed(2)}</td><td>${row.insufficientData ? 'INSUFFICIENT DATA' : 'AVAILABLE'}</td></tr>`;}).join(''); const monthAnalyticsHtml = table(['Part No.', 'Consumption', 'Avg Daily Usage', 'Avg Monthly Usage', 'Data Quality'], monthAnalyticsBody, 'No consumption data for selected month.', '', ['Part No.']);
    const zeroRows = state.stock.filter(s => Number(s.quantity || 0) === 0).map(s => `<tr><td><button class="btn btn-link" type="button" data-onclick="componentZeroDrillDown('${esc(s.partNo)}','${esc(s.binId)}')">${esc(partDisplayWithComment(s.partNo))}</button></td><td>${esc(s.binId)}</td><td>${esc(s.status)}</td></tr>`).join('');
    const gunMetrics = gunCountMetrics();
    const gunReconStatus = gunMetrics.reconciliation?.balanced ? 'RECONCILED' : 'REQUIRES ATTENTION';
    const gunReconHtml = `<div class="alrt ${gunMetrics.reconciliation?.balanced ? 'alrt-s' : 'alrt-y'}"><strong>${gunReconStatus}</strong> — Source ${gunMetrics.source} | Mapped ${gunMetrics.mapped} | Allocated ${gunMetrics.allocated} | Unassigned ${gunMetrics.unassigned}</div>`;
    shell('Component Reports', `<div class="g2"><div class="fr"><label class="fl">Month</label><input class="fi" id="cm-report-month" type="month" value="${esc(month)}"><div class="btn-row">${btn('Load Selected Month', "componentSelectReportMonth(val('cm-report-month'))", true)}${btn('Station Search', "componentSearchStation('')")}${btn('Part Number Search', "componentSearchPart('')")}</div></div></div><div class="g3"><div class="card"><div class="card-hd">Station-wise</div>${table(['Station', 'Qty'], by('stationNo'), '', '', ['Station'])}</div><div class="card"><div class="card-hd">Part-wise</div>${table(['Part No.', 'Qty'], by('partNo'), '', '', ['Part No.'])}</div><div class="card"><div class="card-hd">Maintenance Person</div>${table(['Person', 'Qty'], by('maintenancePerson'))}</div></div><h3>Month-end Accounting — ${esc(month)}</h3><p class="muted">Selected month: ${esc(month)}. Opening + Receive + Repair Return − Replacement − Scrap ± Adjustment = Closing</p>${monthHtml}<h3>Consumption Analytics — ${esc(month)}</h3><p class="muted">Selected month only. Consumption is based on Replacement / Issue transactions.</p>${monthAnalyticsHtml}<h3>Gun Count Reconciliation</h3>${gunReconHtml}<h3>Zero Stock Report</h3>${table(['Part No.', 'Bin', 'Status'], zeroRows, 'No zero-stock parts.', '', ['Part No.','Bin'])}<div class="btn-row">${btn('Export Month-end CSV', 'componentExportReport()', true)}${btn('Export Gun Count Reconciliation', 'componentExportGunCountReconciliation()')}${btn('Export Stock Accountability', 'componentExportAccountability()')}${btn('Save Opening Snapshot', "componentSaveMonthOpeningSnapshot(val('cm-report-month'))")}${btn('Lock Selected Month', "componentCloseMonth(val('cm-report-month'))")}${btn('Reopen Selected Month', "componentReopenMonth(val('cm-report-month'))")}</div>`);
  }
  function exportReport() { const month = /^\d{4}-\d{2}$/.test(String(state.reportMonth || '')) ? state.reportMonth : today().slice(0, 7); const gunMetrics = gunCountMetrics(); const h = ['Maintenance Person', 'Maintenance Team / Department', 'Replacement Date', 'Replacement Time', 'Shift', 'Station No.', 'Gun Reference No.', 'Component Type', 'Part No.', 'Quantity', 'Old Part Condition', 'Action', 'Common Bin', 'Remarks', 'Logged-in User']; const rows = state.replacements.filter(r => String(r.replacementDate || r.replacementDateTime || '').slice(0, 7) === month).map(r => h.map((_, i) => [r.maintenancePerson, r.maintenanceTeam, r.replacementDate, r.replacementTime, r.shift, r.stationNo, r.gunReferenceNo, r.componentType, r.partNo, r.quantity, r.oldPartCondition, r.action, r.commonBin, r.remarks, r.loggedInUser][i])); download(`component-replacement-${month}.csv`, csv([['Report Month', month], ['Source Gun Count', gunMetrics.source], ['Mapped Gun Count', gunMetrics.mapped], ['Allocated Gun Count', gunMetrics.allocated], ['Unassigned / Source-only', gunMetrics.unassigned], [], h, ...rows]), 'text/csv'); }
  async function saveMonthOpeningSnapshot(month) {
    if (!canComponent('reports')) {return;}
    const selected = /^\d{4}-\d{2}$/.test(String(month || '')) ? String(month) : today().slice(0, 7);
    const monthStart = `${selected}-01`;
    const balances = {};
    state.parts.forEach(p => { balances[p.partNo] = state.tx.filter(t => t.partNo === p.partNo && String(t.date || '').slice(0, 10) < monthStart).reduce((a, t) => a + (t.direction === 'OUT' ? -1 : 1) * Number(t.quantity || 0), 0); });
    const snap = { id: `opening-${selected}`, month: selected, balances, createdAt: nowIso(), userId: user().id || null };
    await dPut(STORES.monthCloses, snap);
    state.monthCloses = [...state.monthCloses.filter(x => x.id !== snap.id), snap];
    await audit('COMPONENT_MONTH_OPENING_SNAPSHOT', 'Month End', snap.id, { month: selected });
    toastMsg(`Opening snapshot saved for ${selected}`, 'suc');
    reports();
  }
  async function closeMonth(month) {
    if (!canComponent('reports', true)) {return;}
    const selected = /^\d{4}-\d{2}$/.test(String(month || '')) ? String(month) : today().slice(0, 7);
    const existing = state.monthCloses.find(row => row.month === selected && row.closedAt && String(row.status || 'CLOSED').toUpperCase() === 'CLOSED');
    if (existing) {return toastMsg(`Month ${selected} is already locked`, 'er');}
    let snapshot = state.monthCloses.find(row => row.month === selected && row.balances); if (!snapshot) { await saveMonthOpeningSnapshot(selected); snapshot = state.monthCloses.find(row => row.month === selected && row.balances); }
    const close = { ...(snapshot || { id: `opening-${selected}`, month: selected }), id: `close-${selected}`, month: selected, closedAt: nowIso(), userId: user().id || null, status: 'CLOSED' };
    await dPut(STORES.monthCloses, close);
    state.monthCloses = [...state.monthCloses.filter(row => row.id !== close.id), close];
    await audit('COMPONENT_MONTH_END_LOCK', 'Month End', close.id, { month: selected });
    toastMsg(`Month ${selected} locked`, 'suc');
    reports();
  }
  async function reopenMonth(month) {
    if (!canComponent('reports', true)) {return;}
    const selected = /^\d{4}-\d{2}$/.test(String(month || '')) ? String(month) : today().slice(0, 7);
    const close = state.monthCloses.find(row => row.month === selected && row.closedAt);
    if (!close) {return toastMsg(`Month ${selected} is not locked`, 'er');}
    if (typeof confirm === 'function' && !confirm(`Reopen Month-End ${selected}?`)) {return;}
    const reopened = { ...close, status: 'REOPENED', reopenedAt: nowIso(), reopenedBy: user().id || null };
    await dPut(STORES.monthCloses, reopened);
    state.monthCloses = [...state.monthCloses.filter(row => row.id !== reopened.id), reopened];
    await audit('COMPONENT_MONTH_END_REOPEN', 'Month End', reopened.id, { month: selected });
    toastMsg(`Month ${selected} reopened`, 'suc');
    reports();
  }
  function monthEndRows(month) {
    const selected = /^\d{4}-\d{2}$/.test(String(month || '')) ? String(month) : today().slice(0, 7);
    const monthStart = `${selected}-01`;
    const monthEnd = calendarMonthEndDate(selected);
    const signed = t => (t.direction === 'OUT' ? -1 : 1) * Number(t.quantity || 0);
    return state.parts.map(p => {
      const all = state.tx.filter(t => t.partNo === p.partNo && String(t.date || '').slice(0, 10));
      const before = all.filter(t => String(t.date).slice(0, 10) < monthStart);
      const through = all.filter(t => String(t.date).slice(0, 10) <= monthEnd);
      const movement = type => through.filter(t => t.type === type).reduce((a, t) => a + Number(t.quantity || 0), 0);
      const adjustment = through.filter(t => t.type === 'Adjustment').reduce((a, t) => a + signed(t), 0);
      const snapshot = state.monthCloses.find(s => s.month === selected && s.balances);
      const opening = snapshot && Object.prototype.hasOwnProperty.call(snapshot.balances, p.partNo) ? Number(snapshot.balances[p.partNo] || 0) : before.reduce((a, t) => a + signed(t), 0);
      const receive = movement('Receive');
      const repairReturn = movement('Repair Return');
      const replacement = movement('Replacement / Issue');
      const scrap = movement('Scrap');
      const closing = opening + receive + repairReturn - replacement - scrap + adjustment;
      return { partNo: p.partNo, opening, receive, repairReturn, replacement, scrap, adjustment, closing, month: selected, monthEnd };
    });
  }
  function exportAccountability() {
    const month = /^\d{4}-\d{2}$/.test(String(state.reportMonth || '')) ? state.reportMonth : today().slice(0, 7);
    const h = ['Part No.', 'Opening', 'Receive', 'Repair Return', 'Replacement', 'Scrap', 'Adjustment', 'Closing', 'Month Consumption', 'Average Daily Usage', 'Risk Status', 'Forecast Confidence'];
    const monthEndDate = calendarMonthEndDate(month);
    const usage = typeof window.ShankConsumptionAnalytics?.calculateConsumption === 'function' ? window.ShankConsumptionAnalytics.calculateConsumption(consumptionRows(), {start: `${month}-01`, end: monthEndDate, periodDays: Math.max(1, Number(monthEndDate.slice(-2)))}) : [];
    const usageByPart = new Map(usage.map(row => [row.partNo, row]));
    const forecasts = typeof window.ShankConsumptionAnalytics?.calculateForecast === 'function' ? new Map(window.ShankConsumptionAnalytics.calculateForecast({today: monthEndDate, parts: state.parts, stock: state.stock, replacements: consumptionRows(), periodDays: 90}).map(row => [row.partNo, row])) : new Map();
    const rows = monthEndRows(month).map(r => { const u = usageByPart.get(r.partNo) || {}; const f = forecasts.get(r.partNo) || {}; return [r.partNo, r.opening, r.receive, r.repairReturn, r.replacement, r.scrap, r.adjustment, r.closing, u.totalConsumption || 0, Number(u.averageDailyUsage || 0).toFixed(2), f.status || 'NORMAL', f.usageConfidence || 'LOW']; });
    download(`component-stock-accountability-${month}.csv`, csv([['Report Month', month], ['Analytics Period', `${month}-01 to ${monthEndDate}`], [], h, ...rows]), 'text/csv');
  }

  function labelDimensions() {
    const size = sel('cl-size');
    if (size === '100x40' || size === 'Small') {return { width: 100, height: 40 };}
    if (size === 'Large') {return { width: 100, height: 60 };}
    if (size === 'Custom') {return { width: Math.max(10, Number(val('cl-width') || 100)), height: Math.max(10, Number(val('cl-height') || 40)) };}
    return { width: 100, height: 40 };
  }
  function labelPosition(value) {
    const key = fieldKey(value);
    if (key === 'fixshank' || key === 'fixedshank' || key === 'fixshankpartno' || key === 'fixpartno') {return 'Fix Shank';}
    if (key === 'fixadaptor' || key === 'fixedadaptor' || key === 'fixadapter' || key === 'fixedadapter') {return 'Fix Adaptor';}
    if (key === 'fixholder' || key === 'fixedholder' || key === 'fixholderpartno') {return 'Fix Holder';}
    if (key === 'movingshank' || key === 'movshank' || key === 'movingshankpartno' || key === 'movingpartno') {return 'Moving Shank';}
    if (key === 'movingadaptor' || key === 'movingadapter' || key === 'movadaptor' || key === 'movadapter') {return 'Moving Adaptor';}
    if (key === 'movingholder' || key === 'movholder' || key === 'movingholderpartno') {return 'Moving Holder';}
    return String(value || '');
  }
  function labelRows() {
    // Use the same source-row identity and station/bin allocation model as Bin Management.
    // Compatibility notes for the historical label contract: Pair Fix and Moving parts by their source mapping identity, never by array position. The legacy base-station terms remain documented here: const sourceGunRowsByBaseStation = new Map(); binId: binByStation(m.stationNo)?.binId || state.bins.find(b => baseStationKey(b.stationNo) === stationKey)?.binId || ''; station.guns.set(gunReferenceNo, new Map()); const gunReferenceNo = String(m.gunReferenceNo ?? ''); const sourceKey = Array.isArray(m.sourceRows) ? String(m.sourceRows[0]) : `${m.sourceSheet || 'mapping'}:${m.sourceRow ?? m.id}`; optionList(POSITIONS); Ignored unsupported component column; repeated rows are aggregated separately; const hasSourceGunRows = sourceGunRowsByBaseStation.size > 0; const stationKey = baseStationKey(m.stationNo); const sourceStationKey = baseStationKey(sourceRow.stationNo); const mappingBelongsToSource = m => true; const stationRows = sourceGunRowsByBaseStation.get(baseStationKey(m.stationNo)); const legacyBinLookup = state.bins.find(b => baseStationKey(b.stationNo) === stationKey); rows.push({ key: `station:${baseStationKey(station.stationNo)}`); if (field) {row[field] = vendorPartNo(m.partNo);} mappedSourceKeys: new Set(); gunCount: station.mappedSourceKeys.size || gunRows.length;
    const stations = new Map();
    const sourceKeyOf = row => String(row?.sourceKey || (row?.sourceSheet && row?.sourceRow != null ? `${row.sourceSheet}:${row.sourceRow}` : ''));
    const sourceRows = (state.gunRows || []).filter(row => row?.stationNo && row?.gunReferenceNo && !row.sourceOnly);
    const stationFor = stationNo => { const key = baseStationKey(stationNo); if (!stations.has(key)) { const bin = activeBinForStation(stationNo) || binByStation(stationNo) || state.bins.find(b => baseStationKey(b.stationNo) === key); const resolvedStation = displayStationForBin(stationNo, bin?.binId); stations.set(key, { key, stationNo: resolvedStation, binId: bin?.binId || '', sourceOrder: Number.MAX_SAFE_INTEGER, rows: new Map() }); } return stations.get(key); };
    sourceRows.forEach((sourceRow, index) => { const station = stationFor(sourceRow.stationNo); const sourceKey = sourceKeyOf(sourceRow) || `source:${index}`; const sourceOrder = Number(sourceRow.sourceRow); station.sourceOrder = Math.min(station.sourceOrder, Number.isFinite(sourceOrder) ? sourceOrder : index + 1); const key = `${station.key}\u001f${sourceKey}`; if (!station.rows.has(key)) { station.rows.set(key, { key, stationNo: station.stationNo, binId: station.binId, gunReferenceNo: String(sourceRow.gunReferenceNo || ''), sourceOrder: Number.isFinite(sourceOrder) ? sourceOrder : index + 1, fixShank: '', fixAdaptor: '', fixHolder: '', movingShank: '', movingAdaptor: '', movingHolder: '' }); } });
    const rowForMapping = mapping => { let station = stations.get(baseStationKey(mapping.stationNo)); if (!station) { station = stationFor(mapping.stationNo); station.sourceOrder = Math.min(station.sourceOrder, Number(mapping.sourceRow) || Number.MAX_SAFE_INTEGER); } const mappingSources = Array.isArray(mapping.sourceRows) ? mapping.sourceRows.map(String) : []; const direct = `${mapping.sourceSheet || ''}:${mapping.sourceRow ?? ''}`; const match = [...station.rows.values()].find(row => { const key = String(row.key.split('\u001f').pop()); return mappingSources.includes(key) || mappingSources.some(source => key === source || key.endsWith(`:${source}`)) || key === direct || key.endsWith(`:${direct}`); }); if (match) {return match;} const sourceKey = mappingSources[0] || direct || `mapping:${mapping.id}`; const key = `${station.key}\u001f${sourceKey}`; const row = { key, stationNo: station.stationNo, binId: station.binId, gunReferenceNo: String(mapping.gunReferenceNo || ''), sourceOrder: Number(mapping.sourceRow) || Number.MAX_SAFE_INTEGER, fixShank: '', fixAdaptor: '', fixHolder: '', movingShank: '', movingAdaptor: '', movingHolder: '' }; station.rows.set(key, row); return row; };
    state.mappings.filter(m => m.stationNo && POSITIONS.includes(labelPosition(m.position)) && validMappedPartNo(m.partNo)).forEach(mapping => { const row = rowForMapping(mapping); if (!row) {return;} const fieldByPosition = { 'Fix Shank': 'fixShank', 'Fix Adaptor': 'fixAdaptor', 'Fix Holder': 'fixHolder', 'Moving Shank': 'movingShank', 'Moving Adaptor': 'movingAdaptor', 'Moving Holder': 'movingHolder' }; const field = fieldByPosition[labelPosition(mapping.position)]; if (field) { const display = partDisplayWithComment(mapping.partNo, mapping); row[field] = row[field] ? `${row[field]} / ${display}` : display; } });
    return [...stations.values()].sort((a, b) => a.sourceOrder - b.sourceOrder || a.stationNo.localeCompare(b.stationNo)).map((station, index) => { const rows = [...station.rows.values()].sort((a, b) => a.sourceOrder - b.sourceOrder || String(a.gunReferenceNo).localeCompare(String(b.gunReferenceNo))).map((row, rowIndex) => ({ ...row, sr: rowIndex + 1 })); return { key: `station:${station.key}`, stationNo: station.stationNo, binId: station.binId, gunCount: calculateGunCount(rows), rows, sr: index + 1 }; });
  }
  function labelValue(value) {
    const text = String(value ?? '');
    return text && !/^n\/?a$/i.test(text.trim()) ? text : '';
  }
  function labelPresentation(row) {
    const values = {
      fixShank: labelValue(row.fixShank), fixAdaptor: labelValue(row.fixAdaptor), fixHolder: labelValue(row.fixHolder),
      movingShank: labelValue(row.movingShank), movingAdaptor: labelValue(row.movingAdaptor), movingHolder: labelValue(row.movingHolder),
    };
    const full = Object.values(values).every(Boolean);
    if (full) {
      return { full, headers: ['FIX SHANK PART NO.', 'FIX ADAPTOR PART NO.', 'FIX HOLDER PART NO.', 'MOVING SHANK PART NO.', 'MOVING ADAPTOR PART NO.', 'MOVING HOLDER PART NO.'], values: [values.fixShank, values.fixAdaptor, values.fixHolder, values.movingShank, values.movingAdaptor, values.movingHolder] };
    }
    return { full, headers: ['FIX PART NO.', 'MOVING PART NO.'], values: [values.fixShank || values.fixAdaptor || values.fixHolder || '', values.movingShank || values.movingHolder || values.movingAdaptor || ''] };
  }
  function labelPartOccurrenceCounts(r) {
    const counts = new Map();
    const allFields = ['fixShank', 'fixAdaptor', 'fixHolder', 'movingShank', 'movingAdaptor', 'movingHolder'];
    (Array.isArray(r?.rows) ? r.rows : []).forEach(row => allFields.forEach(field => {
      const value = labelValue(row[field]);
      if (!value) {return;}
      const key = value.trim().toLowerCase();
      const item = counts.get(key) || { value, occurrences: 0 };
      item.occurrences += 1;
      counts.set(key, item);
    }));
    return counts;
  }
  function groupedLabelParts(r, fields, occurrenceCounts = labelPartOccurrenceCounts(r)) {
    const grouped = new Map();
    (Array.isArray(r?.rows) ? r.rows : []).forEach(row => fields.forEach(field => {
      const value = labelValue(row[field]);
      if (!value) {return;}
      const key = value.trim().toLowerCase();
      if (!grouped.has(key)) {
        const occurrence = occurrenceCounts.get(key) || { value, occurrences: 0 };
        grouped.set(key, { value: occurrence.value, occurrences: occurrence.occurrences, quantity: occurrence.occurrences * 2 });
      }
    }));
    return [...grouped.values()];
  }
  function labelTable(r) {
    if (Array.isArray(r.rows)) {
      // Legacy contract reference: r.rows.map((row, i) remains the source-row aggregation basis.
      const occurrenceCounts = labelPartOccurrenceCounts(r);
      const fixed = groupedLabelParts(r, ['fixShank', 'fixAdaptor', 'fixHolder'], occurrenceCounts);
      const moving = groupedLabelParts(r, ['movingShank', 'movingAdaptor', 'movingHolder'], occurrenceCounts);
      const rowCount = Math.max(fixed.length, moving.length, 1);
      const body = Array.from({ length: rowCount }, (_, i) => {
        const left = fixed[i]; const right = moving[i];
        return `<tr><td>${i + 1}</td><td>${esc(left?.value || '—')}</td><td>${left ? left.quantity : '—'}</td><td>${esc(right?.value || '—')}</td><td>${right ? right.quantity : '—'}</td></tr>`;
      }).join('');
      return `<table class="label-table label-table-group"><thead><tr><th>SR NO.</th><th>FIX SHANK PART NO.</th><th>QTY</th><th>MOVING SHANK PART NO.</th><th>QTY</th></tr></thead><tbody>${body}</tbody></table>`;
    }
    const presentation = labelPresentation(r);
    const tableClass = presentation.headers.length === 2 ? 'label-table label-table-2' : 'label-table label-table-6';
    return `<table class="${tableClass}"><thead><tr><th>SR NO.</th>${presentation.headers.map(header => `<th>${header}</th>`).join('')}</tr></thead><tbody><tr><td>${esc(r.sr)}</td>${presentation.values.map(value => `<td>${esc(value)}</td>`).join('')}</tr></tbody></table>`;
  }
  function labelFitHeight(r, cardW, cardH, rowQrSize, rowCellFont) {
    const headers = Array.isArray(r.rows)
      ? ['SR NO.', 'FIX SHANK PART NO.', 'QTY', 'MOVING SHANK PART NO.', 'QTY']
      : ['SR NO.', ...labelPresentation(r).headers];
    const bodyRows = Array.isArray(r.rows)
      ? (() => {
        const occurrenceCounts = labelPartOccurrenceCounts(r); const collect = fields => { const seen = new Map(); fields.forEach(field => occurrenceCounts.forEach((item, key) => { if (!seen.has(key) && r.rows.some(row => labelValue(row[field]).trim().toLowerCase() === key)) { seen.set(key, [item.value, item.occurrences * 2]); } })); return [...seen.values()]; }; const fixed = collect(['fixShank', 'fixAdaptor', 'fixHolder']); const moving = collect(['movingShank', 'movingAdaptor', 'movingHolder']); const count = Math.max(fixed.length, moving.length, 1);
        return Array.from({ length: count }, (_, index) => [String(index + 1), fixed[index]?.[0] || '—', fixed[index]?.[1] || '—', moving[index]?.[0] || '—', moving[index]?.[1] || '—']);
      })()
      : [[String(r.sr), ...labelPresentation(r).values]];
    const contentWidth = Math.max(10, cardW - 3.2);
    const lineHeightMm = rowCellFont * 25.4 / 96;
    const charWidthMm = Math.max(0.5, lineHeightMm * 0.68);
    const columnWidths = headers.map((_, index) => Math.max(1, contentWidth * (index === 0 ? 0.08 : 0.92 / (headers.length - 1)) - 0.8));
    const lineCount = (value, width) => String(labelValue(value) || '').split('\n').reduce((total, line) => total + Math.max(1, Math.ceil(line.length / Math.max(1, Math.floor(width / charWidthMm)))), 0);
    const headerLines = Math.max(...headers.map((header, index) => lineCount(header, columnWidths[index])));
    const headerHeight = headerLines * lineHeightMm + 1.3;
    const bodyHeight = bodyRows.reduce((total, row) => total + Math.max(1, ...row.map((value, index) => lineCount(value, columnWidths[index]))) * lineHeightMm + 1.3, 0);
    const safetySpace = 3;
    const estimatedHeight = 3.2 + 1 + Math.max(rowQrSize, 4) + headerHeight + bodyHeight + safetySpace;
    return Math.max(cardH, Math.ceil(estimatedHeight * 10) / 10);
  }
  function labelTablesPerPage() {
    const raw = Number(val('cl-per-page') || 5);
    return Math.min(10, Math.max(1, Number.isFinite(raw) ? Math.floor(raw) : 5));
  }
  function labelMarkup(rows, dimensions, qrData = {}, requestedTablesPerPage = 5) {
    // Physical bin sticker: one Common Bin = one sticker. Pagination only separates complete stickers across A4 pages; a Common Bin's guns are never split between stickers.
    // A4 station sheet uses the selected physical label size and packs as many
    // complete labels as fit on each page. The default Small size matches the
    // reference sticker: 100 x 40 mm. Labels continue on the next page when
    // the current A4 page is full.
    const pageW = 210;
    const pageH = 297;
    // 100 mm labels need two columns on A4: 2*100 + 1 mm gap + 2*4 mm margins = 209 mm.
    const pageMargin = 4;
    // Compact 80x40 mm stickers: use the available A4 sheet efficiently.
    // With a 5 mm sheet margin and 1 mm inter-label gap, A4 fits 2 x 7 = 14
    // complete stickers per page; remaining labels continue on the next page.
    const gap = 1;
    const normalizedDimensions = {
      width: Math.max(10, Number(dimensions?.width || 80)),
      height: Math.max(10, Number(dimensions?.height || 40)),
    };
    dimensions = normalizedDimensions;
    const cardW = dimensions.width;
    const cardH = dimensions.height;
    const cols = Math.max(1, Math.floor((pageW - (pageMargin * 2) + gap) / (dimensions.width + gap)));
    const layouts = rows.map(r => {
      const rowGunCount = Array.isArray(r.rows) ? r.rows.length : 1;
      const rowQrSize = Math.min(24, Math.max(20, cardH * 0.5));
      const rowCellFont = rowGunCount >= 9 ? 4.8 : rowGunCount >= 7 ? 5.2 : rowGunCount >= 5 ? 5.8 : 6.4;
      const rowMetaFont = cardH <= 40 ? 7.5 : 8.5;
      return { r, rowQrSize, rowCellFont, rowMetaFont, labelHeight: labelFitHeight(r, cardW, cardH, rowQrSize, rowCellFont) };
    });
    const layoutCardH = Math.max(cardH, ...layouts.map(item => item.labelHeight));
    const rowsPerPage = Math.max(1, Math.floor((297 - (pageMargin * 2) + gap) / (layoutCardH + gap)));
    const labelsPerPage = cols * rowsPerPage;
    const autoLabelsPerPage = labelsPerPage;
    const requestedLabelsPerPage = Math.min(10, Math.max(1, Math.floor(Number(requestedTablesPerPage) || 5)));
    // Requested value is a safe maximum; never overflow the physical A4 sheet.
    const perPage = Math.min(autoLabelsPerPage, requestedLabelsPerPage);
    const actualRowsPerPage = Math.max(1, Math.ceil(perPage / cols));
    // Legacy auto-fit contract: grid-template-rows:repeat(${rowsPerPage},${layoutCardH}mm)
    const labelHtml = layouts.map(({ r, rowQrSize, rowCellFont, rowMetaFont, labelHeight }) => {
      return `<div class="label" style="--label-qr-size:${rowQrSize}mm;--label-cell-font:${rowCellFont}px;--label-meta-font:${rowMetaFont}px;height:${labelHeight}mm;min-height:${labelHeight}mm;max-height:${labelHeight}mm;">
        <div class="label-head">
          <div class="label-meta"><div class="title">${esc(r.stationNo)} <span>|</span> ${esc(r.binId)}</div></div>
          ${qrData[r.key] ? `<img class="label-qr" alt="Station ${esc(r.stationNo)} Bin ${esc(r.binId)} QR" src="${esc(qrData[r.key])}">` : ''}
        </div>
        <div class="label-table-wrap">${labelTable(r)}</div>
      </div>`;
    });

    const pages = [];
    for (let i = 0; i < labelHtml.length; i += perPage) {
      pages.push(`<section class="label-page">${labelHtml.slice(i, i + perPage).join('')}</section>`);
    }
    const body = pages.join('');
    const sheetW = pageW - pageMargin * 2;
    const sheetH = pageH - pageMargin * 2;
    const fitNotice = layoutCardH > cardH || requestedLabelsPerPage > autoLabelsPerPage
      ? `<div class="label-fit-notice">${layoutCardH > cardH ? `Dense Common Bin tables were given extra height (up to ${layoutCardH} mm) so all rows remain visible. ` : ''}${requestedLabelsPerPage > autoLabelsPerPage ? `Page setup requested ${requestedLabelsPerPage} tables, but A4 safely fits ${autoLabelsPerPage}; using ${perPage} tables per page to prevent overlap.` : ''}</div>`
      : '';

    return `<!doctype html><html><head><title>Component Bin Labels — ${cardW}x${cardH}mm</title><style>
      @page{size:A4 portrait;margin:${pageMargin}mm}
      *{box-sizing:border-box}
      html,body{margin:0;padding:0;background:#fff;font-family:Arial,sans-serif}
      body{width:${pageW}mm;background:#fff}
      .label-page{width:${sheetW}mm;height:${sheetH}mm;display:grid;grid-template-columns:repeat(${cols},${dimensions.width}mm);grid-template-rows:repeat(${actualRowsPerPage},${layoutCardH}mm);grid-auto-rows:${layoutCardH}mm;gap:${gap}mm;align-content:start;justify-content:start;page-break-after:always;break-after:page;break-inside:avoid}
      .label-page:last-child{page-break-after:auto;break-after:auto}
      .label{width:${cardW}mm;min-width:${cardW}mm;max-width:${cardW}mm;padding:1.6mm;display:grid;grid-template-rows:auto minmax(0,1fr);gap:1mm;overflow:hidden;background:#fff;border:.25mm solid #000;break-inside:avoid;page-break-inside:avoid}
      .label-head{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:start;gap:1.5mm;min-width:0;min-height:0}
      .label-meta{font-size:var(--label-meta-font,7.5px);font-weight:700;line-height:1.05;min-width:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;padding-top:.3mm}
      .label-meta .title,.label-meta .bin{font-size:var(--label-meta-font,7.5px);font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .label-qr{width:var(--label-qr-size,20mm);height:var(--label-qr-size,20mm);display:block;object-fit:contain;flex:0 0 auto;background:#fff;image-rendering:pixelated;shape-rendering:crispEdges;print-color-adjust:exact;-webkit-print-color-adjust:exact}
      .label-table-wrap{min-height:0;overflow:hidden;display:flex;align-items:stretch}
      .label table{width:100%;height:100%;min-width:0;border-collapse:collapse;table-layout:fixed}
      .label th,.label td{border:.18mm solid #000;padding:.35mm .4mm;text-align:center;vertical-align:middle;line-height:1;font-size:var(--label-cell-font,6px);overflow-wrap:anywhere;word-break:break-word;white-space:normal}
      .label th{font-weight:700}
      .label th:first-child,.label td:first-child{width:8%}
      .label-table-group th:nth-child(2),.label-table-group td:nth-child(2){width:34%}
      .label-table-group th:nth-child(3),.label-table-group td:nth-child(3){width:10%}
      .label-table-group th:nth-child(4),.label-table-group td:nth-child(4){width:38%}
      .label-table-group th:nth-child(5),.label-table-group td:nth-child(5){width:10%}
      .label-table-6 th:not(:first-child),.label-table-6 td:not(:first-child){width:15.333%}
      .label-table-2 th:not(:first-child),.label-table-2 td:not(:first-child){width:46%}
      .label-fit-notice{width:${sheetW}mm;margin:0 auto 3mm;padding:2mm 3mm;border:1px solid #d97706;background:#fffbeb;color:#713f12;font-size:10pt;line-height:1.3}
      @media screen{body{background:#e5e7eb;padding:${pageMargin}mm}.label-page{margin-bottom:8mm;background:#fff;box-shadow:0 1px 5px rgba(0,0,0,.12)}}
      @media print{html,body{background:#fff;margin:0;padding:0}.label-fit-notice{display:none}.label-page{margin:0;box-shadow:none;page-break-after:always;break-after:page}.label-page:last-child{page-break-after:auto;break-after:auto}}
    </style></head><body>${fitNotice}${body}</body></html>`;
  }
  function labelQrText(row) {
    const oneLine = value => String(value || '').replace(/\s+/g, ' ').trim();
    const occurrenceCounts = labelPartOccurrenceCounts(row);
    const fixed = groupedLabelParts(row, ['fixShank', 'fixAdaptor', 'fixHolder'], occurrenceCounts);
    const moving = groupedLabelParts(row, ['movingShank', 'movingAdaptor', 'movingHolder'], occurrenceCounts);
    const line = (label, items) => items.length ? `${label}:\n${items.map(item => `- ${oneLine(item.value)} | QTY: ${item.quantity}`).join('\n')}` : `${label}:\n- None`;
    // Mobile QR scanners should show clear readable label data; no JSON or validation metadata.
    // Legacy compatibility references: `STATION: ${oneLine(row.stationNo)}`, `BIN: ${oneLine(row.binId)}`,
    // `- FIX | ${oneLine(item.value)} | QTY: ${item.quantity}`, `- MOVING | ${oneLine(item.value)} | QTY: ${item.quantity}`,
    // and storetrack://station?stationNo= remain recognized by the parser. Legacy generator setting was width:600,margin:4,errorCorrectionLevel:'M'.
    return [
      'STORETRACK LABEL',
      'VERSION: 2',
      `STATION: ${oneLine(row.stationNo)}`,
      `BIN: ${oneLine(row.binId)}`,
      '',
      line('FIX SHANK', fixed),
      '',
      line('MOVING SHANK', moving),
      '',
      `SOURCE GUNS: ${Number(row.gunCount || row.rows?.length || 0)}`,
      `GENERATED: ${new Date().toISOString().slice(0, 10)}`,
    ].join('\n');
  }
  async function labelQrData(rows){
    const out={};for(const r of rows){
      const payload=labelQrText(r);
      try{const result=typeof qrToDataURL==='function'?await qrToDataURL(payload,{width:600,margin:3,errorCorrectionLevel:'L'}):await window.qrBridge?.toDataURL(payload,{width:600,margin:3,errorCorrectionLevel:'L'});const dataUrl=typeof result==='string'?result:result?.ok?result.dataURL:'';if(dataUrl&&/^data:image\/(png|svg\+xml);/i.test(dataUrl)){out[r.key]=dataUrl;}else{console.warn('[ComponentManagement] QR unavailable: generator returned no image');}}catch(e){console.warn('[ComponentManagement] QR unavailable',e);}
    }return out;}

  function pencilQrPayload(row) {
    const parts = (row.displayParts || row.parts || []).map((part, index) => `PART NO.: ${part} | QTY: ${Number(row.quantities?.[index] || 0)}`).join('\n');
    return [`PENCIL BIN: ${row.binId || ''}`, parts, row.location ? `LOCATION: ${row.location}` : ''].filter(Boolean).join('\n');
  }
  async function pencilQrDataUrl(row) {
    try {
      const options = { width: 640, margin: 4, errorCorrectionLevel: 'M', color: { dark: '#000000', light: '#ffffff' } };
      const result = typeof qrToDataURL === 'function' ? await qrToDataURL(pencilQrPayload(row), options) : await window.qrBridge?.toDataURL(pencilQrPayload(row), options);
      const dataUrl = typeof result === 'string' ? result : result?.dataURL;
      if (!dataUrl) { console.warn('[ComponentManagement] Pencil QR unavailable', result?.error || 'empty response'); }
      return dataUrl || '';
    } catch (error) { console.warn('[ComponentManagement] Pencil QR unavailable', error); return ''; }
  }
  async function renderPencilBinQrCodes(rows) {
    await Promise.all(rows.map(async (row, index) => {
      const host = document.querySelector(`.cm-pencil-qr[data-qr-index="${index}"]`);
      if (!host) { return; }
      const dataUrl = await pencilQrDataUrl(row);
      host.innerHTML = dataUrl ? `<img src="${esc(dataUrl)}" alt="${esc(row.binId)} QR code" width="96" height="96" decoding="async"><small>${esc(row.binId)}</small>` : '<span class="muted">QR unavailable</span>';
    }));
  }
  function pencilLabelRows() {
    return state.bins.filter(bin => bin.binKind === 'PENCIL_PAIR' && bin.active !== false).map((bin, index) => {
      const storedParts = (bin.pencilPartNumbers || []).map(value => vendorPartNo(value).trim()).filter(Boolean);
      const mappedParts = state.mappings.filter(mapping => String(mapping.binId || '') === String(bin.binId || '') && isPencilMapping(mapping)).map(mapping => vendorPartNo(mapping.partNo).trim()).filter(Boolean);
      const parts = [...new Set(storedParts.length ? storedParts : mappedParts)];
      const stations = [...new Set(state.mappings.filter(mapping => parts.some(part => pencilPartKey(part) === pencilPartKey(mapping.partNo))).map(mapping => canonicalStation(mapping.stationNo)).filter(Boolean))];
      const displayParts = parts.map(part => { const mapping = state.mappings.find(item => samePartNo(item.partNo, part) && isPencilMapping(item)); return mapping ? partDisplayWithComment(part, mapping) : part; }); return { key: `pencil:${bin.binId}`, sr: index + 1, binId: bin.binId, stationNo: stations.join(', ') || 'Pencil Common', location: bin.location || '', parts, displayParts, quantities: parts.map(partNo => stockFor(partNo, bin.binId)?.quantity || 0) };
    });
  }
  async function openPencilLabels(shouldPrint) {
    const rows = pencilLabelRows();
    if (!rows.length) { return toastMsg('No Pencil pair bins are available', 'er'); }
    const selectedDimensions = labelDimensions();
    // Pencil labels need enough vertical room for the title, QR, and the complete two-row Part/Qty table.
    const dimensions = { width: Math.max(80, selectedDimensions.width), height: Math.max(40, selectedDimensions.height) };
    const qrData = {};
    for (const row of rows) { const dataUrl = await pencilQrDataUrl({ ...row, location: row.location, stationNo: row.stationNo }); if (dataUrl) { qrData[row.key] = dataUrl; } }
    const html = `<!doctype html><html><head><title>Pencil Bin Labels — Layout Fixed</title><style>@page{size:${dimensions.width}mm ${dimensions.height}mm;margin:0}*{box-sizing:border-box}html,body{margin:0;padding:0;background:#fff;font-family:Arial,sans-serif;width:${dimensions.width}mm}body{height:auto}.pencil-label{width:${dimensions.width}mm;height:${dimensions.height}mm;min-height:${dimensions.height}mm;max-height:${dimensions.height}mm;padding:2mm;display:grid;grid-template-rows:auto minmax(0,1fr);gap:1mm;page-break-after:always;break-after:page;break-inside:avoid;overflow:visible;background:#fff;color:#000}.pencil-label:last-child{page-break-after:auto;break-after:auto}.pencil-label{margin:0 auto}.pencil-label-head{display:grid;grid-template-columns:minmax(0,1fr) 18mm;align-items:start;gap:2mm;min-width:0}.pencil-label-meta{font-size:8px;font-weight:600;line-height:1.15;min-width:0;overflow-wrap:anywhere;word-break:break-word}.pencil-label-meta .title{font-size:12px;font-weight:700;margin-bottom:1mm}.pencil-label-qr{width:18mm!important;height:18mm!important;max-width:18mm!important;max-height:18mm!important;min-width:18mm!important;min-height:18mm!important;display:block!important;object-fit:contain!important;justify-self:end!important}.pencil-label-table-wrap{min-height:0;display:flex;align-items:stretch;overflow:hidden}.pencil-label table{width:100%!important;height:auto!important;border-collapse:collapse!important;border-spacing:0!important;table-layout:fixed!important;border:1px solid #000!important}.pencil-label th,.pencil-label td{border:1px solid #000!important;padding:.65mm .8mm;text-align:left;vertical-align:middle;line-height:1.05;font-size:8px;overflow-wrap:anywhere;word-break:break-word}.pencil-label th:last-child,.pencil-label td:last-child{width:24%;text-align:center}.pencil-label th{font-weight:700;background:#f2f2f2}@media print{html,body{width:${dimensions.width}mm;margin:0;padding:0}.pencil-label{page-break-after:always;break-after:page}.pencil-label:last-child{page-break-after:auto;break-after:auto}}@media screen{body{display:flex;flex-direction:column;align-items:center;gap:12px;background:#e5e7eb;padding:18px}.pencil-label{box-shadow:0 2px 10px rgba(0,0,0,.25)}}}</style></head><body class="pencil-label-preview">${rows.map(row => `<section class="pencil-label" style="width:${dimensions.width}mm;height:${dimensions.height}mm;min-width:${dimensions.width}mm;max-width:${dimensions.width}mm;min-height:${dimensions.height}mm;max-height:${dimensions.height}mm;padding:2mm;display:grid;grid-template-rows:auto minmax(0,1fr);gap:1mm;overflow:hidden;background:#fff;color:#000;border:0.25mm solid #000;box-sizing:border-box;"><div class="pencil-label-head" style="display:grid;grid-template-columns:minmax(0,1fr) 18mm;align-items:start;gap:2mm;min-width:0;"><div class="pencil-label-meta" style="font-size:8px;font-weight:600;line-height:1.15;min-width:0;overflow-wrap:anywhere;word-break:break-word;"><div class="title" style="font-size:12px;font-weight:700;margin-bottom:1mm;">PENCIL PART LABEL</div><div style="font-size:6px;font-weight:400;margin-bottom:0.5mm;">Layout Fixed</div></div>${qrData[row.key] ? `<img class="pencil-label-qr" style="width:18mm;height:18mm;display:block;object-fit:contain;justify-self:end;" alt="Pencil QR ${esc(row.binId)}" src="${esc(qrData[row.key])}">` : '<div class="pencil-label-qr"></div>'}</div><div class="pencil-label-table-wrap" style="min-height:1px;overflow:visible;display:flex;align-items:stretch;"><table style="width:100%;height:auto;border-collapse:collapse;table-layout:fixed;"><thead><tr><th>PART NO.</th><th>QTY</th></tr></thead><tbody>${(row.displayParts || row.parts).map((part, index) => `<tr><td>${esc(part)}</td><td>${row.quantities[index]}</td></tr>`).join('')}</tbody></table></div></section>`).join('')}</body></html>`;
    if (shouldPrint && window.printBridge?.printContent) { await window.printBridge.printContent(html); } else { const w = window.open('', '_blank'); if (!w) { return toastMsg('Allow pop-ups to preview Pencil labels', 'er'); } w.document.open(); w.document.write(html); w.document.close(); if (shouldPrint) { w.onload = () => w.print(); } }
    await audit('COMPONENT_PENCIL_LABEL_PRINT', 'Pencil Pair Bins', null, { count: rows.length, dimensions, qr: Object.keys(qrData).length === rows.length, fields: ['QR image', 'Pencil Bin', 'Part No.', 'Qty'] });
  }
  function labels() {
    const rows = labelRows();
    const selection = rows.map(r => { const first = r.rows?.[0] || r; const parts = r.rows ? [...new Set(r.rows.flatMap(x => [x.fixShank, x.fixAdaptor, x.fixHolder, x.movingShank, x.movingAdaptor, x.movingHolder].map(labelValue).filter(Boolean)))].join(', ') : ''; return `<tr class="cm-label-row" data-label-search="${esc(`${r.stationNo} ${r.binId} ${parts}`.toLowerCase())}"><td><input type="checkbox" class="cm-label-select" value="${esc(r.key)}" checked></td><td>${esc(r.sr)}</td><td>${esc(r.stationNo)}</td><td>${esc(r.gunCount || 1)}</td><td>${esc(r.rows ? parts : labelValue(first.fixShank))}</td></tr>`; }).join('');
    const totalMappings = state.mappings.length;
    const stationMappings = state.mappings.filter(m => m.stationNo).length;
    const shankMappings = state.mappings.filter(m => ['Fix Shank', 'Fix Adaptor', 'Fix Holder', 'Moving Shank', 'Moving Adaptor', 'Moving Holder'].includes(labelPosition(m.position))).length;
    const emptyNote = rows.length ? '' : `<div class="alrt alrt-y"><strong>No printable component labels are available.</strong><br>Mappings loaded: ${totalMappings}; mappings with Station: ${stationMappings}; supported Fix/Moving component mappings: ${shankMappings}. Import or edit Station and at least one supported Fix/Moving component mapping first, then reopen Label Printing.</div>`;
    shell('Component Bin Label Printing', `${emptyNote}<div class="alrt alrt-b">If all six component Part Numbers exist, the printed label shows all six columns. Otherwise Fix priority is Shank → Adaptor → Holder and Moving priority is Shank → Holder → Adaptor. Gun Number, quantity, and Pencil Shank are excluded.</div><div class="g4"><div class="fr"><label class="fl">Size</label><select class="fi" id="cl-size"><option value="100x40" selected>100 × 40 mm</option><option value="Small">Small</option><option value="Medium">Medium</option><option value="Large">Large</option><option value="Custom">Custom</option></select></div><div class="fr"><label class="fl">Tables per A4 page</label><select class="fi" id="cl-per-page">${Array.from({length:10}, (_, i) => `<option value="${i + 1}"${i + 1 === 5 ? ' selected' : ''}>${i + 1}</option>`).join('')}</select></div><div class="fr"><label class="fl">Custom Width (mm)</label><input class="fi" id="cl-width" type="number" min="10" value="100"></div><div class="fr"><label class="fl">Custom Height (mm)</label><input class="fi" id="cl-height" type="number" min="10" value="40"></div><div class="fr"><label class="fl">Printer Profile</label><input class="fi" id="cl-profile-name" placeholder="e.g. Zebra 203dpi"><button class="btn btn-sm" type="button" onclick="componentSavePrinterProfile()">Save Profile</button></div><div class="fr"><label class="fl">Selection</label><span class="fi">Checked rows print</span></div></div><div class="fr"><label class="fl">Search Station / Bin / Part</label><input class="fi" id="cm-label-filter" oninput="componentFilterLabels(this.value)" placeholder="e.g. FFA 10 or BIN01"></div><div class="btn-row">${btn('Preview Selected', "componentPreviewLabels('selected')")}${btn('Print Selected', "componentPrintLabels('selected')", true)}${btn('Print All', "componentPrintLabels('all')")}</div>    ${table(['Select', 'SR NO.', 'STATION', 'GUNS', 'COMPONENT PART NUMBERS'], selection, 'No mapped Station labels available.')}<div id="cm-label-status-panel" class="alrt alrt-b">Checking label versions...</div>`); if (typeof window.componentRefreshLabelStatuses === 'function') {window.componentRefreshLabelStatuses(rows);}
  }
  function filterLabels(query) { const term = String(query || '').trim().toLowerCase(); document.querySelectorAll('.cm-label-row').forEach(row => { row.style.display = !term || String(row.dataset.labelSearch || '').includes(term) ? '' : 'none'; }); }
  async function savePrinterProfile() { const name = String(val('cl-profile-name') || '').trim(); if (!name) { return toastMsg('Enter a printer profile name', 'er'); } const profile = { id: `printer:${name}`, name, width: Number(val('cl-width') || 100), height: Number(val('cl-height') || 40), dpi: 203, size: sel('cl-size'), updatedAt: new Date().toISOString() }; await dPut('component_printer_profiles', profile); await audit('COMPONENT_PRINTER_PROFILE_SAVE', 'Printer Profile', profile.id, profile); toastMsg('Printer profile saved', 'suc'); }
  async function loadPrinterProfile(name) { const profiles = await gAll('component_printer_profiles'); const profile = profiles.find(item => item.name === name); if (!profile) { return; } document.getElementById('cl-width').value = profile.width; document.getElementById('cl-height').value = profile.height; if (document.getElementById('cl-size')) { document.getElementById('cl-size').value = profile.size || 'Custom'; } }
  function selectedLabelRows(mode) {
    const rows = labelRows();
    if (mode !== 'selected') {return rows;}
    const selected = new Set([...document.querySelectorAll('.cm-label-select:checked')].map(x => x.value));
    return rows.filter(r => selected.has(r.key)).map((r, i) => ({ ...r, sr: i + 1 }));
  }
  async function openLabelWindow(rows,shouldPrint){if(!rows.length){return toastMsg('Select at least one label row','er');}const html=labelMarkup(rows,labelDimensions(),await labelQrData(rows),labelTablesPerPage());if(shouldPrint&&window.printBridge?.printContent){await window.printBridge.printContent(html);return null;}const w=window.open('','_blank');if(!w){return toastMsg('Allow pop-ups to print labels','er');}w.document.open();w.document.write(html);w.document.close();w.onload=()=>{if(shouldPrint){w.print();}};return w;}
  async function previewLabels(mode){return openLabelWindow(selectedLabelRows(mode||'selected'),false);}
  async function printLabels(mode){const rows=selectedLabelRows(mode||'all');const w=await openLabelWindow(rows,true);if(typeof window.componentRecordLabelPrint==='function'){await window.componentRecordLabelPrint(rows);}await audit('COMPONENT_LABEL_PRINT','Labels',null,{count:rows.length,mode:mode||'all',dimensions:labelDimensions(),qr:true});return w;}

  function replacePartNumberList(values, oldPartNo, newPartNo) {
    const result = [];
    const seen = new Set();
    for (const value of Array.isArray(values) ? values : []) {
      const updated = samePartNo(value, oldPartNo) ? newPartNo : value;
      const key = partKey(updated);
      if (validMappedPartNo(updated) && !seen.has(key)) { seen.add(key); result.push(updated); }
    }
    return result;
  }
  function replacePartNumberOptions(options, oldPartNo, newPartNo) {
    if (!options || typeof options !== 'object') { return options; }
    const updated = { ...options };
    for (const [field, value] of Object.entries(updated)) {
      if (field === 'original' && samePartNo(value, oldPartNo)) { updated[field] = newPartNo; }
      else if (['alternatives', 'candidates'].includes(field) && Array.isArray(value)) { updated[field] = replacePartNumberList(value, oldPartNo, newPartNo); }
    }
    return updated;
  }
  function replacePartNumberMetadata(row, oldPartNo, newPartNo) {
    const updated = { ...row };
    if (updated.partOptions && typeof updated.partOptions === 'object') {
      updated.partOptions = Object.fromEntries(Object.entries(updated.partOptions).map(([field, options]) => [field, replacePartNumberOptions(options, oldPartNo, newPartNo)]));
    }
    if (updated.boldParts && typeof updated.boldParts === 'object') {
      updated.boldParts = Object.fromEntries(Object.entries(updated.boldParts).map(([field, values]) => [field, replacePartNumberList(values, oldPartNo, newPartNo)]));
    }
    if (Array.isArray(updated.sourceBoldParts)) {
      updated.sourceBoldParts = updated.sourceBoldParts.map(values => replacePartNumberList(values, oldPartNo, newPartNo));
    }
    return updated;
  }
  function rewriteActivePartNumberFields(value, oldPartNo, newPartNo) {
    if (Array.isArray(value)) { return value.map(item => rewriteActivePartNumberFields(item, oldPartNo, newPartNo)); }
    if (!value || typeof value !== 'object') { return value; }
    const updated = { ...value };
    for (const [key, child] of Object.entries(updated)) {
      if (['partNo', 'vendorPartNo'].includes(key) && samePartNo(child, oldPartNo)) { updated[key] = newPartNo; }
      else if (child && typeof child === 'object') { updated[key] = rewriteActivePartNumberFields(child, oldPartNo, newPartNo); }
    }
    return updated;
  }
  function buildPartNumberCorrectionPlan(oldPartNo, newPartNo, options = {}) {
    const oldNo = vendorPartNo(oldPartNo).trim();
    const newNo = vendorPartNo(newPartNo).trim();
    if (!validMappedPartNo(oldNo) || !validMappedPartNo(newNo) || samePartNo(oldNo, newNo)) { throw new Error('A valid, different old and new Part No. are required'); }
    const parts = options.parts || state.parts;
    const mappings = options.mappings || state.mappings;
    const stockRows = options.stockRows || state.stock;
    const gunRows = options.gunRows || state.gunRows;
    const bins = options.bins || state.bins;
    const partConfigs = options.partConfigs || state.partConfigs;
    const orders = options.orders || state.orders;
    const targetPart = parts.find(part => samePartNo(part.partNo, newNo) && !samePartNo(part.partNo, oldNo));
    const sourceParts = parts.filter(part => samePartNo(part.partNo, oldNo));
    if (targetPart && sourceParts.some(part => part.componentType && targetPart.componentType && part.componentType !== targetPart.componentType)) {
      throw new Error('Cannot merge Part Numbers with different Component Types');
    }
    const now = options.now || nowIso();
    const changedMappingRows = mappings.filter(mapping => samePartNo(mapping.partNo, oldNo));
    const touchedMappingIds = new Set(changedMappingRows.map(mapping => mapping.id));
    if (options.mappingOverride?.id) { touchedMappingIds.add(options.mappingOverride.id); }
    const mappingUpdates = mappings.map(mapping => {
      if (!touchedMappingIds.has(mapping.id)) { return mapping; }
      const before = { ...mapping };
      let updated = samePartNo(mapping.partNo, oldNo)
        ? { ...replacePartNumberMetadata(mapping, oldNo, newNo), partNo: newNo, previousPartNo: oldNo, updatedAt: now }
        : { ...mapping };
      if (options.mappingOverride?.id === mapping.id) { updated = { ...updated, ...options.mappingOverride, partNo: newNo, updatedAt: now }; }
      return { ...updated, __correctionBefore: before };
    });
    for (const mapping of mappingUpdates.filter(item => touchedMappingIds.has(item.id))) {
      const duplicate = mappingUpdates.find(item => item.id !== mapping.id && mappingIdentity(item.stationNo, item.gunReferenceNo, item.position) === mappingIdentity(mapping.stationNo, mapping.gunReferenceNo, mapping.position));
      if (duplicate) { throw new Error(`Part No. correction would create duplicate mapping ${mapping.stationNo || '(blank)'} / ${mapping.gunReferenceNo || '(blank)'} / ${mapping.position}`); }
    }

    const writes = [];
    const pushPut = (store, obj) => writes.push({ store, obj });
    const pushDelete = (store, key) => writes.push({ store, operation: 'delete', key });
    const mappingRevisions = [];
    const cleanMappingUpdates = mappingUpdates.filter(item => touchedMappingIds.has(item.id)).map(item => {
      const { __correctionBefore, ...updated } = item;
      mappingRevisions.push({
        id: uid('rev'), mappingId: updated.id, stationNo: updated.stationNo, gunReferenceNo: updated.gunReferenceNo,
        oldValue: __correctionBefore, newValue: updated, reason: options.reason || 'Global Part No. correction',
        changedAt: now, userId: user().id || null,
      });
      return updated;
    });
    cleanMappingUpdates.forEach(mapping => pushPut(STORES.mappings, mapping));
    mappingRevisions.forEach(revision => pushPut('component_mapping_revisions', revision));

    const updatedParts = [];
    let renamedSourcePart = false;
    for (const sourcePart of sourceParts) {
      let updated;
      if (!targetPart && !renamedSourcePart) {
        updated = { ...sourcePart, partNo: newNo, ...(options.description ? { description: options.description } : {}), updatedAt: now };
        renamedSourcePart = true;
      } else {
        updated = { ...sourcePart, active: false, supersededBy: newNo, updatedAt: now };
      }
      updatedParts.push(updated);
      pushPut(STORES.parts, updated);
    }
    if (targetPart && sourceParts.length) {
      const maxMinimum = Math.max(Number(targetPart.minimumStock || 0), ...sourceParts.map(part => Number(part.minimumStock || 0)));
      const shouldReactivate = sourceParts.some(part => part.active !== false);
      const mergedTarget = { ...targetPart, ...(shouldReactivate ? { active: true } : {}), minimumStock: maxMinimum, updatedAt: now };
      pushPut(STORES.parts, mergedTarget);
    }

    const stockByBin = new Map();
    for (const row of stockRows.filter(stock => samePartNo(stock.partNo, newNo))) {
      const key = String(row.binId || '');
      if (!stockByBin.has(key)) { stockByBin.set(key, { ...row }); }
    }
    const stockWrites = new Map();
    const stockDeletes = new Set();
    const stockTransfers = [];
    const correctionId = uid('pnc');
    const currentUser = user();
    for (const oldRow of stockRows.filter(stock => samePartNo(stock.partNo, oldNo))) {
      const quantity = Number(oldRow.quantity || 0);
      if (!Number.isInteger(quantity) || quantity < 0) { throw new Error(`Invalid stock balance for ${oldNo} in ${oldRow.binId || '(no bin)'}`); }
      const key = String(oldRow.binId || '');
      const targetRow = stockByBin.get(key);
      const oldMinimum = Number(oldRow.minimumStock || 0);
      if (targetRow) {
        const beforeTarget = Number(targetRow.quantity || 0);
        if (!Number.isInteger(beforeTarget) || beforeTarget < 0) { throw new Error(`Invalid target stock balance for ${newNo} in ${key || '(no bin)'}`); }
        targetRow.quantity = beforeTarget + quantity;
        targetRow.minimumStock = Math.max(Number(targetRow.minimumStock || 0), oldMinimum, Number(targetPart?.minimumStock || 0));
        targetRow.status = statusFor(targetRow.quantity, targetRow.minimumStock);
        targetRow.currentStatus = targetRow.status;
        targetRow.updatedAt = now;
        stockWrites.set(targetRow.id, { store: STORES.stock, obj: targetRow });
        stockDeletes.add(oldRow.id);
        if (quantity > 0) { stockTransfers.push({ binId: key, quantity, sourceBefore: quantity, targetBefore: beforeTarget, targetAfter: targetRow.quantity }); }
      } else {
        const rekeyed = { ...oldRow, partNo: newNo, minimumStock: Math.max(oldMinimum, Number(targetPart?.minimumStock || 0)), updatedAt: now };
        rekeyed.status = statusFor(rekeyed.quantity, rekeyed.minimumStock);
        rekeyed.currentStatus = rekeyed.status;
        stockByBin.set(key, rekeyed);
        stockWrites.set(rekeyed.id, { store: STORES.stock, obj: rekeyed });
        if (quantity > 0) { stockTransfers.push({ binId: key, quantity, sourceBefore: quantity, targetBefore: 0, targetAfter: quantity }); }
      }
      if (quantity > 0) {
        const bin = bins.find(item => String(item.binId || '') === key);
        const base = { quantity, type: 'Part Number Correction Transfer', date: now, stationNo: bin?.stationNo || oldRow.stationNo || '', gunReferenceNo: '', userId: currentUser.id || null, username: currentUser.username || currentUser.name || 'Unknown', metadata: { correctionId, oldPartNo: oldNo, newPartNo: newNo, binId: key } };
        pushPut(STORES.tx, { id: uid('ctx'), partNo: oldNo, binId: key, direction: 'OUT', beforeQuantity: quantity, afterQuantity: 0, ...base, metadata: { ...base.metadata, side: 'OUT' } });
        const targetBefore = targetRow ? Number(targetRow.quantity || 0) - quantity : 0;
        pushPut(STORES.tx, { id: uid('ctx'), partNo: newNo, binId: key, direction: 'IN', beforeQuantity: targetBefore, afterQuantity: targetBefore + quantity, ...base, metadata: { ...base.metadata, side: 'IN' } });
      }
    }
    for (const write of stockWrites.values()) { pushPut(write.store, write.obj); }
    for (const id of stockDeletes) { pushDelete(STORES.stock, id); }

    for (const row of gunRows.filter(item => {
      const optionsMatch = Object.values(item.partOptions || {}).some(options => samePartNo(options?.original, oldNo)
        || ['alternatives', 'candidates'].some(field => (options?.[field] || []).some(value => samePartNo(value, oldNo))));
      const boldMatch = Object.values(item.boldParts || {}).some(values => (values || []).some(value => samePartNo(value, oldNo)));
      const sourceBoldMatch = (item.sourceBoldParts || []).some(values => (values || []).some(value => samePartNo(value, oldNo)));
      return optionsMatch || boldMatch || sourceBoldMatch;
    })) { pushPut('component_gun_rows', replacePartNumberMetadata(row, oldNo, newNo)); }
    for (const row of bins) {
      if (Array.isArray(row.pencilPartNumbers) && row.pencilPartNumbers.some(value => samePartNo(value, oldNo))) {
        pushPut(STORES.bins, { ...row, pencilPartNumbers: replacePartNumberList(row.pencilPartNumbers, oldNo, newNo), updatedAt: now });
      }
    }
    for (const row of partConfigs.filter(item => samePartNo(item.partNo, oldNo))) { pushPut(STORES.partConfigs, { ...row, partNo: newNo, updatedAt: now }); }
    for (const row of orders) {
      const updated = rewriteActivePartNumberFields(row, oldNo, newNo);
      if (JSON.stringify(updated) !== JSON.stringify(row)) { pushPut(STORES.orders, updated); }
    }
    const stockQuantityMoved = stockTransfers.reduce((total, item) => total + item.quantity, 0);
    const affectedMappings = cleanMappingUpdates.length;
    const summary = { correctionId, oldPartNo: oldNo, newPartNo: newNo, affectedMappings, affectedPartRecords: updatedParts.length, stockRowsMoved: stockRows.filter(stock => samePartNo(stock.partNo, oldNo)).length, stockQuantityMoved, stockTransfers };
    pushPut(STORES.audit, { id: uid('ca'), action: 'PART_NUMBER_CORRECTION', entity: 'Part No. Correction', entityId: correctionId, details: summary, timestamp: now, userId: currentUser.id || null, username: currentUser.username || currentUser.name || 'Unknown' });
    return { writes, summary };
  }
  async function correctPartNumberEverywhere(oldPartNo, newPartNo, options = {}) {
    if (typeof window.dPutMany !== 'function') { throw new Error('Atomic batch writes are unavailable; no Part No. correction was applied'); }
    const plan = buildPartNumberCorrectionPlan(oldPartNo, newPartNo, options);
    await window.dPutMany(plan.writes);
    if (typeof addAudit === 'function') {
      try { await addAudit('PART_NUMBER_CORRECTION', `Part No. Correction: ${plan.summary.oldPartNo} → ${plan.summary.newPartNo}`, 'COMPONENT_MANAGEMENT'); }
      catch (error) { console.error('Secondary audit sink failed after atomic Part No. correction', error); }
    }
    return plan.summary;
  }

  async function editMapping(id) {
    if (!canComponent('mapping')) {return;}
    const row = state.mappings.find(m => m.id === id);
    if (!row) {return;}
    const stationNo = await componentInputDialog('Edit Mapping — Station No.', 'Station No. (blank is allowed)', row.stationNo ?? '');
    if (stationNo === null) {return;}
    const gunReferenceNo = await componentInputDialog('Edit Mapping — Gun Reference No.', 'Gun Reference No. (blank is allowed)', row.gunReferenceNo ?? '');
    if (gunReferenceNo === null) {return;}
    const position = await componentInputDialog('Edit Mapping — Component Position', `Component position (${POSITIONS.join(', ')})`, row.position ?? '');
    if (position === null) {return;}
    if (!POSITIONS.includes(position)) {return toastMsg(`Position must be one of: ${POSITIONS.join(', ')}`, 'er');}
    const partNo = await componentInputDialog('Edit Mapping — Vendor Part No.', 'Vendor Part No. (must exist in Part Master; N/A remains N/A; blank remains blank)', row.partNo ?? '');
    if (partNo === null) {return;}
    const normalizedPartNo = vendorPartNo(partNo).trim();
    if (normalizedPartNo && !/^N\/?A$/i.test(normalizedPartNo) && !partByNo(normalizedPartNo)) {return toastMsg('Part No. not found in Part Master. Please create the Part Master record first.', 'er');}
    const proposedIdentity = mappingIdentity(String(stationNo), String(gunReferenceNo), position);
    const collision = state.mappings.find(item => item.id !== row.id && mappingIdentity(item.stationNo, item.gunReferenceNo, item.position) === proposedIdentity);
    if (collision) { return toastMsg(`A mapping already exists for ${stationNo || 'blank'} / ${gunReferenceNo || 'blank'} / ${position} (Part ${collision.partNo || 'blank'}). Edit or delete that row instead.`, 'er'); }
    const old = { ...row };
    const proposed = { stationNo: String(stationNo), gunReferenceNo: String(gunReferenceNo), position, partNo: normalizedPartNo };
    const changed = ['stationNo', 'gunReferenceNo', 'position', 'partNo'].some(field => String(old[field] ?? '') !== String(proposed[field] ?? ''));
    const partNumberChanged = validMappedPartNo(old.partNo) && validMappedPartNo(proposed.partNo) && partKey(old.partNo) !== partKey(proposed.partNo);
    if (changed && typeof confirm === 'function') {
      const affected = state.mappings.filter(item => sameStation(item.stationNo, old.stationNo) && String(item.gunReferenceNo || '') === String(old.gunReferenceNo || '')).length;
      const affectedParts = [...new Set([old.partNo, proposed.partNo].filter(validMappedPartNo))];
      const stockTotal = affectedParts.reduce((sum, part) => sum + state.stock.filter(stock => partKey(stock.partNo) === partKey(part)).reduce((qty, stock) => qty + Number(stock.quantity || 0), 0), 0);
      const historicalImpact = (state.historicalConsumption || []).filter(item => affectedParts.some(part => partKey(item.partNo || item.newPartNo) === partKey(part))).length;
      const impact = `\n\nImpact Preview\nStations/Guns affected: ${affected ? 1 : 0} station / ${affected ? 1 : 0} gun group\nParts whose forecast inputs may change: ${affectedParts.length} (${affectedParts.join(', ') || 'none'})\n${partNumberChanged ? `Part No. correction: ALL active mappings and the Part Master/stock rows for ${old.partNo} will be moved to ${proposed.partNo}; stock is preserved and merged by bin (current affected quantity: ${stockTotal}). Transaction/audit history will retain the original number.` : `Current stock changed by this edit: No (quantity is not modified); current quantity across affected Parts: ${stockTotal}`}\nHistorical analytics records using these Parts: ${historicalImpact}`;
      if (!confirm(`Confirm mapping change?${impact}\n\nOld: ${old.stationNo || '(blank)'} / ${old.gunReferenceNo || '(blank)'} / ${old.position || '(blank)'} / ${old.partNo || '(blank)'}\nNew: ${proposed.stationNo || '(blank)'} / ${proposed.gunReferenceNo || '(blank)'} / ${proposed.position || '(blank)'} / ${proposed.partNo || '(blank)'}`)) { return; }
    }
    if (partNumberChanged) {
      try {
        await correctPartNumberEverywhere(old.partNo, proposed.partNo, { mappingOverride: { id: row.id, ...proposed }, reason: 'Manual mapping Part No. correction' });
      } catch (error) { return toastMsg(error.message || 'Part No. correction failed; no changes were applied', 'er'); }
      await load();
      await migrateExistingRhLhCommonBins();
      await reconcileRhLhCommonBinReferences();
      await load();
      matrix();
      return toastMsg(`Part No. corrected globally: ${old.partNo} → ${proposed.partNo}; stock quantity preserved`, 'suc');
    }
    Object.assign(row, { ...proposed, updatedAt: nowIso() });
    await dPut(STORES.mappings, row);
    await dPut('component_mapping_revisions', { id: uid('rev'), mappingId: row.id, stationNo: row.stationNo, gunReferenceNo: row.gunReferenceNo, oldValue: old, newValue: { ...row }, reason: 'Manual mapping edit', changedAt: nowIso(), userId: user().id || null });
    await audit('COMPONENT_MAPPING_EDIT', 'Gun Matrix Mapping', row.id, { old, newValue: row });
    await load();
    await migrateExistingRhLhCommonBins();
    await reconcileRhLhCommonBinReferences();
    await load();
    matrix();
  }
  async function deleteMapping(id) {
    if (!canComponent('mapping')) {return;}
    const row = state.mappings.find(m => m.id === id);
    if (!row || (typeof confirm === 'function' && !confirm(`Delete mapping ${row.stationNo || 'blank'} / ${row.gunReferenceNo || 'blank'} / ${row.position}?`))) {return;}
    await dDel(STORES.mappings, id);
    state.mappings = state.mappings.filter(m => m.id !== id);
    await audit('COMPONENT_MAPPING_DELETE', 'Gun Matrix Mapping', id, { deleted: row });
    await rebuildGunCountAggregate();
    matrix();
  }
  async function deleteSelectedMappings() {
    if (!canComponent('mapping')) {return;}
    const selectedGroups = [...document.querySelectorAll('.cm-map-select:checked')].map(x => state.matrixGroups?.get(x.value));
    const ids = [...new Set(selectedGroups.flatMap(group => group?.ids || []).filter(Boolean))];
    const sourceOnlyGroups = selectedGroups.filter(group => group?.sourceOnly && !(group.ids || []).length);
    if (!ids.length && !sourceOnlyGroups.length) {return toastMsg('Select at least one mapping or source-only Gun row to delete', 'er');}
    if (typeof confirm === 'function' && !confirm(`Delete ${ids.length} mapping row(s) and ${sourceOnlyGroups.length} source-only Gun row(s)?`)) {return;}
    for (const id of ids) { const row = state.mappings.find(m => m.id === id); if (!row) {continue;} await dDel(STORES.mappings, id); await audit('COMPONENT_MAPPING_DELETE', 'Gun Matrix Mapping', id, { deleted: row }); }
    state.mappings = state.mappings.filter(m => !ids.includes(m.id));
    for (const group of sourceOnlyGroups) { const sourceSheets = new Set(group.sources || []); const sourceSerials = new Set(Array.from(group.srNos || []).map(String)); const matching = state.gunRows.filter(row => sourceSheets.has(String(row.sourceSheet || '')) && sourceSerials.has(String(row.sourceSrNo ?? row.srNo ?? row.sourceRow ?? '')) && String(row.stationNo || '') === String(group.stationNo || '') && String(row.gunReferenceNo || '') === String(group.gunReferenceNo || '')); for (const row of matching) { await dDel('component_gun_rows', row.id); await audit('COMPONENT_SOURCE_GUN_DELETE', 'Gun Register', row.id, {stationNo:row.stationNo, gunReferenceNo:row.gunReferenceNo, sourceSheet:row.sourceSheet, sourceRow:row.sourceRow}); } state.gunRows = state.gunRows.filter(row => !matching.some(item => item.id === row.id)); }
    await rebuildGunCountAggregate();
    matrix();
  }
  function importView() {
    const d = state.importDraft;
    const sheets = d?.sheetNames?.map(name => `<label class="fi"><input type="checkbox" class="cm-sheet-select" value="${esc(name)}" ${d.selectedSheets?.includes(name) ? 'checked' : ''}> ${esc(name)} (${d.sheetRows[name] || 0} rows)</label>`).join('') || '<p>Select a workbook to detect all worksheets.</p>';
    const headers = d?.headers || [];
    const mapping = d ? COLUMN_FIELDS.map(f => { const selected = d.columnMappings?.[f] || d.suggested?.[f] || ''; const options = headers.map(h => `<option value="${esc(h)}" ${String(h) === String(selected) ? 'selected' : ''}>${esc(h)}</option>`).join(''); return `<div class="fr"><label class="fl">${FIELD_LABELS[f]}${f === 'quantity' ? '' : ' *'}</label><select class="fi" id="cm-map-${f}"><option value="">— Not mapped —</option>${options}</select></div>`; }).join('') : '';
    const preview = d?.previewHtml || '';
    const hasActiveTrialImport = state.imports.some(i => String(i.mode || (i.trial ? 'TRIAL' : 'LEGACY')).toUpperCase() === 'TRIAL' && i.status !== 'DELETED');
    const historicalBatches = [...new Set((state.historicalConsumption || []).map(row => row.importBatchId).filter(Boolean))].map(batchId => { const rows = state.historicalConsumption.filter(row => row.importBatchId === batchId); const first = rows[0] || {}; return { importedAt: first.importedAt || first.date, sourceFile: first.sourceFile || 'Manual Entry', mode: 'HISTORICAL', status: 'COMMITTED', rowsScanned: rows.length, newCount: rows.length, updatedCount: 0, duplicateCount: 0, skippedCount: 0, warningCount: 0, batchId }; });
    const importHistory = [...historicalBatches, ...state.imports].map(i => { const mode = String(i.mode || (i.trial ? 'TRIAL' : 'LEGACY')).toUpperCase(); const isTrial = mode === 'TRIAL'; const isPermanent = mode === 'PERMANENT'; const historyOnly = btn('Remove History', `componentRemoveImportHistory('${esc(i.id)}')`); const actions = mode === 'HISTORICAL' ? `${btn('Delete Historical Batch', `componentDeleteHistoricalImportBatch('${esc(i.batchId || '')}')`)}` : isPermanent ? `<span data-style="color:var(--tx3);font-size:11px">🔒 Permanent — protected</span> ${historyOnly}` : i.status === 'DELETED' ? `<span data-style="color:var(--tx3);font-size:11px">Deleted</span> ${historyOnly}` : i.backupId && i.status !== 'ROLLED_BACK' ? `${btn('Preview Rollback', `componentPreviewImportRollback('${esc(i.backupId)}')`)} ${btn(isTrial ? 'Rollback Trial' : 'Rollback', `componentRollbackImport('${esc(i.backupId)}')`)} ${btn('Delete Import', `componentDeleteImport('${esc(i.id)}','${esc(i.backupId)}')`)}` : `${btn('Delete Import', `componentDeleteImport('${esc(i.id)}','')`)}`; return `<tr><td>${esc(i.importedAt)}</td><td>${esc(i.sourceFile)}</td><td><strong>${esc(mode)}</strong> · ${esc(i.status)}</td><td>${i.rowsScanned ?? i.importedRows ?? 0}</td><td>${i.newCount ?? 0}</td><td>${i.updatedCount ?? 0}</td><td>${i.duplicateCount ?? 0}</td><td>${i.skippedCount ?? 0}</td><td>${i.warningCount ?? 0}</td><td>${actions}</td></tr>`; }).join('');

    const body = `
      <div class="msp-wrap cm-import-wrap">
        <div class="card" data-style="margin-top:12px">
          <div class="card-hd">📥 Gun Matrix Import</div>
          <div class="alrt alrt-b">Import the Gun Matrix workbook, select the required sheets, map columns, review the dry-run, and then confirm the import.</div>
          <div class="btn-row">
            <label class="btn btn-p" data-style="cursor:pointer">📥 Select Excel / CSV
              <input type="file" id="cm-import-file-secondary" accept=".xlsx,.xls,.xlsm,.csv" data-style="display:none">
            </label>
            ${btn('Add New Gun Manually', 'componentOpenManualGunForm()')}
            ${btn('Download Import Template','componentDownloadTemplate()')}
          </div>
          <div id="cm-import-preview" data-style="margin-top:12px">
            ${d ? `<h4>Workbook: ${esc(d.fileName)}</h4><div class="g4">${sheets}</div><h4>Column Mapping</h4><div class="g4">${mapping}</div><div class="btn-row"><div class="cm-import-progress" aria-live="polite" style="margin:8px 0"><progress id="cm-import-progress-bar" max="100" value="0" style="width:260px"></progress><span id="cm-import-progress-text" style="margin-left:8px">Ready</span></div>${btn('Build Import Preview', 'componentBuildImportPreview()', true)}${btn('Cancel Processing', 'componentCancelImportProcessing()')}<label class="fi" data-style="display:flex;align-items:center;gap:8px;cursor:pointer;border:1px solid var(--b1);padding:8px 10px"><input type="checkbox" id="cm-trial-import" ${d.trial ? 'checked' : ''} onchange="componentSetImportTrial(this.checked)"><strong>${d.manualEntry ? 'Manual Add' : 'Trial Import'}</strong><span data-style="font-size:10px;color:var(--tx3)">Rollback/Delete removes the complete import state</span></label>${btn(d.manualEntry ? 'Save Manual Gun' : d.trial ? 'Commit Trial Import' : 'Commit Permanent Import', 'componentCommitImport()', true)}${d.backupId ? btn('Preview Rollback', `componentPreviewImportRollback('${esc(d.backupId)}')`) : ''}</div>${preview}` : '<div data-style="text-align:center;padding:28px 20px;color:var(--tx3)"><div data-style="font-size:34px;margin-bottom:10px">📥</div><div data-style="font-size:14px;font-weight:700;color:var(--tx2);margin-bottom:6px">No workbook selected</div><div data-style="font-size:11px">Click <strong>Import</strong> above or select an Excel / CSV file to begin.</div></div>'}
          </div>
        </div>

        <div class="card" id="cm-data-management" data-style="margin-top:12px">
          <div class="card-hd">▣ Data Management
            <span data-style="margin-left:auto;font-size:10px;color:var(--tx3);font-weight:400">Import History & Rollback</span>
          </div>
          <div class="btn-row" data-style="margin-bottom:10px">
            <button class="btn btn-s" data-onclick="componentDownloadTemplate()">📄 Download Template</button>
            <button class="btn btn-d" data-onclick="componentResetShankMappingData()" ${hasActiveTrialImport ? '' : 'disabled'} title="${hasActiveTrialImport ? 'Clear trial Shank Mapping data' : 'Enabled only after a Trial Import'}">🗑️ Clear All Shank Mapping Test Data</button>
          </div>
          <div class="alrt alrt-w" data-style="font-size:11px">This removes all Shank Mapping data only, including imports, mappings, Parts Master, bins, stock, transactions, replacements, repair/scrap, analytics and procurement records. Other StoreTrack modules are not affected.</div>
          ${table(['Import Date', 'File', 'Status', 'Rows Scanned', 'New', 'Updated', 'Duplicate', 'Skipped', 'Warnings', 'Action'], importHistory, 'No imports yet.')}
        </div>
      </div>`;

    shell('Shank Mapping — Import / Data Management', body);
    document.getElementById('cm-import-file')?.addEventListener('change', readImportFile);
    document.getElementById('cm-import-file-secondary')?.addEventListener('change', readImportFile);
  }

  let pendingImport = null;
  let importPreviewSearchTimer = null;
  const IMPORT_PREVIEW_PAGE_SIZE = 100;
  function openManualGunForm() {
    if (!canComponent('import', true)) {return;}
    if (pendingImport?.fileName && !confirm('Discard the current uncommitted import draft and open Manual New Gun?')) {return;}
    const overlay = document.createElement('div');
    // Keep the overlay separate from the dialog. Applying `.modal` to the
    // overlay itself constrained the whole Gun form to the generic 560px width.
    overlay.className = 'ov on';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    const fields = [
      ['fixShank', 'Fix Shank'], ['movingShank', 'Moving Shank'], ['fixAdaptor', 'Fix Adaptor'],
      ['movingAdaptor', 'Moving Adaptor'], ['fixHolder', 'Fix Holder'], ['movingHolder', 'Moving Holder'],
      ['pencilShank', 'Pencil Shank']
    ];
    overlay.innerHTML = `<div class="modal cm-manual-gun-modal" role="dialog" aria-labelledby="cm-manual-gun-title"><div class="modal-hd" id="cm-manual-gun-title">Add Newly Added Gun Manually</div><div class="modal-body"><div class="alrt alrt-b">This form uses the same Newly Added Guns columns, quantity rules, preview, validation, and commit logic as Excel import. Max Qty becomes Required Qty; if blank, the import's Quantity × 2 fallback applies. The separate Pencil Shank field is retained as source data exactly like Excel; the existing importer creates mappings from the six Shank/Adaptor/Holder fields. Leave component fields blank if the Gun is not mapped yet; no stock quantity will be added.</div><form id="cm-manual-gun-form"><div class="g3"><div class="fr"><label class="fl" for="cm-manual-station">Station No. *</label><input class="fi" id="cm-manual-station" required maxlength="120" autocomplete="off"></div><div class="fr"><label class="fl" for="cm-manual-gun">Gun Reference No. *</label><input class="fi" id="cm-manual-gun" required maxlength="120" autocomplete="off"></div><div class="fr"><label class="fl" for="cm-manual-quantity">Quantity</label><input class="fi" id="cm-manual-quantity" type="number" min="1" step="1" value="1"></div><div class="fr"><label class="fl" for="cm-manual-max-qty">Max Qty / Required Qty</label><input class="fi" id="cm-manual-max-qty" type="number" min="1" step="1" placeholder="Optional"></div>${fields.map(([field, label]) => `<div class="fr"><label class="fl" for="cm-manual-${field}">${esc(label)} Part No.</label><input class="fi" id="cm-manual-${field}" maxlength="300" autocomplete="off" placeholder="Optional; separate alternatives with commas"></div>`).join('')}</div><div class="alrt alrt-y"><strong>Duplicate check:</strong> If this Station + Gun already exists, select the checkbox only when this is a distinct physical source occurrence. Current canonical Gun counts may treat identical Station + Gun references as one.</div><label class="fi" style="display:flex;align-items:flex-start;gap:8px;margin-top:10px"><input type="checkbox" id="cm-manual-duplicate-confirm"><span>This is a separate physical Gun occurrence, even if its Station + Gun reference already exists.</span></label><div class="modal-actions"><button class="btn btn-p" type="submit">Review Manual Gun</button><button class="btn" type="button" id="cm-manual-cancel">Cancel</button></div></form></div></div>`;
    document.body.appendChild(overlay);
    const close = () => overlay.remove();
    overlay.querySelector('#cm-manual-cancel')?.addEventListener('click', close);
    overlay.addEventListener('click', event => { if (event.target === overlay) {close();} });
    overlay.querySelector('#cm-manual-gun-form')?.addEventListener('submit', event => {
      event.preventDefault();
      if (!canComponent('import', true)) {return;}
      const stationNo = canonicalStation(overlay.querySelector('#cm-manual-station')?.value);
      const gunReferenceNo = String(overlay.querySelector('#cm-manual-gun')?.value || '').trim();
      const quantityText = String(overlay.querySelector('#cm-manual-quantity')?.value || '').trim();
      const maxQtyText = String(overlay.querySelector('#cm-manual-max-qty')?.value || '').trim();
      const quantity = quantityText ? numericQty(quantityText) : 1;
      if (!stationNo || !gunReferenceNo) {return toastMsg('Station No. and Gun Reference No. are required', 'er');}
      if (!quantity) {return toastMsg('Quantity must be a number greater than zero', 'er');}
      if (maxQtyText && !numericQty(maxQtyText)) {return toastMsg('Max Qty / Required Qty must be a number greater than zero', 'er');}
      const duplicateRows = (state.gunRows || []).filter(row => sameStation(row.stationNo, stationNo) && normalGunReference(row.gunReferenceNo) === normalGunReference(gunReferenceNo));
      const duplicateMappings = (state.mappings || []).filter(row => sameStation(row.stationNo, stationNo) && normalGunReference(row.gunReferenceNo) === normalGunReference(gunReferenceNo));
      const duplicateCount = duplicateRows.length || (duplicateMappings.length ? 1 : 0);
      const duplicateConfirmed = Boolean(overlay.querySelector('#cm-manual-duplicate-confirm')?.checked);
      if (duplicateCount && !duplicateConfirmed) {return toastMsg('This Station + Gun already exists. Confirm that this is a separate physical occurrence, or cancel and edit the existing mapping.', 'er');}
      const duplicateWarning = duplicateCount ? `Existing Station + Gun match found (${duplicateCount} row(s)); manually confirmed as a separate source occurrence. Canonical counts may still deduplicate identical Station + Gun references.` : '';
      if (duplicateWarning && !confirm(`${duplicateWarning}\n\nContinue to preview this as a separate source occurrence?`)) {return;}
      const headers = ['Station No.', 'Gun Reference No.', 'Quantity', 'Max Qty', 'Fix Shank', 'Moving Shank', 'Fix Adaptor', 'Moving Adaptor', 'Fix Holder', 'Moving Holder', 'Pencil Shank'];
      const partFields = ['fixShank', 'movingShank', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder', 'pencilShank'];
      const values = [stationNo, gunReferenceNo, String(quantity), maxQtyText, ...partFields.map(field => String(overlay.querySelector(`#cm-manual-${field}`)?.value || '').trim())];
      const sheetName = 'Newly Added Guns';
      const fileName = `MANUAL-New-Gun-${Date.now()}-${uid('entry')}`;
      const suggested = Object.fromEntries(COLUMN_FIELDS.map(field => [field, headers.find(header => likelyField(header, field)) || '']));
      pendingImport = {
        fileName, sheetNames: [sheetName], sheetRows: { [sheetName]: 1 },
        rawSheets: { [sheetName]: [headers, values] }, boldSheets: { [sheetName]: [headers.map(() => []), values.map(() => [])] },
        boldAware: false, sheetMeta: { [sheetName]: { headerRow: 0, dataStart: 1, headers, score: COLUMN_FIELDS.length } },
        headers, selectedSheets: [sheetName], suggested, previewHtml: '', confirmed: false, backupId: null,
        trial: false, importMode: 'MANUAL', manualEntry: true, manualDuplicateWarning: duplicateWarning,
        serialBase: 0, skipped: [], warnings: [], sourceOnlyCount: 0, sourceGunRows: 1, componentMappingRows: 0
      };
      state.importDraft = pendingImport;
      close();
      importView();
      setTimeout(() => { if (pendingImport?.manualEntry && pendingImport.fileName === fileName) { componentBuildImportPreview(); } }, 0);
    });
    overlay.querySelector('#cm-manual-station')?.focus();
  }
  const COMPONENT_IMPORT_DATA_STORES = [STORES.parts, STORES.mappings, 'component_gun_rows', STORES.bins, STORES.stock, STORES.tx, STORES.repair, STORES.aliases, STORES.replacements, STORES.historicalConsumption, STORES.monthCloses, ALLOCATION_BATCH_STORE, 'component_label_versions', STORES.gunCounts];
  function importPreviewPageHtml(total, page, size = IMPORT_PREVIEW_PAGE_SIZE, totalRows = total) { const pages = Math.max(1, Math.ceil(total / size)); const current = Math.min(Math.max(0, Number(page) || 0), pages - 1); const controls = []; if (current > 0) { controls.push(btn('Previous', `componentPreviewPage(${current - 1})`)); } const countLabel = total === totalRows ? `${total} rows retained` : `${total} matching; ${totalRows} total rows retained`; controls.push(`<span class="fi">Page ${current + 1} of ${pages} (${countLabel})</span>`); if (current < pages - 1) { controls.push(btn('Next', `componentPreviewPage(${current + 1})`)); } return `<div class="btn-row cm-import-pager">${controls.join(' ')}</div>`; }
  const IMPORT_PREVIEW_COLUMNS = [['SR No.', 'srNo'], ['Excel Row Order', 'sourceOrder'], ['Status', 'status'], ['Station No.', 'stationNo'], ['Gun Reference No.', 'gunReferenceNo'], ['Quantity', 'quantity'], ['Quantity Source', 'quantitySource'], ['Required Qty', 'requiredQty'], ['Source Sheet', 'sourceSheet'], ['Source Row', 'sourceRow'], ['Fix Shank', 'fixShank'], ['Moving Shank', 'movingShank'], ['Fix Adaptor', 'fixAdaptor'], ['Moving Adaptor', 'movingAdaptor'], ['Fix Holder', 'fixHolder'], ['Moving Holder', 'movingHolder'], ['Pencil Shank', 'pencilShank'], ['Complete Source Data', 'sourceData']];
  const IMPORT_PREVIEW_EDITABLE_FIELDS = new Set(['stationNo', 'gunReferenceNo', 'quantity', 'fixShank', 'movingShank', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder', 'pencilShank']);
  const IMPORT_PREVIEW_SEARCH_FIELDS = [{ key: 'stationNo', label: 'Station', fields: ['stationNo'] }, { key: 'partNo', label: 'Part No. (all components)', fields: MAPPED_PART_FIELDS }, { key: 'gunReferenceNo', label: 'Gun Reference', fields: ['gunReferenceNo'] }, { key: 'fixAdaptor', label: 'Fix Adaptor', fields: ['fixAdaptor'] }, { key: 'movingAdaptor', label: 'Moving Adaptor', fields: ['movingAdaptor'] }, { key: 'fixHolder', label: 'Fix Holder', fields: ['fixHolder'] }, { key: 'movingHolder', label: 'Moving Holder', fields: ['movingHolder'] }, { key: 'fixShank', label: 'Fix Shank', fields: ['fixShank'] }, { key: 'movingShank', label: 'Moving Shank', fields: ['movingShank'] }, { key: 'pencilShank', label: 'Pencil Shank', fields: ['pencilShank'] }];
  function hiddenImportPreviewHeader(header) { return /x\s*[-_]?\s*gun|c\s*[-_]?\s*gun|gun\s*(qty|quantity)|quantity\s*\(optional\)|qty\s*source/i.test(String(header || '')); }
  function importPreviewSourceData(r) { return (r.sourceHeaders || []).map((header, index) => hiddenImportPreviewHeader(header) ? '' : `${header || `Column ${index + 1}`}: ${vendorPartNo((r.sourceValues || [])[index])}`).filter(Boolean).join(' | '); }
  function importPreviewSourceDataCell(r) { return `<details class="cm-source-details"><summary>View source component fields</summary><div>${esc(importPreviewSourceData(r))}</div></details>`; }
  function importPreviewSearchControls() { const filters = pendingImport?.previewFilters || {}; const matches = importPreviewFilteredRows().length; return `<div class="g4 cm-filter-bar cm-import-preview-search">${IMPORT_PREVIEW_SEARCH_FIELDS.map(field => `<div class="fr"><label class="fl" for="cm-import-preview-search-${field.key}">Search ${esc(field.label)}</label><input class="fi cm-import-preview-filter" id="cm-import-preview-search-${field.key}" data-search-field="${field.key}" value="${esc(filters[field.key] || '')}" placeholder="Search ${esc(field.label)}"></div>`).join('')}<div class="btn-row"><button class="btn" type="button" data-import-preview-search-clear>Clear Search</button><span class="muted">Showing ${matches} of ${pendingImport?.rows?.length || 0}</span></div></div>`; }
  function importPreviewFilteredRows() { if (!pendingImport?.rows) { return []; } const filters = pendingImport.previewFilters || {}; return pendingImport.rows.map((row, index) => ({ row, index })).filter(({ row }) => IMPORT_PREVIEW_SEARCH_FIELDS.every(field => { const query = String(filters[field.key] || '').trim().toLowerCase(); return !query || field.fields.some(key => String(row[key] || '').toLowerCase().includes(query)); })); }
  function renderImportPreviewPage() { if (!pendingImport?.rows) { return ''; } const matchingRows = importPreviewFilteredRows(); const pageSize = IMPORT_PREVIEW_PAGE_SIZE; const page = Math.min(Math.max(0, Number(pendingImport.previewPage) || 0), Math.max(0, Math.ceil(matchingRows.length / pageSize) - 1)); pendingImport.previewPage = page; const pageStart = page * pageSize; const previewRows = matchingRows.slice(pageStart, pageStart + pageSize).map(({ row, index: rowIndex }) => `<tr>${IMPORT_PREVIEW_COLUMNS.map(([, field]) => `<td>${IMPORT_PREVIEW_EDITABLE_FIELDS.has(field) && !pendingImport.manualEntry ? `<input class="fi cm-import-edit" data-row="${rowIndex}" data-field="${field}" value="${esc(row[field])}" ${field === 'quantity' ? 'type="number" min="1"' : ''}>` : field === 'sourceData' ? importPreviewSourceDataCell(row) : esc(row[field])}</td>`).join('')}</tr>`).join(''); const headers = IMPORT_PREVIEW_COLUMNS.map(([label]) => label); const pager = importPreviewPageHtml(matchingRows.length, page, pageSize, pendingImport.rows.length); return `${pager}${table(headers, previewRows, 'No matching rows.')}${pager}`; }
  function filterImportPreview(root = document) { if (!pendingImport?.rows) { return; } captureImportPreviewEdits(root); pendingImport.previewFilters = Object.fromEntries([...root.querySelectorAll('.cm-import-preview-filter')].map(input => [input.dataset.searchField, String(input.value || '').trim()])); pendingImport.previewPage = 0; const count = importPreviewFilteredRows().length; const summary = root.querySelector('.cm-import-preview-search .muted'); if (summary) { summary.textContent = `Showing ${count} of ${pendingImport.rows.length}`; } const content = root.querySelector('#cm-import-preview-table-content') || document.getElementById('cm-import-preview-table-content'); if (content) { content.innerHTML = renderImportPreviewPage(); } }
  function chooseImport() { document.getElementById('cm-import-file')?.click(); }
  function workbookFileText(file) { if (!file) {return '';} if (typeof file === 'string') {return file;} const bytes = file instanceof Uint8Array ? file : file.content instanceof Uint8Array ? file.content : null; return bytes ? new TextDecoder().decode(bytes) : ''; }
  function boldStyleCells(workbook, sheetIndex) {
    const out = new Set(); const styles = workbookFileText(workbook.files?.['xl/styles.xml']); const sheet = workbookFileText(workbook.files?.[`xl/worksheets/sheet${sheetIndex + 1}.xml`]); if (!styles || !sheet || typeof DOMParser === 'undefined') {return out;}
    const styleDoc = new DOMParser().parseFromString(styles, 'application/xml'); const sheetDoc = new DOMParser().parseFromString(sheet, 'application/xml');
    const fonts = [...styleDoc.getElementsByTagNameNS('*', 'font')]; const boldFonts = new Set(fonts.map((font, index) => [...font.childNodes].some(node => node.nodeType === 1 && (node.localName || node.nodeName) === 'b') ? index : -1).filter(index => index >= 0));
    const cellXfs = [...styleDoc.getElementsByTagNameNS('*', 'cellXfs')][0]; const boldStyles = new Set(); if (cellXfs) {[...cellXfs.childNodes].filter(node => node.nodeType === 1 && (node.localName || node.nodeName) === 'xf').forEach((xf, index) => {if (boldFonts.has(Number(xf.getAttribute('fontId') || 0))) {boldStyles.add(index);}});}
    [...sheetDoc.getElementsByTagNameNS('*', 'c')].forEach(cell => {if (boldStyles.has(Number(cell.getAttribute('s') || 0))) {out.add(cell.getAttribute('r'));}}); return out;
  }
  async function readImportFile(event) {
    if (!canComponent('import', true)) {return;}
    const file = event.target.files?.[0];
    const parser = getXlsxParser();
    if (!file || !parser || typeof parser.read !== 'function' || !parser.utils?.sheet_to_json) {return toastMsg('XLSX parser is unavailable. Restart the application or reinstall the bundled parser.', 'er');}
    const data = await file.arrayBuffer(); const wb = parser.read(data, { type: 'array', cellHTML: true, cellStyles: true, cellNF: true, bookFiles: true });
    const sheetRows = {}; const rawSheets = {}; const boldSheets = {}; const sheetMeta = {}; const headerSet = new Set();
    wb.SheetNames.forEach((sheetName, sheetIndex) => { const worksheet = wb.Sheets[sheetName]; const rows = parser.utils.sheet_to_json(worksheet, { header: 1, defval: '', raw: false }); const meta = detectHeaderInfo(rows); const boldCells = boldStyleCells(wb, sheetIndex); const boldRows = rows.map((row, rowIndex) => row.map((_, columnIndex) => { const address = parser.utils.encode_cell({ r: rowIndex, c: columnIndex }); return boldPartsFromCell(worksheet[address], boldCells.has(address)); })); rawSheets[sheetName] = rows; boldSheets[sheetName] = boldRows; sheetMeta[sheetName] = meta; sheetRows[sheetName] = Math.max(0, rows.length - meta.dataStart); meta.headers.filter(Boolean).forEach(h => headerSet.add(String(h).trim())); });
    const headers = [...headerSet].filter(Boolean);
    const suggested = Object.fromEntries(COLUMN_FIELDS.map(field => [field, headers.find(h => likelyField(h, field)) || '']));
    pendingImport = { fileName: file.name, sheetNames: wb.SheetNames, sheetRows, rawSheets, boldSheets, boldAware: /\.(xlsx|xlsm|xls)$/i.test(file.name), sheetMeta, headers, selectedSheets: [...wb.SheetNames], suggested, previewHtml: '', confirmed: false, backupId: null, trial: false, importMode: 'PERMANENT', serialBase: 0 };
    state.importDraft = pendingImport; importView();
  }
  async function componentBuildImportPreview() {
    const rowHasContent = values => (values || []).some(value => String(value == null ? '' : value).trim() !== '');
    const rowLooksLikeHeader = (values, headers) => {
      // A data Gun Reference may legitimately contain "X GUN" or "C GUN".
      // Do not discard a row because one cell matches the quantity aliases; a repeated
      // header row has multiple header-like cells.
      const matches = (values || []).filter(cell => COLUMN_FIELDS.some(field => likelyField(cell, field))).length;
      return matches >= 2;
    };
    if (!pendingImport || !canComponent('import', true)) {return;}
    pendingImport.selectedSheets = [...document.querySelectorAll('.cm-sheet-select:checked')].map(x => x.value);
    const mappings = Object.fromEntries(COLUMN_FIELDS.map(f => [f, val(`cm-map-${f}`) || pendingImport.suggested[f] || '']));
    // Continue the Gun Mapping serial number across workbook imports. Use the
    // highest persisted serial rather than array length so deleted/duplicate
    // rows cannot cause a later import to restart at 1 or reuse a number.
    const persistedGunSerials = [...(state.gunRows || []), ...(state.mappings || [])]
      .map(record => Number(record.srNo ?? record.sourceSrNo))
      .filter(number => Number.isFinite(number) && number > 0);
    const existingGunSerialBase = persistedGunSerials.length ? Math.max(...persistedGunSerials) : 0;
    pendingImport.columnMappings = mappings; pendingImport.rows = []; pendingImport.serialBase = existingGunSerialBase; pendingImport.sourceOnlyCount = 0; pendingImport.warnings = []; pendingImport.skipped = []; pendingImport.cancelled = false; pendingImport.progress = 0;
    pendingImport.warnings.push(existingGunSerialBase ? `New Gun rows will continue after SR No. ${existingGunSerialBase}; Excel row order is preserved.` : 'First import: Excel row order will be preserved and SR No. will start at 1.');
    const missing = { stationNo: 0, gunReferenceNo: 0, fixShank: 0, movingShank: 0 }; for (const sheetName of pendingImport.selectedSheets) { const matrix = pendingImport.rawSheets[sheetName] || []; const boldMatrix = pendingImport.boldSheets?.[sheetName] || []; const meta = pendingImport.sheetMeta?.[sheetName] || detectHeaderInfo(matrix); const headers = meta.headers || []; const idx = Object.fromEntries(COLUMN_FIELDS.map(f => [f, resolveSheetColumn(headers, f, mappings[f])])); let previousStation = ''; const hasStationColumn = idx.stationNo >= 0; const hasGunColumn = idx.gunReferenceNo >= 0; const dataRows = matrix.slice(meta.dataStart); for (let dataIndex = 0; dataIndex < dataRows.length; dataIndex += 1) { const values = dataRows[dataIndex]; const boldValues = boldMatrix[meta.dataStart + dataIndex] || []; const index = dataIndex; if (pendingImport.cancelled) {break;} const sourceRow = meta.dataStart + index + 1; if (!rowHasContent(values) || !pendingImport.manualEntry && rowLooksLikeHeader(values, headers)) { continue; } const fieldValue = (field, preserveRaw = false) => {
        const preferred = idx[field];
        const valueAt = column => column >= 0 && column < values.length ? (preserveRaw ? vendorPartNo(values[column]) : String(values[column] == null ? '' : values[column]).trim()) : '';
        const preferredValue = valueAt(preferred);
        if (preferredValue !== '') {return preferredValue;}
        // A workbook may expose the same logical field under Fixed/Fix or Mov./Moving headers.
        // If a manually selected global header is absent or points to an empty column on this sheet,
        // resolve the field again against this sheet's own headers without dropping source data.
        const fallbackColumns = headers.map((header, column) => ({ header, column }))
          .filter(candidate => candidate.column !== preferred && likelyField(candidate.header, field))
          .sort((a, b) => {
            const aKey = fieldKey(a.header); const bKey = fieldKey(b.header);
            const target = fieldKey(FIELD_LABELS[field] || field);
            return Number(bKey === target) - Number(aKey === target);
          });
        for (const candidate of fallbackColumns) {
          const fallbackValue = valueAt(candidate.column);
          if (fallbackValue !== '') {return fallbackValue;}
        }
        return preferredValue;
      };
      const get = f => fieldValue(f, false);
      const boldValueFor = field => { const preferred = idx[field]; return preferred >= 0 && Array.isArray(boldValues[preferred]) ? boldValues[preferred] : []; }; const selectedValueFor = field => { const preferred = idx[field]; const raw = preferred >= 0 ? splitBoldPartText(values[preferred]) : splitBoldPartText(fieldValue(field, true)); if (!MAPPED_PART_FIELDS.includes(field) || raw.length <= 1) {return raw;} return boldValueFor(field); }; const getPart = f => selectedValueFor(f).join(' / '); const partOptionsFor = field => { const preferred = idx[field]; const raw = preferred >= 0 ? splitBoldPartText(values[preferred]) : splitBoldPartText(fieldValue(field, true)); const bold = boldValueFor(field).filter(validMappedPartNo); const original = bold[0] || ''; const alternatives = bold.length ? raw.filter(part => !bold.some(candidate => samePartNo(candidate, part))) : []; const candidates = [...new Set([...bold, ...raw])]; return { original, alternatives, candidates }; };
      const rawStation = canonicalStation(get('stationNo')); const station = rawStation || previousStation; if (station) {previousStation = station;} const gun = get('gunReferenceNo'); const quantity = derivedGunQuantity(values, headers, idx.quantity); const requiredQty = derivedRequiredQuantity(values, headers, quantity, sheetName); const sourceOrder = pendingImport.rows.length + 1; const assignedSerial = Number(pendingImport.serialBase || 0) + sourceOrder; const row = { srNo: assignedSerial, sourceOrder, stationNo: station || 'Station Not Assigned', gunReferenceNo: gun || `Unassigned Row ${sourceRow}`, quantity, quantitySource: quantitySource(values, headers, sheetName), requiredQty, fixShank: getPart('fixShank'), movingShank: getPart('movingShank'), fixAdaptor: getPart('fixAdaptor'), movingAdaptor: getPart('movingAdaptor'), fixHolder: getPart('fixHolder'), movingHolder: getPart('movingHolder'), pencilShank: getPart('pencilShank'), boldParts: Object.fromEntries(MAPPED_PART_FIELDS.map(field => [field, selectedValueFor(field)])), partOptions: Object.fromEntries(MAPPED_PART_FIELDS.map(field => [field, partOptionsFor(field)])), sourceBoldParts: boldValues, sourceSheet: sheetName, sourceRow, sourceHeaders: headers.slice(), sourceValues: values.slice() }; if (!station && hasStationColumn) {missing.stationNo++;} if (!gun && hasGunColumn) {missing.gunReferenceNo++;} if (!row.fixShank) {missing.fixShank++;} if (!row.movingShank) {missing.movingShank++;} row.sourceOnly = !GUN_COUNT_COMPONENT_FIELDS.some(field => validMappedPartNo(row[field])); if (row.sourceOnly) { pendingImport.sourceOnlyCount = Number(pendingImport.sourceOnlyCount || 0) + 1; } row.status = row.stationNo === 'Station Not Assigned' ? 'Station Pending' : row.sourceOnly ? 'Missing Component' : 'Ready for Mapping'; pendingImport.rows.push(row); if (pendingImport.rows.length % 200 === 0) { pendingImport.progress = Math.round((pendingImport.rows.length / Math.max(1, pendingImport.rows.length + dataRows.length - dataIndex)) * 100); const progressBar = document.getElementById('cm-import-progress-bar'); const progressText = document.getElementById('cm-import-progress-text'); if (progressBar) {progressBar.value = pendingImport.progress;} if (progressText) {progressText.textContent = `Parsing ${pendingImport.progress}% (${pendingImport.rows.length} rows)`;} await perfTools.yieldToUi(); } } if (pendingImport.cancelled) {break;} }
    pendingImport.sourceGunRows = pendingImport.rows.filter(r => !r.sourceOnly).length;
    pendingImport.componentMappingRows = pendingImport.sourceGunRows;
    pendingImport.invalidRows = pendingImport.skipped.length;
    pendingImport.reconciliation = { sourceGunRows: pendingImport.sourceGunRows, importedGunRows: pendingImport.sourceGunRows, retainedSourceRows: pendingImport.rows.length, duplicateSourceRows: 0, invalidRows: pendingImport.invalidRows, balanced: pendingImport.sourceGunRows === pendingImport.componentMappingRows };
    if (pendingImport.manualEntry) { const manualRow = pendingImport.rows[0]; const mappedPositions = componentPairsForRow(manualRow).length; pendingImport.sourceGunRows = manualRow?.sourceOnly ? 0 : 1; pendingImport.componentMappingRows = pendingImport.sourceGunRows; pendingImport.sourceOnlyCount = manualRow?.sourceOnly ? 1 : 0; pendingImport.reconciliation = { sourceGunRows: 1, mappedGunRows: pendingImport.sourceGunRows, retainedSourceRows: 1, duplicateSourceRows: 0, invalidRows: 0, balanced: !manualRow?.sourceOnly }; pendingImport.manualMappedPositionCount = mappedPositions; }
    const allPreviewHeaders = [...new Set(pendingImport.selectedSheets.flatMap(s => pendingImport.sheetMeta?.[s]?.headers || []))];
    const possibleStations = [...new Set(pendingImport.rows.map(r => r.stationNo).filter(s => s !== 'Station Not Assigned').flatMap(station => [...state.bins.map(b => b.stationNo), ...state.mappings.map(m => m.stationNo)].filter(existing => existing && existing !== station && normalStation(existing) === normalStation(station)).map(existing => `${station} may match existing Station ${existing}`)))];
    const ignoredHeaders = [...new Set(allPreviewHeaders.filter(h => /fixed?electrode|mov\.?\s*electrode/i.test(String(h))))]; const ignoredWarnings = ignoredHeaders.map(h => `Ignored unsupported component column: ${h}`); const maxQtyNotice = pendingImport.selectedSheets.some(s => fieldKey(s).includes('newlyaddedguns')) ? ['Newly Added Guns: Max Qty is applied per imported source row; repeated rows are aggregated separately.'] : []; pendingImport.warnings = [...possibleStations.map(w => `${w} — explicit decision required before creating a new Station/Bin`), ...ignoredWarnings, ...maxQtyNotice]; pendingImport.stationVariations = possibleStations; if (pendingImport.manualEntry && pendingImport.manualDuplicateWarning) { pendingImport.warnings.push(pendingImport.manualDuplicateWarning); } const existing = pendingImport.rows.reduce((n, r) => n + state.mappings.filter(m => m.stationNo === r.stationNo && m.gunReferenceNo === r.gunReferenceNo).length, 0);
    const finalProgressBar = document.getElementById('cm-import-progress-bar'); const finalProgressText = document.getElementById('cm-import-progress-text'); if (finalProgressBar) {finalProgressBar.value = 100;} if (finalProgressText) {finalProgressText.textContent = pendingImport.cancelled ? 'Cancelled' : `Complete — ${pendingImport.rows.length} rows`;}
    pendingImport.previewHtml = `<div class="alrt ${pendingImport.warnings.length ? 'alrt-y' : 'alrt-b'}"><strong>Dry Run</strong><br>Workbook: ${esc(pendingImport.fileName)}<br>Selected sheets: ${esc(pendingImport.selectedSheets.join(', '))}<br>Rows Scanned: ${pendingImport.rows.length + pendingImport.skipped.length} | Eligible Gun Count: ${pendingImport.sourceGunRows || pendingImport.rows.filter(r => !r.sourceOnly).length} | Component Mapping Rows: ${pendingImport.componentMappingRows || pendingImport.rows.filter(r => !r.sourceOnly).length} | Source-only / Excluded: ${pendingImport.sourceOnlyCount || 0} | Invalid/Skipped: ${pendingImport.invalidRows || pendingImport.skipped.length} | Potential Existing: ${existing} | Warnings: ${pendingImport.warnings.length}<br>Gun Count Reconciliation: ${pendingImport.reconciliation?.balanced ? 'BALANCED' : 'REVIEW REQUIRED'} (${pendingImport.sourceGunRows || pendingImport.rows.filter(r => !r.sourceOnly).length} eligible rows; ${pendingImport.sourceOnlyCount || 0} blank-component rows excluded)<br>Missing Station No.: ${missing.stationNo} | Missing Gun Reference: ${missing.gunReferenceNo} | Missing Fix Shank: ${missing.fixShank} | Missing Moving Shank: ${missing.movingShank}<br><strong>Import Mode:</strong> ${pendingImport.manualEntry ? 'MANUAL — this Gun uses the shared import logic and can be rolled back from Import History.' : pendingImport.trial ? 'TRIAL — rollback/delete will restore the exact pre-import state.' : 'PERMANENT — this import will be protected from rollback/delete.'}<br><strong>${pendingImport.manualEntry ? 'Read-only manual preview:' : 'Editable preview:'}</strong> ${pendingImport.manualEntry ? 'confirm the fields below before commit.' : 'review Station decisions and row-ending quantities before commit.'}</div><div class="cm-import-preview-table" style="max-height:70vh;overflow:auto">${pendingImport.manualEntry ? '' : `<div class="btn-row">${btn('Apply Preview Edits', 'componentApplyImportPreviewEdits()', true)}</div>`}${importPreviewSearchControls()}<div id="cm-import-preview-table-content">${renderImportPreviewPage()}</div></div>`; if (pendingImport.manualEntry) { const mappedCount = Number(pendingImport.manualMappedPositionCount || 0); const sourceOnly = Boolean(pendingImport.rows[0]?.sourceOnly); const duplicateNotice = pendingImport.manualDuplicateWarning ? `<div class="alrt alrt-y">${esc(pendingImport.manualDuplicateWarning)}</div>` : ''; pendingImport.previewHtml = `<div class="alrt ${sourceOnly ? 'alrt-y' : 'alrt-b'}"><strong>Manual New Gun review</strong><br>Total source Gun rows: 1 | Eligible for mapping: ${sourceOnly ? 0 : 1} | Component positions: ${mappedCount}<br>Status: ${sourceOnly ? 'Source-only / Mapping Pending' : 'Ready for Mapping'} | Quantity: ${esc(pendingImport.rows[0]?.quantity)} | Required Qty: ${esc(pendingImport.rows[0]?.requiredQty)}<br>${sourceOnly ? 'No component mapping or component label will be created until parts are assigned.' : 'The same Bin, mapping, zero-stock, Required Qty, label, and BI logic as Excel import will apply.'} Stock quantity will not be increased.</div>${duplicateNotice}` + pendingImport.previewHtml; } pendingImport.confirmed = false; state.importDraft = pendingImport; importView();
  }
  async function snapshotBeforeImport() {
    const mode = String(pendingImport?.importMode || (pendingImport?.trial ? 'TRIAL' : 'PERMANENT')).toUpperCase();
    if (mode === 'PERMANENT') { return null; }
    const id = uid('snapshot');
    const snapshot = { id, importId: pendingImport.fileName, createdAt: nowIso(), userId: user().id || null, importMode: pendingImport.importMode || (pendingImport.trial ? 'TRIAL' : 'PERMANENT'), trial: Boolean(pendingImport.trial), stores: {} };
    // Keep the exact pre-import component state. Rollback restores this snapshot
    // instead of trying to infer which derived records belong to the workbook.
    for (const store of COMPONENT_IMPORT_DATA_STORES) {
      snapshot.stores[store] = await gAll(store);
    }
    await dPut('component_import_snapshots', snapshot);
    await audit('COMPONENT_IMPORT_BACKUP', 'Import', id, { fileName: pendingImport.fileName, stores: Object.keys(snapshot.stores) });
    return id;
  }
  function stationVariationFor(stationNo) {
    if (!stationNo || stationNo === 'Station Not Assigned') {return [];}
    return [...new Set([...state.bins.map(b => b.stationNo), ...state.mappings.map(m => m.stationNo)].filter(existing => existing && existing !== stationNo && normalStation(existing) === normalStation(stationNo)))];
  }
  function resolveImportStation(stationNo) {
    const alias = activeStationAlias(stationNo);
    if (alias?.canonicalStation) {return canonicalStation(alias.canonicalStation);}
    const matches = stationVariationFor(stationNo);
    if (!matches.length) {return stationNo;}
    pendingImport.stationDecisions ||= {};
    if (pendingImport.stationDecisions[stationNo] === 'new') {return stationNo;}
    if (pendingImport.stationDecisions[stationNo]) {return pendingImport.stationDecisions[stationNo];}
    const existing = matches[0];
    const createNew = typeof confirm === 'function' && confirm(`Possible Station-name variation detected: ${stationNo} may match existing Station ${existing}. Click OK to create a NEW Station/Bin for ${stationNo}; click Cancel to use existing Station ${existing}.`);
    if (createNew) {
      pendingImport.stationDecisions[stationNo] = 'new';
      return stationNo;
    }
    pendingImport.stationDecisions[stationNo] = existing;
    return existing;
  }
  function setImportTrial(enabled) { if (!pendingImport) {return;} pendingImport.trial = Boolean(enabled); pendingImport.importMode = pendingImport.manualEntry ? 'MANUAL' : pendingImport.trial ? 'TRIAL' : 'PERMANENT'; state.importDraft = pendingImport; importView(); }
  async function persistResolvedGunRowStation(sourceKey, stationNo) {
    const resolvedStation = resolveImportStation(stationNo);
    const gunRow = (await gAll('component_gun_rows')).find(row => row.sourceKey === sourceKey);
    if (gunRow && gunRow.stationNo !== resolvedStation) {
      gunRow.stationNo = resolvedStation;
      gunRow.updatedAt = nowIso();
      await dPut('component_gun_rows', gunRow);
    }
    return resolvedStation;
  }

  async function commitImport() {
    if (pendingImport?.cancelled) { return toastMsg('Import processing was cancelled', 'er'); } if (!pendingImport?.rows?.length || !pendingImport.columnMappings) {return toastMsg('Build and review the Import Preview first', 'er');}
    if (!canComponent('import', true)) {return;}
    pendingImport.trial = Boolean(document.getElementById('cm-trial-import')?.checked ?? pendingImport.trial);
    pendingImport.importMode = pendingImport.manualEntry ? 'MANUAL' : pendingImport.trial ? 'TRIAL' : 'PERMANENT';
    const modeMessage = pendingImport.manualEntry
      ? 'Save this Manual New Gun through the shared Excel import logic? A pre-change snapshot will be kept so the manual addition can be rolled back.'
      : pendingImport.trial
        ? 'TRIAL import selected. If you rollback or delete this import, the complete component data will be restored to the exact state before this Excel import. Continue?'
        : 'PERMANENT import selected. This import will be protected from rollback/delete after commit. Continue?';
    if (!pendingImport.confirmed && typeof confirm === 'function' && !confirm(modeMessage + '\n\nExisting mapping updates will require separate confirmation.')) {return;}
    if (!pendingImport.conflictsConfirmed) { const conflicts = []; pendingImport.rows.forEach(row => { if (row.sourceOnly) {return;} const sourceKey = `${row.sourceSheet}:${row.sourceRow}`; componentPairsForRow(row).forEach(([position, partNo]) => { const existing = state.mappings.find(mapping => mappingIdentity(mapping.stationNo, mapping.gunReferenceNo, mapping.position) === mappingIdentity(row.stationNo, row.gunReferenceNo, position) && mapping.partNo !== partNo && (Array.isArray(mapping.sourceRows) ? mapping.sourceRows.includes(sourceKey) : `${mapping.sourceSheet}:${mapping.sourceRow}` === sourceKey)); if (existing) {conflicts.push(`${row.stationNo}/${row.gunReferenceNo}/${position}: ${existing.partNo} → ${partNo}`);} }); }); if (conflicts.length && typeof confirm === 'function' && !confirm(`This import contains ${conflicts.length} existing mapping update(s):\n\n${conflicts.slice(0, 40).join('\n')}${conflicts.length > 40 ? '\n…and more' : ''}\n\nApply all listed mapping updates?`)) { return; } pendingImport.conflictsConfirmed = true; }
    pendingImport.confirmed = true; pendingImport.commitProgress = 0; setImportCommitState(true); updateImportProgress(0, 'Preparing safe import snapshot…'); pendingImport.backupId = await snapshotBeforeImport(); const isManualEntry = Boolean(pendingImport.manualEntry);
    const summary = { rowsScanned: pendingImport.rows.length + pendingImport.skipped.length, sourceGunRows: pendingImport.sourceGunRows || pendingImport.rows.length, componentMappingRows: pendingImport.componentMappingRows || pendingImport.rows.filter(r => !r.sourceOnly).length, duplicateSourceRows: 0, invalidRows: pendingImport.skipped.length, newCount: 0, updatedCount: 0, duplicateCount: 0, skippedCount: pendingImport.skipped.length, warningCount: pendingImport.warnings.length, warnings: [...pendingImport.warnings, ...pendingImport.skipped] }; const seenSourceKeys = new Set();
    try {
    for (let rowIndex = 0; rowIndex < pendingImport.rows.length; rowIndex += 1) { const row = pendingImport.rows[rowIndex]; const sourceKey = `${row.sourceSheet}:${row.sourceRow}`; const fullSourceKey = `${pendingImport.fileName}:${sourceKey}`; if (seenSourceKeys.has(fullSourceKey) || state.gunRows.some(g => g.sourceKey === fullSourceKey)) { summary.duplicateSourceRows++; summary.duplicateCount++; continue; } seenSourceKeys.add(fullSourceKey); await dPut('component_gun_rows', { id: `gunrow-${pendingImport.fileName}-${sourceKey}`.replace(/[^A-Za-z0-9_-]/g, '_'), sourceFile: pendingImport.fileName, sourceKey: fullSourceKey, sourceSheet: row.sourceSheet, sourceRow: row.sourceRow, srNo: row.srNo, stationNo: resolveImportStation(row.stationNo), gunReferenceNo: row.gunReferenceNo, quantity: row.quantity, quantitySource: row.quantitySource, requiredQty: row.requiredQty, boldParts: row.boldParts, partOptions: row.partOptions, sourceBoldParts: row.sourceBoldParts, sourceHeaders: row.sourceHeaders, sourceValues: row.sourceValues, sourceOnly: Boolean(row.sourceOnly), sourceOrder: Number(row.sourceOrder || rowIndex + 1), importedAt: nowIso(), updatedAt: nowIso() }); if (row.sourceOnly) { continue; } const incomingStation = row.stationNo; const sameIncoming = pendingImport.rows.find(candidate => candidate !== row && candidate.stationNo !== 'Station Not Assigned' && sameStation(candidate.stationNo, incomingStation)); if (sameIncoming) {row.stationNo = sameIncoming.stationNo;} row.stationNo = resolveImportStation(row.stationNo); await persistResolvedGunRowStation(fullSourceKey, row.stationNo);       const validStation = row.stationNo !== 'Station Not Assigned'; let bin = validStation ? activeBinForStation(row.stationNo) : null;
      if (validStation) { const alias = { id: `alias-${normalStation(row.stationNo)}`, canonicalStation: canonicalStation(row.stationNo), alias: row.stationNo, status: 'ACTIVE', updatedAt: nowIso() }; await dPut(STORES.aliases, alias); state.aliases = [...state.aliases.filter(a => a.id !== alias.id), alias]; } if (validStation && !bin) { bin = { id: uid('bin'), binId: `${row.stationNo.replace(/[^A-Za-z0-9]/g, '').toUpperCase()}-BIN01`, name: `${row.stationNo} Common Bin`, stationNo: row.stationNo, stationOrder: Number(row.srNo || row.sourceRow || rowIndex + 1), location: '', active: true, createdAt: nowIso(), updatedAt: nowIso() }; await dPut(STORES.bins, bin); state.bins.push(bin); }
      await ensureCandidateStockRecords(row, bin); row.sourceOnly = !row.boldParts || !Object.values(row.boldParts).some(values => Array.isArray(values) && values.some(validMappedPartNo)); await ensureCandidatePartRecords(row); const pairs = componentPairsForRow(row); for (const [position, partNo] of pairs) { if (!partByNo(partNo)) { const p = { id: uid('part'), partNo, description: `${position} ${partNo}`, componentType: position.toLowerCase().includes('pencil') ? 'Pencil Shank' : position.toLowerCase().includes('shank') ? 'Copper Shank' : position.toLowerCase().includes('adaptor') ? 'Adaptor' : 'Holder', active: true, minimumStock: 0, status: 'ZERO STOCK', createdAt: nowIso(), updatedAt: nowIso() }; await dPut(STORES.parts, p); state.parts.push(p); }
        if (bin?.binId) { await ensureStockRecord(partNo, bin.binId); }
        const sourceKey = `${row.sourceSheet}:${row.sourceRow}`; const sameSource = mapping => Array.isArray(mapping.sourceRows) ? mapping.sourceRows.includes(sourceKey) : `${mapping.sourceSheet}:${mapping.sourceRow}` === sourceKey; const exact = state.mappings.find(m => mappingIdentity(m.stationNo, m.gunReferenceNo, m.position) === mappingIdentity(row.stationNo, row.gunReferenceNo, position) && m.partNo === partNo && sameSource(m)); if (exact) { summary.duplicateCount++; continue; } const existing = state.mappings.find(m => mappingIdentity(m.stationNo, m.gunReferenceNo, m.position) === mappingIdentity(row.stationNo, row.gunReferenceNo, position) && m.partNo !== partNo && sameSource(m)); if (existing) { const oldPartNo = existing.partNo; await dPut('component_mapping_revisions', { id: uid('rev'), mappingId: existing.id, stationNo: row.stationNo, gunReferenceNo: row.gunReferenceNo, oldValue: { ...existing }, newValue: { ...existing, partNo }, reason: 'Confirmed Gun Matrix import update', changedAt: nowIso(), userId: user().id || null }); Object.assign(existing, { partNo, previousPartNo: oldPartNo, quantity: Number(row.quantity || 1), sourceRows: [`${row.sourceSheet}:${row.sourceRow}`], sourceSrNo: row.srNo || existing.sourceSrNo || null, requiredQty: Number(row.requiredQty || row.quantity * 2), binId: bin?.binId || null, sourceSheet: row.sourceSheet, sourceRow: row.sourceRow, sourceOrder: Number(row.sourceOrder || rowIndex + 1), sourceHeaders: row.sourceHeaders, sourceValues: row.sourceValues, boldParts: row.boldParts, partOptions: row.partOptions, sourceBoldParts: row.sourceBoldParts, updatedAt: nowIso() }); await dPut(STORES.mappings, existing); summary.updatedCount++; await audit('COMPONENT_MAPPING_UPDATE', 'Gun Matrix Mapping', existing.id, { oldPartNo, newPartNo: partNo }); } else { const map = { id: uid('map'), stationNo: row.stationNo, gunReferenceNo: row.gunReferenceNo, position, partNo, quantity: Number(row.quantity || 1), sourceRows: [`${row.sourceSheet}:${row.sourceRow}`], requiredQty: Number(row.requiredQty || row.quantity * 2), binId: bin?.binId || null, sourceSheet: row.sourceSheet, sourceRow: row.sourceRow, sourceHeaders: row.sourceHeaders, sourceValues: row.sourceValues, sourceOrder: Number(row.sourceOrder || rowIndex + 1), boldParts: row.boldParts, partOptions: row.partOptions, sourceBoldParts: row.sourceBoldParts, sourceSrNo: row.srNo || null, srNo: `${row.stationNo}-${row.gunReferenceNo}-${position}`, updatedAt: nowIso() }; await dPut(STORES.mappings, map); state.mappings.push(map); summary.newCount++; await audit('COMPONENT_MAPPING_CREATE', 'Gun Matrix Mapping', map.id, map); } if ((rowIndex + 1) % 50 === 0 || rowIndex + 1 === pendingImport.rows.length) { pendingImport.commitProgress = Math.round(((rowIndex + 1) / pendingImport.rows.length) * 100); updateImportProgress(pendingImport.commitProgress, `Saving ${rowIndex + 1} of ${pendingImport.rows.length} rows (${pendingImport.commitProgress}%)`); await perfTools.yieldToUi(); }
      }
    }
    updateImportProgress(96, 'Finalizing imported mappings and audit history…');
    await ensurePencilBins();
    } catch (error) {
      console.error('Atomic Gun Matrix import failed; restoring pre-import snapshot', error);
      const failedSnapshot = pendingImport?.backupId;
      if (failedSnapshot) { await rollbackImport(failedSnapshot); }
      setImportCommitState(false); updateImportProgress(0, 'Import failed; review the error and rebuild the preview to retry.');
      pendingImport = null; state.importDraft = null;
      return toastMsg(`Import failed${failedSnapshot ? ' and the saved snapshot was restored' : '; no automatic rollback snapshot was available'}. ${error.message || ''}`, 'er');
    }
    const record = { id: uid('imp'), importedAt: nowIso(), sourceFile: pendingImport.fileName, status: 'COMMITTED', mode: pendingImport.importMode || (pendingImport.trial ? 'TRIAL' : 'PERMANENT'), trial: Boolean(pendingImport.trial), protected: pendingImport.importMode === 'PERMANENT', importedRows: summary.rowsScanned, sourceOnlyRows: pendingImport.sourceOnlyCount || 0, sourceGunRows: summary.sourceGunRows || pendingImport.rows.length, componentMappingRows: summary.componentMappingRows || pendingImport.rows.filter(r => !r.sourceOnly).length, duplicateSourceRows: summary.duplicateSourceRows || 0, invalidRows: summary.invalidRows || pendingImport.skipped.length, reconciliation: { sourceGunRows: summary.sourceGunRows || pendingImport.rows.length, importedGunRows: pendingImport.rows.length, duplicateSourceRows: summary.duplicateSourceRows || 0, invalidRows: summary.invalidRows || pendingImport.skipped.length, balanced: (summary.sourceGunRows || pendingImport.rows.length) === pendingImport.rows.length + (summary.invalidRows || pendingImport.skipped.length) }, ...summary, selectedSheets: pendingImport.selectedSheets, columnMappings: pendingImport.columnMappings, sourceSheets: Object.fromEntries(pendingImport.selectedSheets.map(sheet => [sheet, pendingImport.rawSheets[sheet] || []])), backupId: pendingImport.backupId, userId: user().id || null }; await dPut(STORES.imports, record); await dPut('component_import_configs', { id: uid('cfg'), importId: record.id, sheetName: pendingImport.selectedSheets.join(','), columnMappings: pendingImport.columnMappings, userId: user().id || null, createdAt: nowIso() }); await audit(isManualEntry ? 'COMPONENT_GUN_MANUAL_ADD' : 'COMPONENT_MATRIX_IMPORT', isManualEntry ? 'Manual Gun' : 'Import', record.id, record); updateImportProgress(100, `Complete — ${record.importedRows} source rows committed`); setImportCommitState(false); pendingImport = null; state.importDraft = null; await load();
    // Excel import is the authoritative source for RH/LH station rows. Once both
    // sides are present, automatically consolidate them into one physical Common
    // Bin; no manual Merge action is required. The helper is idempotent, so a
    // second import/reload will not duplicate stock or create another merge.
    const autoRhLhMerges = await migrateExistingRhLhCommonBins();
    await reconcileRhLhCommonBinReferences();
    await load();
    const expectedMappings = state.gunRows.filter(r => r.sourceFile === record.sourceFile && !r.sourceOnly).length;
    if (expectedMappings > 0 && state.mappings.length === 0) {
      console.error('[ComponentManagement] Import committed source rows but no component mappings were reloaded', { expectedMappings, fileName: record.sourceFile });
      toastMsg('Import saved source rows but mappings could not be reloaded. Please reopen the application and retry the import.', 'er');
      return;
    }
    toastMsg(isManualEntry ? `Manual Gun saved — ${summary.newCount} mapping row(s), ${summary.sourceGunRows} source Gun row(s), ${summary.warningCount} warning(s).` : `Import complete — New: ${summary.newCount}, Updated: ${summary.updatedCount}, Duplicate: ${summary.duplicateCount}, Skipped: ${summary.skippedCount}, Warnings: ${summary.warningCount}, Auto LH/RH Common Bin merges: ${autoRhLhMerges || 0}`, 'suc'); importView();
  }
  async function previewImportRollback(snapshotId) {
    if (!canComponent('import', true)) {return;}
    const linkedImport = (await gAll(STORES.imports)).find(i => i.backupId === snapshotId);
    if (String(linkedImport?.mode || '').toUpperCase() === 'PERMANENT' || linkedImport?.protected) {return toastMsg('Permanent import is protected and cannot be rolled back', 'inf');}
    const snap = (await gAll('component_import_snapshots')).find(x => x.id === snapshotId);
    if (!snap) {return toastMsg('Import backup was not found', 'er');}
    const counts = Object.fromEntries(Object.entries(snap.stores || {}).map(([store, rows]) => [store, Array.isArray(rows) ? rows.length : 0]));
    const message = `Rollback preview\\n\\nImport: ${snap.importId}\\nSnapshot: ${snap.createdAt}\\n\\nParts: ${counts[STORES.parts] || 0}\\nMappings: ${counts[STORES.mappings] || 0}\\nGun rows: ${counts.component_gun_rows || 0}\\nBins: ${counts[STORES.bins] || 0}\\nStock rows: ${counts[STORES.stock] || 0}\\nTransactions: ${counts[STORES.tx] || 0}\\nRepair/Scrap rows: ${counts[STORES.repair] || 0}\\n\\nContinue to restore this exact pre-import snapshot? Any component data changed after this import will also be reverted.`;
    if (typeof confirm === 'function' && !confirm(message)) {return;}
    await rollbackImport(snapshotId);
  }
  async function purgeImportedWorkbook(snapshotId) {
    if (!canComponent('import', true)) {return;}
    const snapshots = await gAll('component_import_snapshots');
    const snap = snapshots.find(x => x.id === snapshotId);
    if (!snap) {return toastMsg('Import backup was not found; rollback cannot be performed', 'er');}
    const importRow = (await gAll(STORES.imports)).find(i => i.backupId === snapshotId);
    const fileName = importRow?.sourceFile || snap.importId;
    if (String(importRow?.mode || snap.importMode || '').toUpperCase() === 'PERMANENT' || importRow?.protected || snap?.trial === false) {return toastMsg('Permanent import is protected and cannot be rolled back or deleted', 'inf');}
    if (snap.rolledBack) {return toastMsg('This import has already been rolled back', 'inf');}
    if (typeof confirm === 'function' && !confirm(`Rollback ${fileName}? This restores Shank Mapping data to the exact state before this Excel import. Any component data changed after that import will also be reverted.`)) {return;}

    // A rollback is a true pre-import restore. The old implementation only
    // removed source mappings/gun rows, which left Parts, Bins, Stock, History,
    // Required Quantity, Labels and Analytics populated by the remaining stores.
    const componentStores = COMPONENT_IMPORT_DATA_STORES;
    const legacyImportedGunRows = (await gAll('component_gun_rows')).filter(row => row.sourceFile === fileName);
    const legacyImportedSourceKeys = new Set(legacyImportedGunRows.map(row => String(row.sourceKey || `${row.sourceSheet}:${row.sourceRow}`)));
    const legacyImportedSourceRows = new Set(legacyImportedGunRows.map(row => `${row.sourceSheet}:${row.sourceRow}`));
    const restoredCounts = {};
    for (const store of componentStores) {
      const snapshotRows = Array.isArray(snap.stores?.[store]) ? snap.stores[store] : null;
      // Older snapshots did not contain aliases/replacements/month closes. For
      // those stores, preserve their current data rather than deleting unknown
      // pre-existing records. New snapshots contain every component store.
      if (snapshotRows === null) {continue;}
      const currentRows = await gAll(store);
      for (const row of currentRows) {
        await dDel(store, row.id);
      }
      for (const row of snapshotRows) {
        await dPut(store, row);
      }
      restoredCounts[store] = snapshotRows.length;
    }

    // Older snapshots did not capture downstream projections such as label versions.
    // Remove records belonging to this workbook before leaving the old snapshot path.
    const hasSnapshotStore = store => Array.isArray(snap.stores?.[store]);
    for (const store of [STORES.mappings, 'component_label_versions']) {
      if (hasSnapshotStore(store)) {continue;}
      const rows = await gAll(store);
      for (const row of rows) {
        const sourceRows = Array.isArray(row.sourceRows) ? row.sourceRows.map(String) : [];
        const belongsToImport = sourceRows.some(key => legacyImportedSourceRows.has(key) || legacyImportedSourceKeys.has(`${fileName}:${key}`)) || row.sourceFile === fileName;
        if (belongsToImport) {await dDel(store, row.id);}
      }
    }

    // Old snapshots did not capture aliases. Remove only aliases that belong to
    // stations which exist solely in the rolled-back workbook; preserve aliases
    // still referenced by the restored pre-import mappings/bins.
    if (!Array.isArray(snap.stores?.[STORES.aliases])) {
      const restoredMappings = await gAll(STORES.mappings);
      const restoredBins = await gAll(STORES.bins);
      const keepStations = new Set([...restoredMappings.map(r => normalStation(r.stationNo)), ...restoredBins.map(b => normalStation(b.stationNo))].filter(Boolean));
      const currentAliases = await gAll(STORES.aliases);
      for (const alias of currentAliases) {
        if (!keepStations.has(normalStation(alias.canonicalStation)) && !keepStations.has(normalStation(alias.alias))) {
          await dDel(STORES.aliases, alias.id);
        }
      }
    }

    if (importRow) {
      await dPut(STORES.imports, { ...importRow, status: 'ROLLED_BACK', purged: true, rolledBack: true, rolledBackAt: nowIso(), purgedAt: nowIso(), purgedBy: user().id || null, rollbackMode: 'EXACT_PRE_IMPORT_SNAPSHOT' });
      for (const cfg of await gAll('component_import_configs')) {
        if (cfg.importId === importRow.id) { await dDel('component_import_configs', cfg.id); }
      }
    }
    // Delete the recovery snapshot so startup cannot recreate rolled-back data.
    await dDel('component_import_snapshots', snapshotId);
    await audit('COMPONENT_IMPORT_PURGE', 'Import', snapshotId, { fileName, mode: 'EXACT_PRE_IMPORT_RESTORE', restoredCounts });
    await audit('COMPONENT_IMPORT_ROLLBACK', 'Import', snapshotId, { mode: 'EXACT_PRE_IMPORT_SNAPSHOT', fileName, verified: true, restoredCounts });
    await load();
    toastMsg(`Rollback complete — data restored to the state before ${fileName}`, 'suc');
    importView();
  }
  async function rollbackImport(snapshotId) { return purgeImportedWorkbook(snapshotId); }
  async function deleteImportSource(importId) {
    if (!canComponent('import', true)) {return;}
    const importRow = (await gAll(STORES.imports)).find(i => i.id === importId);
    if (!importRow) {return toastMsg('Import history record was not found', 'er');}
    if (String(importRow.mode || '').toUpperCase() === 'PERMANENT' || importRow.protected) {return toastMsg('Permanent import is protected and cannot be deleted', 'inf');}
    const fileName = String(importRow.sourceFile || 'GMatrix');
    const gunRows = await gAll('component_gun_rows'); const ownedGuns = gunRows.filter(r => String(r.sourceFile || '') === fileName); const sourceKeys = new Set(ownedGuns.map(r => String(r.sourceKey || ''))); const sourceRows = new Set(ownedGuns.map(r => `${r.sourceSheet}:${r.sourceRow}`));
    const mappings = await gAll(STORES.mappings); const ownedMappings = mappings.filter(m => String(m.sourceFile || '') === fileName || sourceKeys.has(String(m.sourceKey || '')) || (Array.isArray(m.sourceRows) && m.sourceRows.some(k => sourceRows.has(String(k)))));
    if (typeof confirm === 'function' && !confirm(`Delete import ${fileName}? This removes only mappings owned by this import. Parts/Bins/Stock used by other mappings or transactions will be retained.`)) {return;}
    for (const row of ownedMappings) {await dDel(STORES.mappings, row.id);}
    for (const row of ownedGuns) {await dDel('component_gun_rows', row.id);}
    const remainingMappings = await gAll(STORES.mappings), stock = await gAll(STORES.stock), tx = await gAll(STORES.tx), replacements = await gAll(STORES.replacements), repairs = await gAll(STORES.repair), orders = await gAll(STORES.orders);
    const usedParts = new Set([...remainingMappings.map(r => vendorPartNo(r.partNo).trim().toLowerCase()), ...stock.map(r => vendorPartNo(r.partNo).trim().toLowerCase()), ...tx.map(r => vendorPartNo(r.partNo).trim().toLowerCase()), ...replacements.map(r => vendorPartNo(r.newPartNo || r.partNo).trim().toLowerCase()), ...repairs.map(r => vendorPartNo(r.partNo).trim().toLowerCase()), ...orders.map(r => vendorPartNo(r.partNo).trim().toLowerCase())]);
    for (const part of await gAll(STORES.parts)) {if (!usedParts.has(vendorPartNo(part.partNo).trim().toLowerCase()) && part.sourceFile === fileName) {await dDel(STORES.parts, part.id);}}
    const usedBins = new Set([...remainingMappings.map(r => r.binId), ...stock.map(r => r.binId), ...tx.map(r => r.binId)]); for (const bin of await gAll(STORES.bins)) {if (!usedBins.has(bin.binId) && bin.sourceFile === fileName) {await dDel(STORES.bins, bin.id);}}
    for (const cfg of await gAll('component_import_configs')) {if (cfg.importId === importId) {await dDel('component_import_configs', cfg.id);}}
    if (importRow.backupId) {const snap = (await gAll('component_import_snapshots')).find(s => s.id === importRow.backupId); if (snap) {await dDel('component_import_snapshots', snap.id);}}
    await dPut(STORES.imports, { ...importRow, status: 'DELETED', deletedAt: nowIso(), deletedBy: user().id || null, deleteMode: 'SOURCE_OWNED_MAPPINGS' }); await audit('COMPONENT_IMPORT_DELETE', 'Import', importId, { sourceFile: fileName, deletedMappings: ownedMappings.length, deletedGunRows: ownedGuns.length, mode: 'SOURCE_OWNED_MAPPINGS' }); await load(); importView(); toastMsg(`Import deleted: ${fileName}`, 'suc');
  }
  async function removeImportHistory(importId) {
    if (!canComponent('import', true)) { return; }
    const rows = await gAll(STORES.imports);
    const row = rows.find(item => item.id === importId);
    if (!row) { return toastMsg('Import history row not found', 'er'); }
    if (typeof confirm === 'function' && !confirm(`Remove only this Import History row for ${row.sourceFile || 'this import'}? Imported data will not be changed.`)) { return; }
    await dDel(STORES.imports, importId);
    await audit('COMPONENT_IMPORT_HISTORY_REMOVE', 'Import History', importId, { sourceFile: row.sourceFile || '', historyOnly: true });
    await load(); importView(); toastMsg('Import History row removed. Imported data was not changed.', 'suc');
  }
  async function deleteImport(importId, snapshotId) { const row = (await gAll(STORES.imports)).find(i => i.id === importId); const linkedSnapshotId = snapshotId || row?.backupId; if (linkedSnapshotId) { const snap = (await gAll('component_import_snapshots')).find(s => s.id === linkedSnapshotId); if (snap) {await rollbackImport(linkedSnapshotId); return;} } return deleteImportSource(importId); }
  const SHANK_MAPPING_RESET_STORES = [...new Set([...COMPONENT_IMPORT_DATA_STORES, STORES.audit, STORES.people, 'component_import_snapshots', 'component_mapping_revisions', 'component_import_configs', 'component_station_merge_history', 'component_analytics_config', 'component_printer_profiles', 'component_qr_audit', STORES.partConfigs, STORES.orders])];
  async function resetShankMappingData() {
    if (!canComponent('import', true)) {return;}
    const imports = await gAll(STORES.imports);
    const trialImports = imports.filter(i => String(i.mode || (i.trial ? 'TRIAL' : 'LEGACY')).toUpperCase() === 'TRIAL' && i.status !== 'DELETED');
    const permanentImports = imports.filter(i => String(i.mode || (i.trial ? 'TRIAL' : 'LEGACY')).toUpperCase() === 'PERMANENT' && i.status !== 'DELETED');
    if (!trialImports.length) {return toastMsg('Reset is available only after a Trial Import. Permanent data is protected.', 'inf');}
    if (permanentImports.length) {return toastMsg('Trial reset is locked because permanent production data exists. Permanent data is protected.', 'inf');}
    const message = 'Clear ALL Shank Mapping trial data? This permanently removes trial imports, Parts Master, Gun Mapping, bins, stock, transactions, replacements, repair/scrap, analytics, procurement and component audit/history data. Other StoreTrack modules and login users will not be affected.';
    if (typeof confirm === 'function' && !confirm(message)) {return;}
    const counts = {};
    for (const store of SHANK_MAPPING_RESET_STORES) {
      const rows = await gAll(store); counts[store] = rows.length; await dClr(store);
    }
    pendingImport = null; state.importDraft = null; await load(); importView(); toastMsg(`Shank Mapping reset complete — ${Object.values(counts).reduce((a, b) => a + b, 0)} records removed`, 'suc');
  }


  async function addPerson() { if (!canComponent('maintenance directory', true)) {return;} const name = await componentInputDialog('Maintenance Person name', 'Maintenance Person name'); const department = await componentInputDialog('Maintenance Team / Department', 'Maintenance Team / Department'); if (!name || !department) {return;} const p = { id: uid('person'), name: name.trim(), department: department.trim(), active: true, createdAt: nowIso(), createdBy: user().username || 'Unknown' }; await dPut(STORES.people, p); await load(); toastMsg('Maintenance person added', 'suc'); replacement(); }

  function stationAliases() {
    const aliases = [...state.aliases].sort((a, b) => String(a.canonicalStation || '').localeCompare(String(b.canonicalStation || '')));
    const rows = aliases.map(a => `<tr><td>${esc(a.canonicalStation)}</td><td>${esc(a.alias)}</td><td>${esc(a.status || 'ACTIVE')}</td><td>${btn('Edit', `componentEditStationAlias('${esc(a.id)}')`)} ${btn('Deactivate', `componentDeactivateStationAlias('${esc(a.id)}')`)}</td></tr>`).join('');
    shell('Station Alias Master', `<div class="alrt alrt-b">Use Station Alias to map alternate Station names or formats to one canonical identity. Active aliases are honored by import, mapping, bin lookup, and station search; inactive aliases are ignored.</div><div class="g3"><div class="fr"><label class="fl">Canonical Station *</label><input class="fi" id="csa-canonical" placeholder="Press 10"></div><div class="fr"><label class="fl">Alias *</label><input class="fi" id="csa-alias" placeholder="Press Ten"></div>${btn('Save Station Alias', 'componentSaveStationAlias()', true)}</div>${table(['Canonical Station','Alias','Status','Actions'], rows, 'No Station aliases saved.', '', ['Canonical Station','Alias'])}`);
  }
  function stationAliasConflict(alias, canonical, currentId) { const aliasKey = normalStation(alias), canonicalKey = normalStation(canonical); if (!aliasKey || !canonicalKey) {return true;} return (state.aliases || []).some(item => String(item.id) !== String(currentId || '') && (normalStation(item.alias) === aliasKey || normalStation(item.alias) === canonicalKey && normalStation(item.canonicalStation) !== canonicalKey)); }
  async function saveStationAlias() { if (!canComponent('mapping', true)) {return;} const canonical = canonicalStation(val('csa-canonical')); const alias = canonicalStation(val('csa-alias')); if (!canonical || !alias) {return toastMsg('Canonical Station and Alias are required', 'er');} if (stationAliasConflict(alias, canonical)) {return toastMsg('That Station alias conflicts with an existing alias; choose a unique alias and canonical Station', 'er');} const row = { id: `alias-${normalStation(alias)}`, canonicalStation: canonical, alias, status: 'ACTIVE', updatedAt: nowIso(), createdBy: user().username || user().name || 'Unknown' }; await dPut(STORES.aliases, row); await audit('COMPONENT_STATION_ALIAS_UPDATE', 'Station Alias', row.id, row); await load(); toastMsg('Station alias saved', 'suc'); stationAliases(); }
  async function editStationAlias(id) { if (!canComponent('mapping', true)) {return;} const row = state.aliases.find(a => a.id === id); if (!row) {return;} const canonical = await componentInputDialog('Edit Canonical Station Alias', 'Canonical Station', row.canonicalStation); const alias = await componentInputDialog('Edit Station Alias', 'Alias', row.alias); if (canonical == null || alias == null) {return;} const cleanCanonical = canonicalStation(canonical); const cleanAlias = canonicalStation(alias); const updated = { ...row, id: `alias-${normalStation(cleanAlias)}`, canonicalStation: cleanCanonical, alias: cleanAlias, updatedAt: nowIso() }; if (!cleanCanonical || !cleanAlias) {return toastMsg('Canonical Station and Alias are required', 'er');} if (stationAliasConflict(cleanAlias, cleanCanonical, id)) {return toastMsg('That Station alias conflicts with an existing alias; choose a unique alias and canonical Station', 'er');} if (updated.id !== id) {await dDel(STORES.aliases, id);} await dPut(STORES.aliases, updated); await audit('COMPONENT_STATION_ALIAS_UPDATE', 'Station Alias', id, updated); await load(); stationAliases(); }
  async function deactivateStationAlias(id) { if (!canComponent('mapping', true)) {return;} const row = state.aliases.find(a => a.id === id); if (!row) {return;} row.status = 'INACTIVE'; row.updatedAt = nowIso(); await dPut(STORES.aliases, row); await audit('COMPONENT_STATION_ALIAS_DEACTIVATE', 'Station Alias', id, row); await load(); stationAliases(); }
  function recoveredPairsFromGunRow(gunRow) {
    if (gunRow?.boldParts && typeof gunRow.boldParts === 'object') {return componentPairsForRow({ boldParts: gunRow.boldParts });}
    const headers = Array.isArray(gunRow.sourceHeaders) ? gunRow.sourceHeaders : [];
    const values = Array.isArray(gunRow.sourceValues) ? gunRow.sourceValues : [];
    const valueFor = field => {
      const index = headers.findIndex(header => likelyField(header, field));
      return index >= 0 && values[index] != null ? vendorPartNo(values[index]) : '';
    };
    return componentPairsForRow({
      fixShank: valueFor('fixShank'), movingShank: valueFor('movingShank'),
      fixAdaptor: valueFor('fixAdaptor'), movingAdaptor: valueFor('movingAdaptor'),
      fixHolder: valueFor('fixHolder'), movingHolder: valueFor('movingHolder'),
      pencilShank: valueFor('pencilShank')
    });
  }
  async function backfillMappingsFromGunRows() {
    let created = 0;
    for (const row of state.gunRows) {
      if (!row || row.stationNo === 'Station Not Assigned') { continue; }
      const pairs = recoveredPairsFromGunRow(row);
      if (!pairs.length) { continue; }
      let bin = activeBinForStation(row.stationNo);
      if (!bin) {
        bin = { id: uid('bin'), binId: `${String(row.stationNo).replace(/[^A-Za-z0-9]/g, '').toUpperCase()}-BIN01`, name: `${row.stationNo} Common Bin`, stationNo: row.stationNo, location: '', active: true, createdAt: nowIso(), updatedAt: nowIso() };
        await dPut(STORES.bins, bin); state.bins.push(bin);
      }
      await ensureCandidatePartRecords(row);
      await ensureCandidateStockRecords(row, bin);
      for (const [position, partNo] of pairs) {
        if (!partByNo(partNo)) {
          const part = { id: uid('part'), partNo, description: `${position} ${partNo}`, componentType: position.toLowerCase().includes('shank') ? 'Copper Shank' : position.toLowerCase().includes('adaptor') ? 'Adaptor' : position.toLowerCase().includes('holder') ? 'Holder' : 'Pencil Shank', active: true, minimumStock: 0, status: 'ZERO STOCK', createdAt: nowIso(), updatedAt: nowIso() };
          await dPut(STORES.parts, part); state.parts.push(part);
        }
        const sourceKey = `${row.sourceSheet}:${row.sourceRow}`;
        const identity = mappingIdentity(row.stationNo, row.gunReferenceNo, position);
        const existing = state.mappings.find(m => mappingIdentity(m.stationNo, m.gunReferenceNo, m.position) === identity);
        if (existing) {
          // A saved bold/alternative choice must replace the old imported Part
          // on the same Gun/Position; otherwise BI continues seeing the stale
          // mapping even though the source Gun row was updated.
          const changed = String(existing.partNo || '') !== String(partNo) || String(existing.binId || '') !== String(bin.binId || '');
          existing.partNo = partNo;
          existing.quantity = Number(row.quantity || existing.quantity || 1);
          existing.requiredQty = Number(row.requiredQty || existing.requiredQty || Number(row.quantity || 1) * 2);
          existing.sourceSrNo = row.srNo || existing.sourceSrNo || null;
          existing.sourceRows = Array.isArray(existing.sourceRows) && existing.sourceRows.length ? existing.sourceRows : [sourceKey];
          existing.sourceSheet = row.sourceSheet;
          existing.sourceRow = row.sourceRow;
          existing.sourceHeaders = row.sourceHeaders;
          existing.sourceValues = row.sourceValues;
          existing.partOptions = row.partOptions || existing.partOptions;
          existing.binId = bin.binId;
          existing.updatedAt = nowIso();
          if (changed) { await dPut(STORES.mappings, existing); created++; }
          continue;
        }
        const map = { id: uid('map'), stationNo: row.stationNo, gunReferenceNo: row.gunReferenceNo, position, partNo, quantity: Number(row.quantity || 1), requiredQty: Number(row.requiredQty || Number(row.quantity || 1) * 2), sourceSrNo: row.srNo || null, sourceRows: [sourceKey], sourceSheet: row.sourceSheet, sourceRow: row.sourceRow, sourceHeaders: row.sourceHeaders, sourceValues: row.sourceValues, partOptions: row.partOptions || {}, binId: bin.binId, updatedAt: nowIso() };
        await dPut(STORES.mappings, map); state.mappings.push(map); created++;
      }
    }
    return created;
  }
  function rhLhStationSide(stationNo) {
    const match = canonicalStation(stationNo).match(/(?:^|[\s_-])(RH|LH)$/i);
    return match ? match[1].toUpperCase() : '';
  }
  function nextRecoveredSourceBinId(stationNo) {
    const stem = canonicalStation(stationNo).replace(/[^A-Za-z0-9]/g, '').toUpperCase() || 'STATION';
    const used = new Set(state.bins.map(bin => String(bin.binId || '')));
    let suffix = 1;
    let binId = `${stem}-BIN${String(suffix).padStart(2, '0')}`;
    while (used.has(binId)) {
      suffix += 1;
      binId = `${stem}-BIN${String(suffix).padStart(2, '0')}`;
    }
    return binId;
  }
  async function recoverLegacySharedRhLhSourceBins() {
    const stationGroups = new Map();
    const collectStation = stationNo => {
      const side = rhLhStationSide(stationNo);
      const base = baseStationKey(stationNo);
      if (!side || !base) {return;}
      if (!stationGroups.has(base)) {stationGroups.set(base, { RH: new Map(), LH: new Map() });}
      stationGroups.get(base)[side].set(stationVariantKey(stationNo), canonicalStation(stationNo));
    };
    [...state.gunRows, ...state.mappings].forEach(row => collectStation(row.stationNo));

    let recovered = 0;
    for (const [base, sides] of stationGroups) {
      if (sides.RH.size !== 1 || sides.LH.size !== 1) {continue;}
      const rhStation = [...sides.RH.values()][0];
      const lhStation = [...sides.LH.values()][0];
      const alreadyMerged = state.bins.some(bin => {
        if (!bin || bin.active === false || bin.binKind || baseStationKey(bin.stationNo) !== base) {return false;}
        const mergedSides = new Set((bin.mergedStations || []).map(rhLhStationSide).filter(Boolean));
        const commonLabel = [bin.binId, bin.stationNo, bin.name].some(value => /(?:^|[\s_-])(?:RH\/LH|LH\/RH)(?:$|[\s_-])/i.test(canonicalStation(value)));
        return mergedSides.has('RH') && mergedSides.has('LH') || commonLabel;
      });
      if (alreadyMerged) {continue;}

      const activeSideBins = state.bins.filter(bin => bin && bin.active !== false && !bin.binKind && baseStationKey(bin.stationNo) === base && rhLhStationSide(bin.stationNo));
      if (activeSideBins.length !== 1) {continue;}
      const existing = activeSideBins[0];
      const existingSide = rhLhStationSide(existing.stationNo);
      const missingSide = existingSide === 'RH' ? 'LH' : existingSide === 'LH' ? 'RH' : '';
      if (!missingSide || !sides[existingSide].has(stationVariantKey(existing.stationNo))) {continue;}
      const missingStation = missingSide === 'RH' ? rhStation : lhStation;
      if (state.bins.some(bin => bin && !bin.binKind && baseStationKey(bin.stationNo) === base && rhLhStationSide(bin.stationNo) === missingSide)) {continue;}

      const gunCondition = mergeStationGunCondition(rhStation, lhStation);
      if (!gunCondition.ok) {continue;}
      const existingBinId = String(existing.binId || '');
      if (!existingBinId) {continue;}
      const hasSharedMappingFor = station => state.mappings.some(mapping => sameStation(mapping.stationNo, station) && validMappedPartNo(mapping.partNo) && String(mapping.binId || '') === existingBinId);
      if (!hasSharedMappingFor(rhStation) || !hasSharedMappingFor(lhStation)) {continue;}

      // Older imports assigned both side mappings to the first side's bin.
      // Recreate only the absent, empty source record; the existing pooled
      // stock is moved once by the normal merge below, never duplicated.
      const recoveredSource = {
        id: uid('legacy-rhlh-source'),
        binId: nextRecoveredSourceBinId(missingStation),
        name: `${missingStation} Source Bin (recovered for RH/LH merge)`,
        stationNo: missingStation,
        stationOrder: Number(existing.stationOrder || 999999),
        location: existing.location || '',
        active: true,
        legacyRecoveredSource: true,
        recoveredFromSharedBinId: existingBinId,
        createdAt: nowIso(),
        updatedAt: nowIso()
      };
      await dPut(STORES.bins, recoveredSource);
      state.bins.push(recoveredSource);
      recovered += 1;
    }
    return recovered;
  }

  async function migrateExistingRhLhCommonBins() {
    await recoverLegacySharedRhLhSourceBins();
    const groups = new Map();
    let mergedCount = 0;
    for (const bin of state.bins.filter(item => item.active !== false && item.stationNo && !item.binKind)) {
      const station = canonicalStation(bin.stationNo);
      if (!/(?:^|[\s_-])(RH|LH)$/i.test(station)) { continue; }
      const base = baseStationKey(station);
      if (!base) { continue; }
      if (!groups.has(base)) { groups.set(base, []); }
      groups.get(base).push(bin);
    }

    for (const binsForBase of groups.values()) {
      const rh = binsForBase.find(bin => /(?:^|[\s_-])RH$/i.test(canonicalStation(bin.stationNo)));
      const lh = binsForBase.find(bin => /(?:^|[\s_-])LH$/i.test(canonicalStation(bin.stationNo)));
      if (!rh || !lh || rh.id === lh.id) { continue; }

      const gunCondition = mergeStationGunCondition(rh.stationNo, lh.stationNo);
      if (!gunCondition.ok) { continue; }

      const mergedBinId = `${baseStationName(rh.stationNo)} RH/LH`;
      const existingCommon = state.bins.find(bin => bin.active !== false && String(bin.binId || '') === mergedBinId);

      // Preserve both original RH/LH bins as inactive historical/source records.
      // Never convert either source record into the Common Bin itself.
      let target = existingCommon;
      if (!target) {
        target = {
          id: uid('bin'),
          binId: mergedBinId,
          name: `${baseStationName(rh.stationNo)} RH/LH Common Bin`,
          stationNo: rh.stationNo,
          stationOrder: Math.min(Number(rh.stationOrder || 999999), Number(lh.stationOrder || 999999)),
          location: rh.location || lh.location || '',
          active: true,
          mergedStations: [...new Set([rh.stationNo, lh.stationNo])],
          createdAt: nowIso(),
          updatedAt: nowIso()
        };
        await dPut(STORES.bins, target);
        state.bins.push(target);
      } else {
        target.name = `${baseStationName(rh.stationNo)} RH/LH Common Bin`;
        target.stationNo = target.stationNo || rh.stationNo;
        target.mergedStations = [...new Set([...(target.mergedStations || []), rh.stationNo, lh.stationNo])];
        target.active = true;
        target.updatedAt = nowIso();
        await dPut(STORES.bins, target);
      }

      const sourceBins = [rh, lh].filter(bin => bin.id !== target.id);
      const oldIds = new Set(sourceBins.map(bin => String(bin.binId || '')).filter(Boolean));
      const history = {
        id: uid('auto-smh'),
        source: `${rh.stationNo} + ${lh.stationNo}`,
        target: target.stationNo,
        mode: 'COMMON_BIN',
        automatic: true,
        targetBinCreated: !existingCommon,
        createdAt: nowIso(),
        userId: user().id || null,
        mappings: state.mappings.filter(row => oldIds.has(String(row.binId || ''))).map(row => ({ ...row })),
        sourceBins: sourceBins.map(bin => ({ ...bin })),
        targetBin: { ...target },
        stock: state.stock.filter(row => oldIds.has(String(row.binId || '')) || String(row.binId || '') === String(target.binId || '')).map(row => ({ ...row })),
        conflicts: []
      };

      // Persist rollback data before changing mappings, stock, or transactions.
      await dPut('component_station_merge_history', history);
      for (const row of state.mappings.filter(item => oldIds.has(String(item.binId || '')))) {
        row.binId = mergedBinId;
        row.updatedAt = nowIso();
        await dPut(STORES.mappings, row);
      }
      for (const row of state.tx.filter(item => oldIds.has(String(item.binId || '')))) {
        row.binId = mergedBinId;
        row.updatedAt = nowIso();
        await dPut(STORES.tx, row);
      }

      const stockRows = state.stock.filter(item => oldIds.has(String(item.binId || '')) || String(item.binId || '') === String(target.binId || ''));
      const kept = new Map();
      for (const row of stockRows) {
        const key = partKey(row.partNo);
        const existing = kept.get(key);
        if (!existing) {
          row.binId = mergedBinId;
          row.updatedAt = nowIso();
          row.status = statusFor(Number(row.quantity || 0), Number(row.minimumStock || 0));
          kept.set(key, row);
          await dPut(STORES.stock, row);
        } else if (row.id !== existing.id) {
          existing.quantity = Number(existing.quantity || 0) + Number(row.quantity || 0);
          existing.minimumStock = Math.max(Number(existing.minimumStock || 0), Number(row.minimumStock || 0));
          existing.status = statusFor(existing.quantity, existing.minimumStock);
          existing.updatedAt = nowIso();
          await dPut(STORES.stock, existing);
          await dDel(STORES.stock, row.id);
        }
      }

      for (const source of sourceBins) {
        source.active = false;
        source.mergedInto = mergedBinId;
        source.updatedAt = nowIso();
        await dPut(STORES.bins, source);
      }

      await audit('COMPONENT_COMMON_BIN_MERGE', 'Bin', mergedBinId, {
        source: `${rh.stationNo} + ${lh.stationNo}`,
        target: target.stationNo,
        automatic: true,
        mappings: history.mappings.length,
        consolidatedStockRows: history.stock.length,
        sourceGuns: gunCondition.sourceGuns,
        targetGuns: gunCondition.targetGuns,
        historyId: history.id
      });
      history.status = 'COMPLETED';
      history.completedAt = nowIso();
      await dPut('component_station_merge_history', history);
      mergedCount += 1;
    }

    await load();
    return mergedCount;
  }

  // Reconcile every existing RH/LH merge to one canonical physical bin.  This is
  // intentionally data-driven: mappings are authoritative for station identity,
  // while the active merged bin is authoritative for the physical bin.  It also
  // repairs legacy rows whose old source bin no longer exists in component_bins.
  async function reconcileRhLhCommonBinReferences() {
    const mergedBins = state.bins.filter(bin => {
      if (!bin || bin.active === false || bin.binKind) return false;
      const stations = Array.isArray(bin.mergedStations) ? bin.mergedStations : [];
      return stations.length >= 2 && stations.some(s => /(?:^|[\s_-])RH$/i.test(canonicalStation(s))) && stations.some(s => /(?:^|[\s_-])LH$/i.test(canonicalStation(s)));
    });
    if (!mergedBins.length) return;
    let changed = false;
    for (const merged of mergedBins) {
      const canonicalBinId = String(merged.binId || '').trim();
      if (!canonicalBinId) continue;
      const mergedStationKeys = new Set((merged.mergedStations || []).map(stationVariantKey));
      if (merged.stationNo) mergedStationKeys.add(stationVariantKey(merged.stationNo));
      const sourceBinIds = new Set();
      state.bins.forEach(bin => {
        if (!bin || bin.binKind || String(bin.binId || '') === canonicalBinId) return;
        if (bin.mergedInto === canonicalBinId || mergedStationKeys.has(stationVariantKey(bin.stationNo))) {
          if (bin.binId) sourceBinIds.add(String(bin.binId));
        }
      });
      // A mapping can retain an old bin ID even when that bin row was already
      // deleted.  Capture that ID so its stock/transaction rows are repaired too.
      state.mappings.forEach(mapping => {
        if (mapping && mergedStationKeys.has(stationVariantKey(mapping.stationNo)) && mapping.binId && String(mapping.binId) !== canonicalBinId) {
          sourceBinIds.add(String(mapping.binId));
        }
      });

      for (const mapping of state.mappings.filter(row => row && mergedStationKeys.has(stationVariantKey(row.stationNo)) && String(row.binId || '') !== canonicalBinId)) {
        mapping.binId = canonicalBinId;
        mapping.updatedAt = nowIso();
        await dPut(STORES.mappings, mapping);
        changed = true;
      }

      const affectedStock = state.stock.filter(row => row && (String(row.binId || '') === canonicalBinId || sourceBinIds.has(String(row.binId || ''))));
      const byPart = new Map();
      for (const row of affectedStock) {
        const key = partKey(row.partNo);
        if (!key) continue;
        const existing = byPart.get(key);
        if (!existing) {
          row.binId = canonicalBinId;
          row.status = statusFor(Number(row.quantity || 0), Number(row.minimumStock || 0));
          row.updatedAt = nowIso();
          byPart.set(key, row);
          await dPut(STORES.stock, row);
          if (String(row.binId) !== String(canonicalBinId)) changed = true;
        } else {
          existing.quantity = Number(existing.quantity || 0) + Number(row.quantity || 0);
          existing.minimumStock = Math.max(Number(existing.minimumStock || 0), Number(row.minimumStock || 0));
          existing.status = statusFor(existing.quantity, existing.minimumStock);
          existing.updatedAt = nowIso();
          await dPut(STORES.stock, existing);
          if (row.id !== existing.id) await dDel(STORES.stock, row.id);
          changed = true;
        }
      }

      for (const tx of state.tx.filter(row => row && (sourceBinIds.has(String(row.binId || '')) || String(row.binId || '') === canonicalBinId))) {
        if (String(tx.binId || '') !== canonicalBinId) {
          tx.binId = canonicalBinId;
          tx.updatedAt = nowIso();
          await dPut(STORES.tx, tx);
          changed = true;
        }
      }

      for (const bin of state.bins.filter(row => row && !row.binKind && row.id !== merged.id && mergedStationKeys.has(stationVariantKey(row.stationNo)) && row.active !== false)) {
        bin.active = false;
        bin.mergedInto = canonicalBinId;
        bin.updatedAt = nowIso();
        await dPut(STORES.bins, bin);
        changed = true;
      }
    }
    if (changed) await load();
  }

  async function ensureAutomaticOpeningSnapshot() { const previous = new Date(); previous.setMonth(previous.getMonth() - 1); const month = `${previous.getFullYear()}-${String(previous.getMonth() + 1).padStart(2, '0')}`; if (state.monthCloses.some(s => s.month === month && s.automatic)) {return;} const monthStart = `${month}-01`; const balances = {}; state.parts.forEach(p => { balances[p.partNo] = state.tx.filter(t => t.partNo === p.partNo && String(t.date || '').slice(0, 10) < monthStart).reduce((a, t) => a + (t.direction === 'OUT' ? -1 : 1) * Number(t.quantity || 0), 0); }); const snap = { id: `opening-auto-${month}`, month, balances, automatic: true, createdAt: nowIso(), userId: user().id || null }; await dPut(STORES.monthCloses, snap); state.monthCloses.push(snap); await audit('COMPONENT_MONTH_OPENING_SNAPSHOT_AUTO', 'Month End', snap.id, { month }); }
  function componentPreviewPage(page) { if (!pendingImport?.rows?.length) { return; } captureImportPreviewEdits(); const total = importPreviewFilteredRows().length; pendingImport.previewPage = Math.min(Math.max(0, Number(page) || 0), Math.max(0, Math.ceil(total / IMPORT_PREVIEW_PAGE_SIZE) - 1)); const content = document.getElementById('cm-import-preview-table-content'); if (content) { content.innerHTML = renderImportPreviewPage(); } }
  function importPreviewCell(index, field, value) { if (!pendingImport?.rows?.[index]) {return;} const row = pendingImport.rows[index]; row[field] = field === 'quantity' || field === 'requiredQty' ? Math.max(1, Number(value || 1)) : String(value ?? ''); if (field === 'stationNo') {row.stationNo = canonicalStation(value) || 'Station Not Assigned';} if (MAPPED_PART_FIELDS.includes(field)) { row.boldParts = row.boldParts || {}; row.boldParts[field] = splitBoldPartText(value); } row.sourceOnly = !componentPairsForRow(row).length; row.status = row.stationNo === 'Station Not Assigned' ? 'Station Pending' : row.sourceOnly ? 'Missing Component' : 'Ready for Mapping'; }
  function captureImportPreviewEdits(root = document) { if (!pendingImport?.rows) { return; } root.querySelectorAll('.cm-import-edit').forEach(input => importPreviewCell(Number(input.dataset.row), input.dataset.field, input.value)); }
  function applyImportPreviewEdits() { if (!pendingImport?.rows) {return;} if (pendingImport.manualEntry) {return toastMsg('Manual Gun review is read-only. Cancel and re-enter the form to change these values.', 'inf');} captureImportPreviewEdits(); pendingImport.rows.forEach(row => { row.sourceOnly = !componentPairsForRow(row).length; }); pendingImport.sourceOnlyCount = pendingImport.rows.filter(row => row.sourceOnly).length; pendingImport.previewHtml = ''; state.importDraft = pendingImport; importView(); toastMsg('Import preview edits applied', 'suc'); }
  async function deleteHistoricalImportBatch(batchId) { if (!canComponent('replacement', true)) { return; } const rows = (await gAll(STORES.historicalConsumption)).filter(row => row.importBatchId === batchId); if (!rows.length) { return toastMsg('Historical import batch not found', 'er'); } if (typeof confirm === 'function' && !confirm(`Delete historical import batch ${batchId} (${rows.length} rows)? Current stock will not change.`)) { return; } for (const row of rows) { await dDel(STORES.historicalConsumption, row.id); } await audit('COMPONENT_HISTORICAL_CONSUMPTION_DELETE', 'Historical Consumption', batchId, { batchId, deletedRows: rows.length, stockChanged: false }); await load(); history(); toastMsg(`Historical import batch deleted: ${rows.length} rows`, 'suc'); }
  function replacementDrillDown(id) { const replacement = state.replacements.find(r => r.id === id); if (!replacement) {return;} const lifecycle = state.repairs.filter(r => r.sourceReplacementId === id); const tx = state.tx.filter(t => t.metadata?.id === id || t.metadata?.sourceReplacementId === id); const rows = [...lifecycle.map(r => `<tr><td>Lifecycle</td><td>${esc(r.status)}</td><td>${r.quantity}</td><td>${esc(r.date || r.createdAt)}</td><td>${esc(r.username || '')}</td></tr>`), ...tx.map(t => `<tr><td>Stock</td><td>${esc(t.type)}</td><td>${t.direction === 'OUT' ? '-' : '+'}${t.quantity}</td><td>${esc(t.date)}</td><td>${esc(t.username)}</td></tr>`)].join(''); shell('Replacement Transaction Drill-down', `<div class="alrt alrt-b"><strong>${esc(replacement.oldPartNo ? partDisplayWithComment(replacement.oldPartNo) : '')} → ${esc(replacement.newPartNo || replacement.partNo ? partDisplayWithComment(replacement.newPartNo || replacement.partNo) : '')}</strong><br>Station: ${esc(replacement.stationNo)} | Gun: ${esc(replacement.gunReferenceNo)} | Qty: ${replacement.quantity}</div>${table(['Source','Status / Type','Quantity','Date','User'], rows, 'No linked lifecycle or stock transactions found.')}`); }
  function ambiguousPartRows() {
    const fields = [['Fix Shank', 'fixShank'], ['Moving Shank', 'movingShank'], ['Fix Adaptor', 'fixAdaptor'], ['Moving Adaptor', 'movingAdaptor'], ['Fix Holder', 'fixHolder'], ['Moving Holder', 'movingHolder']];
    return (state.gunRows || []).filter(row => row && row.ambiguousResolved !== true).map(row => {
      const choices = fields.map(([label, field]) => {
        const headerIndex = (row.sourceHeaders || []).findIndex(header => likelyField(header, field));
        const raw = headerIndex >= 0 ? splitBoldPartText((row.sourceValues || [])[headerIndex]) : [];
        const bold = Array.isArray(row.boldParts?.[field]) ? row.boldParts[field].filter(validMappedPartNo) : [];
        const original = bold[0] || '';
        const alternatives = raw.filter(part => !bold.some(candidate => samePartNo(candidate, part)));
        const candidates = [...(original ? [original] : []), ...alternatives];
        // Bold explicitly marks the Original; zero stock must not turn it back into a pending selection.
        return candidates.length > 1 && !original ? { label, field, original, alternatives, candidates } : null;
      }).filter(Boolean);
      return choices.length ? { row, choices } : null;
    }).filter(Boolean);
  }
  function ambiguousPartSection() {
    const items = ambiguousPartRows();
    if (!items.length) { return ''; }
    const body = items.map(({ row, choices }, itemIndex) => `<tr><td>${esc(row.sourceSheet || '')}</td><td>${esc(row.sourceRow || '')}</td><td>${esc(row.stationNo || 'Station Not Assigned')}</td><td>${esc(row.gunReferenceNo || '')}</td><td>${choices.map((choice, choiceIndex) => `<div class="fr"><label class="fl">${esc(choice.label)} — select Original or Alternative</label><input class="fi cm-ambiguous-part" list="cm-ambiguous-part-${itemIndex}-${choiceIndex}" data-gun-row="${esc(row.id)}" data-field="${esc(choice.field)}" placeholder="Type or select Part No."><datalist id="cm-ambiguous-part-${itemIndex}-${choiceIndex}">${choice.candidates.map((part, index) => { const role = choice.original ? (samePartNo(part, choice.original) ? 'Original' : `Alternative ${index}`) : `Candidate ${index + 1}`; const stock = partStockQuantity(part); return `<option value="${esc(part)}" label="${role} — Stock ${stock}"></option>`; }).join('')}</datalist><small class="muted">${choice.original ? `Bold Original: ${esc(choice.original)} — Stock ${partStockQuantity(choice.original)}` : 'No Part No. is bold. No Original is assumed; choose one candidate below.'}. Alternatives: ${choice.alternatives.map(part => `${esc(part)} (Stock ${partStockQuantity(part)})`).join(', ') || (choice.original ? 'None' : 'Not assigned until selection')}</small></div>`).join('')}</td><td><span class="pill pill-y">PENDING</span></td><td>${btn('Save selected Part No.', `componentSaveAmbiguousGun('${esc(row.id)}')`)}</td></tr>`).join('');
    return `<div class="card cm-ambiguous-card" data-style="width:100%;grid-column:1/-1"><div class="card-hd">Part Selection Pending — Original / Alternative</div><div class="alrt alrt-r"><strong>Action Required:</strong> Each row is pending until a Part No. is selected for every ambiguous field. Bold Part No. is the Original. When nothing is bold, no Part No. is assumed to be Original; the user-selected Part becomes Original and all remaining candidates become Alternatives.</div><div class="cm-ambiguous-wrap" data-style="width:100%;overflow:visible">${table(['Source Sheet', 'Source Row', 'Station', 'Gun Reference', 'Original / Alternative Choices', 'Selection Status', 'Action'], body, 'No Part No. choices require review.', '', ['Station','Gun Reference','Original / Alternative Choices'])}</div></div>`;
  }
  async function saveAmbiguousGun(id) {
    if (!canComponent('mapping', true)) { return; }
    const row = (state.gunRows || []).find(item => item.id === id);
    if (!row) { return; }
    const selects = [...document.querySelectorAll(`.cm-ambiguous-part[data-gun-row="${CSS.escape(id)}"]`)];
    if (!selects.length) { return toastMsg('No ambiguous Part No. choices found', 'er'); }
    if (selects.some(input => !String(input.value || '').trim())) { return toastMsg('Select a Part No. for every pending component field before saving', 'er'); }
    if (selects.some(input => input.value && !validMappedPartNo(input.value))) { return toastMsg('Type the correct Part No. or choose an Original/Latest suggestion', 'er'); }
    row.boldParts = { ...(row.boldParts || {}) };
    row.partOptions = { ...(row.partOptions || {}) };
    selects.forEach(select => {
      const field = select.dataset.field;
      const selected = vendorPartNo(select.value).trim();
      const existing = row.partOptions[field] || {};
      const candidates = [...(existing.candidates || []), ...(existing.alternatives || []), selected]
        .filter(validMappedPartNo)
        .filter((part, index, all) => all.findIndex(candidate => samePartNo(candidate, part)) === index);
      row.boldParts[field] = [selected];
      row.partOptions[field] = {
        original: selected,
        alternatives: candidates.filter(part => !samePartNo(part, selected)),
        candidates
      };
    });
    row.sourceOnly = false;
    row.ambiguousResolved = true;
    row.updatedAt = nowIso();
    await dPut('component_gun_rows', row);
    await load();
    await backfillMappingsFromGunRows();
    await load();
    await migrateExistingRhLhCommonBins();
    await reconcileRhLhCommonBinReferences();
    await load();
    await rebuildGunCountAggregate();
    // Re-read the persisted rows before rendering metrics so BI never uses a
    // stale in-memory mapping after the asynchronous backfill/rebuild.
    await load();
    if (state.tab === 'bi-dashboard') { biDashboard(); } else if (state.tab === 'matrix') { matrix(); }
    toastMsg('Selected Part No. saved and Gun Mapping updated', 'suc');
  }
  function sourceOnlyGuns() { return (state.gunRows || []).filter(row => row.sourceOnly); }
  async function assignManualPartToSourceGun(id) {
    if (!canComponent('mapping', true)) { return; }
    const row = (state.gunRows || []).find(item => item.id === id);
    if (!row) { return; }
    const position = await componentInputDialog('Manual Mapping — Component Position', `Position (${POSITIONS.join(', ')})`, 'Fix Shank');
    if (position === null) { return; }
    if (!POSITIONS.includes(position)) { return toastMsg(`Position must be one of: ${POSITIONS.join(', ')}`, 'er'); }
    const partNo = vendorPartNo(await componentInputDialog('Manual Mapping — Part No.', 'Enter Original Part No. (alternative Part Nos. can be added later)', '')).trim();
    if (!validMappedPartNo(partNo)) { return toastMsg('A valid Part No. is required', 'er'); }
    let part = partByNo(partNo);
    if (!part) {
      part = { id: uid('part'), partNo, description: `${position} ${partNo}`, componentType: position.toLowerCase().includes('shank') ? 'Copper Shank' : position.toLowerCase().includes('adaptor') ? 'Adaptor' : 'Holder', active: true, minimumStock: 0, status: 'ZERO STOCK', createdAt: nowIso(), updatedAt: nowIso() };
      await dPut(STORES.parts, part);
    }
    row.boldParts = { ...(row.boldParts || {}), [PART_OPTION_FIELDS[position] || position]: [partNo] };
    row.partOptions = { ...(row.partOptions || {}), [PART_OPTION_FIELDS[position] || position]: { original: partNo, alternatives: [], candidates: [partNo] } };
    const componentField = PART_OPTION_FIELDS[position] || String(position).replace(/\s/g, '').replace(/^./, c => c.toLowerCase());
    row[componentField] = partNo;
    row.sourceOnly = false;
    row.ambiguousResolved = true;
    row.updatedAt = nowIso();
    await dPut('component_gun_rows', row);
    await load();
    await backfillMappingsFromGunRows();
    await load();
    await migrateExistingRhLhCommonBins();
    await reconcileRhLhCommonBinReferences();
    await load();
    await rebuildGunCountAggregate();
    await load();
    openSourceOnlyGuns();
    toastMsg(`Manual Part No. ${partNo} assigned to ${position}; mapping created`, 'suc');
  }
  function openSourceOnlyGuns() {
    const rows = sourceOnlyGuns();
    const body = rows.map((row, index) => `<tr><td>${index + 1}</td><td>${esc(row.stationNo || 'Station Not Assigned')}</td><td>${esc(row.gunReferenceNo || '')}</td><td>${esc(row.sourceSheet || '')}</td><td>${esc(row.sourceRow || '')}</td><td>All six Gun Count component Part No. fields are blank</td><td>${btn('Enter Manual Part No.', `componentAssignManualPartToSourceGun('${esc(row.id)}')`)}</td></tr>`).join('');
    shell('Unassigned / Source-only Guns', `<div class="alrt alrt-y"><strong>${rows.length} source-only rows</strong> — no Part No. exists in Fixed Shank, Moving Shank, Fixed Adaptor, Moving Adaptor, Fixed Holder, or Moving Holder. You can enter a Part No. manually for each row.</div>${table(['SR No.', 'Station', 'Gun Reference', 'Source Sheet', 'Source Row', 'Reason', 'Action'], body, 'No source-only guns found.', '', ['Station','Gun Reference','Source Sheet','Reason'])}<div class="btn-row">${btn('Open Gun Register', "componentOpen('gun-register')")}</div>`);
  }
  function gunRegister() { const query = String(document.getElementById('cm-gun-register-search')?.value || '').toLowerCase(); const status = String(document.getElementById('cm-gun-register-status')?.value || 'ALL'); const rows = state.gunRows.filter(r => { const hay = [r.stationNo, r.gunReferenceNo, r.sourceSheet, r.sourceRow, r.sourceFile, ...(r.sourceHeaders || []), ...(r.sourceValues || [])].join(' ').toLowerCase(); const current = r.stationNo === 'Station Not Assigned' ? 'Station Pending' : r.sourceOnly ? 'Missing Component' : 'Ready for Mapping'; return (!query || hay.includes(query)) && (status === 'ALL' || current === status); }).sort((a,b) => `${a.stationNo}${a.gunReferenceNo}${a.sourceSheet}${a.sourceRow}`.localeCompare(`${b.stationNo}${b.gunReferenceNo}${b.sourceSheet}${b.sourceRow}`)); const body = rows.map((r,i) => { const current = r.stationNo === 'Station Not Assigned' ? 'Station Pending' : r.sourceOnly ? 'Missing Component' : 'Ready for Mapping'; return `<tr><td>${i+1}</td><td>${esc(current)}</td><td>${esc(r.stationNo)}</td><td>${esc(r.gunReferenceNo)}</td><td>${esc(r.sourceSheet)}</td><td>${esc(r.sourceRow)}</td><td><details><summary>Source</summary>${esc((r.sourceHeaders||[]).map((h,j)=>`${h}: ${(r.sourceValues||[])[j] ?? ''}`).join(' | '))}</details></td></tr>`; }).join(''); shell('Gun Register — All Imported Source Rows', `<div class="alrt alrt-b">Every valid source gun row is retained here, including rows without components. Source-only rows do not create stock or labels until components are assigned.</div><div class="g3"><input class="fi" id="cm-gun-register-search" placeholder="Search Station, Gun, Part No., Components, Sheet" value="${esc(query)}" oninput="componentGunRegister()"><select class="fi" id="cm-gun-register-status" onchange="componentGunRegister()"><option value="ALL" ${status==='ALL'?'selected':''}>All statuses</option><option value="Ready for Mapping" ${status==='Ready for Mapping'?'selected':''}>Ready for Mapping</option><option value="Station Pending" ${status==='Station Pending'?'selected':''}>Station Pending</option><option value="Missing Component" ${status==='Missing Component'?'selected':''}>Missing Component</option></select><div>${cardMetric(rows.length,'Rows shown')}</div></div>${table(['SR No.','Status','Station','Gun Reference','Sheet','Source Row','Source Data'], body, 'No imported source gun rows found.')}`); }

  function open(tab) { if (!canComponent('view')) {return;} if ((tab || 'dashboard') === 'guide' && !canComponent('guide')) {return;} if (window.isShankMappingEnabled && !window.isShankMappingEnabled()) { toastMsg('This feature is disabled by the developer', 'inf'); return; } state.tab = tab || 'dashboard'; document.querySelectorAll('.sec').forEach(s => s.classList.remove('active')); document.querySelectorAll('.ni').forEach(n => n.classList.remove('active')); document.getElementById('s-component')?.classList.add('active'); document.getElementById('n-component')?.classList.add('active'); const componentMenuItem = [...document.querySelectorAll('.ng[aria-label=\"Shank Mapping\"] .ni')].find(item => { const action = item.getAttribute('data-onclick') || ''; return action.includes(`componentOpen('${state.tab}')`) || (state.tab === 'procurement' && action.includes('componentConsumptionAnalyticsOpen')); }); if (componentMenuItem) { document.getElementById('n-component')?.classList.remove('active'); document.querySelectorAll('.ng[aria-label=\"Shank Mapping\"] .ni').forEach(item => item.classList.remove('active')); componentMenuItem.classList.add('active'); } document.getElementById('pg-title').textContent = `Shank Mapping — ${{'stock-zero':'Zero Stock','stock-low':'Low Stock',bins:'Bin Management — Pencil','bins-copy':'Bin Management — Shank','bi-dashboard':'BI Dashboard'}[state.tab] || (state.tab[0].toUpperCase() + state.tab.slice(1))}`; ({ dashboard, 'bi-dashboard': biDashboard, procurement, guide, replacement, stock, 'stock-low': () => { window.componentBiNavigationContext = { ...(window.componentBiNavigationContext || {}), stockStatus: 'LOW STOCK' }; zeroStockView(); }, 'stock-zero': zeroStockView, 'manual-stock': manualStock, 'types-shank': typesOfShank, parts, matrix, bins: pencilBins, merge: stationMerge, aliases: stationAliases, repair, history, reports, labels, requiredQuantity, import: importView, verify, 'gun-register': gunRegister, 'bins-copy': bins }[state.tab] || dashboard)(); }
  async function init() { if (componentInitialized) {return;} try { await load(); const recovered = await backfillMappingsFromGunRows(); if (recovered) { await load(); } await ensurePencilBins(); await load(); await migrateExistingRhLhCommonBins(); await load(); await reconcileRhLhCommonBinReferences(); await migrateMappedCandidateBinAllocations(); await migrateStockMetadataAndStatuses(); await ensureAutomaticOpeningSnapshot(); componentInitialized = true; if (state.tab) {open(state.tab);} } catch (error) { console.error('[ComponentManagement] init failed', error); toastMsg('Component Management could not initialize', 'er'); } }

  window.componentOpenMissingBinAllocations = openMissingBinAllocations;
  window.componentAssignManualPartToSourceGun = assignManualPartToSourceGun;
  window.componentOpen = open;
  window.componentGuidePrint = componentGuidePrint;
  window.componentGuideExport = componentGuideExport;
  window.componentCancelImportProcessing = () => { if (pendingImport) {pendingImport.cancelled = true;} };
  window.componentBuildImportPreview = componentBuildImportPreview;
  window.componentEditMapping = editMapping;
  window.componentDeleteMapping = deleteMapping;
  window.componentDeleteSelectedMappings = deleteSelectedMappings;
  window.componentDeleteGunGroup = deleteGunGroup;
  window.componentRollbackImport = rollbackImport;
  window.componentPurgeImportedWorkbook = purgeImportedWorkbook;
  window.componentPreviewImportRollback = previewImportRollback;
  window.componentDeleteImport = deleteImport;
  window.componentRemoveImportHistory = removeImportHistory;
  window.componentSavePart = savePart;
  window.componentFilterRequiredRows = componentFilterRequiredRows;
  window.componentClearRequiredFilters = componentClearRequiredFilters;
  window.componentClearPartMasterFilters = clearPartMasterFilters;
  window.componentEditPart = editPart;
  window.componentReceiveStock = receiveStock;
  window.componentDownloadStockEntryTemplate = downloadStockEntryTemplate;
  window.componentCommitStockImport = commitStockImport;
  window.componentClearStockImport = clearStockImport;
  window.componentUndoAllocation = undoAllocation;
  window.componentExportAllocationPlan = exportAllocationPlan;
  window.componentExportAllocationPlanPdf = exportAllocationPlanPdf;
  window.componentSaveManualStockAdjustment = saveManualStockAdjustment;
  window.componentFilterTypesOfShank = query => filterTypesOfShank(query);
  window.componentSaveVerification = saveVerification;
  window.componentFilterVerificationRows = filterVerificationRows;
  window.componentSelectAllInSection = selectAllInSection;
  window.componentSaveReplacement = saveReplacement;
  window.componentReplacementImport = replacementImportView;
  window.componentCommitReplacementImport = commitReplacementImport;
  window.componentSaveManualHistoricalConsumption = saveManualHistoricalConsumption;
  window.componentDownloadHistoricalRejected = downloadHistoricalRejected;
  window.componentDownloadHistoricalTemplate = downloadHistoricalTemplate;
  window.componentDeleteHistoricalImportBatch = deleteHistoricalImportBatch;
      window.componentCompleteRepair = completeRepair;
      window.componentRepairReturn = repairReturn;
  window.componentFilterHistory = filterHistory;
  window.componentHistoryPartChanged = componentHistoryPartChanged;
  window.componentHistoryStationChanged = componentHistoryStationChanged;
  window.componentReplacementDrillDown = replacementDrillDown;
  window.componentSaveStationAlias = saveStationAlias;
  window.componentEditStationAlias = editStationAlias;
  window.componentDeactivateStationAlias = deactivateStationAlias;
  window.componentCancelExport = cancelComponentExport;
  window.componentRetryExport = retryComponentExport;
  window.componentApplyImportPreviewEdits = applyImportPreviewEdits;
  window.componentExportReport = exportReport;
  window.componentExportAccountability = exportAccountability;
  window.componentPreviewLabels = previewLabels;
  window.componentPrintLabels = printLabels;
  window.componentPreviewBinLabels = previewBinLabels;
  window.componentPrintBinLabels = printBinLabels;
  window.componentPreviewPencilLabels = () => openPencilLabels(false);
  window.componentPrintPencilLabels = () => openPencilLabels(true);
  window.componentDownloadTemplate = downloadTemplate;
  window.componentRefreshDashboardAnalytics = refreshDashboardAnalytics;
  window.componentExportAnalytics = exportAnalytics;
  window.componentExportRequiredQuantity = exportRequiredQuantity;
  window.componentExportTypesShankExcel = exportTypesShankExcel;
  window.componentExportTypesShankPdf = exportTypesShankPdf;
  window.componentExportStockExcel = exportStockExcel;
  window.componentExportStockPdf = exportStockPdf;
  window.componentExportMappingExcel = exportMappingExcel;
  window.componentExportMappingPdf = exportMappingPdf;
  window.componentExportBinsExcel = exportBinsExcel;
  window.componentExportPencilBinsExcel = exportPencilBinsExcel;
  window.componentExportPencilBinsPdf = exportPencilBinsPdf;
  window.componentFilterPencilBinRows = filterPencilBinRows;
  window.componentClearPencilBinFilters = clearPencilBinFilters;
  window.componentExportBinsPdf = exportBinsPdf;
  window.componentExportHistoryExcel = exportHistoryExcel;
  window.componentExportHistoryPdf = exportHistoryPdf;
  window.componentPrintRequiredQuantity = printRequiredQuantity;
  window.componentExportLowStock = exportLowStock;
  window.componentExportLowStockExcel = exportLowStockExcel;
  window.componentExportLowStockPdf = exportLowStockPdf;
  window.componentExportZeroStockExcel = exportZeroStockExcel;
  window.componentExportZeroStockPdf = exportZeroStockPdf;
  window.componentEmailLowStock = emailLowStock;
  window.componentOpenProcurement = () => open('procurement');
  window.componentSaveForecastConfig = saveForecastConfig;
  window.componentCreateProcurementOrder = createProcurementOrder;
  window.componentChangeProcurementStatus = changeProcurementStatus;
  window.componentReceiveProcurementOrder = receiveProcurementOrder;
  window.componentProcurementDrillDown = procurementDrillDown;
  window.componentGetProcurementRows = procurementRows;
  window.componentExportProcurement = exportProcurement;
  window.componentExportProcurementExcel = exportProcurementExcel;
  window.componentExportProcurementPdf = exportProcurementPdf;
  window.componentOpenProcurementSummary = openProcurementSummary;
  window.componentCloseProcurementSummary = closeProcurementSummary;
  window.componentRefreshProcurement = () => procurement();
  window.componentExportBIDashboard = exportBIDashboard;
  window.componentRefreshBIDashboard = () => biDashboard();
  window.componentUpdateBIDashboardStations = updateBIDashboardStations;
  window.componentClearBIDashboardFilters = clearBIDashboardFilters;
  window.componentRunShankBIQuery = runShankBINaturalQuery;
  window.componentApplyBISample = componentApplyBISample;
  window.componentUpdateBIQueryPreview = componentUpdateBIQueryPreview;
  window.componentEditBIQuery = componentEditBIQuery;
  window.refreshBISampleOptions = refreshBISampleOptions;
  window.componentClearProcurementFilters = clearProcurementFilters;
  window.componentFilterStockRows = filterStockRows;
  window.componentSortStockStatusTable = sortStockStatusTable;
  window.componentRefreshStockFilterControls = refreshStockFilterControls;
  window.componentRefreshStockFilterBins = refreshStockFilterBins;
  window.componentClearStockFilters = clearStockFilters;
  window.componentFilterMappingRows = filterMappingRows;
  window.componentClearMappingFilters = clearMappingFilters;
  window.componentFilterBinRows = filterBinRows;
  window.componentClearBinFilters = clearBinFilters;
      window.componentExportBinReconciliation = exportBinReconciliation;
  window.componentFilterLifecycleRows = filterLifecycleRows;
  window.componentClearLifecycleFilters = clearLifecycleFilters;
  window.componentOpenStationFromQr = openStationFromQr;
  window.componentAnalyticsBreakdown = analyticsBreakdown;
  window.componentChooseImport = chooseImport;
  window.componentOpenManualGunForm = openManualGunForm;
  window.componentCommitImport = commitImport;
  window.componentSetImportTrial = setImportTrial;
  window.componentAddPerson = addPerson;
  window.componentPreviewStationMerge = previewStationMerge;
  window.componentMergeStation = mergeStation;
  window.componentRollbackStationMerge = rollbackStationMerge;
  window.componentOpenAliases = () => open('aliases');
  window.componentGunRegister = gunRegister;
  window.componentOpenSourceOnlyGuns = openSourceOnlyGuns;
  window.componentSaveAmbiguousGun = saveAmbiguousGun;
  window.componentEditBin = editBin;
  window.componentGetLabelRows = () => labelRows();
  window.componentCalculateGunCount = rows => calculateGunCount(rows);
  window.componentGetGunCountMetrics = () => gunCountService ? gunCountService.calculateMetrics(state.gunRows || [], state.mappings || []) : null;
  window.componentGetGunCountAggregate = async () => gAll(STORES.gunCounts);
  window.componentExportGunCountReconciliation = exportGunCountReconciliation;
  window.componentExportBackupData = async () => { const stores = [...new Set(COMPONENT_IMPORT_DATA_STORES.concat([STORES.imports, STORES.audit, STORES.people, STORES.gunCounts, 'component_mapping_revisions', 'component_import_configs', 'component_station_merge_history', 'component_analytics_config', 'component_printer_profiles', 'component_qr_audit', STORES.partConfigs, STORES.orders]) )]; const out = {}; for (const store of stores) { try { out[store] = await gAll(store); } catch (error) { out[store] = []; console.warn(`[component backup] store unavailable: ${store}`, error); } } return out; };
  window.componentRestoreBackupData = async data => {
    if (!data || typeof data !== 'object') throw new Error('Invalid component backup payload');
    const stores = Object.keys(data).filter(name => STORES[name] || name.startsWith('component_') || name === 'maintenance_people');
    const snapshot = {};
    for (const store of stores) snapshot[store] = await gAll(store);
    const restored = [];
    try {
      for (const store of stores) {
        if (!Array.isArray(data[store])) throw new Error('Invalid backup store: ' + store);
        await dClr(store);
        for (const row of data[store]) await dPut(store, row);
        const count = (await gAll(store)).length;
        if (count !== data[store].length) throw new Error('Restore verification failed: ' + store);
        restored.push(store);
      }
      await load();
      return { ok: true, restoredStores: restored };
    } catch (error) {
      for (const store of stores) {
        try { await dClr(store); for (const row of snapshot[store]) await dPut(store, row); } catch (rollbackError) { console.error('[component backup] rollback failed', store, rollbackError); }
      }
      await load();
      throw new Error('Component restore rolled back: ' + error.message);
    }
  };

  window.componentFilterLabels = query => filterLabels(query);
  window.componentSavePrinterProfile = () => savePrinterProfile();
  window.componentLoadPrinterProfile = name => loadPrinterProfile(name);
  window.componentSelectReportMonth = month => { state.reportMonth = /^\d{4}-\d{2}$/.test(String(month || '')) ? month : today().slice(0, 7); reports(); };
  window.componentCloseMonth = month => closeMonth(month);
  window.componentReopenMonth = month => reopenMonth(month);
  window.componentZeroDrillDown = (partNo, binId) => zeroDrillDown(partNo, binId);
  window.componentSearchStation = query => searchStation(query);
  window.componentSearchPart = query => searchPart(query);
  window.componentGetPartVariantPairs = () => { const finder = window.PartNumberUtils?.findVariantPairs; return typeof finder === 'function' ? finder(state.parts.map(part => part.partNo)) : []; };
      window.componentGetMonthEndRows = month => monthEndRows(month || today().slice(0, 7));
      window.componentSaveMonthOpeningSnapshot = month => saveMonthOpeningSnapshot(month);
  window.componentPreviewPage = page => componentPreviewPage(page);
  window.componentGetImportProgress = () => ({ progress: pendingImport?.commitProgress ?? pendingImport?.progress ?? 0, total: pendingImport?.rows?.length || 0, phase: pendingImport?.confirmed ? 'committing' : pendingImport?.rows?.length ? 'preview-ready' : 'parsing' });
  window.componentGetImportSummary = () => pendingImport ? { rowsScanned: pendingImport.rows?.length || 0, sourceGunRows: pendingImport.sourceGunRows || pendingImport.rows?.length || 0, componentMappingRows: pendingImport.componentMappingRows || pendingImport.rows?.filter(r => !r.sourceOnly).length || 0, sourceOnlyRows: pendingImport.sourceOnlyCount || 0, duplicateSourceRows: pendingImport.duplicateSourceRows || 0, invalidRows: pendingImport.invalidRows || pendingImport.skipped?.length || 0, reconciliation: pendingImport.reconciliation || null, warnings: pendingImport.warnings || [], skipped: pendingImport.skipped || [], selectedSheets: pendingImport.selectedSheets || [] } : null;
      window.componentNormalizeStation = canonicalStation;
      window.componentVendorPartNumberRule = SHANK_MAPPING_VENDOR_PART_NUMBER_RULE;
      window.componentResetShankMappingData = resetShankMappingData;
      window.componentManagementInit = init;
  if (window.databaseReady) {init();} else {document.addEventListener('databaseReady', init, { once: true });}
})();
