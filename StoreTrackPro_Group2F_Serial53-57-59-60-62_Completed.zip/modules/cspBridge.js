// ============================================================================
// cspBridge.js — CSP Compatibility Layer for StoreTrack Pro V8
// ----------------------------------------------------------------------------
// Purpose:
//   Under a strict Content-Security-Policy (script-src 'self'; style-src 'self';
//   no 'unsafe-inline', no 'unsafe-eval') the browser will:
//     1. Refuse to execute onclick="", onchange="", oninput="", onkeydown="",
//        onfocus="", onblur="" (and similar) HTML attributes.
//     2. Refuse to apply style="" HTML attributes AND refuse `el.style.cssText=`
//        / `el.setAttribute('style', ...)` assignments.
//
//   This module restores full functionality WITHOUT using eval() or
//   `new Function()` (both of which require 'unsafe-eval' and are therefore
//   not usable under the required policy).
//
//   Strategy:
//     - Every inline `onXXX="expr"` attribute in the markup/templates was
//       mechanically renamed to `data-onXXX="expr"` (data-* attributes are
//       inert as far as the browser/CSP is concerned — they are just text).
//     - Every inline `style="css"` attribute was renamed to `data-style="css"`.
//     - This module attaches real `addEventListener` delegated handlers on
//       `document` for every event type that appears in the codebase, reads
//       the matching `data-onXXX` attribute at event time, and evaluates the
//       (small, well-defined) JS expression it contains using a hand-written,
//       whitelisted, side-effect-scoped expression interpreter (see
//       CSPExpr below) — never eval/Function.
//     - A MutationObserver (plus an initial sweep) finds every element with
//       a `data-style` attribute and applies it via direct CSSOM property
//       assignment (`el.style.propertyName = value`), which the CSP spec
//       explicitly permits even without 'unsafe-inline' (only the *attribute*
//       string / cssText assignment is restricted, not per-property sets).
// ============================================================================

(function () {
  'use strict';

  // ---------------------------------------------------------------------
  // 1. Safe CSS application (replaces style="" / el.style.cssText = "")
  // ---------------------------------------------------------------------

  function cssPropToCamel(prop) {
    if (prop.startsWith('--')) {return prop;} // custom property, handled separately
    return prop.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
  }

  /**
   * Applies a CSS declaration string ("color:red;font-size:10px") to an
   * element using individual CSSOM property assignment only — this is the
   * pattern MDN documents as unaffected by style-src (no 'unsafe-inline'
   * needed): https://developer.mozilla.org/.../style-src
   */
  function applyCssText(el, cssText) {
    if (!el || !cssText) {return;}
    const decls = String(cssText).split(';');
    for (let i = 0; i < decls.length; i++) {
      const decl = decls[i];
      const idx = decl.indexOf(':');
      if (idx === -1) {continue;}
      const prop = decl.slice(0, idx).trim();
      const val = decl.slice(idx + 1).trim();
      if (!prop || val === '') {continue;}
      try {
        if (prop.startsWith('--')) {
          el.style.setProperty(prop, val); // custom properties must use setProperty
        } else {
          el.style[cssPropToCamel(prop)] = val;
        }
      } catch (err) {
        // Unknown/invalid property — skip rather than break the whole batch.
        console.warn('[cspBridge] could not apply style prop', prop, val, err);
      }
    }
  }
  window.applyCssText = applyCssText; // exposed for direct calls replacing old cssText= lines

  function processDataStyle(el) {
    if (!el || el.nodeType !== 1) {return;}
    const raw = el.getAttribute && el.getAttribute('data-style');
    if (raw) {
      applyCssText(el, raw);
      el.removeAttribute('data-style');
    }
  }

  function sweepForDataStyle(root) {
    if (!root || root.nodeType !== 1 && root.nodeType !== 11) {return;}
    if (root.nodeType === 1) {processDataStyle(root);}
    const list = root.querySelectorAll ? root.querySelectorAll('[data-style]') : [];
    for (let i = 0; i < list.length; i++) {processDataStyle(list[i]);}
  }

  // Initial sweep for anything already in the DOM (e.g. static index.html markup).
  document.addEventListener('DOMContentLoaded', () => sweepForDataStyle(document.documentElement));

  // Ongoing sweep for anything injected later via innerHTML/insertAdjacentHTML.
  const styleObserver = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType === 1) {sweepForDataStyle(node);}
      }
    }
  });
  styleObserver.observe(document.documentElement, { childList: true, subtree: true });

  // ---------------------------------------------------------------------
  // 2. Safe expression interpreter (replaces eval/new Function for
  //    evaluating the text that used to sit inside onclick="...")
  // ---------------------------------------------------------------------
  //
  //  Supports the actual grammar found in StoreTrack's inline handlers:
  //    - number / string / true / false / null literals
  //    - `this` (bound to the element that owns the data-onXXX attribute)
  //    - `event` (bound to the native Event object)
  //    - identifier lookup (resolved against window, i.e. real app globals)
  //    - member access:  a.b   a['b']
  //    - calls:           f(a, b)   a.b(c)
  //    - unary:           ! -
  //    - binary:          || && === !== == != < > <= >= + - * / %
  //    - ternary:         a ? b : c
  //    - simple conditionals: "if (condition) action()"
  //    - statement lists: "stmt1; stmt2" (used by a couple of handlers)
  //    - assignment only to the Smart Import map and Batch OUT cart quantities
  //
  //  This is NOT a general JS engine — it only understands this grammar.
  //  Anything outside it throws, which is intentionally conservative.

  const CSPExpr = (function () {
    function tokenize(src) {
      const toks = [];
      let i = 0;
      const n = src.length;
      const isIdStart = c => /[A-Za-z_$]/.test(c);
      const isIdPart = c => /[A-Za-z0-9_$]/.test(c);
      while (i < n) {
        const c = src[i];
        if (/\s/.test(c)) { i++; continue; }
        if (c === '"' || c === "'") {
          const quote = c; let j = i + 1; let str = '';
          while (j < n && src[j] !== quote) {
            if (src[j] === '\\' && j + 1 < n) { str += unescapeChar(src[j + 1]); j += 2; }
            else { str += src[j]; j++; }
          }
          toks.push({ t: 'str', v: str }); i = j + 1; continue;
        }
        if (/[0-9]/.test(c)) {
          let j = i; while (j < n && /[0-9.]/.test(src[j])) {j++;}
          toks.push({ t: 'num', v: parseFloat(src.slice(i, j)) }); i = j; continue;
        }
        if (isIdStart(c)) {
          let j = i; while (j < n && isIdPart(src[j])) {j++;}
          const word = src.slice(i, j);
          if (word === 'true') {toks.push({ t: 'bool', v: true });}
          else if (word === 'false') {toks.push({ t: 'bool', v: false });}
          else if (word === 'null') {toks.push({ t: 'null', v: null });}
          else {toks.push({ t: 'id', v: word });}
          i = j; continue;
        }
        const two = src.slice(i, i + 2);
        const three = src.slice(i, i + 3);
        if (three === '===' || three === '!==') { toks.push({ t: 'op', v: three }); i += 3; continue; }
        if (['||', '&&', '==', '!=', '<=', '>='].includes(two)) { toks.push({ t: 'op', v: two }); i += 2; continue; }
        if ('+-*/%<>!?:,.()[]='.includes(c)) { toks.push({ t: 'op', v: c }); i++; continue; }
        if (c === ';') { toks.push({ t: 'semi', v: ';' }); i++; continue; }
        // Unknown character — skip defensively rather than crash the whole app.
        i++;
      }
      return toks;
    }

    function unescapeChar(c) {
      switch (c) {
        case 'n': return '\n'; case 't': return '\t'; case 'r': return '\r';
        case '\\': return '\\'; case "'": return "'"; case '"': return '"';
        default: return c;
      }
    }

    function parse(toks) {
      let p = 0;
      const peek = () => toks[p];
      const next = () => toks[p++];
      const expectOp = (v) => { const t = next(); if (!t || t.v !== v) {throw new Error('cspBridge expr: expected ' + v);} return t; };

      function parseProgram() {
        const stmts = [parseStatement()];
        while (peek() && peek().t === 'semi') { next(); if (peek()) {stmts.push(parseStatement());} }
        return { type: 'Program', body: stmts };
      }
      // Event attributes are intentionally limited to expressions, but existing
      // markup also uses simple one-line `if (condition) action()` handlers.
      // Parse that safe subset explicitly instead of evaluating arbitrary JS.
      function parseStatement() {
        if (peek() && peek().t === 'id' && peek().v === 'if') {
          next();
          expectOp('(');
          const test = parseTernary();
          expectOp(')');
          const cons = parseStatement();
          let alt = null;
          if (peek() && peek().t === 'id' && peek().v === 'else') {
            next();
            alt = parseStatement();
          }
          return { type: 'If', test, cons, alt };
        }
        const expression = parseTernary();
        if (peek() && peek().t === 'op' && peek().v === '=') {
          next();
          return { type: 'Assign', target: expression, value: parseTernary() };
        }
        return expression;
      }
      function parseTernary() {
        const test = parseOr();
        if (peek() && peek().t === 'op' && peek().v === '?') {
          next();
          const cons = parseTernary();
          expectOp(':');
          const alt = parseTernary();
          return { type: 'Cond', test, cons, alt };
        }
        return test;
      }
      function binLevel(nextFn, ops) {
        let left = nextFn();
        while (peek() && peek().t === 'op' && ops.includes(peek().v)) {
          const op = next().v;
          const right = nextFn();
          left = { type: 'Bin', op, left, right };
        }
        return left;
      }
      const parseOr = () => binLevel(parseAnd, ['||']);
      const parseAnd = () => binLevel(parseEq, ['&&']);
      const parseEq = () => binLevel(parseRel, ['===', '!==', '==', '!=']);
      const parseRel = () => binLevel(parseAdd, ['<', '>', '<=', '>=']);
      const parseAdd = () => binLevel(parseMul, ['+', '-']);
      const parseMul = () => binLevel(parseUnary, ['*', '/', '%']);
      function parseUnary() {
        if (peek() && peek().t === 'op' && (peek().v === '!' || peek().v === '-')) {
          const op = next().v;
          return { type: 'Unary', op, arg: parseUnary() };
        }
        return parsePostfix();
      }
      function parsePostfix() {
        let node = parsePrimary();
        for (;;) {
          if (peek() && peek().t === 'op' && peek().v === '.') {
            next();
            const name = next().v;
            node = { type: 'Member', obj: node, prop: { type: 'Lit', v: name }, computed: false };
          } else if (peek() && peek().t === 'op' && peek().v === '[') {
            next();
            const prop = parseTernary();
            expectOp(']');
            node = { type: 'Member', obj: node, prop, computed: true };
          } else if (peek() && peek().t === 'op' && peek().v === '(') {
            next();
            const args = [];
            if (!(peek() && peek().t === 'op' && peek().v === ')')) {
              args.push(parseTernary());
              while (peek() && peek().t === 'op' && peek().v === ',') { next(); args.push(parseTernary()); }
            }
            expectOp(')');
            node = { type: 'Call', callee: node, args };
          } else {break;}
        }
        return node;
      }
      function parsePrimary() {
        const t = next();
        if (!t) {throw new Error('cspBridge expr: unexpected end');}
        if (t.t === 'num' || t.t === 'str' || t.t === 'bool' || t.t === 'null') {return { type: 'Lit', v: t.v };}
        if (t.t === 'id') {return { type: 'Id', v: t.v };}
        if (t.t === 'op' && t.v === '(') {
          const e = parseTernary();
          expectOp(')');
          return e;
        }
        throw new Error('cspBridge expr: unexpected token ' + JSON.stringify(t));
      }
      const prog = parseProgram();
      if (p < toks.length) {throw new Error('cspBridge expr: unexpected trailing token ' + JSON.stringify(peek()));}
      return prog;
    }

    function evalNode(node, ctx) {
      switch (node.type) {
        case 'Program': {
          let result;
          for (const s of node.body) {result = evalNode(s, ctx);}
          return result;
        }
        case 'If': return evalNode(node.test, ctx) ? evalNode(node.cons, ctx) : (node.alt ? evalNode(node.alt, ctx) : undefined);
        case 'Lit': return node.v;
        case 'Id': {
          if (node.v === 'this') {return ctx.thisVal;}
          if (node.v === 'event') {return ctx.event;}
          if (node.v in ctx.scope) {return ctx.scope[node.v];}
          if (Object.prototype.hasOwnProperty.call(window, node.v)) {return window[node.v];}
          if (typeof window[node.v] !== 'undefined') {return window[node.v];}
          throw new Error('cspBridge expr: unknown identifier "' + node.v + '"');
        }
        case 'Member': {
          const obj = evalNode(node.obj, ctx);
          const key = node.computed ? evalNode(node.prop, ctx) : node.prop.v;
          if (obj === null || obj === undefined) {throw new Error('cspBridge expr: cannot read "' + key + '" of ' + obj);}
          const val = obj[key];
          return typeof val === 'function' ? val.bind(obj) : val;
        }
        case 'Call': {
          const fn = evalNode(node.callee, ctx);
          const args = node.args.map(a => evalNode(a, ctx));
          if (typeof fn !== 'function') {throw new Error('cspBridge expr: not a function');}
          return fn.apply(null, args);
        }
        case 'Unary': {
          const v = evalNode(node.arg, ctx);
          return node.op === '!' ? !v : -v;
        }
        case 'Bin': {
          const op = node.op;
          if (op === '||') { const l = evalNode(node.left, ctx); return l ? l : evalNode(node.right, ctx); }
          if (op === '&&') { const l = evalNode(node.left, ctx); return l ? evalNode(node.right, ctx) : l; }
          const l = evalNode(node.left, ctx), r = evalNode(node.right, ctx);
          switch (op) {
            case '===': return l === r; case '!==': return l !== r;
            case '==': return l == r; case '!=': return l != r;
            case '<': return l < r; case '>': return l > r;
            case '<=': return l <= r; case '>=': return l >= r;
            case '+': return l + r; case '-': return l - r;
            case '*': return l * r; case '/': return l / r; case '%': return l % r;
          }
          throw new Error('cspBridge expr: unknown op ' + op);
        }
        case 'Cond': return evalNode(node.test, ctx) ? evalNode(node.cons, ctx) : evalNode(node.alt, ctx);
        case 'Assign': {
          let root = node.target;
          while (root && root.type === 'Member') root = root.obj;
          if (node.target.type !== 'Member' || root?.type !== 'Id' || !['siMapping', 'batchCart'].includes(root.v)) {
            throw new Error('cspBridge expr: assignment target is not allowed');
          }
          const object = evalNode(node.target.obj, ctx);
          const key = node.target.computed ? evalNode(node.target.prop, ctx) : node.target.prop.v;
          if (!object || !['string', 'number'].includes(typeof key) || String(key) === '__proto__' || String(key) === 'constructor') {
            throw new Error('cspBridge expr: invalid assignment property');
          }
          if (root.v === 'batchCart' && key !== 'qty') throw new Error('cspBridge expr: batch cart assignment is limited to qty');
          if (root.v === 'siMapping' && !/^[A-Za-z][A-Za-z0-9_-]*$/.test(String(key))) throw new Error('cspBridge expr: invalid mapping key');
          const value = evalNode(node.value, ctx);
          object[key] = value;
          return value;
        }
        default: throw new Error('cspBridge expr: unknown node ' + node.type);
      }
    }

    const astCache = new Map();
    function run(src, thisVal, event) {
      let ast = astCache.get(src);
      if (!ast) { ast = parse(tokenize(src)); astCache.set(src, ast); }
      return evalNode(ast, { thisVal, event, scope: {} });
    }
    return { run };
  })();
  window.CSPExpr = CSPExpr;

  // ---------------------------------------------------------------------
  // 3. Delegated event dispatch (replaces onclick="" etc.)
  // ---------------------------------------------------------------------

  const BUBBLING_EVENTS = ['click', 'dblclick', 'change', 'input', 'keyup', 'keydown',
    'keypress', 'submit', 'mouseover', 'mouseout', 'contextmenu'];
  const CAPTURE_ONLY_EVENTS = ['focus', 'blur', 'mouseenter', 'mouseleave']; // do not bubble

  function runHandler(el, type, evt) {
    const expr = el.getAttribute('data-on' + type);
    if (!expr) {return;}
    try {
      CSPExpr.run(expr, el, evt);
    } catch (err) {
      console.error('[cspBridge] handler error for data-on' + type + '="' + expr + '"', err);
    }
  }

  BUBBLING_EVENTS.forEach((type) => {
    document.addEventListener(type, function (evt) {
      const el = evt.target.closest && evt.target.closest('[data-on' + type + ']');
      if (el) {runHandler(el, type, evt);}
    }, false);
  });

  CAPTURE_ONLY_EVENTS.forEach((type) => {
    document.addEventListener(type, function (evt) {
      const el = evt.target;
      if (el && el.hasAttribute && el.hasAttribute('data-on' + type)) {runHandler(el, type, evt);}
    }, true);
  });

  console.log('[cspBridge] CSP compatibility layer active (events + styles).');

  // ---------------------------------------------------------------------
  // 4. Shared print-popup helper
  // ---------------------------------------------------------------------
  //
  // Print/label/report windows (window.open('', '_blank') + document.write)
  // are a separate document from the main CSP'd app UI. Two related issues
  // exist here, both worked around by this one helper:
  //
  //  a) Chromium inherits the *opener's* CSP for about:blank popups created
  //     via window.open() — a deliberate anti-bypass measure — so a plain
  //     window.open() popup still gets the app's strict CSP and silently
  //     drops every <style> tag/attribute. window.printBridge.printContent()
  //     (see preload.js / main.js) avoids this because it creates a real
  //     top-level window from the *main process* with no opener relationship,
  //     navigating via a data: URL — that's not subject to CSP inheritance.
  //
  //  b) Some print HTML is assembled from small helper templates that were
  //     originally written for (or copy-pasted from) main-document rendering
  //     code, and ended up using the data-style="" / data-onXXX="" attribute
  //     form that only the main window's cspBridge knows how to apply.
  //     Popups never load cspBridge, so those attributes would just sit
  //     there unprocessed. Converting them back to literal style=/onXXX=
  //     right before printing fixes that regardless of which helper the
  //     fragment came from, without having to hunt down every call site.
  window.printPopupHtml = function (html) {
    const fixed = String(html)
      .replace(/\bdata-style="/g, 'style="')
      .replace(/\bdata-on(\w+)="/g, 'on$1="');
    if (window.printBridge) {
      window.printBridge.printContent(fixed);
    } else {
      const w = window.open('', '_blank');
      if (!w) {
        if (typeof toast === 'function') {toast('Print window blocked by popup blocker. Please allow popups for this application.', 'er');}
        return;
      }
      const withAutoPrint = fixed.includes('</body>')
        ? fixed.replace('</body>', '<script>window.print();window.close();<\/script></body>')
        : fixed + '<script>window.print();window.close();<\/script>';
      w.document.write(withAutoPrint);
      w.document.close();
    }
  };
})();
