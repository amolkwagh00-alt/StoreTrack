// Smart Recommendations Module - AI-powered recommendations for inventory management

const INVENTORY_INACTIVITY_DAY_MS=24*60*60*1000;
function isQualifyingInventoryMovement(tx){return !!tx&&typeof tx==='object'&&['IN','OUT'].includes(String(tx.type||'').toUpperCase())&&tx.status==='confirmed'&&Number.isFinite(Date.parse(tx.time||''));}
function lastInventoryActivityTime(material,transactions){
  const id=material?.id,barcode=String(material?.barcode||'');let latest=null;
  for(const tx of Array.isArray(transactions)?transactions:[]){
    if(!isQualifyingInventoryMovement(tx))continue;
    const idMatch=id!==null&&id!==undefined&&tx.itemId!==null&&tx.itemId!==undefined&&String(tx.itemId)===String(id);
    const barcodeMatch=barcode!==''&&String(tx.barcode||'')===barcode;
    if(!idMatch&&!barcodeMatch)continue;
    const time=Date.parse(tx.time);if(latest===null||time>latest)latest=time;
  }
  return latest;
}
function classifyInventoryInactivity(days){const n=Number(days);if(!Number.isFinite(n))return 'normal';if(n>=180)return 'dead';if(n>=90)return 'slow';return 'normal';}

/**
 * Recommendation class
 */
class Recommendation {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.type = config.type || 'reorder'; // reorder, pricing, optimization, cross_sell
    this.category = config.category || 'inventory'; // inventory, pricing, operations
    this.entityType = config.entityType || '';
    this.entityId = config.entityId || '';
    this.title = config.title || '';
    this.description = config.description || '';
    this.priority = config.priority || 'medium'; // low, medium, high, urgent
    this.confidence = config.confidence || 0.5; // 0-1
    this.impact = config.impact || 'medium'; // low, medium, high
    this.effort = config.effort || 'medium'; // low, medium, high
    this.action = config.action || '';
    this.actionData = config.actionData || {};
    this.expectedBenefit = config.expectedBenefit || '';
    this.generatedAt = config.generatedAt || new Date().toISOString();
    this.expiresAt = config.expiresAt || null;
    this.status = config.status || 'pending'; // pending, accepted, rejected, completed
    this.acceptedBy = config.acceptedBy || null;
    this.acceptedAt = config.acceptedAt || null;
    this.completedBy = config.completedBy || null;
    this.completedAt = config.completedAt || null;
    this.feedback = config.feedback || '';
  }

  generateId() {
    return `recommendation-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Accept recommendation
   * @param {string} userId - User ID
   */
  accept(userId) {
    this.status = 'accepted';
    this.acceptedBy = userId;
    this.acceptedAt = new Date().toISOString();
  }

  /**
   * Reject recommendation
   * @param {string} userId - User ID
   * @param {string} feedback - Feedback
   */
  reject(userId, feedback = '') {
    this.status = 'rejected';
    this.acceptedBy = userId;
    this.acceptedAt = new Date().toISOString();
    this.feedback = feedback;
  }

  /**
   * Mark as completed
   * @param {string} userId - User ID
   */
  complete(userId) {
    this.status = 'completed';
    this.completedBy = userId;
    this.completedAt = new Date().toISOString();
  }

  /**
   * Check if expired
   * @returns {boolean} - Is expired
   */
  isExpired() {
    if (!this.expiresAt) {return false;}
    return new Date() >= new Date(this.expiresAt);
  }
}

/**
 * Smart Recommendations Engine
 */
class SmartRecommendationsEngine {
  constructor() {
    this.recommendations = new Map();
    this.init();
  }

  /**
   * Initialize recommendations engine
   */
  async init() {
    await this.loadRecommendations();
  }

  /**
   * Load recommendations from storage
   */
  async loadRecommendations() {
    try {
      const recommendations = await gAll('recommendations');
      recommendations.forEach(r => {
        this.recommendations.set(r.id, new Recommendation(r));
      });
    } catch (err) {
      console.error('Failed to load recommendations:', err);
    }
  }

  /**
   * Save recommendation to storage
   * @param {Recommendation} recommendation - Recommendation to save
   */
  async saveRecommendation(recommendation) {
    try {
      await dPut('recommendations', recommendation);
    } catch (err) {
      console.error('Failed to save recommendation:', err);
    }
  }

  /**
   * Generate all recommendations
   * @returns {Promise<Array>} - Generated recommendations
   */
  async generateAllRecommendations() {
    const recommendations = [];

    // Generate reorder recommendations
    const reorderRecs = await this.generateReorderRecommendations();
    recommendations.push(...reorderRecs);

    // Generate pricing recommendations
    const pricingRecs = await this.generatePricingRecommendations();
    recommendations.push(...pricingRecs);

    // Generate optimization recommendations
    const optimizationRecs = await this.generateOptimizationRecommendations();
    recommendations.push(...optimizationRecs);

    // Save recommendations
    for (const rec of recommendations) {
      this.recommendations.set(rec.id, rec);
      await this.saveRecommendation(rec);
    }

    return recommendations;
  }

  /**
   * Generate reorder recommendations
   * @returns {Promise<Array>} - Reorder recommendations
   */
  async generateReorderRecommendations() {
    const recommendations = [];
    const materials = await gAll('materials');

    // FIX (StoreTrack V8 integration): this function originally read
    // material.currentStock / material.minStock / material.maxStock, none of
    // which exist anywhere in this app's actual Material schema (the real
    // fields are `stock` and `lowAlert` — see app.js's renderLow()/updateDash()).
    // That meant this whole function silently produced zero recommendations
    // for every material, always. Also computes a real avgDailyDemand from
    // the last 30 days of confirmed OUT transactions (there was no data
    // source for this before — calculateReorderConfidence() below already
    // had real logic for it, it just never received real numbers).
    const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
    const recentOut = (typeof T !== 'undefined' ? T : []).filter(t =>
      t.type === 'OUT' && t.status === 'confirmed' && new Date(t.time).getTime() >= thirtyDaysAgo);
    const demandByMaterial = {};
    recentOut.forEach(t => { demandByMaterial[t.matId] = (demandByMaterial[t.matId] || 0) + Number(t.qty || 0); });

    for (const material of materials) {
      if (material.active === false) {continue;}
      const currentStock = material.stock || 0;
      const minStock = material.lowAlert || 0;
      // This app doesn't track an explicit "max stock" target — 3x the alert
      // level is a reasonable, conservative reorder-up-to point for a plant
      // spares store. Adjustable per-material once maxStock exists as a real field.
      const maxStock = material.maxStock || (minStock * 3) || 1;
      const avgDailyDemand = (demandByMaterial[material.id] || 0) / 30;
      const materialWithDemand = { ...material, avgDailyDemand };

      // Urgent: Stock below minimum
      if (currentStock < minStock) {
        const orderQty = Math.max(1, Math.ceil(maxStock - currentStock));
        const confidence = this.calculateReorderConfidence(materialWithDemand, currentStock, minStock);

        recommendations.push(new Recommendation({
          type: 'reorder',
          category: 'inventory',
          entityType: 'materials',
          entityId: material.id,
          title: `Urgent Reorder: ${material.name}`,
          description: `Stock level (${currentStock} ${material.unit||''}) is below the alert level (${minStock}). Immediate reorder recommended.${avgDailyDemand>0?` At current usage (~${avgDailyDemand.toFixed(1)}/day) stock runs out in ~${Math.floor(currentStock/avgDailyDemand)} day(s).`:''}`,
          priority: 'urgent',
          confidence,
          impact: 'high',
          effort: 'low',
          action: 'create_purchase_order',
          actionData: {
            materialId: material.id,
            quantity: orderQty,
            urgency: 'urgent'
          },
          expectedBenefit: `Prevent stockout, maintain ${material.name} availability`,
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
        }));
      }

      // High: Stock approaching minimum
      if (currentStock < minStock * 1.2 && currentStock >= minStock) {
        const orderQty = Math.max(1, Math.ceil(maxStock - currentStock));
        const confidence = this.calculateReorderConfidence(materialWithDemand, currentStock, minStock);

        recommendations.push(new Recommendation({
          type: 'reorder',
          category: 'inventory',
          entityType: 'materials',
          entityId: material.id,
          title: `Reorder Soon: ${material.name}`,
          description: `Stock level (${currentStock} ${material.unit||''}) is approaching the alert level (${minStock}). Consider reordering.`,
          priority: 'high',
          confidence,
          impact: 'high',
          effort: 'low',
          action: 'create_purchase_order',
          actionData: {
            materialId: material.id,
            quantity: orderQty,
            urgency: 'normal'
          },
          expectedBenefit: `Maintain optimal stock levels for ${material.name}`,
          expiresAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString()
        }));
      }
    }

    return recommendations;
  }

  /**
   * Calculate reorder confidence
   * @param {object} material - Material data
   * @param {number} currentStock - Current stock
   * @param {number} minStock - Minimum stock
   * @returns {number} - Confidence score
   */
  calculateReorderConfidence(material, currentStock, minStock) {
    const stockRatio = currentStock / (minStock || 1);
    
    // Lower stock ratio = higher confidence
    let confidence = 1 - stockRatio;
    
    // Adjust based on historical demand if available
    if (material.avgDailyDemand) {
      const daysOfStock = currentStock / material.avgDailyDemand;
      if (daysOfStock < 7) {confidence = Math.min(1, confidence + 0.2);}
      if (daysOfStock > 30) {confidence = Math.max(0, confidence - 0.2);}
    }

    return Math.min(1, Math.max(0, confidence));
  }

  /**
   * Generate pricing recommendations
   * @returns {Promise<Array>} - Pricing recommendations
   */
  async generatePricingRecommendations() {
    const recommendations = [];
    const materials = await gAll('materials');

    for (const material of materials) {
      if (!material.price || !material.cost) {continue;}

      const margin = (material.price - material.cost) / material.cost * 100;

      // Low margin warning
      if (margin < 10) {
        recommendations.push(new Recommendation({
          type: 'pricing',
          category: 'pricing',
          entityType: 'materials',
          entityId: material.id,
          title: `Low Margin: ${material.name}`,
          description: `Current margin (${margin.toFixed(1)}%) is below 10%. Consider price adjustment.`,
          priority: 'high',
          confidence: 0.8,
          impact: 'high',
          effort: 'low',
          action: 'adjust_price',
          actionData: {
            materialId: material.id,
            suggestedPrice: material.cost * 1.15,
            currentMargin: margin
          },
          expectedBenefit: `Increase profit margin for ${material.name}`,
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        }));
      }

      // High margin opportunity
      if (margin > 50) {
        recommendations.push(new Recommendation({
          type: 'pricing',
          category: 'pricing',
          entityType: 'materials',
          entityId: material.id,
          title: `High Margin Review: ${material.name}`,
          description: `Current margin (${margin.toFixed(1)}%) is very high. Consider competitive pricing review.`,
          priority: 'low',
          confidence: 0.6,
          impact: 'medium',
          effort: 'medium',
          action: 'review_pricing',
          actionData: {
            materialId: material.id,
            currentMargin: margin
          },
          expectedBenefit: `Optimize pricing for ${material.name} competitiveness`,
          expiresAt: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString()
        }));
      }
    }

    return recommendations;
  }

  /**
   * Generate optimization recommendations
   * @returns {Promise<Array>} - Optimization recommendations
   */
  async generateOptimizationRecommendations() {
    const recommendations=[];
    const materials=await gAll('materials');
    const transactions=await gAll('transactions');
    const now=Date.now();
    for(const material of materials){
      if(!material||Number(material.stock)<=0)continue;
      const lastActivity=lastInventoryActivityTime(material,transactions);
      const daysSinceActivity=lastActivity===null?999:(now-lastActivity)/INVENTORY_INACTIVITY_DAY_MS;
      const classification=classifyInventoryInactivity(daysSinceActivity);
      if(classification==='normal')continue;
      const isDead=classification==='dead';
      recommendations.push(new Recommendation({
        type:'optimization',category:'operations',entityType:'materials',entityId:material.id,
        title:`${isDead?'Dead Stock':'Slow-Moving Item'}: ${material.name}`,
        description:`No completed IN/OUT activity for ${Math.round(daysSinceActivity)} days, ${material.stock} ${material.unit||'units'} ${isDead?'sitting unused':'still in stock'}. ${isDead?'Consider a scrap/return-to-supplier review.':'Worth checking if this is still needed.'}`,
        priority:isDead?'high':'medium',confidence:isDead?0.9:0.7,impact:isDead?'high':'medium',effort:isDead?'high':'medium',
        action:isDead?'review_dead_stock':'review_slow_moving',
        actionData:{materialId:material.id,currentStock:material.stock,daysInactive:Math.round(daysSinceActivity)},
        expectedBenefit:isDead?'Free up storage and audit effort tied up in unused stock':`Free up shelf space / flag for review if ${material.name} is obsolete`,
        expiresAt:new Date(now+(isDead?14:30)*24*60*60*1000).toISOString()
      }));
    }
    return recommendations;
  }

  /**
   * Get recommendation
   * @param {string} id - Recommendation ID
   * @returns {Recommendation} - Recommendation
   */
  getRecommendation(id) {
    return this.recommendations.get(id);
  }

  /**
   * Get all recommendations
   * @returns {Array} - Array of recommendations
   */
  getAllRecommendations() {
    return Array.from(this.recommendations.values());
  }

  /**
   * Get pending recommendations
   * @returns {Array} - Pending recommendations
   */
  getPendingRecommendations() {
    return this.getAllRecommendations()
      .filter(r => r.status === 'pending' && !r.isExpired())
      .sort((a, b) => this.getPriorityScore(b) - this.getPriorityScore(a));
  }

  /**
   * Get recommendations by type
   * @param {string} type - Recommendation type
   * @returns {Array} - Recommendations
   */
  getRecommendationsByType(type) {
    return this.getAllRecommendations().filter(r => r.type === type);
  }

  /**
   * Get recommendations by priority
   * @param {string} priority - Priority
   * @returns {Array} - Recommendations
   */
  getRecommendationsByPriority(priority) {
    return this.getAllRecommendations().filter(r => r.priority === priority);
  }

  /**
   * Get recommendations for entity
   * @param {string} entityType - Entity type
   * @param {string} entityId - Entity ID
   * @returns {Array} - Recommendations
   */
  getRecommendationsForEntity(entityType, entityId) {
    return this.getAllRecommendations()
      .filter(r => r.entityType === entityType && r.entityId === entityId);
  }

  /**
   * Get priority score for sorting
   * @param {Recommendation} recommendation - Recommendation
   * @returns {number} - Priority score
   */
  getPriorityScore(recommendation) {
    const priorityScores = { urgent: 4, high: 3, medium: 2, low: 1 };
    const baseScore = priorityScores[recommendation.priority] || 2;
    const confidenceBonus = recommendation.confidence * 0.5;
    return baseScore + confidenceBonus;
  }

  /**
   * Accept recommendation
   * @param {string} id - Recommendation ID
   * @param {string} userId - User ID
   */
  async acceptRecommendation(id, userId) {
    const recommendation = this.recommendations.get(id);
    if (recommendation) {
      recommendation.accept(userId);
      await this.saveRecommendation(recommendation);
    }
  }

  /**
   * Reject recommendation
   * @param {string} id - Recommendation ID
   * @param {string} userId - User ID
   * @param {string} feedback - Feedback
   */
  async rejectRecommendation(id, userId, feedback = '') {
    const recommendation = this.recommendations.get(id);
    if (recommendation) {
      recommendation.reject(userId, feedback);
      await this.saveRecommendation(recommendation);
    }
  }

  /**
   * Complete recommendation
   * @param {string} id - Recommendation ID
   * @param {string} userId - User ID
   */
  async completeRecommendation(id, userId) {
    const recommendation = this.recommendations.get(id);
    if (recommendation) {
      recommendation.complete(userId);
      await this.saveRecommendation(recommendation);
    }
  }

  /**
   * Delete recommendation
   * @param {string} id - Recommendation ID
   */
  async deleteRecommendation(id) {
    this.recommendations.delete(id);
    await dDel('recommendations', id);
  }

  /**
   * Cleanup old recommendations
   * @param {number} daysToKeep - Days to keep
   */
  async cleanupOldRecommendations(daysToKeep = 90) {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

    let deletedCount = 0;

    for (const [id, rec] of this.recommendations) {
      if (rec.status !== 'pending' && new Date(rec.generatedAt) < cutoffDate) {
        this.recommendations.delete(id);
        await dDel('recommendations', id);
        deletedCount++;
      }
    }

    return deletedCount;
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const recommendations = this.getAllRecommendations();

    return {
      totalRecommendations: recommendations.length,
      byStatus: this.getStatusCounts(recommendations),
      byType: this.getTypeCounts(recommendations),
      byPriority: this.getPriorityCounts(recommendations),
      pendingRecommendations: recommendations.filter(r => r.status === 'pending').length,
      acceptedRecommendations: recommendations.filter(r => r.status === 'accepted').length,
      averageConfidence: recommendations.length > 0
        ? recommendations.reduce((sum, r) => sum + r.confidence, 0) / recommendations.length
        : 0
    };
  }

  /**
   * Get status counts
   * @param {Array} recommendations - Recommendations
   * @returns {object} - Status counts
   */
  getStatusCounts(recommendations) {
    const counts = {};
    recommendations.forEach(r => {
      counts[r.status] = (counts[r.status] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get type counts
   * @param {Array} recommendations - Recommendations
   * @returns {object} - Type counts
   */
  getTypeCounts(recommendations) {
    const counts = {};
    recommendations.forEach(r => {
      counts[r.type] = (counts[r.type] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get priority counts
   * @param {Array} recommendations - Recommendations
   * @returns {object} - Priority counts
   */
  getPriorityCounts(recommendations) {
    const counts = {};
    recommendations.forEach(r => {
      counts[r.priority] = (counts[r.priority] || 0) + 1;
    });
    return counts;
  }
}

/**
 * Global smart recommendations engine instance
 */
const smartRecommendationsEngine = new SmartRecommendationsEngine();

/**
 * Initialize smart recommendations
 */
async function initSmartRecommendations() {
  await smartRecommendationsEngine.init();
  return smartRecommendationsEngine;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.SmartRecommendations = {
    engine: smartRecommendationsEngine,
    init: initSmartRecommendations,
    generateAllRecommendations: () => smartRecommendationsEngine.generateAllRecommendations(),
    getRecommendation: (id) => smartRecommendationsEngine.getRecommendation(id),
    getAllRecommendations: () => smartRecommendationsEngine.getAllRecommendations(),
    getPendingRecommendations: () => smartRecommendationsEngine.getPendingRecommendations(),
    getRecommendationsByType: (type) => smartRecommendationsEngine.getRecommendationsByType(type),
    getRecommendationsByPriority: (priority) => smartRecommendationsEngine.getRecommendationsByPriority(priority),
    getRecommendationsForEntity: (entityType, entityId) => smartRecommendationsEngine.getRecommendationsForEntity(entityType, entityId),
    acceptRecommendation: (id, userId) => smartRecommendationsEngine.acceptRecommendation(id, userId),
    rejectRecommendation: (id, userId, feedback) => smartRecommendationsEngine.rejectRecommendation(id, userId, feedback),
    completeRecommendation: (id, userId) => smartRecommendationsEngine.completeRecommendation(id, userId),
    deleteRecommendation: (id) => smartRecommendationsEngine.deleteRecommendation(id),
    cleanupOldRecommendations: (daysToKeep) => smartRecommendationsEngine.cleanupOldRecommendations(daysToKeep),
    getStats: () => smartRecommendationsEngine.getStatistics()
  };
}
