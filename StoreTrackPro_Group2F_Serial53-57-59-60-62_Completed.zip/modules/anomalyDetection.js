/**
 * Anomaly Detection Module
 * Detects unusual patterns in inventory data using statistical methods
 */

class AnomalyDetection {
  constructor() {
    this.thresholds = {
      zScore: 3, // Standard deviations from mean
      iqrMultiplier: 1.5, // IQR multiplier for outlier detection
      percentChange: 50, // Percent change threshold
      movingAverageWindow: 7
    };
    
    this.anomalies = new Map();
    this.baselineData = new Map();
    this.alertHistory = [];
  }

  /**
   * Detect anomalies in inventory data
   * @param {Array} data - Array of inventory data points
   * @param {string} materialId - Material identifier
   * @returns {Array} Detected anomalies
   */
  detectAnomalies(data, materialId) {
    if (!Array.isArray(data) || data.length < 3) {
      return [];
    }

    const anomalies = [];
    
    // Z-score based anomaly detection
    const zScoreAnomalies = this.detectZScoreAnomalies(data);
    anomalies.push(...zScoreAnomalies);
    
    // IQR based anomaly detection
    const iqrAnomalies = this.detectIQRAnomalies(data);
    anomalies.push(...iqrAnomalies);
    
    // Percent change anomaly detection
    const changeAnomalies = this.detectPercentChangeAnomalies(data);
    anomalies.push(...changeAnomalies);
    
    // Pattern anomaly detection
    const patternAnomalies = this.detectPatternAnomalies(data);
    anomalies.push(...patternAnomalies);
    
    // Store anomalies for this material
    this.anomalies.set(materialId, anomalies);
    
    // Update baseline
    this.updateBaseline(materialId, data);
    
    return anomalies;
  }

  /**
   * Detect anomalies using Z-score method
   */
  detectZScoreAnomalies(data) {
    const anomalies = [];
    const mean = this.calculateMean(data);
    const stdDev = this.calculateStandardDeviation(data, mean);
    
    if (stdDev === 0) {return anomalies;}
    
    data.forEach((value, index) => {
      const zScore = Math.abs((value - mean) / stdDev);
      if (zScore > this.thresholds.zScore) {
        anomalies.push({
          type: 'zScore',
          index,
          value,
          zScore,
          severity: zScore > 5 ? 'critical' : 'warning',
          message: `Value ${value} is ${zScore.toFixed(2)} standard deviations from mean`
        });
      }
    });
    
    return anomalies;
  }

  /**
   * Detect anomalies using IQR method
   */
  detectIQRAnomalies(data) {
    const anomalies = [];
    const sorted = [...data].sort((a, b) => a - b);
    const q1 = this.calculatePercentile(sorted, 25);
    const q3 = this.calculatePercentile(sorted, 75);
    const iqr = q3 - q1;
    
    const lowerBound = q1 - (this.thresholds.iqrMultiplier * iqr);
    const upperBound = q3 + (this.thresholds.iqrMultiplier * iqr);
    
    data.forEach((value, index) => {
      if (value < lowerBound || value > upperBound) {
        anomalies.push({
          type: 'iqr',
          index,
          value,
          lowerBound,
          upperBound,
          severity: value < lowerBound * 0.5 || value > upperBound * 1.5 ? 'critical' : 'warning',
          message: `Value ${value} outside IQR bounds [${lowerBound.toFixed(2)}, ${upperBound.toFixed(2)}]`
        });
      }
    });
    
    return anomalies;
  }

  /**
   * Detect anomalies using percent change
   */
  detectPercentChangeAnomalies(data) {
    const anomalies = [];
    
    for (let i = 1; i < data.length; i++) {
      const prevValue = data[i - 1];
      const currentValue = data[i];
      
      if (prevValue === 0) {continue;}
      
      const percentChange = ((currentValue - prevValue) / Math.abs(prevValue)) * 100;
      
      if (Math.abs(percentChange) > this.thresholds.percentChange) {
        anomalies.push({
          type: 'percentChange',
          index: i,
          value: currentValue,
          previousValue: prevValue,
          percentChange,
          severity: Math.abs(percentChange) > 100 ? 'critical' : 'warning',
          message: `${percentChange.toFixed(1)}% change from ${prevValue} to ${currentValue}`
        });
      }
    }
    
    return anomalies;
  }

  /**
   * Detect pattern anomalies
   */
  detectPatternAnomalies(data) {
    const anomalies = [];
    
    // Detect sudden drops
    for (let i = 2; i < data.length; i++) {
      const trend = this.calculateTrend(data.slice(0, i));
      const current = data[i];
      const expected = trend[trend.length - 1];
      
      if (expected > 0 && current < expected * 0.3) {
        anomalies.push({
          type: 'suddenDrop',
          index: i,
          value: current,
          expected,
          severity: 'critical',
          message: `Sudden drop to ${current} from expected ${expected.toFixed(2)}`
        });
      }
    }
    
    // Detect zero values in non-zero series
    const nonZeroCount = data.filter(v => v > 0).length;
    if (nonZeroCount > data.length * 0.5) {
      data.forEach((value, index) => {
        if (value === 0) {
          anomalies.push({
            type: 'unexpectedZero',
            index,
            value,
            severity: 'warning',
            message: 'Unexpected zero value in typically non-zero series'
          });
        }
      });
    }
    
    return anomalies;
  }

  /**
   * Calculate mean
   */
  calculateMean(data) {
    return data.reduce((sum, val) => sum + val, 0) / data.length;
  }

  /**
   * Calculate standard deviation
   */
  calculateStandardDeviation(data, mean) {
    const variance = data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / data.length;
    return Math.sqrt(variance);
  }

  /**
   * Calculate percentile
   */
  calculatePercentile(sortedData, percentile) {
    const index = (percentile / 100) * (sortedData.length - 1);
    const lower = Math.floor(index);
    const upper = Math.ceil(index);
    const weight = index - lower;
    
    if (upper >= sortedData.length) {return sortedData[sortedData.length - 1];}
    
    return sortedData[lower] * (1 - weight) + sortedData[upper] * weight;
  }

  /**
   * Calculate trend using moving average
   */
  calculateTrend(data) {
    const windowSize = Math.min(3, data.length);
    const trend = [];
    
    for (let i = 0; i < data.length; i++) {
      const start = Math.max(0, i - windowSize + 1);
      const window = data.slice(start, i + 1);
      trend.push(window.reduce((sum, val) => sum + val, 0) / window.length);
    }
    
    return trend;
  }

  /**
   * Update baseline data
   */
  updateBaseline(materialId, data) {
    const existingBaseline = this.baselineData.get(materialId) || [];
    const newBaseline = [...existingBaseline, ...data].slice(-100); // Keep last 100 points
    this.baselineData.set(materialId, newBaseline);
  }

  /**
   * Get anomaly summary
   */
  getAnomalySummary() {
    const summary = {
      totalAnomalies: 0,
      byType: {},
      bySeverity: { critical: 0, warning: 0, info: 0 },
      byMaterial: {}
    };
    
    for (const [materialId, anomalies] of this.anomalies) {
      summary.byMaterial[materialId] = anomalies.length;
      summary.totalAnomalies += anomalies.length;
      
      anomalies.forEach(anomaly => {
        summary.byType[anomaly.type] = (summary.byType[anomaly.type] || 0) + 1;
        summary.bySeverity[anomaly.severity]++;
      });
    }
    
    return summary;
  }

  /**
   * Get anomalies for specific material
   */
  getMaterialAnomalies(materialId) {
    return this.anomalies.get(materialId) || [];
  }

  /**
   * Clear anomalies for material
   */
  clearMaterialAnomalies(materialId) {
    this.anomalies.delete(materialId);
  }

  /**
   * Clear all anomalies
   */
  clearAllAnomalies() {
    this.anomalies.clear();
    this.alertHistory = [];
  }

  /**
   * Set custom thresholds
   */
  setThresholds(newThresholds) {
    this.thresholds = { ...this.thresholds, ...newThresholds };
  }

  /**
   * Get current thresholds
   */
  getThresholds() {
    return { ...this.thresholds };
  }
}

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { AnomalyDetection };
}

// Global anomaly detection instance -- mirrors the pattern already used by
// sentryIntegration.js, apmMonitoring.js, etc. (top-level const singleton,
// exposed on window). This one was previously defined but never
// instantiated, so the BI Dashboard's anomaly card silently no-opped forever.
const anomalyDetection = new AnomalyDetection();

if (typeof window !== 'undefined') {
  window.AnomalyDetection = AnomalyDetection;
  window.anomalyDetection = anomalyDetection;
}
