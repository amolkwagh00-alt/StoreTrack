/* Batch 2C: Serial 24 bin labels and Serial 27 import preview helpers. */
(function (root) {
  'use strict';
  function text(value) { return String(value == null ? '' : value).trim(); }
  function locationCode(location) {
    if (!location) return '';
    return [location.zone, location.rack, location.bin].map(text).filter(Boolean).join('-');
  }
  function safeBarcodePart(value) {
    return text(value).toUpperCase().replace(/[^A-Z0-9_-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  }
  function binBarcode(location) {
    const code = safeBarcodePart(location?.barcode || location?.binBarcode || locationCode(location));
    return code ? `BIN-${code}` : '';
  }
  function validateBinLabels(locations) {
    const rows = Array.isArray(locations) ? locations : [];
    const seenCodes = new Map(), seenBarcodes = new Map(), errors = [];
    const labels = rows.map((location, index) => {
      const code = locationCode(location);
      const barcode = binBarcode(location);
      const id = text(location?.id);
      const label = { index: index + 1, id, code, barcode, zone: text(location?.zone), rack: text(location?.rack), bin: text(location?.bin), description: text(location?.desc || location?.description) };
      if (!id || !code || !barcode) errors.push({ row: index + 1, message: 'Bin/location is missing a stable ID, code, or barcode.' });
      if (code && seenCodes.has(code)) errors.push({ row: index + 1, message: `Duplicate location code ${code}; maps to rows ${seenCodes.get(code)} and ${index + 1}.` });
      if (barcode && seenBarcodes.has(barcode)) errors.push({ row: index + 1, message: `Duplicate barcode ${barcode}; maps to rows ${seenBarcodes.get(barcode)} and ${index + 1}.` });
      if (code) seenCodes.set(code, index + 1);
      if (barcode) seenBarcodes.set(barcode, index + 1);
      return label;
    });
    return { valid: errors.length === 0, labels, errors };
  }
  function normalizeHeader(value) { return text(value).toLowerCase().replace(/[\s_\-/.]/g, ''); }
  function previewImportRows(rows, mapping, existingRecords, options) {
    const source = Array.isArray(rows) ? rows : [];
    const map = mapping || {};
    const existing = Array.isArray(existingRecords) ? existingRecords : [];
    const opts = options || {};
    const get = (row, key) => { const index = Number(map[key]); return Number.isInteger(index) && index >= 0 ? text(row?.[index]) : ''; };
    const required = opts.required || ['partno', 'name'];
    const existingByBarcode = new Map(existing.map(record => [text(record?.barcode).toLowerCase(), record]));
    const seen = new Map(), records = [], errors = [];
    source.forEach((row, rowIndex) => {
      const line = rowIndex + 2;
      const barcode = get(row, 'partno'), name = get(row, 'name');
      const item = { row: line, barcode, name, category: get(row, 'category') || 'General', unit: get(row, 'unit') || 'Pcs', stock: get(row, 'stock'), lowAlert: get(row, 'lowalert') || '10', reorderQty: get(row, 'reorderqty') || '0', location: get(row, 'location') };
      const rowErrors = [];
      if (required.includes('partno') && !barcode) rowErrors.push('Missing required Part No / Barcode');
      if (required.includes('name') && !name) rowErrors.push('Missing required Material Name');
      if (item.stock !== '' && (!/^\d+(?:\.\d+)?$/.test(item.stock) || Number(item.stock) < 0)) rowErrors.push('Stock must be a non-negative number');
      if (item.lowAlert !== '' && (!/^\d+(?:\.\d+)?$/.test(item.lowAlert) || Number(item.lowAlert) < 0)) rowErrors.push('Low Alert must be a non-negative number');
      const key = barcode.toLowerCase();
      if (key && seen.has(key)) rowErrors.push(`Duplicate barcode in file (row ${seen.get(key)})`);
      if (key) seen.set(key, line);
      const existingRecord = key ? existingByBarcode.get(key) : null;
      const status = rowErrors.length ? 'rejected' : existingRecord ? (opts.updateDuplicates ? 'updated' : 'skipped') : 'added';
      if (rowErrors.length) errors.push(...rowErrors.map(message => ({ row: line, message })));
      records.push({ ...item, rowErrors, status, existingId: existingRecord?.id || null });
    });
    const stats = { total: source.length, valid: records.filter(r => !r.rowErrors.length).length, invalid: records.filter(r => r.rowErrors.length).length, added: records.filter(r => r.status === 'added').length, updated: records.filter(r => r.status === 'updated').length, skipped: records.filter(r => r.status === 'skipped').length, rejected: records.filter(r => r.status === 'rejected').length };
    return { records, errors, stats, safeToImport: stats.invalid === 0 && (stats.added + stats.updated) > 0 };
  }
  const api = { locationCode, binBarcode, validateBinLabels, normalizeHeader, previewImportRows };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.StoreTrackBatch2C = api;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
