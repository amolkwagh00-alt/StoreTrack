// Pagination Module - Efficient data pagination for large datasets

/**
 * Pagination class for managing paginated data
 */
class Pagination {
  constructor(options = {}) {
    this.data = options.data || [];
    this.pageSize = options.pageSize || 50;
    this.currentPage = options.currentPage || 1;
    this.totalItems = options.totalItems || this.data.length;
    this.sortField = options.sortField || null;
    this.sortDirection = options.sortDirection || 'asc';
    this.filters = options.filters || {};
  }

  /**
   * Get total number of pages
   * @returns {number} - Total pages
   */
  getTotalPages() {
    return Math.ceil(this.totalItems / this.pageSize);
  }

  /**
   * Get current page data
   * @returns {Array} - Current page data
   */
  getCurrentPageData() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    return this.data.slice(startIndex, endIndex);
  }

  /**
   * Go to specific page
   * @param {number} page - Page number
   */
  goToPage(page) {
    const totalPages = this.getTotalPages();
    if (page < 1) {page = 1;}
    if (page > totalPages) {page = totalPages;}
    this.currentPage = page;
  }

  /**
   * Go to next page
   */
  nextPage() {
    this.goToPage(this.currentPage + 1);
  }

  /**
   * Go to previous page
   */
  previousPage() {
    this.goToPage(this.currentPage - 1);
  }

  /**
   * Go to first page
   */
  firstPage() {
    this.goToPage(1);
  }

  /**
   * Go to last page
   */
  lastPage() {
    this.goToPage(this.getTotalPages());
  }

  /**
   * Set page size
   * @param {number} size - New page size
   */
  setPageSize(size) {
    this.pageSize = size;
    this.currentPage = 1; // Reset to first page
  }

  /**
   * Sort data by field
   * @param {string} field - Field to sort by
   * @param {string} direction - Sort direction ('asc' or 'desc')
   */
  sortBy(field, direction = 'asc') {
    this.sortField = field;
    this.sortDirection = direction;
    
    this.data.sort((a, b) => {
      let aVal = a[field];
      let bVal = b[field];
      
      // Handle null/undefined
      if (aVal == null) {return 1;}
      if (bVal == null) {return -1;}
      
      // Handle strings (case-insensitive)
      if (typeof aVal === 'string') {aVal = aVal.toLowerCase();}
      if (typeof bVal === 'string') {bVal = bVal.toLowerCase();}
      
      if (aVal < bVal) {return direction === 'asc' ? -1 : 1;}
      if (aVal > bVal) {return direction === 'asc' ? 1 : -1;}
      return 0;
    });
  }

  /**
   * Filter data
   * @param {object} filters - Filter criteria
   */
  filter(filters) {
    this.filters = filters;
    
    this.data = this.data.filter(item => {
      return Object.keys(filters).every(key => {
        const filterValue = filters[key];
        const itemValue = item[key];
        
        // Handle different filter types
        if (filterValue == null || filterValue === '') {return true;}
        
        // String contains (case-insensitive)
        if (typeof filterValue === 'string' && typeof itemValue === 'string') {
          return itemValue.toLowerCase().includes(filterValue.toLowerCase());
        }
        
        // Exact match
        return itemValue === filterValue;
      });
    });
    
    this.totalItems = this.data.length;
    this.currentPage = 1; // Reset to first page
  }

  /**
   * Clear all filters
   */
  clearFilters() {
    this.filters = {};
    // Note: This doesn't restore original data - you'd need to store it separately
  }

  /**
   * Get pagination info
   * @returns {object} - Pagination info
   */
  getInfo() {
    return {
      currentPage: this.currentPage,
      pageSize: this.pageSize,
      totalItems: this.totalItems,
      totalPages: this.getTotalPages(),
      hasNextPage: this.currentPage < this.getTotalPages(),
      hasPreviousPage: this.currentPage > 1,
      startIndex: (this.currentPage - 1) * this.pageSize + 1,
      endIndex: Math.min(this.currentPage * this.pageSize, this.totalItems)
    };
  }

  /**
   * Reset pagination
   */
  reset() {
    this.currentPage = 1;
    this.sortField = null;
    this.sortDirection = 'asc';
    this.filters = {};
  }
}

/**
 * IndexedDB pagination for large datasets
 */
class DBPagination {
  constructor(storeName, options = {}) {
    this.storeName = storeName;
    this.pageSize = options.pageSize || 50;
    this.currentPage = options.currentPage || 1;
    this.totalItems = 0;
    this.indexName = options.indexName || null;
    this.indexValue = options.indexValue || null;
  }

  /**
   * Load total count from IndexedDB
   * @returns {Promise<number>} - Total count
   */
  async loadTotalCount() {
    // This would use the database module
    // For now, return 0 - implementation depends on database module
    return this.totalItems;
  }

  /**
   * Load page data from IndexedDB
   * @returns {Promise<Array>} - Page data
   */
  async loadPage() {
    // This would use the database module with pagination
    // For now, return empty array - implementation depends on database module
    return [];
  }

  /**
   * Set index filter
   * @param {string} indexName - Index name
   * @param {any} indexValue - Index value
   */
  setIndexFilter(indexName, indexValue) {
    this.indexName = indexName;
    this.indexValue = indexValue;
    this.currentPage = 1;
  }

  /**
   * Clear index filter
   */
  clearIndexFilter() {
    this.indexName = null;
    this.indexValue = null;
    this.currentPage = 1;
  }
}

/**
 * Render pagination controls
 * @param {object} pagination - Pagination instance
 * @param {string} containerId - Container element ID
 * @param {Function} onPageChange - Callback when page changes
 */
function renderPaginationControls(pagination, containerId, onPageChange) {
  const container = document.getElementById(containerId);
  if (!container) {return;}

  const info = pagination.getInfo();
  const totalPages = info.totalPages;

  let html = `
    <div class="pagination-controls">
      <div class="pagination-info">
        Showing ${info.startIndex} - ${info.endIndex} of ${info.totalItems}
      </div>
      <div class="pagination-buttons">
        <button class="btn btn-sm" 
                ${!info.hasPreviousPage ? 'disabled' : ''} 
                data-onclick="paginationGoToPage('${containerId}', 1)">
          First
        </button>
        <button class="btn btn-sm" 
                ${!info.hasPreviousPage ? 'disabled' : ''} 
                data-onclick="paginationGoToPage('${containerId}', ${info.currentPage - 1})">
          Previous
        </button>
  `;

  // Page numbers (show max 5 pages)
  const startPage = Math.max(1, info.currentPage - 2);
  const endPage = Math.min(totalPages, startPage + 4);
  
  for (let i = startPage; i <= endPage; i++) {
    html += `
      <button class="btn btn-sm ${i === info.currentPage ? 'btn-primary' : ''}" 
              data-onclick="paginationGoToPage('${containerId}', ${i})">
        ${i}
      </button>
    `;
  }

  html += `
        <button class="btn btn-sm" 
                ${!info.hasNextPage ? 'disabled' : ''} 
                data-onclick="paginationGoToPage('${containerId}', ${info.currentPage + 1})">
          Next
        </button>
        <button class="btn btn-sm" 
                ${!info.hasNextPage ? 'disabled' : ''} 
                data-onclick="paginationGoToPage('${containerId}', ${totalPages})">
          Last
        </button>
      </div>
      <div class="pagination-size">
        <select data-onchange="paginationSetPageSize('${containerId}', this.value)">
          <option value="25" ${pagination.pageSize === 25 ? 'selected' : ''}>25</option>
          <option value="50" ${pagination.pageSize === 50 ? 'selected' : ''}>50</option>
          <option value="100" ${pagination.pageSize === 100 ? 'selected' : ''}>100</option>
          <option value="200" ${pagination.pageSize === 200 ? 'selected' : ''}>200</option>
        </select>
        per page
      </div>
    </div>
  `;

  container.innerHTML = html;
}

/**
 * Store pagination instances for global access
 */
const paginationInstances = new Map();

/**
 * Register pagination instance
 * @param {string} id - Unique ID
 * @param {object} pagination - Pagination instance
 * @param {Function} onPageChange - Page change callback
 */
function registerPagination(id, pagination, onPageChange) {
  paginationInstances.set(id, { pagination, onPageChange });
}

/**
 * Go to specific page
 * @param {string} id - Pagination instance ID
 * @param {number} page - Page number
 */
function paginationGoToPage(id, page) {
  const instance = paginationInstances.get(id);
  if (instance) {
    instance.pagination.goToPage(page);
    if (instance.onPageChange) {
      instance.onPageChange(page);
    }
  }
}

/**
 * Set page size
 * @param {string} id - Pagination instance ID
 * @param {number} size - Page size
 */
function paginationSetPageSize(id, size) {
  const instance = paginationInstances.get(id);
  if (instance) {
    instance.pagination.setPageSize(parseInt(size));
    if (instance.onPageChange) {
      instance.onPageChange(1);
    }
  }
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.Pagination = {
    Pagination,
    DBPagination,
    renderControls: renderPaginationControls,
    register: registerPagination,
    goToPage: paginationGoToPage,
    setPageSize: paginationSetPageSize,
    instances: paginationInstances
  };
}
