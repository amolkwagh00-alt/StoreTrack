/* global toastMsg, audit */
/* StoreTrack Pro complete local backup and restore. */
(function () {
  'use strict';
  const BACKUP_KEY = 'storetrack_last_backup_date';
  const RESTORE_TEST_KEY = 'storetrack_last_restore_verification';
  let timer = null;

  function dateKey() { return new Date().toISOString().slice(0, 10); }
  function statusText(message, type) {
    if (typeof toast === 'function') { toast(message, type || 'inf'); }
    else if (typeof toastMsg === 'function') { toastMsg(message, type || 'inf'); }
  }
  function isUserStore(name) { return String(name).toLowerCase() === 'users'; }
  function readSnapshot(names, { decrypt = true } = {}) {
    const operational = names.filter(name => !isUserStore(name));
    const dbName = typeof DB === 'string' ? DB : 'StoreTrackDB';
    return new Promise((resolve, reject) => {
      const open = indexedDB.open(dbName);
      open.onerror = () => reject(open.error || new Error('Could not open database for consistent snapshot'));
      open.onblocked = () => reject(new Error('Database snapshot is blocked'));
      open.onsuccess = () => {
        const database = open.result;
        const available = operational.filter(name => database.objectStoreNames.contains(name));
        const snapshot = {};
        if (!available.length) { database.close(); resolve(snapshot); return; }
        let transaction;
        try { transaction = database.transaction(available, 'readonly'); }
        catch (error) { database.close(); reject(error); return; }
        let failed = false;
        for (const name of available) {
          const request = transaction.objectStore(name).getAll();
          request.onsuccess = () => { snapshot[name] = request.result || []; };
          request.onerror = () => { failed = true; };
        }
        transaction.oncomplete = async () => {
          database.close();
          if (failed) { reject(new Error('Consistent snapshot read failed')); return; }
          try {
            const manager = window.DataEncryption?.manager;
            if (decrypt && manager?.restoreFromStorage) {
              for (const name of available) { snapshot[name] = await Promise.all(snapshot[name].map(row => manager.restoreFromStorage(name, row))); }
            }
            resolve(snapshot);
          } catch (error) { reject(error); }
        };
        transaction.onerror = () => { database.close(); reject(transaction.error || new Error('Consistent snapshot transaction failed')); };
        transaction.onabort = () => { database.close(); reject(transaction.error || new Error('Consistent snapshot transaction aborted')); };
      };
    });
  }
  async function writeRestoreJournal(snapshot, phase = 'prepared') {
    if (!window.backupBridge?.writeRecoveryJournal) { throw new Error('Protected restore recovery storage is unavailable'); }
    const result = await window.backupBridge.writeRecoveryJournal(JSON.stringify({ version: 1, phase, snapshot }));
    if (!result?.ok) { throw new Error(result?.error || 'Could not secure restore recovery journal'); }
  }
  async function clearRestoreJournal() {
    if (!window.backupBridge?.clearRecoveryJournal) { throw new Error('Protected restore recovery storage is unavailable'); }
    const result = await window.backupBridge.clearRecoveryJournal();
    if (!result?.ok) { throw new Error(result?.error || 'Could not clear restore recovery journal'); }
  }
  function restoreRawSnapshot(snapshot) {
    const names = Object.keys(snapshot).filter(name => !isUserStore(name) && Array.isArray(snapshot[name]));
    const dbName = typeof DB === 'string' ? DB : 'StoreTrackDB';
    return new Promise((resolve, reject) => {
      const open = indexedDB.open(dbName);
      open.onerror = () => reject(open.error || new Error('Could not open database for restore recovery'));
      open.onblocked = () => reject(new Error('Database restore recovery is blocked'));
      open.onsuccess = () => {
        const database = open.result;
        const available = names.filter(name => database.objectStoreNames.contains(name));
        if (!available.length) { database.close(); resolve(); return; }
        let transaction;
        try {
          transaction = database.transaction(available, 'readwrite');
          for (const name of available) {
            const store = transaction.objectStore(name);
            store.clear();
            for (const row of snapshot[name]) { store.put(row); }
          }
        } catch (error) {
          database.close();
          reject(error);
          return;
        }
        transaction.oncomplete = () => { database.close(); resolve(); };
        transaction.onerror = () => { database.close(); reject(transaction.error || new Error('Restore recovery transaction failed')); };
        transaction.onabort = () => { database.close(); reject(transaction.error || new Error('Restore recovery transaction aborted')); };
      };
    });
  }
  async function recoverInterruptedRestore() {
    if (!window.backupBridge?.readRecoveryJournal) { return false; }
    const result = await window.backupBridge.readRecoveryJournal();
    if (!result?.ok) { throw new Error(result?.error || 'Could not read protected restore recovery journal'); }
    if (!result.data) { return false; }
    let journal;
    try { journal = JSON.parse(result.data); } catch (_) { throw new Error('Restore recovery journal is invalid; database was not modified'); }
    if (journal?.version !== 1 || !['prepared', 'committed'].includes(journal.phase)) { throw new Error('Restore recovery journal is invalid; database was not modified'); }
    if (journal.phase === 'committed') { await clearRestoreJournal(); return false; }
    if (!journal.snapshot || typeof journal.snapshot !== 'object' || Array.isArray(journal.snapshot)) { throw new Error('Restore recovery journal is invalid; database was not modified'); }
    for (const [name, rows] of Object.entries(journal.snapshot)) {
      if (isUserStore(name) || !Array.isArray(rows)) { throw new Error('Restore recovery journal failed validation; database was not modified'); }
    }
    await restoreRawSnapshot(journal.snapshot);
    await clearRestoreJournal();
    return true;
  }
  async function collect() {
    const names = typeof getStoreNames === 'function' ? getStoreNames() : (window.STORES || []);
    const stores = await readSnapshot(names);
    // Account records contain password hashes and must not be written to a plaintext backup.
    // Existing accounts remain on the target machine when restoring this operational-data backup.
    for (const name of names) { if (!isUserStore(name) && !Object.prototype.hasOwnProperty.call(stores, name)) { stores[name] = []; } }
    return { format: 'StoreTrackProCompleteBackup', version: 2, createdAt: new Date().toISOString(), database: typeof DB === 'string' ? DB : 'StoreTrackDB', excludedStores: ['users'], stores };
  }
  function validationIssue(payload) {
    if (!payload || payload.format !== 'StoreTrackProCompleteBackup') return 'invalid backup format';
    if (!payload.stores || typeof payload.stores !== 'object' || Array.isArray(payload.stores)) return 'stores payload is not an object';
    if (!Object.keys(payload.stores).length) return 'no stores were collected';
    for (const [storeName, rows] of Object.entries(payload.stores)) {
      if (!Array.isArray(rows)) return `store ${storeName} is not an array`;
      const badIndex = rows.findIndex(row => !row || typeof row !== 'object' || Array.isArray(row));
      if (badIndex >= 0) return `store ${storeName} contains an invalid row at index ${badIndex}`;
    }
    return '';
  }
  function valid(payload) { return payload && payload.format === 'StoreTrackProCompleteBackup' && payload.stores && typeof payload.stores === 'object' && !Array.isArray(payload.stores) && Object.keys(payload.stores).length > 0 && Object.values(payload.stores).every(rows => Array.isArray(rows) && rows.every(row => row && typeof row === 'object' && !Array.isArray(row))); }
  function validGRN(row) {
    if (!row || typeof row !== 'object' || Array.isArray(row) || !['string', 'number'].includes(typeof row.id) || String(row.id).trim() === '' || !Array.isArray(row.items)) return false;
    const scalarFields = ['grnNo', 'time', 'supplierId', 'supplierName', 'po', 'invoice', 'totalQty', 'receivedBy'];
    if (scalarFields.some(key => row[key] !== undefined && row[key] !== null && !['string', 'number', 'boolean'].includes(typeof row[key]))) return false;
    return row.items.every(item => item && typeof item === 'object' && !Array.isArray(item) && Object.values(item).every(value => value === null || ['string', 'number', 'boolean'].includes(typeof value)));
  }
  function stable(value) {
    function canonicalize(input) {
      if (Array.isArray(input)) { return input.map(canonicalize); }
      if (!input || typeof input !== 'object') { return input; }
      const result = {};
      for (const key of Object.keys(input).sort()) {
        // Timestamps are deliberately excluded from conflict detection, as
        // before; apply that rule recursively so nested records compare too.
        if (key === 'createdAt' || key === 'updatedAt') { continue; }
        result[key] = canonicalize(input[key]);
      }
      return result;
    }
    return JSON.stringify(canonicalize(value || {}));
  }
  async function compare(payload) {
    const names = typeof getStoreNames === 'function' ? getStoreNames() : Object.keys(payload.stores || {});
    const stores = {}; let totalConflicts = 0, totalNew = 0, totalRemoved = 0;
    for (const storeName of names) {
      if (isUserStore(storeName)) { continue; }
      const current = await gAll(storeName);
      const incoming = Array.isArray(payload.stores?.[storeName]) ? payload.stores[storeName] : [];
      const currentById = new Map(current.map(row => [String(row.id), row]));
      const incomingById = new Map(incoming.map(row => [String(row.id), row]));
      let changed = 0, added = 0, conflicts = 0;
      for (const row of incoming) {
        const old = currentById.get(String(row.id));
        if (!old) { added += 1; } else if (stable(old) !== stable(row)) { changed += 1; conflicts += 1; }
      }
      let removed = 0;
      if (Object.prototype.hasOwnProperty.call(payload.stores, storeName)) {
        for (const row of current) { if (!incomingById.has(String(row.id))) { removed += 1; } }
      }
      stores[storeName] = { present: Object.prototype.hasOwnProperty.call(payload.stores, storeName), current: current.length, incoming: incoming.length, changed, added, removed, conflicts };
      totalConflicts += conflicts; totalNew += added; totalRemoved += removed;
    }
    const targets = { parts: 'component_parts', stock: 'component_stock', mappings: 'component_mappings' };
    const result = { stores, totalConflicts, totalNew, totalRemoved };
    for (const [label, storeName] of Object.entries(targets)) { result[label] = stores[storeName] || { current: 0, incoming: 0, changed: 0, added: 0, removed: 0, conflicts: 0 }; }
    return result;
  }
  function restoreTestRowKey(row) { return row && row.id !== undefined ? String(row.id) : null; }
  function canonicalRestoreData(value) {
    if (Array.isArray(value)) return value.map(canonicalRestoreData);
    if (!value || typeof value !== 'object') return value;
    const result = {};
    for (const key of Object.keys(value).sort()) result[key] = canonicalRestoreData(value[key]);
    return result;
  }
  async function runIsolatedRestoreTest(payload) {
    const errors = [], warnings = [], stores = {};
    if (!valid(payload)) return { ok: false, errors: ['Backup payload structure is invalid.'], warnings, stores, cleaned: true };
    if (Array.isArray(payload.stores.grn) && payload.stores.grn.some(row => !validGRN(row))) return { ok: false, errors: ['Backup contains malformed GRN rows.'], warnings, stores, cleaned: true };
    const operationalNames = (typeof getStoreNames === 'function' ? getStoreNames() : Object.keys(payload.stores)).filter(name => !isUserStore(name));
    const operationalSet = new Set(operationalNames);
    const unsupported = Object.keys(payload.stores).filter(name => !isUserStore(name) && !operationalSet.has(name));
    if (unsupported.length) errors.push(`Backup contains stores unsupported by this application version: ${unsupported.join(', ')}`);
    if (Object.prototype.hasOwnProperty.call(payload.stores, 'users')) warnings.push('User accounts are excluded from restore and remain unchanged.');
    const absentStores = operationalNames.filter(name => !Object.prototype.hasOwnProperty.call(payload.stores, name));
    if (absentStores.length) warnings.push(`Stores absent from the backup will be preserved: ${absentStores.join(', ')}`);

    let liveDb = null, closeLiveDb = true, testDb = null, testDbName = '', cleanupError = '';
    try {
      if (typeof indexedDB === 'undefined' || typeof indexedDB.open !== 'function') throw new Error('IndexedDB is unavailable; restore compatibility cannot be tested.');
      const dbName = typeof DB === 'string' ? DB : 'StoreTrackDB';
      const activeDb = typeof window.getDB === 'function' ? window.getDB() : null;
      if (activeDb) {
        liveDb = activeDb;
        closeLiveDb = false;
      } else {
        if (typeof indexedDB.databases !== 'function') throw new Error('Cannot confirm that the live database already exists; refusing to create or modify it for a restore test.');
        const databases = await indexedDB.databases();
        if (!databases.some(database => database.name === dbName)) throw new Error('The live database was not found; refusing to create it for a restore test.');
        liveDb = await new Promise((resolve, reject) => {
          const request = indexedDB.open(dbName);
          request.onerror = () => reject(request.error || new Error('Could not inspect the live database schema.'));
          request.onblocked = () => reject(new Error('Live database schema inspection is blocked.'));
          request.onsuccess = () => resolve(request.result);
        });
      }
      const schema = {};
      for (const name of operationalNames) {
        if (!liveDb.objectStoreNames.contains(name)) { schema[name] = null; continue; }
        const sourceStore = liveDb.transaction(name, 'readonly').objectStore(name);
        const indexes = Array.from(sourceStore.indexNames).map(indexName => {
          const index = sourceStore.index(indexName);
          return { name: index.name, keyPath: index.keyPath, unique: index.unique, multiEntry: index.multiEntry };
        });
        schema[name] = { keyPath: sourceStore.keyPath, autoIncrement: sourceStore.autoIncrement, indexes };
      }
      if (closeLiveDb) liveDb.close();
      liveDb = null;

      const missingSchema = Object.keys(payload.stores).filter(name => !isUserStore(name) && operationalSet.has(name) && !schema[name]);
      if (missingSchema.length) errors.push(`This application database is missing required store(s): ${missingSchema.join(', ')}`);
      const applicableNames = operationalNames.filter(name => Object.prototype.hasOwnProperty.call(payload.stores, name) && schema[name]);
      if (!applicableNames.length) errors.push('Backup has no operational records or compatible stores to restore.');
      if (errors.length) return { ok: false, errors, warnings, stores, cleaned: true, checkedAt: new Date().toISOString() };

      const encryptionManager = window.DataEncryption?.manager;
      let testManager = encryptionManager;
      const encryptionStoreNames = ['encryption_settings', 'encryption_fields', 'encryption_key'];
      if (encryptionManager && encryptionStoreNames.every(name => Object.prototype.hasOwnProperty.call(payload.stores, name))) {
        const settings = payload.stores.encryption_settings.find(row => row.id === 'settings');
        const fields = payload.stores.encryption_fields.find(row => row.id === 'config');
        const key = payload.stores.encryption_key.find(row => row.id === 'master');
        if (settings?.enabled && (!key || typeof key.key !== 'string' || !key.key)) throw new Error('Backup enables field encryption but its master key is missing.');
        if (settings?.enabled && (!fields || !Array.isArray(fields.fields) || fields.fields.some(field => typeof field !== 'string'))) throw new Error('Backup field-encryption configuration is invalid.');
        testManager = Object.create(Object.getPrototypeOf(encryptionManager));
        Object.assign(testManager, encryptionManager, {
          enabled: !!settings?.enabled,
          encryptionKey: key?.key || null,
          encryptedFields: new Set(Array.isArray(fields?.fields) ? fields.fields.filter(field => typeof field === 'string') : []),
        });
      }
      if (!testManager && payload.stores.encryption_settings?.some(row => row.id === 'settings' && row.enabled)) throw new Error('Field encryption is enabled in the backup but the application encryption manager is unavailable.');

      testDbName = `${dbName}_RestoreTest_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
      testDb = await new Promise((resolve, reject) => {
        const request = indexedDB.open(testDbName, 1);
        request.onupgradeneeded = () => {
          const isolated = request.result;
          for (const name of operationalNames) {
            const definition = schema[name];
            if (!definition) continue;
            const options = { autoIncrement: definition.autoIncrement };
            if (definition.keyPath !== null) options.keyPath = definition.keyPath;
            const store = isolated.createObjectStore(name, options);
            for (const index of definition.indexes) store.createIndex(index.name, index.keyPath, { unique: index.unique, multiEntry: index.multiEntry });
          }
        };
        request.onerror = () => reject(request.error || new Error('Could not create isolated restore database.'));
        request.onblocked = () => reject(new Error('Isolated restore database creation was blocked.'));
        request.onsuccess = () => resolve(request.result);
      });

      for (const name of applicableNames) {
        const expected = payload.stores[name];
        const prepared = await Promise.all(expected.map(row => testManager?.prepareForStorage ? testManager.prepareForStorage(name, row) : row));
        await new Promise((resolve, reject) => {
          let transaction;
          try {
            transaction = testDb.transaction(name, 'readwrite');
            const store = transaction.objectStore(name);
            for (const row of prepared) store.put(row);
          } catch (error) { reject(error); return; }
          transaction.oncomplete = resolve;
          transaction.onerror = () => reject(transaction.error || new Error(`Could not stage ${name}.`));
          transaction.onabort = () => reject(transaction.error || new Error(`Staging ${name} was aborted.`));
        });
        const restoredRows = await new Promise((resolve, reject) => {
          const transaction = testDb.transaction(name, 'readonly');
          const request = transaction.objectStore(name).getAll();
          request.onsuccess = () => resolve(request.result || []);
          request.onerror = () => reject(request.error || new Error(`Could not read staged ${name}.`));
        });
        if (restoredRows.length !== expected.length) throw new Error(`Store ${name}: expected ${expected.length} restored record(s), read back ${restoredRows.length}; duplicate or incompatible keys may have overwritten data.`);
        const expectedById = new Map(expected.filter(row => restoreTestRowKey(row) !== null).map(row => [restoreTestRowKey(row), row]));
        for (const row of restoredRows) {
          const id = restoreTestRowKey(row);
          if (id === null || !expectedById.has(id)) continue;
          const decoded = testManager?.restoreFromStorage ? await testManager.restoreFromStorage(name, row) : row;
          if (JSON.stringify(canonicalRestoreData(decoded)) !== JSON.stringify(canonicalRestoreData(expectedById.get(id)))) throw new Error(`Store ${name}, record ${id}: staged read-back did not match the backup data.`);
        }
        stores[name] = { expected: expected.length, restored: restoredRows.length, ok: true };
      }
    } catch (error) {
      errors.push(error?.message || 'Isolated restore test failed.');
    } finally {
      if (liveDb && closeLiveDb) { try { liveDb.close(); } catch (_) {} }
      if (testDb) { try { testDb.close(); } catch (_) {} testDb = null; }
      if (testDbName) {
        try {
          await new Promise((resolve, reject) => {
            const request = indexedDB.deleteDatabase(testDbName);
            request.onsuccess = resolve;
            request.onerror = () => reject(request.error || new Error('Could not clean up isolated restore database.'));
            request.onblocked = () => reject(new Error('Cleanup of the isolated restore database was blocked.'));
          });
        } catch (error) { cleanupError = error?.message || 'Temporary restore database cleanup failed.'; errors.push(cleanupError); }
      }
    }
    return { ok: errors.length === 0, errors, warnings, stores, cleaned: !cleanupError, checkedAt: new Date().toISOString() };
  }
  function saveRestoreVerification(result, fileName, mode) {
    const record = { ok: !!result?.ok, fileName: String(fileName || 'backup'), mode: String(mode || 'manual'), checkedAt: result?.checkedAt || new Date().toISOString(), errors: result?.errors || [], warnings: result?.warnings || [], stores: result?.stores || {}, cleaned: result?.cleaned !== false };
    try { localStorage.setItem(RESTORE_TEST_KEY, JSON.stringify(record)); } catch (_) { /* Result remains available to the current caller. */ }
    return record;
  }
  function escapeBackupHtml(value) {
    return String(value ?? '').split('&').join('&amp;').split('<').join('&lt;').split('>').join('&gt;').split('"').join('&quot;').split("'").join('&#39;');
  }
  function renderRestoreVerification(record, host) {
    if (!host) return;
    const escape = escapeBackupHtml;
    const storeData = record?.stores && typeof record.stores === 'object' && !Array.isArray(record.stores) ? record.stores : {};
    const rows = Object.entries(storeData).map(([name, counts]) => `<li>${escape(name)}: ${escape(counts?.restored ?? '?')}/${escape(counts?.expected ?? '?')} records restored and read back</li>`).join('');
    const errors = (Array.isArray(record?.errors) ? record.errors : []).map(error => `<li>${escape(error)}</li>`).join('');
    const warnings = (Array.isArray(record?.warnings) ? record.warnings : []).map(warning => `<li>${escape(warning)}</li>`).join('');
    host.innerHTML = `<div class="alrt ${record?.ok ? 'alrt-s' : 'alrt-r'}" role="status" aria-live="polite"><strong>${record?.ok ? 'Isolated restore test passed' : 'Isolated restore test failed'}</strong><br>${escape(record?.fileName || 'backup')} · ${escape(record?.checkedAt || '')} · Temporary test data ${record?.cleaned ? 'cleaned up' : 'cleanup incomplete'}${rows ? `<ul>${rows}</ul>` : ''}${warnings ? `<br>Warnings:<ul>${warnings}</ul>` : ''}${errors ? `<br>Errors:<ul>${errors}</ul>` : ''}</div>`;
  }
  async function createBackup(force) {
    if (!window.backupBridge?.write) { statusText('Backup bridge is unavailable', 'er'); return { ok: false, reason: 'bridge' }; }
    const today = dateKey();
    if (!force && localStorage.getItem(BACKUP_KEY) === today) { return { ok: true, skipped: true, date: today }; }
    const payload = await collect();
    const validationError = (() => {
      if (!payload || payload.format !== 'StoreTrackProCompleteBackup') return 'invalid backup format';
      if (!payload.stores || typeof payload.stores !== 'object' || Array.isArray(payload.stores)) return 'stores payload is not an object';
      if (!Object.keys(payload.stores).length) return 'no stores were collected';
      for (const [storeName, rows] of Object.entries(payload.stores)) {
        if (!Array.isArray(rows)) return `store ${storeName} is not an array`;
        const badIndex = rows.findIndex(row => !row || typeof row !== 'object' || Array.isArray(row));
        if (badIndex >= 0) return `store ${storeName} contains an invalid row at index ${badIndex}`;
      }
      return '';
    })();
    if (validationError) { console.error('[Backup validation]', validationError); statusText(`Backup validation failed: ${validationError}; existing backup was preserved`, 'er'); return { ok: false, reason: 'validation', detail: validationError }; }
    const result = await window.backupBridge.write(JSON.stringify(payload));
    if (!result?.ok) { statusText(result?.error || 'Backup failed; existing backup was preserved', 'er'); return result || { ok: false }; }
    localStorage.setItem(BACKUP_KEY, today);
    let restoreVerification;
    try { restoreVerification = saveRestoreVerification(await runIsolatedRestoreTest(payload), result.fileName || today, 'automatic-after-backup'); }
    catch (error) { restoreVerification = saveRestoreVerification({ ok: false, errors: [error?.message || 'Restore verification failed.'], stores: {}, cleaned: true }, result.fileName || today, 'automatic-after-backup'); }
    statusText(restoreVerification.ok ? `Backup created and isolated restore-tested: ${result.fileName || today}` : `Backup saved, but isolated restore verification failed: ${(restoreVerification.errors || []).join('; ')}`, restoreVerification.ok ? 'suc' : 'er');
    return { ...result, restoreVerification };
  }
  async function restoreBackup(portableSerialized, importedFileName, options = {}) {
    if (!window.backupBridge?.read) { statusText('Backup bridge is unavailable', 'er'); return; }
    let raw;
    if (typeof portableSerialized === 'string') {
      if (!window.backupBridge?.decryptPortable) { statusText('Portable backup import is unavailable', 'er'); return; }
      raw = await window.backupBridge.decryptPortable(portableSerialized);
      if (raw?.ok) { raw.fileName = importedFileName || 'portable backup JSON'; }
    } else {
      raw = await window.backupBridge.read();
    }
    if (!raw?.ok) { statusText(raw?.error || 'No valid backup found', 'er'); return; }
    let payload;
    try { payload = JSON.parse(raw.data); } catch (_) { statusText('Backup file is invalid', 'er'); return; }
    if (!valid(payload)) { statusText('Backup validation failed', 'er'); return; }
    if (Array.isArray(payload.stores.grn) && payload.stores.grn.some(row => !validGRN(row))) { statusText('Restore cancelled: backup contains malformed GRN rows. No data was changed.', 'er'); return; }
    const preview = await compare(payload);
    const names = typeof getStoreNames === 'function' ? getStoreNames() : Object.keys(payload.stores);
    const missingStores = names.filter(name => !isUserStore(name) && !Object.prototype.hasOwnProperty.call(payload.stores, name));
    const missingNote = missingStores.length ? `\n\nIMPORTANT: This backup does not contain ${missingStores.length} current operational store(s): ${missingStores.join(', ')}. Those stores will be PRESERVED and not cleared.` : '';
    const accountNote = '\n\nUser account records are always preserved and never restored from any backup.';
    const securityNote = raw.portable ? '\n\nSECURITY WARNING: This portable JSON includes its own recovery key. Anyone with the file can restore/read its data; store it securely.' : raw.encrypted === false ? '\n\nSECURITY WARNING: This is a legacy plaintext backup. Restore only if you trust its source, then create a new encrypted backup.' : raw.encrypted === true ? '\n\nThis backup is encrypted and authenticated with this computer\'s protected key.' : ''; 
    const perStore = Object.entries(preview.stores).map(([name, counts]) => `${name}: ${counts.current} current, ${counts.incoming} in backup, ${counts.added} added, ${counts.changed} changed, ${counts.removed} removed${counts.present ? ' (store contents replaced)' : ' (local store preserved; absent from backup)'}`).join('\n');
    const summary = `Restore Preview (${raw.fileName || 'backup'})\nBackup created: ${payload.createdAt || 'date not recorded'}\n\n${perStore}\n\nNew records: ${preview.totalNew}\nChanged/conflicting records: ${preview.totalConflicts}\nRecords removed by replacement: ${preview.totalRemoved}${missingNote}${accountNote}${securityNote}\n\nA safety backup of current operational data will be created automatically before restore.`;
    if (options.testOnly) {
      const testResult = saveRestoreVerification(await runIsolatedRestoreTest(payload), raw.fileName || importedFileName || 'backup', 'user-requested-test');
      renderRestoreVerification(testResult, document.getElementById('backup-restore-test-result'));
      statusText(testResult.ok ? `Isolated restore test passed for ${raw.fileName || 'backup'}; live data and backup files were not changed.` : `Isolated restore test failed: ${(testResult.errors || []).join('; ')}`, testResult.ok ? 'suc' : 'er');
      return { ok: testResult.ok, testOnly: true, preview, testResult };
    }
    const host = document.getElementById('backup-restore-preview');
    if (host) {
      const visibleMissingNote = missingStores.length
        ? `<div class="alrt alrt-y"><strong>Partial restore warning:</strong> This backup does not contain ${missingStores.length} current operational store(s): ${missingStores.map(name => String(name).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]))).join(', ')}. These stores will be <strong>preserved</strong> and not cleared.</div>`
        : '';
      const legacyWarning = raw.encrypted === false ? '<div class="alrt alrt-y"><strong>Legacy plaintext backup:</strong> this file is not encrypted or authenticated. Restore only if trusted and create a new encrypted backup afterward.</div>' : '';
      const portableWarning = raw.portable ? '<div class="alrt alrt-y"><strong>Portable key included:</strong> this JSON contains the key needed to decrypt it. Anyone who obtains the file can restore its contents.</div>' : '';
      const encryptionNote = raw.portable ? 'Portable encrypted backup.' : raw.encrypted === true ? 'Encrypted and authenticated backup.' : raw.encrypted === false ? 'Plaintext backup; not authenticated.' : 'Encryption status was not provided.';
      const escape = escapeBackupHtml;
      const detailRows = Object.entries(preview.stores).map(([name, counts]) => `<tr><td>${escape(name)}</td><td>${counts.current}</td><td>${counts.incoming}</td><td>${counts.added}</td><td>${counts.changed}</td><td>${counts.removed}</td><td>${counts.present ? 'Replace with backup rows' : 'Preserve current store (not in backup)'}</td></tr>`).join('');
      const backupRecordTotal = Object.entries(payload.stores).reduce((sum, [name, rows]) => sum + (!isUserStore(name) && Array.isArray(rows) ? rows.length : 0), 0);
      let previousVerification = null;
      try { previousVerification = JSON.parse(localStorage.getItem(RESTORE_TEST_KEY) || 'null'); } catch (_) {}
      host.innerHTML = `${legacyWarning}${portableWarning}${visibleMissingNote}<div class="alrt ${preview.totalConflicts ? 'alrt-y' : 'alrt-b'}"><strong>Restore Preview · ${escape(raw.fileName || 'backup')}</strong><br><span class="muted">Backup created: ${escape(payload.createdAt || 'date not recorded')} · ${backupRecordTotal} operational backup record(s). User accounts are never restored and remain unchanged.</span><div class="tw"><table><thead><tr><th>Store</th><th>Current</th><th>In backup</th><th>Added</th><th>Changed</th><th>Removed</th><th>Restore action</th></tr></thead><tbody>${detailRows}</tbody></table></div><strong>Totals:</strong> ${preview.totalNew} new · ${preview.totalConflicts} changed/conflicting · ${preview.totalRemoved} removed by replacement<br><span class="muted">${encryptionNote} A safety backup will be created before restore. Explicit confirmation is required; absent stores are preserved.</span><br><button id="backup-restore-test-btn" class="btn" type="button">Run Non-mutating Restore Test</button><div id="backup-restore-test-result"></div></div>`;
      if (previousVerification) renderRestoreVerification(previousVerification, document.getElementById('backup-restore-test-result'));
      document.getElementById('backup-restore-test-btn')?.addEventListener('click', () => restoreBackup(portableSerialized, importedFileName, { testOnly: true }).catch(error => { const record = saveRestoreVerification({ ok: false, errors: [error.message || 'Restore test failed.'], cleaned: true }, raw.fileName || 'backup', 'user-requested-test'); renderRestoreVerification(record, document.getElementById('backup-restore-test-result')); statusText(`Restore test failed: ${error.message}; no data was changed.`, 'er'); }));
    }
    if (!confirm(summary + '\n\nContinue?')) { return; }
    const safety = await createBackup(true);
    if (!safety?.ok && !safety?.skipped) { statusText('Restore cancelled because the safety backup failed', 'er'); return; }
    let currentSnapshot;
    try { currentSnapshot = await readSnapshot(names, { decrypt: false }); }
    catch (snapshotError) { statusText(`Restore cancelled because a recovery snapshot could not be secured: ${snapshotError.message}`, 'er'); return; }
    const encryptionManager = window.DataEncryption?.manager;
    const previousEncryptionState = encryptionManager ? {
      enabled: encryptionManager.enabled,
      encryptionKey: encryptionManager.encryptionKey,
      encryptedFields: new Set(encryptionManager.encryptedFields || []),
    } : null;
    try { await writeRestoreJournal(currentSnapshot); }
    catch (journalError) { statusText(`Restore cancelled because a recovery snapshot could not be secured: ${journalError.message}`, 'er'); return; }
    const applyBackupEncryptionState = () => {
      const configStores = ['encryption_settings', 'encryption_fields', 'encryption_key'];
      if (!encryptionManager || !configStores.every(name => Object.prototype.hasOwnProperty.call(payload.stores, name))) { return; }
      const settings = payload.stores.encryption_settings.find(row => row.id === 'settings');
      const fields = payload.stores.encryption_fields.find(row => row.id === 'config');
      const key = payload.stores.encryption_key.find(row => row.id === 'master');
      if (settings?.enabled && (!key || typeof key.key !== 'string' || !key.key)) {
        throw new Error('Backup has field encryption enabled but its master key is missing; no data was changed.');
      }
      encryptionManager.enabled = !!settings?.enabled;
      encryptionManager.encryptionKey = key?.key || null;
      encryptionManager.encryptedFields = new Set(Array.isArray(fields?.fields) ? fields.fields.filter(field => typeof field === 'string') : []);
    };
    const restorePreviousEncryptionState = () => {
      if (!encryptionManager || !previousEncryptionState) { return; }
      encryptionManager.enabled = previousEncryptionState.enabled;
      encryptionManager.encryptionKey = previousEncryptionState.encryptionKey;
      encryptionManager.encryptedFields = new Set(previousEncryptionState.encryptedFields);
    };
    try {
      // dPut encrypts records through this in-memory manager. Adopt the backup
      // field-encryption settings/key before writing its data, so imported rows
      // and the restored key remain compatible after app restart on another PC.
      applyBackupEncryptionState();
      for (const name of names) {
        if (isUserStore(name) || !Object.prototype.hasOwnProperty.call(payload.stores, name)) { continue; }
        await dClr(name);
        for (const row of (Array.isArray(payload.stores[name]) ? payload.stores[name] : [])) { await dPut(name, row); }
      }
      await writeRestoreJournal({}, 'committed');
      try { await clearRestoreJournal(); } catch (journalCleanupError) { console.warn('[Backup recovery journal cleanup]', journalCleanupError); }
    } catch (restoreError) {
      restorePreviousEncryptionState();
      try {
        await restoreRawSnapshot(currentSnapshot);
        await clearRestoreJournal();
        statusText('Restore failed; previous data was restored from the safety snapshot', 'er');
      } catch (rollbackError) {
        console.error('[Backup rollback]', rollbackError);
        statusText('Restore failed and automatic rollback is pending; restart the application before using inventory data', 'er');
      }
      return;
    }
    const restoredTotal = Object.values(payload.stores).reduce((sum, rows) => sum + (Array.isArray(rows) ? rows.length : 0), 0);
    statusText(`Backup restored: ${restoredTotal} records. Reloading StoreTrack Pro to refresh every module.`, 'suc');
    if (typeof audit === 'function') { await audit('COMPLETE_BACKUP_RESTORE', 'Backup', raw.fileName || 'latest', { createdAt: payload.createdAt }); }
    setTimeout(() => window.location.reload(), 250);
  }
  let latestBackupPath = '';
  async function openBackupFolder() {
    if (!window.backupBridge?.openFolder) { statusText('Open Backup Folder is unavailable', 'er'); return; }
    const result = await window.backupBridge.openFolder();
    if (!result?.ok) { statusText(result?.error || 'Could not open Backup Folder', 'er'); }
  }
  async function copyBackupPath() {
    if (!latestBackupPath) { statusText('No backup path available', 'er'); return; }
    try {
      await navigator.clipboard.writeText(latestBackupPath);
      statusText('Backup path copied to clipboard', 'suc');
    } catch (error) {
      console.error('[Backup path copy]', error);
      statusText('Could not copy backup path', 'er');
    }
  }
  function showBackupSuccess(result) {
    if (!result?.ok || !result.path) { return; }
    latestBackupPath = result.path;
    const host = document.getElementById('backup-action-status');
    if (!host) { return; }
    const verification = result.restoreVerification?.ok === true ? 'Isolated restore test passed.' : result.restoreVerification ? `Isolated restore test failed: ${(result.restoreVerification.errors || []).join('; ')}` : 'Restore test status unavailable.';
    const safe = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
    host.innerHTML = `<div class="alrt ${result.restoreVerification?.ok === false ? 'alrt-y' : 'alrt-s'}"><strong>${result.portable ? 'Portable backup file created; recovery key is included in the JSON' : 'Backup file created'}</strong><br>${safe(verification)}<br><span class="muted">Location:</span><br><code style="word-break:break-all;">${safe(result.path)}</code></div><div class="btn-row">${result.portable ? '' : '<button class="btn btn-p" type="button" data-onclick="openBackupFolder()">Open Backup Folder</button>'}<button class="btn" type="button" data-onclick="copyBackupPath()">Copy Backup Path</button></div>`;
  }
  async function createCompleteBackupFromButton() {
    if (!confirm('Create an encrypted and authenticated operational backup? User accounts/password hashes are excluded. Continue?')) { return { ok: false, cancelled: true }; }
    const result = await createBackup(true);
    if (result?.ok && !result?.skipped) { showBackupSuccess(result); }
    return result;
  }
  async function createPortableBackupFromButton() {
    if (!window.backupBridge?.exportPortable) { statusText('Portable backup export is unavailable', 'er'); return { ok: false, reason: 'bridge' }; }
    if (!confirm('Create a portable JSON backup that contains its own recovery key? It can be restored on any PC without the original machine key, but anyone with this file can decrypt and restore its data. Store it securely. Continue?')) { return { ok: false, cancelled: true }; }
    const payload = await collect();
    const issue = validationIssue(payload);
    if (issue) { statusText(`Portable backup validation failed: ${issue}`, 'er'); return { ok: false, reason: 'validation', detail: issue }; }
    const restoreVerification = saveRestoreVerification(await runIsolatedRestoreTest(payload), 'portable backup', 'automatic-before-portable-export');
    if (!restoreVerification.ok) { statusText(`Portable backup was not exported because isolated restore verification failed: ${(restoreVerification.errors || []).join('; ')}`, 'er'); return { ok: false, reason: 'restore-verification', restoreVerification }; }
    const result = await window.backupBridge.exportPortable(JSON.stringify(payload));
    if (!result?.ok) {
      if (!result?.cancelled) { statusText(result?.error || 'Portable backup export failed', 'er'); }
      return result || { ok: false };
    }
    latestBackupPath = result.path || '';
    showBackupSuccess({ ...result, portable: true, restoreVerification });
    statusText(`Portable backup saved and isolated restore-tested: ${result.fileName}`, 'suc');
    return { ...result, restoreVerification };
  }
  function importPortableFile(event) {
    const file = event?.target?.files?.[0];
    if (!file) { return; }
    event.target.value = '';
    if (file.size > 200 * 1024 * 1024) { statusText('Backup file too large (maximum 200 MB)', 'er'); return; }
    const reader = new FileReader();
    reader.onerror = () => statusText('Could not read the selected backup file', 'er');
    reader.onload = () => {
      if (typeof reader.result !== 'string') { statusText('Backup file is invalid', 'er'); return; }
      restoreBackup(reader.result, file.name).catch(error => { console.error('[Portable backup restore]', error); statusText('Portable restore failed: ' + (error?.message || 'Unknown error'), 'er'); });
    };
    reader.readAsText(file);
  }
  async function openBackupCenter() {
    // The backup host lives inside the Shank Mapping component section. The
    // side-menu shortcut must activate that section before injecting the view.
    if (typeof nav === 'function') { nav('component', { bypassFeatureGate: true }); }
    let latest = null;
    try { latest = window.backupBridge?.status ? await window.backupBridge.status() : null; } catch (error) { console.warn('[Backup status]', error); }
    const verification = latest?.verification;
    const verificationText = verification ? `<br>Retained backup integrity: ${verification.passed}/${verification.checked} passed, ${verification.failed} failed.` : '';
    let restoreVerification = null;
    try { restoreVerification = JSON.parse(localStorage.getItem(RESTORE_TEST_KEY) || 'null'); } catch (_) {}
    const restoreErrors = Array.isArray(restoreVerification?.errors) ? restoreVerification.errors : [];
    const restoreErrorText = restoreErrors.length ? ` · ${escapeBackupHtml(restoreErrors.join('; '))}` : '';
    const restoreText = restoreVerification ? `<br>Latest isolated restore test: ${restoreVerification.ok ? 'PASSED' : 'FAILED'} · ${escapeBackupHtml(restoreVerification.fileName || 'backup')} · ${escapeBackupHtml(restoreVerification.checkedAt || '')}. Temporary DB cleanup: ${restoreVerification.cleaned ? 'completed' : 'incomplete'}${restoreErrorText}.` : '<br>No isolated restore test has been recorded on this device yet.';
    const text = latest?.fileName ? `Latest backup: ${latest.fileName}<br>Created: ${latest.createdAt || 'Unknown'}<br>Location: ${latest.path || 'Application data Backups folder'}${verificationText}${restoreText}` : `No daily backup has been created yet.${verificationText}${restoreText}`;
    latestBackupPath = latest?.path || '';
    const html = `<div class="alrt alrt-s"><strong>Automatic backup protection:</strong> Daily backups use authenticated AES-256-GCM encryption with a key protected by this Windows installation. They are for this PC only. User accounts/password hashes are excluded; accounts already on the restore PC are preserved.</div><div class="alrt alrt-b">For a new PC: on the source PC select <strong>Create Backup for Any Windows PC</strong>, copy the resulting portable JSON file to the target PC, then choose <strong>Import Portable Backup JSON</strong> here and confirm the preview. This restores StoreTrack Pro and Shank Mapping operational data.</div><div class="alrt alrt-y"><strong>Portable-file security:</strong> portable JSON contains its recovery key. Anyone holding that file can decrypt its data, so keep it in a trusted location and do not send it through a public or untrusted channel.</div><div class="card">${text}</div><div id="backup-action-status"></div><div id="backup-restore-preview"></div><div class="btn-row"><button id="backup-portable-btn" class="btn btn-p" type="button">Create Backup for Any Windows PC (portable JSON)</button><button id="backup-now-btn" class="btn" type="button">Create This-PC Encrypted Backup</button></div><div class="btn-row"><button id="backup-restore-btn" class="btn" type="button">Restore Latest Backup (this PC)</button><button id="backup-import-portable-btn" class="btn btn-p" type="button">Import Backup from Another PC</button></div><input id="backup-portable-file" type="file" accept=".json,application/json" style="display:none">`;
    const host = document.getElementById('component-management-content');
    if (host) {
      host.innerHTML = `<div class="card"><div class="card-hd">Backup & Restore</div>${html}</div>`;
      document.getElementById('backup-now-btn')?.addEventListener('click', () => {
        createCompleteBackupFromButton().catch(error => { console.error('[Backup create]', error); statusText('Backup failed: ' + (error?.message || 'Unknown error'), 'er'); });
      });
      document.getElementById('backup-restore-btn')?.addEventListener('click', () => {
        restoreBackup().catch(error => { console.error('[Backup restore]', error); statusText('Restore failed: ' + (error?.message || 'Unknown error'), 'er'); });
      });
      document.getElementById('backup-portable-btn')?.addEventListener('click', () => {
        createPortableBackupFromButton().catch(error => { console.error('[Portable backup create]', error); statusText('Portable backup failed: ' + (error?.message || 'Unknown error'), 'er'); });
      });
      const portableInput = document.getElementById('backup-portable-file');
      document.getElementById('backup-import-portable-btn')?.addEventListener('click', () => portableInput?.click());
      portableInput?.addEventListener('change', importPortableFile);
    } else { statusText('Backup screen is not available yet. Open Shank Mapping Dashboard once, then try again.', 'er'); }
  }
  function startDaily() {
    if (timer) { clearInterval(timer); }
    const run = async () => { try { await recoverInterruptedRestore(); } catch (error) { console.error('[Backup recovery]', error); statusText(`Restore recovery is pending: ${error.message}`, 'er'); return; } await createBackup(false); };
    run().catch(error => console.error('[Backup]', error));
    timer = setInterval(() => run().catch(error => console.error('[Backup]', error)), 60 * 60 * 1000);
  }
  window.componentCreateCompleteBackup = createCompleteBackupFromButton;
  window.componentCreatePortableBackup = createPortableBackupFromButton;
  window.openBackupFolder = openBackupFolder;
  window.copyBackupPath = copyBackupPath;
  window.componentRestoreCompleteBackup = restoreBackup;
  window.componentRunIsolatedRestoreTest = runIsolatedRestoreTest;
  window.openBackupCenter = openBackupCenter;
  window.recoverInterruptedStoreTrackRestore = recoverInterruptedRestore;
  window.startStoreTrackDailyBackup = startDaily;
  function wireBackupButtons() {
    document.querySelectorAll('[data-backup-open]').forEach(button => {
      if (button.dataset.backupWired === 'true') { return; }
      button.dataset.backupWired = 'true';
      button.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); openBackupCenter().catch(error => { console.error('[Backup open]', error); statusText('Could not open Backup & Restore', 'er'); }); });
    });
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', wireBackupButtons, { once: true }); }
  else { wireBackupButtons(); }
}());
