/**
 * Enterprise Notification Service
 * Centralized notification management for StoreTrack Pro
 */

class AppNotification {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.type = config.type || 'info'; // info, success, warning, error, critical
    this.category = config.category || 'general'; // inventory, security, system, user, report
    this.title = config.title || '';
    this.message = config.message || '';
    this.data = config.data || {};
    this.userId = config.userId || null;
    this.audienceRoles = Array.isArray(config.audienceRoles) ? config.audienceRoles : null;
    this.isGlobal = config.isGlobal || false;
    this.priority = config.priority || 'normal'; // low, normal, high, urgent
    this.read = config.read !== false;
    this.readAt = config.readAt || null;
    this.expiresAt = config.expiresAt || null;
    this.actionable = config.actionable || false;
    this.actions = config.actions || [];
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `notification-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Mark as read
   */
  markAsRead() {
    this.read = true;
    this.readAt = new Date().toISOString();
  }

  /**
   * Check if expired
   * @returns {boolean} Is expired
   */
  isExpired() {
    if (!this.expiresAt) {return false;}
    return new Date() >= new Date(this.expiresAt);
  }
}

class NotificationServicePreference {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.userId = config.userId || '';
    this.category = config.category || 'all';
    this.enabled = config.enabled !== false;
    this.channels = config.channels || ['in_app']; // in_app, email, sms, push
    this.frequency = config.frequency || 'immediate'; // immediate, daily, weekly, never
    this.quietHours = config.quietHours || null; // { start: '22:00', end: '08:00' }
    this.createdAt = config.createdAt || new Date().toISOString();
    this.updatedAt = config.updatedAt || new Date().toISOString();
  }

  generateId() {
    return `pref-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Check if notification should be sent now
   * @returns {boolean} Should send
   */
  shouldSendNow() {
    if (!this.enabled) {return false;}
    if (this.frequency === 'never') {return false;}

    if (this.quietHours) {
      const now = new Date();
      const currentTime = now.getHours() * 60 + now.getMinutes();
      
      const [startHour, startMin] = this.quietHours.start.split(':').map(Number);
      const [endHour, endMin] = this.quietHours.end.split(':').map(Number);
      if (![startHour, startMin, endHour, endMin].every(Number.isFinite) || startHour < 0 || startHour > 23 || endHour < 0 || endHour > 23 || startMin < 0 || startMin > 59 || endMin < 0 || endMin > 59) return true;
      
      const startTime = startHour * 60 + startMin;
      const endTime = endHour * 60 + endMin;

      const inQuietHours = startTime < endTime
        ? currentTime >= startTime && currentTime < endTime
        : startTime > endTime && (currentTime >= startTime || currentTime < endTime);
      if (inQuietHours) {
        return false;
      }
    }

    return true;
  }
}

class NotificationService {
  constructor() {
    this.notifications = new Map();
    this.preferences = new Map();
    this.channels = new Map();
    this.init();
  }

  /**
   * Initialize notification service
   */
  async init() {
    await this.loadNotifications();
    await this.loadPreferences();
    await this.loadChannels();
    this.cleanupExpiredNotifications();
    this.startCleanupInterval();
  }

  /**
   * Load notifications from storage
   */
  async loadNotifications() {
    try {
      const notifications = await gAll('notifications');
      notifications.forEach(n => {
        this.notifications.set(n.id, new AppNotification(n));
      });
    } catch (err) {
      console.error('Failed to load notifications:', err);
    }
  }

  /**
   * Load preferences from storage
   */
  async loadPreferences() {
    try {
      const preferences = await gAll('notification_preferences');
      preferences.forEach(p => {
        this.preferences.set(p.id, new NotificationServicePreference(p));
      });
    } catch (err) {
      console.error('Failed to load notification preferences:', err);
    }
  }

  /**
   * Load channels from storage
   */
  async loadChannels() {
    try {
      const channels = await gAll('notification_channels');
      channels.forEach(c => {
        this.channels.set(c.id, c);
      });
    } catch (err) {
      console.error('Failed to load notification channels:', err);
    }
  }

  /**
   * Cleanup expired notifications
   */
  async cleanupExpiredNotifications() {
    for (const [id, notification] of this.notifications) {
      if (notification.isExpired()) {
        this.notifications.delete(id);
        await dDel('notifications', id);
      }
    }
  }

  /**
   * Start cleanup interval
   */
  startCleanupInterval() {
    setInterval(() => {
      this.cleanupExpiredNotifications();
    }, 3600000); // Every hour
  }

  /**
   * Create notification
   * @param {object} config - Notification configuration
   * @returns {Notification} Created notification
   */
  async createNotification(config) {
    const notification = new AppNotification(config);
    this.notifications.set(notification.id, notification);
    await this.saveNotification(notification);

    // Send through channels
    await this.sendNotification(notification);

    // Log activity
    if (typeof window !== 'undefined' && window.ActivityTracking) {
      await window.ActivityTracking.logActivity('notification_created', 'notification', notification.id, {
        type: notification.type,
        category: notification.category,
        userId: notification.userId
      });
    }

    return notification;
  }

  /**
   * Send notification through channels
   * @param {Notification} notification - Notification to send
   */
  async sendNotification(notification) {
    const preferences = this.getUserPreferences(notification.userId);
    
    for (const preference of preferences) {
      if (!preference.shouldSendNow()) {continue;}
      
      for (const channel of preference.channels) {
        await this.sendViaChannel(notification, channel);
      }
    }

    // Emit event for in-app notifications
    if (typeof window !== 'undefined' && window.eventBus) {
      window.eventBus.emit('NOTIFICATION', notification);
    }
  }

  /**
   * Send notification via channel
   * @param {Notification} notification - Notification
   * @param {string} channel - Channel type
   */
  async sendViaChannel(notification, channel) {
    switch (channel) {
      case 'in_app':
        // Already handled by event bus
        break;
      case 'email':
        await this.sendViaEmail(notification);
        break;
      case 'sms':
        await this.sendViaSMS(notification);
        break;
      case 'push':
        await this.sendViaPush(notification);
        break;
    }
  }

  /**
   * Send via email
   * @param {Notification} notification - Notification
   */
  async sendViaEmail(notification) {
    if (typeof window !== 'undefined' && window.EmailService) {
      await window.EmailService.sendNotificationEmail(notification);
    }
  }

  /**
   * Send via SMS
   * @param {Notification} notification - Notification
   */
  async sendViaSMS(notification) {
    if (typeof window !== 'undefined' && window.SMSService?.sendNotificationSMS) {
      return window.SMSService.sendNotificationSMS(notification);
    }
    return { sent: false, reason: 'SMS service is not configured' };
  }

  /**
   * Send via push
   * @param {Notification} notification - Notification
   */
  async sendViaPush(notification) {
    if (typeof window !== 'undefined' && window.PushNotifications?.send) {
      return window.PushNotifications.send(notification);
    }
    if (typeof window !== 'undefined' && window.PushNotificationManager?.send) {
      return window.PushNotificationManager.send(notification);
    }
    return { sent: false, reason: 'Push service is not configured' };
  }

  /**
   * Save notification to storage
   * @param {Notification} notification - Notification to save
   */
  async saveNotification(notification) {
    try {
      await dPut('notifications', notification);
    } catch (err) {
      console.error('Failed to save notification:', err);
    }
  }

  /**
   * Update notification
   * @param {string} id - Notification ID
   * @param {object} updates - Updates to apply
   * @returns {Notification} Updated notification
   */
  async updateNotification(id, updates) {
    const notification = this.notifications.get(id);
    if (notification) {
      Object.assign(notification, updates);
      await this.saveNotification(notification);
    }
    return notification;
  }

  /**
   * Delete notification
   * @param {string} id - Notification ID
   */
  async deleteNotification(id) {
    this.notifications.delete(id);
    await dDel('notifications', id);
  }

  /**
   * Mark notification as read
   * @param {string} id - Notification ID
   */
  async markAsRead(id) {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.markAsRead();
      await this.saveNotification(notification);
    }
  }

  /**
   * Mark all notifications as read for user
   * @param {string} userId - User ID
   */
  async markAllAsRead(userId) {
    const userNotifications = this.getNotificationsForUser(userId);
    for (const notification of userNotifications) {
      notification.markAsRead();
      await this.saveNotification(notification);
    }
  }

  /**
   * Create notification preference
   * @param {object} config - Preference configuration
   * @returns {NotificationServicePreference} Created preference
   */
  async createPreference(config) {
    const preference = new NotificationServicePreference(config);
    this.preferences.set(preference.id, preference);
    await this.savePreference(preference);
    return preference;
  }

  /**
   * Update notification preference
   * @param {string} id - Preference ID
   * @param {object} updates - Updates to apply
   * @returns {NotificationServicePreference} Updated preference
   */
  async updatePreference(id, updates) {
    const preference = this.preferences.get(id);
    if (preference) {
      Object.assign(preference, updates);
      preference.updatedAt = new Date().toISOString();
      await this.savePreference(preference);
    }
    return preference;
  }

  /**
   * Delete notification preference
   * @param {string} id - Preference ID
   */
  async deletePreference(id) {
    this.preferences.delete(id);
    await dDel('notification_preferences', id);
  }

  /**
   * Save preference to storage
   * @param {NotificationServicePreference} preference - Preference to save
   */
  async savePreference(preference) {
    try {
      await dPut('notification_preferences', preference);
    } catch (err) {
      console.error('Failed to save notification preference:', err);
    }
  }

  /**
   * Get notification
   * @param {string} id - Notification ID
   * @returns {Notification} Notification
   */
  getNotification(id) {
    return this.notifications.get(id);
  }

  /**
   * Get notifications for user
   * @param {string} userId - User ID
   * @returns {Array} Notifications
   */
  getNotificationsForUser(userId) {
    return Array.from(this.notifications.values())
      .filter(n => n.userId === userId || n.isGlobal)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  /**
   * Get unread notifications for user
   * @param {string} userId - User ID
   * @returns {Array} Unread notifications
   */
  getUnreadNotifications(userId) {
    return this.getNotificationsForUser(userId).filter(n => !n.read);
  }

  /**
   * Get global notifications
   * @returns {Array} Global notifications
   */
  getGlobalNotifications() {
    return Array.from(this.notifications.values())
      .filter(n => n.isGlobal)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  /**
   * Get notifications by category
   * @param {string} category - Category
   * @returns {Array} Notifications
   */
  getNotificationsByCategory(category) {
    return Array.from(this.notifications.values())
      .filter(n => n.category === category)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  /**
   * Get user preferences
   * @param {string} userId - User ID
   * @returns {Array} Preferences
   */
  getUserPreferences(userId) {
    return Array.from(this.preferences.values())
      .filter(p => p.userId === userId || p.userId === '');
  }

  /**
   * Get preference
   * @param {string} id - Preference ID
   * @returns {NotificationServicePreference} Preference
   */
  getPreference(id) {
    return this.preferences.get(id);
  }

  /**
   * Get statistics
   * @returns {object} Statistics
   */
  getStatistics() {
    const notifications = Array.from(this.notifications.values());
    const preferences = Array.from(this.preferences.values());

    return {
      totalNotifications: notifications.length,
      unreadNotifications: notifications.filter(n => !n.read).length,
      byType: this.getTypeCounts(notifications),
      byCategory: this.getCategoryCounts(notifications),
      byPriority: this.getPriorityCounts(notifications),
      totalPreferences: preferences.length,
      activePreferences: preferences.filter(p => p.enabled).length
    };
  }

  /**
   * Get type counts
   * @param {Array} notifications - Notifications
   * @returns {object} Type counts
   */
  getTypeCounts(notifications) {
    const counts = {};
    notifications.forEach(n => {
      counts[n.type] = (counts[n.type] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get category counts
   * @param {Array} notifications - Notifications
   * @returns {object} Category counts
   */
  getCategoryCounts(notifications) {
    const counts = {};
    notifications.forEach(n => {
      counts[n.category] = (counts[n.category] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get priority counts
   * @param {Array} notifications - Notifications
   * @returns {object} Priority counts
   */
  getPriorityCounts(notifications) {
    const counts = {};
    notifications.forEach(n => {
      counts[n.priority] = (counts[n.priority] || 0) + 1;
    });
    return counts;
  }
}

// Global notification service instance
const notificationService = new NotificationService();

// Expose to window
if (typeof window !== 'undefined') {
  window.NotificationService = NotificationService;
  window.notificationService = notificationService;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { NotificationService, notificationService, NotificationServicePreference, AppNotification };
}
