// Dashboard Builder Module - Interactive dashboard customization

/**
 * Dashboard Widget class
 */
class DashboardWidget {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.type = config.type || 'metric'; // metric, chart, table, list
    this.title = config.title || 'Untitled Widget';
    this.position = config.position || { x: 0, y: 0, w: 4, h: 3 };
    this.dataSource = config.dataSource || null;
    this.config = config.config || {};
    this.style = config.style || {};
    this.refreshInterval = config.refreshInterval || null;
    this.visible = config.visible !== false;
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `widget-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Dashboard class
 */
class Dashboard {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.name = config.name || 'Untitled Dashboard';
    this.description = config.description || '';
    this.widgets = config.widgets || [];
    this.layout = config.layout || 'grid'; // grid, free
    this.theme = config.theme || 'default';
    this.isDefault = config.isDefault || false;
    this.shared = config.shared || false;
    this.sharedWith = config.sharedWith || [];
    this.createdAt = config.createdAt || new Date().toISOString();
    this.updatedAt = config.updatedAt || new Date().toISOString();
  }

  generateId() {
    return `dashboard-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Add widget to dashboard
   * @param {DashboardWidget} widget - Widget to add
   */
  addWidget(widget) {
    this.widgets.push(widget);
    this.updatedAt = new Date().toISOString();
  }

  /**
   * Remove widget from dashboard
   * @param {string} widgetId - Widget ID
   */
  removeWidget(widgetId) {
    this.widgets = this.widgets.filter(w => w.id !== widgetId);
    this.updatedAt = new Date().toISOString();
  }

  /**
   * Update widget
   * @param {string} widgetId - Widget ID
   * @param {object} updates - Updates to apply
   */
  updateWidget(widgetId, updates) {
    const widget = this.widgets.find(w => w.id === widgetId);
    if (widget) {
      Object.assign(widget, updates);
      this.updatedAt = new Date().toISOString();
    }
  }
}

/**
 * Dashboard Builder Manager
 */
class DashboardBuilderManager {
  constructor() {
    this.dashboards = new Map();
    this.widgetTypes = new Map();
    this.currentDashboard = null;
    if (window.databaseReady) {
      this.init();
    } else {
      document.addEventListener('databaseReady', () => this.init(), { once: true });
    }
  }

  /**
   * Initialize dashboard builder
   */
  async init() {
    await this.loadDashboards();
    this.setupWidgetTypes();
    await this.ensureDefaultDashboard();
  }

  /**
   * Setup available widget types
   */
  setupWidgetTypes() {
    this.widgetTypes.set('metric', {
      name: 'Metric Card',
      description: 'Display a single key metric',
      icon: '📊',
      defaultConfig: {
        metric: 'totalStock',
        label: 'Total Stock',
        showTrend: true,
        trendPeriod: '7d'
      }
    });

    this.widgetTypes.set('chart', {
      name: 'Chart',
      description: 'Display data as a chart',
      icon: '📈',
      defaultConfig: {
        chartType: 'bar',
        dataSource: 'materials',
        xAxis: 'category',
        yAxis: 'currentStock'
      }
    });

    this.widgetTypes.set('table', {
      name: 'Data Table',
      description: 'Display data in a table',
      icon: '📋',
      defaultConfig: {
        dataSource: 'materials',
        columns: ['barcode', 'name', 'currentStock', 'category'],
        pageSize: 10
      }
    });

    this.widgetTypes.set('list', {
      name: 'List',
      description: 'Display a list of items',
      icon: '📝',
      defaultConfig: {
        dataSource: 'transactions',
        limit: 5,
        sortBy: 'time',
        sortOrder: 'desc'
      }
    });

    this.widgetTypes.set('progress', {
      name: 'Progress',
      description: 'Display progress indicators',
      icon: '🎯',
      defaultConfig: {
        items: [
          { label: 'Stock Level', value: 75, color: '#4CAF50' },
          { label: 'Orders', value: 60, color: '#2196F3' }
        ]
      }
    });
  }

  /**
   * Load dashboards from storage
   */
  async loadDashboards() {
    try {
      const dashboards = await gAll('dashboards');
      dashboards.forEach(d => {
        this.dashboards.set(d.id, new Dashboard(d));
      });
    } catch (err) {
      console.error('Failed to load dashboards:', err);
    }
  }

  /**
   * Ensure default dashboard exists
   */
  async ensureDefaultDashboard() {
    const hasDefault = Array.from(this.dashboards.values()).some(d => d.isDefault);
    
    if (!hasDefault) {
      const defaultDashboard = await this.createDefaultDashboard();
      this.currentDashboard = defaultDashboard.id;
    } else {
      this.currentDashboard = Array.from(this.dashboards.values()).find(d => d.isDefault)?.id;
    }
  }

  /**
   * Create default dashboard
   * @returns {Dashboard} - Default dashboard
   */
  async createDefaultDashboard() {
    const dashboard = new Dashboard({
      name: 'Default Dashboard',
      description: 'Default inventory dashboard',
      isDefault: true,
      widgets: [
        new DashboardWidget({
          type: 'metric',
          title: 'Total Materials',
          position: { x: 0, y: 0, w: 4, h: 2 },
          dataSource: 'materials',
          config: { metric: 'count', label: 'Total Materials' }
        }),
        new DashboardWidget({
          type: 'metric',
          title: 'Total Stock',
          position: { x: 4, y: 0, w: 4, h: 2 },
          dataSource: 'materials',
          config: { metric: 'sum', field: 'currentStock', label: 'Total Stock' }
        }),
        new DashboardWidget({
          type: 'metric',
          title: 'Low Stock Items',
          position: { x: 8, y: 0, w: 4, h: 2 },
          dataSource: 'materials',
          config: { metric: 'count', filter: 'lowStock', label: 'Low Stock' }
        }),
        new DashboardWidget({
          type: 'chart',
          title: 'Stock by Category',
          position: { x: 0, y: 2, w: 6, h: 4 },
          dataSource: 'materials',
          config: { chartType: 'bar', groupBy: 'category', aggregate: 'sum', field: 'currentStock' }
        }),
        new DashboardWidget({
          type: 'list',
          title: 'Recent Transactions',
          position: { x: 6, y: 2, w: 6, h: 4 },
          dataSource: 'transactions',
          config: { limit: 10, sortBy: 'time', sortOrder: 'desc' }
        })
      ]
    });

    this.dashboards.set(dashboard.id, dashboard);
    await this.saveDashboard(dashboard);

    return dashboard;
  }

  /**
   * Create dashboard
   * @param {object} config - Dashboard configuration
   * @returns {Dashboard} - Created dashboard
   */
  async createDashboard(config) {
    const dashboard = new Dashboard(config);
    this.dashboards.set(dashboard.id, dashboard);
    await this.saveDashboard(dashboard);
    return dashboard;
  }

  /**
   * Update dashboard
   * @param {string} id - Dashboard ID
   * @param {object} updates - Updates to apply
   * @returns {Dashboard} - Updated dashboard
   */
  async updateDashboard(id, updates) {
    const dashboard = this.dashboards.get(id);
    if (dashboard) {
      Object.assign(dashboard, updates);
      dashboard.updatedAt = new Date().toISOString();
      await this.saveDashboard(dashboard);
    }
    return dashboard;
  }

  /**
   * Delete dashboard
   * @param {string} id - Dashboard ID
   */
  async deleteDashboard(id) {
    const dashboard = this.dashboards.get(id);
    if (dashboard && !dashboard.isDefault) {
      this.dashboards.delete(id);
      await dDel('dashboards', id);
    }
  }

  /**
   * Get dashboard
   * @param {string} id - Dashboard ID
   * @returns {Dashboard} - Dashboard
   */
  getDashboard(id) {
    return this.dashboards.get(id);
  }

  /**
   * Get all dashboards
   * @returns {Array} - Array of dashboards
   */
  getAllDashboards() {
    return Array.from(this.dashboards.values());
  }

  /**
   * Set current dashboard
   * @param {string} id - Dashboard ID
   */
  setCurrentDashboard(id) {
    this.currentDashboard = id;
  }

  /**
   * Get current dashboard
   * @returns {Dashboard} - Current dashboard
   */
  getCurrentDashboard() {
    if (this.currentDashboard) {
      return this.dashboards.get(this.currentDashboard);
    }
    return null;
  }

  /**
   * Add widget to current dashboard
   * @param {object} widgetConfig - Widget configuration
   * @returns {DashboardWidget} - Created widget
   */
  async addWidget(widgetConfig) {
    const dashboard = this.getCurrentDashboard();
    if (!dashboard) {
      throw new Error('No current dashboard');
    }

    const widget = new DashboardWidget(widgetConfig);
    dashboard.addWidget(widget);
    await this.saveDashboard(dashboard);

    return widget;
  }

  /**
   * Remove widget from current dashboard
   * @param {string} widgetId - Widget ID
   */
  async removeWidget(widgetId) {
    const dashboard = this.getCurrentDashboard();
    if (dashboard) {
      dashboard.removeWidget(widgetId);
      await this.saveDashboard(dashboard);
    }
  }

  /**
   * Update widget in current dashboard
   * @param {string} widgetId - Widget ID
   * @param {object} updates - Updates to apply
   */
  async updateWidget(widgetId, updates) {
    const dashboard = this.getCurrentDashboard();
    if (dashboard) {
      dashboard.updateWidget(widgetId, updates);
      await this.saveDashboard(dashboard);
    }
  }

  /**
   * Save dashboard to storage
   * @param {Dashboard} dashboard - Dashboard to save
   */
  async saveDashboard(dashboard) {
    try {
      await dPut('dashboards', dashboard);
    } catch (err) {
      console.error('Failed to save dashboard:', err);
    }
  }

  /**
   * Get widget types
   * @returns {Array} - Available widget types
   */
  getWidgetTypes() {
    return Array.from(this.widgetTypes.entries()).map(([id, type]) => ({
      id,
      ...type
    }));
  }

  /**
   * Get widget type
   * @param {string} typeId - Widget type ID
   * @returns {object} - Widget type
   */
  getWidgetType(typeId) {
    return this.widgetTypes.get(typeId);
  }

  /**
   * Duplicate dashboard
   * @param {string} id - Dashboard ID to duplicate
   * @param {string} newName - New dashboard name
   * @returns {Dashboard} - Duplicated dashboard
   */
  async duplicateDashboard(id, newName) {
    const original = this.dashboards.get(id);
    if (!original) {
      throw new Error('Dashboard not found');
    }

    const duplicate = new Dashboard({
      ...original,
      id: undefined,
      name: newName || `${original.name} (Copy)`,
      isDefault: false,
      widgets: original.widgets.map(w => new DashboardWidget({ ...w, id: undefined }))
    });

    this.dashboards.set(duplicate.id, duplicate);
    await this.saveDashboard(duplicate);

    return duplicate;
  }

  /**
   * Export dashboard
   * @param {string} id - Dashboard ID
   * @returns {string} - JSON export
   */
  exportDashboard(id) {
    const dashboard = this.dashboards.get(id);
    if (dashboard) {
      return JSON.stringify(dashboard, null, 2);
    }
    return null;
  }

  /**
   * Import dashboard
   * @param {string} json - JSON dashboard
   * @returns {Dashboard} - Imported dashboard
   */
  async importDashboard(json) {
    try {
      const data = JSON.parse(json);
      const dashboard = new Dashboard({
        ...data,
        id: undefined,
        isDefault: false,
        widgets: data.widgets.map(w => new DashboardWidget({ ...w, id: undefined }))
      });

      this.dashboards.set(dashboard.id, dashboard);
      await this.saveDashboard(dashboard);

      return dashboard;
    } catch (err) {
      console.error('Failed to import dashboard:', err);
      return null;
    }
  }

  /**
   * Get dashboard statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const dashboards = this.getAllDashboards();
    const totalWidgets = dashboards.reduce((sum, d) => sum + d.widgets.length, 0);

    const widgetTypeCounts = {};
    dashboards.forEach(d => {
      d.widgets.forEach(w => {
        widgetTypeCounts[w.type] = (widgetTypeCounts[w.type] || 0) + 1;
      });
    });

    return {
      totalDashboards: dashboards.length,
      totalWidgets,
      widgetTypeCounts,
      sharedDashboards: dashboards.filter(d => d.shared).length
    };
  }
}

/**
 * Global dashboard builder instance
 */
const dashboardBuilderManager = new DashboardBuilderManager();

/**
 * Initialize dashboard builder
 */
async function initDashboardBuilder() {
  // Wait for database to be ready
  if (!window.databaseReady) {
    await new Promise(resolve => {
      document.addEventListener('databaseReady', resolve, { once: true });
    });
  }
  await dashboardBuilderManager.init();
  return dashboardBuilderManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.DashboardBuilder = {
    manager: dashboardBuilderManager,
    init: initDashboardBuilder,
    create: (config) => dashboardBuilderManager.createDashboard(config),
    update: (id, updates) => dashboardBuilderManager.updateDashboard(id, updates),
    delete: (id) => dashboardBuilderManager.deleteDashboard(id),
    get: (id) => dashboardBuilderManager.getDashboard(id),
    getAll: () => dashboardBuilderManager.getAllDashboards(),
    setCurrent: (id) => dashboardBuilderManager.setCurrentDashboard(id),
    getCurrent: () => dashboardBuilderManager.getCurrentDashboard(),
    addWidget: (config) => dashboardBuilderManager.addWidget(config),
    removeWidget: (id) => dashboardBuilderManager.removeWidget(id),
    updateWidget: (id, updates) => dashboardBuilderManager.updateWidget(id, updates),
    getWidgetTypes: () => dashboardBuilderManager.getWidgetTypes(),
    getWidgetType: (id) => dashboardBuilderManager.getWidgetType(id),
    duplicate: (id, name) => dashboardBuilderManager.duplicateDashboard(id, name),
    export: (id) => dashboardBuilderManager.exportDashboard(id),
    import: (json) => dashboardBuilderManager.importDashboard(json),
    getStats: () => dashboardBuilderManager.getStatistics()
  };
}
