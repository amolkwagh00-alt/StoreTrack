/**
 * Custom Dashboard Integrations Module
 * Integrates with external monitoring and dashboard systems (Grafana, etc.)
 */

class DashboardIntegrations {
  constructor() {
    this.integrations = new Map();
    this.metricsBuffer = [];
    this.config = {
      bufferSize: 1000,
      flushInterval: 30000, // 30 seconds
      retryAttempts: 3,
      retryDelay: 5000
    };
    this.flushTimer = null;
  }

  /**
   * Initialize dashboard integrations
   * @param {Object} config - Configuration options
   */
  initialize(config = {}) {
    this.config = { ...this.config, ...config };
    this.startFlushTimer();
  }

  /**
   * Register a dashboard integration
   * @param {string} name - Integration name
   * @param {Object} config - Integration configuration
   */
  registerIntegration(name, config) {
    const integration = {
      name,
      type: config.type || 'prometheus',
      endpoint: config.endpoint,
      apiKey: config.apiKey,
      enabled: config.enabled !== false,
      labels: config.labels || {},
      lastFlush: 0,
      flushCount: 0,
      errorCount: 0
    };
    
    this.integrations.set(name, integration);
    return integration;
  }

  /**
   * Send metric to integration
   * @param {string} integrationName - Integration name
   * @param {string} metricName - Metric name
   * @param {number} value - Metric value
   * @param {Object} labels - Metric labels
   */
  sendMetric(integrationName, metricName, value, labels = {}) {
    const integration = this.integrations.get(integrationName);
    if (!integration || !integration.enabled) {return;}
    
    const metric = {
      integrationName,
      metricName,
      value,
      labels: { ...integration.labels, ...labels },
      timestamp: Date.now()
    };
    
    this.metricsBuffer.push(metric);
    
    // Flush if buffer is full
    if (this.metricsBuffer.length >= this.config.bufferSize) {
      this.flushMetrics();
    }
  }

  /**
   * Send counter metric
   * @param {string} integrationName - Integration name
   * @param {string} metricName - Metric name
   * @param {number} value - Counter value
   * @param {Object} labels - Metric labels
   */
  sendCounter(integrationName, metricName, value, labels = {}) {
    this.sendMetric(integrationName, `${metricName}_total`, value, labels);
  }

  /**
   * Send gauge metric
   * @param {string} integrationName - Integration name
   * @param {string} metricName - Metric name
   * @param {number} value - Gauge value
   * @param {Object} labels - Metric labels
   */
  sendGauge(integrationName, metricName, value, labels = {}) {
    this.sendMetric(integrationName, metricName, value, labels);
  }

  /**
   * Send histogram metric
   * @param {string} integrationName - Integration name
   * @param {string} metricName - Metric name
   * @param {number} value - Histogram value
   * @param {Object} labels - Metric labels
   */
  sendHistogram(integrationName, metricName, value, labels = {}) {
    this.sendMetric(integrationName, `${metricName}_bucket`, value, { ...labels, le: '+Inf' });
    this.sendMetric(integrationName, `${metricName}_sum`, value, labels);
    this.sendMetric(integrationName, `${metricName}_count`, 1, labels);
  }

  /**
   * Flush metrics to integrations
   */
  async flushMetrics() {
    if (this.metricsBuffer.length === 0) {return;}
    
    const metricsToFlush = [...this.metricsBuffer];
    this.metricsBuffer = [];
    
    const flushPromises = [];
    
    for (const [name, integration] of this.integrations) {
      if (!integration.enabled) {continue;}
      
      const integrationMetrics = metricsToFlush.filter(m => m.integrationName === name);
      if (integrationMetrics.length === 0) {continue;}
      
      flushPromises.push(this.flushToIntegration(integration, integrationMetrics));
    }
    
    await Promise.allSettled(flushPromises);
  }

  /**
   * Flush metrics to specific integration
   * @param {Object} integration - Integration configuration
   * @param {Array} metrics - Metrics to flush
   */
  async flushToIntegration(integration, metrics) {
    let attempts = 0;
    
    while (attempts < this.config.retryAttempts) {
      try {
        await this.sendToEndpoint(integration, metrics);
        
        integration.lastFlush = Date.now();
        integration.flushCount++;
        integration.errorCount = 0;
        
        return;
      } catch (error) {
        attempts++;
        integration.errorCount++;
        
        if (attempts < this.config.retryAttempts) {
          await new Promise(resolve => setTimeout(resolve, this.config.retryDelay));
        } else {
          console.error(`[Dashboard] Failed to flush to ${integration.name} after ${attempts} attempts:`, error.message);
        }
      }
    }
  }

  /**
   * Send metrics to endpoint
   * @param {Object} integration - Integration configuration
   * @param {Array} metrics - Metrics to send
   */
  async sendToEndpoint(integration, metrics) {
    switch (integration.type) {
      case 'prometheus':
        return this.sendToPrometheus(integration, metrics);
      case 'grafana':
        return this.sendToGrafana(integration, metrics);
      case 'datadog':
        return this.sendToDatadog(integration, metrics);
      case 'influxdb':
        return this.sendToInfluxDB(integration, metrics);
      default:
        throw new Error(`Unknown integration type: ${integration.type}`);
    }
  }

  /**
   * Send to Prometheus Pushgateway
   */
  async sendToPrometheus(integration, metrics) {
    const prometheusFormat = metrics.map(m => {
      const labelsStr = Object.entries(m.labels)
        .map(([k, v]) => `${k}="${v}"`)
        .join(',');
      return `${m.metricName}{${labelsStr}} ${m.value} ${m.timestamp}`;
    }).join('\n');
    
    const response = await fetch(integration.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain'
      },
      body: prometheusFormat
    });
    
    if (!response.ok) {
      throw new Error(`Prometheus push failed: ${response.status}`);
    }
  }

  /**
   * Send to Grafana
   */
  async sendToGrafana(integration, metrics) {
    const payload = {
      metrics: metrics.map(m => ({
        name: m.metricName,
        value: m.value,
        labels: m.labels,
        timestamp: m.timestamp
      }))
    };
    
    const response = await fetch(integration.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${integration.apiKey}`
      },
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
      throw new Error(`Grafana push failed: ${response.status}`);
    }
  }

  /**
   * Send to Datadog
   */
  async sendToDatadog(integration, metrics) {
    const datadogFormat = metrics.map(m => ({
      metric: m.metricName,
      points: [[m.timestamp / 1000, m.value]],
      tags: Object.entries(m.labels).map(([k, v]) => `${k}:${v}`)
    }));
    
    const response = await fetch(integration.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'DD-API-KEY': integration.apiKey
      },
      body: JSON.stringify({ series: datadogFormat })
    });
    
    if (!response.ok) {
      throw new Error(`Datadog push failed: ${response.status}`);
    }
  }

  /**
   * Send to InfluxDB
   */
  async sendToInfluxDB(integration, metrics) {
    const influxFormat = metrics.map(m => {
      const tagsStr = Object.entries(m.labels)
        .map(([k, v]) => `${k}="${v}"`)
        .join(',');
      return `${m.metricName},${tagsStr} value=${m.value} ${m.timestamp * 1000000}`;
    }).join('\n');
    
    const response = await fetch(integration.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain'
      },
      body: influxFormat
    });
    
    if (!response.ok) {
      throw new Error(`InfluxDB push failed: ${response.status}`);
    }
  }

  /**
   * Start automatic flush timer
   */
  startFlushTimer() {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
    }
    
    this.flushTimer = setInterval(() => {
      this.flushMetrics();
    }, this.config.flushInterval);
  }

  /**
   * Stop automatic flush timer
   */
  stopFlushTimer() {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
      this.flushTimer = null;
    }
  }

  /**
   * Get integration status
   * @param {string} name - Integration name
   */
  getIntegrationStatus(name) {
    const integration = this.integrations.get(name);
    if (!integration) {return null;}
    
    return {
      name: integration.name,
      type: integration.type,
      enabled: integration.enabled,
      lastFlush: integration.lastFlush,
      flushCount: integration.flushCount,
      errorCount: integration.errorCount,
      health: integration.errorCount === 0 ? 'healthy' : 'degraded'
    };
  }

  /**
   * Get all integration statuses
   */
  getAllIntegrationStatuses() {
    return Array.from(this.integrations.keys()).map(name => 
      this.getIntegrationStatus(name)
    );
  }

  /**
   * Enable integration
   * @param {string} name - Integration name
   */
  enableIntegration(name) {
    const integration = this.integrations.get(name);
    if (integration) {
      integration.enabled = true;
    }
  }

  /**
   * Disable integration
   * @param {string} name - Integration name
   */
  disableIntegration(name) {
    const integration = this.integrations.get(name);
    if (integration) {
      integration.enabled = false;
    }
  }

  /**
   * Remove integration
   * @param {string} name - Integration name
   */
  removeIntegration(name) {
    this.integrations.delete(name);
  }

  /**
   * Get buffer status
   */
  getBufferStatus() {
    return {
      size: this.metricsBuffer.length,
      maxSize: this.config.bufferSize,
      utilization: (this.metricsBuffer.length / this.config.bufferSize * 100).toFixed(2)
    };
  }

  /**
   * Clear metrics buffer
   */
  clearBuffer() {
    this.metricsBuffer = [];
  }

  /**
   * Set configuration
   * @param {Object} config - Configuration options
   */
  setConfig(config) {
    this.config = { ...this.config, ...config };
    
    // Restart flush timer if interval changed
    if (config.flushInterval) {
      this.startFlushTimer();
    }
  }

  /**
   * Get configuration
   */
  getConfig() {
    return { ...this.config };
  }

  /**
   * Destroy integrations
   */
  destroy() {
    this.stopFlushTimer();
    this.flushMetrics();
    this.integrations.clear();
    this.metricsBuffer = [];
  }
}

// Create singleton instance
const dashboardIntegrations = new DashboardIntegrations();

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { DashboardIntegrations, dashboardIntegrations };
}
