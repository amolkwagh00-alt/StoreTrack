/* global queryCache, backgroundSync */
/**
 * Self-Healing Mechanisms Module
 * Automatically detects and resolves common system issues
 */

class SelfHealing {
  constructor() {
    this.healers = new Map();
    this.healingHistory = [];
    this.config = {
      maxRetries: 3,
      retryDelay: 5000,
      autoHealEnabled: true,
      maxHistory: 1000
    };
    this.eventBus = null;
  }

  /**
   * Initialize self-healing
   * @param {Object} config - Configuration options
   * @param {Object} eventBus - Event bus for notifications
   */
  initialize(config = {}, eventBus = null) {
    this.config = { ...this.config, ...config };
    this.eventBus = eventBus;
    this.registerDefaultHealers();
  }

  /**
   * Register default healing mechanisms
   */
  registerDefaultHealers() {
    // Database connection healer
    this.registerHealer('database_connection', {
      priority: 'critical',
      condition: (issue) => issue.category === 'database' && issue.ruleId === 'database_connection_failed',
      heal: async (issue) => {
        // Attempt to reconnect to database
        if (typeof window !== 'undefined' && window.databaseReady) {
          return { success: true, message: 'Database connection restored' };
        }
        return { success: false, message: 'Could not restore database connection' };
      }
    });
    
    // Memory leak healer
    this.registerHealer('memory_leak', {
      priority: 'critical',
      condition: (issue) => issue.category === 'performance' && issue.ruleId === 'memory_leak',
      heal: async (issue) => {
        // Trigger garbage collection if possible
        const collectGarbage = typeof globalThis.gc === 'function' ? globalThis.gc : null;
        if (collectGarbage) {
          collectGarbage();
          return { success: true, message: 'Garbage collection triggered' };
        }
        // Clear caches
        if (typeof queryCache !== 'undefined') {
          queryCache.clear();
        }
        return { success: true, message: 'Caches cleared' };
      }
    });
    
    // Sync failure healer
    this.registerHealer('sync_failure', {
      priority: 'high',
      condition: (issue) => issue.category === 'sync' && issue.ruleId === 'sync_failure',
      heal: async (issue) => {
        // Restart sync process
        if (typeof backgroundSync !== 'undefined') {
          backgroundSync.forceSync();
          return { success: true, message: 'Sync process restarted' };
        }
        return { success: false, message: 'Sync module not available' };
      }
    });
    
    // Storage healer
    this.registerHealer('storage_cleanup', {
      priority: 'high',
      condition: (issue) => issue.category === 'storage' && issue.ruleId === 'storage_full',
      heal: async (issue) => {
        // Clean up old data
        if (typeof queryCache !== 'undefined') {
          queryCache.clear();
        }
        // Clear old logs
        if (typeof Logger !== 'undefined') {
          // Logger cleanup would go here
        }
        return { success: true, message: 'Storage cleanup performed' };
      }
    });
    
    // Cache healer
    this.registerHealer('cache_clear', {
      priority: 'medium',
      condition: (issue) => issue.category === 'performance' && issue.data?.cacheIssue === true,
      heal: async (issue) => {
        if (typeof queryCache !== 'undefined') {
          queryCache.clear();
          return { success: true, message: 'Cache cleared' };
        }
        return { success: false, message: 'Cache module not available' };
      }
    });
    
    // Service worker healer
    this.registerHealer('service_worker', {
      priority: 'medium',
      condition: (issue) => issue.category === 'network' && issue.data?.serviceWorkerIssue === true,
      heal: async (issue) => {
        if ('serviceWorker' in navigator) {
          const registrations = await navigator.serviceWorker.getRegistrations();
          for (const registration of registrations) {
            await registration.update();
          }
          return { success: true, message: 'Service worker updated' };
        }
        return { success: false, message: 'Service worker not supported' };
      }
    });
  }

  /**
   * Register a healer
   * @param {string} healerId - Healer identifier
   * @param {Object} healer - Healer configuration
   */
  registerHealer(healerId, healer) {
    this.healers.set(healerId, {
      id: healerId,
      ...healer,
      healCount: 0,
      lastHealed: null,
      successCount: 0,
      failureCount: 0
    });
  }

  /**
   * Remove healer
   * @param {string} healerId - Healer identifier
   */
  removeHealer(healerId) {
    this.healers.delete(healerId);
  }

  /**
   * Attempt to heal an issue
   * @param {Object} issue - Issue to heal
   */
  async healIssue(issue) {
    if (!this.config.autoHealEnabled) {
      return { success: false, message: 'Auto-heal disabled' };
    }
    
    // Find applicable healer
    let applicableHealer = null;
    for (const healer of this.healers.values()) {
      if (healer.condition(issue)) {
        applicableHealer = healer;
        break;
      }
    }
    
    if (!applicableHealer) {
      return { success: false, message: 'No applicable healer found' };
    }
    
    // Attempt healing with retries
    let lastResult = null;
    for (let attempt = 1; attempt <= this.config.maxRetries; attempt++) {
      try {
        lastResult = await applicableHealer.heal(issue);
        
        if (lastResult.success) {
          applicableHealer.successCount++;
          applicableHealer.lastHealed = Date.now();
          applicableHealer.healCount++;
          
          this.recordHealing(issue, applicableHealer, lastResult, attempt);
          
          if (this.eventBus) {
            this.eventBus.emit('SELF_HEAL_SUCCESS', {
              issue,
              healer: applicableHealer,
              result: lastResult,
              attempt
            });
          }
          
          return lastResult;
        }
        
        applicableHealer.failureCount++;
        
        if (attempt < this.config.maxRetries) {
          await new Promise(resolve => setTimeout(resolve, this.config.retryDelay));
        }
        
      } catch (error) {
        applicableHealer.failureCount++;
        lastResult = {
          success: false,
          message: error.message,
          error: error.toString()
        };
        
        if (attempt < this.config.maxRetries) {
          await new Promise(resolve => setTimeout(resolve, this.config.retryDelay));
        }
      }
    }
    
    // All attempts failed
    this.recordHealing(issue, applicableHealer, lastResult, this.config.maxRetries);
    
    if (this.eventBus) {
      this.eventBus.emit('SELF_HEAL_FAILED', {
        issue,
        healer: applicableHealer,
        result: lastResult,
        attempts: this.config.maxRetries
      });
    }
    
    return lastResult;
  }

  /**
   * Record healing attempt
   * @param {Object} issue - Issue that was healed
   * @param {Object} healer - Healer that was used
   * @param {Object} result - Healing result
   * @param {number} attempts - Number of attempts
   */
  recordHealing(issue, healer, result, attempts) {
    const record = {
      id: this.generateRecordId(),
      issueId: issue.id,
      healerId: healer.id,
      success: result.success,
      message: result.message,
      attempts,
      timestamp: Date.now()
    };
    
    this.healingHistory.push(record);
    
    // Keep history under max
    if (this.healingHistory.length > this.config.maxHistory) {
      this.healingHistory = this.healingHistory.slice(-this.config.maxHistory);
    }
  }

  /**
   * Process issues for healing
   * @param {Array} issues - Issues to process
   */
  async processIssues(issues) {
    const results = [];
    
    for (const issue of issues) {
      if (issue.status !== 'open' || issue.acknowledged) {continue;}
      
      const result = await this.healIssue(issue);
      results.push({
        issueId: issue.id,
        ...result
      });
    }
    
    return results;
  }

  /**
   * Get healing statistics
   */
  getStatistics() {
    const totalHealings = this.healingHistory.length;
    const successfulHealings = this.healingHistory.filter(h => h.success).length;
    const failedHealings = totalHealings - successfulHealings;
    
    const healerStats = {};
    for (const [healerId, healer] of this.healers) {
      healerStats[healerId] = {
        healCount: healer.healCount,
        successCount: healer.successCount,
        failureCount: healer.failureCount,
        successRate: healer.healCount > 0 
          ? ((healer.successCount / healer.healCount) * 100).toFixed(2)
          : 0,
        lastHealed: healer.lastHealed
      };
    }
    
    return {
      totalHealings,
      successfulHealings,
      failedHealings,
      successRate: totalHealings > 0 
        ? ((successfulHealings / totalHealings) * 100).toFixed(2)
        : 0,
      healers: healerStats,
      autoHealEnabled: this.config.autoHealEnabled
    };
  }

  /**
   * Get healing history
   * @param {Object} filters - History filters
   */
  getHistory(filters = {}) {
    let history = [...this.healingHistory];
    
    if (filters.healerId) {
      history = history.filter(h => h.healerId === filters.healerId);
    }
    
    if (filters.success !== undefined) {
      history = history.filter(h => h.success === filters.success);
    }
    
    if (filters.since) {
      history = history.filter(h => h.timestamp >= filters.since);
    }
    
    return history.sort((a, b) => b.timestamp - a.timestamp);
  }

  /**
   * Enable/disable auto-heal
   * @param {boolean} enabled - Enable state
   */
  setAutoHealEnabled(enabled) {
    this.config.autoHealEnabled = enabled;
    
    if (this.eventBus) {
      this.eventBus.emit('AUTO_HEAL_TOGGLED', { enabled });
    }
  }

  /**
   * Get healer status
   * @param {string} healerId - Healer ID
   */
  getHealerStatus(healerId) {
    const healer = this.healers.get(healerId);
    if (!healer) {return null;}
    
    return {
      id: healer.id,
      priority: healer.priority,
      healCount: healer.healCount,
      successCount: healer.successCount,
      failureCount: healer.failureCount,
      successRate: healer.healCount > 0 
        ? ((healer.successCount / healer.healCount) * 100).toFixed(2)
        : 0,
      lastHealed: healer.lastHealed
    };
  }

  /**
   * Get all healer statuses
   */
  getAllHealerStatuses() {
    return Array.from(this.healers.keys()).map(id => this.getHealerStatus(id));
  }

  /**
   * Generate record ID
   */
  generateRecordId() {
    return `healing_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Clear healing history
   */
  clearHistory() {
    this.healingHistory = [];
  }

  /**
   * Set configuration
   * @param {Object} config - Configuration options
   */
  setConfig(config) {
    this.config = { ...this.config, ...config };
  }

  /**
   * Get configuration
   */
  getConfig() {
    return { ...this.config };
  }

  /**
   * Export healing data
   */
  exportData() {
    return {
      timestamp: Date.now(),
      history: this.healingHistory,
      statistics: this.getStatistics(),
      healers: this.getAllHealerStatuses()
    };
  }

  /**
   * Reset all data
   */
  reset() {
    this.healingHistory = [];
    for (const healer of this.healers.values()) {
      healer.healCount = 0;
      healer.successCount = 0;
      healer.failureCount = 0;
      healer.lastHealed = null;
    }
  }
}

// Create singleton instance
const selfHealing = new SelfHealing();

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { SelfHealing, selfHealing };
}
