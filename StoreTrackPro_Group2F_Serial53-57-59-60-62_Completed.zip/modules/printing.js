/* exported buildLabelPrintHtml, buildLabelZpl, createLabelElement, getLblSettings */
/* global applyCssText */

// Printing Module - Label generation and printing utilities

function clampLabelNumber(value,fallback,min,max){const text=String(value??'').trim();if(!text)return fallback;const n=Number(text);if(!Number.isFinite(n))return fallback;return Math.max(min,Math.min(max,Math.trunc(n)));}
function normalizeLabelSettings(settings={}){
  return {w:clampLabelNumber(settings.w,50,20,200),h:clampLabelNumber(settings.h,25,10,200),fs:clampLabelNumber(settings.fs,8,5,20),per:clampLabelNumber(settings.per,3,1,6),copies:clampLabelNumber(settings.copies,1,1,100),showCat:!!settings.showCat,showUnit:!!settings.showUnit};
}
function getLblSettings(){
  const value=id=>document.getElementById(id)?.value;
  return normalizeLabelSettings({w:value('lbl-w'),h:value('lbl-h'),fs:value('lbl-fs'),per:value('lbl-per'),copies:value('lbl-cop'),showCat:document.getElementById('lbl-cat')?.checked,showUnit:document.getElementById('lbl-unit')?.checked});
}

// Convert mm to pixels for label rendering
function lblMmToPx(mm) { return Number(mm) * 3.7795275591; }
function lblPreviewLayoutCss(per,hgap,vgap,margin){const columns=clampLabelNumber(per,3,1,6),h=clampLabelNumber(hgap,15,0,30),v=clampLabelNumber(vgap,15,0,30),m=clampLabelNumber(margin,10,0,20);return `padding:${lblMmToPx(m)}px;display:grid;grid-template-columns:repeat(${columns},auto);column-gap:${lblMmToPx(h)}px;row-gap:${lblMmToPx(v)}px;justify-content:start`;}

// Calculate barcode height based on label height and font size
function lblCodeHeightMm(h, fs) { return Math.max(6, Math.min(h * 0.42, h - fs - 3)); }

// Escape special characters for ZPL format
function escapeZpl(s) { return String(s ?? '').replace(/[\^~\\]/g, ' '); }
function escapeLabelHTML(value){return String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}

// Build ZPL (Zebra Programming Language) label format
function buildLabelZpl(m, s) {
  s=normalizeLabelSettings(s);m=m||{};
  const dpi = 203, dpmm = dpi / 25.4;
  const pw = Math.round(s.w * dpmm), ll = Math.round(s.h * dpmm);
  const margin = Math.round(2 * dpmm);
  const nameFs = Math.max(16, Math.round(s.fs * 3.2));
  const subFs = Math.max(12, Math.round(s.fs * 2.4));
  const bcHeight = Math.round(lblCodeHeightMm(s.h, s.fs) * dpmm);
  const bcWidth = s.w < 45 ? 1 : 2;
  let y = margin;
  let z = `^XA\n^PW${pw}\n^LL${ll}\n^LH0,0\n`;
  z += `^CF0,${nameFs}\n^FO${margin},${y}^FB${pw - margin * 2},1,0,C,0^FD${escapeZpl(String(m.name||'').substring(0, 28))}^FS\n`;
  y += nameFs + Math.round(0.8 * dpmm);
  if (s.showCat && m.category) {
    z += `^CF0,${subFs}\n^FO${margin},${y}^FB${pw - margin * 2},1,0,C,0^FD${escapeZpl(m.category)}^FS\n`;
    y += subFs + Math.round(0.5 * dpmm);
  }
  z += `^BY${bcWidth},2,${bcHeight}\n^FO${margin},${y}^BCN,,Y,N,N^FD${escapeZpl(m.barcode)}^FS\n`;
  y += bcHeight + Math.round(0.8 * dpmm);
  if (s.showUnit && m.unit) {
    z += `^CF0,${subFs}\n^FO${margin},${y}^FB${pw - margin * 2},1,0,C,0^FDUnit: ${escapeZpl(m.unit)}^FS\n`;
  }
  z += `^XZ\n\n`;
  return z;
}

// Create label DOM element for preview
async function createLabelElement(m, s) {
  s=normalizeLabelSettings(s);m=m||{};
  const { w, h, fs, showCat, showUnit } = s;
  const codeHm = lblCodeHeightMm(h, fs);
  const codePx = lblMmToPx(codeHm);
  const subFs = Math.max(5, fs - 1);
  const qr = await qrToDataURL(m.barcode, { margin: 0, width: Math.round(codePx * 2) });
  const bcCanvas = document.createElement('canvas');
  safeJsBarcode(bcCanvas, m.barcode, {
    format: 'CODE128',
    width: w < 45 ? 1 : 2,
    height: Math.round(codePx * 0.85),
    displayValue: false,
    margin: 0,
  });
  const bc = bcCanvas.toDataURL('image/png');
  const div = document.createElement('div');
  applyCssText(div, `width:${lblMmToPx(w)}px;height:${lblMmToPx(h)}px;border:1px solid #000;background:#fff;color:#000;padding:1mm;display:flex;flex-direction:column;align-items:center;justify-content:center;box-sizing:border-box;overflow:hidden;flex-shrink:0`);
  div.innerHTML = `
    <div data-style="font-size:${fs}pt;font-weight:bold;text-align:center;white-space:nowrap;width:92%;overflow:hidden;text-overflow:ellipsis;line-height:1.1">${escapeLabelHTML(m.name)}</div>
    ${showCat && m.category ? `<div data-style="font-size:${subFs}pt;text-align:center;white-space:nowrap;width:92%;overflow:hidden">${escapeLabelHTML(m.category)}</div>` : ''}
    <div data-style="display:flex;align-items:center;justify-content:center;gap:2px;margin:1px 0;flex:1;min-height:0;width:100%">
      <img src="${qr}" data-style="height:${codePx}px;width:${codePx}px;object-fit:contain;flex-shrink:0">
      <img src="${bc}" data-style="height:${codePx}px;width:auto;max-width:58%;object-fit:contain;flex-shrink:1">
    </div>
    <div data-style="font-size:${subFs}pt;line-height:1">${escapeLabelHTML(m.barcode)}</div>
    ${showUnit && m.unit ? `<div data-style="font-size:${Math.max(5, subFs - 1)}pt">${escapeLabelHTML(m.unit)}</div>` : ''}`;
  return div;
}

// Build HTML for label printing
async function buildLabelPrintHtml(m, s) {
  s=normalizeLabelSettings(s);m=m||{};
  const { w, h, fs, showCat, showUnit } = s;
  const codeHm = lblCodeHeightMm(h, fs);
  const subFs = Math.max(5, fs - 1);
  const qrSize = Math.round(lblMmToPx(codeHm) * 1.8);
  const qr = await qrToDataURL(m.barcode, { margin: 0, width: qrSize });
  const bcCanvas = document.createElement('canvas');
  safeJsBarcode(bcCanvas, m.barcode, {
    format: 'CODE128',
    width: w < 45 ? 1.5 : 2,
    height: Math.round(lblMmToPx(codeHm) * 0.9),
    displayValue: false,
    margin: 0,
  });
  const bc = bcCanvas.toDataURL('image/png');
  return `
    <div class="lbl" style="width:${w}mm;height:${h}mm;background:#fff;border:1px solid #000;padding:1.5mm;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0.8mm">
      <div class="lbl-name" style="font-size:${fs}pt;font-weight:bold;text-align:center;width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeLabelHTML(m.name)}</div>
      ${showCat && m.category ? `<div class="lbl-sub" style="font-size:${subFs}pt;color:#333;text-align:center;width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeLabelHTML(m.category)}</div>` : ''}
      <div class="lbl-codes" style="display:flex;align-items:center;justify-content:center;gap:2mm;width:100%;flex:1;min-height:0">
        <img src="${qr}" style="height:${codeHm}mm;width:${codeHm}mm;object-fit:contain">
        <img src="${bc}" style="height:${codeHm}mm;width:auto;max-width:55%;object-fit:contain">
      </div>
      <div class="lbl-bc" style="font-size:${subFs}pt;font-family:monospace;font-weight:bold;text-align:center;width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeLabelHTML(m.barcode)}</div>
      ${showUnit && m.unit ? `<div class="lbl-sub" style="font-size:${Math.max(5, subFs - 1)}pt;color:#555;text-align:center;width:100%">Unit: ${escapeLabelHTML(m.unit)}</div>` : ''}
    </div>`;
}
