// CSRF Protection Module - Cross-Site Request Forgery protection

/**
 * CSRF Token Manager
 */
class CSRFManager {
  constructor() {
    this.tokenName = 'csrf_token';
    this.headerName = 'X-CSRF-Token';
    this.token = null;
    this.storageKey = 'st_csrf_token';
  }

  /**
   * Generate a random CSRF token
   * @returns {string} - Random token
   */
  generateToken() {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Initialize CSRF token
   * @returns {string} - CSRF token
   */
  init() {
    // Try to get existing token from storage
    const stored = localStorage.getItem(this.storageKey);
    
    if (stored) {
      this.token = stored;
    } else {
      // Generate new token
      this.token = this.generateToken();
      localStorage.setItem(this.storageKey, this.token);
    }
    
    // Inject token into all forms
    this.injectIntoForms();
    
    // Set token in meta tag for AJAX requests
    this.setMetaTag();
    
    return this.token;
  }

  /**
   * Get current CSRF token
   * @returns {string} - CSRF token
   */
  getToken() {
    if (!this.token) {
      this.init();
    }
    return this.token;
  }

  /**
   * Refresh CSRF token
   * @returns {string} - New CSRF token
   */
  refresh() {
    this.token = this.generateToken();
    localStorage.setItem(this.storageKey, this.token);
    this.injectIntoForms();
    this.setMetaTag();
    return this.token;
  }

  /**
   * Inject CSRF token into all forms
   */
  injectIntoForms() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
      let input = form.querySelector(`input[name="${this.tokenName}"]`);
      if (!input) {
        input = document.createElement('input');
        input.type = 'hidden';
        input.name = this.tokenName;
        form.appendChild(input);
      }
      input.value = this.token;
    });
  }

  /**
   * Set CSRF token in meta tag
   */
  setMetaTag() {
    let meta = document.querySelector(`meta[name="${this.tokenName}"]`);
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = this.tokenName;
      document.head.appendChild(meta);
    }
    meta.content = this.token;
  }

  /**
   * Validate CSRF token from request
   * @param {string} token - Token to validate
   * @returns {boolean} - True if valid
   */
  validate(token) {
    return token === this.token;
  }

  /**
   * Add CSRF token to fetch headers
   * @param {object} headers - Existing headers object
   * @returns {object} - Headers with CSRF token
   */
  addToHeaders(headers = {}) {
    return {
      ...headers,
      [this.headerName]: this.getToken()
    };
  }

  /**
   * Add CSRF token to URL parameters
   * @param {string} url - Base URL
   * @returns {string} - URL with CSRF token
   */
  addToUrl(url) {
    const separator = url.includes('?') ? '&' : '?';
    return `${url}${separator}${this.tokenName}=${this.getToken()}`;
  }

  /**
   * Clear CSRF token (e.g., on logout)
   */
  clear() {
    this.token = null;
    localStorage.removeItem(this.storageKey);
    
    // Remove from forms
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
      const input = form.querySelector(`input[name="${this.tokenName}"]`);
      if (input) {input.remove();}
    });
    
    // Remove meta tag
    const meta = document.querySelector(`meta[name="${this.tokenName}"]`);
    if (meta) {meta.remove();}
  }
}

/**
 * CSRF protection instance
 */
const csrf = new CSRFManager();

/**
 * Initialize CSRF protection on page load
 */
function initCSRF() {
  csrf.init();
  
  // Watch for dynamically added forms
  const observer = new MutationObserver(() => {
    csrf.injectIntoForms();
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  return csrf;
}

/**
 * Validate CSRF token from form submission
 * @param {FormData} formData - Form data
 * @returns {boolean} - True if valid
 */
function validateCSRFToken(formData) {
  const token = formData.get(csrf.tokenName);
  return csrf.validate(token);
}

/**
 * Validate CSRF token from request headers
 * @param {object} headers - Request headers
 * @returns {boolean} - True if valid
 */
function validateCSRFHeader(headers) {
  const token = headers[csrf.headerName] || headers['x-csrf-token'];
  return csrf.validate(token);
}

/**
 * Enhanced fetch with CSRF protection
 * @param {string} url - URL to fetch
 * @param {object} options - Fetch options
 * @returns {Promise} - Fetch promise
 */
async function csrfFetch(url, options = {}) {
  const headers = csrf.addToHeaders(options.headers || {});
  
  // For state-changing methods, require CSRF token
  if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(options.method?.toUpperCase())) {
    if (!headers[csrf.headerName]) {
      throw new Error('CSRF token required for state-changing requests');
    }
  }
  
  return fetch(url, {
    ...options,
    headers
  });
}

/**
 * Show CSRF error to user
 */
function showCSRFError() {
  toast('Security validation failed. Please refresh the page.', 'er');
}

/**
 * Handle CSRF validation failure
 */
function handleCSRFError() {
  showCSRFError();
  // Optionally redirect to login or refresh page
  setTimeout(() => {
    location.reload();
  }, 2000);
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.CSRF = {
    manager: csrf,
    init: initCSRF,
    validateToken: validateCSRFToken,
    validateHeader: validateCSRFHeader,
    fetch: csrfFetch,
    showError: showCSRFError,
    handleError: handleCSRFError
  };
  
  // Auto-initialize on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCSRF);
  } else {
    initCSRF();
  }
}
