// Packing and Shipping Module - Order packing and shipping management

/**
 * Shipment class
 */
class Shipment {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.shipmentNumber = config.shipmentNumber || this.generateShipmentNumber();
    this.orderId = config.orderId || '';
    this.orderNumber = config.orderNumber || '';
    this.status = config.status || 'pending'; // pending, packed, shipped, delivered, cancelled
    this.carrier = config.carrier || '';
    this.trackingNumber = config.trackingNumber || '';
    this.service = config.service || 'standard'; // standard, express, overnight
    this.packages = config.packages || [];
    this.shippingAddress = config.shippingAddress || {};
    this.billingAddress = config.billingAddress || {};
    this.weight = config.weight || 0;
    this.dimensions = config.dimensions || { length: 0, width: 0, height: 0 };
    this.shippingCost = config.shippingCost || 0;
    this.shippedAt = config.shippedAt || null;
    this.estimatedDelivery = config.estimatedDelivery || null;
    this.actualDelivery = config.actualDelivery || null;
    this.notes = config.notes || '';
    this.packedBy = config.packedBy || '';
    this.shippedBy = config.shippedBy || '';
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `shipment-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  generateShipmentNumber() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `SHP-${year}${month}-${random}`;
  }

  /**
   * Get total weight
   * @returns {number} - Total weight
   */
  getTotalWeight() {
    return this.packages.reduce((sum, pkg) => sum + pkg.weight, 0);
  }

  /**
   * Get total volume
   * @returns {number} - Total volume
   */
  getTotalVolume() {
    return this.packages.reduce((sum, pkg) => {
      return sum + (pkg.dimensions.length * pkg.dimensions.width * pkg.dimensions.height);
    }, 0);
  }
}

/**
 * Package class
 */
class Package {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.shipmentId = config.shipmentId || '';
    this.packageNumber = config.packageNumber || 1;
    this.items = config.items || [];
    this.weight = config.weight || 0;
    this.dimensions = config.dimensions || { length: 0, width: 0, height: 0 };
    this.trackingNumber = config.trackingNumber || '';
    this.boxType = config.boxType || 'standard'; // standard, large, small, custom
  }

  generateId() {
    return `package-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get volume
   * @returns {number} - Volume
   */
  getVolume() {
    return this.dimensions.length * this.dimensions.width * this.dimensions.height;
  }
}

/**
 * Packing List class
 */
class PackingList {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.shipmentId = config.shipmentId || '';
    this.items = config.items || [];
    this.packedItems = config.packedItems || [];
    this.status = config.status || 'pending'; // pending, in_progress, completed
    this.packedBy = config.packedBy || '';
    this.startedAt = config.startedAt || null;
    this.completedAt = config.completedAt || null;
    this.notes = config.notes || '';
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `packing-list-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get packing progress
   * @returns {number} - Progress percentage
   */
  getProgress() {
    if (this.items.length === 0) {return 0;}
    const required = this.items.reduce((sum, item) => sum + Math.max(0, Number(item.quantity ?? item.qty ?? 1) || 0), 0);
    if (required === 0) return 0;
    const packed = this.packedItems.reduce((sum, packedItem) => {
      const item = this.items.find(candidate => candidate.id === packedItem.itemId);
      const itemRequired = item ? Math.max(0, Number(item.quantity ?? item.qty ?? 1) || 0) : 0;
      return sum + Math.min(itemRequired, Math.max(0, Number(packedItem.quantity ?? 1) || 0));
    }, 0);
    return Math.min(100, (packed / required) * 100);
  }

  /**
   * Is complete
   * @returns {boolean} - Is complete
   */
  isComplete() {
    if (this.items.length === 0) return false;
    return this.items.every(item => {
      const required = Math.max(0, Number(item.quantity ?? item.qty ?? 1) || 0);
      const packed = this.packedItems
        .filter(packedItem => packedItem.itemId === item.id)
        .reduce((sum, packedItem) => sum + Math.max(0, Number(packedItem.quantity ?? 1) || 0), 0);
      return packed >= required;
    });
  }
}

/**
 * Packing and Shipping Manager
 */
class PackingShippingManager {
  constructor() {
    this.shipments = new Map();
    this.packages = new Map();
    this.packingLists = new Map();
    this.init();
  }

  /**
   * Initialize packing and shipping manager
   */
  async init() {
    await this.loadShipments();
    await this.loadPackages();
    await this.loadPackingLists();
  }

  /**
   * Load shipments from storage
   */
  async loadShipments() {
    try {
      const shipments = await gAll('shipments');
      shipments.forEach(s => {
        this.shipments.set(s.id, new Shipment(s));
      });
    } catch (err) {
      console.error('Failed to load shipments:', err);
    }
  }

  /**
   * Load packages from storage
   */
  async loadPackages() {
    try {
      const packages = await gAll('packages');
      packages.forEach(p => {
        this.packages.set(p.id, new Package(p));
      });
    } catch (err) {
      console.error('Failed to load packages:', err);
    }
  }

  /**
   * Load packing lists from storage
   */
  async loadPackingLists() {
    try {
      const lists = await gAll('packing_lists');
      lists.forEach(l => {
        this.packingLists.set(l.id, new PackingList(l));
      });
    } catch (err) {
      console.error('Failed to load packing lists:', err);
    }
  }

  /**
   * Create shipment
   * @param {object} config - Shipment configuration
   * @returns {Shipment} - Created shipment
   */
  async createShipment(config) {
    const shipment = new Shipment(config);
    this.shipments.set(shipment.id, shipment);
    await this.saveShipment(shipment);
    return shipment;
  }

  /**
   * Update shipment
   * @param {string} id - Shipment ID
   * @param {object} updates - Updates to apply
   * @returns {Shipment} - Updated shipment
   */
  async updateShipment(id, updates) {
    const shipment = this.shipments.get(id);
    if (shipment) {
      Object.assign(shipment, updates);
      await this.saveShipment(shipment);
    }
    return shipment;
  }

  /**
   * Delete shipment
   * @param {string} id - Shipment ID
   */
  async deleteShipment(id) {
    this.shipments.delete(id);
    await dDel('shipments', id);
  }

  /**
   * Save shipment to storage
   * @param {Shipment} shipment - Shipment to save
   */
  async saveShipment(shipment) {
    try {
      await dPut('shipments', shipment);
    } catch (err) {
      console.error('Failed to save shipment:', err);
    }
  }

  /**
   * Add package to shipment
   * @param {string} shipmentId - Shipment ID
   * @param {object} packageData - Package data
   * @returns {Package} - Created package
   */
  async addPackage(shipmentId, packageData) {
    const shipment = this.shipments.get(shipmentId);
    if (!shipment) {
      throw new Error('Shipment not found');
    }

    const packageNumber = shipment.packages.length + 1;
    const pkg = new Package({
      ...packageData,
      shipmentId,
      packageNumber
    });

    this.packages.set(pkg.id, pkg);
    await this.savePackage(pkg);

    shipment.packages.push(pkg);
    shipment.weight = shipment.getTotalWeight();
    await this.saveShipment(shipment);

    return pkg;
  }

  /**
   * Save package to storage
   * @param {Package} pkg - Package to save
   */
  async savePackage(pkg) {
    try {
      await dPut('packages', pkg);
    } catch (err) {
      console.error('Failed to save package:', err);
    }
  }

  /**
   * Create packing list
   * @param {object} config - Packing list configuration
   * @returns {PackingList} - Created packing list
   */
  async createPackingList(config) {
    const packingList = new PackingList(config);
    this.packingLists.set(packingList.id, packingList);
    await this.savePackingList(packingList);
    return packingList;
  }

  /**
   * Start packing
   * @param {string} id - Packing list ID
   * @param {string} packedBy - User who is packing
   */
  async startPacking(id, packedBy) {
    const packingList = this.packingLists.get(id);
    if (packingList) {
      packingList.status = 'in_progress';
      packingList.packedBy = packedBy;
      packingList.startedAt = new Date().toISOString();
      await this.savePackingList(packingList);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('packing_started', 'warehouse', id, {
          shipmentId: packingList.shipmentId
        });
      }
    }
  }

  /**
   * Pack item
   * @param {string} id - Packing list ID
   * @param {string} itemId - Item ID
   * @param {number} quantity - Quantity packed
   */
  async packItem(id, itemId, quantity) {
    const packingList = this.packingLists.get(id);
    if (packingList) {
      const item = packingList.items.find(i => i.id === itemId);
      if (item) {
        const amount = Number(quantity);
        const required = Math.max(0, Number(item.quantity ?? item.qty ?? 1) || 0);
        const alreadyPacked = packingList.packedItems
          .filter(packedItem => packedItem.itemId === itemId)
          .reduce((sum, packedItem) => sum + Math.max(0, Number(packedItem.quantity ?? 1) || 0), 0);
        if (!Number.isFinite(amount) || amount <= 0 || alreadyPacked + amount > required) {
          throw new Error('Packed quantity must be positive and cannot exceed the required quantity');
        }
        packingList.packedItems.push({
          itemId,
          barcode: item.barcode,
          itemName: item.itemName,
          quantity: amount,
          packedAt: new Date().toISOString()
        });

        if (packingList.isComplete()) {
          packingList.status = 'completed';
          packingList.completedAt = new Date().toISOString();
        } else {
          packingList.status = 'in_progress';
        }

        await this.savePackingList(packingList);
        return packingList;
      }
    }
    return null;
  }

  /**
   * Complete packing
   * @param {string} id - Packing list ID
   */
  async completePacking(id) {
    const packingList = this.packingLists.get(id);
    if (packingList) {
      if (!packingList.isComplete()) throw new Error('Cannot complete packing until all required quantities are packed');
      packingList.status = 'completed';
      packingList.completedAt = new Date().toISOString();
      await this.savePackingList(packingList);

      // Update shipment status
      const shipment = this.shipments.get(packingList.shipmentId);
      if (shipment) {
        shipment.status = 'packed';
        await this.saveShipment(shipment);
      }

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('packing_completed', 'warehouse', id, {
          shipmentId: packingList.shipmentId
        });
      }
    }
  }

  /**
   * Save packing list to storage
   * @param {PackingList} packingList - Packing list to save
   */
  async savePackingList(packingList) {
    try {
      await dPut('packing_lists', packingList);
    } catch (err) {
      console.error('Failed to save packing list:', err);
    }
  }

  /**
   * Ship shipment
   * @param {string} id - Shipment ID
   * @param {object} shippingData - Shipping data
   */
  async shipShipment(id, shippingData) {
    const shipment = this.shipments.get(id);
    if (shipment) {
      shipment.status = 'shipped';
      shipment.carrier = shippingData.carrier || shipment.carrier;
      shipment.trackingNumber = shippingData.trackingNumber || shipment.trackingNumber;
      shipment.service = shippingData.service || shipment.service;
      shipment.shippedAt = new Date().toISOString();
      shipment.shippedBy = shippingData.shippedBy || '';
      
      // Calculate estimated delivery
      const shippedDate = new Date(shipment.shippedAt);
      const deliveryDays = this.getDeliveryDays(shipment.service);
      const estimatedDelivery = new Date(shippedDate);
      estimatedDelivery.setDate(estimatedDelivery.getDate() + deliveryDays);
      shipment.estimatedDelivery = estimatedDelivery.toISOString();

      await this.saveShipment(shipment);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('shipment_shipped', 'warehouse', id, {
          shipmentNumber: shipment.shipmentNumber,
          carrier: shipment.carrier,
          trackingNumber: shipment.trackingNumber
        });
      }
    }
  }

  /**
   * Get delivery days
   * @param {string} service - Service type
   * @returns {number} - Delivery days
   */
  getDeliveryDays(service) {
    switch (service) {
      case 'overnight':
        return 1;
      case 'express':
        return 2;
      case 'standard':
        return 5;
      default:
        return 5;
    }
  }

  /**
   * Mark as delivered
   * @param {string} id - Shipment ID
   */
  async markAsDelivered(id) {
    const shipment = this.shipments.get(id);
    if (shipment) {
      shipment.status = 'delivered';
      shipment.actualDelivery = new Date().toISOString();
      await this.saveShipment(shipment);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('shipment_delivered', 'warehouse', id, {
          shipmentNumber: shipment.shipmentNumber
        });
      }
    }
  }

  /**
   * Cancel shipment
   * @param {string} id - Shipment ID
   * @param {string} reason - Cancellation reason
   */
  async cancelShipment(id, reason) {
    const shipment = this.shipments.get(id);
    if (shipment) {
      shipment.status = 'cancelled';
      shipment.notes = reason;
      await this.saveShipment(shipment);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('shipment_cancelled', 'warehouse', id, {
          shipmentNumber: shipment.shipmentNumber,
          reason
        });
      }
    }
  }

  /**
   * Calculate shipping cost
   * @param {object} shipmentData - Shipment data
   * @returns {number} - Shipping cost
   */
  calculateShippingCost(shipmentData) {
    const weight = shipmentData.weight || 0;
    const service = shipmentData.service || 'standard';

    // Simplified cost calculation
    const baseRate = 10;
    const weightRate = weight * 0.5;
    const serviceMultiplier = service === 'overnight' ? 3 : service === 'express' ? 2 : 1;

    return (baseRate + weightRate) * serviceMultiplier;
  }

  /**
   * Get shipment
   * @param {string} id - Shipment ID
   * @returns {Shipment} - Shipment
   */
  getShipment(id) {
    return this.shipments.get(id);
  }

  /**
   * Get shipment by number
   * @param {string} shipmentNumber - Shipment number
   * @returns {Shipment} - Shipment
   */
  getShipmentByNumber(shipmentNumber) {
    return Array.from(this.shipments.values()).find(s => s.shipmentNumber === shipmentNumber);
  }

  /**
   * Get shipment by tracking number
   * @param {string} trackingNumber - Tracking number
   * @returns {Shipment} - Shipment
   */
  getShipmentByTrackingNumber(trackingNumber) {
    return Array.from(this.shipments.values()).find(s => s.trackingNumber === trackingNumber);
  }

  /**
   * Get all shipments
   * @returns {Array} - Array of shipments
   */
  getAllShipments() {
    return Array.from(this.shipments.values());
  }

  /**
   * Get shipments by status
   * @param {string} status - Status
   * @returns {Array} - Shipments
   */
  getShipmentsByStatus(status) {
    return this.getAllShipments().filter(s => s.status === status);
  }

  /**
   * Get shipments by order
   * @param {string} orderId - Order ID
   * @returns {Array} - Shipments
   */
  getShipmentsByOrder(orderId) {
    return this.getAllShipments().filter(s => s.orderId === orderId);
  }

  /**
   * Get pending shipments
   * @returns {Array} - Pending shipments
   */
  getPendingShipments() {
    return this.getShipmentsByStatus('pending');
  }

  /**
   * Get in transit shipments
   * @returns {Array} - In transit shipments
   */
  getInTransitShipments() {
    return this.getShipmentsByStatus('shipped');
  }

  /**
   * Get overdue shipments
   * @returns {Array} - Overdue shipments
   */
  getOverdueShipments() {
    const now = new Date();
    return this.getAllShipments().filter(s => {
      if (!s.estimatedDelivery || s.status !== 'shipped') {
        return false;
      }
      return new Date(s.estimatedDelivery) < now;
    });
  }

  /**
   * Get packing list
   * @param {string} id - Packing list ID
   * @returns {PackingList} - Packing list
   */
  getPackingList(id) {
    return this.packingLists.get(id);
  }

  /**
   * Get packing list by shipment
   * @param {string} shipmentId - Shipment ID
   * @returns {PackingList} - Packing list
   */
  getPackingListByShipment(shipmentId) {
    return Array.from(this.packingLists.values()).find(l => l.shipmentId === shipmentId);
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const shipments = this.getAllShipments();
    const packingLists = Array.from(this.packingLists.values());

    return {
      totalShipments: shipments.length,
      byStatus: this.getStatusCounts(shipments),
      byCarrier: this.getCarrierCounts(shipments),
      totalWeight: shipments.reduce((sum, s) => sum + s.weight, 0),
      totalShippingCost: shipments.reduce((sum, s) => sum + s.shippingCost, 0),
      avgShippingCost: shipments.length > 0 
        ? shipments.reduce((sum, s) => sum + s.shippingCost, 0) / shipments.length 
        : 0,
      inTransit: this.getInTransitShipments().length,
      overdue: this.getOverdueShipments().length,
      totalPackingLists: packingLists.length,
      pendingPacking: packingLists.filter(l => l.status === 'pending').length,
      inProgressPacking: packingLists.filter(l => l.status === 'in_progress').length
    };
  }

  /**
   * Get status counts
   * @param {Array} shipments - Shipments
   * @returns {object} - Status counts
   */
  getStatusCounts(shipments) {
    const counts = {};
    shipments.forEach(s => {
      counts[s.status] = (counts[s.status] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get carrier counts
   * @param {Array} shipments - Shipments
   * @returns {object} - Carrier counts
   */
  getCarrierCounts(shipments) {
    const counts = {};
    shipments.forEach(s => {
      if (s.carrier) {
        counts[s.carrier] = (counts[s.carrier] || 0) + 1;
      }
    });
    return counts;
  }
}

/**
 * Global packing and shipping manager instance
 */
const packingShippingManager = new PackingShippingManager();

/**
 * Initialize packing and shipping
 */
async function initPackingShipping() {
  await packingShippingManager.init();
  return packingShippingManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.PackingShipping = {
    manager: packingShippingManager,
    init: initPackingShipping,
    createShipment: (config) => packingShippingManager.createShipment(config),
    updateShipment: (id, updates) => packingShippingManager.updateShipment(id, updates),
    deleteShipment: (id) => packingShippingManager.deleteShipment(id),
    getShipment: (id) => packingShippingManager.getShipment(id),
    getShipmentByNumber: (shipmentNumber) => packingShippingManager.getShipmentByNumber(shipmentNumber),
    getShipmentByTrackingNumber: (trackingNumber) => packingShippingManager.getShipmentByTrackingNumber(trackingNumber),
    getAllShipments: () => packingShippingManager.getAllShipments(),
    getShipmentsByStatus: (status) => packingShippingManager.getShipmentsByStatus(status),
    getShipmentsByOrder: (orderId) => packingShippingManager.getShipmentsByOrder(orderId),
    getPendingShipments: () => packingShippingManager.getPendingShipments(),
    getInTransitShipments: () => packingShippingManager.getInTransitShipments(),
    getOverdueShipments: () => packingShippingManager.getOverdueShipments(),
    addPackage: (shipmentId, data) => packingShippingManager.addPackage(shipmentId, data),
    ship: (id, data) => packingShippingManager.shipShipment(id, data),
    markAsDelivered: (id) => packingShippingManager.markAsDelivered(id),
    cancel: (id, reason) => packingShippingManager.cancelShipment(id, reason),
    calculateShippingCost: (data) => packingShippingManager.calculateShippingCost(data),
    createPackingList: (config) => packingShippingManager.createPackingList(config),
    startPacking: (id, user) => packingShippingManager.startPacking(id, user),
    packItem: (id, itemId, quantity) => packingShippingManager.packItem(id, itemId, quantity),
    completePacking: (id) => packingShippingManager.completePacking(id),
    getPackingList: (id) => packingShippingManager.getPackingList(id),
    getPackingListByShipment: (shipmentId) => packingShippingManager.getPackingListByShipment(shipmentId),
    getStats: () => packingShippingManager.getStatistics()
  };
}
