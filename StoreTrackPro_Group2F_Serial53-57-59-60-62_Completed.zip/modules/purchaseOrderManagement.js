/* exported PurchaseOrderItem */
// Purchase Order Management Module - Purchase order creation and management

/**
 * Purchase Order class
 */
class PurchaseOrder {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.orderNumber = config.orderNumber || this.generateOrderNumber();
    this.supplierId = config.supplierId || '';
    this.supplierName = config.supplierName || '';
    this.status = config.status || 'draft'; // draft, submitted, approved, rejected, ordered, received, cancelled
    this.orderDate = config.orderDate || new Date().toISOString();
    this.expectedDate = config.expectedDate || null;
    this.receivedDate = config.receivedDate || null;
    this.items = config.items || [];
    this.subtotal = config.subtotal || 0;
    this.tax = config.tax || 0;
    this.shipping = config.shipping || 0;
    this.total = config.total || 0;
    this.currency = config.currency || 'USD';
    this.paymentTerms = config.paymentTerms || 'NET30';
    this.shippingAddress = config.shippingAddress || '';
    this.billingAddress = config.billingAddress || '';
    this.notes = config.notes || '';
    this.internalNotes = config.internalNotes || '';
    this.createdBy = config.createdBy || '';
    this.approvedBy = config.approvedBy || null;
    this.approvedAt = config.approvedAt || null;
    this.receivedBy = config.receivedBy || null;
    this.createdAt = config.createdAt || new Date().toISOString();
    this.updatedAt = config.updatedAt || new Date().toISOString();
  }

  generateId() {
    return `po-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  generateOrderNumber() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `PO-${year}${month}-${random}`;
  }

  /**
   * Calculate totals
   */
  calculateTotals() {
    this.subtotal = this.items.reduce((sum, item) => {
      const quantity = Number(item.quantity) || 0;
      const unitPrice = Number(item.unitPrice) || 0;
      const discount = Math.min(100, Math.max(0, Number(item.discount) || 0));
      return sum + quantity * unitPrice * (1 - discount / 100);
    }, 0);
    this.tax = this.subtotal * 0.1; // 10% tax
    this.shipping = this.subtotal > 1000 ? 0 : 50; // Free shipping over 1000
    this.total = this.subtotal + this.tax + this.shipping;
  }
}

/**
 * Purchase Order Item class
 */
class PurchaseOrderItem {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.orderId = config.orderId || '';
    this.itemId = config.itemId || null;
    this.barcode = config.barcode || '';
    this.itemName = config.itemName || '';
    this.sku = config.sku || '';
    this.quantity = config.quantity || 0;
    this.unitPrice = config.unitPrice || 0;
    this.discount = config.discount || 0;
    this.taxRate = config.taxRate || 0;
    this.receivedQuantity = config.receivedQuantity || 0;
    this.binLocation = config.binLocation || '';
    this.notes = config.notes || '';
  }

  generateId() {
    return `po-item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get line total
   * @returns {number} - Line total
   */
  getLineTotal() {
    return this.quantity * this.unitPrice * (1 - this.discount / 100);
  }
}

/**
 * Purchase Order Manager
 */
class PurchaseOrderManager {
  constructor() {
    this.orders = new Map();
    this.init();
  }

  /**
   * Initialize purchase order manager
   */
  async init() {
    await this.loadOrders();
  }

  /**
   * Load orders from storage
   */
  async loadOrders() {
    try {
      const orders = await gAll('purchase_orders');
      orders.forEach(o => {
        this.orders.set(o.id, new PurchaseOrder(o));
      });
    } catch (err) {
      console.error('Failed to load purchase orders:', err);
    }
  }

  /**
   * Create purchase order
   * @param {object} config - Order configuration
   * @returns {PurchaseOrder} - Created order
   */
  async createOrder(config) {
    const order = new PurchaseOrder(config);
    order.calculateTotals();
    this.orders.set(order.id, order);
    await this.saveOrder(order);

    // Log activity
    if (typeof window !== 'undefined' && window.ActivityTracking) {
      await window.ActivityTracking.logActivity('po_created', 'purchase', order.id, {
        orderNumber: order.orderNumber,
        supplierId: order.supplierId,
        total: order.total
      });
    }

    return order;
  }

  /**
   * Update order
   * @param {string} id - Order ID
   * @param {object} updates - Updates to apply
   * @returns {PurchaseOrder} - Updated order
   */
  async updateOrder(id, updates) {
    const order = this.orders.get(id);
    if (order) {
      Object.assign(order, updates);
      order.updatedAt = new Date().toISOString();
      
      if (updates.items) {
        order.calculateTotals();
      }

      await this.saveOrder(order);
    }
    return order;
  }

  /**
   * Delete order
   * @param {string} id - Order ID
   */
  async deleteOrder(id) {
    this.orders.delete(id);
    await dDel('purchase_orders', id);
  }

  /**
   * Save order to storage
   * @param {PurchaseOrder} order - Order to save
   */
  async saveOrder(order) {
    try {
      await dPut('purchase_orders', order);
    } catch (err) {
      console.error('Failed to save purchase order:', err);
    }
  }

  /**
   * Submit order
   * @param {string} id - Order ID
   * @param {string} submittedBy - User who submitted
   */
  async submitOrder(id, submittedBy) {
    const order = this.orders.get(id);
    if (order) {
      order.status = 'submitted';
      order.updatedAt = new Date().toISOString();
      await this.saveOrder(order);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('po_submitted', 'purchase', id, {
          orderNumber: order.orderNumber
        });
      }
    }
  }

  /**
   * Approve order
   * @param {string} id - Order ID
   * @param {string} approvedBy - User who approved
   */
  async approveOrder(id, approvedBy) {
    const order = this.orders.get(id);
    if (order) {
      order.status = 'approved';
      order.approvedBy = approvedBy;
      order.approvedAt = new Date().toISOString();
      order.updatedAt = new Date().toISOString();
      await this.saveOrder(order);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('po_approved', 'purchase', id, {
          orderNumber: order.orderNumber
        });
      }
    }
  }

  /**
   * Reject order
   * @param {string} id - Order ID
   * @param {string} reason - Rejection reason
   */
  async rejectOrder(id, reason) {
    const order = this.orders.get(id);
    if (order) {
      order.status = 'rejected';
      order.internalNotes = reason;
      order.updatedAt = new Date().toISOString();
      await this.saveOrder(order);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('po_rejected', 'purchase', id, {
          orderNumber: order.orderNumber,
          reason
        });
      }
    }
  }

  /**
   * Mark order as ordered
   * @param {string} id - Order ID
   */
  async markAsOrdered(id) {
    const order = this.orders.get(id);
    if (order) {
      order.status = 'ordered';
      order.updatedAt = new Date().toISOString();
      await this.saveOrder(order);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('po_ordered', 'purchase', id, {
          orderNumber: order.orderNumber
        });
      }
    }
  }

  /**
   * Receive order
   * @param {string} id - Order ID
   * @param {object} receivedData - Received data
   * @param {string} receivedBy - User who received
   */
  async receiveOrder(id, receivedData, receivedBy) {
    const order = this.orders.get(id);
    if (!order) return null;
    if (!Array.isArray(receivedData?.items) || !order.items.length) throw new Error('Receipt must include order items');

    const materialUpdates = new Map();
    const receiptPlans = [];
    const seenLines = new Set();
    for (const receivedItem of receivedData.items) {
      const orderItem = order.items.find(item =>
        (receivedItem.itemId && String(item.itemId || item.id) === String(receivedItem.itemId)) ||
        (receivedItem.barcode && item.barcode === receivedItem.barcode)
      );
      if (!orderItem) throw new Error(`Received item is not on purchase order: ${receivedItem.barcode || receivedItem.itemId || 'unknown'}`);
      const lineKey = String(orderItem.id || orderItem.itemId || orderItem.barcode);
      if (seenLines.has(lineKey)) throw new Error(`Duplicate receipt line: ${orderItem.barcode || orderItem.itemName}`);
      seenLines.add(lineKey);

      const previous = Math.max(0, Number(orderItem.receivedQuantity) || 0);
      const quantity = Number(receivedItem.receivedQuantity ?? receivedItem.quantity);
      if (!Number.isFinite(quantity) || quantity < 0) throw new Error('Receipt quantity must be a non-negative number');
      let delta;
      let nextReceiptIds = Array.isArray(orderItem.receiptIds) ? [...orderItem.receiptIds] : [];
      if (receivedItem.receiptId) {
        const receiptId = String(receivedItem.receiptId);
        if (nextReceiptIds.includes(receiptId)) continue;
        delta = quantity;
        nextReceiptIds.push(receiptId);
      } else {
        // Without a receipt ID, quantity is the cumulative received-to-date value.
        delta = Math.max(0, quantity - previous);
      }
      const ordered = Math.max(0, Number(orderItem.quantity) || 0);
      if (previous + delta > ordered) throw new Error(`Receipt exceeds ordered quantity for ${orderItem.barcode || orderItem.itemName}`);
      if (!delta) continue;

      const barcode = receivedItem.barcode || orderItem.barcode;
      let material = [...materialUpdates.values()].find(candidate => candidate.barcode === barcode);
      if (!material) material = await gOne('materials', barcode);
      if (!material) throw new Error(`Material not found for received barcode ${barcode}`);
      material = { ...material };
      material.stock = Number(material.stock ?? material.currentStock ?? 0) + delta;
      delete material.currentStock;
      material.updatedAt = new Date().toISOString();
      materialUpdates.set(String(material.id ?? barcode), material);
      receiptPlans.push({ lineKey, receivedQuantity: previous + delta, receiptIds: nextReceiptIds });
    }

    if (!receiptPlans.length) return order;
    const orderToSave = { ...order, items: order.items.map(item => ({ ...item })) };
    for (const plan of receiptPlans) {
      const orderItem = orderToSave.items.find(item => String(item.id || item.itemId || item.barcode) === plan.lineKey);
      if (!orderItem) throw new Error('Purchase order changed while validating receipt');
      orderItem.receivedQuantity = plan.receivedQuantity;
      if (plan.receiptIds.length) orderItem.receiptIds = plan.receiptIds;
    }
    const now = new Date().toISOString();
    const allReceived = orderToSave.items.every(item => Number(item.receivedQuantity) >= Number(item.quantity));
    const anyReceived = orderToSave.items.some(item => Number(item.receivedQuantity) > 0);
    orderToSave.status = allReceived ? 'received' : (anyReceived ? 'partially_received' : 'ordered');
    orderToSave.receivedDate = allReceived ? now : null;
    orderToSave.receivedBy = receivedBy;
    orderToSave.updatedAt = now;

    if (typeof window !== 'undefined' && typeof window.dPutMany === 'function') {
      await window.dPutMany([
        ...[...materialUpdates.values()].map(material => ({ store: 'materials', obj: material })),
        { store: 'purchase_orders', obj: orderToSave }
      ]);
    } else {
      throw new Error('Atomic storage writes are required to receive a purchase order safely');
    }
    Object.assign(order, orderToSave);

    if (typeof window !== 'undefined' && window.ActivityTracking) {
      await window.ActivityTracking.logActivity('po_received', 'purchase', id, {
        orderNumber: order.orderNumber, status: order.status
      });
    }
    return order;
  }

  /**
   * Cancel order
   * @param {string} id - Order ID
   * @param {string} reason - Cancellation reason
   */
  async cancelOrder(id, reason) {
    const order = this.orders.get(id);
    if (order) {
      order.status = 'cancelled';
      order.internalNotes = reason;
      order.updatedAt = new Date().toISOString();
      await this.saveOrder(order);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('po_cancelled', 'purchase', id, {
          orderNumber: order.orderNumber,
          reason
        });
      }
    }
  }

  /**
   * Get order
   * @param {string} id - Order ID
   * @returns {PurchaseOrder} - Order
   */
  getOrder(id) {
    return this.orders.get(id);
  }

  /**
   * Get order by order number
   * @param {string} orderNumber - Order number
   * @returns {PurchaseOrder} - Order
   */
  getOrderByNumber(orderNumber) {
    return Array.from(this.orders.values()).find(o => o.orderNumber === orderNumber);
  }

  /**
   * Get all orders
   * @returns {Array} - Array of orders
   */
  getAllOrders() {
    return Array.from(this.orders.values());
  }

  /**
   * Get orders by supplier
   * @param {string} supplierId - Supplier ID
   * @returns {Array} - Orders
   */
  getOrdersBySupplier(supplierId) {
    return this.getAllOrders().filter(o => o.supplierId === supplierId);
  }

  /**
   * Get orders by status
   * @param {string} status - Status
   * @returns {Array} - Orders
   */
  getOrdersByStatus(status) {
    return this.getAllOrders().filter(o => o.status === status);
  }

  /**
   * Get pending approval orders
   * @returns {Array} - Pending orders
   */
  getPendingApprovalOrders() {
    return this.getOrdersByStatus('submitted');
  }

  /**
   * Get overdue orders
   * @returns {Array} - Overdue orders
   */
  getOverdueOrders() {
    const now = new Date();
    return this.getAllOrders().filter(o => {
      if (!o.expectedDate || o.status === 'received' || o.status === 'cancelled') {
        return false;
      }
      return new Date(o.expectedDate) < now;
    });
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const orders = this.getAllOrders();

    return {
      totalOrders: orders.length,
      byStatus: this.getStatusCounts(orders),
      totalValue: orders.reduce((sum, o) => sum + o.total, 0),
      avgOrderValue: orders.length > 0 
        ? orders.reduce((sum, o) => sum + o.total, 0) / orders.length 
        : 0,
      pendingApproval: this.getPendingApprovalOrders().length,
      overdue: this.getOverdueOrders().length,
      bySupplier: this.getSupplierCounts(orders),
      thisMonth: this.getThisMonthOrders(orders).length
    };
  }

  /**
   * Get status counts
   * @param {Array} orders - Orders
   * @returns {object} - Status counts
   */
  getStatusCounts(orders) {
    const counts = {};
    orders.forEach(o => {
      counts[o.status] = (counts[o.status] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get supplier counts
   * @param {Array} orders - Orders
   * @returns {object} - Supplier counts
   */
  getSupplierCounts(orders) {
    const counts = {};
    orders.forEach(o => {
      counts[o.supplierId] = (counts[o.supplierId] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get this month orders
   * @param {Array} orders - Orders
   * @returns {Array} - This month orders
   */
  getThisMonthOrders(orders) {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);

    return orders.filter(o => new Date(o.orderDate) >= firstDay);
  }
}

/**
 * Global purchase order manager instance
 */
const purchaseOrderManager = new PurchaseOrderManager();

/**
 * Initialize purchase order management
 */
async function initPurchaseOrderManagement() {
  await purchaseOrderManager.init();
  return purchaseOrderManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.PurchaseOrderManagement = {
    manager: purchaseOrderManager,
    init: initPurchaseOrderManagement,
    createOrder: (config) => purchaseOrderManager.createOrder(config),
    updateOrder: (id, updates) => purchaseOrderManager.updateOrder(id, updates),
    deleteOrder: (id) => purchaseOrderManager.deleteOrder(id),
    getOrder: (id) => purchaseOrderManager.getOrder(id),
    getOrderByNumber: (orderNumber) => purchaseOrderManager.getOrderByNumber(orderNumber),
    getAllOrders: () => purchaseOrderManager.getAllOrders(),
    getOrdersBySupplier: (supplierId) => purchaseOrderManager.getOrdersBySupplier(supplierId),
    getOrdersByStatus: (status) => purchaseOrderManager.getOrdersByStatus(status),
    getPendingApprovalOrders: () => purchaseOrderManager.getPendingApprovalOrders(),
    getOverdueOrders: () => purchaseOrderManager.getOverdueOrders(),
    submit: (id, user) => purchaseOrderManager.submitOrder(id, user),
    approve: (id, user) => purchaseOrderManager.approveOrder(id, user),
    reject: (id, reason) => purchaseOrderManager.rejectOrder(id, reason),
    markAsOrdered: (id) => purchaseOrderManager.markAsOrdered(id),
    receive: (id, data, user) => purchaseOrderManager.receiveOrder(id, data, user),
    cancel: (id, reason) => purchaseOrderManager.cancelOrder(id, reason),
    getStats: () => purchaseOrderManager.getStatistics()
  };
}
