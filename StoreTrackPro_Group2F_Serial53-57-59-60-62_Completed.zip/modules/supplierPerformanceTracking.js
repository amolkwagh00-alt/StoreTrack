// Supplier Performance Tracking Module - Supplier performance metrics and analytics

/**
 * Supplier Performance Metric class
 */
class SupplierPerformanceMetric {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.supplierId = config.supplierId || '';
    this.period = config.period || 'monthly'; // daily, weekly, monthly, quarterly, yearly
    this.periodStart = config.periodStart || new Date().toISOString();
    this.periodEnd = config.periodEnd || new Date().toISOString();
    this.onTimeDeliveryRate = config.onTimeDeliveryRate || 0;
    this.qualityRate = config.qualityRate || 0;
    this.fillRate = config.fillRate ?? null;
    this.responseTime = config.responseTime ?? null; // Average response time in hours
    this.totalOrders = config.totalOrders || 0;
    this.totalValue = config.totalValue || 0;
    this.returns = config.returns || 0;
    this.complaints = config.complaints ?? null;
    this.score = config.score || 0; // Overall performance score (0-100)
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `perf-metric-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Calculate overall score
   * @returns {number} - Overall score
   */
  calculateScore() {
    // Weighted score calculation
    const weights = {
      onTimeDelivery: 0.35,
      quality: 0.30,
      fillRate: 0.20,
      responseTime: 0.10,
      complaints: 0.05
    };

    const scores = [
      { value: this.onTimeDeliveryRate * 100, weight: weights.onTimeDelivery },
      { value: this.qualityRate * 100, weight: weights.quality }
    ];
    if (Number.isFinite(this.fillRate)) { scores.push({ value: this.fillRate * 100, weight: weights.fillRate }); }
    if (Number.isFinite(this.responseTime)) { scores.push({ value: Math.max(0, 100 - (this.responseTime / 24 * 100)), weight: weights.responseTime }); }
    if (Number.isFinite(this.complaints) && this.totalOrders > 0) {
      scores.push({ value: Math.max(0, 100 - (this.complaints / this.totalOrders * 100)), weight: weights.complaints });
    }
    const totalWeight = scores.reduce((sum, entry) => sum + entry.weight, 0);
    this.score = totalWeight > 0
      ? scores.reduce((sum, entry) => sum + (entry.value * entry.weight), 0) / totalWeight
      : 0;

    return this.score;
  }
}

/**
 * Supplier Evaluation class
 */
class SupplierEvaluation {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.supplierId = config.supplierId || '';
    this.evaluatedBy = config.evaluatedBy || '';
    this.evaluatedAt = config.evaluatedAt || new Date().toISOString();
    this.period = config.period || 'quarterly';
    this.criteria = config.criteria || {}; // { criterion: score }
    this.comments = config.comments || '';
    this.rating = config.rating || 0;
    this.recommendation = config.recommendation || ''; // continue, review, replace
    this.approved = config.approved || false;
    this.approvedBy = config.approvedBy || null;
    this.approvedAt = config.approvedAt || null;
  }

  generateId() {
    return `evaluation-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Supplier Performance Tracking Manager
 */
class SupplierPerformanceTrackingManager {
  constructor() {
    this.metrics = new Map();
    this.evaluations = new Map();
    this.init();
  }

  /**
   * Initialize supplier performance tracking manager
   */
  async init() {
    await this.loadMetrics();
    await this.loadEvaluations();
    this.startMetricCalculation();
  }

  /**
   * Load metrics from storage
   */
  async loadMetrics() {
    try {
      const metrics = await gAll('supplier_performance_metrics');
      metrics.forEach(m => {
        this.metrics.set(m.id, new SupplierPerformanceMetric(m));
      });
    } catch (err) {
      console.error('Failed to load performance metrics:', err);
    }
  }

  /**
   * Load evaluations from storage
   */
  async loadEvaluations() {
    try {
      const evaluations = await gAll('supplier_evaluations');
      evaluations.forEach(e => {
        this.evaluations.set(e.id, new SupplierEvaluation(e));
      });
    } catch (err) {
      console.error('Failed to load supplier evaluations:', err);
    }
  }

  /**
   * Start metric calculation
   */
  startMetricCalculation() {
    setInterval(() => {
      this.calculateMetricsForAllSuppliers();
    }, 86400000); // Run daily
  }

  /**
   * Calculate metrics for all suppliers
   */
  async calculateMetricsForAllSuppliers() {
    if (typeof window !== 'undefined' && window.SupplierDatabase) {
      const suppliers = window.SupplierDatabase.getActiveSuppliers();

      for (const supplier of suppliers) {
        await this.calculateMetricsForSupplier(supplier.id);
      }
    }
  }

  /**
   * Calculate metrics for supplier
   * @param {string} supplierId - Supplier ID
   */
  async calculateMetricsForSupplier(supplierId) {
    try {
      // Get supplier items
      const supplierItems = await gAll('supplier_items');
      const items = supplierItems.filter(i => i.supplierId === supplierId);

      // Calculate metrics from orders and transactions
      const transactions = await gAll('transactions');
      const periodEnd = new Date();
      const periodStart = new Date(periodEnd.getFullYear(), periodEnd.getMonth(), 1);
      const inCurrentMonth = transaction => {
        const date = new Date(transaction.time || transaction.timestamp || transaction.date || transaction.createdAt);
        return Number.isFinite(date.getTime()) && date >= periodStart && date <= periodEnd;
      };
      const supplierTransactions = transactions.filter(t => items.some(i => i.barcode === t.barcode) && t.type === 'IN' && inCurrentMonth(t));
      const supplierReturns = transactions.filter(t => items.some(i => i.barcode === t.barcode) && t.type === 'OUT' && inCurrentMonth(t) && (t.returned === true || t.isReturn === true || String(t.reason || '').toLowerCase() === 'return' || String(t.remarks || '').toLowerCase().includes('return')));

      const totalOrders = supplierTransactions.length;
      const totalValue = supplierTransactions.reduce((sum, t) => sum + ((Number(t.qty ?? t.quantity) || 0) * (Number(t.unitCost ?? t.unitPrice) || 0)), 0);

      // Calculate on-time delivery rate (simplified)
      const onTimeDeliveries = supplierTransactions.filter(t => {
        const item = items.find(i => i.barcode === t.barcode);
        const promised = t.promisedDate || t.expectedDate || t.dueDate || t.deliveryDueDate;
        if (promised) return new Date(t.time) <= new Date(promised);
        const orderDate = t.orderDate || t.orderedAt || t.requestedAt;
        if (!orderDate || !item) return false;
        const expectedDate = new Date(orderDate); expectedDate.setDate(expectedDate.getDate() + Number(item.leadTime || 7));
        return new Date(t.time) <= expectedDate;
      }).length;

      const onTimeEligible = supplierTransactions.filter(t => t.promisedDate || t.expectedDate || t.dueDate || t.deliveryDueDate || t.orderDate || t.orderedAt || t.requestedAt).length;
      const onTimeDeliveryRate = onTimeEligible > 0 ? onTimeDeliveries / onTimeEligible : (totalOrders > 0 ? 1 : 0);

      // Calculate quality rate (simplified - based on returns)
      const returns = supplierReturns.length;
      const qualityRate = totalOrders > 0 ? 1 - (returns / totalOrders) : 1;

      const isNumeric = value => value !== null && value !== '' && Number.isFinite(Number(value));
      const numericValues = (keys) => supplierTransactions
        .map(transaction => keys.map(key => transaction[key]).find(isNumeric))
        .filter(value => value !== undefined)
        .map(Number);
      const fillRateValues = supplierTransactions.map(transaction => {
        if (isNumeric(transaction.fillRate)) { return Number(transaction.fillRate); }
        const orderedValue = transaction.orderedQuantity ?? transaction.requestedQuantity ?? transaction.orderQuantity;
        const fulfilledValue = transaction.fulfilledQuantity ?? transaction.receivedQuantity ?? transaction.deliveredQuantity;
        const ordered = Number(orderedValue);
        const fulfilled = Number(fulfilledValue);
        return Number.isFinite(ordered) && ordered > 0 && Number.isFinite(fulfilled) ? fulfilled / ordered : null;
      }).filter(value => Number.isFinite(value));
      const fillRate = fillRateValues.length > 0 ? fillRateValues.reduce((sum, value) => sum + value, 0) / fillRateValues.length : null;

      const responseTimeValues = supplierTransactions.map(transaction => {
        const directValue = transaction.responseTimeHours ?? transaction.responseTime;
        const direct = Number(directValue);
        if (isNumeric(directValue)) { return direct; }
        const requestedAt = transaction.requestedAt ?? transaction.orderDate ?? transaction.orderedAt;
        const respondedAt = transaction.respondedAt ?? transaction.responseAt ?? transaction.acknowledgedAt;
        if (requestedAt && respondedAt) { return (new Date(respondedAt) - new Date(requestedAt)) / 3600000; }
        return null;
      }).filter(value => Number.isFinite(value) && value >= 0);
      const responseTime = responseTimeValues.length > 0 ? responseTimeValues.reduce((sum, value) => sum + value, 0) / responseTimeValues.length : null;

      const complaintValues = numericValues(['complaints', 'complaintCount']);
      const complaints = complaintValues.length > 0 ? complaintValues.reduce((sum, value) => sum + value, 0) : null;

      const metric = new SupplierPerformanceMetric({
        supplierId,
        period: 'monthly',
        periodStart: periodStart.toISOString(),
        periodEnd: periodEnd.toISOString(),
        onTimeDeliveryRate,
        qualityRate,
        fillRate,
        responseTime,
        totalOrders,
        totalValue,
        returns,
        complaints
      });

      metric.calculateScore();
      this.metrics.set(metric.id, metric);
      await this.saveMetric(metric);
      return metric;

    } catch (err) {
      console.error(`Failed to calculate metrics for supplier ${supplierId}:`, err);
    }
  }

  /**
   * Create performance metric
   * @param {object} config - Metric configuration
   * @returns {SupplierPerformanceMetric} - Created metric
   */
  async createMetric(config) {
    const metric = new SupplierPerformanceMetric(config);
    metric.calculateScore();
    this.metrics.set(metric.id, metric);
    await this.saveMetric(metric);
    return metric;
  }

  /**
   * Save metric to storage
   * @param {SupplierPerformanceMetric} metric - Metric to save
   */
  async saveMetric(metric) {
    try {
      await dPut('supplier_performance_metrics', metric);
    } catch (err) {
      console.error('Failed to save performance metric:', err);
    }
  }

  /**
   * Create supplier evaluation
   * @param {object} config - Evaluation configuration
   * @returns {SupplierEvaluation} - Created evaluation
   */
  async createEvaluation(config) {
    const evaluation = new SupplierEvaluation(config);
    
    // Calculate rating from criteria
    const criteriaValues = Object.values(evaluation.criteria);
    evaluation.rating = criteriaValues.length > 0 
      ? criteriaValues.reduce((sum, v) => sum + v, 0) / criteriaValues.length 
      : 0;

    this.evaluations.set(evaluation.id, evaluation);
    await this.saveEvaluation(evaluation);
    return evaluation;
  }

  /**
   * Update evaluation
   * @param {string} id - Evaluation ID
   * @param {object} updates - Updates to apply
   * @returns {SupplierEvaluation} - Updated evaluation
   */
  async updateEvaluation(id, updates) {
    const evaluation = this.evaluations.get(id);
    if (evaluation) {
      Object.assign(evaluation, updates);
      
      // Recalculate rating if criteria changed
      if (updates.criteria) {
        const criteriaValues = Object.values(evaluation.criteria);
        evaluation.rating = criteriaValues.length > 0 
          ? criteriaValues.reduce((sum, v) => sum + v, 0) / criteriaValues.length 
          : 0;
      }

      await this.saveEvaluation(evaluation);
    }
    return evaluation;
  }

  /**
   * Approve evaluation
   * @param {string} id - Evaluation ID
   * @param {string} approvedBy - User who approved
   */
  async approveEvaluation(id, approvedBy) {
    const evaluation = this.evaluations.get(id);
    if (evaluation) {
      evaluation.approved = true;
      evaluation.approvedBy = approvedBy;
      evaluation.approvedAt = new Date().toISOString();
      await this.saveEvaluation(evaluation);
    }
  }

  /**
   * Save evaluation to storage
   * @param {SupplierEvaluation} evaluation - Evaluation to save
   */
  async saveEvaluation(evaluation) {
    try {
      await dPut('supplier_evaluations', evaluation);
    } catch (err) {
      console.error('Failed to save supplier evaluation:', err);
    }
  }

  /**
   * Get metric
   * @param {string} id - Metric ID
   * @returns {SupplierPerformanceMetric} - Metric
   */
  getMetric(id) {
    return this.metrics.get(id);
  }

  /**
   * Get metrics by supplier
   * @param {string} supplierId - Supplier ID
   * @returns {Array} - Metrics
   */
  getMetricsBySupplier(supplierId) {
    return Array.from(this.metrics.values()).filter(m => m.supplierId === supplierId);
  }

  /**
   * Get latest metric for supplier
   * @param {string} supplierId - Supplier ID
   * @returns {SupplierPerformanceMetric|null} - Latest metric
   */
  getLatestMetric(supplierId) {
    const metrics = this.getMetricsBySupplier(supplierId);
    return metrics.sort((a, b) => new Date(b.periodEnd) - new Date(a.periodEnd))[0] || null;
  }

  /**
   * Get evaluation
   * @param {string} id - Evaluation ID
   * @returns {SupplierEvaluation} - Evaluation
   */
  getEvaluation(id) {
    return this.evaluations.get(id);
  }

  /**
   * Get evaluations by supplier
   * @param {string} supplierId - Supplier ID
   * @returns {Array} - Evaluations
   */
  getEvaluationsBySupplier(supplierId) {
    return Array.from(this.evaluations.values()).filter(e => e.supplierId === supplierId);
  }

  /**
   * Get latest evaluation for supplier
   * @param {string} supplierId - Supplier ID
   * @returns {SupplierEvaluation|null} - Latest evaluation
   */
  getLatestEvaluation(supplierId) {
    const evaluations = this.getEvaluationsBySupplier(supplierId);
    return evaluations.sort((a, b) => new Date(b.evaluatedAt) - new Date(a.evaluatedAt))[0] || null;
  }

  /**
   * Get supplier performance summary
   * @param {string} supplierId - Supplier ID
   * @returns {object} - Performance summary
   */
  getPerformanceSummary(supplierId) {
    const latestMetric = this.getLatestMetric(supplierId);
    const latestEvaluation = this.getLatestEvaluation(supplierId);

    return {
      supplierId,
      metric: latestMetric,
      evaluation: latestEvaluation,
      overallScore: latestMetric ? latestMetric.score : 0,
      rating: latestEvaluation ? latestEvaluation.rating : 0,
      recommendation: latestEvaluation ? latestEvaluation.recommendation : 'review'
    };
  }

  /**
   * Get top performing suppliers
   * @param {number} limit - Limit
   * @returns {Array} - Top suppliers
   */
  getTopPerformingSuppliers(limit = 10) {
    const summaries = [];

    if (typeof window !== 'undefined' && window.SupplierDatabase) {
      const suppliers = window.SupplierDatabase.getActiveSuppliers();

      for (const supplier of suppliers) {
        const summary = this.getPerformanceSummary(supplier.id);
        summaries.push({
          supplierId: supplier.id,
          supplierName: supplier.name,
          score: summary.overallScore,
          rating: summary.rating
        });
      }
    }

    return summaries.sort((a, b) => b.score - a.score).slice(0, limit);
  }

  /**
   * Get underperforming suppliers
   * @param {number} threshold - Score threshold
   * @returns {Array} - Underperforming suppliers
   */
  getUnderperformingSuppliers(threshold = 60) {
    const summaries = [];

    if (typeof window !== 'undefined' && window.SupplierDatabase) {
      const suppliers = window.SupplierDatabase.getActiveSuppliers();

      for (const supplier of suppliers) {
        const summary = this.getPerformanceSummary(supplier.id);
        if (summary.overallScore < threshold) {
          summaries.push({
            supplierId: supplier.id,
            supplierName: supplier.name,
            score: summary.overallScore,
            rating: summary.rating
          });
        }
      }
    }

    return summaries.sort((a, b) => a.score - b.score);
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const metrics = Array.from(this.metrics.values());
    const evaluations = Array.from(this.evaluations.values());

    return {
      totalMetrics: metrics.length,
      avgScore: metrics.length > 0 
        ? metrics.reduce((sum, m) => sum + m.score, 0) / metrics.length 
        : 0,
      avgOnTimeDelivery: metrics.length > 0 
        ? metrics.reduce((sum, m) => sum + m.onTimeDeliveryRate, 0) / metrics.length 
        : 0,
      avgQuality: metrics.length > 0 
        ? metrics.reduce((sum, m) => sum + m.qualityRate, 0) / metrics.length 
        : 0,
      avgFillRate: metrics.length > 0 
        ? metrics.reduce((sum, m) => sum + m.fillRate, 0) / metrics.length 
        : 0,
      totalEvaluations: evaluations.length,
      avgRating: evaluations.length > 0 
        ? evaluations.reduce((sum, e) => sum + e.rating, 0) / evaluations.length 
        : 0,
      byRecommendation: this.getRecommendationCounts(evaluations)
    };
  }

  /**
   * Get recommendation counts
   * @param {Array} evaluations - Evaluations
   * @returns {object} - Recommendation counts
   */
  getRecommendationCounts(evaluations) {
    const counts = { continue: 0, review: 0, replace: 0 };
    evaluations.forEach(e => {
      if (counts[e.recommendation] !== undefined) {
        counts[e.recommendation]++;
      }
    });
    return counts;
  }
}

/**
 * Global supplier performance tracking manager instance
 */
const supplierPerformanceTrackingManager = new SupplierPerformanceTrackingManager();

/**
 * Initialize supplier performance tracking
 */
async function initSupplierPerformanceTracking() {
  await supplierPerformanceTrackingManager.init();
  return supplierPerformanceTrackingManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.SupplierPerformanceTracking = {
    manager: supplierPerformanceTrackingManager,
    init: initSupplierPerformanceTracking,
    createMetric: (config) => supplierPerformanceTrackingManager.createMetric(config),
    getMetric: (id) => supplierPerformanceTrackingManager.getMetric(id),
    getMetricsBySupplier: (supplierId) => supplierPerformanceTrackingManager.getMetricsBySupplier(supplierId),
    getLatestMetric: (supplierId) => supplierPerformanceTrackingManager.getLatestMetric(supplierId),
    calculateMetrics: (supplierId) => supplierPerformanceTrackingManager.calculateMetricsForSupplier(supplierId),
    createEvaluation: (config) => supplierPerformanceTrackingManager.createEvaluation(config),
    updateEvaluation: (id, updates) => supplierPerformanceTrackingManager.updateEvaluation(id, updates),
    approveEvaluation: (id, approvedBy) => supplierPerformanceTrackingManager.approveEvaluation(id, approvedBy),
    getEvaluation: (id) => supplierPerformanceTrackingManager.getEvaluation(id),
    getEvaluationsBySupplier: (supplierId) => supplierPerformanceTrackingManager.getEvaluationsBySupplier(supplierId),
    getLatestEvaluation: (supplierId) => supplierPerformanceTrackingManager.getLatestEvaluation(supplierId),
    getPerformanceSummary: (supplierId) => supplierPerformanceTrackingManager.getPerformanceSummary(supplierId),
    getTopPerformingSuppliers: (limit) => supplierPerformanceTrackingManager.getTopPerformingSuppliers(limit),
    getUnderperformingSuppliers: (threshold) => supplierPerformanceTrackingManager.getUnderperformingSuppliers(threshold),
    getStats: () => supplierPerformanceTrackingManager.getStatistics()
  };
}
