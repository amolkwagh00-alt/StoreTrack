// Report Builder Module - Custom report generation and export

function escapeReportHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

function safeReportAlignment(value) {
  return ['left', 'center', 'right'].includes(String(value)) ? String(value) : 'left';
}

function safeReportWidth(value) {
  if (typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 2000) return `${value}px`;
  const text = String(value ?? 'auto');
  return /^(?:auto|\d{1,4}(?:\.\d+)?(?:px|%))$/.test(text) ? text : 'auto';
}

/**
 * Report Builder class for creating custom reports
 */
class ReportBuilder {
  constructor() {
    this.reportConfig = {
      title: '',
      description: '',
      dataSource: '',
      columns: [],
      filters: [],
      sortBy: null,
      sortDirection: 'asc',
      groupBy: null,
      aggregations: []
    };
    this.data = [];
  }

  /**
   * Set report title
   * @param {string} title - Report title
   */
  setTitle(title) {
    this.reportConfig.title = title;
    return this;
  }

  /**
   * Set report description
   * @param {string} description - Report description
   */
  setDescription(description) {
    this.reportConfig.description = description;
    return this;
  }

  /**
   * Set data source
   * @param {string} source - Data source name (e.g., 'materials', 'transactions')
   */
  setDataSource(source) {
    this.reportConfig.dataSource = source;
    return this;
  }

  /**
   * Add column to report
   * @param {string} field - Field name
   * @param {string} label - Column label
   * @param {object} options - Column options (width, align, format)
   */
  addColumn(field, label, options = {}) {
    this.reportConfig.columns.push({
      field,
      label,
      width: options.width || 'auto',
      align: options.align || 'left',
      format: options.format || null,
      visible: options.visible !== false
    });
    return this;
  }

  /**
   * Add filter to report
   * @param {string} field - Field to filter
   * @param {string} operator - Filter operator (eq, neq, contains, gt, lt, etc.)
   * @param {any} value - Filter value
   */
  addFilter(field, operator, value) {
    this.reportConfig.filters.push({ field, operator, value });
    return this;
  }

  /**
   * Set sort order
   * @param {string} field - Field to sort by
   * @param {string} direction - Sort direction ('asc' or 'desc')
   */
  setSort(field, direction = 'asc') {
    this.reportConfig.sortBy = field;
    this.reportConfig.sortDirection = direction;
    return this;
  }

  /**
   * Set grouping
   * @param {string} field - Field to group by
   */
  setGroupBy(field) {
    this.reportConfig.groupBy = field;
    return this;
  }

  /**
   * Add aggregation
   * @param {string} field - Field to aggregate
   * @param {string} operation - Aggregation operation (sum, avg, count, min, max)
   * @param {string} label - Result label
   */
  addAggregation(field, operation, label) {
    this.reportConfig.aggregations.push({ field, operation, label });
    return this;
  }

  /**
   * Load data from IndexedDB
   * @returns {Promise<Array>} - Loaded data
   */
  async loadData() {
    // This would use the database module
    // For now, return empty array
    try {
      if (typeof gAll === 'function') {
        this.data = await gAll(this.reportConfig.dataSource);
      }
    } catch (err) {
      console.error('Failed to load report data:', err);
      this.data = [];
    }
    return this.data;
  }

  /**
   * Apply filters to data
   * @returns {Array} - Filtered data
   */
  applyFilters() {
    let filtered = [...this.data];
    
    this.reportConfig.filters.forEach(filter => {
      filtered = filtered.filter(item => {
        const value = item[filter.field];
        
        switch (filter.operator) {
          case 'eq':
            return value === filter.value;
          case 'neq':
            return value !== filter.value;
          case 'contains':
            return String(value).toLowerCase().includes(String(filter.value).toLowerCase());
          case 'gt':
            return value > filter.value;
          case 'lt':
            return value < filter.value;
          case 'gte':
            return value >= filter.value;
          case 'lte':
            {
              const comparison = typeof filter.value === 'string' && Object.prototype.hasOwnProperty.call(item, filter.value)
                ? item[filter.value]
                : filter.value;
              return Number.isFinite(Number(value)) && Number.isFinite(Number(comparison)) && Number(value) <= Number(comparison);
            }
          default:
            return true;
        }
      });
    });
    
    return filtered;
  }

  /**
   * Apply sorting to data
   * @param {Array} data - Data to sort
   * @returns {Array} - Sorted data
   */
  applySort(data) {
    if (!this.reportConfig.sortBy) {return data;}
    
    const { sortBy, sortDirection } = this.reportConfig;
    
    return [...data].sort((a, b) => {
      let aVal = a[sortBy];
      let bVal = b[sortBy];
      
      if (aVal == null) {return 1;}
      if (bVal == null) {return -1;}
      
      if (typeof aVal === 'string') {aVal = aVal.toLowerCase();}
      if (typeof bVal === 'string') {bVal = bVal.toLowerCase();}
      
      if (aVal < bVal) {return sortDirection === 'asc' ? -1 : 1;}
      if (aVal > bVal) {return sortDirection === 'asc' ? 1 : -1;}
      return 0;
    });
  }

  /**
   * Apply grouping to data
   * @param {Array} data - Data to group
   * @returns {Array} - Grouped data
   */
  applyGrouping(data) {
    if (!this.reportConfig.groupBy) {return [{ group: 'All', data }];}
    
    const groups = {};
    
    data.forEach(item => {
      const groupKey = item[this.reportConfig.groupBy] || 'Uncategorized';
      if (!groups[groupKey]) {
        groups[groupKey] = [];
      }
      groups[groupKey].push(item);
    });
    
    return Object.keys(groups).map(key => ({
      group: key,
      data: groups[key]
    }));
  }

  /**
   * Apply aggregations to data
   * @param {Array} data - Data to aggregate
   * @returns {object} - Aggregation results
   */
  applyAggregations(data) {
    const results = {};
    
    this.reportConfig.aggregations.forEach(agg => {
      const values = data.map(item => item[agg.field]).filter(v => v != null && !isNaN(v));
      
      switch (agg.operation) {
        case 'sum':
          results[agg.label] = values.reduce((sum, v) => sum + v, 0);
          break;
        case 'avg':
          results[agg.label] = values.length > 0 ? values.reduce((sum, v) => sum + v, 0) / values.length : 0;
          break;
        case 'count':
          results[agg.label] = values.length;
          break;
        case 'min':
          results[agg.label] = values.length > 0 ? Math.min(...values) : 0;
          break;
        case 'max':
          results[agg.label] = values.length > 0 ? Math.max(...values) : 0;
          break;
      }
    });
    
    return results;
  }

  /**
   * Generate report
   * @returns {Promise<object>} - Generated report
   */
  async generate() {
    await this.loadData();
    const filtered = this.applyFilters();
    const sorted = this.applySort(filtered);
    const grouped = this.applyGrouping(sorted);
    
    const report = {
      config: { ...this.reportConfig },
      generatedAt: new Date().toISOString(),
      totalRecords: filtered.length,
      groups: grouped.map(group => ({
        name: group.group,
        data: group.data,
        aggregations: this.applyAggregations(group.data)
      })),
      overallAggregations: this.applyAggregations(filtered)
    };
    
    return report;
  }

  /**
   * Export report to CSV
   * @param {object} report - Report object
   * @returns {string} - CSV string
   */
  exportToCSV(report) {
    const headers = report.config.columns.map(col => col.label).join(',');
    const rows = [];
    
    report.groups.forEach(group => {
      if (report.config.groupBy) {
        rows.push([`Group: ${group.name}`].join(','));
      }
      
      group.data.forEach(item => {
        const row = report.config.columns.map(col => {
          let value = item[col.field];
          if (col.format && typeof col.format === 'function') {
            value = col.format(value);
          }
          return `"${String(value || '').replace(/"/g, '""')}"`;
        });
        rows.push(row.join(','));
      });
      
      if (report.config.aggregations.length > 0) {
        const aggRow = report.config.aggregations.map(agg => 
          group.aggregations[agg.label] || ''
        );
        rows.push(['Totals:', ...aggRow].join(','));
      }
    });
    
    return [headers, ...rows].join('\n');
  }

  /**
   * Export report to HTML
   * @param {object} report - Report object
   * @returns {string} - HTML string
   */
  exportToHTML(report) {
    let html = `
      <div class="report-container">
        <div class="report-header">
          <h1>${escapeReportHtml(report.config.title)}</h1>
          <p class="report-description">${escapeReportHtml(report.config.description || '')}</p>
          <p class="report-meta">Generated: ${escapeReportHtml(new Date(report.generatedAt).toLocaleString())}</p>
          <p class="report-meta">Total Records: ${escapeReportHtml(report.totalRecords)}</p>
        </div>
    `;
    
    report.groups.forEach(group => {
      html += `
        <div class="report-group">
          ${report.config.groupBy ? `<h2 class="group-title">${escapeReportHtml(group.name)}</h2>` : ''}
          <table class="report-table">
            <thead>
              <tr>
                ${report.config.columns.map(col => 
                  `<th data-style="text-align: ${safeReportAlignment(col.align)}; width: ${safeReportWidth(col.width)}">${escapeReportHtml(col.label)}</th>`
                ).join('')}
              </tr>
            </thead>
            <tbody>
              ${group.data.map(item => `
                <tr>
                  ${report.config.columns.map(col => {
                    let value = item[col.field];
                    if (col.format && typeof col.format === 'function') {
                      value = col.format(value);
                    }
                    return `<td data-style="text-align: ${safeReportAlignment(col.align)}">${escapeReportHtml(value)}</td>`;
                  }).join('')}
                </tr>
              `).join('')}
            </tbody>
          </table>
          ${report.config.aggregations.length > 0 ? `
            <div class="report-aggregations">
              <strong>Aggregations:</strong>
              ${report.config.aggregations.map(agg => 
                `<span>${escapeReportHtml(agg.label)}: ${escapeReportHtml(group.aggregations[agg.label] ?? 0)}</span>`
              ).join(' | ')}
            </div>
          ` : ''}
        </div>
      `;
    });
    
    html += '</div>';
    return html;
  }

  /**
   * Reset report configuration
   */
  reset() {
    this.reportConfig = {
      title: '',
      description: '',
      dataSource: '',
      columns: [],
      filters: [],
      sortBy: null,
      sortDirection: 'asc',
      groupBy: null,
      aggregations: []
    };
    this.data = [];
  }
}

/**
 * Pre-defined report templates
 */
const REPORT_TEMPLATES = {
  inventorySummary: {
    title: 'Inventory Summary',
    dataSource: 'materials',
    columns: [
      { field: 'barcode', label: 'Barcode' },
      { field: 'name', label: 'Name' },
      { field: 'category', label: 'Category' },
      { field: 'currentStock', label: 'Current Stock', format: v => Number(v).toLocaleString() },
      { field: 'unit', label: 'Unit' },
      { field: 'minStock', label: 'Min Stock' }
    ],
    aggregations: [
      { field: 'currentStock', operation: 'sum', label: 'Total Stock' },
      { field: 'currentStock', operation: 'count', label: 'Total Items' }
    ]
  },
  transactionLog: {
    title: 'Transaction Log',
    dataSource: 'transactions',
    columns: [
      { field: 'time', label: 'Date/Time', format: v => new Date(v).toLocaleString() },
      { field: 'barcode', label: 'Barcode' },
      { field: 'itemName', label: 'Item Name' },
      { field: 'type', label: 'Type' },
      { field: 'quantity', label: 'Quantity' },
      { field: 'user', label: 'User' }
    ],
    sortBy: 'time',
    sortDirection: 'desc'
  },
  lowStockReport: {
    title: 'Low Stock Report',
    dataSource: 'materials',
    columns: [
      { field: 'barcode', label: 'Barcode' },
      { field: 'name', label: 'Name' },
      { field: 'category', label: 'Category' },
      { field: 'currentStock', label: 'Current Stock' },
      { field: 'minStock', label: 'Min Stock' },
      { field: 'maxStock', label: 'Max Stock' }
    ],
    filters: [
      { field: 'currentStock', operator: 'lte', value: 'minStock' }
    ],
    sortBy: 'currentStock',
    sortDirection: 'asc'
  }
};

/**
 * Create report from template
 * @param {string} templateName - Template name
 * @returns {ReportBuilder} - Report builder instance
 */
function createFromTemplate(templateName) {
  const template = REPORT_TEMPLATES[templateName];
  if (!template) {
    throw new Error(`Template "${templateName}" not found`);
  }
  
  const builder = new ReportBuilder();
  builder.setTitle(template.title);
  builder.setDataSource(template.dataSource);
  
  template.columns.forEach(col => {
    builder.addColumn(col.field, col.label, col);
  });
  
  if (template.filters) {
    template.filters.forEach(filter => {
      builder.addFilter(filter.field, filter.operator, filter.value);
    });
  }
  
  if (template.sortBy) {
    builder.setSort(template.sortBy, template.sortDirection);
  }
  
  if (template.aggregations) {
    template.aggregations.forEach(agg => {
      builder.addAggregation(agg.field, agg.operation, agg.label);
    });
  }
  
  return builder;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.ReportBuilder = {
    ReportBuilder,
    TEMPLATES: REPORT_TEMPLATES,
    createFromTemplate
  };
}
