// Dashboard Widgets Module - Customizable dashboard widgets

/**
 * Widget Manager class
 */
class WidgetManager {
  constructor() {
    this.widgets = new Map();
    this.widgetConfigs = new Map();
    this.widgetOrder = [];
    this.activeUserScope = null;
    this.refreshInterval = null;
    this._refreshInFlight = false;
    this._widgetLastRefresh = new Map();
    this._configReady = this.loadWidgetConfigs();
    this.init();
  }

  /**
   * Initialize widget manager
   */
  init() {
    this.setupDragAndDrop();
    this.setupWidgetControls();
  }

  /**
   * Load widget configurations from storage
   */
  getUserScope() {
    if (this.activeUserScope !== null) return this.activeUserScope;
    const id = typeof window !== 'undefined' ? window.currentUser?.id : null;
    return id !== undefined && id !== null && String(id).trim() !== '' ? String(id) : '__anonymous__';
  }

  async loadWidgetConfigs(scope = this.getUserScope()) {
    try {
      const configs = await gAll('widget_configs');
      // Legacy rows without a userId are only visible to the anonymous scope.
      const ownConfigs = Array.isArray(configs) ? configs.filter(config =>
        (config.userId != null ? String(config.userId) : '__anonymous__') === scope
      ) : [];
      this.widgetConfigs.clear();
      this.widgetOrder = [];
      if (!ownConfigs.length) { this.setDefaultWidgets(); if (scope !== '__anonymous__') await this.saveWidgetConfigs(); return; }
      ownConfigs.slice().sort((a, b) => Number(a.position ?? 0) - Number(b.position ?? 0)).forEach(config => {
        this.widgetConfigs.set(config.id, config);
        if (config.visible !== false) {
          if (!this.widgetOrder.includes(config.id)) this.widgetOrder.push(config.id);
        }
      });
    } catch (err) {
      console.error('Failed to load widget configs:', err);
      this.setDefaultWidgets();
    }
  }

  /** Switch the active layout scope after authentication changes. */
  async switchUser(userId) {
    await this._configReady;
    this.stopAutoRefresh();
    this.activeUserScope = userId !== undefined && userId !== null && String(userId).trim() !== ''
      ? String(userId) : '__anonymous__';
    await this.loadWidgetConfigs(this.activeUserScope);
    if (document.querySelector('.dashboard-widgets')) {
      await this.renderWidgets();
      this.startAutoRefresh();
    }
    return this.activeUserScope;
  }

  /**
   * Set default widgets
   */
  setDefaultWidgets() {
    const defaults = [
      { id: 'total-materials', title: 'Total Materials', type: 'metric', visible: true, position: 0 },
      { id: 'low-stock', title: 'Low Stock Items', type: 'metric', visible: true, position: 1 },
      { id: 'today-transactions', title: 'Today\'s Transactions', type: 'metric', visible: true, position: 2 },
      { id: 'stock-value', title: 'Stock Value', type: 'metric', visible: true, position: 3 },
      { id: 'recent-activity', title: 'Recent Activity', type: 'list', visible: true, position: 4 },
      { id: 'stock-by-category', title: 'Stock by Category', type: 'chart', visible: true, position: 5 }
    ];
    
    defaults.forEach(config => {
      this.widgetConfigs.set(config.id, config);
      this.widgetOrder.push(config.id);
    });
  }

  /**
   * Save widget configurations to storage
   */
  async saveWidgetConfigs() {
    try {
      const scope = this.getUserScope();
      const existing = await gAll('widget_configs');
      const preserved = (Array.isArray(existing) ? existing : []).filter(config =>
        (config.userId != null ? String(config.userId) : '__anonymous__') !== scope
      );
      const configs = Array.from(this.widgetConfigs.values()).map(config => ({ ...config, userId: scope === '__anonymous__' ? null : scope }));
      await batchPut('widget_configs', [...preserved, ...configs]);
    } catch (err) {
      console.error('Failed to save widget configs:', err);
    }
  }

  /**
   * Register a widget
   * @param {string} id - Widget ID
   * @param {object} config - Widget configuration
   */
  registerWidget(id, config) {
    this.widgetConfigs.set(id, {
      id,
      title: config.title || 'Widget',
      type: config.type || 'metric',
      visible: config.visible !== false,
      position: config.position || this.widgetOrder.length,
      size: config.size || 'medium',
      ...config,
      refreshInterval: this.normalizeRefreshInterval(config.refreshInterval)
    });
    
    if (config.visible !== false && !this.widgetOrder.includes(id)) {
      this.widgetOrder.push(id);
    }
  }

  /**
   * Unregister a widget
   * @param {string} id - Widget ID
   */
  unregisterWidget(id) {
    this.widgetConfigs.delete(id);
    this.widgetOrder = this.widgetOrder.filter(w => w !== id);
  }

  normalizeRefreshInterval(interval) {
    const value = Number(interval);
    if (!Number.isFinite(value) || value <= 0) { return 60000; }
    return Math.min(300000, Math.max(60000, value));
  }

  /**
   * Get widget configuration
   * @param {string} id - Widget ID
   * @returns {object} - Widget configuration
   */
  getWidgetConfig(id) {
    return this.widgetConfigs.get(id);
  }

  /**
   * Update widget configuration
   * @param {string} id - Widget ID
   * @param {object} updates - Configuration updates
   */
  updateWidgetConfig(id, updates) {
    const config = this.widgetConfigs.get(id);
    if (config) {
      this.widgetConfigs.set(id, { ...config, ...updates });
      this.saveWidgetConfigs();
    }
  }

  /**
   * Show widget
   * @param {string} id - Widget ID
   */
  showWidget(id) {
    const config = this.widgetConfigs.get(id);
    if (config) {
      config.visible = true;
      if (!this.widgetOrder.includes(id)) {
        this.widgetOrder.push(id);
      }
      this.saveWidgetConfigs();
    }
  }

  /**
   * Hide widget
   * @param {string} id - Widget ID
   */
  hideWidget(id) {
    const config = this.widgetConfigs.get(id);
    if (config) {
      config.visible = false;
      this.widgetOrder = this.widgetOrder.filter(w => w !== id);
      this.saveWidgetConfigs();
    }
  }

  /**
   * Move widget to new position
   * @param {string} id - Widget ID
   * @param {number} newPosition - New position index
   */
  moveWidget(id, newPosition) {
    const currentIndex = this.widgetOrder.indexOf(id);
    if (currentIndex !== -1) {
      this.widgetOrder.splice(currentIndex, 1);
      this.widgetOrder.splice(newPosition, 0, id);
      
      // Update positions
      this.widgetOrder.forEach((widgetId, index) => {
        const config = this.widgetConfigs.get(widgetId);
        if (config) {
          config.position = index;
        }
      });
      
      this.saveWidgetConfigs();
    }
  }

  /**
   * Get visible widgets in order
   * @returns {Array} - Ordered widget configurations
   */
  getVisibleWidgets() {
    return this.widgetOrder
      .map(id => this.widgetConfigs.get(id))
      .filter(config => config && config.visible !== false);
  }

  /**
   * Setup drag and drop for widgets
   */
  setupDragAndDrop() {
    const dashboard = document.querySelector('.dashboard-widgets');
    if (!dashboard) {return;}

    let draggedItem = null;

    dashboard.addEventListener('dragstart', (e) => {
      if (e.target.classList.contains('widget')) {
        draggedItem = e.target;
        e.target.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
      }
    });

    dashboard.addEventListener('dragend', (e) => {
      if (e.target.classList.contains('widget')) {
        e.target.classList.remove('dragging');
        draggedItem = null;
      }
    });

    dashboard.addEventListener('dragover', (e) => {
      e.preventDefault();
      const afterElement = this.getDragAfterElement(dashboard, e.clientY);
      if (draggedItem) {
        if (afterElement == null) {
          dashboard.appendChild(draggedItem);
        } else {
          dashboard.insertBefore(draggedItem, afterElement);
        }
      }
    });

    dashboard.addEventListener('drop', (e) => {
      e.preventDefault();
      this.updateWidgetOrderFromDOM();
    });
  }

  /**
   * Get element after drag position
   * @param {HTMLElement} container - Container element
   * @param {number} y - Y coordinate
   * @returns {HTMLElement} - Element after position
   */
  getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('.widget:not(.dragging)')];

    return draggableElements.reduce((closest, child) => {
      const box = child.getBoundingClientRect();
      const offset = y - box.top - box.height / 2;
      
      if (offset < 0 && offset > closest.offset) {
        return { offset: offset, element: child };
      } else {
        return closest;
      }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
  }

  /**
   * Update widget order from DOM
   */
  updateWidgetOrderFromDOM() {
    const dashboard = document.querySelector('.dashboard-widgets');
    if (!dashboard) {return;}

    const widgets = dashboard.querySelectorAll('.widget');
    this.widgetOrder = Array.from(widgets).map(w => w.dataset.widgetId);
    
    this.widgetOrder.forEach((id, index) => {
      const config = this.widgetConfigs.get(id);
      if (config) {
        config.position = index;
      }
    });
    
    this.saveWidgetConfigs();
  }

  /**
   * Setup widget controls (edit, remove, resize)
   */
  setupWidgetControls() {
    document.addEventListener('click', (e) => {
      if (e.target.closest('.widget-remove')) {
        const widgetId = e.target.closest('.widget').dataset.widgetId;
        this.hideWidget(widgetId);
        this.renderWidgets();
      }
      
      if (e.target.closest('.widget-edit')) {
        const widgetId = e.target.closest('.widget').dataset.widgetId;
        this.openWidgetSettings(widgetId);
      }
      
      if (e.target.closest('.widget-resize')) {
        const widgetId = e.target.closest('.widget').dataset.widgetId;
        this.cycleWidgetSize(widgetId);
      }
      if (e.target.closest('.widget-move-up, .widget-move-down')) {
        const button = e.target.closest('.widget-move-up, .widget-move-down');
        const widgetId = button.closest('.widget').dataset.widgetId;
        const currentIndex = this.widgetOrder.indexOf(widgetId);
        const targetIndex = currentIndex + (button.classList.contains('widget-move-up') ? -1 : 1);
        if (currentIndex !== -1 && targetIndex >= 0 && targetIndex < this.widgetOrder.length) {
          this.moveWidget(widgetId, targetIndex);
          this.renderWidgets();
        }
      }
    });
  }

  /**
   * Open widget settings modal
   * @param {string} id - Widget ID
   */
  openWidgetSettings(id) {
    const config = this.widgetConfigs.get(id);
    if (!config) {return;}

    // Create settings modal
    const modal = document.createElement('div');
    modal.className = 'modal widget-settings-modal';
    modal.innerHTML = `
      <div class="modal-content" role="dialog" aria-modal="true" aria-labelledby="widget-settings-heading" aria-describedby="widget-settings-help">
        <h2 id="widget-settings-heading">Widget Settings: ${config.title}</h2>
        <p id="widget-settings-help" class="sr-only">Change the title, size, or refresh interval for this dashboard widget.</p>
        <div class="form-group">
          <label for="widget-title">Title</label>
          <input type="text" id="widget-title" value="${config.title}">
        </div>
        <div class="form-group">
          <label for="widget-size">Size</label>
          <select id="widget-size">
            <option value="small" ${config.size === 'small' ? 'selected' : ''}>Small</option>
            <option value="medium" ${config.size === 'medium' ? 'selected' : ''}>Medium</option>
            <option value="large" ${config.size === 'large' ? 'selected' : ''}>Large</option>
          </select>
        </div>
        <div class="form-group">
          <label for="widget-refresh">Refresh Interval (seconds)</label>
          <input type="number" id="widget-refresh" value="${config.refreshInterval / 1000}">
        </div>
        <div class="modal-actions">
          <button class="btn btn-cancel">Cancel</button>
          <button class="btn btn-primary">Save</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);

    const heading = modal.querySelector('#widget-settings-heading');
    if (heading) heading.textContent = `Widget Settings: ${String(config.title || 'Widget')}`;
    const close = () => { modal.remove(); document.dispatchEvent(new CustomEvent('modal-closed')); };
    
    modal.querySelector('.btn-cancel').addEventListener('click', () => {
      close();
    });
    
    modal.querySelector('.btn-primary').addEventListener('click', () => {
      const title = document.getElementById('widget-title').value;
      const size = document.getElementById('widget-size').value;
      const refreshInterval = parseInt(document.getElementById('widget-refresh').value) * 1000;
      
      this.updateWidgetConfig(id, { title, size, refreshInterval });
      this.renderWidgets();
      close();
    });
  }

  /**
   * Cycle widget size
   * @param {string} id - Widget ID
   */
  cycleWidgetSize(id) {
    const config = this.widgetConfigs.get(id);
    if (!config) {return;}

    const sizes = ['small', 'medium', 'large'];
    const currentIndex = sizes.indexOf(config.size);
    const nextIndex = (currentIndex + 1) % sizes.length;
    
    this.updateWidgetConfig(id, { size: sizes[nextIndex] });
    this.renderWidgets();
  }

  /**
   * Render all widgets
   */
  async renderWidgets() {
    const dashboard = document.querySelector('.dashboard-widgets');
    if (!dashboard) {return;}

    this.destroyDashboardCharts();
    dashboard.innerHTML = '';
    
    const widgets = this.getVisibleWidgets();
    
    for (const config of widgets) {
      const widget = await this.renderWidget(config);
      if (widget) {
        dashboard.appendChild(widget);
      }
    }
  }

  /** Destroy chart instances before rerender removes their canvases. */
  destroyDashboardCharts() {
    const chartManager = window.Charts?.manager;
    if (!chartManager?.getChart || !chartManager.removeChart) { return; }
    this.widgetConfigs.forEach((config, id) => {
      if (config.type === 'chart' && chartManager.getChart(id)) { chartManager.removeChart(id); }
    });
  }

  /**
   * Render a single widget
   * @param {object} config - Widget configuration
   * @returns {Promise<HTMLElement>} - Widget element
   */
  getWidgetIcon(id) {
    const icons = {
      'total-materials': { name: 'materials', paths: '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="m4.5 7.7 7.5 4.2 7.5-4.2M12 12v9"/><path d="m8 5.2 8 4.5"/>' },
      'low-stock': { name: 'low-stock', paths: '<path d="M12 3 22 20H2L12 3Z"/><path d="M12 9v4M12 17h.01"/>' },
      'today-transactions': { name: 'transactions', paths: '<path d="M4 7h15l-3-3M20 17H5l3 3"/><path d="M19 7a8 8 0 0 1-14 5M5 17a8 8 0 0 0 14-5"/>' },
      'stock-value': { name: 'value', paths: '<circle cx="12" cy="12" r="8.5"/><path d="M8.5 9.5h7M8.5 12.5h7M9.5 15.5h5"/>' },
      'recent-activity': { name: 'activity', paths: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/>' },
      'stock-by-category': { name: 'category', paths: '<path d="M4 20h16M7 16v-5M12 16V5M17 16V9"/>' },
      default: { name: 'default', paths: '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>' }
    };
    const icon = Object.hasOwn(icons, id) ? icons[id] : icons.default;
    return `<svg class="widget-icon widget-icon-${icon.name}" data-widget-icon="${icon.name}" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icon.paths}</svg>`;
  }

  getControlIcon(name) {
    const icons = {
      resize: '<path d="M8 3H3v5M3 3l7 7M16 21h5v-5M21 21l-7-7"/>',
      edit: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
      remove: '<path d="m6 6 12 12M18 6 6 18"/>'
    };
    const paths = Object.hasOwn(icons, name) ? icons[name] : '';
    return `<svg class="widget-control-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
  }

  async renderWidget(config) {
    const widget = document.createElement('div');
    const size = ['small', 'medium', 'large'].includes(config.size) ? config.size : 'medium';
    widget.className = `widget widget-${size}`;
    widget.dataset.widgetId = config.id;
    widget.draggable = true;
    
    const content = await this.getWidgetContent(config);
    
    widget.innerHTML = `
      <div class="widget-header">
        <div class="widget-heading">
          ${this.getWidgetIcon(config.id)}
          <h3 class="widget-title"></h3>
        </div>
        <div class="widget-controls">
          <button type="button" class="widget-resize" aria-label="Change widget size" title="Change widget size">${this.getControlIcon('resize')}</button>
          <button type="button" class="widget-edit" aria-label="Edit widget settings" title="Edit widget settings">${this.getControlIcon('edit')}</button>
          <button type="button" class="widget-remove" aria-label="Remove widget" title="Remove widget">${this.getControlIcon('remove')}</button>
          <button type="button" class="widget-move-up" aria-label="Move ${config.title} up" title="Move up">Move up</button>
          <button type="button" class="widget-move-down" aria-label="Move ${config.title} down" title="Move down">Move down</button>
        </div>
      </div>
      <div class="widget-content">
        ${content}
      </div>
    `;

    const title = widget.querySelector('.widget-title');
    if (title) { title.textContent = String(config.title || 'Widget'); }
    
    return widget;
  }

  /**
   * Get widget content based on type
   * @param {object} config - Widget configuration
   * @returns {Promise<string>} - Widget HTML content
   */
  async getWidgetContent(config) {
    switch (config.type) {
      case 'metric':
        return await this.getMetricContent(config);
      case 'list':
        return await this.getListContent(config);
      case 'chart':
        return await this.getChartContent(config);
      default:
        return '<p>Unknown widget type</p>';
    }
  }

  /**
   * Get metric widget content
   * @param {object} config - Widget configuration
   * @returns {Promise<string>} - Widget HTML
   */
  async getMetricContent(config) {
    let value = 0;
    let label = '';
    
    try {
      switch (config.id) {
        case 'total-materials':
          const materials = await gAll('materials');
          value = materials.length;
          label = 'Materials';
          break;
        case 'low-stock':
          const allMaterials = await gAll('materials');
          value = allMaterials.filter(m => { const stock = Number(m.stock ?? m.currentStock ?? 0); const target = Number(m.lowAlert ?? m.minStock ?? 0); return stock === 0 || stock < target; }).length;
          label = 'Low Stock';
          break;
        case 'today-transactions':
          const transactions = await gAll('transactions');
          const today = new Date().toDateString();
          value = transactions.filter(t => t && t.status === 'confirmed' && ['IN','OUT'].includes(t.type) && new Date(t.time).toDateString() === today).length;
          label = 'Transactions';
          break;
        case 'stock-value':
          const stockMaterials = await gAll('materials');
          value = stockMaterials.reduce((sum, m) => sum + Number(m.stock ?? m.currentStock ?? 0) * Number(m.unitCost ?? m.unitPrice ?? m.price ?? m.rate ?? 0), 0);
          label = 'Value';
          break;
        default:
          value = 0;
          label = 'Items';
      }
    } catch (err) {
      console.error('Failed to get widget data:', err);
    }
    
    return `
      <div class="metric-value">${value.toLocaleString()}</div>
      <div class="metric-label">${label}</div>
    `;
  }

  /**
   * Get list widget content
   * @param {object} config - Widget configuration
   * @returns {Promise<string>} - Widget HTML
   */
  async getListContent(config) {
    let items = [];
    
    try {
      switch (config.id) {
        case 'recent-activity':
          const transactions = await gAll('transactions');
          items = transactions.filter(t => t && t.status === 'confirmed' && ['IN','OUT'].includes(t.type)).slice().sort((a,b)=>new Date(b.time)-new Date(a.time)).slice(0,5).map(t => ({
            text: `${t.type}: ${String(t.itemName||'Unknown item')}`,
            time: new Date(t.time).toLocaleTimeString()
          }));
          break;
        default:
          items = [];
      }
    } catch (err) {
      console.error('Failed to get widget data:', err);
    }
    
    if (items.length === 0) {
      return '<p class="no-data">No data available</p>';
    }
    
    return `
      <ul class="widget-list">
        ${items.map(item => `
          <li>
            <span class="item-text">${item.text}</span>
            <span class="item-time">${item.time}</span>
          </li>
        `).join('')}
      </ul>
    `;
  }

  /**
   * Get chart widget content
   * @param {object} config - Widget configuration
   * @returns {Promise<string>} - Widget HTML
   */
  async getChartContent(config) {
    const canvasId = `chart-${config.id}`;
    return `<canvas id="${canvasId}" width="300" height="200"></canvas>`;
  }

  /**
   * Refresh widget data
   * @param {string} id - Widget ID
   */
  async refreshWidget(id) {
    const config = this.widgetConfigs.get(id);
    if (config) {
      const widget = document.querySelector(`.widget[data-widget-id="${id}"]`);
      if (widget) {
        const content = widget.querySelector('.widget-content');
        if (content) {
          content.innerHTML = await this.getWidgetContent(config);
          if (config.type === 'chart' && window.Charts?.createFromConfig) {
            const chartManager = window.Charts.manager;
            if (chartManager?.getChart?.(id)) { chartManager.removeChart(id); }
            const chartConfig = {
              type: config.chartType || 'bar',
              dataSource: config.dataSource || 'materials',
              groupBy: config.groupBy || 'category',
              aggregate: config.aggregate || 'sum',
              field: config.field || 'stock',
              options: { width: 300, height: 200 },
            };
            await window.Charts.createFromConfig(id, `chart-${config.id}`, chartConfig);
          }
        }
      }
    }
  }

  /**
   * Refresh all widgets
   */
  async refreshAllWidgets() {
    if (this._refreshInFlight) { return; }
    this._refreshInFlight = true;
    try {
      for (const config of this.getVisibleWidgets()) {
        if (!document.querySelector(`.widget[data-widget-id="${config.id}"]`)) { continue; }
        await this.refreshWidget(config.id);
        this._widgetLastRefresh.set(config.id, Date.now());
      }
    } finally {
      this._refreshInFlight = false;
    }
  }

  /**
   * Start auto-refresh for widgets
   */
  startAutoRefresh() {
    this.stopAutoRefresh();
    const now = Date.now();
    for (const config of this.getVisibleWidgets()) { this._widgetLastRefresh.set(config.id, now); }
    this.refreshInterval = setInterval(async () => {
      if (this._refreshInFlight) { return; }
      const now = Date.now();
      const due = this.getVisibleWidgets().filter(config =>
        now - (this._widgetLastRefresh.get(config.id) || 0) >= this.normalizeRefreshInterval(config.refreshInterval) &&
        Boolean(document.querySelector(`.widget[data-widget-id="${config.id}"]`))
      );
      if (!due.length) { return; }
      this._refreshInFlight = true;
      try {
        for (const config of due) {
          if (config.visible === false || !this.widgetConfigs.has(config.id) ||
              !document.querySelector(`.widget[data-widget-id="${config.id}"]`)) { continue; }
          await this.refreshWidget(config.id);
          this._widgetLastRefresh.set(config.id, Date.now());
        }
      } finally {
        this._refreshInFlight = false;
      }
    }, 60000);
  }

  /**
   * Stop auto-refresh
   */
  stopAutoRefresh() {
    if (this.refreshInterval !== null) {
      clearInterval(this.refreshInterval);
      this.refreshInterval = null;
    }
  }
}

/**
 * Global widget manager instance
 */
const widgetManager = new WidgetManager();

/**
 * Initialize dashboard widgets
 */
async function initDashboardWidgets() {
  await widgetManager._configReady;
  await widgetManager.renderWidgets();
  widgetManager.startAutoRefresh();
  return widgetManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.DashboardWidgets = {
    manager: widgetManager,
    init: initDashboardWidgets,
    setUser: (userId) => widgetManager.switchUser(userId),
    register: (id, config) => widgetManager.registerWidget(id, config),
    show: (id) => widgetManager.showWidget(id),
    hide: (id) => widgetManager.hideWidget(id),
    move: (id, pos) => widgetManager.moveWidget(id, pos),
    refresh: (id) => widgetManager.refreshWidget(id),
    refreshAll: () => widgetManager.refreshAllWidgets()
  };
}
