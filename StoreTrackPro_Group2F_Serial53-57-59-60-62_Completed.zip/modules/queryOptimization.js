// Database Query Optimization Module - Optimized database queries

/**
 * Query Plan class
 */
class QueryPlan {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.name = config.name || 'Query Plan';
    this.storeName = config.storeName || '';
    this.indexes = config.indexes || [];
    this.filters = config.filters || [];
    this.sorting = config.sorting || [];
    this.estimatedCost = config.estimatedCost || 0;
    this.actualCost = config.actualCost || 0;
    this.executionTime = config.executionTime || 0;
    this.rowCount = config.rowCount || 0;
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `query-plan-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Query Cache Entry class
 */
class QueryCacheEntry {
  constructor(config) {
    this.key = config.key || '';
    this.storeName = config.storeName || '';
    this.query = config.query || {};
    this.result = config.result || null;
    this.hitCount = config.hitCount || 0;
    this.lastAccessed = config.lastAccessed || new Date().toISOString();
    this.createdAt = config.createdAt || new Date().toISOString();
    this.expiresAt = config.expiresAt || null;
  }

  /**
   * Check if expired
   * @returns {boolean} - Is expired
   */
  isExpired() {
    if (!this.expiresAt) {return false;}
    return new Date() >= new Date(this.expiresAt);
  }

  /**
   * Record access
   */
  recordAccess() {
    this.hitCount++;
    this.lastAccessed = new Date().toISOString();
  }
}

/**
 * Query Optimization Manager
 */
class QueryOptimizationManager {
  constructor() {
    this.queryPlans = new Map();
    this.queryCache = new Map();
    this.indexHints = new Map();
    this.cacheEnabled = true;
    this.cacheMaxSize = 1000;
    this.cacheDefaultTTL = 300000; // 5 minutes
    this.init();
  }

  /**
   * Initialize query optimization manager
   */
  async init() {
    await this.loadQueryPlans();
    await this.loadIndexHints();
    this.startCacheCleanup();
  }

  /**
   * Load query plans from storage
   */
  async loadQueryPlans() {
    try {
      const plans = await gAll('query_plans');
      plans.forEach(p => {
        this.queryPlans.set(p.id, new QueryPlan(p));
      });
    } catch (err) {
      console.error('Failed to load query plans:', err);
    }
  }

  /**
   * Load index hints from storage
   */
  async loadIndexHints() {
    try {
      const hints = await gAll('index_hints');
      hints.forEach(h => {
        this.indexHints.set(h.storeName, h.indexes);
      });
    } catch (err) {
      console.error('Failed to load index hints:', err);
    }
  }

  /**
   * Start cache cleanup
   */
  startCacheCleanup() {
    setInterval(() => {
      this.cleanupCache();
    }, 60000); // Cleanup every minute
  }

  /**
   * Optimize query
   * @param {string} storeName - Store name
   * @param {object} query - Query object
   * @returns {object} - Optimized query
   */
  optimizeQuery(storeName, query) {
    const optimized = { ...query };

    // Add index hints
    const hints = this.indexHints.get(storeName);
    if (hints) {
      optimized.useIndex = this.selectBestIndex(hints, query);
    }

    // Optimize filters
    if (query.filters) {
      optimized.filters = this.optimizeFilters(query.filters);
    }

    // Optimize sorting
    if (query.sorting) {
      optimized.sorting = this.optimizeSorting(query.sorting, hints);
    }

    return optimized;
  }

  /**
   * Select best index for query
   * @param {Array} indexes - Available indexes
   * @param {object} query - Query object
   * @returns {string|null} - Best index name
   */
  selectBestIndex(indexes, query) {
    if (!query.filters || query.filters.length === 0) {
      return null;
    }

    // Find index that matches most filter fields
    let bestIndex = null;
    let bestScore = 0;

    for (const index of indexes) {
      const score = this.calculateIndexScore(index, query);
      if (score > bestScore) {
        bestScore = score;
        bestIndex = index.name;
      }
    }

    return bestIndex;
  }

  /**
   * Calculate index score for query
   * @param {object} index - Index definition
   * @param {object} query - Query object
   * @returns {number} - Score
   */
  calculateIndexScore(index, query) {
    if (!query.filters) {return 0;}

    let score = 0;
    for (const filter of query.filters) {
      if (index.fields.includes(filter.field)) {
        score += 10; // High score for matching field
        if (filter.operator === 'eq') {
          score += 5; // Bonus for equality
        }
      }
    }

    // Bonus for primary key
    if (index.isPrimary) {
      score += 20;
    }

    // Bonus for unique index
    if (index.isUnique) {
      score += 10;
    }

    return score;
  }

  /**
   * Optimize filters
   * @param {Array} filters - Filters to optimize
   * @returns {Array} - Optimized filters
   */
  optimizeFilters(filters) {
    // Sort filters by selectivity (most selective first)
    return [...filters].sort((a, b) => {
      const selectivityA = this.getFilterSelectivity(a);
      const selectivityB = this.getFilterSelectivity(b);
      return selectivityB - selectivityA;
    });
  }

  /**
   * Get filter selectivity
   * @param {object} filter - Filter
   * @returns {number} - Selectivity score
   */
  getFilterSelectivity(filter) {
    switch (filter.operator) {
      case 'eq':
        return 10; // Most selective
      case 'in':
        return 8;
      case 'range':
      case 'gt':
      case 'gte':
      case 'lt':
      case 'lte':
        return 5;
      case 'contains':
      case 'startsWith':
        return 2;
      default:
        return 1;
    }
  }

  /**
   * Optimize sorting
   * @param {Array} sorting - Sorting rules
   * @param {Array} indexes - Available indexes
   * @returns {Array} - Optimized sorting
   */
  optimizeSorting(sorting, indexes) {
    if (!indexes) {return sorting;}

    // Check if sorting can use an index
    for (const index of indexes) {
      if (this.sortingUsesIndex(sorting, index)) {
        return sorting; // Already optimal
      }
    }

    return sorting;
  }

  /**
   * Check if sorting uses index
   * @param {Array} sorting - Sorting rules
   * @param {object} index - Index definition
   * @returns {boolean} - Uses index
   */
  sortingUsesIndex(sorting, index) {
    if (sorting.length > index.fields.length) {return false;}

    for (let i = 0; i < sorting.length; i++) {
      if (sorting[i].field !== index.fields[i]) {return false;}
    }

    return true;
  }

  /**
   * Execute optimized query
   * @param {string} storeName - Store name
   * @param {object} query - Query object
   * @returns {Promise<Array>} - Query results
   */
  async executeQuery(storeName, query) {
    const startTime = performance.now();

    // Check cache
    if (this.cacheEnabled) {
      const cacheKey = this.generateCacheKey(storeName, query);
      const cached = this.queryCache.get(cacheKey);

      if (cached && !cached.isExpired()) {
        cached.recordAccess();
        const executionTime = performance.now() - startTime;
        
        this.recordQueryPlan(storeName, query, {
          executionTime,
          rowCount: cached.result.length,
          cacheHit: true
        });

        return cached.result;
      }
    }

    // Optimize query
    const optimizedQuery = this.optimizeQuery(storeName, query);

    // Execute query
    let result = [];
    try {
      result = await this.executeQueryInternal(storeName, optimizedQuery);
    } catch (err) {
      console.error('Query execution failed:', err);
      throw err;
    }

    const executionTime = performance.now() - startTime;

    // Cache result
    if (this.cacheEnabled && result.length > 0) {
      const cacheKey = this.generateCacheKey(storeName, query);
      this.cacheResult(cacheKey, storeName, query, result);
    }

    // Record query plan
    this.recordQueryPlan(storeName, query, {
      executionTime,
      rowCount: result.length,
      cacheHit: false
    });

    return result;
  }

  /**
   * Execute query internally
   * @param {string} storeName - Store name
   * @param {object} query - Optimized query
   * @returns {Promise<Array>} - Query results
   */
  async executeQueryInternal(storeName, query) {
    // This would use the actual IndexedDB query execution
    // For now, use the existing gAll function
    let data = await gAll(storeName);

    // Apply filters
    if (query.filters) {
      data = this.applyFilters(data, query.filters);
    }

    // Apply sorting
    if (query.sorting) {
      data = this.applySorting(data, query.sorting);
    }

    // Apply limit
    if (query.limit) {
      data = data.slice(0, query.limit);
    }

    return data;
  }

  /**
   * Apply filters to data
   * @param {Array} data - Data to filter
   * @param {Array} filters - Filters
   * @returns {Array} - Filtered data
   */
  applyFilters(data, filters) {
    return data.filter(item => {
      return filters.every(filter => {
        const value = item[filter.field];
        const filterValue = filter.value;

        switch (filter.operator) {
          case 'eq':
            return value === filterValue;
          case 'neq':
            return value !== filterValue;
          case 'gt':
            return value > filterValue;
          case 'gte':
            return value >= filterValue;
          case 'lt':
            return value < filterValue;
          case 'lte':
            return value <= filterValue;
          case 'contains':
            return String(value).toLowerCase().includes(String(filterValue).toLowerCase());
          case 'startsWith':
            return String(value).toLowerCase().startsWith(String(filterValue).toLowerCase());
          case 'in':
            return Array.isArray(filterValue) && filterValue.includes(value);
          default:
            return true;
        }
      });
    });
  }

  /**
   * Apply sorting to data
   * @param {Array} data - Data to sort
   * @param {Array} sorting - Sorting rules
   * @returns {Array} - Sorted data
   */
  applySorting(data, sorting) {
    return [...data].sort((a, b) => {
      for (const rule of sorting) {
        const valA = a[rule.field];
        const valB = b[rule.field];
        let result = 0;

        if (valA < valB) {result = -1;}
        if (valA > valB) {result = 1;}

        if (rule.direction === 'desc') {result = -result;}
        if (result !== 0) {return result;}
      }
      return 0;
    });
  }

  /**
   * Generate cache key
   * @param {string} storeName - Store name
   * @param {object} query - Query object
   * @returns {string} - Cache key
   */
  generateCacheKey(storeName, query) {
    const queryStr = JSON.stringify(query);
    return `${storeName}:${queryStr}`;
  }

  /**
   * Cache result
   * @param {string} key - Cache key
   * @param {string} storeName - Store name
   * @param {object} query - Query object
   * @param {Array} result - Query result
   */
  cacheResult(key, storeName, query, result) {
    // Enforce cache size limit
    if (this.queryCache.size >= this.cacheMaxSize) {
      this.evictLRU();
    }

    const entry = new QueryCacheEntry({
      key,
      storeName,
      query,
      result,
      expiresAt: new Date(Date.now() + this.cacheDefaultTTL).toISOString()
    });

    this.queryCache.set(key, entry);
  }

  /**
   * Evict least recently used cache entry
   */
  evictLRU() {
    let lruKey = null;
    let lruTime = Date.now();

    for (const [key, entry] of this.queryCache) {
      const entryTime = new Date(entry.lastAccessed).getTime();
      if (entryTime < lruTime) {
        lruTime = entryTime;
        lruKey = key;
      }
    }

    if (lruKey) {
      this.queryCache.delete(lruKey);
    }
  }

  /**
   * Cleanup expired cache entries
   */
  cleanupCache() {
    for (const [key, entry] of this.queryCache) {
      if (entry.isExpired()) {
        this.queryCache.delete(key);
      }
    }
  }

  /**
   * Clear cache
   * @param {string} storeName - Store name (optional, clears all if not specified)
   */
  clearCache(storeName = null) {
    if (storeName) {
      for (const [key, entry] of this.queryCache) {
        if (entry.storeName === storeName) {
          this.queryCache.delete(key);
        }
      }
    } else {
      this.queryCache.clear();
    }
  }

  /**
   * Record query plan
   * @param {string} storeName - Store name
   * @param {object} query - Query object
   * @param {object} metrics - Query metrics
   */
  recordQueryPlan(storeName, query, metrics) {
    const plan = new QueryPlan({
      storeName,
      filters: query.filters || [],
      sorting: query.sorting || [],
      executionTime: metrics.executionTime,
      rowCount: metrics.rowCount
    });

    this.queryPlans.set(plan.id, plan);
  }

  /**
   * Add index hint
   * @param {string} storeName - Store name
   * @param {Array} indexes - Index definitions
   */
  async addIndexHint(storeName, indexes) {
    this.indexHints.set(storeName, indexes);
    
    try {
      await dPut('index_hints', {
        id: storeName,
        storeName,
        indexes
      });
    } catch (err) {
      console.error('Failed to save index hints:', err);
    }
  }

  /**
   * Get query statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const plans = Array.from(this.queryPlans.values());
    return {
      totalQueries: plans.length,
      avgExecutionTime: plans.reduce((sum, p) => sum + p.executionTime, 0) / plans.length || 0,
      totalRowsReturned: plans.reduce((sum, p) => sum + p.rowCount, 0),
      cacheSize: this.queryCache.size,
      cacheHitRate: this.calculateCacheHitRate(),
      byStore: this.getStoreQueryCounts(plans)
    };
  }

  /**
   * Calculate cache hit rate
   * @returns {number} - Cache hit rate
   */
  calculateCacheHitRate() {
    const totalHits = Array.from(this.queryCache.values())
      .reduce((sum, e) => sum + e.hitCount, 0);
    
    const totalQueries = Array.from(this.queryPlans.values()).length;
    
    if (totalQueries === 0) {return 0;}
    return totalHits / totalQueries;
  }

  /**
   * Get store query counts
   * @param {Array} plans - Query plans
   * @returns {object} - Store counts
   */
  getStoreQueryCounts(plans) {
    const counts = {};
    plans.forEach(p => {
      counts[p.storeName] = (counts[p.storeName] || 0) + 1;
    });
    return counts;
  }
}

/**
 * Global query optimization manager instance
 */
const queryOptimizationManager = new QueryOptimizationManager();

/**
 * Initialize query optimization
 */
async function initQueryOptimization() {
  await queryOptimizationManager.init();
  return queryOptimizationManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.QueryOptimization = {
    manager: queryOptimizationManager,
    init: initQueryOptimization,
    optimize: (store, query) => queryOptimizationManager.optimizeQuery(store, query),
    execute: (store, query) => queryOptimizationManager.executeQuery(store, query),
    addIndexHint: (store, indexes) => queryOptimizationManager.addIndexHint(store, indexes),
    clearCache: (store) => queryOptimizationManager.clearCache(store),
    getStats: () => queryOptimizationManager.getStatistics()
  };
}
