// ── Security Utilities (XSS Protection) ──

/**
 * Sanitize HTML to prevent XSS attacks
 * @param {string} unsafe - Unsafe HTML string
 * @returns {string} - Sanitized HTML
 */
function sanitizeHTML(unsafe) {
  if (typeof unsafe !== 'string') {return '';}
  const div = document.createElement('div');
  div.textContent = unsafe;
  return div.innerHTML;
}

/**
 * Sanitize text by removing HTML tags
 * @param {string} text - Text with potential HTML
 * @returns {string} - Plain text
 */
function sanitizeText(text) {
  if (typeof text !== 'string') {return '';}
  return text.replace(/<[^>]*>/g, '').trim();
}

/**
 * Escape HTML special characters
 * @param {string} str - String to escape
 * @returns {string} - Escaped string
 */
function escapeHTML(str) {
  if (typeof str !== 'string') {return '';}
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Sanitize and validate a number within range
 * @param {*} val - Value to sanitize
 * @param {number} min - Minimum value
 * @param {number} max - Maximum value
 * @param {number} def - Default value if invalid
 * @returns {number} - Sanitized number
 */
function sanitizeNumber(val, min = 0, max = Infinity, def = 0) {
  const num = parseFloat(val);
  if (isNaN(num)) {return def;}
  return Math.max(min, Math.min(max, num));
}

/**
 * Sanitize and validate an integer within range
 * @param {*} val - Value to sanitize
 * @param {number} min - Minimum value
 * @param {number} max - Maximum value
 * @param {number} def - Default value if invalid
 * @returns {number} - Sanitized integer
 */
function sanitizeInteger(val, min = 0, max = Infinity, def = 0) {
  return Math.floor(sanitizeNumber(val, min, max, def));
}

/**
 * Sanitize barcode string
 * @param {string} code - Barcode to sanitize
 * @returns {string} - Sanitized barcode
 */
function sanitizeBarcode(code) {
  if (typeof code !== 'string') {return '';}
  return code.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
}

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} - Is valid email
 */
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/**
 * Validate phone number format
 * @param {string} phone - Phone number to validate
 * @returns {boolean} - Is valid phone
 */
function isValidPhone(phone) {
  return /^[\d\s\-\(\)]{10,}$/.test(phone);
}

/**
 * Check if URL is safe
 * @param {string} url - URL to check
 * @returns {boolean} - Is safe URL
 */
function isSafeURL(url) {
  try {
    const u = new URL(url);
    return ['http:', 'https:', 'data:'].includes(u.protocol);
  } catch {
    return false;
  }
}

/**
 * Generate UUID v4 with fallback for older browsers
 * @returns {string} - UUID string
 */
function generateUUID() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  // Fallback: RFC4122 v4 UUID
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// Note: debounce function is now in modules/debounce.js to avoid duplication

// Export for ES6 modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    sanitizeHTML,
    sanitizeText,
    escapeHTML,
    sanitizeNumber,
    sanitizeInteger,
    sanitizeBarcode,
    isValidEmail,
    isValidPhone,
    isSafeURL,
    generateUUID
  };
}
