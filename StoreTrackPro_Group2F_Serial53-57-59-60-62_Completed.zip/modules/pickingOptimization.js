/* exported PickOrderItem */
// Picking Optimization Module - Warehouse picking route optimization

/**
 * Pick Order class
 */
class PickOrder {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.orderNumber = config.orderNumber || this.generateOrderNumber();
    this.type = config.type || 'sales'; // sales, transfer, return
    this.status = config.status || 'pending'; // pending, assigned, in_progress, completed, cancelled
    this.priority = config.priority || 'normal'; // low, normal, high, urgent
    this.items = config.items || [];
    this.assignedTo = config.assignedTo || null;
    this.assignedAt = config.assignedAt || null;
    this.startedAt = config.startedAt || null;
    this.completedAt = config.completedAt || null;
    this.pickRoute = config.pickRoute || [];
    this.estimatedTime = config.estimatedTime || 0;
    this.actualTime = config.actualTime || 0;
    this.notes = config.notes || '';
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `pick-order-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  generateOrderNumber() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `PK-${year}${month}-${random}`;
  }

  /**
   * Get total items
   * @returns {number} - Total items
   */
  getTotalItems() {
    return this.items.reduce((sum, item) => sum + item.quantity, 0);
  }

  /**
   * Get total quantity
   * @returns {number} - Total quantity
   */
  getTotalQuantity() {
    return this.items.reduce((sum, item) => sum + (item.quantity * item.unitQuantity || 1), 0);
  }
}

/**
 * Pick Order Item class
 */
class PickOrderItem {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.orderId = config.orderId || '';
    this.itemId = config.itemId || null;
    this.barcode = config.barcode || '';
    this.itemName = config.itemName || '';
    this.quantity = config.quantity || 0;
    this.unitQuantity = config.unitQuantity || 1;
    this.binLocation = config.binLocation || '';
    this.pickedQuantity = config.pickedQuantity || 0;
    this.status = config.status || 'pending'; // pending, picked, short
    this.pickedAt = config.pickedAt || null;
    this.notes = config.notes || '';
  }

  generateId() {
    return `pick-item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Is fully picked
   * @returns {boolean} - Is fully picked
   */
  isFullyPicked() {
    return this.pickedQuantity >= this.quantity;
  }

  /**
   * Get remaining quantity
   * @returns {number} - Remaining quantity
   */
  getRemainingQuantity() {
    return Math.max(0, this.quantity - this.pickedQuantity);
  }
}

/**
 * Pick Route class
 */
class PickRoute {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.orderId = config.orderId || '';
    this.waypoints = config.waypoints || []; // Array of { binCode, sequence, distance }
    this.totalDistance = config.totalDistance || 0;
    this.estimatedTime = config.estimatedTime || 0;
    this.algorithm = config.algorithm || 'nearest_neighbor'; // nearest_neighbor, genetic, simulated_annealing
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `route-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Picking Optimization Manager
 */
class PickingOptimizationManager {
  constructor() {
    this.pickOrders = new Map();
    this.pickRoutes = new Map();
    this.init();
  }

  /**
   * Initialize picking optimization manager
   */
  async init() {
    await this.loadPickOrders();
    await this.loadPickRoutes();
  }

  /**
   * Load pick orders from storage
   */
  async loadPickOrders() {
    try {
      const orders = await gAll('pick_orders');
      orders.forEach(o => {
        this.pickOrders.set(o.id, new PickOrder(o));
      });
    } catch (err) {
      console.error('Failed to load pick orders:', err);
    }
  }

  /**
   * Load pick routes from storage
   */
  async loadPickRoutes() {
    try {
      const routes = await gAll('pick_routes');
      routes.forEach(r => {
        this.pickRoutes.set(r.id, new PickRoute(r));
      });
    } catch (err) {
      console.error('Failed to load pick routes:', err);
    }
  }

  /**
   * Create pick order
   * @param {object} config - Order configuration
   * @returns {PickOrder} - Created order
   */
  async createPickOrder(config) {
    const order = new PickOrder(config);
    this.pickOrders.set(order.id, order);
    await this.savePickOrder(order);
    return order;
  }

  /**
   * Update pick order
   * @param {string} id - Order ID
   * @param {object} updates - Updates to apply
   * @returns {PickOrder} - Updated order
   */
  async updatePickOrder(id, updates) {
    const order = this.pickOrders.get(id);
    if (order) {
      Object.assign(order, updates);
      await this.savePickOrder(order);
    }
    return order;
  }

  /**
   * Delete pick order
   * @param {string} id - Order ID
   */
  async deletePickOrder(id) {
    this.pickOrders.delete(id);
    await dDel('pick_orders', id);
  }

  /**
   * Save pick order to storage
   * @param {PickOrder} order - Order to save
   */
  async savePickOrder(order) {
    try {
      await dPut('pick_orders', order);
    } catch (err) {
      console.error('Failed to save pick order:', err);
    }
  }

  /**
   * Assign picker to order
   * @param {string} id - Order ID
   * @param {string} pickerId - Picker ID
   */
  async assignPicker(id, pickerId) {
    const order = this.pickOrders.get(id);
    if (order) {
      order.assignedTo = pickerId;
      order.assignedAt = new Date().toISOString();
      order.status = 'assigned';
      await this.savePickOrder(order);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('pick_order_assigned', 'warehouse', id, {
          orderNumber: order.orderNumber,
          pickerId
        });
      }
    }
  }

  /**
   * Start picking
   * @param {string} id - Order ID
   */
  async startPicking(id) {
    const order = this.pickOrders.get(id);
    if (order) {
      order.status = 'in_progress';
      order.startedAt = new Date().toISOString();
      await this.savePickOrder(order);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('picking_started', 'warehouse', id, {
          orderNumber: order.orderNumber
        });
      }
    }
  }

  /**
   * Complete picking
   * @param {string} id - Order ID
   */
  async completePicking(id) {
    const order = this.pickOrders.get(id);
    if (order) {
      order.status = 'completed';
      order.completedAt = new Date().toISOString();
      order.actualTime = new Date(order.completedAt) - new Date(order.startedAt);
      await this.savePickOrder(order);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('picking_completed', 'warehouse', id, {
          orderNumber: order.orderNumber,
          actualTime: order.actualTime
        });
      }
    }
  }

  /**
   * Pick item
   * @param {string} orderId - Order ID
   * @param {string} itemId - Item ID
   * @param {number} quantity - Quantity picked
   */
  async pickItem(orderId, itemId, quantity) {
    const order = this.pickOrders.get(orderId);
    if (order) {
      const item = order.items.find(i => i.id === itemId);
      if (item) {
        item.pickedQuantity += quantity;
        item.pickedAt = new Date().toISOString();
        item.status = item.isFullyPicked() ? 'picked' : 'pending';
        
        if (item.pickedQuantity > item.quantity) {
          item.status = 'short';
        }

        await this.savePickOrder(order);
      }
    }
  }

  /**
   * Optimize pick route
   * @param {string} orderId - Order ID
   * @param {string} algorithm - Algorithm to use
   * @returns {Promise<PickRoute>} - Optimized route
   */
  async optimizePickRoute(orderId, algorithm = 'nearest_neighbor') {
    const order = this.pickOrders.get(orderId);
    if (!order) {
      throw new Error('Order not found');
    }

    // Get bin locations for items
    const waypoints = [];
    
    if (typeof window !== 'undefined' && window.BinLocationManagement) {
      for (const item of order.items) {
        const bin = window.BinLocationManagement.getBinByCode(item.binLocation);
        if (bin) {
          waypoints.push({
            binCode: bin.binCode,
            itemId: item.itemId,
            barcode: item.barcode,
            itemName: item.itemName,
            quantity: item.quantity,
            zone: bin.zone,
            aisle: bin.aisle,
            rack: bin.rack,
            level: bin.level,
            position: { x: 0, y: 0, z: 0 } // Would be actual coordinates
          });
        }
      }
    }

    // Optimize route based on algorithm
    let optimizedWaypoints;
    switch (algorithm) {
      case 'nearest_neighbor':
        optimizedWaypoints = this.nearestNeighborAlgorithm(waypoints);
        break;
      case 'genetic':
        optimizedWaypoints = this.geneticAlgorithm(waypoints);
        break;
      case 'simulated_annealing':
        optimizedWaypoints = this.simulatedAnnealingAlgorithm(waypoints);
        break;
      default:
        optimizedWaypoints = this.nearestNeighborAlgorithm(waypoints);
    }

    // Calculate total distance
    const totalDistance = this.calculateTotalDistance(optimizedWaypoints);
    const estimatedTime = this.estimatePickTime(optimizedWaypoints, totalDistance);

    const route = new PickRoute({
      orderId,
      waypoints: optimizedWaypoints,
      totalDistance,
      estimatedTime,
      algorithm
    });

    this.pickRoutes.set(route.id, route);
    await this.savePickRoute(route);

    // Update order with route
    order.pickRoute = optimizedWaypoints;
    order.estimatedTime = estimatedTime;
    await this.savePickOrder(order);

    return route;
  }

  /**
   * Nearest neighbor algorithm
   * @param {Array} waypoints - Waypoints
   * @returns {Array} - Optimized waypoints
   */
  nearestNeighborAlgorithm(waypoints) {
    if (waypoints.length <= 1) {return waypoints;}

    const optimized = [waypoints[0]];
    const remaining = [...waypoints.slice(1)];

    while (remaining.length > 0) {
      const current = optimized[optimized.length - 1];
      let nearestIndex = 0;
      let nearestDistance = Infinity;

      for (let i = 0; i < remaining.length; i++) {
        const distance = this.calculateDistance(current, remaining[i]);
        if (distance < nearestDistance) {
          nearestDistance = distance;
          nearestIndex = i;
        }
      }

      optimized.push(remaining[nearestIndex]);
      remaining.splice(nearestIndex, 1);
    }

    return optimized;
  }

  /**
   * Genetic algorithm (simplified)
   * @param {Array} waypoints - Waypoints
   * @returns {Array} - Optimized waypoints
   */
  geneticAlgorithm(waypoints) {
    // Simplified genetic algorithm
    // In production, this would use proper genetic algorithm implementation
    return this.nearestNeighborAlgorithm(waypoints);
  }

  /**
   * Simulated annealing algorithm (simplified)
   * @param {Array} waypoints - Waypoints
   * @returns {Array} - Optimized waypoints
   */
  simulatedAnnealingAlgorithm(waypoints) {
    // Simplified simulated annealing
    // In production, this would use proper simulated annealing implementation
    return this.nearestNeighborAlgorithm(waypoints);
  }

  /**
   * Calculate distance between two waypoints
   * @param {object} from - From waypoint
   * @param {object} to - To waypoint
   * @returns {number} - Distance
   */
  calculateDistance(from, to) {
    // Simplified distance calculation
    // In production, this would use actual warehouse coordinates
    const dx = (to.aisle || 0) - (from.aisle || 0);
    const dy = (to.rack || 0) - (from.rack || 0);
    const dz = (to.level || 0) - (from.level || 0);
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  /**
   * Calculate total distance
   * @param {Array} waypoints - Waypoints
   * @returns {number} - Total distance
   */
  calculateTotalDistance(waypoints) {
    let total = 0;
    for (let i = 0; i < waypoints.length - 1; i++) {
      total += this.calculateDistance(waypoints[i], waypoints[i + 1]);
    }
    return total;
  }

  /**
   * Estimate pick time
   * @param {Array} waypoints - Waypoints
   * @param {number} distance - Total distance
   * @returns {number} - Estimated time in minutes
   */
  estimatePickTime(waypoints, distance) {
    // Base time: 2 minutes per waypoint
    const waypointTime = waypoints.length * 2;
    // Travel time: 0.5 minutes per distance unit
    const travelTime = distance * 0.5;
    return waypointTime + travelTime;
  }

  /**
   * Save pick route to storage
   * @param {PickRoute} route - Route to save
   */
  async savePickRoute(route) {
    try {
      await dPut('pick_routes', route);
    } catch (err) {
      console.error('Failed to save pick route:', err);
    }
  }

  /**
   * Get pick order
   * @param {string} id - Order ID
   * @returns {PickOrder} - Order
   */
  getPickOrder(id) {
    return this.pickOrders.get(id);
  }

  /**
   * Get pick order by order number
   * @param {string} orderNumber - Order number
   * @returns {PickOrder} - Order
   */
  getPickOrderByNumber(orderNumber) {
    return Array.from(this.pickOrders.values()).find(o => o.orderNumber === orderNumber);
  }

  /**
   * Get all pick orders
   * @returns {Array} - Array of orders
   */
  getAllPickOrders() {
    return Array.from(this.pickOrders.values());
  }

  /**
   * Get orders by status
   * @param {string} status - Status
   * @returns {Array} - Orders
   */
  getOrdersByStatus(status) {
    return this.getAllPickOrders().filter(o => o.status === status);
  }

  /**
   * Get orders by picker
   * @param {string} pickerId - Picker ID
   * @returns {Array} - Orders
   */
  getOrdersByPicker(pickerId) {
    return this.getAllPickOrders().filter(o => o.assignedTo === pickerId);
  }

  /**
   * Get pending orders
   * @returns {Array} - Pending orders
   */
  getPendingOrders() {
    return this.getOrdersByStatus('pending');
  }

  /**
   * Get high priority orders
   * @returns {Array} - High priority orders
   */
  getHighPriorityOrders() {
    return this.getAllPickOrders().filter(o => 
      o.priority === 'urgent' || o.priority === 'high'
    );
  }

  /**
   * Get pick route
   * @param {string} id - Route ID
   * @returns {PickRoute} - Route
   */
  getPickRoute(id) {
    return this.pickRoutes.get(id);
  }

  /**
   * Get route by order
   * @param {string} orderId - Order ID
   * @returns {PickRoute} - Route
   */
  getRouteByOrder(orderId) {
    return Array.from(this.pickRoutes.values()).find(r => r.orderId === orderId);
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const orders = this.getAllPickOrders();

    return {
      totalOrders: orders.length,
      byStatus: this.getStatusCounts(orders),
      byPriority: this.getPriorityCounts(orders),
      avgPickTime: orders.length > 0 
        ? orders.filter(o => o.actualTime > 0).reduce((sum, o) => sum + o.actualTime, 0) / orders.filter(o => o.actualTime > 0).length 
        : 0,
      totalItems: orders.reduce((sum, o) => sum + o.getTotalItems(), 0),
      totalQuantity: orders.reduce((sum, o) => sum + o.getTotalQuantity(), 0),
      avgItemsPerOrder: orders.length > 0 
        ? orders.reduce((sum, o) => sum + o.getTotalItems(), 0) / orders.length 
        : 0
    };
  }

  /**
   * Get status counts
   * @param {Array} orders - Orders
   * @returns {object} - Status counts
   */
  getStatusCounts(orders) {
    const counts = {};
    orders.forEach(o => {
      counts[o.status] = (counts[o.status] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get priority counts
   * @param {Array} orders - Orders
   * @returns {object} - Priority counts
   */
  getPriorityCounts(orders) {
    const counts = {};
    orders.forEach(o => {
      counts[o.priority] = (counts[o.priority] || 0) + 1;
    });
    return counts;
  }
}

/**
 * Global picking optimization manager instance
 */
const pickingOptimizationManager = new PickingOptimizationManager();

/**
 * Initialize picking optimization
 */
async function initPickingOptimization() {
  await pickingOptimizationManager.init();
  return pickingOptimizationManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.PickingOptimization = {
    manager: pickingOptimizationManager,
    init: initPickingOptimization,
    createPickOrder: (config) => pickingOptimizationManager.createPickOrder(config),
    updatePickOrder: (id, updates) => pickingOptimizationManager.updatePickOrder(id, updates),
    deletePickOrder: (id) => pickingOptimizationManager.deletePickOrder(id),
    getPickOrder: (id) => pickingOptimizationManager.getPickOrder(id),
    getPickOrderByNumber: (orderNumber) => pickingOptimizationManager.getPickOrderByNumber(orderNumber),
    getAllPickOrders: () => pickingOptimizationManager.getAllPickOrders(),
    getOrdersByStatus: (status) => pickingOptimizationManager.getOrdersByStatus(status),
    getOrdersByPicker: (pickerId) => pickingOptimizationManager.getOrdersByPicker(pickerId),
    getPendingOrders: () => pickingOptimizationManager.getPendingOrders(),
    getHighPriorityOrders: () => pickingOptimizationManager.getHighPriorityOrders(),
    assignPicker: (id, pickerId) => pickingOptimizationManager.assignPicker(id, pickerId),
    startPicking: (id) => pickingOptimizationManager.startPicking(id),
    completePicking: (id) => pickingOptimizationManager.completePicking(id),
    pickItem: (orderId, itemId, quantity) => pickingOptimizationManager.pickItem(orderId, itemId, quantity),
    optimizeRoute: (orderId, algorithm) => pickingOptimizationManager.optimizePickRoute(orderId, algorithm),
    getPickRoute: (id) => pickingOptimizationManager.getPickRoute(id),
    getRouteByOrder: (orderId) => pickingOptimizationManager.getRouteByOrder(orderId),
    getStats: () => pickingOptimizationManager.getStatistics()
  };
}
