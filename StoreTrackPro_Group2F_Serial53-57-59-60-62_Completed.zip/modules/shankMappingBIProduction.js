/* Shank Mapping BI production extensions. Shank-specific, deterministic, read-only analytics. */
(function () {
  'use strict';
  const root = typeof window !== 'undefined' ? window : globalThis;
  const partUtils = (typeof window !== 'undefined' && window.PartNumberUtils) || (typeof require === 'function' ? require('../core/partNumber') : {});
  const partKey = partUtils.partKey || (value => String(value == null ? '' : value).trim().replace(/\s+/g, '').split(/([\/-])/).map(segment => /^\d+$/.test(segment) ? segment.replace(/^0+(?=\d)/, '') : segment.toUpperCase()).join('').toLowerCase());
  const STORES = {
    approvals: 'component_bi_approvals',
    schedules: 'component_bi_schedules',
    feedback: 'component_bi_feedback'
  };
  const esc = value => String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const num = value => { const n = Number(value); return Number.isFinite(n) ? n : 0; };
  const dateValue = row => row?.date || row?.timestamp || row?.createdAt || row?.updatedAt || row?.importedAt || row?.replacementDateTime || row?.replacementDate || null;
  const today = () => new Date().toISOString().slice(0, 10);
  const safeAll = async store => { try { return await window.gAll(store); } catch (_) { return []; } };
  const currentUser = () => window.currentUser || (typeof window.user === 'function' ? window.user() : null) || {};
  const userName = () => currentUser().username || currentUser().name || 'Unknown user';
  const can = capability => typeof window.canShankComponent !== 'function' || window.canShankComponent(capability);
  const actionButton = (label, action, disabled = false) => `<button type="button" class="btn ${disabled ? '' : 'btn-p'}" ${disabled ? 'disabled' : `data-onclick="${action}"`}>${esc(label)}</button>`;
  const card = (title, body, id = '') => `<div class="card"${id ? ` id="${esc(id)}"` : ''}><div class="card-hd">${esc(title)}</div>${body}</div>`;
  const table = (headers, rows, empty = 'No records found.') => `<div class="tw"><table><thead><tr>${headers.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows || `<tr><td colspan="${headers.length}">${esc(empty)}</td></tr>`}</tbody></table></div>`;

  function approvalRowsForSubject(rows, subject) {
    const query = String(subject || '').trim().toLowerCase();
    return query ? (rows || []).filter(row => [row.partNo, row.subject, row.type].some(value => String(value || '').toLowerCase().includes(query))) : [...(rows || [])];
  }

  function actionCenter(forecasts, mappings, anomalies, approvals, accuracy) {
    const items = [];
    forecasts.filter(r => r.status !== 'NORMAL').forEach(r => items.push({type: r.status === 'ZERO STOCK' || r.status === 'STOCK-OUT RISK' ? 'Stock risk' : 'Order required', subject: r.partNo, detail: `${r.status} · ${num(r.currentStock)} on hand`, action: r.status === 'ZERO STOCK' ? `componentBiOpenStock('${esc(r.partNo)}')` : `componentBiCreateOrder('${esc(r.partNo)}')`, label: r.status === 'ZERO STOCK' ? 'Open Stock' : 'Create Order'}));
    const riskyStations = {};
    (mappings || []).forEach(row => { const key = row.stationNo || 'Unknown'; riskyStations[key] = (riskyStations[key] || 0) + 1; });
    Object.entries(riskyStations).filter(([, count]) => count >= 3).forEach(([station, count]) => items.push({type: 'High-risk station', subject: station, detail: `${count} mapped shank rows; review station/gun mapping`, action: `componentBiOpenStation('${esc(station)}')`, label: 'Review Mapping'}));
    (mappings || []).filter(row => !String(row.partNo || '').trim() || !String(row.stationNo || '').trim()).slice(0, 25).forEach(row => items.push({type: 'Data quality', subject: row.stationNo || row.gunReferenceNo || 'Unresolved mapping', detail: 'Required station or part value is missing', action: `componentBiOpenMappingReview('${esc(row.stationNo || '')}')`, label: 'Review Mapping'}));
    (anomalies || []).filter(a => a.status !== 'resolved' && (a.severity === 'high' || a.severity === 'critical' || a.anomaly || a.isAnomaly)).slice(0, 25).forEach(a => items.push({type: 'Usage anomaly', subject: a.partNo || a.stationNo || 'Usage anomaly', detail: a.reason || a.explanation || 'Unreviewed source anomaly', action: `componentBiOpenAnomaly('${esc(a.partNo || '')}')`, label: 'Open Anomaly'}));
    approvals.filter(a => a.status === 'Pending').slice(0, 25).forEach(a => items.push({type: a.type === 'substitute' ? 'Pending substitute' : 'Pending approval', subject: a.partNo || a.subject || a.type, detail: a.originalRecommendation || a.reason || 'Approval required', action: `componentBiOpenApprovals('${esc(a.partNo || a.subject || a.type || '')}')`, label: a.type === 'substitute' ? 'Approve Substitute' : 'Open Approval'}));
    forecasts.filter(r => r.usageConfidence === 'LOW' || r.usageConfidence === 'NO DATA').slice(0, 25).forEach(r => items.push({type: 'Low forecast confidence', subject: r.partNo, detail: r.usageConfidence === 'NO DATA' ? 'No saved usage history' : `${r.usageDays || 0} usage days available`, action: `componentBiOpenPart('${esc(r.partNo)}')`, label: 'Open Part Master'}));
    if (!items.length) {return '<div class="alrt alrt-s">No pending Shank Mapping BI actions were identified from current source data.</div>';}
    return table(['Type', 'Subject', 'Evidence', 'Action'], items.map(item => `<tr><td>${esc(item.type)}</td><td><button type="button" class="btn btn-link" data-onclick="${item.action}">${esc(item.subject)}</button></td><td>${esc(item.detail)}</td><td>${actionButton(item.label, item.action)}</td></tr>`).join(''));
  }

  function simulate(forecast, input) {
    const usageMultiplier = 1 + num(input.usageChange) / 100;
    const leadTime = Math.max(0, num(input.leadTime));
    const stock = Math.max(0, num(forecast.currentStock) + num(input.stockAdjustment));
    const safety = Math.max(0, num(forecast.safetyStockQty) + num(input.safetyAdjustment));
    const daily = Math.max(0, num(forecast.averageDailyUsage) * usageMultiplier);
    const period = Math.max(1, num(input.period) || 30);
    const zeroDays = daily > 0 ? stock / daily : null;
    const zeroDate = zeroDays == null ? null : new Date(Date.now() + Math.ceil(zeroDays) * 86400000).toISOString().slice(0, 10);
    const horizonDays = leadTime;
    const projectedHorizonUsage = daily * period;
    // The order recommendation covers supplier lead time plus safety stock.
    // `period` is the display/simulation horizon and must not inflate the
    // replenishment quantity beyond the lead-time requirement.
    const reorderPoint = daily * horizonDays + safety;
    const orderQty = Math.max(0, Math.ceil(reorderPoint - stock));
    const level = stock <= 0 ? 'ZERO STOCK' : zeroDays != null && zeroDays <= leadTime ? 'STOCK-OUT RISK' : stock <= reorderPoint ? 'REORDER' : 'NORMAL';
    const explanation = level === forecast.status ? 'Risk level is unchanged under these assumptions.' : `Risk changes from ${forecast.status} to ${level} because simulated daily usage is ${daily.toFixed(2)} and the projected cover is ${zeroDays == null ? 'unlimited' : `${zeroDays.toFixed(1)} days`} over the ${period}-day horizon.`;
    return {partNo: forecast.partNo, simulatedDailyUsage: daily, projectedHorizonUsage, expectedZeroDate: zeroDate, simulatedRiskLevel: level, suggestedOrderQuantity: orderQty, current: {dailyUsage: num(forecast.averageDailyUsage), status: forecast.status, stock: num(forecast.currentStock)}, simulated: {dailyUsage: daily, status: level, stock, safetyStock: safety, leadTime, period}, explanation};
  }

  function forecastAccuracy(forecasts, actualRows) {
    const actualByPart = new Map();
    (actualRows || []).forEach(row => { const part = String(row.partNo || row.newPartNo || '').trim(); const key = partKey(part); const actual = row.actualUsage ?? row.actualQuantity ?? row.forecastActualUsage; if (key && Number.isFinite(Number(actual))) {actualByPart.set(key, num(actualByPart.get(key)) + num(actual));} });
    return forecasts.map(row => { const key = row._partKey || partKey(row.partNo); const actual = actualByPart.get(key); if (actual == null) {return {...row, tracked: false};} const forecast = num(row.averageDailyUsage) * 30; const diff = actual - forecast; const accuracy = forecast === 0 ? (actual === 0 ? 100 : 0) : Math.max(0, 100 - Math.abs(diff) / forecast * 100); return {...row, tracked: true, forecastedUsage: forecast, actualUsage: actual, difference: diff, accuracy, direction: diff > 0 ? 'Under-forecast' : diff < 0 ? 'Over-forecast' : 'On target'}; });
  }

  function maintenanceCorrelation(replacements, repairScrap, mappings) {
    const station = {}, part = {}, gun = {};
    (replacements || []).forEach(row => { const qty = num(row.quantity) || 1; const s = row.stationNo || 'Unknown'; const p = row.partNo || row.newPartNo || 'Unknown'; const g = row.gunReferenceNo || 'Unknown'; station[s] = (station[s] || 0) + qty; part[p] = (part[p] || 0) + qty; gun[g] = (gun[g] || 0) + qty; });
    const repairs = (repairScrap || []).filter(row => ['repair', 'scrap', 'repaired', 'scrapped'].some(token => String(row.status || row.type || '').toLowerCase().includes(token)));
    const repairByPart = {}; repairs.forEach(row => { const p = row.partNo || 'Unknown'; repairByPart[p] = (repairByPart[p] || 0) + 1; });
    const rows = Object.entries(station).sort((a, b) => b[1] - a[1]).slice(0, 20).map(([key, count]) => ({scope: 'Station', subject: key, replacements: count, repairs: 0, evidence: count >= 3 ? 'Repeated replacement activity in source transactions.' : 'No repeated replacement threshold reached.'}));
    Object.entries(part).sort((a, b) => b[1] - a[1]).slice(0, 20).forEach(([key, count]) => rows.push({scope: 'Part', subject: key, replacements: count, repairs: repairByPart[key] || 0, evidence: repairByPart[key] ? 'Replacement and repair/scrap records share this part.' : 'Replacement records only; no repair/scrap correlation found.'}));
    Object.entries(gun).sort((a, b) => b[1] - a[1]).slice(0, 20).forEach(([key, count]) => rows.push({scope: 'Gun', subject: key, replacements: count, repairs: 0, evidence: count >= 3 ? 'Repeated gun-linked replacement activity.' : 'No repeated issue threshold reached.'}));
    return rows;
  }

  function freshness(stores) {
    const result = {}; const now = Date.now();
    Object.entries(stores).forEach(([label, rows]) => { const dates = (rows || []).map(dateValue).filter(Boolean).map(value => new Date(value).getTime()).filter(Number.isFinite); const latest = dates.length ? new Date(Math.max(...dates)).toISOString() : null; result[label] = {latest, stale: latest ? now - new Date(latest).getTime() > 86400000 : null, tracked: Boolean(latest)}; });
    return result;
  }

  async function loadProductionData() {
    const [mappings, repairScrap, transactions, anomalies, approvals, feedback, schedules] = await Promise.all([safeAll('component_mappings'), safeAll('component_repair_scrap'), safeAll('component_stock_transactions'), safeAll('component_usage_anomalies'), safeAll(STORES.approvals), safeAll(STORES.feedback), safeAll(STORES.schedules)]);
    return {mappings, repairScrap, transactions, anomalies, approvals, feedback, schedules};
  }

  function actionButtonsHtml(forecasts) {
    const partOptions = (forecasts || []).map(row => `<option value="${esc(row.partNo)}">${esc(row.partNo)}</option>`).join('');
    return `<div class="g4 cm-mobile-stack"><div class="fr"><label class="fl">Usage change (%)</label><input class="fi" id="cm-bi-usage-change" type="number" value="0"></div><div class="fr"><label class="fl">Supplier lead time (days)</label><input class="fi" id="cm-bi-lead-time" type="number" min="0" value="30"></div><div class="fr"><label class="fl">Stock adjustment</label><input class="fi" id="cm-bi-stock-adjustment" type="number" value="0"></div><div class="fr"><label class="fl">Safety stock adjustment</label><input class="fi" id="cm-bi-safety-adjustment" type="number" value="0"></div></div><div class="g3 cm-mobile-stack"><div class="fr"><label class="fl">Part</label><select class="fi" id="cm-bi-simulation-part">${partOptions}</select></div><div class="fr"><label class="fl">Simulation period</label><select class="fi" id="cm-bi-simulation-period"><option>7</option><option selected>30</option><option>60</option><option>90</option></select></div>${actionButton('Run What-if Simulation', 'componentBiRunSimulation()', true)}</div><div id="cm-bi-simulation-output" class="alrt alrt-b">Simulation is read-only and has not been run.</div>`;
  }

  async function render(forecasts, baseData) {
    const production = await loadProductionData();
    const navigationContext = window.componentBiNavigationContext || {};
    const approvalSubject = String(navigationContext.approvalSubject || '').trim().toLowerCase();
    const visibleApprovals = approvalRowsForSubject(production.approvals, approvalSubject);
    if (approvalSubject) { window.componentBiNavigationContext = null; }
    const accuracy = forecastAccuracy(forecasts, [...production.transactions, ...(baseData.replacements || [])]);
    const freshnessData = freshness({Stock: baseData.stock, 'Mapping import': production.mappings, 'Historical consumption': baseData.replacements, Transactions: production.transactions, 'BI refresh': [{updatedAt: new Date().toISOString()}]});
    const maintenance = maintenanceCorrelation(baseData.replacements, production.repairScrap, production.mappings);
    const orderActions = actionCenter(forecasts, production.mappings, production.anomalies, production.approvals, accuracy);
    const freshnessRows = Object.entries(freshnessData).map(([label, value]) => `<tr><td>${esc(label)}</td><td>${esc(value.latest || 'Not tracked')}</td><td>${value.stale === true ? '<span class="pill pill-y">STALE</span>' : value.stale === false ? '<span class="pill pill-s">CURRENT</span>' : '<span class="pill">NOT TRACKED</span>'}</td></tr>`).join('');
    const accuracyRows = accuracy.map(row => row.tracked ? `<tr><td>${esc(row.partNo)}</td><td>${row.forecastedUsage.toFixed(2)}</td><td>${row.actualUsage.toFixed(2)}</td><td>${row.difference.toFixed(2)}</td><td>${row.accuracy.toFixed(1)}%</td><td>${esc(row.direction)}</td><td>${esc(row.usageConfidence || 'LOW')}</td></tr>` : `<tr><td>${esc(row.partNo)}</td><td colspan="6">Not enough actual history — Not tracked</td></tr>`).join('');
    const maintenanceRows = maintenance.map(row => `<tr><td>${esc(row.scope)}</td><td>${esc(row.subject)}</td><td>${row.replacements}</td><td>${row.repairs}</td><td>${esc(row.evidence)}</td></tr>`).join('');
    const scheduleRows = production.schedules.map(row => `<tr><td>${esc(row.reportType)}</td><td>${esc(row.frequency)}</td><td>${esc(row.nextRun || 'Not configured')}</td><td>${esc(row.status || 'Active')}</td><td>${actionButton('Download report', `componentBiDownloadReport('${esc(row.reportType)}')`)}</td></tr>`).join('');
    return `<div class="card"><div class="card-hd">AI Action Center</div>${orderActions}</div>${card('What-if Simulation', actionButtonsHtml(forecasts))}${card('Forecast Accuracy Tracking', accuracyRows ? table(['Part', 'Forecasted usage (30d)', 'Actual usage', 'Difference', 'Accuracy', 'Direction', 'Confidence'], accuracyRows, 'Not enough actual history — Not tracked') : '<div class="alrt alrt-b">Not enough actual history — Not tracked</div>')}${card('Maintenance Correlation', table(['Scope', 'Station / Part / Gun', 'Replacement count', 'Repair/Scrap count', 'Source-based interpretation'], maintenanceRows, 'No maintenance or replacement records available.'))}${card('Approval Workflow', `${approvalSubject ? `<div class="alrt alrt-b">Showing approval records matching: ${esc(navigationContext.approvalSubject)}</div>` : ''}<div class="alrt alrt-b">AI recommendations are not applied automatically. Approval records require an authenticated user, timestamp, original recommendation, decision, comment, and audit entry.</div>${table(['Type', 'Subject', 'Status', 'Original recommendation', 'Action'], visibleApprovals.map(row => `<tr><td>${esc(row.type)}</td><td>${esc(row.partNo || row.subject || '')}</td><td>${esc(row.status || 'Pending')}</td><td>${esc(row.originalRecommendation || '')}</td><td>${row.status === 'Pending' ? actionButton('Review', `componentBiReviewApproval('${esc(row.id)}')`) : esc(row.status || '')}</td></tr>`).join(''), 'No matching approval records.')}<div class="g3 cm-mobile-stack"><select class="fi" id="cm-bi-approval-type"><option value="substitute">Substitute approval</option><option value="critical-reorder">Critical reorder approval</option><option value="anomaly-acknowledgement">High-risk anomaly acknowledgement</option><option value="forecast-override">Manual forecast override</option><option value="order-quantity-override">Suggested order quantity override</option></select>${actionButton('Request approval', 'componentBiRequestSelectedApproval()', true)}</div>`, 'cm-bi-approvals')}${card('Scheduled BI Reports', `<div class="g3 cm-mobile-stack"><select class="fi" id="cm-bi-report-type"><option>Daily risk summary</option><option>Weekly usage report</option><option>Monthly consumption report</option><option>Critical stock alert</option><option>Anomaly summary</option></select><select class="fi" id="cm-bi-report-frequency"><option>Daily</option><option>Weekly</option><option>Monthly</option></select>${actionButton('Save schedule', 'componentBiSaveSchedule()', true)}</div>${table(['Report', 'Frequency', 'Next run', 'Status', 'Download'], scheduleRows, 'No schedules configured. Reports can be generated in-app and downloaded.')}`)}${card('Data Freshness', `${freshnessRows ? table(['Source', 'Latest source timestamp', 'Status'], freshnessRows) : '<div class="alrt alrt-y">No source timestamps are available. Freshness is not tracked.</div>'}<div class="alrt alrt-b">A stale source is not replaced with a fabricated “just now” value.</div>`)}${card('AI Recommendation Feedback', `<div class="g3 cm-mobile-stack"><select class="fi" id="cm-bi-feedback-type"><option>Useful</option><option>Not useful</option><option>Dismiss</option><option>Correct recommendation</option></select><input class="fi" id="cm-bi-feedback-comment" placeholder="Comment (optional)">${actionButton('Save feedback', 'componentBiSaveFeedback()', true)}</div><div class="alrt alrt-b">Feedback is persisted for future rule tuning; no external model training or external AI API is used.</div>`)}`;
  }

  async function createApproval(type, partNo = '', originalRecommendation = '', newValue = '', comment = '') {
    if (!can('reports')) {return null;}
    const record = {id: `bi-approval:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`, type, partNo, originalRecommendation, newValue, comment, status: 'Pending', user: userName(), userId: currentUser().id || null, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()};
    await window.dPut(STORES.approvals, record); if (typeof window.addAudit === 'function') {await window.addAudit('SHANK_BI_APPROVAL_REQUESTED', `Approval requested: ${type}`, partNo, record);} return record;
  }
  async function saveFeedback() { const record = {id: `bi-feedback:${Date.now()}`, type: document.getElementById('cm-bi-feedback-type')?.value || 'Useful', comment: document.getElementById('cm-bi-feedback-comment')?.value || '', user: userName(), userId: currentUser().id || null, createdAt: new Date().toISOString()}; await window.dPut(STORES.feedback, record); if (typeof window.addAudit === 'function') {await window.addAudit('SHANK_BI_RECOMMENDATION_FEEDBACK', `Recommendation feedback: ${record.type}`, 'shank-mapping-bi', record);} window.toastMsg?.('Feedback saved', 'suc'); }
  async function saveSchedule() { const record = {id: `bi-schedule:${document.getElementById('cm-bi-report-type')?.value}`, reportType: document.getElementById('cm-bi-report-type')?.value, frequency: document.getElementById('cm-bi-report-frequency')?.value, status: 'Active', updatedAt: new Date().toISOString(), user: userName()}; await window.dPut(STORES.schedules, record); if (typeof window.addAudit === 'function') {await window.addAudit('SHANK_BI_REPORT_SCHEDULED', `Scheduled report: ${record.reportType}`, record.id, record);} window.toastMsg?.('Report schedule saved', 'suc'); }
  async function downloadReport(reportType) { const data = await loadProductionData(); const content = JSON.stringify({reportType, generatedAt: new Date().toISOString(), approvals: data.approvals, mappings: data.mappings, anomalies: data.anomalies, transactions: data.transactions}, null, 2); const blob = new Blob([content], {type: 'application/json'}); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `shank-mapping-${String(reportType).toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${today()}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); }

  root.ShankMappingBIProduction = {render, simulate, forecastAccuracy, maintenanceCorrelation, freshness, actionCenter, createApproval, approvalRowsForSubject};
  if (typeof module !== 'undefined') {module.exports = {simulate, forecastAccuracy, maintenanceCorrelation, freshness, actionCenter, approvalRowsForSubject};}
  root.componentBiRunSimulation = async function () { const part = document.getElementById('cm-bi-simulation-part')?.value; const output = document.getElementById('cm-bi-simulation-output'); if (!part || !output) {return;} const forecasts = window.componentConsumptionAnalyticsState?.forecasts || []; const forecast = forecasts.find(row => row.partNo === part); if (!forecast) { output.textContent = 'Select a forecastable part to simulate.'; return; } const result = simulate(forecast, {usageChange: document.getElementById('cm-bi-usage-change')?.value, leadTime: document.getElementById('cm-bi-lead-time')?.value, stockAdjustment: document.getElementById('cm-bi-stock-adjustment')?.value, safetyAdjustment: document.getElementById('cm-bi-safety-adjustment')?.value, period: document.getElementById('cm-bi-simulation-period')?.value}); output.innerHTML = `<strong>${esc(result.partNo)}</strong>: simulated daily usage ${result.simulatedDailyUsage.toFixed(2)}, expected zero-stock date ${esc(result.expectedZeroDate || 'Not projected')}, risk ${esc(result.simulatedRiskLevel)}, suggested order ${result.suggestedOrderQuantity}. ${esc(result.explanation)}`; };
  root.componentBiOpenStock = part => { if (can('stock') && typeof window.componentOpen === 'function') {window.componentBiNavigationContext = {partNo: String(part || '')}; window.componentOpen('stock');} };
  root.componentBiCreateOrder = part => { window.componentBiNavigationContext = {partNo: String(part || '')}; if (can('procurement') && typeof window.componentOpenProcurement === 'function') {window.componentOpenProcurement();} else if (typeof window.componentOpen === 'function') {window.componentOpen('procurement');} };
  root.componentBiOpenStation = station => { if (typeof window.componentOpen === 'function') {window.componentBiNavigationContext = {stationNo: String(station || '')}; window.componentOpen('matrix');} };
  root.componentBiOpenMappingReview = station => { if (typeof window.componentOpen === 'function') {window.componentBiNavigationContext = {stationNo: String(station || '')}; window.componentOpen('matrix');} };
  root.componentBiOpenAnomaly = part => { if (typeof window.componentConsumptionAnalyticsDetail === 'function' && part) {window.componentConsumptionAnalyticsDetail(part);} else if (typeof window.componentOpen === 'function') {window.componentOpen('history');} };
  root.componentBiOpenApprovals = async subject => { window.componentBiNavigationContext = {approvalSubject: String(subject || '')}; if (typeof window.componentConsumptionAnalyticsOpen === 'function') {await window.componentConsumptionAnalyticsOpen(); document.getElementById('cm-bi-approvals')?.scrollIntoView?.({behavior: 'smooth', block: 'start'});} else if (typeof window.componentOpen === 'function') {window.componentOpen('bi-dashboard');} };
  root.componentBiOpenPart = part => { if (typeof window.componentOpen === 'function') {window.componentBiNavigationContext = {partNo: String(part || '')}; window.componentOpen('parts');} };
  root.componentBiRequestSelectedApproval = async () => { const type = document.getElementById('cm-bi-approval-type')?.value || 'critical-reorder'; await root.componentBiRequestApproval(type); };
  root.componentBiRequestApproval = async type => { await createApproval(type, '', 'Review source-based Shank Mapping BI recommendation', '', ''); window.toastMsg?.('Approval request created', 'suc'); };
  root.componentBiSaveFeedback = saveFeedback;
  root.componentBiSaveSchedule = saveSchedule;
  root.componentBiDownloadReport = downloadReport;
  root.componentBiReviewApproval = async id => { const rows = await safeAll(STORES.approvals); const row = rows.find(item => item.id === id); if (!row) {return;} const decision = window.prompt('Decision: Approved or Rejected', 'Approved'); if (!decision || !['Approved', 'Rejected'].includes(decision)) {return;} const comment = window.prompt('Reason/comment', '') || ''; row.status = decision; row.comment = comment; row.updatedAt = new Date().toISOString(); row.decidedBy = userName(); row.decidedAt = row.updatedAt; await window.dPut(STORES.approvals, row); if (typeof window.addAudit === 'function') {await window.addAudit('SHANK_BI_APPROVAL_DECISION', `${decision}: ${row.type}`, row.id, row);} window.toastMsg?.(`Approval ${decision.toLowerCase()}`, 'suc'); };
  if (typeof window !== 'undefined') {
    window.componentBiRunSimulation = root.componentBiRunSimulation;
    window.componentBiOpenStock = root.componentBiOpenStock;
    window.componentBiCreateOrder = root.componentBiCreateOrder;
    window.componentBiOpenStation = root.componentBiOpenStation;
    window.componentBiOpenMappingReview = root.componentBiOpenMappingReview;
    window.componentBiOpenAnomaly = root.componentBiOpenAnomaly;
    window.componentBiOpenApprovals = root.componentBiOpenApprovals;
    window.componentBiOpenPart = root.componentBiOpenPart;
    window.componentBiRequestApproval = root.componentBiRequestApproval;
    window.componentBiSaveFeedback = root.componentBiSaveFeedback;
    window.componentBiRequestSelectedApproval = root.componentBiRequestSelectedApproval;
    window.componentBiSaveSchedule = root.componentBiSaveSchedule;
    window.componentBiDownloadReport = root.componentBiDownloadReport;
    window.componentBiReviewApproval = root.componentBiReviewApproval;
  }
}());
