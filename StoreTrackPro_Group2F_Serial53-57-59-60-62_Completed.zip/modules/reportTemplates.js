// Custom Report Templates Module - Reusable report templates

/**
 * Report Template class
 */
class ReportTemplate {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.name = config.name || 'Untitled Template';
    this.description = config.description || '';
    this.category = config.category || 'general';
    this.dataSource = config.dataSource || 'materials';
    this.layout = config.layout || 'table'; // table, summary, chart, custom
    this.columns = config.columns || [];
    this.filters = config.filters || [];
    this.sorting = config.sorting || [];
    this.grouping = config.grouping || null;
    this.aggregations = config.aggregations || [];
    this.style = config.style || {};
    this.isSystem = config.isSystem || false;
    this.isPublic = config.isPublic || false;
    this.createdBy = config.createdBy || null;
    this.createdAt = config.createdAt || new Date().toISOString();
    this.updatedAt = config.updatedAt || new Date().toISOString();
  }

  generateId() {
    return `template-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Report Template Manager
 */
class ReportTemplateManager {
  constructor() {
    this.templates = new Map();
    if (window.databaseReady) {
      this.init();
    } else {
      document.addEventListener('databaseReady', () => this.init(), { once: true });
    }
  }

  /**
   * Initialize template manager
   */
  async init() {
    await this.loadTemplates();
    await this.ensureDefaultTemplates();
  }

  /**
   * Load templates from storage
   */
  async loadTemplates() {
    try {
      const templates = await gAll('report_templates');
      templates.forEach(t => {
        this.templates.set(t.id, new ReportTemplate(t));
      });
    } catch (err) {
      console.error('Failed to load report templates:', err);
    }
  }

  /**
   * Ensure default templates exist
   */
  async ensureDefaultTemplates() {
    const defaultTemplates = [
      {
        name: 'Inventory Summary',
        description: 'Summary of all inventory items',
        category: 'inventory',
        dataSource: 'materials',
        layout: 'table',
        columns: [
          { field: 'barcode', label: 'Barcode', width: 120 },
          { field: 'name', label: 'Name', width: 200 },
          { field: 'category', label: 'Category', width: 100 },
          { field: 'stock', label: 'Current Stock', width: 100, align: 'right' },
          { field: 'lowAlert', label: 'Low Alert', width: 80, align: 'right' },
          { field: 'unitCost', label: 'Unit Cost', width: 100, align: 'right', format: 'currency' }
        ],
        sorting: [{ field: 'name', direction: 'asc' }],
        isSystem: true,
        isPublic: true
      },
      {
        name: 'Low Stock Report',
        description: 'Items with low stock levels',
        category: 'inventory',
        dataSource: 'materials',
        layout: 'table',
        columns: [
          { field: 'barcode', label: 'Barcode', width: 120 },
          { field: 'name', label: 'Name', width: 200 },
          { field: 'stock', label: 'Current Stock', width: 100, align: 'right', highlight: 'low' },
          { field: 'lowAlert', label: 'Low Alert', width: 80, align: 'right' },
          { field: 'reorderQty', label: 'Reorder Qty', width: 100, align: 'right', calculated: true }
        ],
        filters: [
          { field: 'stock', operator: 'lte', value: 'lowAlert' }
        ],
        sorting: [{ field: 'stock', direction: 'asc' }],
        isSystem: true,
        isPublic: true
      },
      {
        name: 'Transaction History',
        description: 'History of all transactions',
        category: 'transactions',
        dataSource: 'transactions',
        layout: 'table',
        columns: [
          { field: 'time', label: 'Date/Time', width: 150, format: 'datetime' },
          { field: 'barcode', label: 'Barcode', width: 120 },
          { field: 'itemName', label: 'Item Name', width: 200 },
          { field: 'type', label: 'Type', width: 80 },
          { field: 'qty', label: 'Quantity', width: 100, align: 'right' },
          { field: 'user', label: 'User', width: 100 }
        ],
        sorting: [{ field: 'time', direction: 'desc' }],
        isSystem: true,
        isPublic: true
      },
      {
        name: 'Stock Value Summary',
        description: 'Total value of inventory by category',
        category: 'inventory',
        dataSource: 'materials',
        layout: 'summary',
        grouping: 'category',
        aggregations: [
          { field: 'stock', operation: 'sum', label: 'Total Stock' },
          { field: 'value', operation: 'sum', label: 'Total Value' }
        ],
        isSystem: true,
        isPublic: true
      },
      {
        name: 'Daily Transaction Summary',
        description: 'Daily transaction summary',
        category: 'transactions',
        dataSource: 'transactions',
        layout: 'summary',
        grouping: 'date',
        aggregations: [
          { field: 'qty', operation: 'sum', label: 'Total Quantity' },
          { field: 'type', operation: 'count', label: 'Transaction Count' }
        ],
        isSystem: true,
        isPublic: true
      }
    ];

    for (const templateConfig of defaultTemplates) {
      const existing = Array.from(this.templates.values()).find(t => t.name === templateConfig.name);
      if (!existing) {
        const template = new ReportTemplate(templateConfig);
        this.templates.set(template.id, template);
        await this.saveTemplate(template);
      }
    }
  }

  /**
   * Create template
   * @param {object} config - Template configuration
   * @returns {ReportTemplate} - Created template
   */
  async createTemplate(config) {
    const template = new ReportTemplate(config);
    this.templates.set(template.id, template);
    await this.saveTemplate(template);
    return template;
  }

  /**
   * Update template
   * @param {string} id - Template ID
   * @param {object} updates - Updates to apply
   * @returns {ReportTemplate} - Updated template
   */
  async updateTemplate(id, updates) {
    const template = this.templates.get(id);
    if (template && !template.isSystem) {
      Object.assign(template, updates);
      template.updatedAt = new Date().toISOString();
      await this.saveTemplate(template);
    }
    return template;
  }

  /**
   * Delete template
   * @param {string} id - Template ID
   */
  async deleteTemplate(id) {
    const template = this.templates.get(id);
    if (template && !template.isSystem) {
      this.templates.delete(id);
      await dDel('report_templates', id);
    }
  }

  /**
   * Get template
   * @param {string} id - Template ID
   * @returns {ReportTemplate} - Template
   */
  getTemplate(id) {
    return this.templates.get(id);
  }

  /**
   * Get all templates
   * @returns {Array} - Array of templates
   */
  getAllTemplates() {
    return Array.from(this.templates.values());
  }

  /**
   * Get templates by category
   * @param {string} category - Category name
   * @returns {Array} - Templates in category
   */
  getTemplatesByCategory(category) {
    return this.getAllTemplates().filter(t => t.category === category);
  }

  /**
   * Get public templates
   * @returns {Array} - Public templates
   */
  getPublicTemplates() {
    return this.getAllTemplates().filter(t => t.isPublic);
  }

  /**
   * Get user templates
   * @param {string} userId - User ID
   * @returns {Array} - User's templates
   */
  getUserTemplates(userId) {
    return this.getAllTemplates().filter(t => t.createdBy === userId);
  }

  /**
   * Save template to storage
   * @param {ReportTemplate} template - Template to save
   */
  async saveTemplate(template) {
    try {
      await dPut('report_templates', template);
    } catch (err) {
      console.error('Failed to save report template:', err);
    }
  }

  /**
   * Generate report from template
   * @param {string} templateId - Template ID
   * @param {object} overrides - Override parameters
   * @returns {Promise<object>} - Generated report
   */
  async generateReport(templateId, overrides = {}) {
    const template = this.templates.get(templateId);
    if (!template) {
      throw new Error('Template not found');
    }

    // Fetch data
    let data = [];
    try {
      data = await gAll(template.dataSource);
      if (template.dataSource === 'materials') {
        data = data.map(item => {
          const stock = Number(item.stock ?? item.currentStock ?? 0) || 0;
          const lowAlert = Number(item.lowAlert ?? item.minStock ?? 0) || 0;
          const unitCost = Number(item.unitCost ?? item.unitPrice ?? item.price ?? 0) || 0;
          return { ...item, stock, lowAlert, unitCost, value: stock * unitCost };
        });
      } else if (template.dataSource === 'transactions') {
        data = data.map(item => {
          const timestamp = item.time ?? item.timestamp ?? item.date ?? item.createdAt;
          const parsed = timestamp ? new Date(timestamp) : null;
          const date = parsed && Number.isFinite(parsed.getTime()) ? parsed.toISOString().slice(0, 10) : '';
          return { ...item, qty: Number(item.qty ?? item.quantity ?? 0) || 0, date };
        });
      }
    } catch (err) {
      console.error('Failed to fetch data:', err);
    }

    // Apply filters
    if (template.filters.length > 0) {
      data = this.applyFilters(data, template.filters);
    }

    // Apply sorting
    if (template.sorting.length > 0) {
      data = this.applySorting(data, template.sorting);
    }

    // Apply grouping and aggregations
    let reportData = data;
    if (template.grouping) {
      reportData = this.applyGrouping(data, template.grouping, template.aggregations);
    }

    // Apply calculated fields
    reportData = this.applyCalculatedFields(reportData, template.columns);

    return {
      template: {
        id: template.id,
        name: template.name,
        description: template.description
      },
      data: reportData,
      columns: template.columns,
      layout: template.layout,
      generatedAt: new Date().toISOString(),
      recordCount: Array.isArray(reportData) ? reportData.length : Object.keys(reportData).length
    };
  }

  /**
   * Apply filters to data
   * @param {Array} data - Data to filter
   * @param {Array} filters - Filters to apply
   * @returns {Array} - Filtered data
   */
  applyFilters(data, filters) {
    return data.filter(item => {
      return filters.every(filter => {
        const value = item[filter.field];
        const filterValue = filter.value;

        switch (filter.operator) {
          case 'eq':
            return value === filterValue;
          case 'neq':
            return value !== filterValue;
          case 'contains':
            return String(value).toLowerCase().includes(String(filterValue).toLowerCase());
          case 'gt':
            return value > filterValue;
          case 'gte':
            return value >= filterValue;
          case 'lt':
            return value < filterValue;
          case 'lte':
            // Special case for comparing to another field
            if (typeof filterValue === 'string' && Object.prototype.hasOwnProperty.call(item, filterValue)) {
              const left = Number(value);
              const right = Number(item[filterValue]);
              return Number.isFinite(left) && Number.isFinite(right) && left <= right;
            }
            return value <= filterValue;
          default:
            return true;
        }
      });
    });
  }

  /**
   * Apply sorting to data
   * @param {Array} data - Data to sort
   * @param {Array} sorting - Sorting rules
   * @returns {Array} - Sorted data
   */
  applySorting(data, sorting) {
    return [...data].sort((a, b) => {
      for (const rule of sorting) {
        const valA = a[rule.field];
        const valB = b[rule.field];
        let result = 0;

        if (valA < valB) {result = -1;}
        if (valA > valB) {result = 1;}

        if (rule.direction === 'desc') {result = -result;}
        if (result !== 0) {return result;}
      }
      return 0;
    });
  }

  /**
   * Apply grouping and aggregations
   * @param {Array} data - Data to group
   * @param {string} groupField - Field to group by
   * @param {Array} aggregations - Aggregations to apply
   * @returns {object} - Grouped data
   */
  applyGrouping(data, groupField, aggregations) {
    const groups = {};

    data.forEach(item => {
      let groupKey = item[groupField];
      if (groupField === 'date') {
        const timestamp = item.date ?? item.time ?? item.timestamp ?? item.createdAt;
        const parsed = timestamp ? new Date(timestamp) : null;
        groupKey = parsed && Number.isFinite(parsed.getTime()) ? parsed.toISOString().slice(0, 10) : '';
      }
      groupKey = groupKey || 'Uncategorized';
      if (!groups[groupKey]) {
        groups[groupKey] = [];
      }
      groups[groupKey].push(item);
    });

    const result = {};
    Object.entries(groups).forEach(([key, items]) => {
      result[key] = {
        group: key,
        count: items.length
      };

      aggregations.forEach(agg => {
        switch (agg.operation) {
          case 'sum':
            result[key][agg.label] = items.reduce((sum, item) => sum + (Number(item[agg.field]) || 0), 0);
            break;
          case 'avg':
            result[key][agg.label] = items.reduce((sum, item) => sum + (item[agg.field] || 0), 0) / items.length;
            break;
          case 'count':
            result[key][agg.label] = items.length;
            break;
          case 'min':
            result[key][agg.label] = Math.min(...items.map(i => i[agg.field] || 0));
            break;
          case 'max':
            result[key][agg.label] = Math.max(...items.map(i => i[agg.field] || 0));
            break;
        }
      });
    });

    return result;
  }

  /**
   * Apply calculated fields
   * @param {Array|object} data - Data to process
   * @param {Array} columns - Column definitions
   * @returns {Array|object} - Data with calculated fields
   */
  applyCalculatedFields(data, columns) {
    if (!Array.isArray(data)) {return data;}

    return data.map(item => {
      const result = { ...item };

      columns.forEach(col => {
        if (col.calculated) {
          switch (col.field) {
            case 'reorderQty':
              result[col.field] = Math.max(0, Number(item.lowAlert ?? item.minStock ?? 0) - Number(item.stock ?? item.currentStock ?? 0));
              break;
            case 'totalValue':
              result[col.field] = Number(item.stock ?? item.currentStock ?? 0) * Number(item.unitCost ?? item.unitPrice ?? 0);
              break;
          }
        }
      });

      return result;
    });
  }

  /**
   * Duplicate template
   * @param {string} id - Template ID to duplicate
   * @param {string} newName - New template name
   * @returns {ReportTemplate} - Duplicated template
   */
  async duplicateTemplate(id, newName) {
    const original = this.templates.get(id);
    if (!original) {
      throw new Error('Template not found');
    }

    const duplicate = new ReportTemplate({
      ...original,
      id: undefined,
      name: newName || `${original.name} (Copy)`,
      isSystem: false
    });

    this.templates.set(duplicate.id, duplicate);
    await this.saveTemplate(duplicate);

    return duplicate;
  }

  /**
   * Export template
   * @param {string} id - Template ID
   * @returns {string} - JSON export
   */
  exportTemplate(id) {
    const template = this.templates.get(id);
    if (template) {
      return JSON.stringify(template, null, 2);
    }
    return null;
  }

  /**
   * Import template
   * @param {string} json - JSON template
   * @returns {ReportTemplate} - Imported template
   */
  async importTemplate(json) {
    try {
      const data = JSON.parse(json);
      const template = new ReportTemplate({
        ...data,
        id: undefined,
        isSystem: false
      });

      this.templates.set(template.id, template);
      await this.saveTemplate(template);

      return template;
    } catch (err) {
      console.error('Failed to import template:', err);
      return null;
    }
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const templates = this.getAllTemplates();
    return {
      total: templates.length,
      system: templates.filter(t => t.isSystem).length,
      custom: templates.filter(t => !t.isSystem).length,
      public: templates.filter(t => t.isPublic).length,
      byCategory: this.getCategoryCounts()
    };
  }

  /**
   * Get category counts
   * @returns {object} - Category counts
   */
  getCategoryCounts() {
    const counts = {};
    this.getAllTemplates().forEach(t => {
      counts[t.category] = (counts[t.category] || 0) + 1;
    });
    return counts;
  }
}

/**
 * Global template manager instance
 */
const reportTemplateManager = new ReportTemplateManager();

/**
 * Initialize report templates
 */
async function initReportTemplates() {
  // Wait for database to be ready
  if (!window.databaseReady) {
    await new Promise(resolve => {
      document.addEventListener('databaseReady', resolve, { once: true });
    });
  }
  await reportTemplateManager.init();
  return reportTemplateManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.ReportTemplates = {
    manager: reportTemplateManager,
    init: initReportTemplates,
    create: (config) => reportTemplateManager.createTemplate(config),
    update: (id, updates) => reportTemplateManager.updateTemplate(id, updates),
    delete: (id) => reportTemplateManager.deleteTemplate(id),
    get: (id) => reportTemplateManager.getTemplate(id),
    getAll: () => reportTemplateManager.getAllTemplates(),
    getByCategory: (cat) => reportTemplateManager.getTemplatesByCategory(cat),
    getPublic: () => reportTemplateManager.getPublicTemplates(),
    getUser: (userId) => reportTemplateManager.getUserTemplates(userId),
    generate: (id, overrides) => reportTemplateManager.generateReport(id, overrides),
    duplicate: (id, name) => reportTemplateManager.duplicateTemplate(id, name),
    export: (id) => reportTemplateManager.exportTemplate(id),
    import: (json) => reportTemplateManager.importTemplate(json),
    getStats: () => reportTemplateManager.getStatistics()
  };
}
