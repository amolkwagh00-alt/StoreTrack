// Advanced Lazy Loading Module - Enhanced lazy loading with prefetching

/**
 * Lazy Load Config class
 */
class LazyLoadConfig {
  constructor(config) {
    this.selector = config.selector || '[data-lazy]';
    this.rootMargin = config.rootMargin || '50px';
    this.threshold = config.threshold || 0.1;
    this.loadImmediately = config.loadImmediately || false;
    this.prefetch = config.prefetch !== false;
    this.prefetchDistance = config.prefetchDistance || 200;
    this.placeholder = config.placeholder || null;
    this.onLoad = config.onLoad || null;
    this.onError = config.onError || null;
  }
}

/**
 * Advanced Lazy Load Manager
 */
class AdvancedLazyLoadManager {
  constructor() {
    this.observers = new Map();
    this.prefetchObserver = null;
    this.loadedElements = new Set();
    this.prefetchedElements = new Set();
    this.config = new LazyLoadConfig({});
    this.init();
  }

  /**
   * Initialize advanced lazy loading
   */
  async init() {
    this.setupMainObserver();
    this.setupPrefetchObserver();
    this.observeExistingElements();
  }

  /**
   * Setup main intersection observer
   */
  setupMainObserver() {
    this.observer = new IntersectionObserver(
      (entries) => this.handleIntersection(entries),
      {
        rootMargin: this.config.rootMargin,
        threshold: this.config.threshold
      }
    );
  }

  /**
   * Setup prefetch observer
   */
  setupPrefetchObserver() {
    if (this.config.prefetch) {
      this.prefetchObserver = new IntersectionObserver(
        (entries) => this.handlePrefetch(entries),
        {
          rootMargin: `${this.config.prefetchDistance}px`,
          threshold: 0
        }
      );
    }
  }

  /**
   * Observe existing elements
   */
  observeExistingElements() {
    const elements = document.querySelectorAll(this.config.selector);
    elements.forEach(el => this.observe(el));
  }

  /**
   * Observe element
   * @param {HTMLElement} element - Element to observe
   */
  observe(element) {
    if (this.loadedElements.has(element)) {return;}

    this.observer.observe(element);

    if (this.prefetchObserver) {
      this.prefetchObserver.observe(element);
    }
  }

  /**
   * Unobserve element
   * @param {HTMLElement} element - Element to unobserve
   */
  unobserve(element) {
    this.observer.unobserve(element);
    if (this.prefetchObserver) {
      this.prefetchObserver.unobserve(element);
    }
  }

  /**
   * Handle intersection
   * @param {Array} entries - Intersection entries
   */
  handleIntersection(entries) {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        this.loadElement(entry.target);
        this.unobserve(entry.target);
      }
    }
  }

  /**
   * Handle prefetch
   * @param {Array} entries - Intersection entries
   */
  handlePrefetch(entries) {
    for (const entry of entries) {
      if (entry.isIntersecting && !this.prefetchedElements.has(entry.target)) {
        this.prefetchElement(entry.target);
        this.prefetchedElements.add(entry.target);
      }
    }
  }

  /**
   * Load element
   * @param {HTMLElement} element - Element to load
   */
  async loadElement(element) {
    if (this.loadedElements.has(element)) {return;}

    const src = element.dataset.src || element.dataset.lazySrc;
    const srcset = element.dataset.srcset || element.dataset.lazySrcset;
    const type = element.dataset.lazyType || 'image';

    try {
      switch (type) {
        case 'image':
          await this.loadImage(element, src, srcset);
          break;
        case 'background':
          await this.loadBackground(element, src);
          break;
        case 'iframe':
          await this.loadIframe(element, src);
          break;
        case 'script':
          await this.loadScript(element, src);
          break;
        case 'component':
          await this.loadComponent(element, src);
          break;
        default:
          await this.loadGeneric(element, src);
      }

      this.loadedElements.add(element);
      element.classList.add('lazy-loaded');
      element.classList.remove('lazy-loading');

      if (this.config.onLoad) {
        this.config.onLoad(element);
      }

    } catch (err) {
      console.error('Failed to load lazy element:', err);
      element.classList.add('lazy-error');

      if (this.config.onError) {
        this.config.onError(element, err);
      }
    }
  }

  /**
   * Prefetch element
   * @param {HTMLElement} element - Element to prefetch
   */
  async prefetchElement(element) {
    const src = element.dataset.src || element.dataset.lazySrc;
    if (!src) {return;}

    try {
      const link = document.createElement('link');
      link.rel = 'prefetch';
      link.href = src;
      link.as = element.dataset.lazyType === 'image' ? 'image' : 'fetch';
      document.head.appendChild(link);

      // Remove after prefetch
      setTimeout(() => {
        link.remove();
      }, 5000);
    } catch (err) {
      console.error('Failed to prefetch:', err);
    }
  }

  /**
   * Load image
   * @param {HTMLElement} element - Image element
   * @param {string} src - Image source
   * @param {string} srcset - Image source set
   */
  loadImage(element, src, srcset) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      
      img.onload = () => {
        if (element.tagName === 'IMG') {
          element.src = src;
          if (srcset) {element.srcset = srcset;}
        } else {
          element.style.backgroundImage = `url(${src})`;
        }
        resolve();
      };

      img.onerror = () => {
        reject(new Error('Failed to load image'));
      };

      img.src = src;
    });
  }

  /**
   * Load background
   * @param {HTMLElement} element - Element with background
   * @param {string} src - Background image source
   */
  loadBackground(element, src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      
      img.onload = () => {
        element.style.backgroundImage = `url(${src})`;
        resolve();
      };

      img.onerror = () => {
        reject(new Error('Failed to load background'));
      };

      img.src = src;
    });
  }

  /**
   * Load iframe
   * @param {HTMLElement} element - Iframe element
   * @param {string} src - Iframe source
   */
  loadIframe(element, src) {
    return new Promise((resolve, reject) => {
      element.src = src;
      element.onload = resolve;
      element.onerror = () => reject(new Error('Failed to load iframe'));
    });
  }

  /**
   * Load script
   * @param {HTMLElement} element - Script element
   * @param {string} src - Script source
   */
  loadScript(element, src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.async = true;
      
      script.onload = () => {
        resolve();
      };

      script.onerror = () => {
        reject(new Error('Failed to load script'));
      };

      document.head.appendChild(script);
    });
  }

  /**
   * Load component
   * @param {HTMLElement} element - Container element
   * @param {string} src - Component URL
   */
  async loadComponent(element, src) {
    try {
      const response = await fetch(src);
      const html = await response.text();
      element.innerHTML = html;

      // Execute any scripts in the loaded HTML
      const scripts = element.querySelectorAll('script');
      scripts.forEach(script => {
        const newScript = document.createElement('script');
        newScript.textContent = script.textContent;
        document.head.appendChild(newScript);
      });
    } catch (err) {
      throw new Error('Failed to load component');
    }
  }

  /**
   * Load generic
   * @param {HTMLElement} element - Element
   * @param {string} src - Source
   */
  loadGeneric(element, src) {
    element.src = src;
    return Promise.resolve();
  }

  /**
   * Update config
   * @param {object} config - New config
   */
  updateConfig(config) {
    this.config = new LazyLoadConfig({ ...this.config, ...config });
    
    // Re-setup observers with new config
    this.observer.disconnect();
    if (this.prefetchObserver) {
      this.prefetchObserver.disconnect();
    }
    
    this.setupMainObserver();
    this.setupPrefetchObserver();
  }

  /**
   * Force load all
   */
  forceLoadAll() {
    const elements = document.querySelectorAll(this.config.selector);
    elements.forEach(el => {
      this.loadElement(el);
      this.unobserve(el);
    });
  }

  /**
   * Reset
   */
  reset() {
    this.observer.disconnect();
    if (this.prefetchObserver) {
      this.prefetchObserver.disconnect();
    }
    
    this.loadedElements.clear();
    this.prefetchedElements.clear();
    
    this.setupMainObserver();
    this.setupPrefetchObserver();
    this.observeExistingElements();
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const totalElements = document.querySelectorAll(this.config.selector).length;
    
    return {
      total: totalElements,
      loaded: this.loadedElements.size,
      prefetched: this.prefetchedElements.size,
      pending: totalElements - this.loadedElements.size,
      percentage: totalElements > 0 ? (this.loadedElements.size / totalElements) * 100 : 0
    };
  }
}

/**
 * Global advanced lazy load manager instance
 */
const advancedLazyLoadManager = new AdvancedLazyLoadManager();

/**
 * Initialize advanced lazy loading
 */
async function initAdvancedLazyLoading() {
  await advancedLazyLoadManager.init();
  return advancedLazyLoadManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.AdvancedLazyLoad = {
    manager: advancedLazyLoadManager,
    init: initAdvancedLazyLoading,
    observe: (el) => advancedLazyLoadManager.observe(el),
    unobserve: (el) => advancedLazyLoadManager.unobserve(el),
    updateConfig: (config) => advancedLazyLoadManager.updateConfig(config),
    forceLoadAll: () => advancedLazyLoadManager.forceLoadAll(),
    reset: () => advancedLazyLoadManager.reset(),
    getStats: () => advancedLazyLoadManager.getStatistics()
  };
}
