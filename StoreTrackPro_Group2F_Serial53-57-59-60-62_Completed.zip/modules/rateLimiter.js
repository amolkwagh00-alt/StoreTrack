// Rate Limiting Module - Prevent API abuse and brute force attacks

/**
 * Rate limiter configuration
 */
const RATE_LIMIT_CONFIG = {
  // Login attempts
  login: {
    maxAttempts: 5,
    windowMs: 15 * 60 * 1000, // 15 minutes
    blockDuration: 30 * 60 * 1000 // 30 minutes
  },
  // General API calls
  api: {
    maxRequests: 100,
    windowMs: 60 * 1000, // 1 minute
    blockDuration: 5 * 60 * 1000 // 5 minutes
  },
  // Data export operations
  export: {
    maxRequests: 10,
    windowMs: 60 * 1000, // 1 minute
    blockDuration: 10 * 60 * 1000 // 10 minutes
  },
  // Data import operations
  import: {
    maxRequests: 5,
    windowMs: 60 * 1000, // 1 minute
    blockDuration: 15 * 60 * 1000 // 15 minutes
  }
};

/**
 * Rate limiter class
 */
class RateLimiter {
  constructor(config) {
    this.config = config;
    this.attempts = new Map(); // key -> { count, resetTime, blockedUntil }
  }

  /**
   * Check if request is allowed
   * @param {string} key - Identifier (e.g., username, IP)
   * @returns {object} - { allowed: boolean, remaining: number, resetTime: number, blockedUntil: number }
   */
  check(key) {
    const now = Date.now();
    const record = this.attempts.get(key);

    // If blocked, check if block duration has expired
    if (record && record.blockedUntil && record.blockedUntil > now) {
      return {
        allowed: false,
        remaining: 0,
        resetTime: record.blockedUntil,
        blockedUntil: record.blockedUntil
      };
    }

    // If no record or window expired, create new record
    if (!record || record.resetTime < now) {
      this.attempts.set(key, {
        count: 1,
        resetTime: now + this.config.windowMs,
        blockedUntil: null
      });
      return {
        allowed: true,
        remaining: this.config.maxAttempts - 1,
        resetTime: now + this.config.windowMs,
        blockedUntil: null
      };
    }

    // Increment count
    record.count++;

    // Check if limit exceeded
    if (record.count > this.config.maxAttempts) {
      // Block for configured duration
      record.blockedUntil = now + this.config.blockDuration;
      return {
        allowed: false,
        remaining: 0,
        resetTime: record.resetTime,
        blockedUntil: record.blockedUntil
      };
    }

    return {
      allowed: true,
      remaining: this.config.maxAttempts - record.count,
      resetTime: record.resetTime,
      blockedUntil: null
    };
  }

  /**
   * Reset rate limit for a key
   * @param {string} key - Identifier to reset
   */
  reset(key) {
    this.attempts.delete(key);
  }

  /**
   * Clear all rate limit records
   */
  clear() {
    this.attempts.clear();
  }

  /**
   * Get current status for a key
   * @param {string} key - Identifier
   * @returns {object} - Current status
   */
  getStatus(key) {
    const record = this.attempts.get(key);
    if (!record) {
      return {
        count: 0,
        remaining: this.config.maxAttempts,
        resetTime: null,
        blockedUntil: null
      };
    }
    return {
      count: record.count,
      remaining: Math.max(0, this.config.maxAttempts - record.count),
      resetTime: record.resetTime,
      blockedUntil: record.blockedUntil
    };
  }
}

/**
 * Rate limiter instances
 */
const limiters = {
  login: new RateLimiter(RATE_LIMIT_CONFIG.login),
  api: new RateLimiter(RATE_LIMIT_CONFIG.api),
  export: new RateLimiter(RATE_LIMIT_CONFIG.export),
  import: new RateLimiter(RATE_LIMIT_CONFIG.import)
};

/**
 * Check login rate limit
 * @param {string} username - Username to check
 * @returns {object} - Rate limit status
 */
function checkLoginLimit(username) {
  return limiters.login.check(username);
}

/**
 * Check API rate limit
 * @param {string} identifier - IP or session identifier
 * @returns {object} - Rate limit status
 */
function checkApiLimit(identifier) {
  return limiters.api.check(identifier);
}

/**
 * Check export rate limit
 * @param {string} identifier - User or session identifier
 * @returns {object} - Rate limit status
 */
function checkExportLimit(identifier) {
  return limiters.export.check(identifier);
}

/**
 * Check import rate limit
 * @param {string} identifier - User or session identifier
 * @returns {object} - Rate limit status
 */
function checkImportLimit(identifier) {
  return limiters.import.check(identifier);
}

/**
 * Reset login rate limit (e.g., after successful login)
 * @param {string} username - Username to reset
 */
function resetLoginLimit(username) {
  limiters.login.reset(username);
}

/**
 * Get formatted time remaining
 * @param {number} ms - Milliseconds
 * @returns {string} - Formatted time string
 */
function formatTimeRemaining(ms) {
  if (!ms) {return '';}
  const seconds = Math.ceil(ms / 1000);
  if (seconds < 60) {return `${seconds}s`;}
  const minutes = Math.ceil(seconds / 60);
  return `${minutes}m`;
}

/**
 * Show rate limit error to user
 * @param {object} result - Rate limit check result
 * @param {string} operation - Operation being performed
 */
function showRateLimitError(result, operation = 'operation') {
  const timeRemaining = formatTimeRemaining(result.blockedUntil - Date.now());
  toast(`Too many ${operation} attempts. Please wait ${timeRemaining}.`, 'er');
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.RateLimiter = {
    checkLoginLimit,
    checkApiLimit,
    checkExportLimit,
    checkImportLimit,
    resetLoginLimit,
    formatTimeRemaining,
    showRateLimitError,
    limiters
  };
}
