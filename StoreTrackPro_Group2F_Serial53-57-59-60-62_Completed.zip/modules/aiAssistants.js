/* StoreTrack Pro AI Assistants
 * Offline-first, retrieval-based assistants. No external data is sent anywhere.
 * Every answer is generated only from records read from the current user's local DB.
 */
(function () {
  'use strict';

  const STORE_NAMES = [
    'materials', 'transactions', 'audit', 'users', 'component_parts',
    'component_mappings', 'component_stock', 'component_stock_transactions',
    'component_replacements', 'component_repair_scrap', 'component_audit_log', 'maintenance_people',
    'component_historical_consumption'
  ];

  const text = value => String(value == null ? '' : value).trim();
  const lower = value => text(value).toLocaleLowerCase();
  const num = value => Number.isFinite(Number(value)) ? Number(value) : 0;
  const dateOf = row => row?.replacementDateTime || row?.replacementDate || row?.date || row?.timestamp || row?.time || row?.createdAt || row?.updatedAt || '';
  const dayOf = row => text(dateOf(row)).slice(0, 10);
  const esc = value => text(value).replace(/[&<>'"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[ch]));
  const unique = values => [...new Set(values.filter(Boolean))];
  const source = (store, count, extra = '') => `Source: ${store} (${count} record${count === 1 ? '' : 's'})${extra ? `; ${extra}` : ''}.`;
  function clarification(question) {
    const q = text(question);
    if (!q) return 'कृपया Part No. किंवा stock, usage, replacement, repair याबद्दल प्रश्न विचारा.';
    if (/^(p[-\s]?\d+|part\s+\S+|[a-z]{1,6}[-_]\d+)$/i.test(q)) return 'तुम्हाला या Part चा current stock, location, usage, last replacement किंवा pending repair यापैकी काय जाणून घ्यायचे आहे?';
    return '';
  }

  function currentUser() {
    try {
      return window.stateManager?.get?.('session.currentUser') || window.__storeTrackCurrentUser || null;
    } catch (_) { return window.__storeTrackCurrentUser || null; }
  }

  async function readData() {
    const data = {};
    for (const store of STORE_NAMES) {
      try { data[store] = await window.gAll(store); } catch (_) { data[store] = []; }
    }
    return data;
  }

  function canUseAudit(user) { return ['admin', 'developer'].includes(lower(user?.role)); }

  async function logAIAction(action, details = {}) {
    const user = currentUser();
    const event = { id: `ai-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`, action, entityType: 'ai_assistant', userId: user?.id || user?.username || null, username: user?.username || null, role: user?.role || null, createdAt: new Date().toISOString(), ...details };
    try { if (typeof window.dPut === 'function') await window.dPut('audit', event); } catch (error) { console.warn('[AI audit] local log failed:', error.message); }
    try { if (window.centralBridge?.logAIEvent) await window.centralBridge.logAIEvent({ action, partNo: event.partNo, queryType: event.queryType, recordCount: event.recordCount, clientTimestamp: event.createdAt }); } catch (error) { console.info('[AI audit] central logging unavailable (offline mode):', error.message); }
  }

  function questionType(question) {
    const q = lower(question);
    if (/export|डाउनलोड/.test(q)) return 'export_guidance';
    if (/stock|साठा|उपलब्ध|माल/.test(q)) return 'stock';
    if (/replacement|बदल|वापरला/.test(q)) return 'replacement';
    if (/repair|दुरुस्ती/.test(q)) return 'repair';
    if (/where|कुठे|station|machine/.test(q)) return 'mapping';
    return 'general';
  }

  function partMatches(row, query) {
    const q = lower(query);
    return !q || [row.partNo, row.newPartNo, row.description, row.name, row.componentType, row.barcode].some(v => {
      const value = lower(v);
      return value && (value.includes(q) || q.includes(value));
    });
  }

  function buildContext(data) {
    const parts = data.component_parts || [];
    const stock = data.component_stock || [];
    const replacements = data.component_replacements || [];
    const repairs = data.component_repair_scrap || [];
    const historicalConsumption = data.component_historical_consumption || [];
    const mappings = data.component_mappings || [];
    const materials = data.materials || [];
    return { parts, stock, replacements, repairs, historicalConsumption, mappings, materials, transactions: data.transactions || [], audit: data.audit || [], users: data.users || [] };
  }

  function answerChat(question, data) {
    const q = lower(question);
    const c = buildContext(data);
    const requestedPart = c.parts.find(p => partMatches(p, question)) || c.materials.find(p => partMatches(p, question));
    const partNo = requestedPart?.partNo || requestedPart?.barcode;
    const clarify = clarification(question);
    if (clarify) return clarify;

    if (/(export|export कसा|report export|डाउनलोड)/i.test(q)) {
      return `Report export करण्यासाठी Reports / Consumption / Audit पेज उघडा आणि Export CSV किंवा Excel बटण वापरा. AI स्वतः file तयार करत नाही; अधिकृत application controls वापरा. ${source('application export controls', 0)}`;
    }
    if (/(current stock|stock किती|साठा|उपलब्ध|किती शिल्लक|माल किती|available stock)/i.test(q)) {
      if (partNo) {
        const rows = c.stock.filter(r => lower(r.partNo) === lower(partNo));
        const qty = rows.reduce((sum, r) => sum + num(r.quantity ?? r.stock), 0);
        const bins = unique(rows.map(r => r.binId || r.location));
        return `${partNo} चा current stock: ${qty} ${requestedPart.unit || 'units'}${bins.length ? `; Bin/Location: ${bins.join(', ')}` : ''}. ${source('component_stock', rows.length, bins.length ? `locations ${bins.join(', ')}` : '')}`;
      }
      const total = c.stock.reduce((sum, r) => sum + num(r.quantity ?? r.stock), 0) + c.materials.reduce((sum, r) => sum + num(r.stock), 0);
      return `Application मध्ये नोंदलेला aggregate stock: ${total} units. Specific Part No. दिल्यास bin-wise उत्तर देऊ शकतो. ${source('component_stock + materials', c.stock.length + c.materials.length)}`;
    }
    if (/(last replacement|replacement कधी|शेवटचा बदल|बदल कधी|शेवटचा वापर|last used)/i.test(q)) {
      const rows = c.replacements.filter(r => !partNo || lower(r.newPartNo || r.partNo) === lower(partNo)).sort((a, b) => String(dateOf(b)).localeCompare(String(dateOf(a))));
      if (!rows.length) return `${partNo || 'या Part'} साठी replacement record उपलब्ध नाही.`;
      const r = rows[0];
      return `${partNo || r.newPartNo || r.partNo} चे last replacement: ${dateOf(r) || 'date not recorded'}; Station: ${r.stationNo || '—'}; Gun/Machine: ${r.gunReferenceNo || r.machine || '—'}; Team: ${r.maintenanceTeam || '—'}. ${source('component_replacements', rows.length, `latest record ${dateOf(r) || 'undated'}`)}`;
    }
    if (/(repair pending|repair pending आहे|repair|दुरुस्ती)/i.test(q)) {
      const rows = c.repairs.filter(r => !partNo || lower(r.partNo) === lower(partNo));
      const pending = rows.filter(r => /pending|open|repair/i.test(lower(r.status || r.action)) && !/completed|closed|returned|scrap/i.test(lower(r.status)));
      return pending.length ? `${partNo || 'या Part'} साठी ${pending.length} repair record pending आहे. Latest reason: ${pending[0].reason || pending[0].repairReason || pending[0].remarks || 'कारण नोंदलेले नाही'}. ${source('component_repair_scrap', pending.length)}` : `${partNo || 'या Part'} साठी pending repair record सापडला नाही. ${source('component_repair_scrap', rows.length)}`;
    }
    if (/(where used|कुठे वापरला|वापरला|कुठे बसवला|कोणत्या station|which station)/i.test(q)) {
      if (!partNo) return 'कृपया Part No. किंवा component name द्या.';
      const mapped = c.mappings.filter(r => lower(r.partNo) === lower(partNo));
      const stations = unique(mapped.map(r => r.stationNo));
      const guns = unique(mapped.map(r => r.gunReferenceNo));
      return mapped.length ? `${partNo} वापर: ${stations.length ? `Station ${stations.join(', ')}` : 'Station record नाही'}; ${guns.length ? `Gun/Machine ${guns.join(', ')}` : 'Gun/Machine record नाही'}; mapping records: ${mapped.length}. ${source('component_mappings', mapped.length)}` : `${partNo} साठी application मध्ये mapping record सापडला नाही. ${source('component_mappings', 0)}`;
    }
    return 'मी फक्त StoreTrack Pro मधील authorized data वर उत्तर देतो. उदाहरणे: “Part P-101 कुठे वापरला आहे?”, “P-101 current stock किती?”, “last replacement कधी?”, “repair pending आहे का?”, “report export कसा करायचा?”';
  }

  function auditAnalysis(data) {
    const c = buildContext(data);
    const findings = [];
    const logs = [...c.audit, ...(data.component_audit_log || [])];
    const riskyWords = /delete|delete|adjust|password|role|import|export|scrap|approve|reject|reset|override/i;
    logs.filter(r => riskyWords.test(`${r.action} ${r.details} ${r.description}`)).slice(-100).forEach(r => findings.push({ severity: /password|role|delete|reset/i.test(`${r.action} ${r.details}`) ? 'HIGH' : 'MEDIUM', type: 'Risky transaction', text: `${r.userName || r.username || r.userId || 'Unknown user'} — ${r.action || 'change'} — ${r.details || r.description || 'no details'}`, date: dateOf(r), evidence: 1 }));
    const byDay = new Map();
    logs.forEach(r => { const day = dayOf(r); if (!day) return; if (!byDay.has(day)) byDay.set(day, []); byDay.get(day).push(r); });
    byDay.forEach((rows, day) => { const users = unique(rows.map(r => r.userName || r.username || r.userId)); if (rows.length >= 8 || users.length >= 3) findings.push({ severity: rows.length >= 15 ? 'HIGH' : 'MEDIUM', type: 'Same-day unusual change', text: `${day}: ${rows.length} audit events by ${users.join(', ')}`, date: day, evidence: rows.length }); });
    const stockByPart = new Map();
    c.stock.forEach(r => stockByPart.set(lower(r.partNo), (stockByPart.get(lower(r.partNo)) || 0) + num(r.quantity ?? r.stock)));
    c.parts.forEach(p => { const stock = stockByPart.get(lower(p.partNo)) || 0; const tx = c.replacements.filter(r => lower(r.newPartNo || r.partNo) === lower(p.partNo)).reduce((s, r) => s + num(r.quantity), 0); if (stock < 0 || (tx > 0 && stock === 0)) findings.push({ severity: stock < 0 ? 'HIGH' : 'MEDIUM', type: 'Possible stock mismatch', text: `${p.partNo}: stock ${stock}; replacement quantity recorded ${tx}. Check receiving, bin transfer, or delayed stock posting.`, date: '', evidence: 1 }); });
    const userCounts = new Map(); logs.forEach(r => { const u = r.userName || r.username || r.userId || 'Unknown'; userCounts.set(u, (userCounts.get(u) || 0) + 1); });
    const average = logs.length ? logs.length / Math.max(1, userCounts.size) : 0; userCounts.forEach((count, user) => { if (count > Math.max(10, average * 3)) findings.push({ severity: 'MEDIUM', type: 'User-wise unusual activity', text: `${user}: ${count} events, above the baseline of ${average.toFixed(1)} per user.`, date: '', evidence: 1 }); });
    return { findings, summary: `Audit scope: ${logs.length} events, ${c.users.length} users, ${findings.length} flagged items. Evidence counts are indicators for review, not proof of misconduct.` };
  }

  function rootCause(partNo, data) {
    const c = buildContext(data);
    const q = lower(partNo);
    const replacements = c.replacements.filter(r => lower(r.newPartNo || r.partNo) === q);
    const repairs = c.repairs.filter(r => lower(r.partNo) === q);
    const historical = (c.historicalConsumption || []).filter(r => lower(r.partNo) === q);
    const historicalRows = historical.map(r => ({ ...r, quantity: r.quantity ?? r.qty, replacementDate: r.replacementDate || r.date }));
    const dimensions = ['stationNo', 'gunReferenceNo', 'machine', 'maintenanceTeam', 'shift', 'reason', 'repairReason', 'scrapReason'];
    const breakdown = {};
    dimensions.forEach(key => { const counts = new Map(); [...replacements, ...repairs, ...historicalRows].forEach(r => { const value = text(r[key] || (key === 'reason' ? r.remarks : '') || 'Not recorded'); counts.set(value, (counts.get(value) || 0) + 1); }); breakdown[key] = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([value, count]) => ({ value, count })); });
    const replacementQty = [...replacements, ...historicalRows].reduce((s, r) => s + num(r.quantity || 1), 0);
    const days = unique([...replacements, ...historicalRows].map(dayOf));
    const possible = [];
    const top = key => breakdown[key]?.[0]?.value && breakdown[key][0].count >= 2;
    if (top('stationNo')) possible.push(`Station concentration: ${breakdown.stationNo[0].value} (${breakdown.stationNo[0].count} records)`);
    if (top('gunReferenceNo') || top('machine')) possible.push('Machine/Gun concentration suggests equipment-specific loading, alignment, or operating-condition review.');
    if (top('maintenanceTeam')) possible.push(`Maintenance-team concentration: ${breakdown.maintenanceTeam[0].value}`);
    if (top('shift')) possible.push(`Shift concentration: ${breakdown.shift[0].value}`);
    if (top('repairReason') || top('reason') || top('scrapReason')) possible.push('Repeated repair/scrap reason is a candidate failure mode; verify physically before corrective action.');
    if (days.length && replacementQty / days.length >= 2) possible.push(`High consumption frequency: ${replacementQty} units across ${days.length} recorded days.`);
    const confidence = replacements.length + repairs.length >= 10 ? 'High' : replacements.length + repairs.length >= 4 ? 'Medium' : 'Low';
    const dataQuality = replacements.length + repairs.length < 4 ? 'Low data: record station, machine, team, shift, and failure reason consistently.' : 'Sufficient repeated records for an indicative pattern review.';
    return { partNo, records: replacements.length + repairs.length + historicalRows.length, replacementQty, breakdown, confidence, dataQuality, possibleReasons: possible.length ? possible : ['Insufficient repeated-pattern data; record station, machine, team, shift, and failure reason consistently.'], disclaimer: 'Possible reasons only — AI does not establish causality. Confirm with maintenance inspection and production quality records.' };
  }

  function renderChatAnswer(answer) { const el = document.getElementById('ai-chat-answer'); if (el) el.innerHTML = `<div class="ai-answer">${esc(answer)}</div>`; }
  function renderAudit(result) { const summary = document.getElementById('ai-audit-summary'); const body = document.getElementById('ai-audit-body'); if (summary) summary.textContent = result.summary; if (body) body.innerHTML = result.findings.length ? result.findings.map(f => `<tr><td><span class="bdg ${f.severity === 'HIGH' ? 'br' : 'ba'}">${esc(f.severity)}</span></td><td>${esc(f.type)}</td><td>${esc(f.text)}</td><td>${esc(f.date || '—')}<br><small>Evidence: ${esc(f.evidence || 1)}</small></td></tr>`).join('') : '<tr><td colspan="4" class="ai-empty">No rule-based findings in the available data.</td></tr>'; }
  function renderRootCause(result) { const summary = document.getElementById('ai-rc-summary'); const list = document.getElementById('ai-rc-reasons'); if (summary) summary.textContent = `${result.records} related records; ${result.replacementQty} replacement units. Confidence: ${result.confidence}. ${result.dataQuality} ${result.disclaimer}`; if (list) list.innerHTML = result.possibleReasons.map(r => `<li>${esc(r)}</li>`).join(''); }

  async function init() {
    const user = currentUser();
    const auditButton = document.getElementById('ai-run-audit');
    const auditNote = document.getElementById('ai-audit-access');
    const allowed = canUseAudit(user);
    if (auditButton) { auditButton.disabled = !allowed; auditButton.title = allowed ? '' : 'Admin or Developer access required'; }
    if (auditNote) auditNote.textContent = allowed ? `Authorized for ${user.role} role.` : `AI Audit उपलब्ध नाही. Required role: Admin किंवा Developer. Current role: ${user?.role || 'Not logged in'}.`;
    const data = await readData();
    const q = document.getElementById('ai-chat-question');
    if (q && !q.dataset.wired) { q.dataset.wired = '1'; q.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); window.aiAssistantChat(); } }); }
    window.__aiAssistantData = data;
  }

  window.aiAskPreset = function (question) { const input = document.getElementById('ai-chat-question'); if (input) { input.value = question; window.aiAssistantChat(); } };
  window.aiAssistantChat = async function () { const question = document.getElementById('ai-chat-question')?.value || ''; const data = window.__aiAssistantData || await readData(); await logAIAction('chat_query', { queryType: questionType(question), partNo: (question.match(/\b[A-Za-z]{1,8}[-_]\d+\b/) || [])[0] || null, recordCount: Object.values(data).reduce((n, rows) => n + (Array.isArray(rows) ? rows.length : 0), 0) }); renderChatAnswer(answerChat(question, data)); };
  window.aiRunAudit = async function () { const user = currentUser(); if (!canUseAudit(user)) { renderChatAnswer(`AI Audit उपलब्ध नाही. Required role: Admin किंवा Developer. Current role: ${user?.role || 'Not logged in'}.`); return; } const data = await readData(); await logAIAction('audit_run', { queryType: 'authorized_audit', recordCount: (data.audit || []).length + (data.component_audit_log || []).length }); renderAudit(auditAnalysis(data)); };
  window.aiRunRootCause = async function () { const part = document.getElementById('ai-rc-part')?.value || ''; if (!part.trim()) { renderChatAnswer('Root Cause Analysis साठी Part No. द्या.'); return; } const data = await readData(); await logAIAction('root_cause_run', { partNo: text(part).slice(0, 120), queryType: 'root_cause', recordCount: (data.component_replacements || []).length + (data.component_repair_scrap || []).length + (data.component_historical_consumption || []).length }); renderRootCause(rootCause(part, data)); };
  window.aiAssistantInit = init;
  window.aiAssistantTest = { answerChat, auditAnalysis, rootCause, canUseAudit };
})();
