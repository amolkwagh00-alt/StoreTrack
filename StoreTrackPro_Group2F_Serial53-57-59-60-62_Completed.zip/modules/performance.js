/* StoreTrack Pro large-data performance helpers. */
(function () {
  'use strict';
  function yieldToUi() {
    return new Promise(resolve => {
      if (typeof window !== 'undefined' && typeof window.requestAnimationFrame === 'function') {
        window.requestAnimationFrame(() => resolve());
      } else {
        setTimeout(resolve, 0);
      }
    });
  }
  async function forEachChunk(items, callback, chunkSize = 200, onProgress) {
    const list = Array.isArray(items) ? items : [];
    for (let start = 0; start < list.length; start += chunkSize) {
      const end = Math.min(start + chunkSize, list.length);
      for (let index = start; index < end; index += 1) { await callback(list[index], index); }
      if (onProgress) { onProgress(end, list.length); }
      if (end < list.length) { await yieldToUi(); }
    }
  }
  function page(items, pageNumber = 0, pageSize = 100) {
    const list = Array.isArray(items) ? items : [];
    const size = Math.max(1, Number(pageSize) || 100);
    const current = Math.max(0, Number(pageNumber) || 0);
    return { rows: list.slice(current * size, current * size + size), page: current, pageSize: size, total: list.length, pages: Math.max(1, Math.ceil(list.length / size)) };
  }
  function indexBy(items, keyFn) {
    const index = new Map();
    for (const item of (Array.isArray(items) ? items : [])) {
      const key = keyFn(item);
      if (!index.has(key)) { index.set(key, []); }
      index.get(key).push(item);
    }
    return index;
  }
  if (typeof window !== 'undefined') {
    window.storeTrackPerformance = { yieldToUi, forEachChunk, page, indexBy };
  }
  if (typeof module !== 'undefined') {module.exports = { yieldToUi, forEachChunk, page, indexBy };}
})();
