// User Groups and Permissions Module - Role-based access control

/**
 * Permission definition
 */
class Permission {
  constructor(id, name, description, resource, action) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.resource = resource; // e.g., 'materials', 'transactions', 'users'
    this.action = action; // e.g., 'read', 'write', 'delete', 'admin'
  }
}

/**
 * User Group class
 */
class UserGroup {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.name = config.name || 'New Group';
    this.description = config.description || '';
    this.permissions = config.permissions || [];
    this.users = config.users || [];
    this.createdAt = config.createdAt || new Date().toISOString();
    this.updatedAt = config.updatedAt || new Date().toISOString();
  }

  generateId() {
    return `group-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Check if group has permission
   * @param {string} resource - Resource name
   * @param {string} action - Action name
   * @returns {boolean} - Has permission
   */
  hasPermission(resource, action) {
    return this.permissions.some(p => 
      p.resource === resource && p.action === action
    );
  }

  /**
   * Add permission
   * @param {Permission} permission - Permission to add
   */
  addPermission(permission) {
    if (!this.hasPermission(permission.resource, permission.action)) {
      this.permissions.push(permission);
      this.updatedAt = new Date().toISOString();
    }
  }

  /**
   * Remove permission
   * @param {string} permissionId - Permission ID
   */
  removePermission(permissionId) {
    this.permissions = this.permissions.filter(p => p.id !== permissionId);
    this.updatedAt = new Date().toISOString();
  }

  /**
   * Add user to group
   * @param {string} userId - User ID
   */
  addUser(userId) {
    if (!this.users.includes(userId)) {
      this.users.push(userId);
      this.updatedAt = new Date().toISOString();
    }
  }

  /**
   * Remove user from group
   * @param {string} userId - User ID
   */
  removeUser(userId) {
    this.users = this.users.filter(u => u !== userId);
    this.updatedAt = new Date().toISOString();
  }
}

/**
 * User Group Manager
 */
class UserGroupManager {
  constructor() {
    this.groups = new Map();
    this.permissions = new Map();
    if (window.databaseReady) {
      this.init();
    } else {
      document.addEventListener('databaseReady', () => this.init(), { once: true });
    }
  }

  /**
   * Initialize group manager
   */
  async init() {
    this.setupDefaultPermissions();
    await this.loadGroups();
    await this.ensureDefaultGroups();
  }

  /**
   * Setup default permissions
   */
  setupDefaultPermissions() {
    const defaultPermissions = [
      // Materials permissions
      new Permission('materials.read', 'View Materials', 'Can view material inventory', 'materials', 'read'),
      new Permission('materials.write', 'Edit Materials', 'Can add and edit materials', 'materials', 'write'),
      new Permission('materials.delete', 'Delete Materials', 'Can delete materials', 'materials', 'delete'),
      new Permission('materials.admin', 'Material Admin', 'Full control over materials', 'materials', 'admin'),
      
      // Transactions permissions
      new Permission('transactions.read', 'View Transactions', 'Can view transaction history', 'transactions', 'read'),
      new Permission('transactions.write', 'Create Transactions', 'Can create new transactions', 'transactions', 'write'),
      new Permission('transactions.delete', 'Delete Transactions', 'Can delete transactions', 'transactions', 'delete'),
      new Permission('transactions.admin', 'Transaction Admin', 'Full control over transactions', 'transactions', 'admin'),
      
      // Users permissions
      new Permission('users.read', 'View Users', 'Can view user list', 'users', 'read'),
      new Permission('users.write', 'Edit Users', 'Can add and edit users', 'users', 'write'),
      new Permission('users.delete', 'Delete Users', 'Can delete users', 'users', 'delete'),
      new Permission('users.admin', 'User Admin', 'Full control over users', 'users', 'admin'),
      
      // Reports permissions
      new Permission('reports.read', 'View Reports', 'Can view reports', 'reports', 'read'),
      new Permission('reports.write', 'Create Reports', 'Can create custom reports', 'reports', 'write'),
      new Permission('reports.export', 'Export Reports', 'Can export reports', 'reports', 'export'),
      
      // Settings permissions
      new Permission('settings.read', 'View Settings', 'Can view settings', 'settings', 'read'),
      new Permission('settings.write', 'Edit Settings', 'Can modify settings', 'settings', 'write'),
      new Permission('settings.admin', 'Settings Admin', 'Full control over settings', 'settings', 'admin'),
      
      // PM permissions
      new Permission('pm.read', 'View PM', 'Can view PM schedules', 'pm', 'read'),
      new Permission('pm.write', 'Edit PM', 'Can create and edit PM schedules', 'pm', 'write'),
      new Permission('pm.delete', 'Delete PM', 'Can delete PM schedules', 'pm', 'delete'),
      
      // MSP permissions
      new Permission('msp.read', 'View MSP', 'Can view MSP lists', 'msp', 'read'),
      new Permission('msp.write', 'Edit MSP', 'Can create and edit MSP lists', 'msp', 'write'),
      new Permission('msp.delete', 'Delete MSP', 'Can delete MSP lists', 'msp', 'delete')
    ];

    defaultPermissions.forEach(p => this.permissions.set(p.id, p));
  }

  /**
   * Load groups from storage
   */
  async loadGroups() {
    try {
      const groups = await gAll('user_groups');
      groups.forEach(g => {
        const group = new UserGroup(g);
        this.groups.set(group.id, group);
      });
    } catch (err) {
      console.error('Failed to load groups:', err);
    }
  }

  /**
   * Ensure default groups exist
   */
  async ensureDefaultGroups() {
    const defaultGroups = [
      {
        name: 'Administrators',
        description: 'Full system access',
        permissions: Array.from(this.permissions.values())
      },
      {
        name: 'Store Managers',
        description: 'Manage inventory and transactions',
        permissions: [
          this.permissions.get('materials.read'),
          this.permissions.get('materials.write'),
          this.permissions.get('transactions.read'),
          this.permissions.get('transactions.write'),
          this.permissions.get('reports.read'),
          this.permissions.get('reports.export'),
          this.permissions.get('pm.read'),
          this.permissions.get('pm.write'),
          this.permissions.get('msp.read'),
          this.permissions.get('msp.write')
        ].filter(p => p)
      },
      {
        name: 'Store Staff',
        description: 'View and create transactions',
        permissions: [
          this.permissions.get('materials.read'),
          this.permissions.get('transactions.read'),
          this.permissions.get('transactions.write'),
          this.permissions.get('reports.read')
        ].filter(p => p)
      },
      {
        name: 'Viewers',
        description: 'Read-only access',
        permissions: [
          this.permissions.get('materials.read'),
          this.permissions.get('transactions.read'),
          this.permissions.get('reports.read')
        ].filter(p => p)
      }
    ];

    for (const groupConfig of defaultGroups) {
      const existing = Array.from(this.groups.values()).find(g => g.name === groupConfig.name);
      if (!existing) {
        const group = new UserGroup(groupConfig);
        this.groups.set(group.id, group);
      }
    }

    await this.saveGroups();
  }

  /**
   * Save groups to storage
   */
  async saveGroups() {
    try {
      await dClr('user_groups');
      await batchPut('user_groups', Array.from(this.groups.values()));
    } catch (err) {
      console.error('Failed to save groups:', err);
    }
  }

  /**
   * Create group
   * @param {object} config - Group configuration
   * @returns {UserGroup} - Created group
   */
  createGroup(config) {
    const group = new UserGroup(config);
    this.groups.set(group.id, group);
    this.saveGroups();
    return group;
  }

  /**
   * Update group
   * @param {string} id - Group ID
   * @param {object} updates - Updates to apply
   * @returns {UserGroup} - Updated group
   */
  updateGroup(id, updates) {
    const group = this.groups.get(id);
    if (group) {
      Object.assign(group, updates);
      group.updatedAt = new Date().toISOString();
      this.saveGroups();
    }
    return group;
  }

  /**
   * Delete group
   * @param {string} id - Group ID
   */
  async deleteGroup(id) {
    const group = this.groups.get(id);
    if (group && group.name !== 'Administrators') {
      this.groups.delete(id);
      await this.saveGroups();
    }
  }

  /**
   * Get group
   * @param {string} id - Group ID
   * @returns {UserGroup} - Group
   */
  getGroup(id) {
    return this.groups.get(id);
  }

  /**
   * Get all groups
   * @returns {Array} - Array of groups
   */
  getAllGroups() {
    return Array.from(this.groups.values());
  }

  /**
   * Get groups for user
   * @param {string} userId - User ID
   * @returns {Array} - Array of groups
   */
  getGroupsForUser(userId) {
    return this.getAllGroups().filter(g => g.users.includes(userId));
  }

  /**
   * Check if user has permission
   * @param {string} userId - User ID
   * @param {string} resource - Resource name
   * @param {string} action - Action name
   * @returns {boolean} - Has permission
   */
  userHasPermission(userId, resource, action) {
    const userGroups = this.getGroupsForUser(userId);
    return userGroups.some(g => g.hasPermission(resource, action));
  }

  /**
   * Get all permissions for user
   * @param {string} userId - User ID
   * @returns {Array} - Array of permissions
   */
  getUserPermissions(userId) {
    const userGroups = this.getGroupsForUser(userId);
    const permissions = new Set();
    
    userGroups.forEach(group => {
      group.permissions.forEach(p => permissions.add(p));
    });
    
    return Array.from(permissions);
  }

  /**
   * Add user to group
   * @param {string} groupId - Group ID
   * @param {string} userId - User ID
   */
  async addUserToGroup(groupId, userId) {
    const group = this.groups.get(groupId);
    if (group) {
      group.addUser(userId);
      await this.saveGroups();
    }
  }

  /**
   * Remove user from group
   * @param {string} groupId - Group ID
   * @param {string} userId - User ID
   */
  async removeUserFromGroup(groupId, userId) {
    const group = this.groups.get(groupId);
    if (group) {
      group.removeUser(userId);
      await this.saveGroups();
    }
  }

  /**
   * Add permission to group
   * @param {string} groupId - Group ID
   * @param {string} permissionId - Permission ID
   */
  async addPermissionToGroup(groupId, permissionId) {
    const group = this.groups.get(groupId);
    const permission = this.permissions.get(permissionId);
    if (group && permission) {
      group.addPermission(permission);
      await this.saveGroups();
    }
  }

  /**
   * Remove permission from group
   * @param {string} groupId - Group ID
   * @param {string} permissionId - Permission ID
   */
  async removePermissionFromGroup(groupId, permissionId) {
    const group = this.groups.get(groupId);
    if (group) {
      group.removePermission(permissionId);
      await this.saveGroups();
    }
  }

  /**
   * Get all available permissions
   * @returns {Array} - Array of permissions
   */
  getAllPermissions() {
    return Array.from(this.permissions.values());
  }

  /**
   * Get permissions by resource
   * @param {string} resource - Resource name
   * @returns {Array} - Array of permissions
   */
  getPermissionsByResource(resource) {
    return this.getAllPermissions().filter(p => p.resource === resource);
  }
}

/**
 * Global group manager instance
 */
const groupManager = new UserGroupManager();

/**
 * Initialize user groups
 */
async function initUserGroups() {
  // Wait for database to be ready
  if (!window.databaseReady) {
    await new Promise(resolve => {
      document.addEventListener('databaseReady', resolve, { once: true });
    });
  }
  await groupManager.init();
  return groupManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.UserGroups = {
    manager: groupManager,
    init: initUserGroups,
    createGroup: (config) => groupManager.createGroup(config),
    updateGroup: (id, updates) => groupManager.updateGroup(id, updates),
    deleteGroup: (id) => groupManager.deleteGroup(id),
    getGroup: (id) => groupManager.getGroup(id),
    getAllGroups: () => groupManager.getAllGroups(),
    getGroupsForUser: (userId) => groupManager.getGroupsForUser(userId),
    userHasPermission: (userId, resource, action) => groupManager.userHasPermission(userId, resource, action),
    getUserPermissions: (userId) => groupManager.getUserPermissions(userId),
    addUserToGroup: (groupId, userId) => groupManager.addUserToGroup(groupId, userId),
    removeUserFromGroup: (groupId, userId) => groupManager.removeUserFromGroup(groupId, userId),
    addPermissionToGroup: (groupId, permId) => groupManager.addPermissionToGroup(groupId, permId),
    removePermissionFromGroup: (groupId, permId) => groupManager.removePermissionFromGroup(groupId, permId),
    getAllPermissions: () => groupManager.getAllPermissions(),
    getPermissionsByResource: (resource) => groupManager.getPermissionsByResource(resource)
  };
}
