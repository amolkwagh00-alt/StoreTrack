/**
 * Enterprise Password Policy
 * Password strength validation and policy enforcement for StoreTrack Pro
 *
 * FIX (StoreTrack V8 core/ integration): originally `import { SECURITY } from
 * '../core/constants.js'` — ES-module syntax that throws when loaded via a
 * plain <script> tag (same root cause documented in core/constants.js). Now
 * reads window.CONST.SECURITY (set by core/constants.js, which is guaranteed
 * to load first — see index.html script order) with safe hardcoded fallbacks
 * so this file never throws even if constants.js is missing for any reason.
 */
const _SECURITY_DEFAULTS = {
  PASSWORD: { MIN_LENGTH: 8, MAX_LENGTH: 128, REQUIRE_UPPERCASE: true, REQUIRE_LOWERCASE: true, REQUIRE_NUMBER: true, REQUIRE_SPECIAL: true, EXPIRY_DAYS: 90 }
};
const PASSWORD_SECURITY_CFG = (typeof window !== 'undefined' && window.CONST && window.CONST.SECURITY) ? window.CONST.SECURITY : _SECURITY_DEFAULTS;

const LOCKOUT_STORAGE_KEY = 'storetrack.login-lockouts.v1';

class PasswordPolicy {
  constructor(options = {}) {
    this.policy = {
      minLength: PASSWORD_SECURITY_CFG.PASSWORD.MIN_LENGTH,
      maxLength: PASSWORD_SECURITY_CFG.PASSWORD.MAX_LENGTH,
      requireUppercase: PASSWORD_SECURITY_CFG.PASSWORD.REQUIRE_UPPERCASE,
      requireLowercase: PASSWORD_SECURITY_CFG.PASSWORD.REQUIRE_LOWERCASE,
      requireNumber: PASSWORD_SECURITY_CFG.PASSWORD.REQUIRE_NUMBER,
      requireSpecial: PASSWORD_SECURITY_CFG.PASSWORD.REQUIRE_SPECIAL,
      expiryDays: PASSWORD_SECURITY_CFG.PASSWORD.EXPIRY_DAYS,
      preventCommon: true,
      preventUserInfo: true,
      preventSequential: true,
      preventRepeating: true,
      historyCount: 5,
      maxFailedAttempts: 5,
      lockoutDuration: 15 * 60 * 1000 // 15 minutes
    };
    
    this.commonPasswords = [
      'password', '123456', '12345678', 'qwerty', 'abc123',
      'monkey', 'master', 'dragon', '111111', 'baseball',
      'iloveyou', 'trustno1', 'sunshine', 'princess', 'admin',
      'welcome', 'shadow', 'ashley', 'football', 'jesus',
      'michael', 'ninja', 'mustang', 'password1', 'password123'
    ];
    
    this.userPasswordHistory = new Map();
    this.failedAttempts = new Map();
    this.lockedAccounts = new Map();
    if (options.restorePersistedLockouts === true) {
      this.restorePersistedLockouts();
    }
  }

  restorePersistedLockouts() {
    try {
      const raw = window.localStorage?.getItem(LOCKOUT_STORAGE_KEY);
      const saved = raw ? JSON.parse(raw) : {};
      for (const [userId, state] of Object.entries(saved)) {
        if (!userId || !state || !Number.isFinite(state.attempts) || state.attempts < 0) continue;
        this.failedAttempts.set(userId, Math.floor(state.attempts));
        if (Number.isFinite(state.lockedAt) && Number.isFinite(state.duration) && state.duration > 0) {
          if (Date.now() - state.lockedAt < state.duration) this.lockedAccounts.set(userId, { lockedAt: state.lockedAt, duration: state.duration });
        }
      }
      return true;
    } catch (error) {
      console.warn('[PasswordPolicy] Could not restore persisted lockout state:', error);
      return false;
    }
  }

  persistLockouts() {
    try {
      const saved = {};
      for (const [userId, attempts] of this.failedAttempts) {
        const lock = this.lockedAccounts.get(userId);
        saved[userId] = { attempts, ...(lock ? { lockedAt: lock.lockedAt, duration: lock.duration } : {}) };
      }
      for (const [userId, lock] of this.lockedAccounts) {
        if (!saved[userId]) saved[userId] = { attempts: this.failedAttempts.get(userId) || 0, lockedAt: lock.lockedAt, duration: lock.duration };
      }
      window.localStorage?.setItem(LOCKOUT_STORAGE_KEY, JSON.stringify(saved));
    } catch (error) {
      console.warn('[PasswordPolicy] Could not persist lockout state:', error);
    }
  }

  /**
   * Validate password against policy
   * @param {string} password - Password to validate
   * @param {Object} userInfo - User info for context
   * @returns {Object} Validation result
   */
  validate(password, userInfo = {}) {
    const errors = [];
    const warnings = [];

    // Length check
    if (password.length < this.policy.minLength) {
      errors.push(`Password must be at least ${this.policy.minLength} characters`);
    }
    
    if (password.length > this.policy.maxLength) {
      errors.push(`Password must not exceed ${this.policy.maxLength} characters`);
    }

    // Uppercase check
    if (this.policy.requireUppercase && !/[A-Z]/.test(password)) {
      errors.push('Password must contain at least one uppercase letter');
    }

    // Lowercase check
    if (this.policy.requireLowercase && !/[a-z]/.test(password)) {
      errors.push('Password must contain at least one lowercase letter');
    }

    // Number check
    if (this.policy.requireNumber && !/[0-9]/.test(password)) {
      errors.push('Password must contain at least one number');
    }

    // Special character check
    if (this.policy.requireSpecial && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      errors.push('Password must contain at least one special character');
    }

    // Common password check
    if (this.policy.preventCommon && this.isCommonPassword(password)) {
      errors.push('Password is too common. Please choose a stronger password');
    }

    // User info check
    if (this.policy.preventUserInfo) {
      const userInfoInPassword = this.containsUserInfo(password, userInfo);
      if (userInfoInPassword) {
        warnings.push('Password should not contain personal information');
      }
    }

    // Sequential characters check
    if (this.policy.preventSequential && this.hasSequentialChars(password)) {
      warnings.push('Password should not contain sequential characters');
    }

    // Repeating characters check
    if (this.policy.preventRepeating && this.hasRepeatingChars(password)) {
      warnings.push('Password should not contain repeating characters');
    }

    // Calculate strength
    const strength = this.calculateStrength(password);

    return {
      valid: errors.length === 0,
      errors,
      warnings,
      strength,
      score: strength.score
    };
  }

  /**
   * Check if password is common
   * @param {string} password - Password
   * @returns {boolean} Is common
   */
  isCommonPassword(password) {
    const lowerPassword = password.toLowerCase();
    return this.commonPasswords.includes(lowerPassword);
  }

  /**
   * Check if password contains user info
   * @param {string} password - Password
   * @param {Object} userInfo - User info
   * @returns {boolean} Contains user info
   */
  containsUserInfo(password, userInfo) {
    const lowerPassword = password.toLowerCase();
    
    const userInfoFields = [
      userInfo.username,
      userInfo.email,
      userInfo.firstName,
      userInfo.lastName,
      userInfo.phone
    ].filter(Boolean);

    for (const field of userInfoFields) {
      if (field && lowerPassword.includes(field.toLowerCase())) {
        return true;
      }
    }

    return false;
  }

  /**
   * Check for sequential characters
   * @param {string} password - Password
   * @returns {boolean} Has sequential
   */
  hasSequentialChars(password) {
    const sequences = ['0123456789', 'abcdefghijklmnopqrstuvwxyz', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm'];
    const lowerPassword = password.toLowerCase();

    for (const seq of sequences) {
      for (let i = 0; i < seq.length - 2; i++) {
        const threeChars = seq.substring(i, i + 3);
        const reverseThreeChars = threeChars.split('').reverse().join('');
        
        if (lowerPassword.includes(threeChars) || lowerPassword.includes(reverseThreeChars)) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Check for repeating characters
   * @param {string} password - Password
   * @returns {boolean} Has repeating
   */
  hasRepeatingChars(password) {
    const regex = /(.)\1{2,}/;
    return regex.test(password);
  }

  /**
   * Calculate password strength
   * @param {string} password - Password
   * @returns {Object} Strength info
   */
  calculateStrength(password) {
    let score = 0;

    // Length
    if (password.length >= 8) {score += 1;}
    if (password.length >= 12) {score += 1;}
    if (password.length >= 16) {score += 1;}

    // Character types
    if (/[a-z]/.test(password)) {score += 1;}
    if (/[A-Z]/.test(password)) {score += 1;}
    if (/[0-9]/.test(password)) {score += 1;}
    if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {score += 1;}

    // Complexity
    if (password.length >= 10 && /[a-z]/.test(password) && /[A-Z]/.test(password) && /[0-9]/.test(password)) {
      score += 1;
    }

    if (password.length >= 12 && /[a-z]/.test(password) && /[A-Z]/.test(password) && /[0-9]/.test(password) && /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      score += 1;
    }

    // Determine level
    let level = 'weak';
    if (score >= 3) {level = 'fair';}
    if (score >= 5) {level = 'good';}
    if (score >= 7) {level = 'strong';}
    if (score >= 9) {level = 'excellent';}

    return {
      score,
      level,
      maxScore: 10
    };
  }

  /**
   * Check password against history
   * @param {string} userId - User ID
   * @param {string} password - Password
   * @returns {boolean} Is in history
   */
  isInHistory(userId, password) {
    const history = this.userPasswordHistory.get(userId) || [];
    return history.includes(password);
  }

  /**
   * Add password to history
   * @param {string} userId - User ID
   * @param {string} password - Password
   */
  addToHistory(userId, password) {
    if (!this.userPasswordHistory.has(userId)) {
      this.userPasswordHistory.set(userId, []);
    }

    const history = this.userPasswordHistory.get(userId);
    history.push(password);

    // Keep only last N passwords
    if (history.length > this.policy.historyCount) {
      history.shift();
    }
  }

  /**
   * Record failed attempt
   * @param {string} userId - User ID
   */
  recordFailedAttempt(userId) {
    const attempts = (this.failedAttempts.get(userId) || 0) + 1;
    this.failedAttempts.set(userId, attempts);

    if (attempts >= this.policy.maxFailedAttempts) {
      this.lockAccount(userId);
    }
    this.persistLockouts();
  }

  /**
   * Clear failed attempts
   * @param {string} userId - User ID
   */
  clearFailedAttempts(userId) {
    this.failedAttempts.delete(userId);
    this.persistLockouts();
  }

  /**
   * Lock account
   * @param {string} userId - User ID
   */
  lockAccount(userId) {
    this.lockedAccounts.set(userId, {
      lockedAt: Date.now(),
      duration: this.policy.lockoutDuration
    });
    this.persistLockouts();
  }

  /**
   * Unlock account
   * @param {string} userId - User ID
   */
  unlockAccount(userId) {
    this.lockedAccounts.delete(userId);
    this.clearFailedAttempts(userId);
    this.persistLockouts();
  }

  /**
   * Check if account is locked
   * @param {string} userId - User ID
   * @returns {boolean} Is locked
   */
  isAccountLocked(userId) {
    const lockInfo = this.lockedAccounts.get(userId);
    if (!lockInfo) {return false;}

    // Check if lock has expired
    const elapsed = Date.now() - lockInfo.lockedAt;
    if (elapsed >= lockInfo.duration) {
      this.unlockAccount(userId);
      return false;
    }

    return true;
  }

  /**
   * Get remaining lock time
   * @param {string} userId - User ID
   * @returns {number} Remaining time in ms
   */
  getRemainingLockTime(userId) {
    const lockInfo = this.lockedAccounts.get(userId);
    if (!lockInfo) {return 0;}

    const elapsed = Date.now() - lockInfo.lockedAt;
    const remaining = lockInfo.duration - elapsed;
    return Math.max(0, remaining);
  }

  /**
   * Check if password needs change
   * @param {string} lastChanged - Last changed timestamp
   * @returns {boolean} Needs change
   */
  needsPasswordChange(lastChanged) {
    if (!lastChanged) {return true;}
    
    const elapsed = Date.now() - new Date(lastChanged).getTime();
    const expiryMs = this.policy.expiryDays * 24 * 60 * 60 * 1000;
    
    return elapsed >= expiryMs;
  }

  /**
   * Get days until password expiry
   * @param {string} lastChanged - Last changed timestamp
   * @returns {number} Days until expiry
   */
  getDaysUntilExpiry(lastChanged) {
    if (!lastChanged) {return 0;}
    
    const elapsed = Date.now() - new Date(lastChanged).getTime();
    const expiryMs = this.policy.expiryDays * 24 * 60 * 60 * 1000;
    const remainingMs = expiryMs - elapsed;
    
    return Math.max(0, Math.floor(remainingMs / (24 * 60 * 60 * 1000)));
  }

  /**
   * Generate random password
   * @param {number} length - Password length
   * @returns {string} Generated password
   */
  generatePassword(length = 16) {
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const special = '!@#$%^&*()_+-=[]{}|;:,.<>?';

    let password = '';
    const allChars = uppercase + lowercase + numbers + special;

    // Ensure at least one of each required type
    if (this.policy.requireUppercase) {
      password += uppercase[Math.floor(Math.random() * uppercase.length)];
    }
    if (this.policy.requireLowercase) {
      password += lowercase[Math.floor(Math.random() * lowercase.length)];
    }
    if (this.policy.requireNumber) {
      password += numbers[Math.floor(Math.random() * numbers.length)];
    }
    if (this.policy.requireSpecial) {
      password += special[Math.floor(Math.random() * special.length)];
    }

    // Fill remaining length
    while (password.length < length) {
      password += allChars[Math.floor(Math.random() * allChars.length)];
    }

    // Shuffle password
    return password.split('').sort(() => Math.random() - 0.5).join('');
  }

  /**
   * Update policy
   * @param {Object} newPolicy - New policy settings
   */
  updatePolicy(newPolicy) {
    this.policy = { ...this.policy, ...newPolicy };
  }

  /**
   * Get current policy
   * @returns {Object} Current policy
   */
  getPolicy() {
    return { ...this.policy };
  }
}

// Global password policy instance
const passwordPolicy = new PasswordPolicy({ restorePersistedLockouts: true });

// Expose to window
if (typeof window !== 'undefined') {
  window.PasswordPolicy = PasswordPolicy;
  window.passwordPolicy = passwordPolicy;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PasswordPolicy, passwordPolicy };
}
