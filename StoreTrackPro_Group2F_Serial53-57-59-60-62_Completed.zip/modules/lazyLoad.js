// Lazy Loading Module - Performance optimization for images and components

/**
 * Intersection Observer for lazy loading
 */
class LazyLoader {
  constructor(options = {}) {
    this.options = {
      rootMargin: options.rootMargin || '50px',
      threshold: options.threshold || 0.01,
      selector: options.selector || '[data-lazy]',
      ...options
    };
    
    this.observer = null;
    this.init();
  }

  /**
   * Initialize intersection observer
   */
  init() {
    if ('IntersectionObserver' in window) {
      this.observer = new IntersectionObserver(
        this.handleIntersect.bind(this),
        {
          rootMargin: this.options.rootMargin,
          threshold: this.options.threshold
        }
      );
      
      // Observe existing elements
      this.observeExisting();
      
      // Watch for dynamically added elements
      this.watchDynamicElements();
    } else {
      // Fallback for browsers without IntersectionObserver
      this.loadAll();
    }
  }

  /**
   * Handle intersection callback
   */
  handleIntersect(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const element = entry.target;
        this.loadElement(element);
        this.observer.unobserve(element);
      }
    });
  }

  /**
   * Load a single lazy element
   */
  loadElement(element) {
    const type = element.dataset.lazyType || 'img';
    
    switch (type) {
      case 'img':
        this.loadImage(element);
        break;
      case 'bg':
        this.loadBackground(element);
        break;
      case 'component':
        this.loadComponent(element);
        break;
      case 'iframe':
        this.loadIframe(element);
        break;
      default:
        this.loadImage(element);
    }
  }

  /**
   * Load lazy image
   */
  loadImage(element) {
    const src = element.dataset.src;
    const srcset = element.dataset.srcset;
    
    if (src) {
      element.src = src;
      element.onload = () => {
        element.classList.add('loaded');
        element.removeAttribute('data-src');
      };
    }
    
    if (srcset) {
      element.srcset = srcset;
      element.removeAttribute('data-srcset');
    }
  }

  /**
   * Load lazy background image
   */
  loadBackground(element) {
    const bg = element.dataset.bg;
    
    if (bg) {
      const img = new Image();
      img.onload = () => {
        element.style.backgroundImage = `url('${bg}')`;
        element.classList.add('loaded');
        element.removeAttribute('data-bg');
      };
      img.src = bg;
    }
  }

  /**
   * Load lazy component (dynamic import)
   */
  loadComponent(element) {
    const component = element.dataset.component;
    
    if (component) {
      this.loadScript(component).then(() => {
        element.classList.add('loaded');
        element.removeAttribute('data-component');
      }).catch(err => {
        console.error('Failed to load component:', err);
      });
    }
  }

  /**
   * Load lazy iframe
   */
  loadIframe(element) {
    const src = element.dataset.src;
    
    if (src) {
      element.src = src;
      element.classList.add('loaded');
      element.removeAttribute('data-src');
    }
  }

  /**
   * Load script dynamically
   */
  loadScript(src) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }

  /**
   * Observe existing lazy elements
   */
  observeExisting() {
    const elements = document.querySelectorAll(this.options.selector);
    elements.forEach(el => this.observer.observe(el));
  }

  /**
   * Watch for dynamically added elements
   */
  watchDynamicElements() {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            const element = node;
            if (element.matches(this.options.selector)) {
              this.observer.observe(element);
            }
            // Check children
            const children = element.querySelectorAll(this.options.selector);
            children.forEach(child => this.observer.observe(child));
          }
        });
      });
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  /**
   * Load all elements immediately (fallback)
   */
  loadAll() {
    const elements = document.querySelectorAll(this.options.selector);
    elements.forEach(el => this.loadElement(el));
  }

  /**
   * Disconnect observer
   */
  disconnect() {
    if (this.observer) {
      this.observer.disconnect();
    }
  }
}

/**
 * Lazy load images with placeholder
 * @param {string} src - Image source
 * @param {object} options - Options
 * @returns {string} - HTML string
 */
function createLazyImage(src, options = {}) {
  const {
    alt = '',
    class: className = '',
    width = '',
    height = '',
    placeholder = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'
  } = options;
  
  return `
    <img 
      data-lazy 
      data-lazy-type="img" 
      data-src="${src}" 
      src="${placeholder}"
      alt="${alt}"
      class="lazy-image ${className}"
      ${width ? `width="${width}"` : ''}
      ${height ? `height="${height}"` : ''}
    />
  `;
}

/**
 * Lazy load background image
 * @param {string} src - Background image source
 * @param {object} options - Options
 * @returns {string} - Style string
 */
function createLazyBackground(src, options = {}) {
  const {
    class: className = '',
    size = 'cover',
    position = 'center'
  } = options;
  
  return `
    <div 
      data-lazy 
      data-lazy-type="bg" 
      data-bg="${src}"
      class="lazy-bg ${className}"
      data-style="background-size: ${size}; background-position: ${position};"
    ></div>
  `;
}

/**
 * Lazy load component
 * @param {string} component - Component script path
 * @param {object} options - Options
 * @returns {string} - HTML string
 */
function createLazyComponent(component, options = {}) {
  const {
    class: className = '',
    id = ''
  } = options;
  
  return `
    <div 
      data-lazy 
      data-lazy-type="component" 
      data-component="${component}"
      class="lazy-component ${className}"
      ${id ? `id="${id}"` : ''}
    ></div>
  `;
}

/**
 * Initialize lazy loading on page load
 */
let lazyLoaderInstance = null;

function initLazyLoad(options = {}) {
  if (!lazyLoaderInstance) {
    lazyLoaderInstance = new LazyLoader(options);
  }
  return lazyLoaderInstance;
}

/**
 * Force load all lazy elements
 */
function forceLoadAll() {
  if (lazyLoaderInstance) {
    lazyLoaderInstance.loadAll();
  }
}

/**
 * Disconnect lazy loader
 */
function disconnectLazyLoad() {
  if (lazyLoaderInstance) {
    lazyLoaderInstance.disconnect();
    lazyLoaderInstance = null;
  }
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.LazyLoad = {
    LazyLoader,
    init: initLazyLoad,
    createImage: createLazyImage,
    createBackground: createLazyBackground,
    createComponent: createLazyComponent,
    forceLoadAll,
    disconnect: disconnectLazyLoad
  };
  
  // Auto-initialize on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => initLazyLoad());
  } else {
    initLazyLoad();
  }
}
