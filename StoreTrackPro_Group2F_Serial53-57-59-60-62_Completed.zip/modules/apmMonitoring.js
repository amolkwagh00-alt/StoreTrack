/**
 * Application Performance Monitoring (APM) Module
 * Tracks application performance metrics and health
 */

class APMMonitoring {
  constructor() {
    this.metrics = new Map();
    this.transactions = new Map();
    this.spans = new Map();
    this.config = {
      sampleRate: 0.1, // 10% sampling
      maxTransactions: 1000,
      maxSpans: 10000,
      slowThreshold: 1000, // 1 second
      verySlowThreshold: 5000 // 5 seconds
    };
    this.startTime = Date.now();
  }

  /**
   * Initialize APM with configuration
   * @param {Object} config - Configuration options
   */
  initialize(config = {}) {
    this.setConfig(config);
    console.log('[APM] Initialized with config:', config);
  }

  /**
   * Start a transaction
   * @param {string} name - Transaction name
   * @param {string} op - Operation type
   */
  startTransaction(name, op = 'custom') {
    const id = this.generateId();
    const transaction = {
      id,
      name,
      op,
      startTime: performance.now(),
      spans: [],
      metadata: {}
    };
    
    this.transactions.set(id, transaction);
    return id;
  }

  /**
   * End a transaction
   * @param {string} transactionId - Transaction ID
   * @param {Object} metadata - Additional metadata
   */
  endTransaction(transactionId, metadata = {}) {
    const transaction = this.transactions.get(transactionId);
    if (!transaction) {return;}
    
    transaction.endTime = performance.now();
    transaction.duration = transaction.endTime - transaction.startTime;
    transaction.metadata = { ...transaction.metadata, ...metadata };
    
    // Classify performance
    if (transaction.duration > this.config.verySlowThreshold) {
      transaction.performance = 'very_slow';
    } else if (transaction.duration > this.config.slowThreshold) {
      transaction.performance = 'slow';
    } else {
      transaction.performance = 'normal';
    }
    
    // Store metric
    this.recordMetric('transaction_duration', transaction.duration, {
      name: transaction.name,
      op: transaction.op,
      performance: transaction.performance
    });
    
    // Clean up old transactions
    if (this.transactions.size > this.config.maxTransactions) {
      this.cleanupOldTransactions();
    }
  }

  /**
   * Start a span within a transaction
   * @param {string} transactionId - Transaction ID
   * @param {string} name - Span name
   * @param {string} op - Operation type
   */
  startSpan(transactionId, name, op = 'custom') {
    const transaction = this.transactions.get(transactionId);
    if (!transaction) {return null;}
    
    const id = this.generateId();
    const span = {
      id,
      transactionId,
      name,
      op,
      startTime: performance.now()
    };
    
    this.spans.set(id, span);
    transaction.spans.push(id);
    return id;
  }

  /**
   * End a span
   * @param {string} spanId - Span ID
   */
  endSpan(spanId) {
    const span = this.spans.get(spanId);
    if (!span) {return;}
    
    span.endTime = performance.now();
    span.duration = span.endTime - span.startTime;
    
    // Record metric
    this.recordMetric('span_duration', span.duration, {
      name: span.name,
      op: span.op
    });
  }

  /**
   * Record a metric
   * @param {string} name - Metric name
   * @param {number} value - Metric value
   * @param {Object} tags - Metric tags
   */
  recordMetric(name, value, tags = {}) {
    const metricKey = `${name}_${JSON.stringify(tags)}`;
    const existing = this.metrics.get(metricKey) || {
      name,
      values: [],
      tags,
      count: 0,
      sum: 0,
      min: Infinity,
      max: -Infinity
    };
    
    existing.values.push(value);
    existing.count++;
    existing.sum += value;
    existing.min = Math.min(existing.min, value);
    existing.max = Math.max(existing.max, value);
    
    // Keep only last 1000 values
    if (existing.values.length > 1000) {
      existing.values.shift();
    }
    
    this.metrics.set(metricKey, existing);
  }

  /**
   * Record a counter
   * @param {string} name - Counter name
   * @param {number} value - Increment value
   * @param {Object} tags - Counter tags
   */
  incrementCounter(name, value = 1, tags = {}) {
    const metricKey = `${name}_${JSON.stringify(tags)}`;
    const existing = this.metrics.get(metricKey) || {
      name,
      type: 'counter',
      value: 0,
      tags
    };
    
    existing.value += value;
    this.metrics.set(metricKey, existing);
  }

  /**
   * Record a gauge
   * @param {string} name - Gauge name
   * @param {number} value - Gauge value
   * @param {Object} tags - Gauge tags
   */
  recordGauge(name, value, tags = {}) {
    const metricKey = `${name}_${JSON.stringify(tags)}`;
    this.metrics.set(metricKey, {
      name,
      type: 'gauge',
      value,
      tags,
      timestamp: Date.now()
    });
  }

  /**
   * Record a histogram
   * @param {string} name - Histogram name
   * @param {number} value - Value to record
   * @param {Object} tags - Histogram tags
   */
  recordHistogram(name, value, tags = {}) {
    const metricKey = `${name}_${JSON.stringify(tags)}`;
    const existing = this.metrics.get(metricKey) || {
      name,
      type: 'histogram',
      values: [],
      tags
    };
    
    existing.values.push(value);
    
    // Keep only last 1000 values
    if (existing.values.length > 1000) {
      existing.values.shift();
    }
    
    this.metrics.set(metricKey, existing);
  }

  /**
   * Get metric statistics
   * @param {string} name - Metric name
   * @param {Object} tags - Metric tags
   */
  getMetricStats(name, tags = {}) {
    const metricKey = `${name}_${JSON.stringify(tags)}`;
    const metric = this.metrics.get(metricKey);
    
    if (!metric) {return null;}
    
    if (metric.type === 'counter' || metric.type === 'gauge') {
      return metric;
    }
    
    const values = metric.values;
    const sorted = [...values].sort((a, b) => a - b);
    
    return {
      name,
      count: values.length,
      sum: metric.sum,
      min: metric.min,
      max: metric.max,
      mean: metric.sum / values.length,
      median: sorted[Math.floor(sorted.length / 2)],
      p50: sorted[Math.floor(sorted.length * 0.5)],
      p90: sorted[Math.floor(sorted.length * 0.9)],
      p95: sorted[Math.floor(sorted.length * 0.95)],
      p99: sorted[Math.floor(sorted.length * 0.99)],
      tags
    };
  }

  /**
   * Get all metrics
   */
  getAllMetrics() {
    return Array.from(this.metrics.values());
  }

  /**
   * Get transaction statistics
   */
  getTransactionStats() {
    const transactions = Array.from(this.transactions.values());
    
    if (transactions.length === 0) {
      return { count: 0 };
    }
    
    const durations = transactions.map(t => t.duration);
    const sorted = [...durations].sort((a, b) => a - b);
    
    const performanceCounts = {
      normal: 0,
      slow: 0,
      very_slow: 0
    };
    
    transactions.forEach(t => {
      performanceCounts[t.performance]++;
    });
    
    return {
      count: transactions.length,
      totalDuration: durations.reduce((sum, d) => sum + d, 0),
      avgDuration: durations.reduce((sum, d) => sum + d, 0) / durations.length,
      minDuration: sorted[0],
      maxDuration: sorted[sorted.length - 1],
      medianDuration: sorted[Math.floor(sorted.length / 2)],
      p95Duration: sorted[Math.floor(sorted.length * 0.95)],
      p99Duration: sorted[Math.floor(sorted.length * 0.99)],
      performance: performanceCounts
    };
  }

  /**
   * Get system health metrics
   */
  getSystemHealth() {
    const uptime = Date.now() - this.startTime;
    const memory = this.getMemoryUsage();
    const performance = this.getPerformanceMetrics();
    
    return {
      uptime,
      uptimeFormatted: this.formatUptime(uptime),
      memory,
      performance,
      transactionCount: this.transactions.size,
      spanCount: this.spans.size,
      metricCount: this.metrics.size
    };
  }

  /**
   * Get memory usage
   */
  getMemoryUsage() {
    if (typeof performance !== 'undefined' && performance.memory) {
      return {
        usedJSHeapSize: performance.memory.usedJSHeapSize,
        totalJSHeapSize: performance.memory.totalJSHeapSize,
        jsHeapSizeLimit: performance.memory.jsHeapSizeLimit,
        usagePercent: (performance.memory.usedJSHeapSize / performance.memory.jsHeapSizeLimit) * 100
      };
    }
    return null;
  }

  /**
   * Get performance metrics
   */
  getPerformanceMetrics() {
    if (typeof performance !== 'undefined' && performance.timing) {
      const timing = performance.timing;
      return {
        domContentLoaded: timing.domContentLoadedEventEnd - timing.navigationStart,
        loadComplete: timing.loadEventEnd - timing.navigationStart,
        firstPaint: timing.responseStart - timing.navigationStart
      };
    }
    return null;
  }

  /**
   * Format uptime
   */
  formatUptime(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) {return `${days}d ${hours % 24}h`;}
    if (hours > 0) {return `${hours}h ${minutes % 60}m`;}
    if (minutes > 0) {return `${minutes}m ${seconds % 60}s`;}
    return `${seconds}s`;
  }

  /**
   * Generate unique ID
   */
  generateId() {
    return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Clean up old transactions
   */
  cleanupOldTransactions() {
    const entries = Array.from(this.transactions.entries());
    entries.sort((a, b) => a[1].startTime - b[1].startTime);
    
    const toRemove = entries.slice(0, entries.length - this.config.maxTransactions);
    toRemove.forEach(([id]) => {
      this.transactions.delete(id);
    });
  }

  /**
   * Clean up old spans
   */
  cleanupOldSpans() {
    if (this.spans.size <= this.config.maxSpans) {return;}
    
    const entries = Array.from(this.spans.entries());
    entries.sort((a, b) => a[1].startTime - b[1].startTime);
    
    const toRemove = entries.slice(0, entries.length - this.config.maxSpans);
    toRemove.forEach(([id]) => {
      this.spans.delete(id);
    });
  }

  /**
   * Clear all metrics
   */
  clearMetrics() {
    this.metrics.clear();
  }

  /**
   * Clear all transactions
   */
  clearTransactions() {
    this.transactions.clear();
  }

  /**
   * Clear all spans
   */
  clearSpans() {
    this.spans.clear();
  }

  /**
   * Reset all data
   */
  reset() {
    this.metrics.clear();
    this.transactions.clear();
    this.spans.clear();
    this.startTime = Date.now();
  }

  /**
   * Export metrics as JSON
   */
  exportMetrics() {
    return {
      timestamp: Date.now(),
      metrics: Array.from(this.metrics.values()),
      transactions: Array.from(this.transactions.values()),
      systemHealth: this.getSystemHealth()
    };
  }

  /**
   * Set configuration
   * @param {Object} config - Configuration options
   */
  setConfig(config) {
    this.config = { ...this.config, ...config };
  }

  /**
   * Get configuration
   */
  getConfig() {
    return { ...this.config };
  }
}

// Create singleton instance
const apmMonitoring = new APMMonitoring();

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { APMMonitoring, apmMonitoring };
}
