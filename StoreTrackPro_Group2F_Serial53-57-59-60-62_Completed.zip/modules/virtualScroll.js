/**
 * Virtual Scrolling Module
 * Efficient rendering of large lists by only rendering visible items
 */

class VirtualScroll {
  constructor(options = {}) {
    this.itemHeight = options.itemHeight || 50;
    this.bufferSize = options.bufferSize || 5;
    this.container = options.container;
    this.items = [];
    this.visibleStart = 0;
    this.visibleEnd = 0;
    this.scrollTop = 0;
    this.totalHeight = 0;
    this.renderedItems = new Map();
    this.itemTemplate = options.itemTemplate || this.defaultTemplate;
    this.onItemClick = options.onItemClick || (() => {});
    
    this.init();
  }

  /**
   * Initialize virtual scroll
   */
  init() {
    if (!this.container) {return;}
    
    this.container.style.overflow = 'auto';
    this.container.style.position = 'relative';
    
    // Create spacer elements
    this.topSpacer = document.createElement('div');
    this.bottomSpacer = document.createElement('div');
    this.topSpacer.style.position = 'absolute';
    this.topSpacer.style.left = '0';
    this.topSpacer.style.right = '0';
    this.topSpacer.style.top = '0';
    this.topSpacer.style.height = '0';
    this.topSpacer.style.pointerEvents = 'none';
    
    this.bottomSpacer.style.position = 'absolute';
    this.bottomSpacer.style.left = '0';
    this.bottomSpacer.style.right = '0';
    this.bottomSpacer.style.bottom = '0';
    this.bottomSpacer.style.height = '0';
    this.bottomSpacer.style.pointerEvents = 'none';
    
    this.container.appendChild(this.topSpacer);
    this.container.appendChild(this.bottomSpacer);
    
    // Create content container
    this.contentContainer = document.createElement('div');
    this.contentContainer.style.position = 'relative';
    this.contentContainer.style.width = '100%';
    this.container.appendChild(this.contentContainer);
    
    // Bind scroll event
    this.container.addEventListener('scroll', () => this.handleScroll());
    
    // Bind resize event
    window.addEventListener('resize', () => this.handleResize());
  }

  /**
   * Set items to display
   * @param {Array} items - Array of items
   */
  setItems(items) {
    this.items = items;
    this.totalHeight = items.length * this.itemHeight;
    this.updateSpacers();
    this.render();
  }

  /**
   * Handle scroll event
   */
  handleScroll() {
    this.scrollTop = this.container.scrollTop;
    this.render();
  }

  /**
   * Handle resize event
   */
  handleResize() {
    this.render();
  }

  /**
   * Calculate visible range
   */
  calculateVisibleRange() {
    const containerHeight = this.container.clientHeight;
    const startIndex = Math.floor(this.scrollTop / this.itemHeight);
    const endIndex = Math.ceil((this.scrollTop + containerHeight) / this.itemHeight);
    
    // Add buffer
    return {
      start: Math.max(0, startIndex - this.bufferSize),
      end: Math.min(this.items.length, endIndex + this.bufferSize)
    };
  }

  /**
   * Update spacer heights
   */
  updateSpacers() {
    const visibleRange = this.calculateVisibleRange();
    
    this.topSpacer.style.height = `${visibleRange.start * this.itemHeight}px`;
    this.bottomSpacer.style.height = `${(this.items.length - visibleRange.end) * this.itemHeight}px`;
  }

  /**
   * Render visible items
   */
  render() {
    const visibleRange = this.calculateVisibleRange();
    
    // Check if range changed
    if (visibleRange.start === this.visibleStart && visibleRange.end === this.visibleEnd) {
      return;
    }
    
    this.visibleStart = visibleRange.start;
    this.visibleEnd = visibleRange.end;
    
    this.updateSpacers();
    this.renderItems(visibleRange);
  }

  /**
   * Render items in range
   * @param {Object} range - Visible range
   */
  renderItems(range) {
    // Clear current content
    this.contentContainer.innerHTML = '';
    
    // Render visible items
    for (let i = range.start; i < range.end; i++) {
      const item = this.items[i];
      if (!item) {continue;}
      
      const itemElement = this.createItemElement(item, i);
      this.contentContainer.appendChild(itemElement);
    }
  }

  /**
   * Create item element
   * @param {Object} item - Item data
   * @paramnumber} index - Item index
   */
  createItemElement(item, index) {
    const element = document.createElement('div');
    element.style.position = 'absolute';
    element.style.top = `${index * this.itemHeight}px`;
    element.style.left = '0';
    element.style.right = '0';
    element.style.height = `${this.itemHeight}px`;
    element.style.boxSizing = 'border-box';
    
    // Apply template
    const template = this.itemTemplate(item, index);
    element.innerHTML = template;
    
    // Bind click event
    element.addEventListener('click', () => this.onItemClick(item, index));
    
    return element;
  }

  /**
   * Default item template
   * @param {Object} item - Item data
   * @param {number} index - Item index
   */
  defaultTemplate(item, index) {
    return `
      <div data-style="padding: 10px; border-bottom: 1px solid #eee; display: flex; align-items: center;">
        <span data-style="flex: 1;">${item.name || item.id || 'Item ' + index}</span>
        <span data-style="color: #666;">${item.value || ''}</span>
      </div>
    `;
  }

  /**
   * Scroll to specific index
   * @param {number} index - Item index
   */
  scrollToIndex(index) {
    const targetScroll = index * this.itemHeight;
    this.container.scrollTop = targetScroll;
  }

  /**
   * Get visible items
   */
  getVisibleItems() {
    return this.items.slice(this.visibleStart, this.visibleEnd);
  }

  /**
   * Refresh current view
   */
  refresh() {
    this.render();
  }

  /**
   * Destroy virtual scroll
   */
  destroy() {
    if (this.container) {
      this.container.removeEventListener('scroll', () => this.handleScroll());
      this.container.innerHTML = '';
    }
    window.removeEventListener('resize', () => this.handleResize());
    this.items = [];
    this.renderedItems.clear();
  }

  /**
   * Set item height
   * @param {number} height - New item height
   */
  setItemHeight(height) {
    this.itemHeight = height;
    this.totalHeight = this.items.length * this.itemHeight;
    this.updateSpacers();
    this.render();
  }

  /**
   * Get scroll position
   */
  getScrollPosition() {
    return {
      scrollTop: this.scrollTop,
      scrollPercentage: (this.scrollTop / (this.totalHeight - this.container.clientHeight)) * 100
    };
  }
}

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { VirtualScroll };
}
