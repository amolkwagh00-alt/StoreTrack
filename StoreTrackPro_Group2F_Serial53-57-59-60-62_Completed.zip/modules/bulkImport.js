// Bulk Import Module - Import data with validation and error handling

/**
 * Import Result class
 */
class ImportResult {
  constructor() {
    this.success = 0;
    this.failed = 0;
    this.errors = [];
    this.warnings = [];
    this.imported = [];
    this.skipped = [];
  }

  addSuccess(item) {
    this.success++;
    this.imported.push(item);
  }

  addFailure(item, error) {
    this.failed++;
    this.errors.push({ item, error });
  }

  addWarning(item, warning) {
    this.warnings.push({ item, warning });
  }

  addSkipped(item, reason) {
    this.skipped.push({ item, reason });
  }

  getTotal() {
    return this.success + this.failed + this.skipped.length;
  }

  getSummary() {
    return {
      total: this.getTotal(),
      success: this.success,
      failed: this.failed,
      skipped: this.skipped.length,
      warnings: this.warnings.length
    };
  }
}

/**
 * Bulk Import Manager
 */
class BulkImportManager {
  constructor() {
    this.validationSchemas = new Map();
    this.init();
  }

  /**
   * Initialize import manager
   */
  init() {
    this.setupDefaultSchemas();
  }

  /**
   * Setup default validation schemas
   */
  setupDefaultSchemas() {
    this.validationSchemas.set('materials', {
      barcode: { required: true, type: 'string', unique: true },
      name: { required: true, type: 'string', minLength: 1 },
      category: { required: true, type: 'string' },
      unit: { required: true, type: 'string', enum: ['pcs', 'kg', 'liters', 'meters', 'boxes'] },
      stock: { required: true, type: 'number', min: 0 },
      lowAlert: { required: false, type: 'number', min: 0 },
      reorderQty: { required: false, type: 'number', min: 0 },
      unitCost: { required: false, type: 'number', min: 0 },
      active: { required: false, type: 'boolean', default: true }
    });

    this.validationSchemas.set('transactions', {
      barcode: { required: true, type: 'string' },
      itemName: { required: true, type: 'string' },
      type: { required: true, type: 'string', enum: ['IN', 'OUT', 'ADJUSTMENT'] },
      quantity: { required: true, type: 'number', min: 1 },
      user: { required: true, type: 'string' },
      time: { required: false, type: 'date', default: () => new Date().toISOString() }
    });

    this.validationSchemas.set('users', {
      username: { required: true, type: 'string', unique: true, minLength: 3 },
      name: { required: true, type: 'string', minLength: 1 },
      role: { required: true, type: 'string', enum: ['Admin', 'Store', 'Viewer'] },
      active: { required: false, type: 'boolean', default: true }
    });
  }

  /**
   * Add custom validation schema
   * @param {string} name - Schema name
   * @param {object} schema - Validation schema
   */
  addSchema(name, schema) {
    this.validationSchemas.set(name, schema);
  }

  /**
   * Validate item against schema
   * @param {object} item - Item to validate
   * @param {object} schema - Validation schema
   * @returns {object} - Validation result
   */
  validateItem(item, schema) {
    const errors = [];
    const warnings = [];

    Object.entries(schema).forEach(([field, rules]) => {
      const value = item[field];

      // Required check
      if (rules.required && (value === undefined || value === null || value === '')) {
        errors.push(`${field} is required`);
        return;
      }

      // Skip further validation if field is not required and empty
      if (!rules.required && (value === undefined || value === null || value === '')) {
        return;
      }

      // Type check
      if (rules.type) {
        switch (rules.type) {
          case 'string':
            if (typeof value !== 'string') {
              errors.push(`${field} must be a string`);
            } else if (rules.minLength && value.length < rules.minLength) {
              errors.push(`${field} must be at least ${rules.minLength} characters`);
            } else if (rules.maxLength && value.length > rules.maxLength) {
              errors.push(`${field} must not exceed ${rules.maxLength} characters`);
            }
            break;
          case 'number':
            if (typeof value !== 'number' || isNaN(value)) {
              errors.push(`${field} must be a number`);
            } else if (rules.min !== undefined && value < rules.min) {
              errors.push(`${field} must be at least ${rules.min}`);
            } else if (rules.max !== undefined && value > rules.max) {
              errors.push(`${field} must not exceed ${rules.max}`);
            }
            break;
          case 'boolean':
            if (typeof value !== 'boolean') {
              errors.push(`${field} must be a boolean`);
            }
            break;
          case 'date':
            if (!this.isValidDate(value)) {
              errors.push(`${field} must be a valid date`);
            }
            break;
        }
      }

      // Enum check
      if (rules.enum && !rules.enum.includes(value)) {
        errors.push(`${field} must be one of: ${rules.enum.join(', ')}`);
      }

      // Unique check (will be validated during import)
      if (rules.unique) {
        warnings.push(`${field} should be unique`);
      }
    });

    return { valid: errors.length === 0, errors, warnings };
  }

  /**
   * Check if value is a valid date
   * @param {any} value - Value to check
   * @returns {boolean} - Valid date
   */
  isValidDate(value) {
    if (value instanceof Date) {return !isNaN(value);}
    if (typeof value === 'string') {return !isNaN(new Date(value));}
    return false;
  }

  /**
   * Parse CSV data
   * @param {string} csv - CSV string
   * @param {object} options - Parse options
   * @returns {Array} - Parsed data
   */
  parseCSV(csv, options = {}) {
    const delimiter = String(options.delimiter || ',').slice(0, 1) || ',';
    const hasHeaders = options.hasHeaders !== false;
    const rows = [];
    let row = [], value = '', quoted = false;
    const pushValue = () => { row.push(value.trim()); value = ''; };
    const pushRow = () => {
      pushValue();
      if (row.some(cell => cell !== '')) rows.push(row);
      row = [];
    };
    const source = String(csv ?? '').replace(/^\uFEFF/, '');
    for (let index = 0; index < source.length; index += 1) {
      const character = source[index];
      if (character === '"') {
        if (quoted && source[index + 1] === '"') { value += '"'; index += 1; }
        else { quoted = !quoted; }
      } else if (!quoted && character === delimiter) {
        pushValue();
      } else if (!quoted && (character === '\n' || character === '\r')) {
        pushRow();
        if (character === '\r' && source[index + 1] === '\n') index += 1;
      } else {
        value += character;
      }
    }
    if (quoted) { throw new Error('Malformed CSV: unclosed quoted field'); }
    if (value.length || row.length) pushRow();
    if (!rows.length) {return [];}

    const headers = hasHeaders ? rows[0].map(header => header.trim()) : [];
    const dataRows = hasHeaders ? rows.slice(1) : rows;
    return dataRows.map(values => {
      const item = {};

      if (hasHeaders) {
        headers.forEach((header, index) => {
          item[header] = values[index];
        });
      } else {
        values.forEach((value, index) => {
          item[`field${index}`] = value;
        });
      }

      return item;
    });
  }

  /**
   * Parse Excel data. In the renderer, prefer the bundled SheetJS global;
   * in Node/test contexts, use the already-declared exceljs dependency.
   * The first row of the selected worksheet is treated as the header row.
   * @param {ArrayBuffer|Buffer|Uint8Array} buffer - Excel file buffer
   * @param {object} options - Parse options (sheetName, sheetIndex, hasHeaders)
   * @returns {Promise<Array>} - Parsed data
   */
  async parseExcel(buffer, options = {}) {
    if (!buffer) {return [];}

    const sheetName = options.sheetName;
    const sheetIndex = Number.isInteger(options.sheetIndex) ? options.sheetIndex : 0;
    const globalParser = typeof globalThis !== 'undefined' ? globalThis.XLSX : null;
    if (globalParser?.read && globalParser.utils?.sheet_to_json) {
      const workbook = globalParser.read(buffer, { type: 'array', cellDates: true });
      const selectedName = sheetName || workbook.SheetNames[sheetIndex];
      const sheet = workbook.Sheets[selectedName];
      if (!sheet) {throw new Error(`Worksheet not found: ${selectedName || sheetIndex}`);}
      return globalParser.utils.sheet_to_json(sheet, {
        header: options.hasHeaders === false ? 1 : undefined,
        defval: '',
        raw: false,
      }).map((row) => {
        if (Array.isArray(row)) return row.reduce((item, value, index) => ({ ...item, [`field${index}`]: value }), {});
        return row;
      });
    }

    let ExcelJS;
    try {
      // eslint-disable-next-line global-require
      ExcelJS = require('exceljs');
    } catch (error) {
      throw new Error('Excel parser is unavailable; bundle XLSX or install exceljs');
    }
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);
    const worksheet = sheetName ? workbook.getWorksheet(sheetName) : workbook.worksheets[sheetIndex];
    if (!worksheet) {throw new Error(`Worksheet not found: ${sheetName || sheetIndex}`);}
    const rows = [];
    let headers = [];
    worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      const values = row.values.slice(1).map((value) => value instanceof Date ? value.toISOString() : value ?? '');
      if (rowNumber === 1 && options.hasHeaders !== false) {
        headers = values.map((value) => String(value).trim());
        return;
      }
      const item = {};
      values.forEach((value, index) => { item[headers[index] || `field${index}`] = value; });
      if (values.some((value) => value !== '')) rows.push(item);
    });
    return rows;
  }

  /**
   * Import data to store
   * @param {string} storeName - Store name
   * @param {Array} data - Data to import
   * @param {object} options - Import options
   * @returns {Promise<ImportResult>} - Import result
   */
  async importData(storeName, data, options = {}) {
    const result = new ImportResult();
    const schema = this.validationSchemas.get(storeName);

    if (!schema) {
      result.addFailure(null, `No validation schema found for ${storeName}`);
      return result;
    }

    const { skipDuplicates = true, updateDuplicates = false, dryRun = false } = options;

    // Get existing data for duplicate checking
    let existingData = [];
    if (skipDuplicates || updateDuplicates) {
      try {
        existingData = await gAll(storeName);
      } catch (err) {
        console.error('Failed to load existing data:', err);
      }
    }

    const seenUniqueValues = new Set();
    for (const sourceItem of data) {
      const item = { ...sourceItem };
      if (storeName === 'materials') {
        if (item.stock === undefined && item.currentStock !== undefined) item.stock = item.currentStock;
        if (item.lowAlert === undefined && item.minStock !== undefined) item.lowAlert = item.minStock;
        if (item.unitCost === undefined && item.unitPrice !== undefined) item.unitCost = item.unitPrice;
        delete item.currentStock;
        delete item.minStock;
        delete item.unitPrice;
      }
      Object.entries(schema).forEach(([field, rules]) => {
        if (item[field] === undefined && rules.default !== undefined)
          item[field] = typeof rules.default === 'function' ? rules.default() : rules.default;
      });
      // Validate item
      const validation = this.validateItem(item, schema);

      if (!validation.valid) {
        result.addFailure(item, validation.errors.join(', '));
        continue;
      }

      if (validation.warnings.length > 0) {
        result.addWarning(item, validation.warnings.join(', '));
      }

      // Check for duplicates
      const uniqueField = Object.entries(schema).find(([_, rules]) => rules.unique);
      if (uniqueField) {
        const [fieldName] = uniqueField;
        const uniqueValue = item[fieldName];
        if (seenUniqueValues.has(uniqueValue)) {
          result.addSkipped(item, `Duplicate ${fieldName} in import batch: ${uniqueValue}`);
          continue;
        }
        seenUniqueValues.add(uniqueValue);
        const existing = existingData.find(d => d[fieldName] === item[fieldName]);

        if (existing) {
          if (skipDuplicates && !updateDuplicates) {
            result.addSkipped(item, `Duplicate ${fieldName}: ${item[fieldName]}`);
            continue;
          } else if (updateDuplicates) {
            item.id = existing.id;
            if (!dryRun) {
              try {
                await dPut(storeName, item);
              } catch (err) {
                result.addFailure(item, `Failed to update: ${err.message}`);
                continue;
              }
            }
            result.addSuccess(item);
            continue;
          }
        }
      }

      // Import item
      if (!dryRun) {
        try {
          await dPut(storeName, item);
        } catch (err) {
          result.addFailure(item, `Failed to import: ${err.message}`);
          continue;
        }
      }

      result.addSuccess(item);
    }

    return result;
  }

  /**
   * Import from CSV
   * @param {string} storeName - Store name
   * @param {string} csv - CSV string
   * @param {object} options - Import options
   * @returns {Promise<ImportResult>} - Import result
   */
  async importFromCSV(storeName, csv, options = {}) {
    const data = this.parseCSV(csv, options);
    return this.importData(storeName, data, options);
  }

  /**
   * Import from Excel
   * @param {string} storeName - Store name
   * @param {ArrayBuffer} buffer - Excel file buffer
   * @param {object} options - Import options
   * @returns {Promise<ImportResult>} - Import result
   */
  async importFromExcel(storeName, buffer, options = {}) {
    const data = await this.parseExcel(buffer, options);
    return this.importData(storeName, data, options);
  }

  /**
   * Get import template for store
   * @param {string} storeName - Store name
   * @returns {string} - CSV template
   */
  getTemplate(storeName) {
    const schema = this.validationSchemas.get(storeName);
    if (!schema) {return '';}

    const headers = Object.keys(schema);
    const exampleRow = headers.map(h => {
      const rules = schema[h];
      if (rules.type === 'boolean') {return 'true';}
      if (rules.type === 'number') {return '0';}
      if (rules.enum) {return rules.enum[0];}
      return '';
    });

    return [headers.join(','), exampleRow.join(',')].join('\n');
  }

  /**
   * Download import template
   * @param {string} storeName - Store name
   */
  downloadTemplate(storeName) {
    const template = this.getTemplate(storeName);
    const blob = new Blob([template], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${storeName}_template.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }
}

/**
 * Global import manager instance
 */
const importManager = new BulkImportManager();

/**
 * Initialize bulk import
 */
function initBulkImport() {
  return importManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.BulkImport = {
    manager: importManager,
    init: initBulkImport,
    importData: (store, data, opts) => importManager.importData(store, data, opts),
    importFromCSV: (store, csv, opts) => importManager.importFromCSV(store, csv, opts),
    importFromExcel: (store, buffer, opts) => importManager.importFromExcel(store, buffer, opts),
    getTemplate: (store) => importManager.getTemplate(store),
    downloadTemplate: (store) => importManager.downloadTemplate(store),
    addSchema: (name, schema) => importManager.addSchema(name, schema),
    validateItem: (item, schema) => importManager.validateItem(item, schema)
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { BulkImportManager, ImportResult };
}
