// Advanced Sort Module - Multi-field sorting with custom comparators

/**
 * Sort Rule class
 */
class SortRule {
  constructor(field, direction = 'asc', comparator = null) {
    this.field = field;
    this.direction = direction; // 'asc' or 'desc'
    this.comparator = comparator || this.defaultComparator;
    this.id = this.generateId();
  }

  generateId() {
    return `${this.field}-${this.direction}-${Date.now()}`;
  }

  /**
   * Default comparator
   * @param {any} a - First value
   * @param {any} b - Second value
   * @returns {number} - Comparison result
   */
  defaultComparator(a, b) {
    if (a == null) {return 1;}
    if (b == null) {return -1;}
    
    if (typeof a === 'string' && typeof b === 'string') {
      return a.localeCompare(b);
    }
    
    if (a < b) {return -1;}
    if (a > b) {return 1;}
    return 0;
  }

  /**
   * Compare two items
   * @param {object} itemA - First item
   * @param {object} itemB - Second item
   * @returns {number} - Comparison result
   */
  compare(itemA, itemB) {
    const valA = itemA[this.field];
    const valB = itemB[this.field];
    
    const result = this.comparator(valA, valB);
    return this.direction === 'asc' ? result : -result;
  }
}

/**
 * Advanced Sort Manager
 */
class AdvancedSortManager {
  constructor() {
    this.sortRules = [];
    this.savedSorts = new Map();
    this.init();
  }

  /**
   * Initialize sort manager
   */
  init() {
    this.loadSavedSorts();
  }

  /**
   * Add sort rule
   * @param {string} field - Field name
   * @param {string} direction - Sort direction
   * @param {Function} comparator - Custom comparator
   */
  addRule(field, direction = 'asc', comparator = null) {
    const rule = new SortRule(field, direction, comparator);
    this.sortRules.push(rule);
    return rule;
  }

  /**
   * Remove sort rule by ID
   * @param {string} id - Rule ID
   */
  removeRule(id) {
    this.sortRules = this.sortRules.filter(r => r.id !== id);
  }

  /**
   * Clear all sort rules
   */
  clearRules() {
    this.sortRules = [];
  }

  /**
   * Update sort rule
   * @param {string} id - Rule ID
   * @param {object} updates - Updates to apply
   */
  updateRule(id, updates) {
    const rule = this.sortRules.find(r => r.id === id);
    if (rule) {
      Object.assign(rule, updates);
    }
  }

  /**
   * Get all sort rules
   * @returns {Array} - Array of sort rules
   */
  getRules() {
    return this.sortRules;
  }

  /**
   * Sort data with current rules
   * @param {Array} data - Data to sort
   * @returns {Array} - Sorted data
   */
  sort(data) {
    if (this.sortRules.length === 0) {
      return data;
    }

    return [...data].sort((a, b) => {
      for (const rule of this.sortRules) {
        const result = rule.compare(a, b);
        if (result !== 0) {
          return result;
        }
      }
      return 0;
    });
  }

  /**
   * Sort IndexedDB with rules
   * @param {string} storeName - Store name
   * @returns {Promise<Array>} - Sorted data
   */
  async sortDB(storeName) {
    try {
      const data = await gAll(storeName);
      return this.sort(data);
    } catch (err) {
      console.error('Sort failed:', err);
      return [];
    }
  }

  /**
   * Save current sort configuration
   * @param {string} name - Sort name
   * @param {string} description - Sort description
   */
  async saveSort(name, description = '') {
    const sort = {
      id: this.generateSortId(name),
      name,
      description,
      rules: JSON.parse(JSON.stringify(this.sortRules)),
      createdAt: new Date().toISOString()
    };

    this.savedSorts.set(sort.id, sort);
    await this.saveSortsToStorage();
    
    return sort;
  }

  /**
   * Generate sort ID
   * @param {string} name - Sort name
   * @returns {string} - Sort ID
   */
  generateSortId(name) {
    return name.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now();
  }

  /**
   * Load saved sort
   * @param {string} id - Sort ID
   */
  loadSort(id) {
    const sort = this.savedSorts.get(id);
    if (sort) {
      this.sortRules = sort.rules.map(r => new SortRule(r.field, r.direction, r.comparator));
    }
    return sort;
  }

  /**
   * Delete saved sort
   * @param {string} id - Sort ID
   */
  async deleteSort(id) {
    this.savedSorts.delete(id);
    await this.saveSortsToStorage();
  }

  /**
   * Get all saved sorts
   * @returns {Array} - Array of saved sorts
   */
  getSavedSorts() {
    return Array.from(this.savedSorts.values());
  }

  /**
   * Load saved sorts from storage
   */
  async loadSavedSorts() {
    try {
      const sorts = await gAll('saved_sorts');
      sorts.forEach(sort => {
        this.savedSorts.set(sort.id, sort);
      });
    } catch (err) {
      console.error('Failed to load saved sorts:', err);
    }
  }

  /**
   * Save sorts to storage
   */
  async saveSortsToStorage() {
    try {
      await dClr('saved_sorts');
      await batchPut('saved_sorts', Array.from(this.savedSorts.values()));
    } catch (err) {
      console.error('Failed to save sorts:', err);
    }
  }

  /**
   * Export sort as JSON
   * @param {string} id - Sort ID
   * @returns {string} - JSON string
   */
  exportSort(id) {
    const sort = this.savedSorts.get(id);
    if (sort) {
      return JSON.stringify(sort, null, 2);
    }
    return null;
  }

  /**
   * Import sort from JSON
   * @param {string} json - JSON string
   * @returns {object} - Imported sort
   */
  importSort(json) {
    try {
      const sort = JSON.parse(json);
      sort.id = this.generateSortId(sort.name);
      sort.createdAt = new Date().toISOString();
      
      this.savedSorts.set(sort.id, sort);
      this.saveSortsToStorage();
      
      return sort;
    } catch (err) {
      console.error('Failed to import sort:', err);
      return null;
    }
  }

  /**
   * Get predefined comparators
   * @returns {object} - Comparator functions
   */
  getComparators() {
    return {
      default: (a, b) => {
        if (a == null) {return 1;}
        if (b == null) {return -1;}
        if (typeof a === 'string' && typeof b === 'string') {return a.localeCompare(b);}
        if (a < b) {return -1;}
        if (a > b) {return 1;}
        return 0;
      },
      numeric: (a, b) => {
        const numA = parseFloat(a) || 0;
        const numB = parseFloat(b) || 0;
        return numA - numB;
      },
      date: (a, b) => {
        const dateA = new Date(a).getTime() || 0;
        const dateB = new Date(b).getTime() || 0;
        return dateA - dateB;
      },
      caseInsensitive: (a, b) => {
        const strA = String(a).toLowerCase();
        const strB = String(b).toLowerCase();
        return strA.localeCompare(strB);
      },
      natural: (a, b) => {
        const strA = String(a);
        const strB = String(b);
        return strA.localeCompare(strB, undefined, { numeric: true, sensitivity: 'base' });
      },
      length: (a, b) => {
        const lenA = String(a).length;
        const lenB = String(b).length;
        return lenA - lenB;
      }
    };
  }

  /**
   * Get comparator by name
   * @param {string} name - Comparator name
   * @returns {Function} - Comparator function
   */
  getComparator(name) {
    const comparators = this.getComparators();
    return comparators[name] || comparators.default;
  }

  /**
   * Get field definitions for data source
   * @param {string} source - Data source name
   * @returns {Array} - Field definitions
   */
  getFieldDefinitions(source) {
    const definitions = {
      materials: [
        { field: 'barcode', label: 'Barcode', type: 'text', defaultComparator: 'default' },
        { field: 'name', label: 'Name', type: 'text', defaultComparator: 'caseInsensitive' },
        { field: 'category', label: 'Category', type: 'text', defaultComparator: 'default' },
        { field: 'currentStock', label: 'Current Stock', type: 'number', defaultComparator: 'numeric' },
        { field: 'minStock', label: 'Min Stock', type: 'number', defaultComparator: 'numeric' },
        { field: 'unit', label: 'Unit', type: 'text', defaultComparator: 'default' },
        { field: 'active', label: 'Active', type: 'boolean', defaultComparator: 'default' }
      ],
      transactions: [
        { field: 'barcode', label: 'Barcode', type: 'text', defaultComparator: 'default' },
        { field: 'itemName', label: 'Item Name', type: 'text', defaultComparator: 'caseInsensitive' },
        { field: 'type', label: 'Type', type: 'text', defaultComparator: 'default' },
        { field: 'quantity', label: 'Quantity', type: 'number', defaultComparator: 'numeric' },
        { field: 'time', label: 'Date/Time', type: 'date', defaultComparator: 'date' },
        { field: 'user', label: 'User', type: 'text', defaultComparator: 'caseInsensitive' }
      ],
      users: [
        { field: 'username', label: 'Username', type: 'text', defaultComparator: 'caseInsensitive' },
        { field: 'name', label: 'Name', type: 'text', defaultComparator: 'caseInsensitive' },
        { field: 'role', label: 'Role', type: 'text', defaultComparator: 'default' },
        { field: 'active', label: 'Active', type: 'boolean', defaultComparator: 'default' }
      ]
    };
    
    return definitions[source] || [];
  }
}

/**
 * Global sort manager instance
 */
const sortManager = new AdvancedSortManager();

/**
 * Initialize advanced sort
 */
function initAdvancedSort() {
  return sortManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.AdvancedSort = {
    manager: sortManager,
    init: initAdvancedSort,
    addRule: (field, dir, comp) => sortManager.addRule(field, dir, comp),
    removeRule: (id) => sortManager.removeRule(id),
    clearRules: () => sortManager.clearRules(),
    sort: (data) => sortManager.sort(data),
    sortDB: (store) => sortManager.sortDB(store),
    saveSort: (name, desc) => sortManager.saveSort(name, desc),
    loadSort: (id) => sortManager.loadSort(id),
    deleteSort: (id) => sortManager.deleteSort(id),
    getSavedSorts: () => sortManager.getSavedSorts(),
    exportSort: (id) => sortManager.exportSort(id),
    importSort: (json) => sortManager.importSort(json),
    getComparators: () => sortManager.getComparators(),
    getComparator: (name) => sortManager.getComparator(name),
    getFieldDefinitions: (source) => sortManager.getFieldDefinitions(source)
  };
}
