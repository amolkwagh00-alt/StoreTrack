// Bin Location Management Module - Warehouse bin location management

/**
 * Bin Location class
 */
class BinLocation {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.binCode = config.binCode || '';
    this.name = config.name || '';
    this.zone = config.zone || '';
    this.aisle = config.aisle || '';
    this.rack = config.rack || '';
    this.level = config.level || '';
    this.position = config.position || ''; // position within level
    this.type = config.type || 'storage'; // storage, picking, receiving, shipping
    this.capacity = config.capacity || 0;
    this.currentLoad = config.currentLoad || 0;
    this.status = config.status || 'active'; // active, inactive, blocked
    this.itemId = config.itemId || null;
    this.barcode = config.barcode || '';
    this.itemName = config.itemName || '';
    this.quantity = config.quantity || 0;
    this.createdAt = config.createdAt || new Date().toISOString();
    this.updatedAt = config.updatedAt || new Date().toISOString();
  }

  generateId() {
    return `bin-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get full location code
   * @returns {string} - Full location code
   */
  getFullLocationCode() {
    const parts = [this.zone, this.aisle, this.rack, this.level, this.position];
    return parts.filter(p => p).join('-');
  }

  /**
   * Get capacity percentage
   * @returns {number} - Capacity percentage
   */
  getCapacityPercentage() {
    if (this.capacity === 0) {return 0;}
    return (this.currentLoad / this.capacity) * 100;
  }

  /**
   * Is available
   * @returns {boolean} - Is available
   */
  isAvailable() {
    return this.status === 'active' && (this.itemId === null || this.quantity === 0);
  }

  /**
   * Is full
   * @returns {boolean} - Is full
   */
  isFull() {
    return this.currentLoad >= this.capacity;
  }
}

/**
 * Zone class
 */
class Zone {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.code = config.code || '';
    this.name = config.name || '';
    this.type = config.type || 'general'; // general, cold, frozen, hazardous, high_security
    this.description = config.description || '';
    this.capacity = config.capacity || 0;
    this.currentLoad = config.currentLoad || 0;
    this.status = config.status || 'active';
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `zone-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Bin Location Manager
 */
class BinLocationManager {
  constructor() {
    this.bins = new Map();
    this.zones = new Map();
    this.init();
  }

  /**
   * Initialize bin location manager
   */
  async init() {
    await this.loadBins();
    await this.loadZones();
  }

  /**
   * Load bins from storage
   */
  async loadBins() {
    try {
      const bins = await gAll('bin_locations');
      bins.forEach(b => {
        this.bins.set(b.id, new BinLocation(b));
      });
    } catch (err) {
      console.error('Failed to load bin locations:', err);
    }
  }

  /**
   * Load zones from storage
   */
  async loadZones() {
    try {
      const zones = await gAll('warehouse_zones');
      zones.forEach(z => {
        this.zones.set(z.id, new Zone(z));
      });
    } catch (err) {
      console.error('Failed to load warehouse zones:', err);
    }
  }

  /**
   * Create bin location
   * @param {object} config - Bin configuration
   * @returns {BinLocation} - Created bin
   */
  async createBin(config) {
    const bin = new BinLocation(config);
    this.bins.set(bin.id, bin);
    await this.saveBin(bin);
    return bin;
  }

  /**
   * Update bin
   * @param {string} id - Bin ID
   * @param {object} updates - Updates to apply
   * @returns {BinLocation} - Updated bin
   */
  async updateBin(id, updates) {
    const bin = this.bins.get(id);
    if (bin) {
      Object.assign(bin, updates);
      bin.updatedAt = new Date().toISOString();
      await this.saveBin(bin);
    }
    return bin;
  }

  /**
   * Delete bin
   * @param {string} id - Bin ID
   */
  async deleteBin(id) {
    this.bins.delete(id);
    await dDel('bin_locations', id);
  }

  /**
   * Save bin to storage
   * @param {BinLocation} bin - Bin to save
   */
  async saveBin(bin) {
    try {
      await dPut('bin_locations', bin);
    } catch (err) {
      console.error('Failed to save bin location:', err);
    }
  }

  /**
   * Assign item to bin
   * @param {string} binId - Bin ID
   * @param {object} itemData - Item data
   * @returns {BinLocation} - Updated bin
   */
  async assignItemToBin(binId, itemData) {
    const bin = this.bins.get(binId);
    if (!bin) {
      throw new Error('Bin not found');
    }

    if (bin.status !== 'active') throw new Error('Cannot assign inventory to an inactive or blocked bin');
    const quantity = Number(itemData.quantity);
    if (!Number.isFinite(quantity) || quantity < 0) throw new Error('Bin quantity must be a non-negative number');
    if (bin.capacity > 0 && quantity > Number(bin.capacity)) throw new Error('Assignment exceeds bin capacity');
    const occupied = (bin.itemId !== null && bin.itemId !== undefined || bin.barcode) && Number(bin.quantity) > 0;
    const incomingId = itemData.itemId ?? null;
    const sameItem = (incomingId !== null && String(bin.itemId) === String(incomingId)) ||
      (itemData.barcode && bin.barcode === itemData.barcode);
    if (occupied && !sameItem) throw new Error(`Bin ${bin.binCode || binId} already contains a different item`);

    bin.itemId = itemData.itemId ?? (sameItem ? bin.itemId : null);
    bin.barcode = itemData.barcode ?? (sameItem ? bin.barcode : '');
    bin.itemName = itemData.itemName ?? (sameItem ? bin.itemName : '');
    bin.quantity = quantity;
    bin.currentLoad = quantity;
    bin.updatedAt = new Date().toISOString();

    await this.saveBin(bin);

    // Log activity
    if (typeof window !== 'undefined' && window.ActivityTracking) {
      await window.ActivityTracking.logActivity('bin_item_assigned', 'warehouse', binId, {
        binCode: bin.binCode,
        barcode: itemData.barcode,
        quantity: itemData.quantity
      });
    }

    return bin;
  }

  /**
   * Remove item from bin
   * @param {string} binId - Bin ID
   */
  async removeItemFromBin(binId) {
    const bin = this.bins.get(binId);
    if (bin) {
      bin.itemId = null;
      bin.barcode = '';
      bin.itemName = '';
      bin.quantity = 0;
      bin.currentLoad = 0;
      bin.updatedAt = new Date().toISOString();
      await this.saveBin(bin);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('bin_item_removed', 'warehouse', binId, {
          binCode: bin.binCode
        });
      }
    }
  }

  /**
   * Find available bin for item
   * @param {object} itemData - Item data
   * @param {string} preferredZone - Preferred zone
   * @returns {BinLocation|null} - Available bin
   */
  findAvailableBin(itemData, preferredZone = null) {
    const availableBins = this.getAllBins().filter(b => 
      b.isAvailable() && 
      b.capacity >= itemData.quantity &&
      (preferredZone ? b.zone === preferredZone : true)
    );

    // Prefer bins of same type
    const sameTypeBins = availableBins.filter(b => b.itemId === itemData.itemId);
    if (sameTypeBins.length > 0) {
      return sameTypeBins[0];
    }

    return availableBins[0] || null;
  }

  /**
   * Create zone
   * @param {object} config - Zone configuration
   * @returns {Zone} - Created zone
   */
  async createZone(config) {
    const zone = new Zone(config);
    this.zones.set(zone.id, zone);
    await this.saveZone(zone);
    return zone;
  }

  /**
   * Update zone
   * @param {string} id - Zone ID
   * @param {object} updates - Updates to apply
   * @returns {Zone} - Updated zone
   */
  async updateZone(id, updates) {
    const zone = this.zones.get(id);
    if (zone) {
      Object.assign(zone, updates);
      await this.saveZone(zone);
    }
    return zone;
  }

  /**
   * Delete zone
   * @param {string} id - Zone ID
   */
  async deleteZone(id) {
    this.zones.delete(id);
    await dDel('warehouse_zones', id);
  }

  /**
   * Save zone to storage
   * @param {Zone} zone - Zone to save
   */
  async saveZone(zone) {
    try {
      await dPut('warehouse_zones', zone);
    } catch (err) {
      console.error('Failed to save warehouse zone:', err);
    }
  }

  /**
   * Get bin
   * @param {string} id - Bin ID
   * @returns {BinLocation} - Bin
   */
  getBin(id) {
    return this.bins.get(id);
  }

  /**
   * Get bin by code
   * @param {string} binCode - Bin code
   * @returns {BinLocation} - Bin
   */
  getBinByCode(binCode) {
    return Array.from(this.bins.values()).find(b => b.binCode === binCode);
  }

  /**
   * Get bins by zone
   * @param {string} zone - Zone
   * @returns {Array} - Bins
   */
  getBinsByZone(zone) {
    return this.getAllBins().filter(b => b.zone === zone);
  }

  /**
   * Get bins by type
   * @param {string} type - Bin type
   * @returns {Array} - Bins
   */
  getBinsByType(type) {
    return this.getAllBins().filter(b => b.type === type);
  }

  /**
   * Get bins by item
   * @param {string} barcode - Item barcode
   * @returns {Array} - Bins
   */
  getBinsByItem(barcode) {
    return this.getAllBins().filter(b => b.barcode === barcode);
  }

  /**
   * Get all bins
   * @returns {Array} - Array of bins
   */
  getAllBins() {
    return Array.from(this.bins.values());
  }

  /**
   * Get available bins
   * @returns {Array} - Available bins
   */
  getAvailableBins() {
    return this.getAllBins().filter(b => b.isAvailable());
  }

  /**
   * Get full bins
   * @returns {Array} - Full bins
   */
  getFullBins() {
    return this.getAllBins().filter(b => b.isFull());
  }

  /**
   * Get zone
   * @param {string} id - Zone ID
   * @returns {Zone} - Zone
   */
  getZone(id) {
    return this.zones.get(id);
  }

  /**
   * Get zone by code
   * @param {string} code - Zone code
   * @returns {Zone} - Zone
   */
  getZoneByCode(code) {
    return Array.from(this.zones.values()).find(z => z.code === code);
  }

  /**
   * Get all zones
   * @returns {Array} - Array of zones
   */
  getAllZones() {
    return Array.from(this.zones.values());
  }

  /**
   * Get active zones
   * @returns {Array} - Active zones
   */
  getActiveZones() {
    return this.getAllZones().filter(z => z.status === 'active');
  }

  /**
   * Get warehouse map
   * @returns {object} - Warehouse map
   */
  getWarehouseMap() {
    const zones = this.getActiveZones();
    const map = {};

    for (const zone of zones) {
      map[zone.code] = {
        zone: zone,
        bins: this.getBinsByZone(zone.code),
        capacity: zone.capacity,
        currentLoad: zone.currentLoad,
        utilization: zone.capacity > 0 ? (zone.currentLoad / zone.capacity) * 100 : 0
      };
    }

    return map;
  }

  /**
   * Get item location
   * @param {string} barcode - Item barcode
   * @returns {BinLocation|null} - Bin location
   */
  getItemLocation(barcode) {
    return this.getBinsByItem(barcode)[0] || null;
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const bins = this.getAllBins();
    const zones = this.getAllZones();

    return {
      totalBins: bins.length,
      activeBins: bins.filter(b => b.status === 'active').length,
      occupiedBins: bins.filter(b => b.itemId !== null).length,
      availableBins: bins.filter(b => b.isAvailable()).length,
      fullBins: bins.filter(b => b.isFull()).length,
      totalCapacity: bins.reduce((sum, b) => sum + b.capacity, 0),
      totalLoad: bins.reduce((sum, b) => sum + b.currentLoad, 0),
      avgUtilization: bins.length > 0 
        ? bins.reduce((sum, b) => sum + b.getCapacityPercentage(), 0) / bins.length 
        : 0,
      byType: this.getTypeCounts(bins),
      byZone: this.getZoneCounts(bins),
      totalZones: zones.length,
      activeZones: zones.filter(z => z.status === 'active').length
    };
  }

  /**
   * Get type counts
   * @param {Array} bins - Bins
   * @returns {object} - Type counts
   */
  getTypeCounts(bins) {
    const counts = {};
    bins.forEach(b => {
      counts[b.type] = (counts[b.type] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get zone counts
   * @param {Array} bins - Bins
   * @returns {object} - Zone counts
   */
  getZoneCounts(bins) {
    const counts = {};
    bins.forEach(b => {
      counts[b.zone] = (counts[b.zone] || 0) + 1;
    });
    return counts;
  }
}

/**
 * Global bin location manager instance
 */
const binLocationManager = new BinLocationManager();

/**
 * Initialize bin location management
 */
async function initBinLocationManagement() {
  await binLocationManager.init();
  return binLocationManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.BinLocationManagement = {
    manager: binLocationManager,
    init: initBinLocationManagement,
    createBin: (config) => binLocationManager.createBin(config),
    updateBin: (id, updates) => binLocationManager.updateBin(id, updates),
    deleteBin: (id) => binLocationManager.deleteBin(id),
    getBin: (id) => binLocationManager.getBin(id),
    getBinByCode: (binCode) => binLocationManager.getBinByCode(binCode),
    getBinsByZone: (zone) => binLocationManager.getBinsByZone(zone),
    getBinsByType: (type) => binLocationManager.getBinsByType(type),
    getBinsByItem: (barcode) => binLocationManager.getBinsByItem(barcode),
    getAllBins: () => binLocationManager.getAllBins(),
    getAvailableBins: () => binLocationManager.getAvailableBins(),
    getFullBins: () => binLocationManager.getFullBins(),
    assignItemToBin: (binId, data) => binLocationManager.assignItemToBin(binId, data),
    removeItemFromBin: (binId) => binLocationManager.removeItemFromBin(binId),
    findAvailableBin: (itemData, zone) => binLocationManager.findAvailableBin(itemData, zone),
    createZone: (config) => binLocationManager.createZone(config),
    updateZone: (id, updates) => binLocationManager.updateZone(id, updates),
    deleteZone: (id) => binLocationManager.deleteZone(id),
    getZone: (id) => binLocationManager.getZone(id),
    getZoneByCode: (code) => binLocationManager.getZoneByCode(code),
    getAllZones: () => binLocationManager.getAllZones(),
    getActiveZones: () => binLocationManager.getActiveZones(),
    getWarehouseMap: () => binLocationManager.getWarehouseMap(),
    getItemLocation: (barcode) => binLocationManager.getItemLocation(barcode),
    getStats: () => binLocationManager.getStatistics()
  };
}
