// PDF Export Module - Export reports and data to PDF

/**
 * PDF Export class for generating PDF documents
 */
class PDFExport {
  constructor(options = {}) {
    this.options = {
      pageSize: options.pageSize || 'A4',
      orientation: options.orientation || 'portrait',
      margin: options.margin || 20,
      fontSize: options.fontSize || 12,
      fontFamily: options.fontFamily || 'Arial',
      ...options
    };
  }

  /**
   * Generate PDF from HTML content
   * @param {string} html - HTML content
   * @param {string} filename - Output filename
   */
  async fromHTML(html, filename = 'document.pdf') {
    try {
      if (typeof window !== 'undefined' && window.printBridge) {
        const result = await window.printBridge.savePDF({
          html: html,
          filename: filename,
          options: this.options
        });
        
        if (result.error) {
          throw new Error(result.error);
        }
        
        return result;
      } else {
        // Fallback: Use browser print
        this.printHTML(html);
        return { ok: true, message: 'Print dialog opened' };
      }
    } catch (err) {
      console.error('PDF export error:', err);
      throw err;
    }
  }

  /**
   * Print HTML content (fallback method)
   * @param {string} html - HTML content
   */
  printHTML(html) {
    // NOTE: window.open('', '_blank') inherits the opener's CSP in Chromium
    // (anti-bypass measure), so its <style> block was being silently
    // dropped. window.printBridge.printContent() creates a real top-level
    // window in the main process (no opener relationship, navigates via a
    // data: URL through the isolated, non-CSP'd printSession), so its
    // styling actually renders. Same fix as modules/pm.js.
    const fullHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Print Document</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f4f4f4; }
          </style>
        </head>
        <body>
          ${html}
        </body>
        </html>
      `;
    window.printPopupHtml(fullHtml);
  }

  /**
   * Generate PDF from data
   * @param {object} data - Data object
   * @param {string} filename - Output filename
   */
  async fromData(data, filename = 'data.pdf') {
    const html = this.dataToHTML(data);
    return this.fromHTML(html, filename);
  }

  /**
   * Convert data to HTML
   * @param {object} data - Data object
   * @returns {string} - HTML string
   */
  dataToHTML(data) {
    let html = `
      <div style="font-family: ${this.options.fontFamily}; font-size: ${this.options.fontSize}px;">
    `;
    
    if (data.title) {
      html += `<h1 style="text-align: center; margin-bottom: 20px;">${data.title}</h1>`;
    }
    
    if (data.description) {
      html += `<p style="text-align: center; margin-bottom: 20px; color: #666;">${data.description}</p>`;
    }
    
    if (data.meta) {
      html += `<div style="margin-bottom: 20px; font-size: 10px; color: #999;">`;
      Object.entries(data.meta).forEach(([key, value]) => {
        html += `<span style="margin-right: 20px;"><strong>${key}:</strong> ${value}</span>`;
      });
      html += `</div>`;
    }
    
    if (data.tables && data.tables.length > 0) {
      data.tables.forEach(table => {
        html += this.tableToHTML(table);
      });
    }
    
    html += '</div>';
    return html;
  }

  /**
   * Convert table data to HTML
   * @param {object} table - Table object
   * @returns {string} - HTML string
   */
  tableToHTML(table) {
    let html = `
      <div style="margin-bottom: 30px;">
        ${table.title ? `<h2>${table.title}</h2>` : ''}
        <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
    `;
    
    // Header
    if (table.headers) {
      html += '<thead><tr>';
      table.headers.forEach(header => {
        html += `<th style="border: 1px solid #ddd; padding: 8px; background-color: #f4f4f4; text-align: left;">${header}</th>`;
      });
      html += '</tr></thead>';
    }
    
    // Body
    html += '<tbody>';
    table.rows.forEach(row => {
      html += '<tr>';
      row.forEach(cell => {
        html += `<td style="border: 1px solid #ddd; padding: 8px;">${cell || ''}</td>`;
      });
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    
    return html;
  }

  /**
   * Generate PDF from report
   * @param {object} report - Report object from ReportBuilder
   * @param {string} filename - Output filename
   */
  async fromReport(report, filename = 'report.pdf') {
    const html = this.reportToHTML(report);
    return this.fromHTML(html, filename);
  }

  /**
   * Convert report to HTML
   * @param {object} report - Report object
   * @returns {string} - HTML string
   */
  reportToHTML(report) {
    let html = `
      <div style="font-family: ${this.options.fontFamily}; font-size: ${this.options.fontSize}px;">
        <h1 style="text-align: center; margin-bottom: 20px;">${report.config.title}</h1>
        <p style="text-align: center; margin-bottom: 20px; color: #666;">${report.config.description || ''}</p>
        <div style="margin-bottom: 20px; font-size: 10px; color: #999; text-align: center;">
          <span>Generated: ${new Date(report.generatedAt).toLocaleString()}</span>
          <span style="margin-left: 20px;">Total Records: ${report.totalRecords}</span>
        </div>
    `;
    
    report.groups.forEach(group => {
      html += `
        <div style="margin-bottom: 30px;">
          ${report.config.groupBy ? `<h2>${group.name}</h2>` : ''}
          <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
            <thead>
              <tr>
                ${report.config.columns.map(col => 
                  `<th style="border: 1px solid #ddd; padding: 8px; background-color: #f4f4f4; text-align: ${col.align};">${col.label}</th>`
                ).join('')}
              </tr>
            </thead>
            <tbody>
              ${group.data.map(item => `
                <tr>
                  ${report.config.columns.map(col => {
                    let value = item[col.field];
                    if (col.format && typeof col.format === 'function') {
                      value = col.format(value);
                    }
                    return `<td style="border: 1px solid #ddd; padding: 8px; text-align: ${col.align};">${value || ''}</td>`;
                  }).join('')}
                </tr>
              `).join('')}
            </tbody>
          </table>
          ${report.config.aggregations.length > 0 ? `
            <div style="margin-top: 10px; font-size: 11px; color: #666;">
              <strong>Aggregations:</strong>
              ${report.config.aggregations.map(agg => 
                `<span style="margin-left: 10px;">${agg.label}: ${group.aggregations[agg.label] || 0}</span>`
              ).join('')}
            </div>
          ` : ''}
        </div>
      `;
    });
    
    html += '</div>';
    return html;
  }

  /**
   * Set page size
   * @param {string} size - Page size (A4, Letter, etc.)
   */
  setPageSize(size) {
    this.options.pageSize = size;
    return this;
  }

  /**
   * Set orientation
   * @param {string} orientation - Orientation (portrait, landscape)
   */
  setOrientation(orientation) {
    this.options.orientation = orientation;
    return this;
  }

  /**
   * Set margin
   * @param {number} margin - Margin in pixels
   */
  setMargin(margin) {
    this.options.margin = margin;
    return this;
  }
}

/**
 * Quick PDF export functions
 */
function exportReportToPDF(report, filename) {
  const exporter = new PDFExport();
  return exporter.fromReport(report, filename);
}

function exportHTMLToPDF(html, filename) {
  const exporter = new PDFExport();
  return exporter.fromHTML(html, filename);
}

function exportDataToPDF(data, filename) {
  const exporter = new PDFExport();
  return exporter.fromData(data, filename);
}

/**
 * Print function for immediate printing
 */
function printReport(report) {
  const exporter = new PDFExport();
  const html = exporter.reportToHTML(report);
  exporter.printHTML(html);
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.PDFExport = {
    PDFExport,
    exportReport: exportReportToPDF,
    exportHTML: exportHTMLToPDF,
    exportData: exportDataToPDF,
    print: printReport
  };
}
