/* exported hashPassword, verifyPassword */
// ── Password Hashing & Authentication Helpers ─────────────────────────────────────
// SECURITY FIX: plain `===` comparisons on password/hash strings leak timing
// information (the comparison returns as soon as it finds a mismatched
// character). This is a minor risk for a LAN desktop app, but it's cheap to
// close — compare every character regardless of an early mismatch.
function _safeCompare(a,b){
  if(typeof a!=='string'||typeof b!=='string'){return false;}
  if(a.length!==b.length){return false;}
  let diff=0;
  for(let i=0;i<a.length;i++){diff|=a.charCodeAt(i)^b.charCodeAt(i);}
  return diff===0;
}

// Hash type detection helpers
function _isBcrypt(h){return typeof h==='string'&&h.startsWith('$2');}
function _isPbkdf2(h){return typeof h==='string'&&h.startsWith('$pbkdf2$');}

async function _sha256(plain){
  const enc=new TextEncoder();
  const buf=await crypto.subtle.digest('SHA-256',enc.encode(plain));
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}

async function hashPassword(plain){
  if(window.authBridge){
    try{const r=await window.authBridge.hashPassword(plain);if(r&&r.ok){return r.hash;}}catch(_){}
  }
  return _sha256(plain);
}

async function verifyPassword(plain,storedHash){
  if(!storedHash){return false;}
  // PBKDF2 hash — verify via authBridge (main process has crypto)
  if(_isPbkdf2(storedHash)){
    if(window.authBridge){
      try{const r=await window.authBridge.verifyPassword(plain,storedHash);if(r&&r.ok){return r.valid;}}catch(_){}
    }
    return false;
  }
  // Legacy bcrypt hash — verify via authBridge
  if(_isBcrypt(storedHash)){
    if(window.authBridge){
      try{const r=await window.authBridge.verifyPassword(plain,storedHash);if(r&&r.ok){return r.valid;}}catch(_){}
    }
    return false;
  }
  // Legacy SHA-256 hash (64 hex chars) — compare directly in renderer
  return _safeCompare(await _sha256(plain),storedHash);
}
