// Automated Alerts Module - Automated alert generation and management

/**
 * Automated Alert class
 */
class AutomatedAlert {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.type = config.type || 'system'; // system, inventory, security, performance
    this.category = config.category || '';
    this.eventType = config.eventType || '';
    this.source = config.source || ''; // sensor, rule, schedule, manual
    this.sourceId = config.sourceId || '';
    this.severity = config.severity || 'medium'; // low, medium, high, critical
    this.title = config.title || '';
    this.message = config.message || '';
    this.data = config.data || {};
    this.triggeredAt = config.triggeredAt || new Date().toISOString();
    this.expiresAt = config.expiresAt || null;
    this.status = config.status || 'active'; // active, acknowledged, resolved, expired
    this.acknowledgedAt = config.acknowledgedAt || null;
    this.acknowledgedBy = config.acknowledgedBy || null;
    this.resolvedAt = config.resolvedAt || null;
    this.resolvedBy = config.resolvedBy || null;
    this.resolution = config.resolution || '';
    this.notificationSent = config.notificationSent || false;
    this.notificationChannels = config.notificationChannels || [];
    this.recipients = config.recipients || [];
    this.metadata = config.metadata || {};
  }

  generateId() {
    return `alert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Acknowledge alert
   * @param {string} userId - User ID
   */
  acknowledge(userId) {
    this.status = 'acknowledged';
    this.acknowledgedAt = new Date().toISOString();
    this.acknowledgedBy = userId;
  }

  /**
   * Resolve alert
   * @param {string} userId - User ID
   * @param {string} resolution - Resolution description
   */
  resolve(userId, resolution = '') {
    this.status = 'resolved';
    this.resolvedAt = new Date().toISOString();
    this.resolvedBy = userId;
    this.resolution = resolution;
  }

  /**
   * Check if expired
   * @returns {boolean} - Is expired
   */
  isExpired() {
    if (!this.expiresAt) {return false;}
    return new Date() >= new Date(this.expiresAt);
  }
}

/**
 * Alert Rule class
 */
class AlertRule {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.name = config.name || '';
    this.description = config.description || '';
    this.type = config.type || 'system';
    this.category = config.category || '';
    this.condition = config.condition || '';
    this.parameters = config.parameters || {};
    this.severity = config.severity || 'medium';
    this.enabled = config.enabled !== false;
    this.notificationChannels = config.notificationChannels || ['in-app'];
    this.recipients = config.recipients || [];
    this.cooldownPeriod = config.cooldownPeriod || 300; // seconds
    this.lastTriggered = config.lastTriggered || null;
    this.triggerCount = config.triggerCount || 0;
    this.schedule = config.schedule || null; // cron-like schedule
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `alert-rule-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Check if rule should trigger
   * @param {object} context - Context data
   * @returns {boolean} - Should trigger
   */
  shouldTrigger(context) {
    if (!this.enabled) {return false;}

    // Check cooldown
    if (this.lastTriggered) {
      const elapsed = (Date.now() - new Date(this.lastTriggered).getTime()) / 1000;
      if (elapsed < this.cooldownPeriod) {return false;}
    }

    // Check condition
    return this.evaluateCondition(context);
  }

  /**
   * Evaluate condition
   * @param {object} context - Context data
   * @returns {boolean} - Condition result
   */
  evaluateCondition(context) {
    try {
      // Simple condition evaluation
      const { condition, parameters } = this;
      const { value, threshold } = context;

      if (condition === 'value_gt') {return value > (parameters.threshold || threshold);}
      if (condition === 'value_lt') {return value < (parameters.threshold || threshold);}
      if (condition === 'value_eq') {return value === (parameters.threshold || threshold);}
      if (condition === 'value_between') {return value >= parameters.min && value <= parameters.max;}
      if (condition === 'stock_low') {return context.currentStock < context.minStock;}
      if (condition === 'stock_out') {return context.currentStock <= 0;}
      if (condition === 'device_offline') {return context.isOffline === true;}
      if (condition === 'battery_low') {return context.batteryLevel < (parameters.threshold || 20);}
      if (condition === 'anomaly_detected') {return context.hasAnomaly === true;}
      if (condition === 'schedule') {return this.checkSchedule();}

      return false;
    } catch (err) {
      console.error('Failed to evaluate alert condition:', err);
      return false;
    }
  }

  /**
   * Check schedule
   * @returns {boolean} - Schedule match
   */
  checkSchedule() {
    if (!this.schedule) {return false;}
    // Simplified schedule check
    const now = new Date();
    const hour = now.getHours();
    const day = now.getDay();

    if (this.schedule.days && !this.schedule.days.includes(day)) {return false;}
    if (this.schedule.hours && !this.schedule.hours.includes(hour)) {return false;}

    return true;
  }

  /**
   * Mark as triggered
   */
  markTriggered() {
    this.lastTriggered = new Date().toISOString();
    this.triggerCount++;
  }
}

/**
 * Automated Alerts Manager
 */
class AutomatedAlertsManager {
  constructor() {
    this.alerts = new Map();
    this.rules = new Map();
    this.initialized = false;
    this.initializing = null;
  }

  /**
   * Initialize automated alerts manager
   */
  async init() {
    if (this.initialized) return this;
    if (this.initializing) return this.initializing;
    this.initializing = (async () => {
      await this.loadAlerts();
      await this.loadRules();
      await this.initializeDefaultRules();
      this.startScheduledAlerts();
      this.initialized = true;
      return this;
    })();
    try {
      return await this.initializing;
    } finally {
      this.initializing = null;
    }
  }

  /**
   * Load alerts from storage
   */
  async loadAlerts() {
    try {
      const alerts = await gAll('automated_alerts');
      alerts.forEach(a => {
        this.alerts.set(a.id, new AutomatedAlert(a));
      });
    } catch (err) {
      console.error('Failed to load automated alerts:', err);
    }
  }

  /**
   * Load rules from storage
   */
  async loadRules() {
    try {
      const rules = await gAll('alert_rules');
      rules.forEach(r => {
        this.rules.set(r.id, new AlertRule(r));
      });
    } catch (err) {
      console.error('Failed to load alert rules:', err);
    }
  }

  /**
   * Initialize default alert rules
   */
  async initializeDefaultRules() {
    const defaultRules = [
      {
        name: 'Low Stock Alert',
        description: 'Alert when material stock falls below minimum',
        type: 'inventory',
        category: 'stock',
        condition: 'stock_low',
        severity: 'high',
        enabled: true,
        notificationChannels: ['in-app', 'email'],
        cooldownPeriod: 3600
      },
      {
        name: 'Stock Out Alert',
        description: 'Alert when material stock reaches zero',
        type: 'inventory',
        category: 'stock',
        condition: 'stock_out',
        severity: 'critical',
        enabled: true,
        notificationChannels: ['in-app', 'email', 'push'],
        cooldownPeriod: 1800
      },
      {
        name: 'Device Offline Alert',
        description: 'Alert when IoT device goes offline',
        type: 'system',
        category: 'device',
        condition: 'device_offline',
        severity: 'high',
        enabled: true,
        notificationChannels: ['in-app', 'email'],
        cooldownPeriod: 600
      },
      {
        name: 'Low Battery Alert',
        description: 'Alert when device battery is low',
        type: 'system',
        category: 'device',
        condition: 'battery_low',
        parameters: { threshold: 20 },
        severity: 'medium',
        enabled: true,
        notificationChannels: ['in-app'],
        cooldownPeriod: 3600
      },
      {
        name: 'Anomaly Detected Alert',
        description: 'Alert when anomaly is detected',
        type: 'security',
        category: 'anomaly',
        condition: 'anomaly_detected',
        severity: 'high',
        enabled: true,
        notificationChannels: ['in-app', 'email'],
        cooldownPeriod: 300
      },
      {
        name: 'Daily Summary Alert',
        description: 'Daily summary of inventory status',
        type: 'system',
        category: 'summary',
        condition: 'schedule',
        schedule: { days: [1, 2, 3, 4, 5], hours: [9] },
        severity: 'low',
        enabled: false,
        notificationChannels: ['in-app', 'email'],
        cooldownPeriod: 86400
      }
    ];

    for (const rule of defaultRules) {
      if (!this.rules.has(rule.name)) {
        await this.createRule(rule);
      }
    }
  }

  /**
   * Start scheduled alerts
   */
  startScheduledAlerts() {
    setInterval(() => {
      this.checkScheduledRules();
    }, 60000); // Check every minute
  }

  /**
   * Check scheduled rules
   */
  async checkScheduledRules() {
    for (const rule of this.rules.values()) {
      if (rule.condition === 'schedule' && rule.shouldTrigger({})) {
        await this.triggerAlert(rule, {});
        rule.markTriggered();
        await this.saveRule(rule);
      }
    }
  }

  /**
   * Save alert to storage
   * @param {AutomatedAlert} alert - Alert to save
   */
  async saveAlert(alert) {
    try {
      await dPut('automated_alerts', alert);
    } catch (err) {
      console.error('Failed to save automated alert:', err);
    }
  }

  /**
   * Save rule to storage
   * @param {AlertRule} rule - Rule to save
   */
  async saveRule(rule) {
    try {
      await dPut('alert_rules', rule);
    } catch (err) {
      console.error('Failed to save alert rule:', err);
    }
  }

  /**
   * Create rule
   * @param {object} config - Rule configuration
   * @returns {AlertRule} - Created rule
   */
  async createRule(config) {
    const rule = new AlertRule(config);
    this.rules.set(rule.id, rule);
    await this.saveRule(rule);
    return rule;
  }

  /**
   * Update rule
   * @param {string} id - Rule ID
   * @param {object} updates - Updates to apply
   * @returns {AlertRule} - Updated rule
   */
  async updateRule(id, updates) {
    const rule = this.rules.get(id);
    if (rule) {
      Object.assign(rule, updates);
      await this.saveRule(rule);
    }
    return rule;
  }

  /**
   * Delete rule
   * @param {string} id - Rule ID
   */
  async deleteRule(id) {
    this.rules.delete(id);
    await dDel('alert_rules', id);
  }

  /**
   * Trigger alert from rule
   * @param {AlertRule} rule - Rule that triggered
   * @param {object} context - Context data
   */
  async triggerAlert(rule, context) {
    const alert = new AutomatedAlert({
      type: rule.type,
      category: rule.category,
      eventType: rule.condition,
      source: 'rule',
      sourceId: rule.id,
      severity: rule.severity,
      title: rule.name,
      message: this.generateAlertMessage(rule, context),
      data: context,
      notificationChannels: rule.notificationChannels,
      recipients: rule.recipients
    });

    this.alerts.set(alert.id, alert);
    await this.saveAlert(alert);

    // Send notifications
    await this.sendNotifications(alert);

    // Log activity
    if (typeof window !== 'undefined' && window.ActivityTracking) {
      await window.ActivityTracking.logActivity('automated_alert_triggered', 'alert', alert.id, {
        type: alert.type,
        severity: alert.severity,
        ruleId: rule.id
      });
    }

    return alert;
  }

  /**
   * Generate alert message
   * @param {AlertRule} rule - Rule
   * @param {object} context - Context data
   * @returns {string} - Alert message
   */
  generateAlertMessage(rule, context) {
    const { description } = rule;
    
    if (rule.condition === 'stock_low') {
      return `${description}. Current stock: ${context.currentStock}, Minimum: ${context.minStock}`;
    }
    if (rule.condition === 'stock_out') {
      return `${description}. Material: ${context.materialName || 'Unknown'}`;
    }
    if (rule.condition === 'device_offline') {
      return `${description}. Device: ${context.deviceName || 'Unknown'}`;
    }
    if (rule.condition === 'battery_low') {
      return `${description}. Battery: ${context.batteryLevel}%`;
    }
    if (rule.condition === 'anomaly_detected') {
      return `${description}. Type: ${context.anomalyType || 'Unknown'}`;
    }

    return description;
  }

  /**
   * Send notifications for alert
   * @param {AutomatedAlert} alert - Alert
   */
  async sendNotifications(alert) {
    for (const channel of alert.notificationChannels) {
      const eligibleRecipients = resolveAlertRecipients(alert, channel);
      const explicitRecipients = Array.isArray(alert.recipients) && alert.recipients.length > 0;
      if (explicitRecipients && eligibleRecipients.length === 0) continue;
      const deliveryAlert = { ...alert, recipients: eligibleRecipients };
      switch (channel) {
        case 'in-app':
          if (explicitRecipients && typeof window !== 'undefined' && window.notificationService?.createNotification) {
            for (const recipient of eligibleRecipients) {
              const userId = alertRecipientId(recipient);
              if (!userId) continue;
              await window.notificationService.createNotification({
                type: alert.severity === 'critical' ? 'critical' : alert.severity === 'high' ? 'warning' : 'info',
                category: alert.category || alert.type, title: alert.title, message: alert.message,
                data: alert.data, userId, isGlobal: false, priority: alert.severity, read: false
              });
            }
          }
          break;
        case 'email':
          await this.sendEmailNotification(deliveryAlert);
          break;
        case 'push':
          await this.sendPushNotification(deliveryAlert);
          break;
        case 'sms':
          await this.sendSMSNotification(deliveryAlert);
          break;
        case 'webhook':
          await this.sendWebhookNotification(deliveryAlert);
          break;
      }
    }

    alert.notificationSent = true;
    await this.saveAlert(alert);
  }

  /**
   * Send email notification
   * @param {AutomatedAlert} alert - Alert
   */
  async sendEmailNotification(alert) {
    if (typeof window !== 'undefined' && window.EmailService?.sendNotificationEmail) {
      return window.EmailService.sendNotificationEmail(alert);
    }
    return { sent: false, reason: 'Email service is not configured' };
  }

  /**
   * Send push notification
   * @param {AutomatedAlert} alert - Alert
   */
  async sendPushNotification(alert) {
    if (typeof window !== 'undefined' && window.PushNotifications?.send) {
      return window.PushNotifications.send(alert);
    }
    if (typeof window !== 'undefined' && window.PushNotificationManager?.send) {
      return window.PushNotificationManager.send(alert);
    }
    return { sent: false, reason: 'Push service is not configured' };
  }

  /**
   * Send SMS notification
   * @param {AutomatedAlert} alert - Alert
   */
  async sendSMSNotification(alert) {
    if (typeof window !== 'undefined' && window.SMSService?.sendNotificationSMS) {
      return window.SMSService.sendNotificationSMS(alert);
    }
    return { sent: false, reason: 'SMS service is not configured' };
  }

  /**
   * Send webhook notification
   * @param {AutomatedAlert} alert - Alert
   */
  async sendWebhookNotification(alert) {
    const url = alert?.metadata?.webhookUrl || alert?.data?.webhookUrl;
    if (!url || typeof fetch !== 'function') {
      return { sent: false, reason: 'Webhook URL is not configured' };
    }
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(alert)
    });
    if (!response.ok) throw new Error(`Webhook failed: HTTP ${response.status}`);
    return { sent: true, status: response.status };
  }

  /**
   * Check rules against context
   * @param {object} context - Context data
   * @returns {Promise<Array>} - Triggered alerts
   */
  async checkRules(context) {
    const triggeredAlerts = [];

    for (const rule of this.rules.values()) {
      if (rule.shouldTrigger(context)) {
        const alert = await this.triggerAlert(rule, context);
        rule.markTriggered();
        await this.saveRule(rule);
        triggeredAlerts.push(alert);
      }
    }

    return triggeredAlerts;
  }

  /**
   * Acknowledge alert
   * @param {string} id - Alert ID
   * @param {string} userId - User ID
   */
  async acknowledgeAlert(id, userId) {
    const alert = this.alerts.get(id);
    if (alert) {
      alert.acknowledge(userId);
      await this.saveAlert(alert);
    }
  }

  /**
   * Resolve alert
   * @param {string} id - Alert ID
   * @param {string} userId - User ID
   * @param {string} resolution - Resolution
   */
  async resolveAlert(id, userId, resolution = '') {
    const alert = this.alerts.get(id);
    if (alert) {
      alert.resolve(userId, resolution);
      await this.saveAlert(alert);
    }
  }

  /**
   * Get alert
   * @param {string} id - Alert ID
   * @returns {AutomatedAlert} - Alert
   */
  getAlert(id) {
    return this.alerts.get(id);
  }

  /**
   * Get all alerts
   * @returns {Array} - Array of alerts
   */
  getAllAlerts() {
    return Array.from(this.alerts.values());
  }

  /**
   * Get active alerts
   * @returns {Array} - Active alerts
   */
  getActiveAlerts() {
    return this.getAllAlerts().filter(a => a.status === 'active' && !a.isExpired());
  }

  /**
   * Get alerts by type
   * @param {string} type - Alert type
   * @returns {Array} - Alerts
   */
  getAlertsByType(type) {
    return this.getAllAlerts().filter(a => a.type === type);
  }

  /**
   * Get alerts by severity
   * @param {string} severity - Severity
   * @returns {Array} - Alerts
   */
  getAlertsBySeverity(severity) {
    return this.getAllAlerts().filter(a => a.severity === severity);
  }

  /**
   * Get critical alerts
   * @returns {Array} - Critical alerts
   */
  getCriticalAlerts() {
    return this.getAlertsBySeverity('critical').filter(a => a.status === 'active');
  }

  /**
   * Get rule
   * @param {string} id - Rule ID
   * @returns {AlertRule} - Rule
   */
  getRule(id) {
    return this.rules.get(id);
  }

  /**
   * Get all rules
   * @returns {Array} - Array of rules
   */
  getAllRules() {
    return Array.from(this.rules.values());
  }

  /**
   * Get enabled rules
   * @returns {Array} - Enabled rules
   */
  getEnabledRules() {
    return this.getAllRules().filter(r => r.enabled);
  }

  /**
   * Delete alert
   * @param {string} id - Alert ID
   */
  async deleteAlert(id) {
    this.alerts.delete(id);
    await dDel('automated_alerts', id);
  }

  /**
   * Cleanup old alerts
   * @param {number} daysToKeep - Days to keep
   */
  async cleanupOldAlerts(daysToKeep = 30) {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

    let deletedCount = 0;

    for (const [id, alert] of this.alerts) {
      if (alert.status === 'resolved' && new Date(alert.resolvedAt) < cutoffDate) {
        this.alerts.delete(id);
        await dDel('automated_alerts', id);
        deletedCount++;
      }
    }

    return deletedCount;
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const alerts = this.getAllAlerts();
    const rules = this.getAllRules();

    return {
      totalAlerts: alerts.length,
      activeAlerts: alerts.filter(a => a.status === 'active').length,
      byType: this.getTypeCounts(alerts),
      bySeverity: this.getSeverityCounts(alerts),
      totalRules: rules.length,
      enabledRules: rules.filter(r => r.enabled).length,
      byCondition: this.getConditionCounts(rules),
      totalTriggers: rules.reduce((sum, r) => sum + r.triggerCount, 0)
    };
  }

  /**
   * Get type counts
   * @param {Array} alerts - Alerts
   * @returns {object} - Type counts
   */
  getTypeCounts(alerts) {
    const counts = {};
    alerts.forEach(a => {
      counts[a.type] = (counts[a.type] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get severity counts
   * @param {Array} alerts - Alerts
   * @returns {object} - Severity counts
   */
  getSeverityCounts(alerts) {
    const counts = {};
    alerts.forEach(a => {
      counts[a.severity] = (counts[a.severity] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get condition counts
   * @param {Array} rules - Rules
   * @returns {object} - Condition counts
   */
  getConditionCounts(rules) {
    const counts = {};
    rules.forEach(r => {
      counts[r.condition] = (counts[r.condition] || 0) + 1;
    });
    return counts;
  }
}

function alertRecipientId(recipient) {
  if (recipient && typeof recipient === 'object') return String(recipient.userId || recipient.id || recipient.username || '');
  return String(recipient || '');
}

// Preferences are scoped by recipient, event type and delivery channel. No
// matching preference preserves the pre-existing alert-rule behavior.
function alertRecipientAllowed(recipient, channel, eventTypes, preferencesManager) {
  const userId=alertRecipientId(recipient);
  if (!userId || !preferencesManager?.getPreferencesForUser) return true;
  const channels = channel === 'in-app' ? ['in-app', 'in_app'] : [channel];
  const events = new Set((eventTypes || []).filter(Boolean).map(String));
  const matching = key => preferencesManager.getPreferencesForUser(String(key)).filter(pref =>
    channels.includes(pref.channel) && (events.has(String(pref.eventType || '')) || pref.eventType === '*' || pref.eventType === 'all')
  );
  // Explicit user preferences take precedence; role preferences are the fallback.
  const userMatches=matching(userId);
  const role=recipient && typeof recipient==='object' ? String(recipient.role||'') : '';
  const roleMatches=role?matching(`role:${role}`):[];
  const matches=userMatches.length?userMatches:roleMatches;
  if (!matches.length) return true;
  const specific = matches.find(pref => events.has(String(pref.eventType || ''))) || matches[0];
  return specific.enabled !== false && (typeof specific.shouldNotifyNow !== 'function' || specific.shouldNotifyNow());
}
function resolveAlertRecipients(alert, channel, preferencesManager = (typeof window !== 'undefined' ? window.NotificationPreferences?.manager : null)) {
  const recipients = Array.isArray(alert?.recipients) ? alert.recipients : [];
  const eventTypes = [alert?.eventType, alert?.category, alert?.type];
  return recipients.filter(recipient => alertRecipientAllowed(recipient, channel, eventTypes, preferencesManager));
}
/**
 * Global automated alerts manager instance
 */
const automatedAlertsManager = new AutomatedAlertsManager();

/**
 * Initialize automated alerts
 */
async function initAutomatedAlerts() {
  await automatedAlertsManager.init();
  return automatedAlertsManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.AutomatedAlerts = {
    manager: automatedAlertsManager,
    init: initAutomatedAlerts,
    createRule: (config) => automatedAlertsManager.createRule(config),
    updateRule: (id, updates) => automatedAlertsManager.updateRule(id, updates),
    deleteRule: (id) => automatedAlertsManager.deleteRule(id),
    triggerAlert: (rule, context) => automatedAlertsManager.triggerAlert(rule, context),
    checkRules: (context) => automatedAlertsManager.checkRules(context),
    acknowledgeAlert: (id, userId) => automatedAlertsManager.acknowledgeAlert(id, userId),
    resolveAlert: (id, userId, resolution) => automatedAlertsManager.resolveAlert(id, userId, resolution),
    getAlert: (id) => automatedAlertsManager.getAlert(id),
    getAllAlerts: () => automatedAlertsManager.getAllAlerts(),
    getActiveAlerts: () => automatedAlertsManager.getActiveAlerts(),
    getAlertsByType: (type) => automatedAlertsManager.getAlertsByType(type),
    getAlertsBySeverity: (severity) => automatedAlertsManager.getAlertsBySeverity(severity),
    getCriticalAlerts: () => automatedAlertsManager.getCriticalAlerts(),
    getRule: (id) => automatedAlertsManager.getRule(id),
    getAllRules: () => automatedAlertsManager.getAllRules(),
    getEnabledRules: () => automatedAlertsManager.getEnabledRules(),
    deleteAlert: (id) => automatedAlertsManager.deleteAlert(id),
    cleanupOldAlerts: (daysToKeep) => automatedAlertsManager.cleanupOldAlerts(daysToKeep),
    getStats: () => automatedAlertsManager.getStatistics()
  };
}
