// Returns Management Module - Product returns and RMA management

/**
 * Return Request class
 */
class ReturnRequest {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.rmaNumber = config.rmaNumber || this.generateRMANumber();
    this.orderId = config.orderId || '';
    this.orderNumber = config.orderNumber || '';
    this.customerId = config.customerId || '';
    this.customerName = config.customerName || '';
    this.type = config.type || 'return'; // return, exchange, refund
    this.reason = config.reason || '';
    this.reasonCode = config.reasonCode || '';
    this.items = config.items || [];
    this.status = config.status || 'pending'; // pending, approved, rejected, received, processed, completed, cancelled
    this.priority = config.priority || 'normal'; // low, normal, high, urgent
    this.approvedBy = config.approvedBy || null;
    this.approvedAt = config.approvedAt || null;
    this.rejectedBy = config.rejectedBy || null;
    this.rejectedAt = config.rejectedAt || null;
    this.rejectionReason = config.rejectionReason || '';
    this.receivedAt = config.receivedAt || null;
    this.processedAt = config.processedAt || null;
    this.completedAt = config.completedAt || null;
    this.refundAmount = config.refundAmount || 0;
    this.refundMethod = config.refundMethod || 'original'; // original, store_credit, check
    this.refundProcessed = config.refundProcessed || false;
    this.notes = config.notes || '';
    this.internalNotes = config.internalNotes || '';
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `return-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  generateRMANumber() {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `RMA-${year}${month}-${random}`;
  }

  /**
   * Get total refund amount
   * @returns {number} - Total refund amount
   */
  getTotalRefundAmount() {
    return this.items.reduce((sum, item) => sum + (item.refundAmount || 0), 0);
  }

  /**
   * Get total items
   * @returns {number} - Total items
   */
  getTotalItems() {
    return this.items.reduce((sum, item) => sum + item.quantity, 0);
  }
}

/**
 * Return Item class
 */
class ReturnItem {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.returnId = config.returnId || '';
    this.itemId = config.itemId || null;
    this.barcode = config.barcode || '';
    this.itemName = config.itemName || '';
    this.quantity = config.quantity || 0;
    this.unitPrice = config.unitPrice || 0;
    this.refundAmount = config.refundAmount || 0;
    this.condition = config.condition || 'new'; // new, used, damaged, defective
    this.reason = config.reason || '';
    this.receivedQuantity = config.receivedQuantity || 0;
    this.action = config.action || 'refund'; // refund, exchange, repair, discard
    this.notes = config.notes || '';
  }

  generateId() {
    return `return-item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Is fully received
   * @returns {boolean} - Is fully received
   */
  isFullyReceived() {
    return this.receivedQuantity >= this.quantity;
  }
}

/**
 * Return Inspection class
 */
class ReturnInspection {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.returnId = config.returnId || '';
    this.itemId = config.itemId || null;
    this.barcode = config.barcode || '';
    this.inspectedBy = config.inspectedBy || '';
    this.inspectedAt = config.inspectedAt || new Date().toISOString();
    this.condition = config.condition || '';
    this.defectType = config.defectType || '';
    this.isResellable = config.isResellable || false;
    this.action = config.action || ''; // refund, exchange, repair, discard
    this.notes = config.notes || '';
    this.photos = config.photos || [];
  }

  generateId() {
    return `inspection-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Returns Management Manager
 */
class ReturnsManagementManager {
  constructor() {
    this.returnRequests = new Map();
    this.returnItems = new Map();
    this.inspections = new Map();
    this.init();
  }

  /**
   * Initialize returns management manager
   */
  async init() {
    await this.loadReturnRequests();
    await this.loadReturnItems();
    await this.loadInspections();
  }

  /**
   * Load return requests from storage
   */
  async loadReturnRequests() {
    try {
      const requests = await gAll('return_requests');
      requests.forEach(r => {
        this.returnRequests.set(r.id, new ReturnRequest(r));
      });
    } catch (err) {
      console.error('Failed to load return requests:', err);
    }
  }

  /**
   * Load return items from storage
   */
  async loadReturnItems() {
    try {
      const items = await gAll('return_items');
      items.forEach(i => {
        this.returnItems.set(i.id, new ReturnItem(i));
      });
    } catch (err) {
      console.error('Failed to load return items:', err);
    }
  }

  /**
   * Load inspections from storage
   */
  async loadInspections() {
    try {
      const inspections = await gAll('return_inspections');
      inspections.forEach(i => {
        this.inspections.set(i.id, new ReturnInspection(i));
      });
    } catch (err) {
      console.error('Failed to load return inspections:', err);
    }
  }

  /**
   * Create return request
   * @param {object} config - Return request configuration
   * @returns {ReturnRequest} - Created return request
   */
  async createReturnRequest(config) {
    const returnRequest = new ReturnRequest(config);
    returnRequest.refundAmount = returnRequest.getTotalRefundAmount();
    this.returnRequests.set(returnRequest.id, returnRequest);
    await this.saveReturnRequest(returnRequest);
    return returnRequest;
  }

  /**
   * Update return request
   * @param {string} id - Return request ID
   * @param {object} updates - Updates to apply
   * @returns {ReturnRequest} - Updated return request
   */
  async updateReturnRequest(id, updates) {
    const returnRequest = this.returnRequests.get(id);
    if (returnRequest) {
      Object.assign(returnRequest, updates);
      returnRequest.refundAmount = returnRequest.getTotalRefundAmount();
      await this.saveReturnRequest(returnRequest);
    }
    return returnRequest;
  }

  /**
   * Delete return request
   * @param {string} id - Return request ID
   */
  async deleteReturnRequest(id) {
    this.returnRequests.delete(id);
    await dDel('return_requests', id);
  }

  /**
   * Save return request to storage
   * @param {ReturnRequest} returnRequest - Return request to save
   */
  async saveReturnRequest(returnRequest) {
    try {
      await dPut('return_requests', returnRequest);
    } catch (err) {
      console.error('Failed to save return request:', err);
    }
  }

  /**
   * Approve return request
   * @param {string} id - Return request ID
   * @param {string} approvedBy - User who approved
   */
  async approveReturnRequest(id, approvedBy) {
    const returnRequest = this.returnRequests.get(id);
    if (returnRequest) {
      returnRequest.status = 'approved';
      returnRequest.approvedBy = approvedBy;
      returnRequest.approvedAt = new Date().toISOString();
      await this.saveReturnRequest(returnRequest);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('return_approved', 'returns', id, {
          rmaNumber: returnRequest.rmaNumber,
          refundAmount: returnRequest.refundAmount
        });
      }
    }
  }

  /**
   * Reject return request
   * @param {string} id - Return request ID
   * @param {string} rejectedBy - User who rejected
   * @param {string} reason - Rejection reason
   */
  async rejectReturnRequest(id, rejectedBy, reason) {
    const returnRequest = this.returnRequests.get(id);
    if (returnRequest) {
      returnRequest.status = 'rejected';
      returnRequest.rejectedBy = rejectedBy;
      returnRequest.rejectedAt = new Date().toISOString();
      returnRequest.rejectionReason = reason;
      await this.saveReturnRequest(returnRequest);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('return_rejected', 'returns', id, {
          rmaNumber: returnRequest.rmaNumber,
          reason
        });
      }
    }
  }

  /**
   * Receive return
   * @param {string} id - Return request ID
   * @param {object} receivedData - Received data
   */
  async receiveReturn(id, receivedData) {
    const returnRequest = this.returnRequests.get(id);
    if (returnRequest) {
      returnRequest.status = 'received';
      returnRequest.receivedAt = new Date().toISOString();
      
      // Update received quantities
      if (receivedData.items) {
        for (const receivedItem of receivedData.items) {
          const returnItem = returnRequest.items.find(i => i.barcode === receivedItem.barcode);
          if (returnItem) {
            returnItem.receivedQuantity = receivedItem.quantity;
          }
        }
      }

      await this.saveReturnRequest(returnRequest);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('return_received', 'returns', id, {
          rmaNumber: returnRequest.rmaNumber
        });
      }
    }
  }

  /**
   * Process return
   * @param {string} id - Return request ID
   * @param {string} processedBy - User who processed
   */
  async processReturn(id, processedBy) {
    const returnRequest = this.returnRequests.get(id);
    if (returnRequest) {
      returnRequest.status = 'processed';
      returnRequest.processedAt = new Date().toISOString();
      await this.saveReturnRequest(returnRequest);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('return_processed', 'returns', id, {
          rmaNumber: returnRequest.rmaNumber
        });
      }
    }
  }

  /**
   * Complete return
   * @param {string} id - Return request ID
   */
  async completeReturn(id) {
    const returnRequest = this.returnRequests.get(id);
    if (returnRequest) {
      returnRequest.status = 'completed';
      returnRequest.completedAt = new Date().toISOString();
      returnRequest.refundProcessed = true;
      await this.saveReturnRequest(returnRequest);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('return_completed', 'returns', id, {
          rmaNumber: returnRequest.rmaNumber,
          refundAmount: returnRequest.refundAmount
        });
      }
    }
  }

  /**
   * Cancel return request
   * @param {string} id - Return request ID
   * @param {string} reason - Cancellation reason
   */
  async cancelReturnRequest(id, reason) {
    const returnRequest = this.returnRequests.get(id);
    if (returnRequest) {
      returnRequest.status = 'cancelled';
      returnRequest.internalNotes = reason;
      await this.saveReturnRequest(returnRequest);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('return_cancelled', 'returns', id, {
          rmaNumber: returnRequest.rmaNumber,
          reason
        });
      }
    }
  }

  /**
   * Create inspection
   * @param {object} config - Inspection configuration
   * @returns {ReturnInspection} - Created inspection
   */
  async createInspection(config) {
    const inspection = new ReturnInspection(config);
    this.inspections.set(inspection.id, inspection);
    await this.saveInspection(inspection);
    return inspection;
  }

  /**
   * Save inspection to storage
   * @param {ReturnInspection} inspection - Inspection to save
   */
  async saveInspection(inspection) {
    try {
      await dPut('return_inspections', inspection);
    } catch (err) {
      console.error('Failed to save return inspection:', err);
    }
  }

  /**
   * Get return request
   * @param {string} id - Return request ID
   * @returns {ReturnRequest} - Return request
   */
  getReturnRequest(id) {
    return this.returnRequests.get(id);
  }

  /**
   * Get return request by RMA number
   * @param {string} rmaNumber - RMA number
   * @returns {ReturnRequest} - Return request
   */
  getReturnRequestByRMA(rmaNumber) {
    return Array.from(this.returnRequests.values()).find(r => r.rmaNumber === rmaNumber);
  }

  /**
   * Get all return requests
   * @returns {Array} - Array of return requests
   */
  getAllReturnRequests() {
    return Array.from(this.returnRequests.values());
  }

  /**
   * Get return requests by status
   * @param {string} status - Status
   * @returns {Array} - Return requests
   */
  getReturnRequestsByStatus(status) {
    return this.getAllReturnRequests().filter(r => r.status === status);
  }

  /**
   * Get return requests by customer
   * @param {string} customerId - Customer ID
   * @returns {Array} - Return requests
   */
  getReturnRequestsByCustomer(customerId) {
    return this.getAllReturnRequests().filter(r => r.customerId === customerId);
  }

  /**
   * Get pending returns
   * @returns {Array} - Pending returns
   */
  getPendingReturns() {
    return this.getReturnRequestsByStatus('pending');
  }

  /**
   * Get approved returns
   * @returns {Array} - Approved returns
   */
  getApprovedReturns() {
    return this.getReturnRequestsByStatus('approved');
  }

  /**
   * Get inspection
   * @param {string} id - Inspection ID
   * @returns {ReturnInspection} - Inspection
   */
  getInspection(id) {
    return this.inspections.get(id);
  }

  /**
   * Get inspections by return
   * @param {string} returnId - Return request ID
   * @returns {Array} - Inspections
   */
  getInspectionsByReturn(returnId) {
    return Array.from(this.inspections.values()).filter(i => i.returnId === returnId);
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const requests = this.getAllReturnRequests();
    const inspections = Array.from(this.inspections.values());

    return {
      totalRequests: requests.length,
      byStatus: this.getStatusCounts(requests),
      byType: this.getTypeCounts(requests),
      byReason: this.getReasonCounts(requests),
      totalRefundAmount: requests.reduce((sum, r) => sum + r.refundAmount, 0),
      avgRefundAmount: requests.length > 0 
        ? requests.reduce((sum, r) => sum + r.refundAmount, 0) / requests.length 
        : 0,
      pending: this.getPendingReturns().length,
      approved: this.getApprovedReturns().length,
      totalInspections: inspections.length,
      resellableRate: inspections.length > 0 
        ? inspections.filter(i => i.isResellable).length / inspections.length 
        : 0
    };
  }

  /**
   * Get status counts
   * @param {Array} requests - Return requests
   * @returns {object} - Status counts
   */
  getStatusCounts(requests) {
    const counts = {};
    requests.forEach(r => {
      counts[r.status] = (counts[r.status] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get type counts
   * @param {Array} requests - Return requests
   * @returns {object} - Type counts
   */
  getTypeCounts(requests) {
    const counts = {};
    requests.forEach(r => {
      counts[r.type] = (counts[r.type] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get reason counts
   * @param {Array} requests - Return requests
   * @returns {object} - Reason counts
   */
  getReasonCounts(requests) {
    const counts = {};
    requests.forEach(r => {
      if (r.reasonCode) {
        counts[r.reasonCode] = (counts[r.reasonCode] || 0) + 1;
      }
    });
    return counts;
  }
}

/**
 * Global returns management manager instance
 */
const returnsManagementManager = new ReturnsManagementManager();

/**
 * Initialize returns management
 */
async function initReturnsManagement() {
  await returnsManagementManager.init();
  return returnsManagementManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.ReturnsManagement = {
    manager: initReturnsManagement,
    init: initReturnsManagement,
    createReturnRequest: (config) => returnsManagementManager.createReturnRequest(config),
    updateReturnRequest: (id, updates) => returnsManagementManager.updateReturnRequest(id, updates),
    deleteReturnRequest: (id) => returnsManagementManager.deleteReturnRequest(id),
    getReturnRequest: (id) => returnsManagementManager.getReturnRequest(id),
    getReturnRequestByRMA: (rmaNumber) => returnsManagementManager.getReturnRequestByRMA(rmaNumber),
    getAllReturnRequests: () => returnsManagementManager.getAllReturnRequests(),
    getReturnRequestsByStatus: (status) => returnsManagementManager.getReturnRequestsByStatus(status),
    getReturnRequestsByCustomer: (customerId) => returnsManagementManager.getReturnRequestsByCustomer(customerId),
    getPendingReturns: () => returnsManagementManager.getPendingReturns(),
    getApprovedReturns: () => returnsManagementManager.getApprovedReturns(),
    approve: (id, user) => returnsManagementManager.approveReturnRequest(id, user),
    reject: (id, user, reason) => returnsManagementManager.rejectReturnRequest(id, user, reason),
    receive: (id, data) => returnsManagementManager.receiveReturn(id, data),
    process: (id, user) => returnsManagementManager.processReturn(id, user),
    complete: (id) => returnsManagementManager.completeReturn(id),
    cancel: (id, reason) => returnsManagementManager.cancelReturnRequest(id, reason),
    createInspection: (config) => returnsManagementManager.createInspection(config),
    getInspection: (id) => returnsManagementManager.getInspection(id),
    getInspectionsByReturn: (returnId) => returnsManagementManager.getInspectionsByReturn(returnId),
    getStats: () => returnsManagementManager.getStatistics()
  };
}
