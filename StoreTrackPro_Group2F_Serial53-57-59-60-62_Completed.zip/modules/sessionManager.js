// Session Manager Module - User session management and security

/**
 * Session class
 */
class Session {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.userId = config.userId || null;
    this.username = config.username || null;
    this.startTime = config.startTime || new Date().toISOString();
    this.lastActivity = config.lastActivity || new Date().toISOString();
    this.ipAddress = config.ipAddress || null;
    this.userAgent = config.userAgent || null;
    this.active = config.active !== false;
    this.timeoutMinutes = config.timeoutMinutes || 30;
  }

  generateId() {
    return `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Check if session is expired
   * @returns {boolean} - Is expired
   */
  isExpired() {
    const lastActivity = new Date(this.lastActivity);
    const now = new Date();
    const diffMinutes = (now - lastActivity) / (1000 * 60);
    return diffMinutes > this.timeoutMinutes;
  }

  /**
   * Update last activity
   */
  updateActivity() {
    this.lastActivity = new Date().toISOString();
  }

  /**
   * Get session duration in minutes
   * @returns {number} - Duration in minutes
   */
  getDuration() {
    const start = new Date(this.startTime);
    const now = new Date();
    return (now - start) / (1000 * 60);
  }

  /**
   * Invalidate session
   */
  invalidate() {
    this.active = false;
  }
}

/**
 * Session Manager
 */
class SessionManager {
  constructor() {
    this.currentSession = null;
    this.activityCheckInterval = null;
    this.warningTimeout = null;
    this.warningShown = false;
    this.init();
  }

  /**
   * Initialize session manager
   */
  async init() {
    this.setupActivityTracking();
    this.setupVisibilityListener();
  }

  /**
   * Setup activity tracking
   */
  setupActivityTracking() {
    // Track user activity
    const events = ['mousedown', 'keydown', 'scroll', 'touchstart'];
    events.forEach(event => {
      document.addEventListener(event, () => this.onUserActivity());
    });
  }

  /**
   * Setup visibility listener
   */
  setupVisibilityListener() {
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        this.onUserActivity();
      }
    });
  }

  /**
   * Handle user activity
   */
  onUserActivity() {
    if (this.currentSession && this.currentSession.active) {
      this.currentSession.updateActivity();
      this.saveCurrentSession();
      
      // Reset warning if activity detected
      if (this.warningShown) {
        this.dismissWarning();
      }
    }
  }

  /**
   * Create session
   * @param {object} user - User object
   * @returns {Session} - Created session
   */
  async createSession(user) {
    const session = new Session({
      userId: user.id,
      username: user.username,
      ipAddress: await this.getIPAddress(),
      userAgent: navigator.userAgent
    });

    this.currentSession = session;
    await this.saveSession(session);
    this.startActivityCheck();
    
    // Log session creation
    if (typeof window !== 'undefined' && window.ActivityTracking) {
      await window.ActivityTracking.logLogin(user.username, true);
    }

    return session;
  }

  /**
   * Get IP address (placeholder)
   * @returns {Promise<string>} - IP address
   */
  async getIPAddress() {
    // This would get the actual IP address
    return null;
  }

  /**
   * Save session to storage
   * @param {Session} session - Session to save
   */
  async saveSession(session) {
    try {
      await dPut('sessions', session);
    } catch (err) {
      console.error('Failed to save session:', err);
    }
  }

  /**
   * Save current session
   */
  async saveCurrentSession() {
    if (this.currentSession) {
      await this.saveSession(this.currentSession);
    }
  }

  /**
   * Start activity check interval
   */
  startActivityCheck() {
    if (this.activityCheckInterval) {
      clearInterval(this.activityCheckInterval);
    }

    this.activityCheckInterval = setInterval(() => {
      this.checkSession();
    }, 60000); // Check every minute
  }

  /**
   * Stop activity check
   */
  stopActivityCheck() {
    if (this.activityCheckInterval) {
      clearInterval(this.activityCheckInterval);
      this.activityCheckInterval = null;
    }
  }

  /**
   * Check session status
   */
  async checkSession() {
    if (!this.currentSession || !this.currentSession.active) {
      return;
    }

    // Check if expired
    if (this.currentSession.isExpired()) {
      await this.endSession('timeout');
      return;
    }

    // Show warning before timeout
    const timeUntilTimeout = this.getTimeUntilTimeout();
    if (timeUntilTimeout <= 5 && timeUntilTimeout > 0 && !this.warningShown) {
      this.showTimeoutWarning(timeUntilTimeout);
    }
  }

  /**
   * Get time until timeout in minutes
   * @returns {number} - Minutes until timeout
   */
  getTimeUntilTimeout() {
    if (!this.currentSession) {return 0;}

    const lastActivity = new Date(this.currentSession.lastActivity);
    const now = new Date();
    const elapsedMinutes = (now - lastActivity) / (1000 * 60);
    const remainingMinutes = this.currentSession.timeoutMinutes - elapsedMinutes;
    
    return Math.max(0, remainingMinutes);
  }

  /**
   * Show timeout warning
   * @param {number} minutes - Minutes until timeout
   */
  showTimeoutWarning(minutes) {
    this.warningShown = true;
    
    const message = `Your session will expire in ${Math.ceil(minutes)} minute${minutes !== 1 ? 's' : ''} due to inactivity. Click to extend.`;
    
    // Create warning element
    const warning = document.createElement('div');
    warning.className = 'session-warning';
    warning.innerHTML = `
      <div class="session-warning-content">
        <span class="warning-icon">⚠️</span>
        <span class="warning-message">${message}</span>
        <button class="btn btn-sm btn-primary" data-onclick="SessionManager.extendSession()">Extend Session</button>
        <button class="btn btn-sm" data-onclick="SessionManager.dismissWarning()">Dismiss</button>
      </div>
    `;
    
    document.body.appendChild(warning);
    
    // Auto-dismiss after timeout
    this.warningTimeout = setTimeout(() => {
      if (this.warningShown) {
        this.endSession('timeout');
      }
    }, minutes * 60 * 1000);
  }

  /**
   * Dismiss warning
   */
  dismissWarning() {
    this.warningShown = false;
    const warning = document.querySelector('.session-warning');
    if (warning) {
      warning.remove();
    }
    if (this.warningTimeout) {
      clearTimeout(this.warningTimeout);
      this.warningTimeout = null;
    }
  }

  /**
   * Extend session
   */
  async extendSession() {
    if (this.currentSession) {
      this.currentSession.updateActivity();
      await this.saveCurrentSession();
      this.dismissWarning();
    }
  }

  /**
   * End session
   * @param {string} reason - Reason for ending session
   */
  async endSession(reason = 'logout') {
    if (this.currentSession) {
      this.currentSession.invalidate();
      await this.saveCurrentSession();
      
      // Log session end
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logLogout(this.currentSession.username);
      }
      
      this.currentSession = null;
      this.stopActivityCheck();
      this.dismissWarning();
      
      // Trigger logout
      if (reason === 'timeout') {
        alert('Your session has expired due to inactivity. Please log in again.');
        this.redirectToLogin();
      }
    }
  }

  /**
   * Redirect to login
   */
  redirectToLogin() {
    // This would redirect to login page
    window.location.reload();
  }

  /**
   * Get current session
   * @returns {Session} - Current session
   */
  getCurrentSession() {
    return this.currentSession;
  }

  /**
   * Check if user is authenticated
   * @returns {boolean} - Is authenticated
   */
  isAuthenticated() {
    return this.currentSession && this.currentSession.active && !this.currentSession.isExpired();
  }

  /**
   * Get all sessions for user
   * @param {string} userId - User ID
   * @returns {Promise<Array>} - User sessions
   */
  async getUserSessions(userId) {
    try {
      const sessions = await gAll('sessions');
      return sessions.filter(s => s.userId === userId).map(s => this.hydrateSession(s));
    } catch (err) {
      console.error('Failed to get user sessions:', err);
      return [];
    }
  }

  /**
   * Get active sessions
   * @returns {Promise<Array>} - Active sessions
   */
  async getActiveSessions() {
    try {
      const sessions = await gAll('sessions');
      return sessions.filter(s => s.active).map(s => this.hydrateSession(s)).filter(s => !s.isExpired());
    } catch (err) {
      console.error('Failed to get active sessions:', err);
      return [];
    }
  }

  /**
   * Terminate session
   * @param {string} sessionId - Session ID
   */
  async terminateSession(sessionId) {
    try {
      const session = await gOne('sessions', sessionId);
      if (session) {
        const hydrated = this.hydrateSession(session);
        hydrated.invalidate();
        await dPut('sessions', hydrated);
      }
    } catch (err) {
      console.error('Failed to terminate session:', err);
    }
  }

  /**
   * Terminate all user sessions except current
   * @param {string} userId - User ID
   */
  async terminateOtherSessions(userId) {
    try {
      const sessions = await this.getUserSessions(userId);
      for (const session of sessions) {
        if (session.id !== this.currentSession?.id) {
          await this.terminateSession(session.id);
        }
      }
    } catch (err) {
      console.error('Failed to terminate other sessions:', err);
    }
  }

  /**
   * Clear old sessions
   * @param {number} daysToKeep - Number of days to keep
   */
  async clearOldSessions(daysToKeep = 30) {
    try {
      const sessions = (await gAll('sessions')).map(s => this.hydrateSession(s));
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

      const sessionsToDelete = sessions.filter(s => new Date(s.startTime) < cutoffDate);

      for (const session of sessionsToDelete) {
        await dDel('sessions', session.id);
      }

      console.log(`Cleared ${sessionsToDelete.length} old sessions`);
    } catch (err) {
      console.error('Failed to clear old sessions:', err);
    }
  }

  /**
   * Get session statistics
   * @returns {Promise<object>} - Session statistics
   */
  async getStatistics() {
    try {
      const sessions = (await gAll('sessions')).map(s => this.hydrateSession(s));
      const activeSessions = sessions.filter(s => s.active && !s.isExpired());
      
      const stats = {
        total: sessions.length,
        active: activeSessions.length,
        inactive: sessions.length - activeSessions.length,
        averageDuration: 0,
        byUser: {}
      };

      if (sessions.length > 0) {
        const totalDuration = sessions.reduce((sum, s) => sum + s.getDuration(), 0);
        stats.averageDuration = totalDuration / sessions.length;
      }

      sessions.forEach(s => {
        if (s.username) {
          stats.byUser[s.username] = (stats.byUser[s.username] || 0) + 1;
        }
      });

      return stats;
    } catch (err) {
      console.error('Failed to get session statistics:', err);
      return {};
    }
  }

  /**
   * Set session timeout
   * @param {number} minutes - Timeout in minutes
   */
  setSessionTimeout(minutes) {
    if (this.currentSession) {
      this.currentSession.timeoutMinutes = minutes;
      this.saveCurrentSession();
    }
  }

  /** Reconstruct prototype methods omitted by IndexedDB structured cloning. */
  hydrateSession(record) {
    if (!record) return record;
    if (record instanceof Session) return record;
    return Object.assign(new Session(record), record);
  }
}

/**
 * Global session manager instance
 */
const sessionManager = new SessionManager();

/**
 * Initialize session manager
 */
async function initSessionManager() {
  await sessionManager.init();
  return sessionManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.SessionManager = {
    manager: sessionManager,
    init: initSessionManager,
    createSession: (user) => sessionManager.createSession(user),
    endSession: (reason) => sessionManager.endSession(reason),
    getCurrentSession: () => sessionManager.getCurrentSession(),
    isAuthenticated: () => sessionManager.isAuthenticated(),
    extendSession: () => sessionManager.extendSession(),
    getUserSessions: (userId) => sessionManager.getUserSessions(userId),
    getActiveSessions: () => sessionManager.getActiveSessions(),
    terminateSession: (id) => sessionManager.terminateSession(id),
    terminateOtherSessions: (userId) => sessionManager.terminateOtherSessions(userId),
    clearOldSessions: (days) => sessionManager.clearOldSessions(days),
    getStatistics: () => sessionManager.getStatistics(),
    setSessionTimeout: (minutes) => sessionManager.setSessionTimeout(minutes)
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { Session, SessionManager, sessionManager };
}
