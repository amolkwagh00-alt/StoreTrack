/**
 * Background Data Synchronization Module
 * Handles background sync operations without blocking UI
 */

class BackgroundSync {
  constructor() {
    this.syncQueue = [];
    this.isProcessing = false;
    this.syncStatus = {
      pending: 0,
      inProgress: 0,
      completed: 0,
      failed: 0
    };
    this.syncHistory = [];
    this.processorTimer = null;
    this.config = {
      maxConcurrent: 3,
      retryAttempts: 3,
      retryDelay: 5000,
      batchSize: 50
    };
    this.eventBus = null;
  }

  /**
   * Initialize background sync
   * @param {Object} eventBus - Event bus for notifications
   */
  initialize(options = {}) {
    if (options && typeof options.emit === 'function') {
      this.eventBus = options;
    } else {
      this.eventBus = options?.eventBus && typeof options.eventBus.emit === 'function' ? options.eventBus : null;
      this.setConfig({
        maxConcurrent: options?.maxConcurrent ?? options?.maxConcurrentTasks ?? this.config.maxConcurrent,
        retryAttempts: options?.retryAttempts ?? this.config.retryAttempts,
      });
    }
    this.startSyncProcessor();
    this.registerServiceWorker();
  }

  /**
   * Register service worker for background sync
   */
  registerServiceWorker() {
    if (typeof navigator === 'undefined' || window.location.protocol === 'file:') {
      return;
    }
    if ('serviceWorker' in navigator && typeof ServiceWorkerRegistration !== 'undefined' && 'sync' in ServiceWorkerRegistration.prototype) {
      navigator.serviceWorker.ready.then(registration => {
        registration.sync.register('background-sync').catch(err => {
          console.debug('Background sync registration failed:', err);
        });
      });
    }
  }

  /**
   * Add sync task to queue
   * @param {Object} task - Sync task configuration
   */
  addSyncTask(task) {
    const syncTask = {
      id: this.generateTaskId(),
      type: task.type || 'data',
      action: task.action || 'sync',
      data: task.data || {},
      priority: task.priority || 'normal',
      createdAt: Date.now(),
      attempts: 0,
      status: 'pending'
    };
    
    this.syncQueue.push(syncTask);
    this.syncStatus.pending++;
    
    // Sort by priority
    this.syncQueue.sort((a, b) => {
      const priorityOrder = { high: 0, normal: 1, low: 2 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });
    
    if (this.eventBus) {
      this.eventBus.emit('SYNC_TASK_QUEUED', syncTask);
    }
    
    return syncTask.id;
  }

  /**
   * Start sync processor
   */
  startSyncProcessor() {
    if (this.processorTimer) { return; }
    this.processorTimer = setInterval(() => {
      if (!this.isPaused && !this.isProcessing && this.syncQueue.length > 0) {
        this.processQueue();
      }
    }, 1000);
  }

  /**
   * Process sync queue
   */
  async processQueue() {
    if (this.isPaused || this.isProcessing) {return;}
    
    this.isProcessing = true;
    const tasksToProcess = this.syncQueue.splice(0, this.config.maxConcurrent);
    
    this.syncStatus.inProgress += tasksToProcess.length;
    this.syncStatus.pending -= tasksToProcess.length;
    
    const promises = tasksToProcess.map(task => this.processTask(task));
    await Promise.allSettled(promises);
    
    this.isProcessing = false;
  }

  /**
   * Process individual sync task
   * @param {Object} task - Sync task
   */
  async processTask(task) {
    task.status = 'inProgress';
    task.startedAt = Date.now();
    
    if (this.eventBus) {
      this.eventBus.emit('SYNC_TASK_STARTED', task);
    }
    
    try {
      let result;
      
      switch (task.action) {
        case 'sync':
          result = await this.syncData(task.data);
          break;
        case 'upload':
          result = await this.uploadData(task.data);
          break;
        case 'download':
          result = await this.downloadData(task.data);
          break;
        case 'validate':
          result = await this.validateData(task.data);
          break;
        default:
          throw new Error(`Unknown action: ${task.action}`);
      }
      
      task.status = 'completed';
      task.completedAt = Date.now();
      task.result = result;
      this.syncStatus.completed++;
      
      if (this.eventBus) {
        this.eventBus.emit('SYNC_TASK_COMPLETED', task);
      }
      
    } catch (error) {
      task.status = 'failed';
      task.error = error.message;
      task.failedAt = Date.now();
      task.attempts++;
      
      this.syncStatus.failed++;
      
      // Retry if attempts not exceeded
      if (task.attempts < this.config.retryAttempts) {
        task.status = 'pending';
        task.nextRetryAt = Date.now() + this.config.retryDelay;
        this.syncQueue.push(task);
        this.syncStatus.pending++;
      }
      
      if (this.eventBus) {
        this.eventBus.emit('SYNC_TASK_FAILED', task);
      }
    }
    
    this.syncStatus.inProgress--;
    this.syncHistory.push(task);
    
    // Keep history limited
    if (this.syncHistory.length > 1000) {
      this.syncHistory = this.syncHistory.slice(-1000);
    }
  }

  /**
   * Sync data with remote source
   * @param {Object} data - Data to sync
   */
  async syncData(data) {
    const { storeName, records, conflictResolution = 'server' } = data;
    
    // Batch processing for large datasets
    const batches = this.chunkArray(records, this.config.batchSize);
    const results = [];
    
    for (const batch of batches) {
      const batchResult = await this.syncBatch(storeName, batch, conflictResolution);
      results.push(...batchResult);
    }
    
    return {
      synced: results.length,
      conflicts: results.filter(r => r.conflict).length,
      results
    };
  }

  /**
   * Sync a batch of records
   * @param {string} storeName - Store name
   * @param {Array} batch - Batch of records
   * @param {string} conflictResolution - Conflict resolution strategy
   */
  async syncBatch(storeName, batch, conflictResolution) {
    throw new Error(`Remote sync adapter is not configured; refusing to report ${batch.length} ${storeName} records as synchronized`);
  }

  /**
   * Upload data to remote
   * @param {Object} data - Data to upload
   */
  async uploadData(data) {
    void data;
    throw new Error('Remote upload adapter is not configured; no data was uploaded');
  }

  /**
   * Download data from remote
   * @param {Object} data - Download parameters
   */
  async downloadData() {
    throw new Error('Remote download adapter is not configured; no data was downloaded');
  }

  /**
   * Validate data integrity
   * @param {Object} data - Data to validate
   */
  async validateData(data) {
    const records = data.records || [];

    const results = records.map(record => ({
      id: record.id,
      valid: true,
      issues: []
    }));
    
    return {
      validated: results.length,
      invalid: results.filter(r => !r.valid).length,
      results
    };
  }

  /**
   * Chunk array into batches
   * @param {Array} array - Array to chunk
   * @param {number} size - Batch size
   */
  chunkArray(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  /**
   * Simulate network delay
   */
  async simulateNetworkDelay() {
    const delay = Math.random() * 1000 + 500;
    await new Promise(resolve => setTimeout(resolve, delay));
  }

  /**
   * Generate unique task ID
   */
  generateTaskId() {
    return `sync_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get sync status
   */
  getStatus() {
    return {
      ...this.syncStatus,
      queueLength: this.syncQueue.length,
      isProcessing: this.isProcessing,
      isPaused: this.isPaused
    };
  }

  /**
   * Get sync history
   * @param {number} limit - Number of records to return
   */
  getHistory(limit = 100) {
    return this.syncHistory.slice(-limit);
  }

  /**
   * Get task by ID
   * @param {string} taskId - Task ID
   */
  getTask(taskId) {
    return this.syncHistory.find(t => t.id === taskId) || 
           this.syncQueue.find(t => t.id === taskId);
  }

  /**
   * Cancel task
   * @param {string} taskId - Task ID
   */
  cancelTask(taskId) {
    const queueIndex = this.syncQueue.findIndex(t => t.id === taskId);
    if (queueIndex !== -1) {
      this.syncQueue.splice(queueIndex, 1);
      this.syncStatus.pending--;
      return true;
    }
    return false;
  }

  /**
   * Clear completed tasks from history
   */
  clearHistory() {
    this.syncHistory = this.syncHistory.filter(t => t.status !== 'completed');
  }

  /**
   * Pause sync processing
   */
  pause() {
    this.isPaused = true;
  }

  /**
   * Resume sync processing
   */
  resume() {
    this.isPaused = false;
    // Resume must actively drain an already queued workload.
    if (!this.isProcessing && this.syncQueue.length > 0) {
      void this.processQueue().catch(error => {
        console.error('[BackgroundSync] Resume failed:', error);
      });
    }
  }

  /**
   * Set sync configuration
   * @param {Object} config - Configuration options
   */
  setConfig(config) {
    this.config = { ...this.config, ...config };
  }

  /**
   * Get sync configuration
   */
  getConfig() {
    return { ...this.config };
  }

  /**
   * Force immediate sync
   */
  async forceSync() {
    if (this.syncQueue.length === 0) {
      return { status: 'no_tasks' };
    }
    
    await this.processQueue();
    return { status: 'completed', processed: this.syncStatus.completed };
  }
}

// Create singleton instance
const backgroundSync = new BackgroundSync();

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { BackgroundSync, backgroundSync };
}
