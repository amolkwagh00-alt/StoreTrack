// Supplier Database Module - Supplier information management

/**
 * Supplier class
 */
class Supplier {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.code = config.code || '';
    this.name = config.name || '';
    this.contactPerson = config.contactPerson || '';
    this.email = config.email || '';
    this.phone = config.phone || '';
    this.address = config.address || '';
    this.city = config.city || '';
    this.state = config.state || '';
    this.country = config.country || '';
    this.postalCode = config.postalCode || '';
    this.website = config.website || '';
    this.taxId = config.taxId || '';
    this.paymentTerms = config.paymentTerms || 'NET30';
    this.currency = config.currency || 'USD';
    this.status = config.status || 'active'; // active, inactive, blocked
    this.rating = config.rating || 0;
    this.categories = config.categories || [];
    this.notes = config.notes || '';
    this.createdAt = config.createdAt || new Date().toISOString();
    this.updatedAt = config.updatedAt || new Date().toISOString();
  }

  generateId() {
    return `supplier-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get full address
   * @returns {string} - Full address
   */
  getFullAddress() {
    const parts = [this.address, this.city, this.state, this.country, this.postalCode];
    return parts.filter(p => p).join(', ');
  }
}

/**
 * Supplier Item class
 */
class SupplierItem {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.supplierId = config.supplierId || '';
    this.itemId = config.itemId || null;
    this.barcode = config.barcode || '';
    this.itemName = config.itemName || '';
    this.sku = config.sku || '';
    this.unitPrice = config.unitPrice || 0;
    this.currency = config.currency || 'USD';
    this.minOrderQty = config.minOrderQty || 1;
    this.leadTime = config.leadTime || 7;
    this.isPreferred = config.isPreferred || false;
    this.lastOrdered = config.lastOrdered || null;
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `supplier-item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Supplier Contact class
 */
class SupplierContact {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.supplierId = config.supplierId || '';
    this.name = config.name || '';
    this.role = config.role || '';
    this.email = config.email || '';
    this.phone = config.phone || '';
    this.mobile = config.mobile || '';
    this.isPrimary = config.isPrimary || false;
    this.createdAt = config.createdAt || new Date().toISOString();
  }

  generateId() {
    return `supplier-contact-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Supplier Database Manager
 */
class SupplierDatabaseManager {
  constructor() {
    this.suppliers = new Map();
    this.supplierItems = new Map();
    this.supplierContacts = new Map();
    this.init();
  }

  /**
   * Initialize supplier database manager
   */
  async init() {
    await this.loadSuppliers();
    await this.loadSupplierItems();
    await this.loadSupplierContacts();
  }

  /**
   * Load suppliers from storage
   */
  async loadSuppliers() {
    try {
      const suppliers = await gAll('suppliers');
      suppliers.forEach(s => {
        this.suppliers.set(s.id, new Supplier(s));
      });
    } catch (err) {
      console.error('Failed to load suppliers:', err);
    }
  }

  /**
   * Load supplier items from storage
   */
  async loadSupplierItems() {
    try {
      const items = await gAll('supplier_items');
      items.forEach(i => {
        this.supplierItems.set(i.id, new SupplierItem(i));
      });
    } catch (err) {
      console.error('Failed to load supplier items:', err);
    }
  }

  /**
   * Load supplier contacts from storage
   */
  async loadSupplierContacts() {
    try {
      const contacts = await gAll('supplier_contacts');
      contacts.forEach(c => {
        this.supplierContacts.set(c.id, new SupplierContact(c));
      });
    } catch (err) {
      console.error('Failed to load supplier contacts:', err);
    }
  }

  /**
   * Create supplier
   * @param {object} config - Supplier configuration
   * @returns {Supplier} - Created supplier
   */
  async createSupplier(config) {
    const supplier = new Supplier(config);
    this.suppliers.set(supplier.id, supplier);
    await this.saveSupplier(supplier);
    return supplier;
  }

  /**
   * Update supplier
   * @param {string} id - Supplier ID
   * @param {object} updates - Updates to apply
   * @returns {Supplier} - Updated supplier
   */
  async updateSupplier(id, updates) {
    const supplier = this.suppliers.get(id);
    if (supplier) {
      Object.assign(supplier, updates);
      supplier.updatedAt = new Date().toISOString();
      await this.saveSupplier(supplier);
    }
    return supplier;
  }

  /**
   * Delete supplier
   * @param {string} id - Supplier ID
   */
  async deleteSupplier(id) {
    this.suppliers.delete(id);
    await dDel('suppliers', id);

    // Delete related items and contacts
    for (const item of this.supplierItems.values()) {
      if (item.supplierId === id) {
        this.supplierItems.delete(item.id);
        await dDel('supplier_items', item.id);
      }
    }

    for (const contact of this.supplierContacts.values()) {
      if (contact.supplierId === id) {
        this.supplierContacts.delete(contact.id);
        await dDel('supplier_contacts', contact.id);
      }
    }
  }

  /**
   * Save supplier to storage
   * @param {Supplier} supplier - Supplier to save
   */
  async saveSupplier(supplier) {
    try {
      await dPut('suppliers', supplier);
    } catch (err) {
      console.error('Failed to save supplier:', err);
    }
  }

  /**
   * Add item to supplier
   * @param {string} supplierId - Supplier ID
   * @param {object} itemData - Item data
   * @returns {SupplierItem} - Created supplier item
   */
  async addSupplierItem(supplierId, itemData) {
    const supplier = this.suppliers.get(supplierId);
    if (!supplier) {
      throw new Error('Supplier not found');
    }

    const item = new SupplierItem({
      ...itemData,
      supplierId
    });

    this.supplierItems.set(item.id, item);
    await this.saveSupplierItem(item);

    return item;
  }

  /**
   * Update supplier item
   * @param {string} id - Item ID
   * @param {object} updates - Updates to apply
   * @returns {SupplierItem} - Updated item
   */
  async updateSupplierItem(id, updates) {
    const item = this.supplierItems.get(id);
    if (item) {
      Object.assign(item, updates);
      await this.saveSupplierItem(item);
    }
    return item;
  }

  /**
   * Remove supplier item
   * @param {string} id - Item ID
   */
  async removeSupplierItem(id) {
    this.supplierItems.delete(id);
    await dDel('supplier_items', id);
  }

  /**
   * Save supplier item to storage
   * @param {SupplierItem} item - Item to save
   */
  async saveSupplierItem(item) {
    try {
      await dPut('supplier_items', item);
    } catch (err) {
      console.error('Failed to save supplier item:', err);
    }
  }

  /**
   * Add contact to supplier
   * @param {string} supplierId - Supplier ID
   * @param {object} contactData - Contact data
   * @returns {SupplierContact} - Created contact
   */
  async addSupplierContact(supplierId, contactData) {
    const supplier = this.suppliers.get(supplierId);
    if (!supplier) {
      throw new Error('Supplier not found');
    }

    const contact = new SupplierContact({
      ...contactData,
      supplierId
    });

    // If this is primary, remove primary from other contacts
    if (contact.isPrimary) {
      for (const c of this.supplierContacts.values()) {
        if (c.supplierId === supplierId && c.isPrimary) {
          c.isPrimary = false;
          await this.saveSupplierContact(c);
        }
      }
    }

    this.supplierContacts.set(contact.id, contact);
    await this.saveSupplierContact(contact);

    return contact;
  }

  /**
   * Update supplier contact
   * @param {string} id - Contact ID
   * @param {object} updates - Updates to apply
   * @returns {SupplierContact} - Updated contact
   */
  async updateSupplierContact(id, updates) {
    const contact = this.supplierContacts.get(id);
    if (contact) {
      Object.assign(contact, updates);
      await this.saveSupplierContact(contact);
    }
    return contact;
  }

  /**
   * Remove supplier contact
   * @param {string} id - Contact ID
   */
  async removeSupplierContact(id) {
    this.supplierContacts.delete(id);
    await dDel('supplier_contacts', id);
  }

  /**
   * Save supplier contact to storage
   * @param {SupplierContact} contact - Contact to save
   */
  async saveSupplierContact(contact) {
    try {
      await dPut('supplier_contacts', contact);
    } catch (err) {
      console.error('Failed to save supplier contact:', err);
    }
  }

  /**
   * Get supplier
   * @param {string} id - Supplier ID
   * @returns {Supplier} - Supplier
   */
  getSupplier(id) {
    return this.suppliers.get(id);
  }

  /**
   * Get supplier by code
   * @param {string} code - Supplier code
   * @returns {Supplier} - Supplier
   */
  getSupplierByCode(code) {
    return Array.from(this.suppliers.values()).find(s => s.code === code);
  }

  /**
   * Get all suppliers
   * @returns {Array} - Array of suppliers
   */
  getAllSuppliers() {
    return Array.from(this.suppliers.values());
  }

  /**
   * Get active suppliers
   * @returns {Array} - Active suppliers
   */
  getActiveSuppliers() {
    return this.getAllSuppliers().filter(s => s.status === 'active');
  }

  /**
   * Get suppliers by category
   * @param {string} category - Category
   * @returns {Array} - Suppliers
   */
  getSuppliersByCategory(category) {
    return this.getAllSuppliers().filter(s => s.categories.includes(category));
  }

  /**
   * Search suppliers
   * @param {string} query - Search query
   * @returns {Array} - Matching suppliers
   */
  searchSuppliers(query) {
    const lowerQuery = query.toLowerCase();
    return this.getAllSuppliers().filter(s => 
      s.name.toLowerCase().includes(lowerQuery) ||
      s.code.toLowerCase().includes(lowerQuery) ||
      s.contactPerson.toLowerCase().includes(lowerQuery) ||
      s.email.toLowerCase().includes(lowerQuery)
    );
  }

  /**
   * Get supplier item
   * @param {string} id - Item ID
   * @returns {SupplierItem} - Item
   */
  getSupplierItem(id) {
    return this.supplierItems.get(id);
  }

  /**
   * Get items by supplier
   * @param {string} supplierId - Supplier ID
   * @returns {Array} - Items
   */
  getItemsBySupplier(supplierId) {
    return Array.from(this.supplierItems.values()).filter(i => i.supplierId === supplierId);
  }

  /**
   * Get suppliers for item
   * @param {string} barcode - Item barcode
   * @returns {Array} - Supplier items
   */
  getSuppliersForItem(barcode) {
    return Array.from(this.supplierItems.values()).filter(i => i.barcode === barcode);
  }

  /**
   * Get preferred supplier for item
   * @param {string} barcode - Item barcode
   * @returns {SupplierItem|null} - Preferred supplier item
   */
  getPreferredSupplierForItem(barcode) {
    const suppliers = this.getSuppliersForItem(barcode);
    return suppliers.find(s => s.isPreferred) || suppliers[0] || null;
  }

  /**
   * Get supplier contact
   * @param {string} id - Contact ID
   * @returns {SupplierContact} - Contact
   */
  getSupplierContact(id) {
    return this.supplierContacts.get(id);
  }

  /**
   * Get contacts by supplier
   * @param {string} supplierId - Supplier ID
   * @returns {Array} - Contacts
   */
  getContactsBySupplier(supplierId) {
    return Array.from(this.supplierContacts.values()).filter(c => c.supplierId === supplierId);
  }

  /**
   * Get primary contact for supplier
   * @param {string} supplierId - Supplier ID
   * @returns {SupplierContact|null} - Primary contact
   */
  getPrimaryContact(supplierId) {
    const contacts = this.getContactsBySupplier(supplierId);
    return contacts.find(c => c.isPrimary) || contacts[0] || null;
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const suppliers = this.getAllSuppliers();
    const items = Array.from(this.supplierItems.values());
    const contacts = Array.from(this.supplierContacts.values());

    return {
      totalSuppliers: suppliers.length,
      activeSuppliers: suppliers.filter(s => s.status === 'active').length,
      inactiveSuppliers: suppliers.filter(s => s.status === 'inactive').length,
      blockedSuppliers: suppliers.filter(s => s.status === 'blocked').length,
      avgRating: suppliers.length > 0 
        ? suppliers.reduce((sum, s) => sum + s.rating, 0) / suppliers.length 
        : 0,
      byCategory: this.getCategoryCounts(suppliers),
      totalItems: items.length,
      totalContacts: contacts.length,
      byCountry: this.getCountryCounts(suppliers)
    };
  }

  /**
   * Get category counts
   * @param {Array} suppliers - Suppliers
   * @returns {object} - Category counts
   */
  getCategoryCounts(suppliers) {
    const counts = {};
    suppliers.forEach(s => {
      s.categories.forEach(cat => {
        counts[cat] = (counts[cat] || 0) + 1;
      });
    });
    return counts;
  }

  /**
   * Get country counts
   * @param {Array} suppliers - Suppliers
   * @returns {object} - Country counts
   */
  getCountryCounts(suppliers) {
    const counts = {};
    suppliers.forEach(s => {
      if (s.country) {
        counts[s.country] = (counts[s.country] || 0) + 1;
      }
    });
    return counts;
  }
}

/**
 * Global supplier database manager instance
 */
const supplierDatabaseManager = new SupplierDatabaseManager();

/**
 * Initialize supplier database
 */
async function initSupplierDatabase() {
  await supplierDatabaseManager.init();
  return supplierDatabaseManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.SupplierDatabase = {
    manager: supplierDatabaseManager,
    init: initSupplierDatabase,
    createSupplier: (config) => supplierDatabaseManager.createSupplier(config),
    updateSupplier: (id, updates) => supplierDatabaseManager.updateSupplier(id, updates),
    deleteSupplier: (id) => supplierDatabaseManager.deleteSupplier(id),
    getSupplier: (id) => supplierDatabaseManager.getSupplier(id),
    getSupplierByCode: (code) => supplierDatabaseManager.getSupplierByCode(code),
    getAllSuppliers: () => supplierDatabaseManager.getAllSuppliers(),
    getActiveSuppliers: () => supplierDatabaseManager.getActiveSuppliers(),
    getSuppliersByCategory: (category) => supplierDatabaseManager.getSuppliersByCategory(category),
    searchSuppliers: (query) => supplierDatabaseManager.searchSuppliers(query),
    addSupplierItem: (supplierId, data) => supplierDatabaseManager.addSupplierItem(supplierId, data),
    updateSupplierItem: (id, updates) => supplierDatabaseManager.updateSupplierItem(id, updates),
    removeSupplierItem: (id) => supplierDatabaseManager.removeSupplierItem(id),
    getSupplierItem: (id) => supplierDatabaseManager.getSupplierItem(id),
    getItemsBySupplier: (supplierId) => supplierDatabaseManager.getItemsBySupplier(supplierId),
    getSuppliersForItem: (barcode) => supplierDatabaseManager.getSuppliersForItem(barcode),
    getPreferredSupplierForItem: (barcode) => supplierDatabaseManager.getPreferredSupplierForItem(barcode),
    addSupplierContact: (supplierId, data) => supplierDatabaseManager.addSupplierContact(supplierId, data),
    updateSupplierContact: (id, updates) => supplierDatabaseManager.updateSupplierContact(id, updates),
    removeSupplierContact: (id) => supplierDatabaseManager.removeSupplierContact(id),
    getSupplierContact: (id) => supplierDatabaseManager.getSupplierContact(id),
    getContactsBySupplier: (supplierId) => supplierDatabaseManager.getContactsBySupplier(supplierId),
    getPrimaryContact: (supplierId) => supplierDatabaseManager.getPrimaryContact(supplierId),
    getStats: () => supplierDatabaseManager.getStatistics()
  };
}
