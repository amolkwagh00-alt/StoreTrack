/**
 * Performance Baseline Tracking Module
 * Tracks and maintains performance baselines for comparison
 */

class PerformanceBaseline {
  constructor() {
    this.baselines = new Map();
    this.measurements = new Map();
    this.comparisons = new Map();
    this.config = {
      sampleSize: 100,
      aggregationInterval: 60000, // 1 minute
      retentionPeriod: 30 * 24 * 60 * 60 * 1000, // 30 days
      warmupPeriod: 5 * 60 * 1000, // 5 minutes
      significanceThreshold: 0.05 // 5% significance level
    };
    this.startTime = Date.now();
    this.isWarmedUp = false;
    this.warmupTimer = null;
  }

  /**
   * Initialize baseline tracking
   * @param {Object} config - Configuration options
   */
  initialize(config = {}) {
    this.config = { ...this.config, ...config };
    this.startWarmup();
  }

  /**
   * Start warmup period
   */
  startWarmup() {
    this.warmupTimer = setTimeout(() => {
      this.isWarmedUp = true;
      this.calculateBaselines();
    }, this.config.warmupPeriod);
  }

  /**
   * Record a measurement
   * @param {string} metricName - Metric name
   * @param {number} value - Measurement value
   * @param {Object} metadata - Additional metadata
   */
  recordMeasurement(metricName, value, metadata = {}) {
    const measurements = this.measurements.get(metricName) || [];
    
    measurements.push({
      value,
      timestamp: Date.now(),
      ...metadata
    });
    
    // Keep only recent measurements
    const cutoff = Date.now() - this.config.retentionPeriod;
    const recent = measurements.filter(m => m.timestamp >= cutoff);
    
    this.measurements.set(metricName, recent);
    
    // Update baseline if warmed up and enough samples
    if (this.isWarmedUp && recent.length >= this.config.sampleSize) {
      this.updateBaseline(metricName);
    }
  }

  /**
   * Update baseline for a metric
   * @param {string} metricName - Metric name
   */
  updateBaseline(metricName) {
    const measurements = this.measurements.get(metricName);
    if (!measurements || measurements.length < this.config.sampleSize) {return;}
    
    // Use recent samples for baseline
    const samples = measurements.slice(-this.config.sampleSize).map(m => m.value);
    
    const stats = this.calculateStatistics(samples);
    
    this.baselines.set(metricName, {
      name: metricName,
      ...stats,
      sampleCount: samples.length,
      calculatedAt: Date.now(),
      period: {
        start: measurements[measurements.length - samples.length].timestamp,
        end: measurements[measurements.length - 1].timestamp
      }
    });
  }

  /**
   * Calculate statistics from samples
   * @param {Array} samples - Sample values
   */
  calculateStatistics(samples) {
    const sorted = [...samples].sort((a, b) => a - b);
    const n = samples.length;
    
    const mean = samples.reduce((sum, v) => sum + v, 0) / n;
    const variance = samples.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / n;
    const stdDev = Math.sqrt(variance);
    
    const median = n % 2 === 0 
      ? (sorted[n/2 - 1] + sorted[n/2]) / 2 
      : sorted[Math.floor(n/2)];
    
    return {
      mean,
      median,
      stdDev,
      variance,
      min: sorted[0],
      max: sorted[n - 1],
      p25: sorted[Math.floor(n * 0.25)],
      p75: sorted[Math.floor(n * 0.75)],
      p90: sorted[Math.floor(n * 0.90)],
      p95: sorted[Math.floor(n * 0.95)],
      p99: sorted[Math.floor(n * 0.99)]
    };
  }

  /**
   * Calculate all baselines
   */
  calculateBaselines() {
    for (const metricName of this.measurements.keys()) {
      this.updateBaseline(metricName);
    }
  }

  /**
   * Compare current value to baseline
   * @param {string} metricName - Metric name
   * @param {number} currentValue - Current value to compare
   */
  compareToBaseline(metricName, currentValue) {
    const baseline = this.baselines.get(metricName);
    if (!baseline) {
      return null;
    }
    
    const zScore = baseline.stdDev > 0 
      ? (currentValue - baseline.mean) / baseline.stdDev
      : 0;
    
    const percentChange = baseline.mean > 0 
      ? ((currentValue - baseline.mean) / baseline.mean) * 100
      : 0;
    
    let status = 'normal';
    if (Math.abs(zScore) > 3) {status = 'critical';}
    else if (Math.abs(zScore) > 2) {status = 'warning';}
    else if (Math.abs(zScore) > 1) {status = 'degraded';}
    
    const comparison = {
      metricName,
      currentValue,
      baseline,
      zScore,
      percentChange,
      status,
      timestamp: Date.now()
    };
    
    this.comparisons.set(`${metricName}_${Date.now()}`, comparison);
    
    return comparison;
  }

  /**
   * Get baseline for metric
   * @param {string} metricName - Metric name
   */
  getBaseline(metricName) {
    return this.baselines.get(metricName);
  }

  /**
   * Get all baselines
   */
  getAllBaselines() {
    return Array.from(this.baselines.values());
  }

  /**
   * Get measurements for metric
   * @param {string} metricName - Metric name
   * @param {Object} options - Query options
   */
  getMeasurements(metricName, options = {}) {
    const measurements = this.measurements.get(metricName) || [];
    
    let filtered = [...measurements];
    
    if (options.since) {
      filtered = filtered.filter(m => m.timestamp >= options.since);
    }
    
    if (options.until) {
      filtered = filtered.filter(m => m.timestamp <= options.until);
    }
    
    if (options.limit) {
      filtered = filtered.slice(-options.limit);
    }
    
    return filtered;
  }

  /**
   * Get recent comparisons
   * @param {string} metricName - Metric name
   * @param {number} limit - Number of comparisons
   */
  getRecentComparisons(metricName, limit = 10) {
    const comparisons = Array.from(this.comparisons.values())
      .filter(c => c.metricName === metricName)
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, limit);
    
    return comparisons;
  }

  /**
   * Get baseline drift analysis
   * @param {string} metricName - Metric name
   */
  getBaselineDrift(metricName) {
    const measurements = this.measurements.get(metricName);
    const baseline = this.baselines.get(metricName);
    
    if (!measurements || !baseline) {return null;}
    
    // Split measurements into old and new
    const midpoint = Math.floor(measurements.length / 2);
    const oldSamples = measurements.slice(0, midpoint).map(m => m.value);
    const newSamples = measurements.slice(midpoint).map(m => m.value);
    
    if (oldSamples.length < 10 || newSamples.length < 10) {return null;}
    
    const oldStats = this.calculateStatistics(oldSamples);
    const newStats = this.calculateStatistics(newSamples);
    
    const meanDrift = newStats.mean - oldStats.mean;
    const meanDriftPercent = oldStats.mean > 0 
      ? (meanDrift / oldStats.mean) * 100
      : 0;
    
    // Perform simple t-test for significance
    const pooledStdDev = Math.sqrt(
      (oldStats.variance * (oldSamples.length - 1) + newStats.variance * (newSamples.length - 1)) /
      (oldSamples.length + newSamples.length - 2)
    );
    
    const tStatistic = pooledStdDev > 0 
      ? meanDrift / (pooledStdDev * Math.sqrt(1/oldSamples.length + 1/newSamples.length))
      : 0;
    
    const isSignificant = Math.abs(tStatistic) > 1.96; // Approximate for 95% confidence
    
    return {
      metricName,
      oldMean: oldStats.mean,
      newMean: newStats.mean,
      meanDrift,
      meanDriftPercent,
      tStatistic,
      isSignificant,
      direction: meanDrift > 0 ? 'increasing' : 'decreasing',
      magnitude: Math.abs(meanDriftPercent)
    };
  }

  /**
   * Get performance summary
   */
  getPerformanceSummary() {
    const summary = {
      totalMetrics: this.measurements.size,
      baselinesEstablished: this.baselines.size,
      isWarmedUp: this.isWarmedUp,
      uptime: Date.now() - this.startTime,
      metrics: {}
    };
    
    for (const metricName of this.measurements.keys()) {
      const baseline = this.baselines.get(metricName);
      const measurements = this.measurements.get(metricName);
      
      summary.metrics[metricName] = {
        hasBaseline: !!baseline,
        measurementCount: measurements.length,
        lastMeasurement: measurements[measurements.length - 1],
        baseline: baseline || null
      };
    }
    
    return summary;
  }

  /**
   * Export baseline data
   */
  exportBaselines() {
    return {
      timestamp: Date.now(),
      baselines: this.getAllBaselines(),
      summary: this.getPerformanceSummary()
    };
  }

  /**
   * Import baseline data
   * @param {Object} data - Baseline data to import
   */
  importBaselines(data) {
    if (data.baselines) {
      data.baselines.forEach(baseline => {
        this.baselines.set(baseline.name, baseline);
      });
    }
  }

  /**
   * Reset baseline for metric
   * @param {string} metricName - Metric name
   */
  resetBaseline(metricName) {
    this.baselines.delete(metricName);
    this.updateBaseline(metricName);
  }

  /**
   * Reset all baselines
   */
  resetAllBaselines() {
    this.baselines.clear();
    this.calculateBaselines();
  }

  /**
   * Clear measurements for metric
   * @param {string} metricName - Metric name
   */
  clearMeasurements(metricName) {
    this.measurements.delete(metricName);
    this.baselines.delete(metricName);
  }

  /**
   * Clear all data
   */
  clearAll() {
    this.measurements.clear();
    this.baselines.clear();
    this.comparisons.clear();
    this.isWarmedUp = false;
    this.startTime = Date.now();
    
    if (this.warmupTimer) {
      clearTimeout(this.warmupTimer);
    }
    
    this.startWarmup();
  }

  /**
   * Set configuration
   * @param {Object} config - Configuration options
   */
  setConfig(config) {
    this.config = { ...this.config, ...config };
  }

  /**
   * Get configuration
   */
  getConfig() {
    return { ...this.config };
  }
}

// Create singleton instance
const performanceBaseline = new PerformanceBaseline();

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PerformanceBaseline, performanceBaseline };
}
