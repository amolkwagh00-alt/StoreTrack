(function () {
  'use strict';

  const REPLACEMENT_TYPE = 'Replacement / Issue';
  const DEFAULT_CONFIG = { leadTimeDays: 60, internalProcurementDays: 30, safetyStockQty: 0, safetyStockDays: 0, usagePeriodDays: 90, lowStockDays: 0 };
  const SHIFTS = ['1st Shift', '2nd Shift', '3rd Shift'];
  const partUtils = (typeof window !== 'undefined' && window.PartNumberUtils) || (typeof require === 'function' ? require('../core/partNumber') : {});
  const normalizePartNo = partUtils.normalizePartNo || (value => String(value == null ? '' : value).trim().replace(/\s+/g, '').split(/([\/-])/).map(segment => /^\d+$/.test(segment) ? segment.replace(/^0+(?=\d)/, '') : segment.toUpperCase()).join(''));
  const partKey = partUtils.partKey || (value => normalizePartNo(value).toLowerCase());
  const displayPartNo = partUtils.displayPartNo || (values => [...new Set(values)].join(' / '));

  function isoDate(value) {
    return String(value || '').slice(0, 10);
  }

  function parseDate(value) {
    const date = new Date(`${isoDate(value)}T00:00:00Z`);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function addDays(value, days) {
    const date = parseDate(value) || new Date();
    date.setUTCDate(date.getUTCDate() + Number(days || 0));
    return date.toISOString().slice(0, 10);
  }

  function daysBetween(start, end) {
    const a = parseDate(start);
    const b = parseDate(end);
    return a && b ? Math.max(1, Math.floor((b - a) / 86400000) + 1) : 1;
  }

  function numeric(value) {
    const result = Number(value);
    return Number.isFinite(result) ? result : 0;
  }

  function inRange(date, start, end) {
    const day = isoDate(date);
    return day >= isoDate(start) && day <= isoDate(end);
  }

  function isReplacement(row) {
    return row && (row.type === REPLACEMENT_TYPE || row.transactionType === REPLACEMENT_TYPE || row.transactionType === 'Replacement');
  }

  function replacementDate(row) {
    return isoDate(row.replacementDate || row.replacementDateTime || row.date || row.createdAt);
  }

  function matches(row, filters) {
    if (!isReplacement(row)) {return false;}
    if (filters.start && !inRange(replacementDate(row), filters.start, filters.end || filters.start)) {return false;}
    if (filters.partNo && partKey(row.partNo) !== partKey(filters.partNo)) {return false;}
    if (filters.stationNo && String(row.stationNo || '') !== String(filters.stationNo)) {return false;}
    if (filters.gunReferenceNo && String(row.gunReferenceNo || '') !== String(filters.gunReferenceNo)) {return false;}
    if (filters.componentType && String(row.componentType || '') !== String(filters.componentType)) {return false;}
    if (filters.shift && String(row.shift || '') !== String(filters.shift)) {return false;}
    return true;
  }

  function emptyPart(partNo) {
    return { partNo, totalConsumption: 0, last7Days: 0, last30Days: 0, last60Days: 0, last90Days: 0, averageDailyUsage: 0, averageMonthlyUsage: 0, insufficientData: true, shifts: { '1st Shift': 0, '2nd Shift': 0, '3rd Shift': 0 }, stations: {}, transactions: [] };
  }

  function calculateConsumption(replacements, options = {}) {
    const end = isoDate(options.end || new Date().toISOString());
    const periodDays = Math.max(1, Number(options.periodDays || 90));
    const start = isoDate(options.start || addDays(end, -(periodDays - 1)));
    const rows = (replacements || []).filter(row => matches(row, { ...options, start, end }));
    const byPart = new Map();
    rows.forEach(row => {
      const partNo = String(row.partNo || '').trim();
      const key = partKey(partNo);
      if (!key) {return;}
      const item = byPart.get(key) || { ...emptyPart(partNo), variants: new Set() };
      item.variants.add(partNo);
      const quantity = Math.max(0, numeric(row.quantity));
      const day = replacementDate(row);
      item.totalConsumption += quantity;
      [7, 30, 60, 90].forEach(window => {
        if (inRange(day, addDays(end, -(window - 1)), end)) {item[`last${window}Days`] += quantity;}
      });
      if (SHIFTS.includes(row.shift)) {item.shifts[row.shift] += quantity;}
      const station = String(row.stationNo || 'Unknown').trim() || 'Unknown';
      item.stations[station] = numeric(item.stations[station]) + quantity;
      item.transactions.push(row);
      byPart.set(key, item);
    });
    return [...byPart.values()].map(item => {
      item.partNo = displayPartNo([...(item.variants || []), item.partNo]);
      item.averageDailyUsage = item.totalConsumption / daysBetween(start, end);
      item.averageMonthlyUsage = item.averageDailyUsage * 30;
      item.insufficientData = item.transactions.length === 0;
      return item;
    });
  }

  function mergeConfig(part, globalConfig = {}) {
    const partConfig = part?.analytics || part?.consumptionConfig || {};
    return { ...DEFAULT_CONFIG, ...globalConfig, ...partConfig, criticalFlag: Boolean(partConfig.criticalFlag ?? globalConfig.criticalFlag ?? false), leadTimeDays: numeric(partConfig.leadTimeDays ?? globalConfig.leadTimeDays ?? DEFAULT_CONFIG.leadTimeDays), internalProcurementDays: numeric(partConfig.internalProcurementDays ?? globalConfig.internalProcurementDays ?? DEFAULT_CONFIG.internalProcurementDays), safetyStockQty: numeric(partConfig.safetyStockQty ?? globalConfig.safetyStockQty ?? 0), safetyStockDays: numeric(partConfig.safetyStockDays ?? globalConfig.safetyStockDays ?? 0), usagePeriodDays: numeric(partConfig.usagePeriodDays ?? globalConfig.usagePeriodDays ?? DEFAULT_CONFIG.usagePeriodDays) || 90 };
  }

  function forecastStatus({ currentStock, expectedDaysUntilZero, effectiveLeadTimeDays, reorderPoint, lowStockThreshold }) {
    if (numeric(currentStock) <= 0) {return 'ZERO STOCK';}
    if (expectedDaysUntilZero != null && expectedDaysUntilZero < numeric(effectiveLeadTimeDays)) {return 'STOCK-OUT RISK';}
    if (numeric(currentStock) <= numeric(lowStockThreshold) && numeric(lowStockThreshold) > 0) {return 'LOW STOCK';}
    if (numeric(currentStock) <= numeric(reorderPoint)) {return 'REORDER';}
    return 'NORMAL';
  }
  function calculateForecast(input = {}) {
    const today = isoDate(input.today || new Date().toISOString());
    const stockByPart = new Map();
    const stockVariants = new Map();
    const occurrenceByPart = new Map();
    Object.entries(input.occurrenceByPart || {}).forEach(([partNo, quantity]) => {
      const key = partKey(partNo);
      if (key) {occurrenceByPart.set(key, numeric(occurrenceByPart.get(key)) + numeric(quantity));}
    });
    (input.stock || []).forEach(row => { const partNo = String(row.partNo || '').trim(); const key = partKey(partNo); if (key) { const item = stockVariants.get(key) || { variants: new Set(), quantity: 0 }; item.variants.add(partNo); item.quantity += numeric(row.quantity); stockVariants.set(key, item); stockByPart.set(key, item.quantity); } });
    const partGroups = new Map();
    (input.parts || [...stockByPart.keys()].map(partNo => ({ partNo }))).forEach(part => { const key = partKey(part.partNo); if (!key) {return;} const group = partGroups.get(key) || { ...part, variants: new Set() }; group.variants.add(String(part.partNo || '').trim()); partGroups.set(key, group); });
    const parts = [...partGroups.entries()].map(([key, part]) => ({ ...part, partNo: displayPartNo([...part.variants]), _partKey: key }));
    const consumption = calculateConsumption(input.replacements || [], { end: today, periodDays: input.periodDays || 90 });
    const consumptionByPart = new Map(consumption.map(row => [partKey(row.partNo), row]));
    return parts.map(part => {
      const partNo = String(part.partNo || '').trim();
      const logicalKey = part._partKey || partKey(partNo);
      const usage = consumptionByPart.get(logicalKey) || emptyPart(partNo);
      const config = mergeConfig(part, input.config || {});
      const currentStock = numeric(stockByPart.get(logicalKey));
      const averageDailyUsage = usage.averageDailyUsage;
      const averagePriorUsage = usage.last90Days > 0 ? usage.last90Days / 90 : 0;
      const usageDays = new Set(usage.transactions.map(row => replacementDate(row)).filter(Boolean)).size; const usageConfidence = usageDays >= 90 ? 'HIGH' : usageDays >= 30 ? 'MEDIUM' : usageDays >= 1 ? 'LOW' : 'NO DATA';
      const abnormalConsumption = averagePriorUsage > 0 && usage.last7Days > averagePriorUsage * 7 * 2;
      const expectedDaysUntilZero = averageDailyUsage > 0 ? currentStock / averageDailyUsage : null;
      const expectedZeroDate = expectedDaysUntilZero == null ? null : addDays(today, Math.ceil(expectedDaysUntilZero));
      const occurrenceQty = numeric(occurrenceByPart.get(logicalKey) ?? part.occurrenceQty ?? part.minimumStock); const safetyStock = occurrenceQty; const effectiveLeadTimeDays = config.leadTimeDays + config.internalProcurementDays; const reorderPoint = averageDailyUsage * effectiveLeadTimeDays + safetyStock; const lowStockThreshold = occurrenceQty;
      const stockStatus = numeric(currentStock) <= 0 ? 'ZERO STOCK' : numeric(currentStock) < numeric(lowStockThreshold) && numeric(lowStockThreshold) > 0 ? 'LOW STOCK' : 'OK STOCK';
      const forecastStatusValue = usage.insufficientData ? 'NO DATA' : forecastStatus({ currentStock, expectedDaysUntilZero, effectiveLeadTimeDays, reorderPoint, lowStockThreshold });
      const status = usage.insufficientData ? stockStatus : forecastStatusValue;
      return { ...part, partNo, currentStock, stockStatus, forecastStatus: forecastStatusValue, averageDailyUsage, averageMonthlyUsage: usage.averageMonthlyUsage, last7Days: usage.last7Days, last30Days: usage.last30Days, last60Days: usage.last60Days, last90Days: usage.last90Days, expectedDaysUntilZero, expectedZeroDate, leadTimeDays: effectiveLeadTimeDays, supplierLeadTimeDays: config.leadTimeDays, internalProcurementDays: config.internalProcurementDays, safetyStockQty: safetyStock, occurrenceQty, reorderPoint, criticalFlag: Boolean(config.criticalFlag), insufficientData: usage.insufficientData, usageDays, usageConfidence, abnormalConsumption, status, shifts: usage.shifts, stations: usage.stations };
    });
  }

  function orderNowRows(input) {
    const priority = { 'ZERO STOCK': 5, 'STOCK-OUT RISK': 4, REORDER: 3, 'LOW STOCK': 2, NORMAL: 1 };
    return calculateForecast(input).filter(row => !['NORMAL', 'OK STOCK', 'NO DATA'].includes(row.status)).sort((a, b) => priority[b.status] - priority[a.status] || String(a.partNo).localeCompare(String(b.partNo)));
  }

  function transactionDrillDown(rows, partNo) {
    const list = (rows || []).filter(row => partKey(row.partNo) === partKey(partNo)).sort((a, b) => String(a.date || a.replacementDateTime || a.createdAt || '').localeCompare(String(b.date || b.replacementDateTime || b.createdAt || '')));
    let balance = 0;
    let cumulativeUsage = 0;
    return list.map(row => {
      const quantity = numeric(row.quantity);
      if (row.type === 'Receive' || row.type === 'Repair Return') {balance += quantity;}
      else if (row.type === 'Replacement / Issue' || row.type === 'Scrap' || row.type === 'Adjustment' && row.direction === 'OUT') {balance -= quantity; cumulativeUsage += quantity;}
      else if (row.type === 'Adjustment') {balance += quantity;}
      return { ...row, runningBalance: balance, cumulativeUsage };
    });
  }

  async function loadConfig() {
    if (typeof window.gAll !== 'function') {return { ...DEFAULT_CONFIG };}
    const rows = await window.gAll('component_analytics_config');
    return { ...DEFAULT_CONFIG, ...(rows.find(row => row.id === 'default') || {}) };
  }

  async function saveConfig(config) {
    if (typeof window.dPut !== 'function') {throw new Error('Database is unavailable');}
    const value = { id: 'default', ...DEFAULT_CONFIG, ...config, updatedAt: new Date().toISOString() };
    await window.dPut('component_analytics_config', value);
    if (typeof window.addAudit === 'function') {await window.addAudit('COMPONENT_ANALYTICS_CONFIG_UPDATE', 'Shank Analytics Configuration', 'default');}
    return value;
  }

  const api = { REPLACEMENT_TYPE, DEFAULT_CONFIG, calculateConsumption, calculateForecast, forecastStatus, orderNowRows, transactionDrillDown, loadConfig, saveConfig, addDays, daysBetween };
  if (typeof window !== 'undefined') {window.ShankConsumptionAnalytics = api;}
  if (typeof module !== 'undefined') {module.exports = api;}
}());
