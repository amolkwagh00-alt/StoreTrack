/**
 * Sentry Error Tracking Integration
 * Production error monitoring and reporting
 */

class SentryIntegration {
  constructor() {
    this.enabled = false;
    this.dsn = null;
    this.environment = 'development';
    this.release = null;
    this.initialized = false;
  }

  /**
   * Initialize Sentry
   * @param {Object} config - Sentry configuration
   */
  initialize(config = {}) {
    if (typeof window === 'undefined') {
      // Main process initialization
      this.initializeMainProcess(config);
    } else {
      // Renderer process initialization
      this.initializeRenderer(config);
    }
  }

  /**
   * Initialize Sentry in main process
   */
  initializeMainProcess(config) {
    try {
      if (typeof require !== 'function') {
        console.warn('[Sentry] require not available, skipping main process init');
        return;
      }
      
      const { Sentry } = require('@sentry/electron');
      
      this.dsn = config.dsn || (typeof process !== 'undefined' ? process.env.SENTRY_DSN : null);
      this.environment = config.environment || (typeof process !== 'undefined' ? process.env.NODE_ENV : 'development') || 'development';
      this.release = config.release || (typeof require === 'function' ? require('../package.json').version : '1.0.0');
      
      if (!this.dsn) {
        console.warn('[Sentry] DSN not configured, error tracking disabled');
        return;
      }
      
      Sentry.init({
        dsn: this.dsn,
        environment: this.environment,
        release: this.release,
        beforeSend: this.filterBeforeSend.bind(this),
        integrations: [
          new Sentry.Integrations.FunctionToString(),
          new Sentry.Integrations.LinkedErrors(),
          new Sentry.Integrations.Http({ tracing: false })
        ],
        tracesSampleRate: config.tracesSampleRate || 0.1,
        maxBreadcrumbs: 50,
        debug: config.debug || false
      });
      
      this.enabled = true;
      this.initialized = true;
      console.log('[Sentry] Main process initialized');
      
    } catch (error) {
      console.error('[Sentry] Initialization failed:', error.message);
    }
  }

  /**
   * Initialize Sentry in renderer process
   */
  initializeRenderer(config) {
    try {
      const Sentry = window.Sentry;
      if (!Sentry || typeof Sentry.BrowserClient !== 'function') {
        console.warn('[Sentry] Browser SDK is not loaded, renderer tracking disabled');
        return;
      }
      const { BrowserClient } = Sentry;
      
      this.dsn = config.dsn || window.SENTRY_DSN;
      this.environment = config.environment || 'development';
      this.release = config.release || window.APP_VERSION;
      
      if (!this.dsn) {
        console.warn('[Sentry] DSN not configured, error tracking disabled');
        return;
      }
      
      const client = new BrowserClient({
        dsn: this.dsn,
        environment: this.environment,
        release: this.release,
        beforeSend: this.filterBeforeSend.bind(this),
        integrations: [
          new Sentry.Integrations.FunctionToString(),
          new Sentry.Integrations.InboundFilters(),
          new Sentry.Integrations.Breadcrumbs({
            console: false,
            dom: true,
            fetch: true,
            history: true,
            xhr: true
          })
        ],
        tracesSampleRate: config.tracesSampleRate || 0.1,
        maxBreadcrumbs: 50,
        debug: config.debug || false
      });
      
      Sentry.getCurrentHub().bindClient(client);
      
      this.enabled = true;
      this.initialized = true;
      console.log('[Sentry] Renderer process initialized');
      
    } catch (error) {
      console.error('[Sentry] Initialization failed:', error.message);
    }
  }

  /**
   * Filter errors before sending
   * @param {Object} event - Sentry event
   */
  filterBeforeSend(event) {
    // Filter out sensitive data
    if (event.request) {
      delete event.request.cookies;
      delete event.request.headers;
    }
    
    // Filter out specific error types
    if (event.exception) {
      const values = event.exception.values || [];
      for (const value of values) {
        // Filter out network errors that are expected
        if (value.type === 'NetworkError' && value.value?.includes('fetch')) {
          return null;
        }
      }
    }
    
    // Add custom context
    event.contexts = event.contexts || {};
    event.contexts.app = {
      name: 'StoreTrack Pro',
      version: this.release,
      environment: this.environment
    };
    
    return event;
  }

  /**
   * Capture exception
   * @param {Error} error - Error to capture
   * @param {Object} context - Additional context
   */
  captureException(error, context = {}) {
    if (!this.enabled) {return;}
    
    try {
      const Sentry = require('@sentry/electron');
      Sentry.withScope(scope => {
        Object.keys(context).forEach(key => {
          scope.setExtra(key, context[key]);
        });
        Sentry.captureException(error);
      });
    } catch (e) {
      console.error('[Sentry] Failed to capture exception:', e.message);
    }
  }

  /**
   * Capture message
   * @param {string} message - Message to capture
   * @param {string} level - Log level
   */
  captureMessage(message, level = 'info') {
    if (!this.enabled) {return;}
    
    try {
      const Sentry = require('@sentry/electron');
      Sentry.captureMessage(message, level);
    } catch (e) {
      console.error('[Sentry] Failed to capture message:', e.message);
    }
  }

  /**
   * Set user context
   * @param {Object} user - User information
   */
  setUser(user) {
    if (!this.enabled) {return;}
    
    try {
      const Sentry = require('@sentry/electron');
      Sentry.setUser(user);
    } catch (e) {
      console.error('[Sentry] Failed to set user:', e.message);
    }
  }

  /**
   * Set tag
   * @param {string} key - Tag key
   * @param {string} value - Tag value
   */
  setTag(key, value) {
    if (!this.enabled) {return;}
    
    try {
      const Sentry = require('@sentry/electron');
      Sentry.setTag(key, value);
    } catch (e) {
      console.error('[Sentry] Failed to set tag:', e.message);
    }
  }

  /**
   * Add breadcrumb
   * @param {Object} breadcrumb - Breadcrumb data
   */
  addBreadcrumb(breadcrumb) {
    if (!this.enabled) {return;}
    
    try {
      const Sentry = require('@sentry/electron');
      Sentry.addBreadcrumb(breadcrumb);
    } catch (e) {
      console.error('[Sentry] Failed to add breadcrumb:', e.message);
    }
  }

  /**
   * Start performance transaction
   * @param {string} name - Transaction name
   * @param {string} op - Operation type
   */
  startTransaction(name, op = 'custom') {
    if (!this.enabled) {return null;}
    
    try {
      const Sentry = require('@sentry/electron');
      return Sentry.startTransaction({ name, op });
    } catch (e) {
      console.error('[Sentry] Failed to start transaction:', e.message);
      return null;
    }
  }

  /**
   * Enable/disable Sentry
   * @param {boolean} enabled - Enable state
   */
  setEnabled(enabled) {
    this.enabled = enabled;
  }

  /**
   * Check if Sentry is enabled
   */
  isEnabled() {
    return this.enabled;
  }

  /**
   * Get current configuration
   */
  getConfig() {
    return {
      enabled: this.enabled,
      environment: this.environment,
      release: this.release,
      initialized: this.initialized
    };
  }
}

// Create singleton instance
const sentryIntegration = new SentryIntegration();

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { SentryIntegration, sentryIntegration };
}
