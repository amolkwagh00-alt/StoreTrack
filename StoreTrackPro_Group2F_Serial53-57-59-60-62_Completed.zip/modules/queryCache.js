/**
 * Query Result Caching Module
 * Provides intelligent caching for database query results
 */

class QueryCache {
  constructor() {
    this.cache = new Map();
    this.cacheStats = {
      hits: 0,
      misses: 0,
      evictions: 0,
      size: 0
    };
    this.config = {
      maxSize: 1000, // Maximum number of cached queries
      defaultTTL: 5 * 60 * 1000, // 5 minutes default TTL
      maxSizeBytes: 50 * 1024 * 1024 // 50MB max cache size
    };
    this.currentSizeBytes = 0;
  }

  /**
   * Apply runtime cache configuration during application startup.
   * @param {Object} config - Supported cache settings.
   * @returns {QueryCache} This cache instance.
   */
  initialize(config = {}) {
    this.config = { ...this.config, ...config };
    return this;
  }

  /**
   * Generate cache key from query parameters
   * @param {string} storeName - Database store name
   * @param {Object} query - Query parameters
   * @returns {string} Cache key
   */
  generateKey(storeName, query = {}) {
    const normalized = {
      store: storeName,
      ...query
    };
    return JSON.stringify(normalized);
  }

  /**
   * Get cached query result
   * @param {string} storeName - Database store name
   * @param {Object} query - Query parameters
   * @returns {Array|null} Cached result or null if not found/expired
   */
  get(storeName, query = {}) {
    const key = this.generateKey(storeName, query);
    const entry = this.cache.get(key);
    
    if (!entry) {
      this.cacheStats.misses++;
      return null;
    }
    
    // Check if expired
    if (Date.now() > entry.expiresAt) {
      this.evict(key);
      this.cacheStats.misses++;
      return null;
    }
    
    // Update access time for LRU
    entry.lastAccessed = Date.now();
    this.cacheStats.hits++;
    
    return entry.data;
  }

  /**
   * Store query result in cache
   * @param {string} storeName - Database store name
   * @param {Object} query - Query parameters
   * @param {Array} data - Query result data
   * @param {number} ttl - Time to live in milliseconds
   */
  set(storeName, query = {}, data, ttl = this.config.defaultTTL) {
    const key = this.generateKey(storeName, query);
    const dataSize = this.calculateSize(data);
    
    // Check if we need to evict entries
    this.ensureCapacity(dataSize);
    
    const entry = {
      data,
      createdAt: Date.now(),
      expiresAt: Date.now() + ttl,
      lastAccessed: Date.now(),
      size: dataSize,
      storeName,
      query
    };
    
    // Remove existing entry if present
    const existing = this.cache.get(key);
    if (existing) {
      this.currentSizeBytes -= existing.size;
    }
    
    this.cache.set(key, entry);
    this.currentSizeBytes += dataSize;
    this.cacheStats.size = this.cache.size;
  }

  /**
   * Invalidate cache entries for a specific store
   * @param {string} storeName - Database store name
   */
  invalidateStore(storeName) {
    for (const [key, entry] of this.cache) {
      if (entry.storeName === storeName) {
        this.evict(key);
      }
    }
  }

  /**
   * Invalidate cache entries matching a pattern
   * @param {string} storeName - Database store name
   * @param {Object} pattern - Query pattern to match
   */
  invalidatePattern(storeName, pattern) {
    for (const [key, entry] of this.cache) {
      if (entry.storeName === storeName && this.matchesPattern(entry.query, pattern)) {
        this.evict(key);
      }
    }
  }

  /**
   * Check if query matches pattern
   * @param {Object} query - Query to check
   * @param {Object} pattern - Pattern to match
   * @returns {boolean} Match result
   */
  matchesPattern(query, pattern) {
    for (const key in pattern) {
      if (query[key] !== pattern[key]) {
        return false;
      }
    }
    return true;
  }

  /**
   * Evict entry from cache
   * @param {string} key - Cache key
   */
  evict(key) {
    const entry = this.cache.get(key);
    if (entry) {
      this.currentSizeBytes -= entry.size;
      this.cache.delete(key);
      this.cacheStats.evictions++;
      this.cacheStats.size = this.cache.size;
    }
  }

  /**
   * Ensure cache has capacity for new entry
   * @param {number} requiredSize - Size of new entry in bytes
   */
  ensureCapacity(requiredSize) {
    // Check size limit
    if (this.currentSizeBytes + requiredSize > this.config.maxSizeBytes) {
      this.evictLRU(requiredSize);
    }
    
    // Check entry count limit
    if (this.cache.size >= this.config.maxSize) {
      this.evictLRU();
    }
  }

  /**
   * Evict least recently used entries
   * @param {number} requiredSize - Optional size requirement
   */
  evictLRU(requiredSize = 0) {
    const entries = Array.from(this.cache.entries());
    entries.sort((a, b) => a[1].lastAccessed - b[1].lastAccessed);
    
    let freedSpace = 0;
    for (const [key, entry] of entries) {
      this.evict(key);
      freedSpace += entry.size;
      
      if (requiredSize > 0 && freedSpace >= requiredSize) {
        break;
      }
      
      if (this.cache.size < this.config.maxSize * 0.8) {
        break;
      }
    }
  }

  /**
   * Calculate approximate size of data in bytes
   * @param {any} data - Data to size
   * @returns {number} Size in bytes
   */
  calculateSize(data) {
    try {
      const str = JSON.stringify(data);
      return str.length * 2; // Approximate UTF-16 byte size
    } catch (e) {
      return 1024; // Default 1KB if calculation fails
    }
  }

  /**
   * Clear all cache entries
   */
  clear() {
    this.cache.clear();
    this.currentSizeBytes = 0;
    this.cacheStats.size = 0;
  }

  /**
   * Get cache statistics
   * @returns {Object} Cache statistics
   */
  getStats() {
    const hitRate = this.cacheStats.hits + this.cacheStats.misses > 0
      ? (this.cacheStats.hits / (this.cacheStats.hits + this.cacheStats.misses) * 100).toFixed(2)
      : 0;
    
    return {
      ...this.cacheStats,
      hitRate: parseFloat(hitRate),
      currentSizeBytes: this.currentSizeBytes,
      currentSizeMB: (this.currentSizeBytes / (1024 * 1024)).toFixed(2),
      maxSizeMB: (this.config.maxSizeBytes / (1024 * 1024)).toFixed(2)
    };
  }

  /**
   * Get cache entries by store
   * @param {string} storeName - Database store name
   * @returns {Array} Cache entries for the store
   */
  getStoreEntries(storeName) {
    const entries = [];
    for (const [key, entry] of this.cache) {
      if (entry.storeName === storeName) {
        entries.push({
          key,
          query: entry.query,
          createdAt: entry.createdAt,
          expiresAt: entry.expiresAt,
          size: entry.size
        });
      }
    }
    return entries;
  }

  /**
   * Set cache configuration
   * @param {Object} config - Configuration options
   */
  setConfig(config) {
    this.config = { ...this.config, ...config };
    
    // If new max size is smaller, evict entries
    if (this.currentSizeBytes > this.config.maxSizeBytes) {
      this.ensureCapacity();
    }
  }

  /**
   * Get cache configuration
   * @returns {Object} Current configuration
   */
  getConfig() {
    return { ...this.config };
  }

  /**
   * Clean up expired entries
   */
  cleanupExpired() {
    const now = Date.now();
    for (const [key, entry] of this.cache) {
      if (now > entry.expiresAt) {
        this.evict(key);
      }
    }
  }

  /**
   * Start automatic cleanup interval
   * @param {number} intervalMs - Cleanup interval in milliseconds
   */
  startAutoCleanup(intervalMs = 60 * 1000) {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
    
    this.cleanupInterval = setInterval(() => {
      this.cleanupExpired();
    }, intervalMs);
  }

  /**
   * Stop automatic cleanup
   */
  stopAutoCleanup() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }
}

// Create singleton instance
const queryCache = new QueryCache();

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { QueryCache, queryCache };
}
