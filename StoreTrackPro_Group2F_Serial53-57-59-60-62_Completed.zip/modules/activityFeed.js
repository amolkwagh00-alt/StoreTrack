// Activity Feed Module - Real-time activity stream for collaboration

/**
 * Activity Item class
 */
class ActivityItem {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.type = config.type || 'general'; // update, comment, mention, system
    this.action = config.action || 'unknown';
    this.userId = config.userId || null;
    this.username = config.username || 'System';
    this.userAvatar = config.userAvatar || null;
    this.targetType = config.targetType || null; // material, transaction, user, document
    this.targetId = config.targetId || null;
    this.targetName = config.targetName || null;
    this.content = config.content || '';
    this.metadata = config.metadata || {};
    this.timestamp = config.timestamp || new Date().toISOString();
    this.isRead = config.isRead || false;
    this.priority = config.priority || 'normal'; // low, normal, high
  }

  generateId() {
    return `activity-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Activity Feed Manager
 */
class ActivityFeedManager {
  constructor() {
    this.feeds = new Map();
    this.globalFeed = [];
    this.subscriptions = new Map();
    this.maxFeedSize = 1000;
    this.init();
  }

  /**
   * Initialize activity feed manager
   */
  async init() {
    await this.loadGlobalFeed();
    await this.loadFeeds();
  }

  /**
   * Load global feed from storage
   */
  async loadGlobalFeed() {
    try {
      const feed = await gAll('activity_feed');
      this.globalFeed = feed.map(a => new ActivityItem(a));
    } catch (err) {
      console.error('Failed to load activity feed:', err);
    }
  }

  /**
   * Load user feeds from storage
   */
  async loadFeeds() {
    try {
      const feeds = await gAll('user_activity_feeds');
      feeds.forEach(f => {
        this.feeds.set(f.userId, f.items || []);
      });
    } catch (err) {
      console.error('Failed to load user feeds:', err);
    }
  }

  /**
   * Add activity to feed
   * @param {object} config - Activity configuration
   * @returns {ActivityItem} - Created activity
   */
  async addActivity(config) {
    const activity = new ActivityItem(config);
    
    // Add to global feed
    this.globalFeed.unshift(activity);
    
    // Limit global feed size
    if (this.globalFeed.length > this.maxFeedSize) {
      this.globalFeed = this.globalFeed.slice(0, this.maxFeedSize);
    }

    // Add to user's personal feed
    if (activity.userId) {
      this.addToUserFeed(activity.userId, activity);
    }

    // Add to relevant users' feeds
    await this.addToRelevantFeeds(activity);
    if (activity.userId) await this.saveUserFeed(activity.userId);

    // Save
    await this.saveGlobalFeed();

    // Notify subscribers
    this.notifySubscribers(activity);

    return activity;
  }

  /**
   * Add activity to user's feed
   * @param {string} userId - User ID
   * @param {ActivityItem} activity - Activity item
   */
  addToUserFeed(userId, activity) {
    if (!this.feeds.has(userId)) {
      this.feeds.set(userId, []);
    }

    const userFeed = this.feeds.get(userId);
    userFeed.unshift(activity);

    // Limit user feed size
    if (userFeed.length > 500) {
      this.feeds.set(userId, userFeed.slice(0, 500));
    }
  }

  /**
   * Add activity to relevant users' feeds
   * @param {ActivityItem} activity - Activity item
   */
  async addToRelevantFeeds(activity) {
    const updatedUsers = new Set();
    // Add to users mentioned in activity
    if (activity.metadata.mentions) {
      for (const mentionedUserId of activity.metadata.mentions) {
        this.addToUserFeed(mentionedUserId, activity);
        updatedUsers.add(mentionedUserId);
      }
    }

    // Add to users following the target
    if (activity.targetId) {
      const followers = await this.getTargetFollowers(activity.targetType, activity.targetId);
      for (const followerId of followers) {
        this.addToUserFeed(followerId, activity);
        updatedUsers.add(followerId);
      }
    }
    for (const userId of updatedUsers) await this.saveUserFeed(userId);
  }

  /**
   * Get followers of a target
   * @param {string} targetType - Target type
   * @param {string} targetId - Target ID
   * @returns {Promise<Array>} - Follower user IDs
   */
  async getTargetFollowers(targetType, targetId) {
    // This would query a followers table
    // For now, return empty array
    return [];
  }

  /**
   * Get global feed
   * @param {object} filters - Filters to apply
   * @returns {Array} - Activity items
   */
  getGlobalFeed(filters = {}) {
    let feed = [...this.globalFeed];

    if (filters.type) {
      feed = feed.filter(a => a.type === filters.type);
    }

    if (filters.action) {
      feed = feed.filter(a => a.action === filters.action);
    }

    if (filters.userId) {
      feed = feed.filter(a => a.userId === filters.userId);
    }

    if (filters.targetType) {
      feed = feed.filter(a => a.targetType === filters.targetType);
    }

    if (filters.targetId) {
      feed = feed.filter(a => a.targetId === filters.targetId);
    }

    if (filters.since) {
      const since = new Date(filters.since);
      feed = feed.filter(a => new Date(a.timestamp) >= since);
    }

    if (filters.until) {
      const until = new Date(filters.until);
      feed = feed.filter(a => new Date(a.timestamp) <= until);
    }

    if (filters.limit) {
      feed = feed.slice(0, filters.limit);
    }

    return feed;
  }

  /**
   * Get user's feed
   * @param {string} userId - User ID
   * @param {object} filters - Filters to apply
   * @returns {Array} - Activity items
   */
  getUserFeed(userId, filters = {}) {
    let feed = this.feeds.get(userId) || [];

    if (filters.unreadOnly) {
      feed = feed.filter(a => !a.isRead);
    }

    if (filters.type) {
      feed = feed.filter(a => a.type === filters.type);
    }

    if (filters.priority) {
      feed = feed.filter(a => a.priority === filters.priority);
    }

    if (filters.limit) {
      feed = feed.slice(0, filters.limit);
    }

    return feed;
  }

  /**
   * Mark activities as read
   * @param {string} userId - User ID
   * @param {Array} activityIds - Activity IDs to mark as read
   */
  async markAsRead(userId, activityIds) {
    const userFeed = this.feeds.get(userId);
    if (userFeed) {
      activityIds.forEach(id => {
        const activity = userFeed.find(a => a.id === id);
        if (activity) {
          activity.isRead = true;
        }
      });
      await this.saveUserFeed(userId);
    }
  }

  /**
   * Mark all activities as read for user
   * @param {string} userId - User ID
   */
  async markAllAsRead(userId) {
    const userFeed = this.feeds.get(userId);
    if (userFeed) {
      userFeed.forEach(a => a.isRead = true);
      await this.saveUserFeed(userId);
    }
  }

  /**
   * Get unread count for user
   * @param {string} userId - User ID
   * @returns {number} - Unread count
   */
  getUnreadCount(userId) {
    const userFeed = this.feeds.get(userId) || [];
    return userFeed.filter(a => !a.isRead).length;
  }

  /**
   * Subscribe to feed updates
   * @param {string} userId - User ID
   * @param {Function} callback - Callback function
   */
  subscribe(userId, callback) {
    if (!this.subscriptions.has(userId)) {
      this.subscriptions.set(userId, new Set());
    }
    this.subscriptions.get(userId).add(callback);
  }

  /**
   * Unsubscribe from feed updates
   * @param {string} userId - User ID
   * @param {Function} callback - Callback function
   */
  unsubscribe(userId, callback) {
    if (this.subscriptions.has(userId)) {
      this.subscriptions.get(userId).delete(callback);
    }
  }

  /**
   * Notify subscribers
   * @param {ActivityItem} activity - Activity item
   */
  notifySubscribers(activity) {
    // Notify global subscribers
    for (const [, callbacks] of this.subscriptions) {
      callbacks.forEach(callback => {
        try {
          callback(activity);
        } catch (err) {
          console.error('Activity feed subscriber callback error:', err);
        }
      });
    }
  }

  /**
   * Save global feed to storage
   */
  async saveGlobalFeed() {
    try {
      await dClr('activity_feed');
      await batchPut('activity_feed', this.globalFeed);
    } catch (err) {
      console.error('Failed to save activity feed:', err);
    }
  }

  /**
   * Save user feed to storage
   * @param {string} userId - User ID
   */
  async saveUserFeed(userId) {
    try {
      await dPut('user_activity_feeds', {
        id: userId,
        userId,
        items: this.feeds.get(userId) || []
      });
    } catch (err) {
      console.error('Failed to save user feed:', err);
    }
  }

  /**
   * Delete activity
   * @param {string} activityId - Activity ID
   */
  async deleteActivity(activityId) {
    this.globalFeed = this.globalFeed.filter(a => a.id !== activityId);
    
    for (const [userId, feed] of this.feeds) {
      this.feeds.set(userId, feed.filter(a => a.id !== activityId));
    }

    await this.saveGlobalFeed();
  }

  /**
   * Clear old activities
   * @param {number} daysToKeep - Days to keep
   */
  async clearOldActivities(daysToKeep = 30) {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

    this.globalFeed = this.globalFeed.filter(a => new Date(a.timestamp) >= cutoffDate);

    for (const [userId, feed] of this.feeds) {
      this.feeds.set(userId, feed.filter(a => new Date(a.timestamp) >= cutoffDate));
    }

    await this.saveGlobalFeed();
  }

  /**
   * Get activity statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const feed = this.getGlobalFeed();
    return {
      totalActivities: feed.length,
      byType: this.getTypeCounts(feed),
      byAction: this.getActionCounts(feed),
      byTargetType: this.getTargetTypeCounts(feed),
      byPriority: this.getPriorityCounts(feed)
    };
  }

  /**
   * Get type counts
   * @param {Array} feed - Activity feed
   * @returns {object} - Type counts
   */
  getTypeCounts(feed) {
    const counts = {};
    feed.forEach(a => {
      counts[a.type] = (counts[a.type] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get action counts
   * @param {Array} feed - Activity feed
   * @returns {object} - Action counts
   */
  getActionCounts(feed) {
    const counts = {};
    feed.forEach(a => {
      counts[a.action] = (counts[a.action] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get target type counts
   * @param {Array} feed - Activity feed
   * @returns {object} - Target type counts
   */
  getTargetTypeCounts(feed) {
    const counts = {};
    feed.forEach(a => {
      if (a.targetType) {
        counts[a.targetType] = (counts[a.targetType] || 0) + 1;
      }
    });
    return counts;
  }

  /**
   * Get priority counts
   * @param {Array} feed - Activity feed
   * @returns {object} - Priority counts
   */
  getPriorityCounts(feed) {
    const counts = {};
    feed.forEach(a => {
      counts[a.priority] = (counts[a.priority] || 0) + 1;
    });
    return counts;
  }

  /**
   * Create common activity types
   */
  async createUpdateActivity(userId, targetType, targetId, targetName, changes) {
    return this.addActivity({
      type: 'update',
      action: 'updated',
      userId,
      username: await this.getUsername(userId),
      targetType,
      targetId,
      targetName,
      content: `Updated ${targetType}: ${targetName}`,
      metadata: { changes }
    });
  }

  async createCommentActivity(userId, targetType, targetId, targetName, comment) {
    return this.addActivity({
      type: 'comment',
      action: 'commented',
      userId,
      username: await this.getUsername(userId),
      targetType,
      targetId,
      targetName,
      content: `Commented on ${targetName}`,
      metadata: { comment }
    });
  }

  async createMentionActivity(userId, mentionedUserId, targetType, targetId, content) {
    return this.addActivity({
      type: 'mention',
      action: 'mentioned',
      userId,
      username: await this.getUsername(userId),
      targetType,
      targetId,
      content,
      metadata: { mentions: [mentionedUserId] }
    });
  }

  /**
   * Get username from user ID
   * @param {string} userId - User ID
   * @returns {Promise<string>} - Username
   */
  async getUsername(userId) {
    try {
      const user = await gOne('users', userId);
      return user?.username || 'Unknown';
    } catch (err) {
      return 'Unknown';
    }
  }
}

/**
 * Global activity feed manager instance
 */
const activityFeedManager = new ActivityFeedManager();

/**
 * Initialize activity feed
 */
async function initActivityFeed() {
  await activityFeedManager.init();
  return activityFeedManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.ActivityFeed = {
    manager: activityFeedManager,
    init: initActivityFeed,
    add: (config) => activityFeedManager.addActivity(config),
    getGlobal: (filters) => activityFeedManager.getGlobalFeed(filters),
    getUser: (userId, filters) => activityFeedManager.getUserFeed(userId, filters),
    markAsRead: (userId, ids) => activityFeedManager.markAsRead(userId, ids),
    markAllAsRead: (userId) => activityFeedManager.markAllAsRead(userId),
    getUnreadCount: (userId) => activityFeedManager.getUnreadCount(userId),
    subscribe: (userId, callback) => activityFeedManager.subscribe(userId, callback),
    unsubscribe: (userId, callback) => activityFeedManager.unsubscribe(userId, callback),
    delete: (id) => activityFeedManager.deleteActivity(id),
    clearOld: (days) => activityFeedManager.clearOldActivities(days),
    createUpdate: (userId, type, tid, tname, changes) => activityFeedManager.createUpdateActivity(userId, type, tid, tname, changes),
    createComment: (userId, type, tid, tname, comment) => activityFeedManager.createCommentActivity(userId, type, tid, tname, comment),
    createMention: (userId, mentioned, type, tid, content) => activityFeedManager.createMentionActivity(userId, mentioned, type, tid, content),
    getStats: () => activityFeedManager.getStatistics()
  };
}
