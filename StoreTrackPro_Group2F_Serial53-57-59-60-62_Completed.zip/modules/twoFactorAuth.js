// Two-Factor Authentication Module - TOTP-based 2FA

/**
 * TOTP Generator (Time-based One-Time Password)
 */
class TOTPGenerator {
  constructor() {
    this.secretLength = 20;
    this.digits = 6;
    this.period = 30; // 30 seconds
  }

  /**
   * Generate random secret
   * @returns {string} - Base32 encoded secret
   */
  generateSecret() {
    const buffer = new Uint8Array(this.secretLength);
    crypto.getRandomValues(buffer);
    return this.base32Encode(buffer);
  }

  /**
   * Encode to Base32
   * @param {Uint8Array} buffer - Buffer to encode
   * @returns {string} - Base32 string
   */
  base32Encode(buffer) {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let bits = 0;
    let value = 0;
    let output = '';

    for (let i = 0; i < buffer.length; i++) {
      value = (value << 8) | buffer[i];
      bits += 8;

      while (bits >= 5) {
        output += alphabet[(value >>> (bits - 5)) & 31];
        bits -= 5;
      }
    }

    if (bits > 0) {
      output += alphabet[(value << (5 - bits)) & 31];
    }

    return output;
  }

  /**
   * Generate a standards-compliant RFC 6238 TOTP code using HMAC-SHA1.
   * @param {string} secret - Base32 secret
   * @param {number} timestampMs - Timestamp in milliseconds (defaults to now)
   * @returns {Promise<string>} - 6-digit code
   */
  async generateTOTP(secret, timestampMs = Date.now()) {
    const keyBytes = this.base32Decode(secret);
    const counter = Math.floor(timestampMs / 1000 / this.period);
    const counterBytes = this.intToBytes(counter);
    const key = await crypto.subtle.importKey(
      'raw',
      keyBytes,
      { name: 'HMAC', hash: 'SHA-1' },
      false,
      ['sign']
    );
    const mac = new Uint8Array(await crypto.subtle.sign('HMAC', key, counterBytes));
    const offset = mac[mac.length - 1] & 0x0f;
    const binary = ((mac[offset] & 0x7f) << 24) |
      ((mac[offset + 1] & 0xff) << 16) |
      ((mac[offset + 2] & 0xff) << 8) |
      (mac[offset + 3] & 0xff);
    return String(binary % (10 ** this.digits)).padStart(this.digits, '0');
  }

  /** Convert a positive integer counter to an 8-byte big-endian value. */
  intToBytes(num) {
    const bytes = new Uint8Array(8);
    let value = Math.max(0, Math.floor(num));
    for (let i = 7; i >= 0; i--) {
      bytes[i] = value % 256;
      value = Math.floor(value / 256);
    }
    return bytes;
  }

  /**
   * Decode Base32 (RFC 4648), ignoring whitespace and optional padding.
   * @param {string} str - Base32 string
   * @returns {Uint8Array} - Decoded bytes
   */
  base32Decode(str) {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    const normalized = String(str).replace(/=+$/,'').replace(/\s+/g,'').toUpperCase();
    let buffer = 0;
    let bits = 0;
    const output = [];
    for (const char of normalized) {
      const value = alphabet.indexOf(char);
      if (value < 0) throw new Error(`Invalid Base32 character: ${char}`);
      buffer = (buffer << 5) | value;
      bits += 5;
      if (bits >= 8) {
        bits -= 8;
        output.push((buffer >>> bits) & 0xff);
      }
    }
    return new Uint8Array(output);
  }

  /**
   * Verify TOTP code
   * @param {string} secret - Base32 secret
   * @param {string} code - Code to verify
   * @returns {boolean} - Valid
   */
  async verifyTOTP(secret, code) {
    const normalized = String(code || '').trim();
    if (!/^\d{6}$/.test(normalized)) return false;
    const now = Date.now();
    // Allow the standard ±1 time-step drift for small clock differences.
    for (const offset of [-1, 0, 1]) {
      const candidate = await this.generateTOTP(secret, now + offset * this.period * 1000);
      if (candidate === normalized) return true;
    }
    return false;
  }
}

/**
 * Two-Factor Auth Manager
 */
class TwoFactorAuthManager {
  constructor() {
    this.totpGenerator = new TOTPGenerator();
    this.userSecrets = new Map();
    this.backupCodes = new Map();
    this.enabledUsers = new Set();
  }

  /**
   * Initialize 2FA manager
   */
  async init() {
    await this.loadUserSecrets();
    await this.loadBackupCodes();
  }

  /**
   * Load user secrets from storage
   */
  async loadUserSecrets() {
    const secrets = await gAll('2fa_secrets');
    for (const stored of secrets) {
      const secretData = { ...stored };
      if (typeof stored.secret === 'string' && stored.secret.startsWith('st-secure:v1:')) {
        secretData.secret = await window.DataEncryption.manager.unprotectSecret(stored.secret);
      } else if (typeof stored.secret === 'string' && stored.secret) {
        const bridge = window.encryptionKeyBridge;
        if (bridge?.getKey && (await bridge.getKey()).available) {
          const protectedValue = await window.DataEncryption.manager.protectSecret(stored.secret);
          await dPut('2fa_secrets', { ...stored, secret: protectedValue });
        } else {
          console.warn('[TwoFactorAuth] Existing plaintext TOTP seed retained for compatibility: protected storage is unavailable on this platform.');
        }
      }
      this.userSecrets.set(secretData.userId, secretData);
      if (secretData.enabled) this.enabledUsers.add(secretData.userId);
    }
  }

  /**
   * Load backup codes from storage
   */
  async loadBackupCodes() {
    const codes = await gAll('2fa_backup_codes');
    for (const stored of codes) {
      const codeData = { ...stored };
      const legacyCode = this.decodeLegacyBackupCode(stored.code);
      if (legacyCode) {
        codeData.code = await this.hashBackupCode(legacyCode);
        await dPut('2fa_backup_codes', codeData);
      }
      if (!this.backupCodes.has(codeData.userId)) this.backupCodes.set(codeData.userId, []);
      this.backupCodes.get(codeData.userId).push(codeData);
    }
  }

  decodeLegacyBackupCode(encoded) {
    if (typeof encoded !== 'string' || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(encoded)) return null;
    try {
      const decoded = atob(encoded);
      return /^\d{8}$/.test(decoded) && btoa(decoded) === encoded ? decoded : null;
    } catch (_) { return null; }
  }

  /**
   * Setup 2FA for user
   * @param {string} userId - User ID
   * @returns {Promise<object>} - Setup data
   */
  async setup2FA(userId) {
    if (!window.DataEncryption?.manager?.protectSecret) throw new Error('Protected storage is unavailable; cannot enable two-factor authentication safely');
    const secret = this.totpGenerator.generateSecret();
    await window.DataEncryption.manager.protectSecret(secret);
    const backupCodes = this.generateBackupCodes();

    const secretData = {
      userId,
      secret,
      enabled: false,
      createdAt: new Date().toISOString()
    };

    await this.saveSecret(secretData);
    this.userSecrets.set(userId, secretData);

    // Store backup codes
    for (const code of backupCodes) {
      const codeData = {
        userId,
        code: await this.hashBackupCode(code),
        used: false,
        createdAt: new Date().toISOString()
      };
      
      if (!this.backupCodes.has(userId)) {
        this.backupCodes.set(userId, []);
      }
      this.backupCodes.get(userId).push(codeData);
      await this.saveBackupCode(codeData);
    }

    return {
      secret,
      backupCodes,
      qrCodeUrl: this.generateQRCodeUrl(secret, userId)
    };
  }

  /**
   * Generate backup codes
   * @returns {Array} - Backup codes
   */
  generateBackupCodes() {
    const codes = [];
    const values = new Uint32Array(10);
    crypto.getRandomValues(values);
    for (const value of values) {
      codes.push(String(10000000 + (value % 90000000)).padStart(8, '0'));
    }
    return codes;
  }

  /**
   * Hash backup code
   * @param {string} code - Plain code
   * @returns {string} - Hashed code
   */
  async hashBackupCode(code, salt = null) {
    const saltBytes = salt || crypto.getRandomValues(new Uint8Array(16));
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(String(code)), 'PBKDF2', false, ['deriveBits']);
    const digest = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: saltBytes, iterations: 120000 }, key, 256);
    return `pbkdf2-sha256$120000$${this.arrayBufferToBase64(saltBytes)}$${this.arrayBufferToBase64(digest)}`;
  }

  async verifyBackupCode(code, encodedHash) {
    const parts = String(encodedHash || '').split('$');
    if (parts.length !== 4 || parts[0] !== 'pbkdf2-sha256' || parts[1] !== '120000') return false;
    let salt;
    try { salt = new Uint8Array(this.base64ToArrayBuffer(parts[2])); } catch (_) { return false; }
    if (salt.length !== 16) return false;
    const computed = await this.hashBackupCode(code, salt);
    const actual = computed.slice(computed.lastIndexOf('$') + 1);
    const expected = parts[3];
    if (actual.length !== expected.length) return false;
    let difference = 0;
    for (let i = 0; i < actual.length; i++) difference |= actual.charCodeAt(i) ^ expected.charCodeAt(i);
    return difference === 0;
  }

  arrayBufferToBase64(value) {
    const bytes = new Uint8Array(value);
    let binary = '';
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary);
  }

  base64ToArrayBuffer(value) {
    const binary = atob(value);
    return Uint8Array.from(binary, character => character.charCodeAt(0)).buffer;
  }

  /**
   * Generate QR code URL
   * @param {string} secret - TOTP secret
   * @param {string} userId - User ID
   * @returns {string} - QR code URL
   */
  generateQRCodeUrl(secret, userId) {
    const issuer = encodeURIComponent('StoreTrack Pro');
    const account = encodeURIComponent(userId);
    return `otpauth://totp/${issuer}:${account}?secret=${secret}&issuer=${issuer}`;
  }

  /**
   * Verify and enable 2FA
   * @param {string} userId - User ID
   * @param {string} code - Verification code
   * @returns {Promise<boolean>} - Success
   */
  async verifyAndEnable(userId, code) {
    const secretData = this.userSecrets.get(userId);
    if (!secretData) {
      return false;
    }

    const isValid = await this.totpGenerator.verifyTOTP(secretData.secret, code);
    
    if (isValid) {
      secretData.enabled = true;
      secretData.enabledAt = new Date().toISOString();
      this.enabledUsers.add(userId);
      await this.saveSecret(secretData);
      
      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('2fa_enabled', 'auth', userId);
      }
    }

    return isValid;
  }

  /**
   * Verify 2FA code during login
   * @param {string} userId - User ID
   * @param {string} code - Verification code
   * @returns {Promise<boolean>} - Valid
   */
  async verifyCode(userId, code) {
    // Check if 2FA is enabled for user
    if (!this.enabledUsers.has(userId)) {
      return true; // 2FA not required
    }

    const secretData = this.userSecrets.get(userId);
    if (!secretData || !secretData.enabled) {
      return false;
    }

    // Try TOTP first
    if (await this.totpGenerator.verifyTOTP(secretData.secret, code)) {
      return true;
    }

    // Try backup codes
    const userBackupCodes = this.backupCodes.get(userId) || [];
    for (const backupCode of userBackupCodes) {
      if (!backupCode.used && await this.verifyBackupCode(code, backupCode.code)) {
        backupCode.used = true;
        backupCode.usedAt = new Date().toISOString();
        await this.saveBackupCode(backupCode);
        return true;
      }
    }

    return false;
  }

  /**
   * Disable 2FA for user
   * @param {string} userId - User ID
   * @param {string} password - User password (for verification)
   * @returns {Promise<boolean>} - Success
   */
  async disable2FA(userId, password) {
    if (typeof password !== 'string' || password.length === 0) {
      return false;
    }

    const users = await gAll('users');
    const user = users.find(candidate => candidate.id === userId || candidate.username === userId);
    if (!user) {
      return false;
    }

    let passwordValid = false;
    if (user.passwordHash && typeof verifyPassword === 'function') {
      passwordValid = await verifyPassword(password, user.passwordHash);
    } else if (typeof user.password === 'string') {
      passwordValid = password === user.password;
    }
    if (!passwordValid) {
      return false;
    }

    const secretData = this.userSecrets.get(userId);
    if (secretData) {
      secretData.enabled = false;
      secretData.disabledAt = new Date().toISOString();
      this.enabledUsers.delete(userId);
      await this.saveSecret(secretData);
      
      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('2fa_disabled', 'auth', userId);
      }
      
      return true;
    }

    return false;
  }

  /**
   * Check if 2FA is enabled for user
   * @param {string} userId - User ID
   * @returns {boolean} - Enabled
   */
  is2FAEnabled(userId) {
    return this.enabledUsers.has(userId);
  }

  /**
   * Generate new backup codes
   * @param {string} userId - User ID
   * @returns {Promise<Array>} - New backup codes
   */
  async regenerateBackupCodes(userId) {
    // Delete old codes
    const oldCodes = this.backupCodes.get(userId) || [];
    for (const code of oldCodes) {
      await dDel('2fa_backup_codes', code.id);
    }
    
    this.backupCodes.delete(userId);
    
    // Generate new codes
    const newCodes = this.generateBackupCodes();
    for (const code of newCodes) {
      const codeData = {
        userId,
        code: await this.hashBackupCode(code),
        used: false,
        createdAt: new Date().toISOString()
      };
      
      if (!this.backupCodes.has(userId)) {
        this.backupCodes.set(userId, []);
      }
      this.backupCodes.get(userId).push(codeData);
      await this.saveBackupCode(codeData);
    }
    
    return newCodes;
  }

  /**
   * Get remaining backup codes count
   * @param {string} userId - User ID
   * @returns {number} - Remaining codes
   */
  getRemainingBackupCodes(userId) {
    const codes = this.backupCodes.get(userId) || [];
    return codes.filter(c => !c.used).length;
  }

  /**
   * Save secret to storage
   * @param {object} secretData - Secret data
   */
  async saveSecret(secretData) {
    const protectedSecret = await window.DataEncryption.manager.protectSecret(secretData.secret);
    await dPut('2fa_secrets', { ...secretData, secret: protectedSecret });
  }

  /**
   * Save backup code to storage
   * @param {object} codeData - Code data
   */
  async saveBackupCode(codeData) {
    await dPut('2fa_backup_codes', codeData);
  }

  /**
   * Get 2FA status for user
   * @param {string} userId - User ID
   * @returns {object} - 2FA status
   */
  getUser2FAStatus(userId) {
    const secretData = this.userSecrets.get(userId);
    const backupCodesCount = this.getRemainingBackupCodes(userId);

    return {
      enabled: this.enabledUsers.has(userId),
      enabledAt: secretData?.enabledAt || null,
      backupCodesRemaining: backupCodesCount,
      requiresRecovery: backupCodesCount < 3
    };
  }
}

/**
 * Global 2FA manager instance
 */
const twoFactorAuthManager = new TwoFactorAuthManager();

/**
 * Initialize 2FA
 */
async function initTwoFactorAuth() {
  await twoFactorAuthManager.init();
  return twoFactorAuthManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.TwoFactorAuth = {
    manager: twoFactorAuthManager,
    init: initTwoFactorAuth,
    setup: (userId) => twoFactorAuthManager.setup2FA(userId),
    verifyAndEnable: (userId, code) => twoFactorAuthManager.verifyAndEnable(userId, code),
    verifyCode: (userId, code) => twoFactorAuthManager.verifyCode(userId, code),
    disable: (userId, password) => twoFactorAuthManager.disable2FA(userId, password),
    isEnabled: (userId) => twoFactorAuthManager.is2FAEnabled(userId),
    regenerateBackupCodes: (userId) => twoFactorAuthManager.regenerateBackupCodes(userId),
    getStatus: (userId) => twoFactorAuthManager.getUser2FAStatus(userId)
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { TOTPGenerator, TwoFactorAuthManager, twoFactorAuthManager };
}
