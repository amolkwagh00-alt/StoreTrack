// Notification Preferences Module - User notification settings management

/**
 * Notification Preference class
 */
class NotificationPreference {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.userId = config.userId || '';
    this.channel = config.channel || 'in-app'; // in-app, email, push, sms
    this.category = config.category || 'general'; // general, inventory, reports, system, security
    this.eventType = config.eventType || ''; // material.created, transaction.completed, etc.
    this.enabled = config.enabled !== false;
    this.frequency = config.frequency || 'immediate'; // immediate, hourly, daily, weekly
    this.conditions = config.conditions || [];
    this.quietHours = config.quietHours || null; // { start: '22:00', end: '08:00' }
    this.createdAt = config.createdAt || new Date().toISOString();
    this.updatedAt = config.updatedAt || new Date().toISOString();
  }

  generateId() {
    return `notif-pref-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Check if should notify now
   * @returns {boolean} - Should notify
   */
  shouldNotifyNow() {
    if (!this.enabled) {return false;}

    // Check quiet hours
    if (this.quietHours) {
      const now = new Date();
      const currentTime = now.getHours() * 60 + now.getMinutes();
      
      const [startHour, startMin] = this.quietHours.start.split(':').map(Number);
      const [endHour, endMin] = this.quietHours.end.split(':').map(Number);
      
      const startTime = startHour * 60 + startMin;
      const endTime = endHour * 60 + endMin;

      if (startTime <= endTime) {
        // Same day range (e.g., 22:00 to 08:00 doesn't make sense, should be 22:00 to 08:00 next day)
        if (currentTime >= startTime && currentTime <= endTime) {
          return false;
        }
      } else {
        // Overnight range (e.g., 22:00 to 08:00)
        if (currentTime >= startTime || currentTime <= endTime) {
          return false;
        }
      }
    }

    return true;
  }
}

/**
 * Notification Template class
 */
class NotificationTemplate {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.eventType = config.eventType || '';
    this.subject = config.subject || '';
    this.body = config.body || '';
    this.variables = config.variables || []; // Array of variable names
    this.channels = config.channels || ['in-app']; // Supported channels
    this.priority = config.priority || 'normal'; // low, normal, high, urgent
    this.category = config.category || 'general';
    this.isDefault = config.isDefault || false;
    this.createdAt = config.createdAt || new Date().toISOString();
    this.updatedAt = config.updatedAt || new Date().toISOString();
  }

  generateId() {
    return `notif-template-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Render template with variables
   * @param {object} variables - Variable values
   * @returns {object} - Rendered template
   */
  render(variables) {
    let subject = this.subject;
    let body = this.body;

    // Replace variables in format {{variableName}}
    for (const [key, value] of Object.entries(variables)) {
      const pattern = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
      subject = subject.replace(pattern, value);
      body = body.replace(pattern, value);
    }

    return { subject, body };
  }
}

/**
 * Notification Preferences Manager
 */
class NotificationPreferencesManager {
  constructor() {
    this.preferences = new Map();
    this.templates = new Map();
    this.ready = this.init();
  }

  /**
   * Initialize notification preferences manager
   */
  async init() {
    await this.loadPreferences();
    await this.loadTemplates();
    await this.initializeDefaultTemplates();
  }

  /**
   * Load preferences from storage
   */
  async loadPreferences() {
    try {
      const preferences = await gAll('notification_preferences');
      preferences.forEach(p => {
        this.preferences.set(p.id, new NotificationPreference(p));
      });
    } catch (err) {
      console.error('Failed to load notification preferences:', err);
    }
  }

  /**
   * Load templates from storage
   */
  async loadTemplates() {
    try {
      const templates = await gAll('notification_templates');
      templates.forEach(t => {
        this.templates.set(t.id, new NotificationTemplate(t));
      });
    } catch (err) {
      console.error('Failed to load notification templates:', err);
    }
  }

  /**
   * Initialize default templates
   */
  async initializeDefaultTemplates() {
    const defaultTemplates = [
      {
        eventType: 'material.created',
        subject: 'New Material Created: {{name}}',
        body: 'A new material has been created:\n\nName: {{name}}\nSKU: {{sku}}\nCategory: {{category}}\n\nCreated by: {{createdBy}}',
        variables: ['name', 'sku', 'category', 'createdBy'],
        channels: ['in-app', 'email'],
        priority: 'normal',
        category: 'inventory',
        isDefault: true
      },
      {
        eventType: 'material.low_stock',
        subject: 'Low Stock Alert: {{name}}',
        body: 'Material {{name}} is running low on stock.\n\nCurrent Stock: {{currentStock}}\nMinimum Stock: {{minStock}}\n\nPlease reorder soon.',
        variables: ['name', 'currentStock', 'minStock'],
        channels: ['in-app', 'email', 'push'],
        priority: 'high',
        category: 'inventory',
        isDefault: true
      },
      {
        eventType: 'transaction.completed',
        subject: 'Transaction Completed: {{type}}',
        body: 'A {{type}} transaction has been completed.\n\nMaterial: {{materialName}}\nQuantity: {{quantity}}\nUser: {{userName}}\nTime: {{timestamp}}',
        variables: ['type', 'materialName', 'quantity', 'userName', 'timestamp'],
        channels: ['in-app'],
        priority: 'normal',
        category: 'inventory',
        isDefault: true
      },
      {
        eventType: 'report.generated',
        subject: 'Report Generated: {{reportName}}',
        body: 'Your report "{{reportName}}" has been generated and is ready for viewing.\n\nGenerated at: {{timestamp}}',
        variables: ['reportName', 'timestamp'],
        channels: ['in-app', 'email'],
        priority: 'normal',
        category: 'reports',
        isDefault: true
      },
      {
        eventType: 'system.maintenance',
        subject: 'System Maintenance Scheduled',
        body: 'System maintenance has been scheduled.\n\nStart Time: {{startTime}}\nEnd Time: {{endTime}}\n\nPlease save your work before this time.',
        variables: ['startTime', 'endTime'],
        channels: ['in-app', 'email'],
        priority: 'high',
        category: 'system',
        isDefault: true
      },
      {
        eventType: 'security.login_failed',
        subject: 'Failed Login Attempt Detected',
        body: 'Multiple failed login attempts have been detected for your account.\n\nIP Address: {{ipAddress}}\nAttempts: {{attempts}}\n\nIf this was not you, please change your password immediately.',
        variables: ['ipAddress', 'attempts'],
        channels: ['in-app', 'email', 'push'],
        priority: 'urgent',
        category: 'security',
        isDefault: true
      }
    ];

    for (const template of defaultTemplates) {
      const existing = Array.from(this.templates.values())
        .find(t => t.eventType === template.eventType && t.isDefault);
      
      if (!existing) {
        await this.createTemplate(template);
      }
    }
  }

  /**
   * Create preference
   * @param {object} config - Preference configuration
   * @returns {NotificationPreference} - Created preference
   */
  async createPreference(config) {
    const preference = new NotificationPreference(config);
    this.preferences.set(preference.id, preference);
    await this.savePreference(preference);
    return preference;
  }

  /**
   * Update preference
   * @param {string} id - Preference ID
   * @param {object} updates - Updates to apply
   * @returns {NotificationPreference} - Updated preference
   */
  async updatePreference(id, updates) {
    const preference = this.preferences.get(id);
    if (preference) {
      Object.assign(preference, updates);
      preference.updatedAt = new Date().toISOString();
      await this.savePreference(preference);
    }
    return preference;
  }

  /**
   * Delete preference
   * @param {string} id - Preference ID
   */
  async deletePreference(id) {
    this.preferences.delete(id);
    await dDel('notification_preferences', id);
  }

  /**
   * Save preference to storage
   * @param {NotificationPreference} preference - Preference to save
   */
  async savePreference(preference) {
    try {
      await dPut('notification_preferences', preference);
    } catch (err) {
      console.error('Failed to save notification preference:', err);
      throw err;
    }
  }

  /**
   * Create template
   * @param {object} config - Template configuration
   * @returns {NotificationTemplate} - Created template
   */
  async createTemplate(config) {
    const template = new NotificationTemplate(config);
    this.templates.set(template.id, template);
    await this.saveTemplate(template);
    return template;
  }

  /**
   * Update template
   * @param {string} id - Template ID
   * @param {object} updates - Updates to apply
   * @returns {NotificationTemplate} - Updated template
   */
  async updateTemplate(id, updates) {
    const template = this.templates.get(id);
    if (template) {
      Object.assign(template, updates);
      template.updatedAt = new Date().toISOString();
      await this.saveTemplate(template);
    }
    return template;
  }

  /**
   * Delete template
   * @param {string} id - Template ID
   */
  async deleteTemplate(id) {
    const template = this.templates.get(id);
    if (template) {
      if (template.isDefault) {
        throw new Error('Cannot delete default template');
      }
      this.templates.delete(id);
      await dDel('notification_templates', id);
    }
  }

  /**
   * Save template to storage
   * @param {NotificationTemplate} template - Template to save
   */
  async saveTemplate(template) {
    try {
      await dPut('notification_templates', template);
    } catch (err) {
      console.error('Failed to save notification template:', err);
    }
  }

  /**
   * Get preferences for user
   * @param {string} userId - User ID
   * @returns {Array} - User preferences
   */
  getPreferencesForUser(userId) {
    return Array.from(this.preferences.values())
      .filter(p => p.userId === userId);
  }

  /**
   * Get preferences for event
   * @param {string} eventType - Event type
   * @returns {Array} - Preferences
   */
  getPreferencesForEvent(eventType) {
    return Array.from(this.preferences.values())
      .filter(p => p.eventType === eventType);
  }

  /**
   * Get preferences for user and event
   * @param {string} userId - User ID
   * @param {string} eventType - Event type
   * @returns {Array} - Preferences
   */
  getPreferencesForUserAndEvent(userId, eventType) {
    return Array.from(this.preferences.values())
      .filter(p => p.userId === userId && p.eventType === eventType);
  }

  /**
   * Get enabled preferences for user
   * @param {string} userId - User ID
   * @returns {Array} - Enabled preferences
   */
  getEnabledPreferencesForUser(userId) {
    return this.getPreferencesForUser(userId).filter(p => p.enabled);
  }

  /**
   * Get preferences by channel
   * @param {string} channel - Channel
   * @returns {Array} - Preferences
   */
  getPreferencesByChannel(channel) {
    return Array.from(this.preferences.values())
      .filter(p => p.channel === channel);
  }

  /**
   * Get preferences by category
   * @param {string} category - Category
   * @returns {Array} - Preferences
   */
  getPreferencesByCategory(category) {
    return Array.from(this.preferences.values())
      .filter(p => p.category === category);
  }

  /**
   * Get template for event
   * @param {string} eventType - Event type
   * @returns {NotificationTemplate} - Template
   */
  getTemplateForEvent(eventType) {
    return Array.from(this.templates.values())
      .find(t => t.eventType === eventType);
  }

  /**
   * Get template
   * @param {string} id - Template ID
   * @returns {NotificationTemplate} - Template
   */
  getTemplate(id) {
    return this.templates.get(id);
  }

  /**
   * Get all templates
   * @returns {Array} - Array of templates
   */
  getAllTemplates() {
    return Array.from(this.templates.values());
  }

  /**
   * Get default templates
   * @returns {Array} - Default templates
   */
  getDefaultTemplates() {
    return this.getAllTemplates().filter(t => t.isDefault);
  }

  /**
   * Get custom templates
   * @returns {Array} - Custom templates
   */
  getCustomTemplates() {
    return this.getAllTemplates().filter(t => !t.isDefault);
  }

  /**
   * Set user notification preference
   * @param {string} userId - User ID
   * @param {string} channel - Channel
   * @param {string} eventType - Event type
   * @param {boolean} enabled - Enabled
   * @param {object} options - Additional options
   * @returns {NotificationPreference} - Set preference
   */
  async setUserNotificationPreference(userId, channel, eventType, enabled, options = {}) {
    const existing = Array.from(this.preferences.values())
      .find(p => p.userId === userId && p.channel === channel && p.eventType === eventType);

    if (existing) {
      return await this.updatePreference(existing.id, { enabled, ...options });
    }

    return await this.createPreference({
      userId,
      channel,
      eventType,
      enabled,
      ...options
    });
  }

  /**
   * Enable all notifications for user
   * @param {string} userId - User ID
   * @param {string} channel - Channel
   */
  async enableAllNotificationsForUser(userId, channel = 'in-app') {
    const templates = this.getAllTemplates();
    const enabled = [];

    for (const template of templates) {
      try {
        const pref = await this.setUserNotificationPreference(userId, channel, template.eventType, true);
        enabled.push(pref);
      } catch (err) {
        console.error(`Failed to enable notification for ${template.eventType}:`, err);
      }
    }

    return enabled;
  }

  /**
   * Disable all notifications for user
   * @param {string} userId - User ID
   * @param {string} channel - Channel
   */
  async disableAllNotificationsForUser(userId, channel = 'in-app') {
    const userPrefs = this.getPreferencesForUser(userId).filter(p => p.channel === channel);
    const disabled = [];

    for (const pref of userPrefs) {
      try {
        const updated = await this.updatePreference(pref.id, { enabled: false });
        disabled.push(updated);
      } catch (err) {
        console.error(`Failed to disable notification ${pref.id}:`, err);
      }
    }

    return disabled;
  }

  /**
   * Delete all preferences for user
   * @param {string} userId - User ID
   */
  async deleteAllPreferencesForUser(userId) {
    const userPrefs = this.getPreferencesForUser(userId);
    
    for (const pref of userPrefs) {
      this.preferences.delete(pref.id);
      await dDel('notification_preferences', pref.id);
    }
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const preferences = Array.from(this.preferences.values());
    const templates = this.getAllTemplates();

    return {
      totalPreferences: preferences.length,
      enabledPreferences: preferences.filter(p => p.enabled).length,
      byChannel: this.getChannelCounts(preferences),
      byCategory: this.getCategoryCounts(preferences),
      totalTemplates: templates.length,
      defaultTemplates: templates.filter(t => t.isDefault).length,
      customTemplates: templates.filter(t => !t.isDefault).length
    };
  }

  /**
   * Get channel counts
   * @param {Array} preferences - Preferences
   * @returns {object} - Channel counts
   */
  getChannelCounts(preferences) {
    const counts = {};
    preferences.forEach(p => {
      counts[p.channel] = (counts[p.channel] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get category counts
   * @param {Array} preferences - Preferences
   * @returns {object} - Category counts
   */
  getCategoryCounts(preferences) {
    const counts = {};
    preferences.forEach(p => {
      counts[p.category] = (counts[p.category] || 0) + 1;
    });
    return counts;
  }
}

/**
 * Global notification preferences manager instance
 */
const notificationPreferencesManager = new NotificationPreferencesManager();

/**
 * Initialize notification preferences
 */
async function initNotificationPreferences() {
  await notificationPreferencesManager.ready;
  return notificationPreferencesManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.NotificationPreferences = {
    manager: notificationPreferencesManager,
    init: initNotificationPreferences,
    createPreference: (config) => notificationPreferencesManager.createPreference(config),
    updatePreference: (id, updates) => notificationPreferencesManager.updatePreference(id, updates),
    deletePreference: (id) => notificationPreferencesManager.deletePreference(id),
    createTemplate: (config) => notificationPreferencesManager.createTemplate(config),
    updateTemplate: (id, updates) => notificationPreferencesManager.updateTemplate(id, updates),
    deleteTemplate: (id) => notificationPreferencesManager.deleteTemplate(id),
    getPreferencesForUser: (userId) => notificationPreferencesManager.getPreferencesForUser(userId),
    getPreferencesForEvent: (eventType) => notificationPreferencesManager.getPreferencesForEvent(eventType),
    getPreferencesForUserAndEvent: (userId, eventType) => notificationPreferencesManager.getPreferencesForUserAndEvent(userId, eventType),
    getEnabledPreferencesForUser: (userId) => notificationPreferencesManager.getEnabledPreferencesForUser(userId),
    getPreferencesByChannel: (channel) => notificationPreferencesManager.getPreferencesByChannel(channel),
    getPreferencesByCategory: (category) => notificationPreferencesManager.getPreferencesByCategory(category),
    getTemplateForEvent: (eventType) => notificationPreferencesManager.getTemplateForEvent(eventType),
    getTemplate: (id) => notificationPreferencesManager.getTemplate(id),
    getAllTemplates: () => notificationPreferencesManager.getAllTemplates(),
    getDefaultTemplates: () => notificationPreferencesManager.getDefaultTemplates(),
    getCustomTemplates: () => notificationPreferencesManager.getCustomTemplates(),
    setUserNotificationPreference: (userId, channel, eventType, enabled, options) => notificationPreferencesManager.setUserNotificationPreference(userId, channel, eventType, enabled, options),
    enableAllNotificationsForUser: (userId, channel) => notificationPreferencesManager.enableAllNotificationsForUser(userId, channel),
    disableAllNotificationsForUser: (userId, channel) => notificationPreferencesManager.disableAllNotificationsForUser(userId, channel),
    deleteAllPreferencesForUser: (userId) => notificationPreferencesManager.deleteAllPreferencesForUser(userId),
    getStats: () => notificationPreferencesManager.getStatistics()
  };
}
