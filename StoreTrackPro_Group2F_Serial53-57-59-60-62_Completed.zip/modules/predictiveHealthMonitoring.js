/**
 * Predictive Health Monitoring Module
 * Monitors system health and predicts potential issues
 */

class PredictiveHealthMonitoring {
  constructor() {
    this.healthMetrics = new Map();
    this.baselines = new Map();
    this.alerts = [];
    this.predictions = new Map();
    this.config = {
      baselineWindow: 100, // Number of samples for baseline
      alertThreshold: 2, // Standard deviations from baseline
      predictionHorizon: 24, // Hours to predict ahead
      checkInterval: 60000, // Check every minute
      maxAlerts: 1000
    };
    this.checkTimer = null;
  }

  /**
   * Initialize health monitoring
   * @param {Object} config - Configuration options
   */
  initialize(config = {}) {
    this.config = { ...this.config, ...config };
    this.startMonitoring();
  }

  /**
   * Start health monitoring
   */
  startMonitoring() {
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
    }
    
    this.checkTimer = setInterval(() => {
      this.performHealthCheck();
    }, this.config.checkInterval);
  }

  /**
   * Stop health monitoring
   */
  stopMonitoring() {
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
      this.checkTimer = null;
    }
  }

  /**
   * Record health metric
   * @param {string} metricName - Metric name
   * @param {number} value - Metric value
   * @param {Object} metadata - Additional metadata
   */
  recordMetric(metricName, value, metadata = {}) {
    const metric = this.healthMetrics.get(metricName) || {
      name: metricName,
      values: [],
      metadata: {}
    };
    
    metric.values.push({
      value,
      timestamp: Date.now(),
      ...metadata
    });
    
    // Keep only baseline window + buffer
    if (metric.values.length > this.config.baselineWindow * 2) {
      metric.values = metric.values.slice(-this.config.baselineWindow * 2);
    }
    
    metric.metadata = { ...metric.metadata, ...metadata };
    this.healthMetrics.set(metricName, metric);
    
    // Update baseline if we have enough data
    if (metric.values.length >= this.config.baselineWindow) {
      this.updateBaseline(metricName);
    }
  }

  /**
   * Update baseline for a metric
   * @param {string} metricName - Metric name
   */
  updateBaseline(metricName) {
    const metric = this.healthMetrics.get(metricName);
    if (!metric || metric.values.length < this.config.baselineWindow) {return;}
    
    const baselineValues = metric.values.slice(-this.config.baselineWindow).map(v => v.value);
    const mean = baselineValues.reduce((sum, v) => sum + v, 0) / baselineValues.length;
    const variance = baselineValues.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / baselineValues.length;
    const stdDev = Math.sqrt(variance);
    
    const sorted = [...baselineValues].sort((a, b) => a - b);
    const p50 = sorted[Math.floor(sorted.length * 0.5)];
    const p95 = sorted[Math.floor(sorted.length * 0.95)];
    const p99 = sorted[Math.floor(sorted.length * 0.99)];
    
    this.baselines.set(metricName, {
      mean,
      stdDev,
      min: sorted[0],
      max: sorted[sorted.length - 1],
      p50,
      p95,
      p99,
      sampleCount: baselineValues.length,
      lastUpdated: Date.now()
    });
  }

  /**
   * Perform health check
   */
  performHealthCheck() {
    for (const [metricName, metric] of this.healthMetrics) {
      const baseline = this.baselines.get(metricName);
      if (!baseline) {continue;}
      
      const latestValue = metric.values[metric.values.length - 1].value;
      const zScore = baseline.stdDev > 0 
        ? Math.abs((latestValue - baseline.mean) / baseline.stdDev)
        : 0;
      
      // Check for anomalies
      if (zScore > this.config.alertThreshold) {
        this.createAlert(metricName, latestValue, zScore, baseline);
      }
      
      // Generate prediction
      this.generatePrediction(metricName, metric.values);
    }
  }

  /**
   * Create health alert
   * @param {string} metricName - Metric name
   * @param {number} value - Current value
   * @param {number} zScore - Z-score
   * @param {Object} baseline - Baseline data
   */
  createAlert(metricName, value, zScore, baseline) {
    const alert = {
      id: this.generateAlertId(),
      metricName,
      value,
      baseline: baseline.mean,
      zScore,
      severity: zScore > 4 ? 'critical' : zScore > 3 ? 'warning' : 'info',
      timestamp: Date.now(),
      acknowledged: false
    };
    
    this.alerts.push(alert);
    
    // Keep only max alerts
    if (this.alerts.length > this.config.maxAlerts) {
      this.alerts = this.alerts.slice(-this.config.maxAlerts);
    }
  }

  /**
   * Generate prediction for metric
   * @param {string} metricName - Metric name
   * @param {Array} values - Historical values
   */
  generatePrediction(metricName, values) {
    if (values.length < 10) {return;}
    
    // Simple linear regression prediction
    const recentValues = values.slice(-20).map(v => v.value);
    const n = recentValues.length;
    
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    
    recentValues.forEach((y, x) => {
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumX2 += x * x;
    });
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    
    // Predict future values
    const predictions = [];
    for (let i = 1; i <= this.config.predictionHorizon; i++) {
      const predictedValue = slope * (n + i) + intercept;
      predictions.push({
        hour: i,
        value: predictedValue,
        timestamp: Date.now() + i * 60 * 60 * 1000
      });
    }
    
    this.predictions.set(metricName, {
      slope,
      intercept,
      predictions,
      generatedAt: Date.now()
    });
  }

  /**
   * Get health status
   */
  getHealthStatus() {
    const metrics = {};
    
    for (const [name, metric] of this.healthMetrics) {
      const baseline = this.baselines.get(name);
      const latestValue = metric.values[metric.values.length - 1];
      
      let status = 'healthy';
      let zScore = 0;
      
      if (baseline) {
        zScore = baseline.stdDev > 0 
          ? Math.abs((latestValue.value - baseline.mean) / baseline.stdDev)
          : 0;
        
        if (zScore > 4) {status = 'critical';}
        else if (zScore > 3) {status = 'warning';}
        else if (zScore > 2) {status = 'degraded';}
      }
      
      metrics[name] = {
        currentValue: latestValue.value,
        timestamp: latestValue.timestamp,
        status,
        zScore,
        baseline: baseline ? baseline.mean : null,
        trend: this.calculateTrend(metric.values)
      };
    }
    
    // Overall health
    const statuses = Object.values(metrics).map(m => m.status);
    let overallStatus = 'healthy';
    
    if (statuses.includes('critical')) {overallStatus = 'critical';}
    else if (statuses.includes('warning')) {overallStatus = 'warning';}
    else if (statuses.includes('degraded')) {overallStatus = 'degraded';}
    
    return {
      overallStatus,
      metrics,
      timestamp: Date.now()
    };
  }

  /**
   * Calculate trend for metric
   * @param {Array} values - Metric values
   */
  calculateTrend(values) {
    if (values.length < 2) {return 'stable';}
    
    const recent = values.slice(-10);
    const first = recent[0].value;
    const last = recent[recent.length - 1].value;
    const change = ((last - first) / first) * 100;
    
    if (change > 5) {return 'increasing';}
    if (change < -5) {return 'decreasing';}
    return 'stable';
  }

  /**
   * Get alerts
   * @param {Object} filters - Alert filters
   */
  getAlerts(filters = {}) {
    let filtered = [...this.alerts];
    
    if (filters.severity) {
      filtered = filtered.filter(a => a.severity === filters.severity);
    }
    
    if (filters.metricName) {
      filtered = filtered.filter(a => a.metricName === filters.metricName);
    }
    
    if (filters.acknowledged !== undefined) {
      filtered = filtered.filter(a => a.acknowledged === filters.acknowledged);
    }
    
    if (filters.since) {
      filtered = filtered.filter(a => a.timestamp >= filters.since);
    }
    
    return filtered.sort((a, b) => b.timestamp - a.timestamp);
  }

  /**
   * Acknowledge alert
   * @param {string} alertId - Alert ID
   */
  acknowledgeAlert(alertId) {
    const alert = this.alerts.find(a => a.id === alertId);
    if (alert) {
      alert.acknowledged = true;
      alert.acknowledgedAt = Date.now();
    }
  }

  /**
   * Get prediction for metric
   * @param {string} metricName - Metric name
   */
  getPrediction(metricName) {
    return this.predictions.get(metricName);
  }

  /**
   * Get all predictions
   */
  getAllPredictions() {
    return Array.from(this.predictions.entries()).map(([name, prediction]) => ({
      metricName: name,
      ...prediction
    }));
  }

  /**
   * Get baseline for metric
   * @param {string} metricName - Metric name
   */
  getBaseline(metricName) {
    return this.baselines.get(metricName);
  }

  /**
   * Get all baselines
   */
  getAllBaselines() {
    return Array.from(this.baselines.entries()).map(([name, baseline]) => ({
      metricName: name,
      ...baseline
    }));
  }

  /**
   * Generate alert ID
   */
  generateAlertId() {
    return `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Clear alerts
   */
  clearAlerts() {
    this.alerts = [];
  }

  /**
   * Clear old alerts
   * @param {number} olderThan - Timestamp threshold
   */
  clearOldAlerts(olderThan) {
    this.alerts = this.alerts.filter(a => a.timestamp >= olderThan);
  }

  /**
   * Set configuration
   * @param {Object} config - Configuration options
   */
  setConfig(config) {
    this.config = { ...this.config, ...config };
    
    // Restart monitoring if interval changed
    if (config.checkInterval) {
      this.startMonitoring();
    }
  }

  /**
   * Get configuration
   */
  getConfig() {
    return { ...this.config };
  }

  /**
   * Export health data
   */
  exportData() {
    return {
      timestamp: Date.now(),
      healthStatus: this.getHealthStatus(),
      alerts: this.alerts,
      predictions: this.getAllPredictions(),
      baselines: this.getAllBaselines()
    };
  }

  /**
   * Reset all data
   */
  reset() {
    this.healthMetrics.clear();
    this.baselines.clear();
    this.alerts = [];
    this.predictions.clear();
  }
}

// Create singleton instance
const predictiveHealthMonitoring = new PredictiveHealthMonitoring();

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PredictiveHealthMonitoring, predictiveHealthMonitoring };
}
