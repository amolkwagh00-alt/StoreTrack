/**
 * Canvas-based Chart Rendering Module
 * High-performance chart rendering using HTML5 Canvas
 */

class CanvasCharts {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.padding = { top: 40, right: 40, bottom: 60, left: 60 };
    this.colors = {
      primary: '#00AEEF',
      secondary: '#FF8C00',
      success: '#22C55E',
      danger: '#EF4444',
      warning: '#F59E0B',
      grid: '#e5e7eb',
      text: '#374151'
    };
    this.animations = [];
    this.animationFrame = null;
  }

  /**
   * Clear canvas
   */
  clear() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  /**
   * Draw line chart
   * @param {Array} data - Chart data
   * @param {Object} options - Chart options
   */
  drawLineChart(data, options = {}) {
    this.clear();
    
    const { labels, values } = data;
    const chartWidth = this.canvas.width - this.padding.left - this.padding.right;
    const chartHeight = this.canvas.height - this.padding.top - this.padding.bottom;
    
    // Calculate scales
    const maxValue = Math.max(...values) * 1.1;
    const minValue = Math.min(...values) * 0.9;
    const valueRange = maxValue - minValue;
    
    // Draw grid
    this.drawGrid(chartWidth, chartHeight, 5);
    
    // Draw axes
    this.drawAxes(chartWidth, chartHeight);
    
    // Draw line
    this.ctx.beginPath();
    this.ctx.strokeStyle = options.color || this.colors.primary;
    this.ctx.lineWidth = 2;
    
    values.forEach((value, index) => {
      const x = this.padding.left + (index / (values.length - 1)) * chartWidth;
      const y = this.padding.top + chartHeight - ((value - minValue) / valueRange) * chartHeight;
      
      if (index === 0) {
        this.ctx.moveTo(x, y);
      } else {
        this.ctx.lineTo(x, y);
      }
    });
    
    this.ctx.stroke();
    
    // Draw points
    values.forEach((value, index) => {
      const x = this.padding.left + (index / (values.length - 1)) * chartWidth;
      const y = this.padding.top + chartHeight - ((value - minValue) / valueRange) * chartHeight;
      
      this.ctx.beginPath();
      this.ctx.arc(x, y, 4, 0, Math.PI * 2);
      this.ctx.fillStyle = options.color || this.colors.primary;
      this.ctx.fill();
    });
    
    // Draw labels
    this.drawLabels(labels, values, chartWidth, chartHeight, minValue, maxValue);
  }

  /**
   * Draw bar chart
   * @param {Array} data - Chart data
   * @param {Object} options - Chart options
   */
  drawBarChart(data, options = {}) {
    this.clear();
    
    const { labels, values } = data;
    const chartWidth = this.canvas.width - this.padding.left - this.padding.right;
    const chartHeight = this.canvas.height - this.padding.top - this.padding.bottom;
    
    const maxValue = Math.max(...values) * 1.1;
    const barWidth = (chartWidth / values.length) * 0.8;
    const barSpacing = (chartWidth / values.length) * 0.2;
    
    // Draw grid
    this.drawGrid(chartWidth, chartHeight, 5);
    
    // Draw axes
    this.drawAxes(chartWidth, chartHeight);
    
    // Draw bars
    values.forEach((value, index) => {
      const x = this.padding.left + index * (barWidth + barSpacing) + barSpacing / 2;
      const barHeight = (value / maxValue) * chartHeight;
      const y = this.padding.top + chartHeight - barHeight;
      
      // Gradient fill
      const gradient = this.ctx.createLinearGradient(x, y, x, y + barHeight);
      gradient.addColorStop(0, options.color || this.colors.primary);
      gradient.addColorStop(1, this.adjustColor(options.color || this.colors.primary, -30));
      
      this.ctx.fillStyle = gradient;
      this.ctx.fillRect(x, y, barWidth, barHeight);
      
      // Border
      this.ctx.strokeStyle = this.adjustColor(options.color || this.colors.primary, -20);
      this.ctx.lineWidth = 1;
      this.ctx.strokeRect(x, y, barWidth, barHeight);
    });
    
    // Draw labels
    this.drawLabels(labels, values, chartWidth, chartHeight, 0, maxValue);
  }

  /**
   * Draw pie chart
   * @param {Array} data - Chart data
   * @param {Object} options - Chart options
   */
  drawPieChart(data, options = {}) {
    this.clear();
    
    const { labels, values } = data;
    const total = values.reduce((sum, val) => sum + val, 0);
    const centerX = this.canvas.width / 2;
    const centerY = this.canvas.height / 2;
    const radius = Math.min(centerX, centerY) - this.padding.top;
    
    const colors = [
      this.colors.primary,
      this.colors.secondary,
      this.colors.success,
      this.colors.danger,
      this.colors.warning
    ];
    
    let startAngle = -Math.PI / 2;
    
    values.forEach((value, index) => {
      const sliceAngle = (value / total) * Math.PI * 2;
      const endAngle = startAngle + sliceAngle;
      
      // Draw slice
      this.ctx.beginPath();
      this.ctx.moveTo(centerX, centerY);
      this.ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      this.ctx.closePath();
      
      this.ctx.fillStyle = colors[index % colors.length];
      this.ctx.fill();
      
      // Draw border
      this.ctx.strokeStyle = '#fff';
      this.ctx.lineWidth = 2;
      this.ctx.stroke();
      
      // Draw label
      const midAngle = startAngle + sliceAngle / 2;
      const labelX = centerX + Math.cos(midAngle) * (radius * 0.7);
      const labelY = centerY + Math.sin(midAngle) * (radius * 0.7);
      
      this.ctx.fillStyle = '#fff';
      this.ctx.font = '12px Arial';
      this.ctx.textAlign = 'center';
      this.ctx.fillText(`${labels[index]}`, labelX, labelY);
      this.ctx.fillText(`${((value / total) * 100).toFixed(1)}%`, labelX, labelY + 14);
      
      startAngle = endAngle;
    });
  }

  /**
   * Draw area chart
   * @param {Array} data - Chart data
   * @param {Object} options - Chart options
   */
  drawAreaChart(data, options = {}) {
    this.clear();
    
    const { labels, values } = data;
    const chartWidth = this.canvas.width - this.padding.left - this.padding.right;
    const chartHeight = this.canvas.height - this.padding.top - this.padding.bottom;
    
    const maxValue = Math.max(...values) * 1.1;
    const minValue = Math.min(...values) * 0.9;
    const valueRange = maxValue - minValue;
    
    // Draw grid
    this.drawGrid(chartWidth, chartHeight, 5);
    
    // Draw axes
    this.drawAxes(chartWidth, chartHeight);
    
    // Draw area
    this.ctx.beginPath();
    this.ctx.moveTo(this.padding.left, this.padding.top + chartHeight);
    
    values.forEach((value, index) => {
      const x = this.padding.left + (index / (values.length - 1)) * chartWidth;
      const y = this.padding.top + chartHeight - ((value - minValue) / valueRange) * chartHeight;
      this.ctx.lineTo(x, y);
    });
    
    this.ctx.lineTo(this.padding.left + chartWidth, this.padding.top + chartHeight);
    this.ctx.closePath();
    
    // Gradient fill
    const gradient = this.ctx.createLinearGradient(0, this.padding.top, 0, this.padding.top + chartHeight);
    gradient.addColorStop(0, this.adjustColor(options.color || this.colors.primary, 0));
    gradient.addColorStop(1, this.adjustColor(options.color || this.colors.primary, -50));
    
    this.ctx.fillStyle = gradient;
    this.ctx.fill();
    
    // Draw line on top
    this.ctx.beginPath();
    this.ctx.strokeStyle = options.color || this.colors.primary;
    this.ctx.lineWidth = 2;
    
    values.forEach((value, index) => {
      const x = this.padding.left + (index / (values.length - 1)) * chartWidth;
      const y = this.padding.top + chartHeight - ((value - minValue) / valueRange) * chartHeight;
      
      if (index === 0) {
        this.ctx.moveTo(x, y);
      } else {
        this.ctx.lineTo(x, y);
      }
    });
    
    this.ctx.stroke();
    
    // Draw labels
    this.drawLabels(labels, values, chartWidth, chartHeight, minValue, maxValue);
  }

  /**
   * Draw grid lines
   */
  drawGrid(width, height, lines) {
    this.ctx.strokeStyle = this.colors.grid;
    this.ctx.lineWidth = 1;
    
    // Horizontal lines
    for (let i = 0; i <= lines; i++) {
      const y = this.padding.top + (height / lines) * i;
      this.ctx.beginPath();
      this.ctx.moveTo(this.padding.left, y);
      this.ctx.lineTo(this.padding.left + width, y);
      this.ctx.stroke();
    }
  }

  /**
   * Draw axes
   */
  drawAxes(width, height) {
    this.ctx.strokeStyle = this.colors.text;
    this.ctx.lineWidth = 2;
    
    // Y-axis
    this.ctx.beginPath();
    this.ctx.moveTo(this.padding.left, this.padding.top);
    this.ctx.lineTo(this.padding.left, this.padding.top + height);
    this.ctx.stroke();
    
    // X-axis
    this.ctx.beginPath();
    this.ctx.moveTo(this.padding.left, this.padding.top + height);
    this.ctx.lineTo(this.padding.left + width, this.padding.top + height);
    this.ctx.stroke();
  }

  /**
   * Draw labels
   */
  drawLabels(labels, values, width, height, minValue, maxValue) {
    this.ctx.fillStyle = this.colors.text;
    this.ctx.font = '11px Arial';
    
    // X-axis labels
    const labelSpacing = width / labels.length;
    labels.forEach((label, index) => {
      const x = this.padding.left + index * labelSpacing + labelSpacing / 2;
      const y = this.padding.top + height + 20;
      
      this.ctx.textAlign = 'center';
      this.ctx.fillText(label, x, y);
    });
    
    // Y-axis labels
    const valueSpacing = height / 5;
    for (let i = 0; i <= 5; i++) {
      const value = minValue + (maxValue - minValue) * (i / 5);
      const x = this.padding.left - 10;
      const y = this.padding.top + height - (i * valueSpacing);
      
      this.ctx.textAlign = 'right';
      this.ctx.fillText(value.toFixed(0), x, y + 4);
    }
  }

  /**
   * Adjust color brightness
   */
  adjustColor(color, amount) {
    const hex = color.replace('#', '');
    const r = Math.max(0, Math.min(255, parseInt(hex.substr(0, 2), 16) + amount));
    const g = Math.max(0, Math.min(255, parseInt(hex.substr(2, 2), 16) + amount));
    const b = Math.max(0, Math.min(255, parseInt(hex.substr(4, 2), 16) + amount));
    
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  }

  /**
   * Animate chart
   * @param {string} type - Chart type
   * @param {Array} data - Chart data
   * @param {Object} options - Chart options
   */
  animateChart(type, data, options = {}) {
    const duration = options.duration || 1000;
    const startTime = Date.now();
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easedProgress = this.easeOutCubic(progress);
      
      // Interpolate data based on progress
      const interpolatedData = this.interpolateData(data, easedProgress);
      
      switch (type) {
        case 'line':
          this.drawLineChart(interpolatedData, options);
          break;
        case 'bar':
          this.drawBarChart(interpolatedData, options);
          break;
        case 'area':
          this.drawAreaChart(interpolatedData, options);
          break;
      }
      
      if (progress < 1) {
        this.animationFrame = requestAnimationFrame(animate);
      }
    };
    
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
    }
    
    animate();
  }

  /**
   * Interpolate data for animation
   */
  interpolateData(data, progress) {
    return {
      labels: data.labels,
      values: data.values.map(v => v * progress)
    };
  }

  /**
   * Easing function
   */
  easeOutCubic(t) {
    return 1 - Math.pow(1 - t, 3);
  }

  /**
   * Export chart as image
   */
  exportAsImage(format = 'png') {
    return this.canvas.toDataURL(`image/${format}`);
  }

  /**
   * Resize canvas
   */
  resize(width, height) {
    this.canvas.width = width;
    this.canvas.height = height;
  }
}

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { CanvasCharts };
}
