/* StoreTrack truthful BI/AI analytics: read-only, source-backed, no fabricated values. */
(function(){
  'use strict';
  const n=v=>Number.isFinite(Number(v))?Number(v):0;
  const date=r=>r?.time||r?.timestamp||r?.createdAt||r?.updatedAt||r?.date||'';
  const daysSince=v=>{const t=new Date(v).getTime();return Number.isFinite(t)?Math.max(0,Math.floor((Date.now()-t)/86400000)):null;};
  const rows=async s=>{try{return await window.gAll(s);}catch(_){return[];}};
  const confirmed=t=>!['pending','rejected','cancelled','canceled','void'].includes(String(t?.status||'').toLowerCase());
  function abc(items){const total=items.reduce((s,x)=>s+x.value,0);if(!total)return items.map(x=>({...x,class:'UNTRACKED'}));let run=0;return items.slice().sort((a,b)=>b.value-a.value).map(x=>{run+=x.value;return {...x,class:run/total<=.8?'A':run/total<=.95?'B':'C'};});}
  function xyz(items){return items.map(x=>{const vals=x.months||[];if(vals.length<3)return {...x,variability:'NOT_TRACKED'};const mean=vals.reduce((s,v)=>s+v,0)/vals.length;const sd=Math.sqrt(vals.reduce((s,v)=>s+(v-mean)**2,0)/vals.length);const cv=mean?sd/mean:null;return {...x,variability:cv==null?'NOT_TRACKED':cv<=.5?'X':cv<=1?'Y':'Z'};});}
  async function calculate(){
    const [materials,transactions,approvals,adjustments,grn,parts,componentStock,replacements]=await Promise.all(['materials','transactions','approvals','adjustments','grn','component_parts','component_stock','component_replacements'].map(rows));
    const out=transactions.filter(t=>t.type==='OUT'&&confirmed(t)&&Number.isFinite(Number(t.qty)));
    const byItem=new Map();out.forEach(t=>{const k=String(t.itemId??t.barcode??'');const x=byItem.get(k)||{key:k,qty:0,months:{},lastOut:null};x.qty+=n(t.qty);const d=new Date(date(t));if(Number.isFinite(d.getTime())){const month=d.toISOString().slice(0,7);x.months[month]=(x.months[month]||0)+n(t.qty);if(!x.lastOut||d>new Date(x.lastOut))x.lastOut=d.toISOString();}byItem.set(k,x);});
    const inventory=materials.map(m=>{const value=n(m.unitCost)*n(m.stock);const last=transactions.filter(t=>String(t.itemId??t.barcode??'')===String(m.id??m.barcode)).map(date).filter(Boolean).sort().pop();return {id:m.id,name:m.name,barcode:m.barcode,stock:n(m.stock),unitCost:n(m.unitCost),value,lastMovement:last||m.updatedAt||m.createdAt||null,ageDays:daysSince(last||m.updatedAt||m.createdAt)};});
    const classified=xyz(abc(inventory.map(x=>{const b=byItem.get(String(x.id))||byItem.get(String(x.barcode));return {...x,consumption:b?.qty||0,months:b?Object.values(b.months):[]};})));
    const pending=approvals.filter(a=>String(a.status||'').toLowerCase()==='pending').map(a=>({...a,ageDays:daysSince(date(a))}));
    const quality=[];materials.forEach(m=>{if(!m.barcode)quality.push({type:'Missing barcode',record:m.name||m.id});if(!m.unit)quality.push({type:'Missing unit',record:m.name||m.id});if(n(m.stock)<0)quality.push({type:'Negative stock',record:m.name||m.id});});transactions.forEach(t=>{if(!t.user&&!t.userName)quality.push({type:'Transaction without user',record:t.id});if(!date(t))quality.push({type:'Transaction without timestamp',record:t.id});});
    const component=parts.map(p=>{const stock=componentStock.filter(s=>String(s.partNo)===String(p.partNo)).reduce((a,s)=>a+n(s.quantity),0);const reps=replacements.filter(r=>String(r.partNo||r.newPartNo)===String(p.partNo)).reduce((a,r)=>a+n(r.quantity||1),0);return {partNo:p.partNo,stock,replacements:reps};});
    const summary={materials:materials.length,transactions:transactions.length,confirmedOut:out.length,stockValue:inventory.reduce((s,x)=>s+x.value,0),valuationTracked:inventory.some(x=>x.unitCost>0),lowStock:materials.filter(m=>n(m.stock)===0||n(m.stock)<n(m.lowAlert)).length,pendingApprovals:pending.length,qualityIssues:quality.length,staleItems:inventory.filter(x=>x.ageDays!=null&&x.ageDays>=90).length};
    const daily={date:new Date().toISOString().slice(0,10),outQty:out.filter(t=>String(date(t)).slice(0,10)===new Date().toISOString().slice(0,10)).reduce((s,t)=>s+n(t.qty),0),lowStock:summary.lowStock,pendingApprovals:summary.pendingApprovals,qualityIssues:summary.qualityIssues,source:{transactions:out.length,materials:materials.length,approvals:approvals.length}};
    return {summary,inventory:classified,pendingApprovals:pending,quality,component,daily,sourceCounts:{materials:materials.length,transactions:transactions.length,approvals:approvals.length,adjustments:adjustments.length,grn:grn.length,componentParts:parts.length}};
  }
  window.truthfulAnalytics={calculate};
})();
