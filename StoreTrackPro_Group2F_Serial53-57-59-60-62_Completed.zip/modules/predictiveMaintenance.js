/**
 * Predictive Maintenance Module
 * Predicts equipment failure and maintenance needs using historical data
 */

function gammaLanczos(value) {
  const coefficients = [
    676.5203681218851, -1259.1392167224028, 771.3234287776531,
    -176.6150291621406, 12.507343278686905, -0.13857109526572012,
    9.984369578019572e-6, 1.5056327351493116e-7
  ];
  if (value < 0.5) return Math.PI / (Math.sin(Math.PI * value) * gammaLanczos(1 - value));
  const z = value - 1;
  let sum = 0.9999999999998099;
  coefficients.forEach((coefficient, index) => { sum += coefficient / (z + index + 1); });
  const t = z + coefficients.length - 0.5;
  return Math.sqrt(2 * Math.PI) * Math.pow(t, z + 0.5) * Math.exp(-t) * sum;
}

class PredictiveMaintenance {
  constructor() {
    this.equipmentData = new Map();
    this.failureHistory = new Map();
    this.maintenanceSchedule = new Map();
    this.models = {
      weibull: this.weibullAnalysis.bind(this),
      exponential: this.exponentialAnalysis.bind(this),
      regression: this.regressionAnalysis.bind(this)
    };
  }

  /**
   * Register equipment for monitoring
   * @param {string} equipmentId - Equipment identifier
   * @param {Object} equipmentInfo - Equipment details
   */
  registerEquipment(equipmentId, equipmentInfo) {
    this.equipmentData.set(equipmentId, {
      id: equipmentId,
      name: equipmentInfo.name || 'Unknown',
      type: equipmentInfo.type || 'general',
      installDate: equipmentInfo.installDate || new Date(),
      lastMaintenance: equipmentInfo.lastMaintenance || null,
      usageHours: equipmentInfo.usageHours || 0,
      specifications: equipmentInfo.specifications || {},
      status: 'active'
    });
  }

  /**
   * Record equipment usage data
   * @param {string} equipmentId - Equipment identifier
   * @param {Object} usageData - Usage metrics
   */
  recordUsage(equipmentId, usageData) {
    const equipment = this.equipmentData.get(equipmentId);
    if (!equipment) {return;}

    equipment.usageData = equipment.usageData || [];
    equipment.usageData.push({
      timestamp: Date.now(),
      ...usageData
    });

    // Keep only last 1000 data points
    if (equipment.usageData.length > 1000) {
      equipment.usageData = equipment.usageData.slice(-1000);
    }

    // Update total usage hours
    if (usageData.hours) {
      equipment.usageHours += usageData.hours;
    }
  }

  /**
   * Record maintenance event
   * @param {string} equipmentId - Equipment identifier
   * @param {Object} maintenanceData - Maintenance details
   */
  recordMaintenance(equipmentId, maintenanceData) {
    const equipment = this.equipmentData.get(equipmentId);
    if (!equipment) {return;}

    equipment.maintenanceHistory = equipment.maintenanceHistory || [];
    equipment.maintenanceHistory.push({
      timestamp: Date.now(),
      ...maintenanceData
    });

    equipment.lastMaintenance = new Date();
    equipment.status = 'active';
  }

  /**
   * Record failure event
   * @param {string} equipmentId - Equipment identifier
   * @param {Object} failureData - Failure details
   */
  recordFailure(equipmentId, failureData) {
    const equipment = this.equipmentData.get(equipmentId);
    if (!equipment) {return;}

    equipment.failureHistory = equipment.failureHistory || [];
    equipment.failureHistory.push({
      timestamp: Date.now(),
      ...failureData
    });

    equipment.status = 'failed';

    // Update global failure history for pattern analysis
    const typeFailures = this.failureHistory.get(equipment.type) || [];
    typeFailures.push({
      equipmentId,
      timestamp: Date.now(),
      ...failureData
    });
    this.failureHistory.set(equipment.type, typeFailures);
  }

  /**
   * Predict time to failure
   * @param {string} equipmentId - Equipment identifier
   * @param {string} modelType - Prediction model to use
   * @returns {Object} Prediction results
   */
  predictTimeToFailure(equipmentId, modelType = 'weibull') {
    const equipment = this.equipmentData.get(equipmentId);
    if (!equipment) {
      throw new Error('Equipment not found');
    }

    const model = this.models[modelType];
    if (!model) {
      throw new Error(`Unknown model type: ${modelType}`);
    }

    const prediction = model(equipment);
    
    // Schedule maintenance based on prediction
    if (prediction.daysToFailure < 30) {
      this.scheduleMaintenance(equipmentId, {
        priority: prediction.daysToFailure < 7 ? 'critical' : 'high',
        predictedFailure: new Date(Date.now() + prediction.daysToFailure * 24 * 60 * 60 * 1000),
        confidence: prediction.confidence
      });
    }

    return prediction;
  }

  /**
   * Weibull analysis for failure prediction
   */
  weibullAnalysis(equipment) {
    const usageData = equipment.usageData || [];
    const failureHistory = equipment.failureHistory || [];
    
    if (usageData.length < 10) {
      return this.getDefaultPrediction(equipment);
    }

    // Calculate Weibull parameters (simplified)
    const usageHours = usageData.map(d => d.hours || 0);
    const totalUsage = usageHours.reduce((sum, h) => sum + h, 0);
    const avgUsage = totalUsage / usageHours.length;
    
    // Estimate shape and scale parameters
    const shape = Number(this.estimateShapeParameter(failureHistory));
    const scale = Number(this.estimateScaleParameter(equipment, avgUsage));
    if (!Number.isFinite(shape) || shape <= 0 || !Number.isFinite(scale) || scale <= 0 || avgUsage <= 0) {
      return this.getDefaultPrediction(equipment);
    }
    
    // Calculate probability of failure
    const currentAge = equipment.usageHours;
    const survivalProbability = Math.exp(-Math.pow(currentAge / scale, shape));
    const failureProbability = 1 - survivalProbability;
    
    // Estimate days to failure
    const expectedLife = scale * gammaLanczos(1 + 1 / shape);
    const remainingLife = Math.max(0, expectedLife - currentAge);
    const daysToFailure = remainingLife / (avgUsage / 24); // Convert hours to days
    
    return {
      modelType: 'weibull',
      daysToFailure: Math.round(daysToFailure),
      failureProbability: Math.round(failureProbability * 100),
      confidence: this.calculateConfidence(usageData.length, failureHistory.length),
      parameters: { shape, scale },
      recommendedAction: this.getRecommendedAction(daysToFailure, failureProbability)
    };
  }

  /**
   * Exponential distribution analysis
   */
  exponentialAnalysis(equipment) {
    const usageData = equipment.usageData || [];
    const failureHistory = equipment.failureHistory || [];
    
    if (failureHistory.length < 2) {
      return this.getDefaultPrediction(equipment);
    }

    // Calculate failure rate (lambda)
    const failureTimes = failureHistory.map(f => {
      const installTime = new Date(equipment.installDate).getTime();
      return (f.timestamp - installTime) / (1000 * 60 * 60 * 24); // Days
    });
    
    const meanTimeBetweenFailures = failureTimes.reduce((sum, t) => sum + t, 0) / failureTimes.length;
    const failureRate = 1 / meanTimeBetweenFailures;
    
    // Calculate time since last failure
    const lastFailure = failureHistory[failureHistory.length - 1];
    const timeSinceFailure = (Date.now() - lastFailure.timestamp) / (1000 * 60 * 60 * 24);
    
    // Calculate survival probability
    const survivalProbability = Math.exp(-failureRate * timeSinceFailure);
    const failureProbability = 1 - survivalProbability;
    
    // Estimate days to next failure
    const expectedTimeToFailure = 1 / failureRate;
    const daysToFailure = Math.max(0, expectedTimeToFailure - timeSinceFailure);
    
    return {
      modelType: 'exponential',
      daysToFailure: Math.round(daysToFailure),
      failureProbability: Math.round(failureProbability * 100),
      confidence: this.calculateConfidence(usageData.length, failureHistory.length),
      parameters: { failureRate, meanTimeBetweenFailures },
      recommendedAction: this.getRecommendedAction(daysToFailure, failureProbability)
    };
  }

  /**
   * Regression analysis for trend-based prediction
   */
  regressionAnalysis(equipment) {
    const usageData = equipment.usageData || [];
    
    if (usageData.length < 10) {
      return this.getDefaultPrediction(equipment);
    }

    // Extract performance metrics over time
    const performanceData = usageData.map((d, i) => ({
      time: i,
      performance: d.performance || d.efficiency || 100,
      temperature: d.temperature || 25,
      vibration: d.vibration || 0
    }));
    
    // Calculate degradation trend
    const trend = this.calculateDegradationTrend(performanceData);
    
    // Predict when performance will reach critical threshold
    const criticalThreshold = 70; // 70% performance
    const currentPerformance = performanceData[performanceData.length - 1].performance;
    const degradationRate = trend.slope;
    
    if (degradationRate >= 0) {
      // No degradation detected
      return {
        modelType: 'regression',
        daysToFailure: 365,
        failureProbability: 5,
        confidence: this.calculateConfidence(usageData.length, 0),
        parameters: { degradationRate: 0 },
        recommendedAction: 'monitor'
      };
    }
    
    const performanceDropNeeded = currentPerformance - criticalThreshold;
    const timeToCritical = performanceDropNeeded / Math.abs(degradationRate);
    const daysToFailure = Math.round(timeToCritical * (usageData.length / 30)); // Estimate days
    
    return {
      modelType: 'regression',
      daysToFailure: Math.max(1, daysToFailure),
      failureProbability: Math.round((1 - currentPerformance / 100) * 100),
      confidence: this.calculateConfidence(usageData.length, 0),
      parameters: { degradationRate, currentPerformance },
      recommendedAction: this.getRecommendedAction(daysToFailure, (1 - currentPerformance / 100))
    };
  }

  /**
   * Estimate Weibull shape parameter
   */
  estimateShapeParameter(failureHistory) {
    if (failureHistory.length < 2) {return 2.0;} // Default shape parameter
    
    // Simplified shape parameter estimation
    // In production, use maximum likelihood estimation
    return 2.0 + (failureHistory.length * 0.1);
  }

  /**
   * Estimate Weibull scale parameter
   */
  estimateScaleParameter(equipment, avgUsage) {
    const specifications = equipment.specifications || {};
    const expectedLife = specifications.expectedLife || 10000; // Default 10,000 hours
    
    return expectedLife * (1 + (equipment.usageHours / expectedLife) * 0.1);
  }

  /**
   * Calculate confidence level
   */
  calculateConfidence(dataPoints, failureCount) {
    const dataScore = Math.min(100, dataPoints * 2);
    const failureScore = Math.min(100, failureCount * 20);
    return Math.round((dataScore + failureScore) / 2);
  }

  /**
   * Get recommended action
   */
  getRecommendedAction(daysToFailure, failureProbability) {
    if (daysToFailure < 7 || failureProbability > 80) {
      return 'immediate_maintenance';
    } else if (daysToFailure < 30 || failureProbability > 50) {
      return 'schedule_maintenance';
    } else if (daysToFailure < 90 || failureProbability > 30) {
      return 'plan_maintenance';
    } else {
      return 'monitor';
    }
  }

  /**
   * Get default prediction when insufficient data
   */
  getDefaultPrediction(equipment) {
    const specifications = equipment.specifications || {};
    const expectedLife = specifications.expectedLife || 10000;
    const remainingLife = Math.max(0, expectedLife - equipment.usageHours);
    
    return {
      modelType: 'default',
      daysToFailure: Math.round(remainingLife / 24),
      failureProbability: Math.round((equipment.usageHours / expectedLife) * 100),
      confidence: 20,
      parameters: {},
      recommendedAction: 'monitor'
    };
  }

  /**
   * Calculate degradation trend
   */
  calculateDegradationTrend(data) {
    const n = data.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    
    data.forEach((d, i) => {
      sumX += i;
      sumY += d.performance;
      sumXY += i * d.performance;
      sumX2 += i * i;
    });
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    
    return { slope, intercept };
  }

  /**
   * Schedule maintenance
   */
  scheduleMaintenance(equipmentId, schedule) {
    this.maintenanceSchedule.set(equipmentId, {
      equipmentId,
      scheduledDate: schedule.predictedFailure,
      priority: schedule.priority,
      confidence: schedule.confidence,
      status: 'scheduled',
      createdAt: new Date()
    });
  }

  /**
   * Get maintenance schedule
   */
  getMaintenanceSchedule() {
    return Array.from(this.maintenanceSchedule.values());
  }

  /**
   * Get equipment health status
   */
  getEquipmentHealth(equipmentId) {
    const equipment = this.equipmentData.get(equipmentId);
    if (!equipment) {return null;}

    const prediction = this.predictTimeToFailure(equipmentId);
    
    return {
      equipmentId,
      name: equipment.name,
      status: equipment.status,
      usageHours: equipment.usageHours,
      lastMaintenance: equipment.lastMaintenance,
      prediction,
      healthScore: this.calculateHealthScore(prediction)
    };
  }

  /**
   * Calculate health score (0-100)
   */
  calculateHealthScore(prediction) {
    const failureScore = 100 - prediction.failureProbability;
    const timeScore = Math.min(100, prediction.daysToFailure * 2);
    const confidenceScore = prediction.confidence;
    
    return Math.round((failureScore * 0.4 + timeScore * 0.4 + confidenceScore * 0.2));
  }

  /**
   * Get all equipment health
   */
  getAllEquipmentHealth() {
    const health = [];
    for (const equipmentId of this.equipmentData.keys()) {
      health.push(this.getEquipmentHealth(equipmentId));
    }
    return health;
  }
}

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PredictiveMaintenance };
}
