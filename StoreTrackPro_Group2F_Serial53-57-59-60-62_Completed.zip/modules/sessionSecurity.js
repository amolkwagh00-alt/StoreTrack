/**
 * Enterprise Session Security
 * Auto logout, remember me, and session timeout management for StoreTrack Pro
 *
 * FIX (StoreTrack V8 core/ integration): originally `import { SECURITY } from
 * '../core/constants.js'` — ES-module syntax, crashes on plain <script> load.
 * Now reads window.CONST.SECURITY with safe fallbacks (see passwordPolicy.js
 * for the same fix, applied identically here).
 */
const _SESSION_SECURITY_DEFAULTS = {
  SESSION: { TIMEOUT: 30 * 60 * 1000, WARNING_TIME: 60 * 1000, REMEMBER_ME_DAYS: 30 }
};
const SESSION_SECURITY_CFG = (typeof window !== 'undefined' && window.CONST && window.CONST.SECURITY) ? window.CONST.SECURITY : _SESSION_SECURITY_DEFAULTS;

class SessionSecurity {
  constructor() {
    this.sessionTimeout = SESSION_SECURITY_CFG.SESSION.TIMEOUT;
    this.warningTime = SESSION_SECURITY_CFG.SESSION.WARNING_TIME;
    this.rememberMeDays = SESSION_SECURITY_CFG.SESSION.REMEMBER_ME_DAYS;
    
    this.sessionTimer = null;
    this.warningTimer = null;
    this.lastActivity = Date.now();
    this.warningShown = false;
    this.sessionData = null;
    
    this.activityListeners = [];
  }

  /**
   * Initialize session security
   * @param {Object} options - Configuration options
   */
  initialize(options = {}) {
    this.sessionTimeout = options.sessionTimeout || this.sessionTimeout;
    this.warningTime = options.warningTime || this.warningTime;
    this.rememberMeDays = options.rememberMeDays || this.rememberMeDays;
    
    this.setupActivityTracking();
    this.loadSessionData();
  }

  /**
   * Setup activity tracking
   */
  setupActivityTracking() {
    if (typeof window === 'undefined') {return;}

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
    
    events.forEach(event => {
      document.addEventListener(event, () => this.recordActivity(), { passive: true });
    });

    window.addEventListener('focus', () => this.recordActivity());
    window.addEventListener('blur', () => this.recordActivity());
  }

  /**
   * Record user activity
   */
  recordActivity() {
    this.lastActivity = Date.now();
    this.warningShown = false;
    
    if (this.sessionData && this.sessionData.active) {
      this.resetTimers();
    }
  }

  /**
   * Start session monitoring
   * @param {Object} sessionData - Session data
   * @param {boolean} rememberMe - Remember me flag
   */
  startSession(sessionData, rememberMe = false) {
    this.sessionData = {
      ...sessionData,
      active: true,
      startTime: Date.now(),
      rememberMe,
      expiry: rememberMe ? Date.now() + (this.rememberMeDays * 24 * 60 * 60 * 1000) : null
    };

    this.saveSessionData();
    this.resetTimers();
    
    if (typeof window !== 'undefined' && window.eventBus) {
      window.eventBus.emit('SESSION_STARTED', this.sessionData);
    }
  }

  /**
   * Stop session monitoring
   */
  stopSession() {
    this.clearTimers();
    
    if (this.sessionData) {
      this.sessionData.active = false;
      this.sessionData.endTime = Date.now();
      this.saveSessionData();
      
      if (typeof window !== 'undefined' && window.eventBus) {
        window.eventBus.emit('SESSION_ENDED', this.sessionData);
      }
    }
  }

  /**
   * Reset timers
   */
  resetTimers() {
    this.clearTimers();
    
    const warningDelay = this.sessionTimeout - this.warningTime;
    this.warningTimer = setTimeout(() => this.showWarning(), warningDelay);
    this.sessionTimer = setTimeout(() => this.logout(), this.sessionTimeout);
  }

  /**
   * Clear timers
   */
  clearTimers() {
    if (this.warningTimer) {
      clearTimeout(this.warningTimer);
      this.warningTimer = null;
    }
    
    if (this.sessionTimer) {
      clearTimeout(this.sessionTimer);
      this.sessionTimer = null;
    }
  }

  /**
   * Show session warning
   */
  showWarning() {
    if (this.warningShown) {return;}
    
    this.warningShown = true;
    const remainingTime = this.sessionTimeout - (Date.now() - this.lastActivity);
    const remainingSeconds = Math.ceil(remainingTime / 1000);
    
    if (typeof window !== 'undefined' && window.eventBus) {
      window.eventBus.emit('SESSION_WARNING', {
        remainingTime,
        remainingSeconds,
        message: `Your session will expire in ${remainingSeconds} seconds`
      });
    }
  }

  /**
   * Logout user
   */
  logout() {
    this.stopSession();
    
    if (typeof window !== 'undefined' && window.eventBus) {
      window.eventBus.emit('SESSION_TIMEOUT', this.sessionData);
    }
  }

  /**
   * Extend session
   */
  extendSession() {
    this.lastActivity = Date.now();
    this.warningShown = false;
    this.resetTimers();
    
    if (typeof window !== 'undefined' && window.eventBus) {
      window.eventBus.emit('SESSION_EXTENDED', this.sessionData);
    }
  }

  /**
   * Get session data
   * @returns {Object} Session data
   */
  getSessionData() {
    return this.sessionData ? { ...this.sessionData } : null;
  }

  /**
   * Check if session is active
   * @returns {boolean} Is active
   */
  isSessionActive() {
    return this.sessionData && this.sessionData.active;
  }

  /**
   * Get remaining session time
   * @returns {number} Remaining time in ms
   */
  getRemainingTime() {
    if (!this.sessionData || !this.sessionData.active) {return 0;}
    
    const elapsed = Date.now() - this.lastActivity;
    return Math.max(0, this.sessionTimeout - elapsed);
  }

  /**
   * Save session data to localStorage
   */
  saveSessionData() {
    try {
      if (this.sessionData && this.sessionData.rememberMe) {
        localStorage.setItem('storetrack_session', JSON.stringify(this.sessionData));
      } else {
        localStorage.removeItem('storetrack_session');
      }
    } catch (error) {
      console.error('SessionSecurity: Failed to save session:', error);
    }
  }

  /**
   * Load session data from localStorage
   */
  loadSessionData() {
    try {
      const saved = localStorage.getItem('storetrack_session');
      if (saved) {
        const sessionData = JSON.parse(saved);
        
        // Check if remember me session is still valid
        if (sessionData.rememberMe && sessionData.expiry) {
          if (Date.now() < sessionData.expiry) {
            this.sessionData = sessionData;
            this.startSession(sessionData, true);
          } else {
            localStorage.removeItem('storetrack_session');
          }
        }
      }
    } catch (error) {
      console.error('SessionSecurity: Failed to load session:', error);
    }
  }

  /**
   * Clear session data
   */
  clearSessionData() {
    localStorage.removeItem('storetrack_session');
    this.sessionData = null;
  }

  /**
   * Update session timeout
   * @param {number} timeout - New timeout in ms
   */
  setSessionTimeout(timeout) {
    this.sessionTimeout = timeout;
    if (this.sessionData && this.sessionData.active) {
      this.resetTimers();
    }
  }

  /**
   * Update warning time
   * @param {number} warningTime - New warning time in ms
   */
  setWarningTime(warningTime) {
    this.warningTime = warningTime;
    if (this.sessionData && this.sessionData.active) {
      this.resetTimers();
    }
  }

  /**
   * Get session statistics
   * @returns {Object} Session statistics
   */
  getSessionStats() {
    if (!this.sessionData) {return null;}
    
    const duration = this.sessionData.endTime 
      ? this.sessionData.endTime - this.sessionData.startTime 
      : Date.now() - this.sessionData.startTime;
    
    return {
      duration,
      startTime: this.sessionData.startTime,
      endTime: this.sessionData.endTime,
      rememberMe: this.sessionData.rememberMe,
      remainingTime: this.getRemainingTime()
    };
  }
}

// Global session security instance
const sessionSecurity = new SessionSecurity();

// Expose to window
if (typeof window !== 'undefined') {
  window.SessionSecurity = SessionSecurity;
  window.sessionSecurity = sessionSecurity;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { SessionSecurity, sessionSecurity };
}
