/* exported pmBulkPrintChecksheets, pmBulkPrintSlips, pmCancelImport, pmClearAllSchedules, pmConfirmImport, pmDeleteSchedule, pmDownloadTemplate, pmGenerateCombinedSlipForPerson, pmGenerateCombinedSlipForSelected, pmImportFile, pmLoadData, pmManualMatchChecksheet, pmPrintChecksheetFromPreview, pmPrintSlip, pmPrintSlipsGrid */
// Preventive Maintenance Module - PM schedules, checksheets, and printing

let pmSchedules = [];
let pmCurrentSlipPrintHtml = '';
let pmChecklistFileMap = {}; // Maps equipment name → { path, type } for matched checksheet files
const pmMappingData = {}; // Stores equipment → checksheet file mapping (persistent)

// Some PM Excel files end up imported more than once (e.g. re-uploading the
// same plan), which creates separate DB records for what is really the same
// task, so the same equipment line shows up 2-3x for a person. Rather than
// silently deleting rows from the database — we can't be sure every repeat
// is accidental — slip generation and the person-group list are built from a
// de-duplicated view: exact repeats of equipment+location+priority+weeklyPlan+shift
// for the same person are collapsed down to a single line.
function pmDedupeItems(items) {
  const seen = new Set();
  return items.filter(i => {
    const key = [i.equipment, i.location, i.priority, i.weeklyPlan, i.shift]
      .map(v => (v || '').toString().trim().toLowerCase()).join('|');
    if (seen.has(key)) {return false;}
    seen.add(key);
    return true;
  });
}

// Download Excel template
async function pmDownloadTemplate() {
  try {
    const result = await window.pmBridge.generateTemplate();
    if (result.error) {throw new Error(result.error);}
    const blob = new Blob([result.buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'PM_Schedule_Template.xlsx';
    a.click();
    URL.revokeObjectURL(url);
    toast('Template downloaded', 'suc');
  } catch (err) {
    console.error('Template download error:', err);
    toast('Failed to download template: ' + err.message, 'err');
  }
}

// Import Excel file with smart parser and validation
async function pmImportFile(event) {
  const file = event.target.files[0];
  if (!file) {return;}
  const validExtensions = ['.xlsx', '.xls', '.xlsm'];
  const fileExt = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
  if (!validExtensions.includes(fileExt)) {
    toast('Invalid file type. Please upload .xlsx, .xls, or .xlsm files only.', 'err');
    event.target.value = '';
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    toast('File too large. Maximum size is 10MB.', 'err');
    event.target.value = '';
    return;
  }
  showLoading('Parsing Excel with Smart Parser...');
  try {
    const buffer = await file.arrayBuffer();
    const result = await window.pmBridge.smartParseSchedule(new Uint8Array(buffer));
    if (result.error) {throw new Error(result.error);}
    const { headers, mapping, rows, headerRowIndex, totalRows, dataRowsCount } = result;
    const statusDiv = document.getElementById('pm-import-status');
    const summaryDiv = document.getElementById('pm-import-summary');
    statusDiv.style.display = 'block';
    summaryDiv.innerHTML = `
      <div data-style="font-size:11px;margin-bottom:8px">
        <div><strong>Header Row:</strong> ${headerRowIndex + 1}</div>
        <div><strong>Total Rows:</strong> ${totalRows}</div>
        <div><strong>Data Rows:</strong> ${dataRowsCount}</div>
        <div><strong>Column Mapping:</strong></div>
        <div data-style="margin-left:10px;font-family:var(--mn);font-size:10px">
          ${Object.entries(mapping).map(([k, v]) => `<div>${k} → Column ${v}</div>`).join('')}
        </div>
      </div>
      <div data-style="display:flex;gap:8px;margin-top:8px">
        <button class="btn btn-p" data-onclick="pmConfirmImport()" data-style="font-size:11px;padding:4px 12px">✓ Confirm Import</button>
        <button class="btn btn-d" data-onclick="pmCancelImport()" data-style="font-size:11px;padding:4px 12px">✕ Cancel</button>
      </div>
    `;
    window.pmTempImportData = { rows, headers, mapping };
    hideLoading();
    toast('Excel parsed successfully. Please review and confirm.', 'suc');
  } catch (err) {
    console.error('[PM Import Error]', err);
    toast('Import failed: ' + err.message, 'err');
    hideLoading();
    event.target.value = '';
  }
}

// Confirm import after review
async function pmConfirmImport() {
  if (!window.pmTempImportData) {
    toast('No data to import', 'err');
    return;
  }
  const { rows } = window.pmTempImportData;
  showLoading('Importing PM schedules...');
  try {
    const imported = [];
    for (const row of rows) {
      const item = { id: generateUUID(), ...row, createdAt: new Date().toISOString() };
      imported.push(item);
    }
    if (imported.length === 0) {
      toast('No valid data found in Excel', 'err');
      hideLoading();
      return;
    }
    for (const item of imported) {
      await dPut('pm_schedules', item);
    }
    pmSchedules = await gAll('pm_schedules');
    await pmAutoMatchChecklists();
    window.pmTempImportData = null;
    document.getElementById('pm-import-summary').innerHTML = `<div data-style="color:var(--gn)">✅ Successfully imported ${imported.length} PM schedules</div>`;
    pmRenderList();
    pmRenderPersonGroups();
    toast(`Imported ${imported.length} PM schedules`, 'suc');
  } catch (err) {
    console.error('[PM Import Confirm Error]', err);
    toast('Import failed: ' + err.message, 'err');
  } finally {
    hideLoading();
    document.getElementById('pm-file-input').value = '';
  }
}

// Cancel import
function pmCancelImport() {
  window.pmTempImportData = null;
  document.getElementById('pm-import-status').style.display = 'none';
  document.getElementById('pm-file-input').value = '';
  toast('Import cancelled', 'inf');
}

// Calculate similarity for auto-matching checksheets
function calculateSimilarity(str1, str2) {
  const s1 = String(str1 || '').toLowerCase().trim();
  const s2 = String(str2 || '').toLowerCase().trim();
  if (s1 === s2) {return 1;}
  if (!s1 || !s2) {return 0;}
  const longer = s1.length > s2.length ? s1 : s2;
  const shorter = s1.length > s2.length ? s2 : s1;
  if (longer.length === 0) {return 1;}
  const editDistance = (a, b) => {
    const matrix = [];
    for (let i = 0; i <= b.length; i++) {matrix[i] = [i];}
    for (let j = 0; j <= a.length; j++) {matrix[0][j] = j;}
    for (let i = 1; i <= b.length; i++) {
      for (let j = 1; j <= a.length; j++) {
        if (b.charAt(i - 1) === a.charAt(j - 1)) {matrix[i][j] = matrix[i - 1][j - 1];}
        else {matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, Math.min(matrix[i][j - 1] + 1, matrix[i - 1][j] + 1));}
      }
    }
    return matrix[b.length][a.length];
  };
  return (longer.length - editDistance(longer, shorter)) / longer.length;
}

// ── Load PM data at startup (called from app.js after DB is ready) ───────────
async function pmLoadData() {
  try {
    pmSchedules = (await gAll('pm_schedules')) || [];
    if (typeof pmRenderList === 'function') { pmRenderList(); pmRenderPersonGroups(); }
  } catch (e) {
    console.error('[pm] Failed to load pm_schedules:', e);
    pmSchedules = [];
  }
  try {
    const checklists = await gAll('pm_checklists');
    checklists.forEach(c => {
      if (c.equipment && c.path) {pmChecklistFileMap[c.equipment] = { path: c.path, type: c.type };}
    });
  } catch (e) {
    console.error('[pm] Failed to load pm_checklists:', e);
  }
}

// ── Render "All PM Schedules" table ───────────────────────────────────────────
function pmRenderList() {
  const tbody = document.getElementById('pm-list-body');
  if (!tbody) {return;}
  const q = (document.getElementById('pm-search')?.value || '').toLowerCase();
  let rows = [...pmSchedules];
  if (q) {
    rows = rows.filter(s =>
      (s.equipment || '').toLowerCase().includes(q) ||
      (s.location || '').toLowerCase().includes(q)
    );
  }
  tbody.innerHTML = rows.map(s => `
    <tr>
      <td>${sanitizeHTML(String(s.serialNo || '—'))}</td>
      <td>${sanitizeHTML(String(s.equipment || '—'))}</td>
      <td>${sanitizeHTML(String(s.location || '—'))}</td>
      <td>${sanitizeHTML(String(s.priority || '—'))}</td>
      <td>${sanitizeHTML(String(s.who || '—'))}</td>
      <td>${sanitizeHTML(String(s.weeklyPlan || '—'))}</td>
      <td>${sanitizeHTML(String(s.shift || '—'))}</td>
      <td>${Math.min(100, Math.max(1, Number(s.checksheetQty) || 1))}</td>
      <td>
        <button class="btn" data-style="font-size:10px;padding:2px 8px" data-onclick="pmPreviewChecksheet(${JSON.stringify(String(s.id))})">📋 Checksheet</button>
        <button class="btn btn-d" data-style="font-size:10px;padding:2px 8px" data-onclick="pmDeleteSchedule(${JSON.stringify(String(s.id))})">🗑</button>
      </td>
    </tr>`).join('');

  const emptyState = document.getElementById('pm-empty-state');
  if (emptyState) {
    emptyState.style.display = rows.length ? 'none' : '';
    const message = emptyState.querySelector('p, .muted, span');
    if (message) {message.textContent = pmSchedules.length ? 'No PM schedules match the current search.' : 'No PM schedules yet. Import a schedule to get started.';}
  }
}

async function pmDeleteSchedule(id) {
  if (!confirm('Delete this PM schedule entry?')) {return;}
  try { await dDel('pm_schedules', id); } catch (e) { console.error('[pm] delete failed', e); }
  pmSchedules = pmSchedules.filter(s => s.id !== id);
  pmRenderList();
  pmRenderPersonGroups();
}

// ── Render "PM Slips grouped by Person" ───────────────────────────────────────
function pmRenderPersonGroups() {
  const container = document.getElementById('pm-person-groups');
  if (!container) {return;}
  const q = (document.getElementById('pm-person-search')?.value || '').toLowerCase();
  const priorityFilter = document.getElementById('pm-filter-priority')?.value || '';
  const shiftFilter = document.getElementById('pm-filter-shift')?.value || '';

  let rows = [...pmSchedules];
  if (priorityFilter) {rows = rows.filter(s => s.priority === priorityFilter);}
  if (shiftFilter) {rows = rows.filter(s => s.shift === shiftFilter);}

  const groups = {};
  rows.forEach(s => {
    const who = s.who || 'Unassigned';
    if (q && !who.toLowerCase().includes(q)) {return;}
    (groups[who] = groups[who] || []).push(s);
  });
  Object.keys(groups).forEach(name => { groups[name] = pmDedupeItems(groups[name]); });

  const names = Object.keys(groups).sort();
  container.innerHTML = names.map(name => {
    const items = groups[name];
    const encodedName = JSON.stringify(name).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return `
    <div class="pm-person-row">
      <div data-style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span data-style="font-weight:700">👤 ${sanitizeHTML(String(name))}</span>
        <span class="bdg" data-style="font-size:10px">${items.length} equipment</span>
        <button class="btn btn-p" data-style="font-size:10px;padding:3px 10px;margin-left:auto" data-onclick="pmGenerateCombinedSlipForPerson(${encodedName})">📋 Generate Slip</button>
      </div>
      <div data-style="font-size:11px;color:var(--tx3)">${items.map(i => sanitizeHTML(String(i.equipment || '—'))).join(', ')}</div>
    </div>`;
  }).join('');

  const emptyState = document.getElementById('pm-empty-state');
  if (emptyState) {emptyState.style.display = names.length ? 'none' : '';}
}

// ── Slip / checksheet generation & printing ───────────────────────────────────
// Compact slip body shared by the single-slip preview and the multi-up grid print.
// fontScale lets the grid layout (5-up) shrink text further to fit each cell.
function pmBuildSlipBodyHtml(name, items, fontScale) {
  const safe = value => String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  name = safe(name);
  items = (items || []).map(item => Object.fromEntries(Object.entries(item || {}).map(([key, value]) => [key, safe(value)])));
  const fs = fontScale || 1;
  const pad = Math.max(2, Math.round(3 * fs));
  const th = Math.max(7, Math.round(10 * fs));
  return `
    <div class="pm-slip-body" style="width:100%;box-sizing:border-box;font-family:Arial,sans-serif;color:#000">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:6px;margin-bottom:${Math.round(5*fs)}px;line-height:1.15">
      <div style="flex:1;min-width:0;font-weight:700;font-size:${Math.round(12*fs)}px;overflow-wrap:anywhere">PM Slip — ${name}</div>
      <div style="flex:0 0 auto;white-space:nowrap;font-size:${Math.round(9*fs)}px;color:#333">Date: ______________</div>
    </div>
    <div style="font-size:${th}px;line-height:1.2;margin-bottom:${Math.round(5*fs)}px;overflow-wrap:anywhere">
      Actual person (if ${name} unavailable): __________________ + __________________
    </div>
    <table class="pm-slip-items" style="width:100%;table-layout:fixed;border-collapse:collapse;font-size:${th}px;line-height:1.15;border:1px solid #333">
      <colgroup><col style="width:42%"><col style="width:18%"><col style="width:12%"><col style="width:18%"><col style="width:10%"></colgroup>
      <thead><tr>
        <th style="border:1px solid #333;padding:${pad}px 3px;text-align:left;vertical-align:top;background:#eee;color:#000;overflow-wrap:anywhere">Equipment</th>
        <th style="border:1px solid #333;padding:${pad}px 3px;text-align:left;vertical-align:top;background:#eee;color:#000;overflow-wrap:anywhere">Location</th>
        <th style="border:1px solid #333;padding:${pad}px 3px;text-align:left;vertical-align:top;background:#eee;color:#000;overflow-wrap:anywhere">Priority</th>
        <th style="border:1px solid #333;padding:${pad}px 3px;text-align:left;vertical-align:top;background:#eee;color:#000;overflow-wrap:anywhere">Weekly Plan</th>
        <th style="border:1px solid #333;padding:${pad}px 3px;text-align:left;vertical-align:top;background:#eee;color:#000;overflow-wrap:anywhere">Shift</th>
      </tr></thead>
      <tbody>${items.map(i => `<tr>
        <td style="border:1px solid #999;padding:${pad}px 3px;vertical-align:top;background:#fff;color:#000;overflow-wrap:anywhere">${i.equipment || '—'}</td>
        <td style="border:1px solid #999;padding:${pad}px 3px;vertical-align:top;background:#fff;color:#000;overflow-wrap:anywhere">${i.location || '—'}</td>
        <td style="border:1px solid #999;padding:${pad}px 3px;vertical-align:top;background:#fff;color:#000;overflow-wrap:anywhere">${i.priority || '—'}</td>
        <td style="border:1px solid #999;padding:${pad}px 3px;vertical-align:top;background:#fff;color:#000;overflow-wrap:anywhere">${i.weeklyPlan || '—'}</td>
        <td style="border:1px solid #999;padding:${pad}px 3px;vertical-align:top;background:#fff;color:#000;overflow-wrap:anywhere">${i.shift || '—'}</td>
      </tr>`).join('')}</tbody>
    </table>
    <div style="font-size:${th}px;line-height:1.2;margin-top:${Math.round(5*fs)}px">
      <div style="margin-bottom:2px">Work done / remarks:</div>
      <div style="border-bottom:1px solid #999;height:${Math.round(14*fs)}px"></div>
      <div style="border-bottom:1px solid #999;height:${Math.round(14*fs)}px"></div>
    </div>
    <div style="display:flex;justify-content:space-between;gap:10px;font-size:${th}px;line-height:1.2;margin-top:${Math.round(5*fs)}px">
      <span>Done by: ________________</span>
      <span>Sign: ________________</span>
    </div>
    </div>`;
}

// Full-size slip (used in the single-slip preview modal / single print)
function pmBuildSlipHtml(name, items, fontScale = 0.92) {
  return `<div class="pm-slip-card" style="width:100%;max-width:125mm;margin:0 auto;padding:4mm;border:1px solid #333;box-sizing:border-box">${pmBuildSlipBodyHtml(name, items, fontScale)}</div>`;
}

function pmGenerateCombinedSlipForPerson(name) {
  const items = pmDedupeItems(pmSchedules.filter(s => (s.who || 'Unassigned') === name));
  const content = document.getElementById('pm-slip-content');
  if (content) {
    // pmBuildSlipHtml() / pmBuildSlipBodyHtml() are shared with the print
    // popups (pmBulkPrintSlips, pmPrintSlipsGrid), which write straight into
    // a window.open() document that has no CSP and no cspBridge — so those
    // functions must keep emitting literal style="" for that path to work.
    // This preview modal, however, lives in the main (CSP'd) window, where
    // literal style="" is silently dropped. Convert to data-style="" only
    // here, right at the point of insertion into the CSP'd document, so
    // cspBridge's applyCssText() picks it up and both code paths keep working.
    pmCurrentSlipPrintHtml = pmBuildSlipHtml(name, items);
    content.innerHTML = pmCurrentSlipPrintHtml.replace(/\bstyle="/g, 'data-style="');
  }
  document.getElementById('pm-slip-ov')?.classList.add('on');
}

function pmGenerateCombinedSlipForSelected() {
  const names = [...new Set(pmSchedules.map(s => s.who || 'Unassigned'))].sort();
  const picker = document.getElementById('pm-person-picker-content');
  if (picker) {
    picker.innerHTML = names.length
      ? names.map(n => { const encoded = JSON.stringify(n).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); return `<div class="btn" data-style="display:block;margin-bottom:6px;cursor:pointer" data-onclick="document.getElementById('pm-person-picker-ov').classList.remove('on');pmGenerateCombinedSlipForPerson(${encoded})">👤 ${sanitizeHTML(String(n))}</div>`; }).join('')
      : '<div data-style="color:var(--tx3);font-size:12px">No PM schedules imported yet.</div>';
  }
  document.getElementById('pm-person-picker-ov')?.classList.add('on');
}

function pmPrintSlip() {
  const content = document.getElementById('pm-slip-content');
  if (!content) {return;}
  const printableContent = pmCurrentSlipPrintHtml || content.innerHTML.replace(/\bdata-style="/g, 'style="');
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>@page{size:A5 portrait;margin:7mm}*{box-sizing:border-box}html,body{margin:0;padding:0;font-family:Arial,sans-serif;color:#000}.pm-slip-card{width:100%;max-width:125mm;margin:0 auto}.pm-slip-body{width:100%}.pm-slip-items{width:100%;table-layout:fixed}tr,th,td{break-inside:avoid;page-break-inside:avoid}</style></head><body>${printableContent}</body></html>`;
  window.printPopupHtml(html);
}

function pmBulkPrintSlips() {
  // One compact A5 page per person; long equipment lists may continue cleanly.
  const names = [...new Set(pmSchedules.map(s => s.who || 'Unassigned'))].sort();
  if (!names.length) { toast('No PM schedules to print', 'err'); return; }
  const body = names.map(n => `<div class="pm-slip-page">${pmBuildSlipHtml(n, pmDedupeItems(pmSchedules.filter(s => (s.who || 'Unassigned') === n)), 0.92)}</div>`).join('');
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    @page{size:A5 portrait;margin:7mm}*{box-sizing:border-box}
    html,body{margin:0;padding:0;font-family:Arial,sans-serif;color:#000}
    .pm-slip-page{width:100%;min-height:58mm;margin:0;padding:0;box-sizing:border-box;break-after:page;page-break-after:always}
    .pm-slip-page:last-child{break-after:auto;page-break-after:auto}
    .pm-slip-page table{width:100%;table-layout:fixed}
    tr,th,td{break-inside:avoid;page-break-inside:avoid}
  </style></head><body>${body}</body></html>`;
  window.printPopupHtml(html);
}

// Multi-up printing: fit 5 slips onto an A4 page so there's no need to print
// each person's slip separately. Laid out as a real 2-column HTML table (3
// rows, last cell left blank so exactly 5 slips print per page) — a table
// guarantees the left/right cell in a row start at the same top edge, which
// CSS Grid was not reliably giving once combined with print break hints.
// Each row has a consistent target height so cards align across the page;
// table rows can grow when longer equipment lists need more room, rather than
// clipping the person's slip content.
function pmPrintSlipsGrid(perPage) {
  perPage = 5; // fixed: 5 slips per page
  const names = [...new Set(pmSchedules.map(s => s.who || 'Unassigned'))].sort();
  if (!names.length) { toast('No PM schedules to print', 'err'); return; }

  const cols = 2;
  const fontScale = 0.92;

  // Each slip becomes one <td>. Using a real HTML table (not CSS Grid) for
  // the page layout guarantees that the left/right cell in the same row
  // always start at the same top edge and share the same row height —
  // that's a fundamental property of table layout, whereas CSS Grid combined
  // with break-inside/page-break hints was leaving rows visibly unaligned.
  const cells = names.map(n =>
    `<td class="pm-slip-cell">${pmBuildSlipHtml(n, pmDedupeItems(pmSchedules.filter(s => (s.who || 'Unassigned') === n)), fontScale)}</td>`
  );

  // Chunk into pages of `perPage` cells each
  const pages = [];
  for (let i = 0; i < cells.length; i += perPage) {pages.push(cells.slice(i, i + perPage));}

  const pagesHtml = pages.map(pageCells => {
    // Pad the last page so the table stays 2-wide even if it's not full
    const padded = pageCells.concat(Array(perPage - pageCells.length).fill('<td class="pm-slip-cell pm-slip-cell-empty"></td>'));
    const rowsHtml = [];
    for (let i = 0; i < padded.length; i += cols) {rowsHtml.push(`<tr>${padded.slice(i, i + cols).join('')}</tr>`);}
    return `<table class="pm-slip-page">${rowsHtml.join('')}</table>`;
  }).join('');

  const html = `<!DOCTYPE html><html><head><style>
    @page{size:A4 portrait;margin:6mm}
    *{box-sizing:border-box}
    body{font-family:Arial,sans-serif;margin:0;color:#000}
    .pm-slip-page{width:100%;border-collapse:separate;border-spacing:2mm;table-layout:fixed;page-break-after:always}
    .pm-slip-page:last-child{page-break-after:auto}
    .pm-slip-page > tbody > tr{height:82mm}
    .pm-slip-cell{height:82mm;width:50%;border:none;padding:0;vertical-align:top;background:transparent;break-inside:avoid;page-break-inside:avoid}
    .pm-slip-cell .pm-slip-card{min-height:78mm;margin:0 auto}
    .pm-slip-cell-empty{border:none;background:transparent}
    .pm-slip-cell table{width:100%;table-layout:fixed}
  </style></head><body>${pagesHtml}</body></html>`;
  window.printPopupHtml(html);
}

function pmChecksheetItems(parsed) { return Array.isArray(parsed?.items) ? parsed.items : Array.isArray(parsed?.rows) ? parsed.rows : []; }

function pmChecksheetItemHtml(item) {
  const label = item?.inspectionItem || item?.text || item?.item || item?.description || '';
  const details = [['Standard', item?.standard], ['OK', item?.ok], ['NG', item?.ng], ['Remarks', item?.remarks]].filter(([, value]) => String(value || '').trim()).map(([name, value]) => `<span><b>${name}:</b> ${sanitizeHTML(String(value))}</span>`).join(' · ');
  return `<li>${sanitizeHTML(String(label))}${details ? `<div>${details}</div>` : ''}</li>`;
}

async function pmPreviewChecksheet(id) {
  const s = pmSchedules.find(x => x.id === id);
  if (!s) {return;}
  const info = document.getElementById('pm-checksheet-info');
  const content = document.getElementById('pm-checksheet-content');
  const manualBox = document.getElementById('pm-checksheet-manual-match');
  const manualSelect = document.getElementById('pm-manual-match-select');
  if (info) {info.innerHTML = `<b>${sanitizeHTML(String(s.equipment || '—'))}</b> · ${sanitizeHTML(String(s.location || '—'))} · Priority: ${sanitizeHTML(String(s.priority || '—'))}`;}
  const file = pmChecklistFileMap[s.equipment];
  if (content) {
    content.innerHTML = file
      ? `<div>Matched checksheet file: <b>${sanitizeHTML(String(file.path))}</b><div id="pm-checksheet-parsed" data-style="margin-top:8px">Loading checksheet content…</div></div>`
      : `<div data-style="color:#888">No checksheet file matched for this equipment yet. Run "Auto-match Checksheets", or link one manually below.</div>`;
    if (file && window.pmBridge?.parseChecklistFile) { try { const parsed=await window.pmBridge.parseChecklistFile(file.path,file.type); const host=document.getElementById('pm-checksheet-parsed'); if(host){ const rows=pmChecksheetItems(parsed); host.innerHTML=rows.length?`<ol>${rows.map(pmChecksheetItemHtml).join('')}</ol>`:'<span>No readable checklist rows found.</span>'; } } catch(error) { console.warn('[pm] parse checksheet failed',error); } }
  }
  window._pmChecksheetPreviewId = id;

  // Manual match: always offer it, so a wrong auto-match can be corrected too
  if (manualBox && manualSelect) {
    try {
      const result = await window.pmBridge.listChecklistFiles();
      const files = (result && result.files) || [];
      if (files.length) {
        manualSelect.innerHTML = '<option value="">— Select a file —</option>' +
          files.map(f => `<option value="${sanitizeHTML(String(f.path || ''))}" data-type="${sanitizeHTML(String(f.type || ''))}">${sanitizeHTML(String(f.name || f.path || ''))}</option>`).join('');
        manualBox.style.display = '';
      } else {
        manualBox.style.display = 'none';
      }
    } catch (err) {
      console.error('[PM Manual Match List Error]', err);
      manualBox.style.display = 'none';
    }
  }

  document.getElementById('pm-checksheet-ov')?.classList.add('on');
}

// Manually link the selected checksheet file to the currently previewed equipment
async function pmManualMatchChecksheet() {
  const id = window._pmChecksheetPreviewId;
  const s = pmSchedules.find(x => x.id === id);
  if (!s) {return;}
  const select = document.getElementById('pm-manual-match-select');
  const path = select?.value;
  if (!path) { if (typeof toast === 'function') {toast('Please select a file to link', 'er');} return; }
  const type = select.selectedOptions[0]?.dataset.type || '';

  pmChecklistFileMap[s.equipment] = { path, type };
  try {
    await dPut('pm_checklists', {
      id: generateUUID(),
      equipment: s.equipment,
      path, type,
      items: [],
      updatedAt: new Date().toISOString(),
      autoMatched: false
    });
  } catch (e) {
    console.error('[pm] manual match save failed', e);
  }
  if (typeof toast === 'function') {toast(`Linked checksheet for ${s.equipment}`, 'suc');}
  pmPreviewChecksheet(id);
}

function pmPrintChecksheetFromPreview() {
  const content = document.getElementById('pm-checksheet-content');
  if (!content) {return;}
  const html = `<!DOCTYPE html><html><head><style>body{font-family:Arial,sans-serif;margin:12mm}</style></head><body>${content.innerHTML}</body></html>`;
  window.printPopupHtml(html);
}

async function pmBulkPrintChecksheets() {
  if (!pmSchedules.length) { toast('No PM schedules to print', 'err'); return; }
  if (!window.pmBridge?.parseChecklistFile) { toast('Checksheet parser is unavailable; no checksheet was printed', 'err'); return; }
  const schedules = pmSchedules.flatMap(schedule => Array.from({length: Math.min(100, Math.max(1, Number(schedule.checksheetQty) || 1))}, () => schedule));
  const body = (await Promise.all(schedules.map(async schedule => {
    const file = pmChecklistFileMap[schedule.equipment];
    let items = [];
    if (file?.path) {
      try { const parsed = await window.pmBridge.parseChecklistFile(file.path, file.type); items = pmChecksheetItems(parsed); }
      catch (error) { console.warn('[pm] bulk checksheet parse failed', error); }
    }
    const checklist = items.length ? `<ol>${items.map(pmChecksheetItemHtml).join('')}</ol>` : `<p>${file ? 'No readable checklist items were found in the linked file.' : 'No checksheet matched. Link a checksheet before printing.'}</p>`;
    return `<section style="page-break-after:always"><h2>${sanitizeHTML(String(schedule.equipment || '—'))}</h2><p>${sanitizeHTML(String(schedule.location || '—'))} · Priority: ${sanitizeHTML(String(schedule.priority || '—'))} · Shift: ${sanitizeHTML(String(schedule.shift || '—'))}</p>${checklist}</section>`;
  }))).join('');
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>PM Checksheets</title><style>body{font-family:Arial,sans-serif;margin:12mm}section{break-after:page;page-break-after:always}li{margin:4px 0}</style></head><body>${body}</body></html>`;
  window.printPopupHtml(html);
}

async function pmClearAllSchedules() {
  if (!confirm('Delete ALL PM schedules and matched checksheets? This cannot be undone.')) {return;}
  try {
    await dClr('pm_schedules');
    await dClr('pm_checklists');
  } catch (e) {
    console.error('[pm] clear failed', e);
  }
  pmSchedules = [];
  pmChecklistFileMap = {};
  pmRenderList();
  pmRenderPersonGroups();
  toast('All PM schedules cleared', 'suc');
}

// Auto-match checksheets to equipment
async function pmAutoMatchChecklists() {
  try {
    const result = await window.pmBridge.listChecklistFiles();
    if (result.error || !result.files || result.files.length === 0) {return;}
    const files = result.files;
    const checklists = await gAll('pm_checklists');
    checklists.forEach(c => {
      if (c.equipment && c.path) {pmChecklistFileMap[c.equipment] = { path: c.path, type: c.type };}
    });
    let matchedCount = 0;
    for (const schedule of pmSchedules) {
      if (pmChecklistFileMap[schedule.equipment]) {continue;}
      let bestMatch = null;
      let bestScore = 0;
      for (const file of files) {
        const score = calculateSimilarity(schedule.equipment, file.equipment);
        if (score > bestScore && score > 0.5) {
          bestScore = score;
          bestMatch = file;
        }
      }
      if (bestMatch) {
        pmChecklistFileMap[schedule.equipment] = { path: bestMatch.path, type: bestMatch.type };
        await dPut('pm_checklists', {
          id: generateUUID(),
          equipment: schedule.equipment,
          path: bestMatch.path,
          type: bestMatch.type,
          items: [],
          updatedAt: new Date().toISOString(),
          autoMatched: true
        });
        matchedCount++;
      }
    }
    if (matchedCount > 0) {
      toast(`Auto-matched ${matchedCount} checksheets`, 'suc');
    }
  } catch (err) {
    console.error('[PM Auto-match Error]', err);
  }
}
