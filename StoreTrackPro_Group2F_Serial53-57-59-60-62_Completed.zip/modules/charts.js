// Charts Module - Data visualization using Canvas API

/**
 * Simple chart library using HTML5 Canvas
 */
class Chart {
  constructor(canvas, options = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.options = {
      width: options.width || 400,
      height: options.height || 300,
      padding: options.padding || 40,
      colors: options.colors || ['#4a9eff', '#ff6b6b', '#51cf66', '#ffd43b', '#cc5de8'],
      ...options
    };
    
    this.canvas.width = this.options.width;
    this.canvas.height = this.options.height;
    this.data = [];
  }

  /**
   * Clear canvas
   */
  clear() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  /**
   * Set chart data
   * @param {Array} data - Chart data
   */
  setData(data) {
    this.data = data;
    return this;
  }

  /**
   * Draw bar chart
   */
  drawBarChart() {
    this.clear();
    const { ctx, canvas, options, data } = this;
    const { padding, colors } = options;
    
    const chartWidth = canvas.width - padding * 2;
    const chartHeight = canvas.height - padding * 2;
    
    // Find max value for scaling
    const maxValue = Math.max(...data.map(d => d.value));
    
    // Draw axes
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, canvas.height - padding);
    ctx.lineTo(canvas.width - padding, canvas.height - padding);
    ctx.strokeStyle = '#ccc';
    ctx.stroke();
    
    // Draw bars
    const barWidth = chartWidth / data.length - 10;
    
    data.forEach((item, index) => {
      const barHeight = (item.value / maxValue) * chartHeight;
      const x = padding + index * (chartWidth / data.length) + 5;
      const y = canvas.height - padding - barHeight;
      
      // Draw bar
      ctx.fillStyle = colors[index % colors.length];
      ctx.fillRect(x, y, barWidth, barHeight);
      
      // Draw label
      ctx.fillStyle = '#333';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(item.label, x + barWidth / 2, canvas.height - padding + 15);
      
      // Draw value
      ctx.fillStyle = '#666';
      ctx.fillText(item.value, x + barWidth / 2, y - 5);
    });
  }

  /**
   * Draw line chart
   */
  drawLineChart() {
    this.clear();
    const { ctx, canvas, options, data } = this;
    const { padding, colors } = options;
    
    const chartWidth = canvas.width - padding * 2;
    const chartHeight = canvas.height - padding * 2;
    
    const maxValue = Math.max(...data.map(d => d.value));
    
    // Draw axes
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, canvas.height - padding);
    ctx.lineTo(canvas.width - padding, canvas.height - padding);
    ctx.strokeStyle = '#ccc';
    ctx.stroke();
    
    // Draw line
    ctx.beginPath();
    ctx.strokeStyle = colors[0];
    ctx.lineWidth = 2;
    
    data.forEach((item, index) => {
      const x = padding + (index / (data.length - 1)) * chartWidth;
      const y = canvas.height - padding - (item.value / maxValue) * chartHeight;
      
      if (index === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });
    
    ctx.stroke();
    
    // Draw points
    data.forEach((item, index) => {
      const x = padding + (index / (data.length - 1)) * chartWidth;
      const y = canvas.height - padding - (item.value / maxValue) * chartHeight;
      
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = colors[0];
      ctx.fill();
      
      // Draw label
      ctx.fillStyle = '#333';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(item.label, x, canvas.height - padding + 15);
    });
  }

  /**
   * Draw pie chart
   */
  drawPieChart() {
    this.clear();
    const { ctx, canvas, options, data } = this;
    const { colors } = options;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 20;
    
    const total = data.reduce((sum, item) => sum + item.value, 0);
    
    let startAngle = 0;
    
    data.forEach((item, index) => {
      const sliceAngle = (item.value / total) * Math.PI * 2;
      const endAngle = startAngle + sliceAngle;
      
      // Draw slice
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = colors[index % colors.length];
      ctx.fill();
      
      // Draw label
      const labelAngle = startAngle + sliceAngle / 2;
      const labelX = centerX + Math.cos(labelAngle) * (radius * 0.7);
      const labelY = centerY + Math.sin(labelAngle) * (radius * 0.7);
      
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(item.label, labelX, labelY);
      
      startAngle = endAngle;
    });
  }

  /**
   * Draw donut chart
   */
  drawDonutChart() {
    this.clear();
    const { ctx, canvas, options, data } = this;
    const { colors } = options;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const outerRadius = Math.min(centerX, centerY) - 20;
    const innerRadius = outerRadius * 0.5;
    
    const total = data.reduce((sum, item) => sum + item.value, 0);
    
    let startAngle = 0;
    
    data.forEach((item, index) => {
      const sliceAngle = (item.value / total) * Math.PI * 2;
      const endAngle = startAngle + sliceAngle;
      
      // Draw slice
      ctx.beginPath();
      ctx.arc(centerX, centerY, outerRadius, startAngle, endAngle);
      ctx.arc(centerX, centerY, innerRadius, endAngle, startAngle, true);
      ctx.closePath();
      ctx.fillStyle = colors[index % colors.length];
      ctx.fill();
      
      startAngle = endAngle;
    });
    
    // Draw center text
    ctx.fillStyle = '#333';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Total', centerX, centerY - 10);
    ctx.fillText(total.toLocaleString(), centerX, centerY + 10);
  }
}

/**
 * Chart manager for managing multiple charts
 */
class ChartManager {
  constructor() {
    this.charts = new Map();
  }

  /**
   * Create a new chart
   * @param {string} id - Chart ID
   * @param {string} canvasId - Canvas element ID
   * @param {object} options - Chart options
   * @returns {Chart} - Chart instance
   */
  createChart(id, canvasId, options = {}) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) {
      console.error(`Canvas element "${canvasId}" not found`);
      return null;
    }
    
    const chart = new Chart(canvas, options);
    this.charts.set(id, chart);
    return chart;
  }

  /**
   * Get chart by ID
   * @param {string} id - Chart ID
   * @returns {Chart} - Chart instance
   */
  getChart(id) {
    return this.charts.get(id);
  }

  /**
   * Remove chart
   * @param {string} id - Chart ID
   */
  removeChart(id) {
    this.charts.delete(id);
  }

  /**
   * Clear all charts
   */
  clearAll() {
    this.charts.forEach(chart => chart.clear());
  }
}

/**
 * Pre-defined chart configurations for common use cases
 */
const CHART_CONFIGS = {
  stockByCategory: {
    type: 'bar',
    title: 'Stock by Category',
    dataSource: 'materials',
    groupBy: 'category',
    aggregate: 'sum',
    field: 'currentStock'
  },
  transactionTrend: {
    type: 'line',
    title: 'Transaction Trend',
    dataSource: 'transactions',
    groupBy: 'date',
    aggregate: 'count'
  },
  lowStockDistribution: {
    type: 'pie',
    title: 'Low Stock Distribution',
    dataSource: 'materials',
    filter: { field: 'currentStock', operator: 'lte', value: 'minStock' },
    groupBy: 'category'
  },
  materialStatus: {
    type: 'donut',
    title: 'Material Status',
    dataSource: 'materials',
    groupBy: 'active',
    aggregate: 'count'
  }
};

/**
 * Global chart manager instance
 */
const chartManager = new ChartManager();

/**
 * Create chart from configuration
 * @param {string} id - Chart ID
 * @param {string} canvasId - Canvas element ID
 * @param {object} config - Chart configuration
 * @returns {Promise<Chart>} - Chart instance
 */
async function createChartFromConfig(id, canvasId, config) {
  const chart = chartManager.createChart(id, canvasId, config.options);
  if (!chart) {return null;}
  
  // Load data based on configuration
  let data = [];
  try {
    if (typeof gAll === 'function') {
      const rawData = await gAll(config.dataSource);
      
      // Apply filters
      let filtered = rawData;
      if (config.filter) {
        filtered = rawData.filter(item => {
          const value = item[config.filter.field];
          switch (config.filter.operator) {
            case 'lte':
              return value <= item[config.filter.value];
            default:
              return true;
          }
        });
      }
      
      // Group and aggregate
      if (config.groupBy) {
        const groups = {};
        filtered.forEach(item => {
          const key = item[config.groupBy] || 'Other';
          if (!groups[key]) {groups[key] = [];}
          groups[key].push(item);
        });
        
        data = Object.keys(groups).map(key => {
          const group = groups[key];
          let value = group.length;
          
          if (config.aggregate === 'sum' && config.field) {
            value = group.reduce((sum, item) => sum + (item[config.field] || 0), 0);
          }
          
          return { label: key, value };
        });
      }
    }
  } catch (err) {
    console.error('Failed to load chart data:', err);
  }
  
  chart.setData(data);
  
  // Draw chart based on type
  switch (config.type) {
    case 'bar':
      chart.drawBarChart();
      break;
    case 'line':
      chart.drawLineChart();
      break;
    case 'pie':
      chart.drawPieChart();
      break;
    case 'donut':
      chart.drawDonutChart();
      break;
  }
  
  return chart;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.Charts = {
    Chart,
    ChartManager,
    manager: chartManager,
    CONFIGS: CHART_CONFIGS,
    createFromConfig: createChartFromConfig
  };
}
