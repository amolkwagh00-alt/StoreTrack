// Collaborative Editing Module - Real-time collaborative document editing

/**
 * Document State class
 */
class DocumentState {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.type = config.type || 'text'; // text, table, form
    this.content = config.content || '';
    this.version = config.version || 0;
    this.lastModifiedBy = config.lastModifiedBy || null;
    this.lastModifiedAt = config.lastModifiedAt || new Date().toISOString();
    this.lockedBy = config.lockedBy || null;
    this.lockedAt = config.lockedAt || null;
  }

  generateId() {
    return `doc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Operation class for OT (Operational Transformation)
 */
class Operation {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.type = config.type || 'insert'; // insert, delete, retain
    this.position = config.position || 0;
    this.length = config.length || 0;
    this.content = config.content || '';
    this.userId = config.userId || null;
    this.timestamp = config.timestamp || new Date().toISOString();
    this.version = config.version || 0;
  }

  generateId() {
    return `op-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Apply operation to content
   * @param {string} content - Content to apply to
   * @returns {string} - New content
   */
  apply(content) {
    switch (this.type) {
      case 'insert':
        return content.slice(0, this.position) + this.content + content.slice(this.position);
      case 'delete':
        return content.slice(0, this.position) + content.slice(this.position + this.length);
      case 'retain':
        return content;
      default:
        return content;
    }
  }

  /**
   * Transform operation against another
   * @param {Operation} other - Other operation
   * @returns {Operation} - Transformed operation
   */
  transform(other) {
    // Simplified OT transformation
    if (this.type === 'insert' && other.type === 'insert') {
      if (other.position <= this.position) {
        this.position += other.content.length;
      }
    } else if (this.type === 'insert' && other.type === 'delete') {
      if (other.position < this.position) {
        this.position = Math.max(other.position, this.position - other.length);
      }
    } else if (this.type === 'delete' && other.type === 'insert') {
      if (other.position <= this.position) {
        this.position += other.content.length;
      }
    } else if (this.type === 'delete' && other.type === 'delete') {
      if (other.position < this.position) {
        this.position = Math.max(other.position, this.position - other.length);
        this.length = Math.max(0, this.length - other.length);
      }
    }

    return this;
  }
}

/**
 * Collaborative Editing Manager
 */
class CollaborativeEditingManager {
  constructor() {
    this.documents = new Map();
    this.operations = new Map();
    this.cursors = new Map();
    this.init();
  }

  /**
   * Initialize collaborative editing manager
   */
  async init() {
    await this.loadDocuments();
    await this.loadOperations();
  }

  /**
   * Load documents from storage
   */
  async loadDocuments() {
    try {
      const docs = await gAll('collaborative_documents');
      docs.forEach(d => {
        this.documents.set(d.id, new DocumentState(d));
      });
    } catch (err) {
      console.error('Failed to load collaborative documents:', err);
    }
  }

  /**
   * Load operations from storage
   */
  async loadOperations() {
    try {
      const ops = await gAll('collaborative_operations');
      ops.forEach(o => {
        const op = new Operation(o);
        if (!this.operations.has(o.documentId)) {
          this.operations.set(o.documentId, []);
        }
        this.operations.get(o.documentId).push(op);
      });
    } catch (err) {
      console.error('Failed to load operations:', err);
    }
  }

  /**
   * Create document
   * @param {object} config - Document configuration
   * @returns {DocumentState} - Created document
   */
  async createDocument(config) {
    const doc = new DocumentState(config);
    this.documents.set(doc.id, doc);
    await this.saveDocument(doc);
    return doc;
  }

  /**
   * Get document
   * @param {string} id - Document ID
   * @returns {DocumentState} - Document
   */
  getDocument(id) {
    return this.documents.get(id);
  }

  /**
   * Update document
   * @param {string} id - Document ID
   * @param {string} content - New content
   * @param {string} userId - User ID
   */
  async updateDocument(id, content, userId) {
    const doc = this.documents.get(id);
    if (doc) {
      doc.content = content;
      doc.version++;
      doc.lastModifiedBy = userId;
      doc.lastModifiedAt = new Date().toISOString();
      await this.saveDocument(doc);
    }
  }

  /**
   * Lock document
   * @param {string} id - Document ID
   * @param {string} userId - User ID
   */
  async lockDocument(id, userId) {
    const doc = this.documents.get(id);
    if (doc) {
      doc.lockedBy = userId;
      doc.lockedAt = new Date().toISOString();
      await this.saveDocument(doc);
    }
  }

  /**
   * Unlock document
   * @param {string} id - Document ID
   */
  async unlockDocument(id) {
    const doc = this.documents.get(id);
    if (doc) {
      doc.lockedBy = null;
      doc.lockedAt = null;
      await this.saveDocument(doc);
    }
  }

  /**
   * Check if document is locked
   * @param {string} id - Document ID
   * @returns {boolean} - Is locked
   */
  isLocked(id) {
    const doc = this.documents.get(id);
    return doc ? !!doc.lockedBy : false;
  }

  /**
   * Get document lock owner
   * @param {string} id - Document ID
   * @returns {string|null} - Lock owner user ID
   */
  getLockOwner(id) {
    const doc = this.documents.get(id);
    return doc ? doc.lockedBy : null;
  }

  /**
   * Apply operation to document
   * @param {string} documentId - Document ID
   * @param {Operation} operation - Operation to apply
   * @returns {DocumentState} - Updated document
   */
  async applyOperation(documentId, operation) {
    const doc = this.documents.get(documentId);
    if (!doc) {
      throw new Error('Document not found');
    }

    // Transform against pending operations
    const baseVersion = Number(operation.version) || 0;
    const pendingOps = (this.operations.get(documentId) || []).filter(pendingOp => Number(pendingOp.version) > baseVersion);
    for (const pendingOp of pendingOps) {
      operation.transform(pendingOp);
    }

    // Apply operation
    doc.content = operation.apply(doc.content);
    doc.version++;
    doc.lastModifiedBy = operation.userId;
    doc.lastModifiedAt = operation.timestamp;

    // Store operation
    operation.version = doc.version;
    if (!this.operations.has(documentId)) {
      this.operations.set(documentId, []);
    }
    this.operations.get(documentId).push(operation);

    // Save
    await this.saveDocument(doc);
    await this.saveOperation(operation);

    return doc;
  }

  /**
   * Get operations for document
   * @param {string} documentId - Document ID
   * @param {number} sinceVersion - Since version
   * @returns {Array} - Operations
   */
  getOperations(documentId, sinceVersion = 0) {
    const ops = this.operations.get(documentId) || [];
    return ops.filter(op => op.version > sinceVersion);
  }

  /**
   * Update cursor position
   * @param {string} documentId - Document ID
   * @param {string} userId - User ID
   * @param {number} position - Cursor position
   */
  updateCursor(documentId, userId, position) {
    const key = `${documentId}:${userId}`;
    this.cursors.set(key, {
      documentId,
      userId,
      position,
      updatedAt: new Date().toISOString()
    });
  }

  /**
   * Get cursors for document
   * @param {string} documentId - Document ID
   * @returns {Array} - Cursors
   */
  getCursors(documentId) {
    const cursors = [];
    for (const [, cursor] of this.cursors) {
      if (cursor.documentId === documentId) {
        cursors.push(cursor);
      }
    }
    return cursors;
  }

  /**
   * Remove cursor
   * @param {string} documentId - Document ID
   * @param {string} userId - User ID
   */
  removeCursor(documentId, userId) {
    const key = `${documentId}:${userId}`;
    this.cursors.delete(key);
  }

  /**
   * Save document to storage
   * @param {DocumentState} doc - Document to save
   */
  async saveDocument(doc) {
    try {
      await dPut('collaborative_documents', doc);
    } catch (err) {
      console.error('Failed to save document:', err);
    }
  }

  /**
   * Save operation to storage
   * @param {Operation} op - Operation to save
   */
  async saveOperation(op) {
    try {
      await dPut('collaborative_operations', op);
    } catch (err) {
      console.error('Failed to save operation:', err);
    }
  }

  /**
   * Delete document
   * @param {string} id - Document ID
   */
  async deleteDocument(id) {
    this.documents.delete(id);
    this.operations.delete(id);
    await dDel('collaborative_documents', id);
  }

  /**
   * Get all documents
   * @returns {Array} - Array of documents
   */
  getAllDocuments() {
    return Array.from(this.documents.values());
  }

  /**
   * Get documents by user
   * @param {string} userId - User ID
   * @returns {Array} - User's documents
   */
  getDocumentsByUser(userId) {
    return this.getAllDocuments().filter(d => d.lastModifiedBy === userId);
  }

  /**
   * Merge document changes
   * @param {string} documentId - Document ID
   * @param {string} remoteContent - Remote content
   * @param {number} remoteVersion - Remote version
   * @returns {object} - Merge result
   */
  async mergeChanges(documentId, remoteContent, remoteVersion) {
    const doc = this.documents.get(documentId);
    if (!doc) {
      throw new Error('Document not found');
    }

    // Simple merge strategy: use latest version
    if (remoteVersion > doc.version) {
      doc.content = remoteContent;
      doc.version = remoteVersion;
      await this.saveDocument(doc);
      return { merged: true, conflict: false };
    }

    if (remoteVersion < doc.version) {
      // Remote is behind, send our version
      return { merged: false, conflict: false, needUpdate: true, content: doc.content, version: doc.version };
    }

    // Same version, check for conflicts
    if (remoteContent !== doc.content) {
      return { merged: false, conflict: true, localContent: doc.content, remoteContent };
    }

    return { merged: false, conflict: false, same: true };
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    return {
      totalDocuments: this.documents.size,
      lockedDocuments: Array.from(this.documents.values()).filter(d => d.lockedBy).length,
      totalOperations: Array.from(this.operations.values()).reduce((sum, ops) => sum + ops.length, 0),
      activeCursors: this.cursors.size
    };
  }
}

/**
 * Global collaborative editing manager instance
 */
const collaborativeEditingManager = new CollaborativeEditingManager();

/**
 * Initialize collaborative editing
 */
async function initCollaborativeEditing() {
  await collaborativeEditingManager.init();
  return collaborativeEditingManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.CollaborativeEditing = {
    manager: collaborativeEditingManager,
    init: initCollaborativeEditing,
    createDocument: (config) => collaborativeEditingManager.createDocument(config),
    getDocument: (id) => collaborativeEditingManager.getDocument(id),
    updateDocument: (id, content, userId) => collaborativeEditingManager.updateDocument(id, content, userId),
    lockDocument: (id, userId) => collaborativeEditingManager.lockDocument(id, userId),
    unlockDocument: (id) => collaborativeEditingManager.unlockDocument(id),
    isLocked: (id) => collaborativeEditingManager.isLocked(id),
    getLockOwner: (id) => collaborativeEditingManager.getLockOwner(id),
    applyOperation: (docId, op) => collaborativeEditingManager.applyOperation(docId, op),
    getOperations: (docId, since) => collaborativeEditingManager.getOperations(docId, since),
    updateCursor: (docId, userId, pos) => collaborativeEditingManager.updateCursor(docId, userId, pos),
    getCursors: (docId) => collaborativeEditingManager.getCursors(docId),
    removeCursor: (docId, userId) => collaborativeEditingManager.removeCursor(docId, userId),
    deleteDocument: (id) => collaborativeEditingManager.deleteDocument(id),
    getAllDocuments: () => collaborativeEditingManager.getAllDocuments(),
    getDocumentsByUser: (userId) => collaborativeEditingManager.getDocumentsByUser(userId),
    mergeChanges: (docId, content, version) => collaborativeEditingManager.mergeChanges(docId, content, version),
    getStats: () => collaborativeEditingManager.getStatistics()
  };
}
