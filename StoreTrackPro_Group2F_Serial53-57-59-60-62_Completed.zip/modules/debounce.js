// Debounce Module - Performance optimization for search inputs and API calls

/**
 * Debounce function - delays execution until after wait time has elapsed
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @param {boolean} immediate - Execute immediately on first call
 * @returns {Function} - Debounced function
 */
function debounce(func, wait = 300, immediate = false) {
  let timeout;
  
  return function executedFunction(...args) {
    const context = this;
    const later = () => {
      timeout = null;
      if (!immediate) {func.apply(context, args);}
    };
    
    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    
    if (callNow) {func.apply(context, args);}
  };
}

/**
 * Throttle function - limits execution to once every wait time
 * @param {Function} func - Function to throttle
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} - Throttled function
 */
function throttle(func, wait = 300) {
  let timeout;
  let previous = 0;
  
  return function executedFunction(...args) {
    const context = this;
    const now = Date.now();
    const remaining = wait - (now - previous);
    
    if (remaining <= 0 || remaining > wait) {
      if (timeout) {
        clearTimeout(timeout);
        timeout = null;
      }
      previous = now;
      func.apply(context, args);
    } else if (!timeout) {
      timeout = setTimeout(() => {
        previous = Date.now();
        timeout = null;
        func.apply(context, args);
      }, remaining);
    }
  };
}

/**
 * Debounce manager for managing multiple debounced functions
 */
class DebounceManager {
  constructor() {
    this.debounceMap = new Map();
    this.throttleMap = new Map();
  }
  
  /**
   * Create or get a debounced function
   * @param {string} key - Unique key for the debounced function
   * @param {Function} func - Function to debounce
   * @param {number} wait - Wait time in milliseconds
   * @param {boolean} immediate - Execute immediately on first call
   * @returns {Function} - Debounced function
   */
  debounce(key, func, wait = 300, immediate = false) {
    if (!this.debounceMap.has(key)) {
      this.debounceMap.set(key, debounce(func, wait, immediate));
    }
    return this.debounceMap.get(key);
  }
  
  /**
   * Create or get a throttled function
   * @param {string} key - Unique key for the throttled function
   * @param {Function} func - Function to throttle
   * @param {number} wait - Wait time in milliseconds
   * @returns {Function} - Throttled function
   */
  throttle(key, func, wait = 300) {
    if (!this.throttleMap.has(key)) {
      this.throttleMap.set(key, throttle(func, wait));
    }
    return this.throttleMap.get(key);
  }
  
  /**
   * Clear a specific debounced function
   * @param {string} key - Key of the debounced function
   */
  clearDebounce(key) {
    this.debounceMap.delete(key);
  }
  
  /**
   * Clear a specific throttled function
   * @param {string} key - Key of the throttled function
   */
  clearThrottle(key) {
    this.throttleMap.delete(key);
  }
  
  /**
   * Clear all debounced and throttled functions
   */
  clearAll() {
    this.debounceMap.clear();
    this.throttleMap.clear();
  }
}

/**
 * Global debounce manager instance
 */
const debounceManager = new DebounceManager();

/**
 * Apply debounce to search input
 * @param {string} selector - CSS selector for search input
 * @param {Function} callback - Callback function
 * @param {number} wait - Wait time in milliseconds
 */
function applySearchDebounce(selector, callback, wait = 300) {
  const input = document.querySelector(selector);
  if (!input) {return;}
  
  const debouncedCallback = debounceManager.debounce(
    `search-${selector}`,
    callback,
    wait
  );
  
  input.addEventListener('input', (e) => {
    debouncedCallback(e.target.value);
  });
  
  return debouncedCallback;
}

/**
 * Apply throttle to scroll event
 * @param {Function} callback - Callback function
 * @param {number} wait - Wait time in milliseconds
 */
function applyScrollThrottle(callback, wait = 100) {
  const throttledCallback = debounceManager.throttle(
    'scroll',
    callback,
    wait
  );
  
  window.addEventListener('scroll', throttledCallback, { passive: true });
  
  return throttledCallback;
}

/**
 * Apply throttle to resize event
 * @param {Function} callback - Callback function
 * @param {number} wait - Wait time in milliseconds
 */
function applyResizeThrottle(callback, wait = 200) {
  const throttledCallback = debounceManager.throttle(
    'resize',
    callback,
    wait
  );
  
  window.addEventListener('resize', throttledCallback);
  
  return throttledCallback;
}

/**
 * Cancel pending debounce/throttle operations
 * @param {string} key - Key to cancel
 */
function cancel(key) {
  debounceManager.clearDebounce(key);
  debounceManager.clearThrottle(key);
}

/**
 * Cancel all pending operations
 */
function cancelAll() {
  debounceManager.clearAll();
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.Debounce = {
    debounce,
    throttle,
    manager: debounceManager,
    applySearchDebounce,
    applyScrollThrottle,
    applyResizeThrottle,
    cancel,
    cancelAll
  };
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { debounce, throttle, DebounceManager, cancel, cancelAll };
}
