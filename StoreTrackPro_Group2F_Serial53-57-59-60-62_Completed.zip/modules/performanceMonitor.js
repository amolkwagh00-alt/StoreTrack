/**
 * StoreTrack local performance budgets.
 *
 * Privacy: keeps numeric durations and fixed category names in bounded memory only.
 * Never stores labels, URLs, input values, or other user data, and never sends data.
 *
 * Explicit instrumentation API (available as window.performanceMonitor):
 *   mark(name, { category }) -> mark token
 *   measure(name, startToken, endToken, { category }) -> duration or null
 *   record(name, durationMs, { category }) -> duration or null
 *   summary() -> counts/average/p95/exceedances per category (also console.info)
 * Category names are fixed allow-listed budgets; names supplied as `name` are not
 * retained. Configuration may be set before this script as
 * window.STORETRACK_PERFORMANCE_CONFIG = { enabled: true, maxSamples: 200,
 *   thresholds: { filter: 250 } }. Unsupported browser APIs degrade to safe no-ops.
 */
(function (root) {
  'use strict';

  const DEFAULT_THRESHOLDS = Object.freeze({
    acknowledgement: 100,
    screen: 1000,
    stockStatus: 2000,
    stockStatusLarge: 5000,
    filter: 300,
    filterLarge: 1000,
    localSave: 1000,
    centralCommit: 2000,
    centralPush: 2000,
    exportSmall: 3000
  });
  const CATEGORIES = new Set(Object.keys(DEFAULT_THRESHOLDS));
  const MAX_SAMPLE_LIMIT = 1000;
  const LABELS = Object.freeze({
    acknowledgement: 'input acknowledgement / next paint',
    screen: 'ordinary screen usable',
    stockStatus: 'Stock Status (normal data)',
    stockStatusLarge: 'Stock Status (large data)',
    filter: 'search/filter',
    filterLarge: 'search/filter (large data)',
    localSave: 'local save',
    centralCommit: 'central LAN commit',
    centralPush: 'central push-to-render',
    exportSmall: 'small export'
  });

  function createMonitor(host, config) {
    config = config && typeof config === 'object' ? config : {};
    const enabled = config.enabled !== false;
    const capacity = Number.isFinite(config.maxSamples)
      ? Math.max(1, Math.min(MAX_SAMPLE_LIMIT, Math.floor(config.maxSamples)))
      : 200;
    const thresholds = Object.assign({}, DEFAULT_THRESHOLDS);
    if (config.thresholds && typeof config.thresholds === 'object') {
      for (const key of CATEGORIES) {
        const value = config.thresholds[key];
        if (Number.isFinite(value) && value >= 0) thresholds[key] = value;
      }
    }
    const samples = [];
    const marks = new Map();
    const now = () => {
      try {
        return host && host.performance && typeof host.performance.now === 'function'
          ? host.performance.now() : Date.now();
      } catch (_) { return Date.now(); }
    };

    function normalizeCategory(category) {
      return CATEGORIES.has(category) ? category : 'acknowledgement';
    }

    function record(name, duration, options) {
      if (!enabled || !Number.isFinite(duration) || duration < 0) return null;
      const category = normalizeCategory(options && options.category);
      const sample = { category, duration, timestamp: Date.now() };
      samples.push(sample);
      if (samples.length > capacity) samples.splice(0, samples.length - capacity);
      if (duration > thresholds[category] && host && host.console && typeof host.console.warn === 'function') {
        host.console.warn(`[Performance budget] ${LABELS[category]} exceeded: ${duration.toFixed(1)}ms (target ${thresholds[category]}ms)`);
      }
      // Publish only an allow-listed category and numeric duration; never expose
      // caller-provided labels, URLs, or other potentially identifying text.
      try {
        if (host && host.eventBus && typeof host.eventBus.emit === 'function') {
          host.eventBus.emit('PERFORMANCE_METRIC', { name: category, type: 'performance', value: duration, unit: 'ms' });
        }
      } catch (_) { /* telemetry is optional and must not break the measured path */ }
      return duration;
    }

    function recordMetric(metric) {
      if (!metric || typeof metric !== 'object') return null;
      const value = Number(metric.value);
      if (!Number.isFinite(value) || value < 0) return null;
      return record(metric.name, value, { category: metric.category });
    }

    function mark(name, options) {
      if (!enabled) return null;
      const token = `local-mark-${marks.size + 1}`;
      marks.set(token, { at: now(), category: normalizeCategory(options && options.category) });
      if (marks.size > capacity) marks.delete(marks.keys().next().value);
      return token;
    }

    function measure(name, startToken, endToken, options) {
      if (!enabled) return null;
      const start = marks.get(startToken);
      const end = endToken ? marks.get(endToken) : { at: now() };
      if (!start || !end || end.at < start.at) return null;
      const category = options && options.category || start.category;
      marks.delete(startToken);
      if (endToken) marks.delete(endToken);
      return record(name, end.at - start.at, { category });
    }

    function summary() {
      const result = {};
      for (const category of CATEGORIES) {
        const values = samples.filter(item => item.category === category).map(item => item.duration).sort((a, b) => a - b);
        if (!values.length) continue;
        result[category] = {
          count: values.length,
          averageMs: values.reduce((sum, value) => sum + value, 0) / values.length,
          p95Ms: values[Math.min(values.length - 1, Math.ceil(values.length * 0.95) - 1)],
          thresholdMs: thresholds[category],
          exceedances: values.filter(value => value > thresholds[category]).length
        };
      }
      if (host && host.console && typeof host.console.info === 'function') {
        host.console.info('[Performance budget] local summary', result);
      }
      return result;
    }

    function classify(target) {
      let node = target;
      for (let i = 0; node && i < 8; i++, node = node.parentElement) {
        const text = `${node.id || ''} ${node.getAttribute ? node.getAttribute('aria-label') || '' : ''} ${node.getAttribute ? node.getAttribute('data-onclick') || '' : ''}`.toLowerCase();
        if (/stock-zero|stock status/.test(text)) return 'stockStatus';
        if (/filter|search|query/.test(text) || /^(INPUT|SELECT|TEXTAREA)$/.test(node.tagName || '')) return 'filter';
        if (node.classList && (node.classList.contains('ni') || node.classList.contains('sb-toggle'))) return 'screen';
      }
      return 'acknowledgement';
    }

    if (enabled && host && typeof host.PerformanceObserver === 'function') {
      try {
        const observer = new host.PerformanceObserver(list => {
          for (const entry of list.getEntries()) {
            if (!Number.isFinite(entry.duration) || entry.duration < 0) continue;
            const category = classify(entry.target);
            record('event-timing', entry.duration, { category });
          }
        });
        // Chromium requires at least 16 ms for event timing entries; a value of
        // zero throws and would silently disable all automatic click metrics.
        observer.observe({ type: 'event', buffered: true, durationThreshold: 16 });
      } catch (_) {
        // Event Timing is optional; explicit API remains available without it.
      }
    }

    return Object.freeze({
      enabled,
      thresholds: Object.freeze(thresholds),
      mark,
      measure,
      record,
      recordMetric,
      summary,
      getSamples: () => samples.map(sample => Object.assign({}, sample)),
      clear: () => { samples.length = 0; marks.clear(); },
      classifyTarget: classify
    });
  }

  const monitor = createMonitor(root, root && root.STORETRACK_PERFORMANCE_CONFIG);
  if (root) {
    root.PerformanceBudgetMonitor = createMonitor;
    root.performanceMonitor = monitor;
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = { createMonitor, performanceMonitor: monitor, DEFAULT_THRESHOLDS };
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
