/* eslint-disable curly */
(function () {
  'use strict';
  const META_ID = 'central-sync';
  let running = false;
  let started = false;
  let healthTimer = null;
  let flushTimer = null;
  let pullTimer = null;
  let eventHandler = null;
  let eventChain = Promise.resolve();
  let healthFlight = null;
  let pullFlight = null;
  const MAX_QUEUE_ATTEMPTS = 10;
  const QUEUE_BACKOFF_MS = [5000, 15000, 30000, 60000, 120000, 300000];
  const perfNow = () => { try { return performance.now(); } catch (_) { return Date.now(); } };
  const recordPerf = (category, startedAt) => {
    try { window.performanceMonitor?.record('central-sync', perfNow() - startedAt, { category }); }
    catch (_) { /* Performance instrumentation must never affect synchronization. */ }
  };

  async function readMeta() {
    return (await gOne('central_meta', META_ID)) || { id: META_ID, baseUrl: '', lastSequence: 0 };
  }
  async function writeMeta(patch) {
    const next = { ...(await readMeta()), ...patch, id: META_ID };
    await dPut('central_meta', next);
    return next;
  }
  async function queueTransaction(transaction, error) {
    await dPut('central_queue', { id: transaction.id, transaction, status: 'queued', attempts: 0, nextAttemptAt: 0, lastError: error?.message || null, queuedAt: new Date().toISOString() });
    return { ok: false, queued: true, transaction };
  }
  async function recordConflict(item, error) {
    item.status = 'conflict';
    item.lastError = error?.message || 'Central rejected this transaction';
    item.errorStatus = Number(error?.statusCode) || null;
    item.conflictAt = new Date().toISOString();
    item.nextAttemptAt = null;
    item.conflictBody = error?.body && typeof error.body === 'object' ? error.body : null;
    await dPut('central_queue', item);
    window.dispatchEvent(new CustomEvent('central-sync-conflict', { detail: { id: item.id, message: item.lastError, statusCode: item.errorStatus } }));
  }
  async function getQueueItems(status) {
    try { return (await gAll('central_queue')).filter(item => !status || item.status === status); }
    catch (_) { return []; }
  }
  async function queueCount() { return (await getQueueItems()).filter(item => ['queued', 'failed', 'conflict'].includes(item.status)).length; }
  async function queueDetails() {
      try { return (await gAll('central_queue')).filter(item => ['queued', 'failed', 'conflict'].includes(item.status)).slice(0, 10).map(item => ({ id: item.id, status: item.status, attempts: item.attempts || 0, error: item.lastError || 'not attempted' })); }
    catch (_) { return []; }
  }
  function publishHealth(status) {
    window.centralHealth = status;
    window.dispatchEvent(new CustomEvent('central-health-update', { detail: status }));
    const label = document.getElementById('central-status');
    if (label) {
      label.textContent = status.state === 'online' ? `Online · ${status.latencyMs ?? '--'} ms` : status.state === 'degraded' ? `Degraded · ${status.latencyMs ?? '--'} ms` : status.configured ? 'Offline' : 'Not configured';
      label.style.color = status.state === 'online' ? 'var(--gn)' : status.state === 'degraded' ? 'var(--am)' : 'var(--tx3)';
    }
  }
  function checkHealth() {
    if (healthFlight) return healthFlight;
    healthFlight = (async () => {
    if (!window.centralBridge) return { configured: false, online: false, state: 'offline', queueCount: await queueCount() };
    try {
      const result = await window.centralBridge.getStatus();
      const localMeta = await readMeta();
      const pending = await queueCount();
      const state = !result.configured ? 'offline' : !result.online ? 'offline' : Number(result.latencyMs) > 1000 ? 'degraded' : 'online';
      const identity = { deviceId: result.deviceId || window.location?.hostname || 'unknown-device', appVersion: result.appVersion || window.CONST?.APP?.VERSION || 'unknown' };
      const health = { ...result, ...identity, lastSyncAt: localMeta.lastSyncAt || null, lastSequence: Math.max(Number(result.lastSequence)||0, Number(localMeta.lastSequence)||0), state, queueCount: pending, queueDetails: await queueDetails(), checkedAt: new Date().toISOString() };
      await writeMeta({ ...identity, lastHealth: health }); publishHealth(health); return health;
    } catch (error) {
      const localMeta = await readMeta();
      const health = { configured: true, online: false, state: 'offline', error: error.message, deviceId: localMeta.deviceId || window.location?.hostname || 'unknown-device', appVersion: localMeta.appVersion || window.CONST?.APP?.VERSION || 'unknown', lastSyncAt: localMeta.lastSyncAt || null, lastSequence: Number(localMeta.lastSequence)||0, queueCount: await queueCount(), queueDetails: await queueDetails(), checkedAt: new Date().toISOString() };
      await writeMeta({ lastHealth: health }); publishHealth(health); return health;
    }
    })().finally(() => { healthFlight = null; });
    return healthFlight;
  }
  async function applyMaterial(material) {
    if (!material || material.id == null) return;
    const local = await gOne('materials', material.id);
    const merged = { ...(local || {}), ...material, stock: Number(material.stock), updatedAt: material.updatedAt || material.updated_at, lowAlert: material.lowAlert ?? local?.lowAlert, reorderQty: material.reorderQty ?? local?.reorderQty };
    await dPut('materials', merged);
    if (Array.isArray(window.M)) { const index = window.M.findIndex(item => String(item.id) === String(merged.id)); if (index >= 0) window.M[index] = merged; else window.M.push(merged); }
  }
  async function reconcileResponse(result) {
    if (result.material) await applyMaterial(result.material);
    if (result.sequence) await writeMeta({ lastSequence: Number(result.sequence) });
    if (result.transaction) await dPut('transactions', result.transaction);
    return result;
  }
  async function submit(transaction) {
    if (transaction?.historical || transaction?.importBatchId || transaction?.type === 'Historical Consumption') return { ok: false, queued: false, skipped: true, reason: 'historical-local-only' };
    const enriched = { ...transaction, deviceId: transaction.deviceId || window.location.hostname, status: transaction.status || 'confirmed' };
    if (!window.centralBridge) return { ok: false, queued: false, skipped: true };
    const startedAt = perfNow();
    let commitMeasured = false;
    try {
      const response = await window.centralBridge.commitStock(enriched);
      recordPerf('centralCommit', startedAt);
      commitMeasured = true;
      return await reconcileResponse(response);
    }
    catch (error) {
      if (!commitMeasured) recordPerf('centralCommit', startedAt);
      if (Number(error?.statusCode) === 409) {
        const item = { id: enriched.id, transaction: enriched, status: 'conflict', attempts: 0, queuedAt: new Date().toISOString() };
        await recordConflict(item, error);
        return { ok: false, conflict: true, transaction: enriched, error: error.message };
      }
      if (error?.message?.includes('Central server is not configured') || error?.message?.includes('Failed to fetch') || error?.message?.includes('fetch failed') || error?.statusCode == null || error.statusCode >= 500) return queueTransaction(enriched, error);
      throw error;
    }
  }
  async function flushQueue() {
    if (running || !window.centralBridge) return;
    running = true;
    try {
      const now = Date.now();
      const queued = (await getQueueItems('queued')).filter(item => !item.nextAttemptAt || Number(item.nextAttemptAt) <= now).sort((a, b) => String(a.queuedAt).localeCompare(String(b.queuedAt)));
      let hadError = false;
      for (const item of queued) {
        if (item.transaction?.historical || item.transaction?.importBatchId || item.transaction?.type === 'Historical Consumption') { await dDel('central_queue', item.id); continue; }
        try { await reconcileResponse(await window.centralBridge.commitStock(item.transaction)); await dDel('central_queue', item.id); }
        catch (error) {
          hadError = true;
          item.attempts = Number(item.attempts || 0) + 1; item.lastError = error.message || String(error);
          if (Number(error?.statusCode) === 409) { await recordConflict(item, error); continue; }
          if (item.attempts >= MAX_QUEUE_ATTEMPTS) { item.status = 'failed'; delete item.nextAttemptAt; }
          else { const base = QUEUE_BACKOFF_MS[Math.min(item.attempts - 1, QUEUE_BACKOFF_MS.length - 1)]; item.nextAttemptAt = Date.now() + Math.min(300000, Math.round(base * (0.8 + Math.random() * 0.4))); }
          await dPut('central_queue', item);
          if (item.status === 'failed' && Number(item.attempts) === MAX_QUEUE_ATTEMPTS) {
            window.dispatchEvent(new CustomEvent('central-sync-failed', { detail: { id: item.id, message: item.lastError, attempts: item.attempts } }));
          }
          if (item.status === 'failed' || (error.statusCode && error.statusCode < 500)) continue;
        }
      }
      if (hadError) await checkHealth();
    } finally { running = false; }
  }
  function pullChanges() {
    if (pullFlight) return pullFlight;
    if (!window.centralBridge) return Promise.resolve();
    pullFlight = (async () => { try {
    const meta = await readMeta();
    const result = await window.centralBridge.pullChanges(meta.lastSequence || 0);
    let changed = false;
    for (const change of result.changes || []) {
      const sequence = Number(change.sequence);
      const current = Number((await readMeta()).lastSequence || 0);
      if (!Number.isFinite(sequence) || sequence <= current) continue;
      if (change.payload?.material) await applyMaterial(change.payload.material);
      if (change.payload?.transaction) await dPut('transactions', change.payload.transaction);
      await writeMeta({ lastSequence: sequence });
      changed = true;
    }
    const cursor = Number(result.cursor);
    const current = Number((await readMeta()).lastSequence || 0);
    if (Number.isFinite(cursor) && cursor > current) await writeMeta({ lastSequence: cursor });
    await writeMeta({ lastSyncAt: new Date().toISOString() });
    if (changed && typeof window.renderMaster === 'function') window.renderMaster();
    if (changed && typeof window.updateDash === 'function') window.updateDash();
    return result;
    } catch (error) { await checkHealth(); throw error; }
    finally { pullFlight = null; } })();
    return pullFlight;
  }
  async function getFailedQueueItems() { return getQueueItems('failed'); }
  async function getConflictQueueItems() { return getQueueItems('conflict'); }
  async function discardConflict(id) {
    const item = (await getConflictQueueItems()).find(row => String(row.id) === String(id));
    if (!item) return { ok: false, reason: 'not-found' };
    await dDel('central_queue', item.id);
    return { ok: true, discarded: item.id };
  }
  async function resolveConflict(id, correctedTransaction) {
    const item = (await getConflictQueueItems()).find(row => String(row.id) === String(id));
    if (!item) return { ok: false, reason: 'not-found' };
    if (!correctedTransaction || correctedTransaction.itemId == null || !Number.isFinite(Number(correctedTransaction.qty)) || Number(correctedTransaction.qty) <= 0) throw new Error('A corrected transaction with itemId and positive quantity is required');
    if (String(correctedTransaction.itemId) !== String(item.transaction?.itemId)) throw new Error('Conflict resolution cannot change the original material; discard it and create a new transaction instead');
    const newId = String(correctedTransaction.id || '');
    if (!newId || newId === String(item.id)) throw new Error('Conflict resolution requires a new transaction ID');
    const result = await submit({ ...item.transaction, ...correctedTransaction, id: newId, status: 'confirmed' });
    if (!result?.queued && result?.ok !== false) await dDel('central_queue', item.id);
    return { ...result, resolvedFrom: item.id };
  }
  async function retryFailedQueueItem(id) {
    const failed = await getQueueItems('failed');
    const selected = id == null ? failed : failed.filter(item => String(item.id) === String(id));
    for (const item of selected) { item.status = 'queued'; item.attempts = 0; item.nextAttemptAt = 0; item.lastError = null; await dPut('central_queue', item); }
    if (selected.length) await flushQueue();
    return { retried: selected.length, items: selected.map(item => item.id) };
  }
  async function applyIncomingEvent(event) {
    const startedAt = perfNow();
    const incoming = event?.event; if (!incoming) return;
    const meta = await readMeta(); const sequence = Number(incoming.sequence); const lastSequence = Number(meta.lastSequence || 0);
    if (!Number.isFinite(sequence) || sequence <= lastSequence) return;
    if (sequence !== lastSequence + 1) { await pullChanges(); return; }
    if (incoming.payload?.material) await applyMaterial(incoming.payload.material);
    if (incoming.payload?.transaction) await dPut('transactions', incoming.payload.transaction);
    await writeMeta({ lastSequence: sequence, lastSyncAt: new Date().toISOString() });
    if (typeof window.renderMaster === 'function') window.renderMaster();
    if (typeof window.updateDash === 'function') window.updateDash();
    recordPerf('centralPush', startedAt);
  }
  async function syncMaterials(materials) {
    if (!window.centralBridge?.upsertMaterial || !Array.isArray(materials)) return { synced: 0, skipped: true };
    let synced = 0;
    for (const material of materials) {
      if (!material?.id || !material?.barcode || !material?.name) continue;
      await window.centralBridge.upsertMaterial({ id: String(material.id), barcode: String(material.barcode), name: String(material.name), category: material.category, unit: material.unit, stock: material.stock, lowAlert: material.lowAlert, reorderQty: material.reorderQty, unitCost: material.unitCost, hsn: material.hsn, location: material.location, binLocationId: material.binLocationId, photo: material.photo, specs: material.specs, active: material.active !== false }); synced += 1;
    }
    return { synced };
  }
  async function syncUsers(users) {
    if (!window.centralBridge?.syncUsers || !Array.isArray(users)) return { synced: 0, skipped: true };
    const safeUsers = users.slice(0, 500).map(user => ({ username: user?.username, name: user?.name, role: user?.role, active: user?.active !== false, passwordHash: user?.passwordHash })).filter(user => user.username && user.passwordHash);
    return window.centralBridge.syncUsers(safeUsers);
  }
  async function start() {
    if (started || !window.centralBridge) return;
    const status = await checkHealth(); if (!status?.configured) return;
    started = true;
    eventHandler = event => { eventChain = eventChain.then(() => applyIncomingEvent(event)).catch(error => console.error('[centralSync:event]', error)); };
    window.centralBridge.onEvent(eventHandler); window.addEventListener('online', flushQueue);
    if (healthTimer) clearInterval(healthTimer); healthTimer = setInterval(checkHealth, 30000);
    if (flushTimer) clearInterval(flushTimer); flushTimer = setInterval(flushQueue, 5000);
    if (pullTimer) clearInterval(pullTimer); pullTimer = setInterval(() => pullChanges().catch(error => publishHealth({ configured: true, online: false, state: 'offline', error: error.message, checkedAt: new Date().toISOString() })), 15000);
    await flushQueue(); await pullChanges().catch(() => {});
  }
  function stop() {
    if (!started) return; started = false;
    if (healthTimer) clearInterval(healthTimer); if (flushTimer) clearInterval(flushTimer); if (pullTimer) clearInterval(pullTimer);
    healthTimer = flushTimer = pullTimer = null; window.removeEventListener('online', flushQueue); window.centralBridge?.removeListeners?.(); eventHandler = null; eventChain = Promise.resolve();
  }
  window.centralSync = { start, stop, submit, flushQueue, pullChanges, syncMaterials, syncUsers, applyMaterial, readMeta, writeMeta, checkHealth, getQueueItems, getFailedQueueItems, getConflictQueueItems, discardConflict, resolveConflict, retryFailedQueueItem };
  window.addEventListener('DOMContentLoaded', () => start().catch(error => console.error('[centralSync]', error)));
})();
