/**
 * Enterprise Lazy Loader
 * Lazy loading utilities for StoreTrack Pro
 */

class LazyLoadConfigV2 {
  constructor(config) {
    this.selector = config.selector || '.lazy-load';
    this.threshold = config.threshold || 0.1;
    this.rootMargin = config.rootMargin || '0px';
    this.placeholder = config.placeholder || null;
    this.fadeIn = config.fadeIn !== false;
    this.fadeInDuration = config.fadeInDuration || 300;
  }
}

class LazyLoaderV2 {
  constructor(config = {}) {
    this.config = new LazyLoadConfigV2(config);
    this.observer = null;
    this.loadedElements = new Set();
    this.init();
  }

  /**
   * Initialize lazy loader
   */
  init() {
    if (typeof window === 'undefined' || !('IntersectionObserver' in window)) {
      console.warn('IntersectionObserver not supported, falling back to immediate loading');
      this.loadAll();
      return;
    }

    this.setupObserver();
    this.observeElements();
  }

  /**
   * Setup IntersectionObserver
   */
  setupObserver() {
    this.observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            this.loadElement(entry.target);
            this.observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: this.config.threshold,
        rootMargin: this.config.rootMargin
      }
    );
  }

  /**
   * Observe elements
   */
  observeElements() {
    const elements = document.querySelectorAll(this.config.selector);
    elements.forEach(element => {
      if (!this.loadedElements.has(element)) {
        this.observer.observe(element);
      }
    });
  }

  /**
   * Load element
   * @param {HTMLElement} element - Element to load
   */
  loadElement(element) {
    if (this.loadedElements.has(element)) {return;}

    const src = element.dataset.src;
    const srcset = element.dataset.srcset;
    const bg = element.dataset.bg;

    if (src) {
      element.src = src;
    }

    if (srcset) {
      element.srcset = srcset;
    }

    if (bg) {
      element.style.backgroundImage = `url(${bg})`;
    }

    if (this.config.fadeIn) {
      element.style.opacity = '0';
      element.style.transition = `opacity ${this.config.fadeInDuration}ms ease-in`;
      
      requestAnimationFrame(() => {
        element.style.opacity = '1';
      });
    }

    element.classList.add('loaded');
    this.loadedElements.add(element);

    // Emit event
    if (typeof window !== 'undefined' && window.eventBus) {
      window.eventBus.emit('LAZY_ELEMENT_LOADED', { element });
    }
  }

  /**
   * Load all elements immediately
   */
  loadAll() {
    const elements = document.querySelectorAll(this.config.selector);
    elements.forEach(element => {
      this.loadElement(element);
    });
  }

  /**
   * Update config
   * @param {object} config - New config
   */
  updateConfig(config) {
    this.config = new LazyLoadConfigV2({ ...this.config, ...config });
    
    if (this.observer) {
      this.observer.disconnect();
      this.setupObserver();
      this.observeElements();
    }
  }

  /**
   * Add new elements to observe
   * @param {string} selector - CSS selector
   */
  addElements(selector) {
    const elements = document.querySelectorAll(selector);
    elements.forEach(element => {
      if (!this.loadedElements.has(element)) {
        this.observer.observe(element);
      }
    });
  }

  /**
   * Destroy lazy loader
   */
  destroy() {
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
    this.loadedElements.clear();
  }
}

class LazyModuleLoader {
  constructor() {
    this.loadedModules = new Map();
    this.loadingModules = new Map();
  }

  /**
   * Load module dynamically
   * @param {string} moduleName - Module name
   * @param {Function} loader - Loader function
   * @returns {Promise<*>} Loaded module
   */
  async loadModule(moduleName, loader) {
    // Return cached module if already loaded
    if (this.loadedModules.has(moduleName)) {
      return this.loadedModules.get(moduleName);
    }

    // Return loading promise if currently loading
    if (this.loadingModules.has(moduleName)) {
      return this.loadingModules.get(moduleName);
    }

    // Load module
    const loadingPromise = loader().then(module => {
      this.loadedModules.set(moduleName, module);
      this.loadingModules.delete(moduleName);
      
      // Emit event
      if (typeof window !== 'undefined' && window.eventBus) {
        window.eventBus.emit('MODULE_LOADED', { moduleName });
      }
      
      return module;
    }).catch(err => {
      this.loadingModules.delete(moduleName);
      throw err;
    });

    this.loadingModules.set(moduleName, loadingPromise);
    return loadingPromise;
  }

  /**
   * Preload module
   * @param {string} moduleName - Module name
   * @param {Function} loader - Loader function
   */
  async preloadModule(moduleName, loader) {
    try {
      await this.loadModule(moduleName, loader);
    } catch (err) {
      console.error(`Failed to preload module ${moduleName}:`, err);
    }
  }

  /**
   * Check if module is loaded
   * @param {string} moduleName - Module name
   * @returns {boolean} Is loaded
   */
  isLoaded(moduleName) {
    return this.loadedModules.has(moduleName);
  }

  /**
   * Check if module is loading
   * @param {string} moduleName - Module name
   * @returns {boolean} Is loading
   */
  isLoading(moduleName) {
    return this.loadingModules.has(moduleName);
  }

  /**
   * Unload module
   * @param {string} moduleName - Module name
   */
  unloadModule(moduleName) {
    this.loadedModules.delete(moduleName);
    this.loadingModules.delete(moduleName);
  }

  /**
   * Clear all modules
   */
  clear() {
    this.loadedModules.clear();
    this.loadingModules.clear();
  }

  /**
   * Get loaded modules
   * @returns {Array<string>} Loaded module names
   */
  getLoadedModules() {
    return Array.from(this.loadedModules.keys());
  }
}

class LazyImageLoader {
  constructor() {
    this.imageCache = new Map();
  }

  /**
   * Load image
   * @param {string} src - Image source
   * @returns {Promise<HTMLImageElement>} Loaded image
   */
  loadImage(src) {
    // Return cached image if available
    if (this.imageCache.has(src)) {
      return Promise.resolve(this.imageCache.get(src));
    }

    return new Promise((resolve, reject) => {
      const img = new Image();
      
      img.onload = () => {
        this.imageCache.set(src, img);
        resolve(img);
      };
      
      img.onerror = () => {
        reject(new Error(`Failed to load image: ${src}`));
      };
      
      img.src = src;
    });
  }

  /**
   * Preload images
   * @param {Array<string>} srcs - Image sources
   * @returns {Promise<Array<HTMLImageElement>>} Loaded images
   */
  async preloadImages(srcs) {
    const promises = srcs.map(src => this.loadImage(src));
    return Promise.all(promises);
  }

  /**
   * Clear image cache
   */
  clearCache() {
    this.imageCache.clear();
  }

  /**
   * Get cache size
   * @returns {number} Cache size
   */
  getCacheSize() {
    return this.imageCache.size;
  }
}

class LazyComponentLoader {
  constructor() {
    this.components = new Map();
    this.loadedComponents = new Map();
  }

  /**
   * Register component
   * @param {string} name - Component name
   * @param {Function} loader - Loader function
   */
  registerComponent(name, loader) {
    this.components.set(name, loader);
  }

  /**
   * Load component
   * @param {string} name - Component name
   * @returns {Promise<*>} Loaded component
   */
  async loadComponent(name) {
    // Return cached component if already loaded
    if (this.loadedComponents.has(name)) {
      return this.loadedComponents.get(name);
    }

    const loader = this.components.get(name);
    if (!loader) {
      throw new Error(`Component ${name} not registered`);
    }

    const component = await loader();
    this.loadedComponents.set(name, component);
    
    // Emit event
    if (typeof window !== 'undefined' && window.eventBus) {
      window.eventBus.emit('COMPONENT_LOADED', { componentName: name });
    }
    
    return component;
  }

  /**
   * Preload component
   * @param {string} name - Component name
   */
  async preloadComponent(name) {
    try {
      await this.loadComponent(name);
    } catch (err) {
      console.error(`Failed to preload component ${name}:`, err);
    }
  }

  /**
   * Preload multiple components
   * @param {Array<string>} names - Component names
   */
  async preloadComponents(names) {
    const promises = names.map(name => this.preloadComponent(name));
    await Promise.all(promises);
  }

  /**
   * Check if component is loaded
   * @param {string} name - Component name
   * @returns {boolean} Is loaded
   */
  isLoaded(name) {
    return this.loadedComponents.has(name);
  }

  /**
   * Unload component
   * @param {string} name - Component name
   */
  unloadComponent(name) {
    this.loadedComponents.delete(name);
  }

  /**
   * Get registered components
   * @returns {Array<string>} Component names
   */
  getRegisteredComponents() {
    return Array.from(this.components.keys());
  }

  /**
   * Get loaded components
   * @returns {Array<string>} Loaded component names
   */
  getLoadedComponents() {
    return Array.from(this.loadedComponents.keys());
  }
}

// Global instances
const lazyLoader = new LazyLoaderV2();
const lazyModuleLoader = new LazyModuleLoader();
const lazyImageLoader = new LazyImageLoader();
const lazyComponentLoader = new LazyComponentLoader();

// Expose to window
if (typeof window !== 'undefined') {
  window.LazyLoaderV2 = LazyLoaderV2;
  window.lazyLoader = lazyLoader;
  window.LazyModuleLoader = LazyModuleLoader;
  window.lazyModuleLoader = lazyModuleLoader;
  window.LazyImageLoader = LazyImageLoader;
  window.lazyImageLoader = lazyImageLoader;
  window.LazyComponentLoader = LazyComponentLoader;
  window.lazyComponentLoader = lazyComponentLoader;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    LazyLoaderV2,
    lazyLoader,
    LazyModuleLoader,
    lazyModuleLoader,
    LazyImageLoader,
    lazyImageLoader,
    LazyComponentLoader,
    lazyComponentLoader
  };
}
