/**
 * Machine Learning Demand Prediction Module
 * Uses statistical models and time series analysis for inventory demand forecasting
 */

class MLDemandPrediction {
  constructor() {
    this.models = {
      simpleMovingAverage: this.simpleMovingAverage.bind(this),
      weightedMovingAverage: this.weightedMovingAverage.bind(this),
      exponentialSmoothing: this.exponentialSmoothing.bind(this),
      linearRegression: this.linearRegression.bind(this),
      seasonalDecomposition: this.seasonalDecomposition.bind(this)
    };
    
    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    this.trainingData = [];
    this.modelAccuracy = new Map();
  }

  /**
   * Train prediction model with historical data
   * @param {Array} historicalData - Array of historical demand data
   * @param {string} modelType - Type of model to train
   */
  trainModel(historicalData, modelType = 'exponentialSmoothing') {
    if (!Array.isArray(historicalData) || historicalData.length < 3) {
      throw new Error('Insufficient historical data for training');
    }

    this.trainingData = historicalData;
    
    // Calculate model accuracy using cross-validation
    const accuracy = this.calculateModelAccuracy(historicalData, modelType);
    this.modelAccuracy.set(modelType, accuracy);
    
    return {
      modelType,
      trained: true,
      accuracy,
      dataPoints: historicalData.length
    };
  }

  /**
   * Predict demand for future periods
   * @param {number} periods - Number of periods to predict
   * @param {string} modelType - Prediction model to use
   * @returns {Array} Predicted demand values
   */
  predictDemand(periods = 7, modelType = 'exponentialSmoothing') {
    if (this.trainingData.length === 0) {
      throw new Error('Model not trained. Call trainModel() first.');
    }

    const cacheKey = `${modelType}_${periods}_${this.trainingData.length}`;
    const cached = this.cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
      return cached.predictions;
    }

    const model = this.models[modelType];
    if (!model) {
      throw new Error(`Unknown model type: ${modelType}`);
    }

    const predictions = model(this.trainingData, periods);
    
    this.cache.set(cacheKey, {
      predictions,
      timestamp: Date.now()
    });

    return predictions;
  }

  /**
   * Simple Moving Average prediction
   */
  simpleMovingAverage(data, periods) {
    const windowSize = Math.min(7, data.length);
    const predictions = [];
    
    for (let i = 0; i < periods; i++) {
      const recentData = data.slice(-windowSize);
      const avg = recentData.reduce((sum, val) => sum + val, 0) / recentData.length;
      predictions.push(Math.round(avg));
      data.push(avg); // Add prediction for next iteration
    }
    
    return predictions;
  }

  /**
   * Weighted Moving Average prediction
   */
  weightedMovingAverage(data, periods) {
    const windowSize = Math.min(7, data.length);
    const weights = Array.from({ length: windowSize }, (_, i) => i + 1);
    const totalWeight = weights.reduce((sum, w) => sum + w, 0);
    const predictions = [];
    
    for (let i = 0; i < periods; i++) {
      const recentData = data.slice(-windowSize);
      const weightedSum = recentData.reduce((sum, val, idx) => sum + (val * weights[idx]), 0);
      const avg = weightedSum / totalWeight;
      predictions.push(Math.round(avg));
      data.push(avg);
    }
    
    return predictions;
  }

  /**
   * Exponential Smoothing prediction
   */
  exponentialSmoothing(data, periods, alpha = 0.3) {
    const predictions = [];
    let smoothed = data[0];
    
    // Apply exponential smoothing to historical data
    for (let i = 1; i < data.length; i++) {
      smoothed = alpha * data[i] + (1 - alpha) * smoothed;
    }
    
    // Generate predictions
    for (let i = 0; i < periods; i++) {
      predictions.push(Math.round(smoothed));
      // For simplicity, use last smoothed value as prediction
      // In production, you'd use trend and seasonality components
    }
    
    return predictions;
  }

  /**
   * Linear Regression prediction
   */
  linearRegression(data, periods) {
    const n = data.length;
    const x = Array.from({ length: n }, (_, i) => i);
    const y = data;
    
    // Calculate regression coefficients
    const sumX = x.reduce((sum, val) => sum + val, 0);
    const sumY = y.reduce((sum, val) => sum + val, 0);
    const sumXY = x.reduce((sum, val, i) => sum + (val * y[i]), 0);
    const sumX2 = x.reduce((sum, val) => sum + (val * val), 0);
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    
    const predictions = [];
    for (let i = 0; i < periods; i++) {
      const nextX = n + i;
      const prediction = slope * nextX + intercept;
      predictions.push(Math.max(0, Math.round(prediction)));
    }
    
    return predictions;
  }

  /**
   * Seasonal Decomposition prediction
   */
  seasonalDecomposition(data, periods) {
    const seasonLength = 7; // Weekly seasonality
    const predictions = [];
    
    if (data.length < seasonLength * 2) {
      // Fall back to simple moving average if insufficient data
      return this.simpleMovingAverage(data, periods);
    }
    
    // Calculate seasonal indices
    const seasonalIndices = this.calculateSeasonalIndices(data, seasonLength);
    
    // Calculate trend using moving average
    const trend = this.calculateTrend(data);
    
    // Generate predictions
    for (let i = 0; i < periods; i++) {
      const trendValue = trend[trend.length - 1] + (trend[trend.length - 1] - trend[trend.length - 2]);
      const seasonalIndex = seasonalIndices[i % seasonLength];
      const prediction = trendValue * seasonalIndex;
      predictions.push(Math.max(0, Math.round(prediction)));
    }
    
    return predictions;
  }

  /**
   * Calculate seasonal indices
   */
  calculateSeasonalIndices(data, seasonLength) {
    const indices = new Array(seasonLength).fill(0);
    const counts = new Array(seasonLength).fill(0);
    
    for (let i = 0; i < data.length; i++) {
      const season = i % seasonLength;
      indices[season] += data[i];
      counts[season]++;
    }
    
    return indices.map((sum, i) => {
      const avg = sum / counts[i];
      const overallAvg = data.reduce((sum, val) => sum + val, 0) / data.length;
      return avg / overallAvg;
    });
  }

  /**
   * Calculate trend using centered moving average
   */
  calculateTrend(data) {
    const windowSize = 3;
    const trend = [];
    
    for (let i = 0; i < data.length; i++) {
      const start = Math.max(0, i - Math.floor(windowSize / 2));
      const end = Math.min(data.length, i + Math.ceil(windowSize / 2));
      const window = data.slice(start, end);
      trend.push(window.reduce((sum, val) => sum + val, 0) / window.length);
    }
    
    return trend;
  }

  /**
   * Calculate model accuracy using cross-validation
   */
  calculateModelAccuracy(data, modelType) {
    const trainSize = Math.floor(data.length * 0.8);
    const trainData = data.slice(0, trainSize);
    const testData = data.slice(trainSize);
    
    const model = this.models[modelType];
    const predictions = model(trainData, testData.length);
    
    // Calculate Mean Absolute Percentage Error (MAPE)
    let totalError = 0;
    for (let i = 0; i < testData.length; i++) {
      const actual = testData[i];
      const predicted = predictions[i];
      const error = Math.abs((actual - predicted) / actual);
      totalError += error;
    }
    
    const mape = (totalError / testData.length) * 100;
    return {
      mape: Math.round(mape * 100) / 100,
      accuracy: Math.max(0, 100 - mape)
    };
  }

  /**
   * Get confidence intervals for predictions
   */
  getConfidenceIntervals(predictions, confidence = 0.95) {
    const stdDev = this.calculateStandardDeviation(this.trainingData);
    const zScore = this.getZScore(confidence);
    
    return predictions.map(pred => ({
      lower: Math.max(0, Math.round(pred - zScore * stdDev)),
      upper: Math.round(pred + zScore * stdDev),
      prediction: pred
    }));
  }

  /**
   * Calculate standard deviation
   */
  calculateStandardDeviation(data) {
    const mean = data.reduce((sum, val) => sum + val, 0) / data.length;
    const variance = data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / data.length;
    return Math.sqrt(variance);
  }

  /**
   * Get Z-score for confidence level
   */
  getZScore(confidence) {
    const zScores = {
      0.90: 1.645,
      0.95: 1.96,
      0.99: 2.576
    };
    return zScores[confidence] || 1.96;
  }

  /**
   * Get model performance metrics
   */
  getModelMetrics() {
    const metrics = {};
    for (const [modelType, accuracy] of this.modelAccuracy) {
      metrics[modelType] = accuracy;
    }
    return metrics;
  }

  /**
   * Clear cache
   */
  clearCache() {
    this.cache.clear();
  }
}

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { MLDemandPrediction };
}
