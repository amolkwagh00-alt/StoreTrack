// ── Data Encryption Module — AES-GCM with password-derived keys ──────────────
// Used by: app.js exportBackup()/importBackup() for optional password-protected
// backups. Nothing else in this app needs encryption (data at rest inside the
// app's IndexedDB is handled separately by modules/dataEncryption.js).

// Derive a real AES-GCM 256-bit key from a user password + salt using PBKDF2
// (100,000 iterations — OWASP-recommended minimum as of 2023/2024).
async function generateKey(password, salt) {
  const passKey = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' },
    passKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

async function encrypt(data, key) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const enc = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(data));
  return { encrypted: Array.from(new Uint8Array(enc)), iv: Array.from(iv) };
}

async function decrypt(encrypted, iv, key) {
  const dec = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: new Uint8Array(iv) }, key, new Uint8Array(encrypted));
  return new TextDecoder().decode(dec);
}

// High-level helpers used directly by app.js — hide the salt/iv/key plumbing.
async function encryptBackup(plainText, password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await generateKey(password, salt);
  const { encrypted, iv } = await encrypt(plainText, key);
  return {
    encrypted: true,
    algo: 'AES-GCM-256/PBKDF2-100000',
    salt: Array.from(salt),
    iv,
    data: encrypted
  };
}

async function decryptBackup(pkg, password) {
  const salt = new Uint8Array(pkg.salt);
  const key = await generateKey(password, salt);
  return decrypt(pkg.data, pkg.iv, key); // throws if password is wrong (bad tag)
}

if (typeof window !== 'undefined') {
  window.Encryption = { generateKey, encrypt, decrypt, encryptBackup, decryptBackup };
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { generateKey, encrypt, decrypt, encryptBackup, decryptBackup };
}
