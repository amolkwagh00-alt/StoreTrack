// Data Archiving Module - Archive old data to maintain performance

/**
 * Archive Policy class
 */
class ArchivePolicy {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.name = config.name || '';
    this.description = config.description || '';
    this.entityType = config.entityType || ''; // materials, transactions, audit_events, etc.
    this.criteria = config.criteria || {}; // { age: 365, status: 'completed' }
    this.archiveStore = config.archiveStore || ''; // Target archive store
    this.enabled = config.enabled !== false;
    this.autoRun = config.autoRun || false;
    this.schedule = config.schedule || 'monthly'; // daily, weekly, monthly
    this.lastRun = config.lastRun || null;
    this.nextRun = config.nextRun || null;
    this.archivedCount = config.archivedCount || 0;
    this.createdBy = config.createdBy || '';
    this.createdAt = config.createdAt || new Date().toISOString();
    this.updatedAt = config.updatedAt || new Date().toISOString();
  }

  generateId() {
    return `archive-policy-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Calculate next run time
   * @returns {string|null} - Next run time ISO string
   */
  calculateNextRun() {
    if (!this.autoRun) {return null;}

    const now = new Date();
    const nextRun = new Date(now);

    switch (this.schedule) {
      case 'daily':
        nextRun.setDate(nextRun.getDate() + 1);
        break;
      case 'weekly':
        nextRun.setDate(nextRun.getDate() + 7);
        break;
      case 'monthly':
        nextRun.setMonth(nextRun.getMonth() + 1);
        break;
      case 'quarterly':
        nextRun.setMonth(nextRun.getMonth() + 3);
        break;
    }

    return nextRun.toISOString();
  }

  /**
   * Should run now
   * @returns {boolean} - Should run
   */
  shouldRunNow() {
    if (!this.enabled || !this.autoRun) {return false;}
    if (!this.nextRun) {return false;}
    return new Date() >= new Date(this.nextRun);
  }
}

/**
 * Archive Record class
 */
class ArchiveRecord {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.policyId = config.policyId || '';
    this.originalStore = config.originalStore || '';
    this.archiveStore = config.archiveStore || '';
    this.originalId = config.originalId || null;
    this.archivedAt = config.archivedAt || new Date().toISOString();
    this.archivedBy = config.archivedBy || '';
    this.reason = config.reason || '';
    this.data = config.data || {};
  }

  generateId() {
    return `archive-record-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Data Archiving Manager
 */
class DataArchivingManager {
  constructor() {
    this.policies = new Map();
    this.records = new Map();
    this.init();
  }

  /**
   * Initialize data archiving manager
   */
  async init() {
    await this.loadPolicies();
    await this.loadRecords();
    this.startScheduledArchiving();
  }

  /**
   * Load policies from storage
   */
  async loadPolicies() {
    try {
      const policies = await gAll('archive_policies');
      policies.forEach(p => {
        this.policies.set(p.id, new ArchivePolicy(p));
      });
    } catch (err) {
      console.error('Failed to load archive policies:', err);
    }
  }

  /**
   * Load records from storage
   */
  async loadRecords() {
    try {
      const records = await gAll('archive_records');
      records.forEach(r => {
        this.records.set(r.id, new ArchiveRecord(r));
      });
    } catch (err) {
      console.error('Failed to load archive records:', err);
    }
  }

  /**
   * Start scheduled archiving
   */
  startScheduledArchiving() {
    setInterval(() => {
      this.checkAndRunScheduledArchives();
    }, 3600000); // Check every hour
  }

  /**
   * Check and run scheduled archives
   */
  async checkAndRunScheduledArchives() {
    for (const policy of this.policies.values()) {
      if (policy.shouldRunNow()) {
        try {
          await this.runArchive(policy);
          policy.lastRun = new Date().toISOString();
          policy.nextRun = policy.calculateNextRun();
          await this.savePolicy(policy);
        } catch (err) {
          console.error(`Failed to run archive policy ${policy.id}:`, err);
        }
      }
    }
  }

  /**
   * Create policy
   * @param {object} config - Policy configuration
   * @returns {ArchivePolicy} - Created policy
   */
  async createPolicy(config) {
    const policy = new ArchivePolicy(config);
    policy.nextRun = policy.calculateNextRun();
    this.policies.set(policy.id, policy);
    await this.savePolicy(policy);
    return policy;
  }

  /**
   * Update policy
   * @param {string} id - Policy ID
   * @param {object} updates - Updates to apply
   * @returns {ArchivePolicy} - Updated policy
   */
  async updatePolicy(id, updates) {
    const policy = this.policies.get(id);
    if (policy) {
      Object.assign(policy, updates);
      policy.updatedAt = new Date().toISOString();
      if (updates.schedule || updates.autoRun) {
        policy.nextRun = policy.calculateNextRun();
      }
      await this.savePolicy(policy);
    }
    return policy;
  }

  /**
   * Delete policy
   * @param {string} id - Policy ID
   */
  async deletePolicy(id) {
    this.policies.delete(id);
    await dDel('archive_policies', id);
  }

  /**
   * Save policy to storage
   * @param {ArchivePolicy} policy - Policy to save
   */
  async savePolicy(policy) {
    try {
      await dPut('archive_policies', policy);
    } catch (err) {
      console.error('Failed to save archive policy:', err);
    }
  }

  /**
   * Run archive policy
   * @param {ArchivePolicy} policy - Policy to run
   * @returns {Promise<object>} - Archive result
   */
  async runArchive(policy) {
    const data = await gAll(policy.entityType);
    const toArchive = this.filterDataForArchive(data, policy.criteria);

    let archivedCount = 0;
    const errors = [];

    for (const item of toArchive) {
      try {
        // Create archive record
        const archiveRecord = new ArchiveRecord({
          policyId: policy.id,
          originalStore: policy.entityType,
          archiveStore: policy.archiveStore,
          originalId: item.id,
          archivedBy: 'system',
          reason: `Archived by policy: ${policy.name}`,
          data: item
        });

        await this.saveRecord(archiveRecord);
        this.records.set(archiveRecord.id, archiveRecord);

        // Delete from original store
        await dDel(policy.entityType, item.id);

        archivedCount++;
      } catch (err) {
        errors.push({ itemId: item.id, error: err.message });
      }
    }

    // Update policy
    policy.archivedCount += archivedCount;
    await this.savePolicy(policy);

    // Log activity
    if (typeof window !== 'undefined' && window.ActivityTracking) {
      await window.ActivityTracking.logActivity('data_archived', 'archive', policy.id, {
        policyName: policy.name,
        entityType: policy.entityType,
        archivedCount,
        errors: errors.length
      });
    }

    return {
      policyId: policy.id,
      archivedCount,
      errors
    };
  }

  /**
   * Filter data for archive based on criteria
   * @param {Array} data - Data to filter
   * @param {object} criteria - Archive criteria
   * @returns {Array} - Data to archive
   */
  filterDataForArchive(data, criteria) {
    if (!criteria || Object.keys(criteria).length === 0) {return [];}

    return data.filter(item => {
      // Check age criteria
      if (criteria.age) {
        const itemDate = new Date(item.createdAt || item.time || item.timestamp);
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - criteria.age);
        if (itemDate >= cutoffDate) {return false;}
      }

      // Check status criteria
      if (criteria.status && item.status !== criteria.status) {
        return false;
      }

      // Check custom criteria
      if (criteria.custom) {
        for (const [field, value] of Object.entries(criteria.custom)) {
          if (item[field] !== value) {return false;}
        }
      }

      return true;
    });
  }

  /**
   * Save record to storage
   * @param {ArchiveRecord} record - Record to save
   */
  async saveRecord(record) {
    // Do not report an archive as complete (or delete its source) unless the
    // archive record was durably written to the backing store.
    await dPut('archive_records', record);
  }

  /**
   * Restore archived data
   * @param {string} recordId - Archive record ID
   * @param {string} restoredBy - User who restored
   * @returns {Promise<object>} - Restored data
   */
  async restoreArchivedData(recordId, restoredBy = '') {
    const record = this.records.get(recordId);
    if (!record) {
      throw new Error('Archive record not found');
    }

    try {
      // Restore to original store
      await dPut(record.originalStore, record.data);

      // Delete archive record
      this.records.delete(recordId);
      await dDel('archive_records', recordId);

      // Log activity
      if (typeof window !== 'undefined' && window.ActivityTracking) {
        await window.ActivityTracking.logActivity('data_restored', 'archive', recordId, {
          originalStore: record.originalStore,
          originalId: record.originalId,
          restoredBy
        });
      }

      return record.data;
    } catch (err) {
      throw new Error(`Failed to restore data: ${err.message}`);
    }
  }

  /**
   * Get policy
   * @param {string} id - Policy ID
   * @returns {ArchivePolicy} - Policy
   */
  getPolicy(id) {
    return this.policies.get(id);
  }

  /**
   * Get all policies
   * @returns {Array} - Array of policies
   */
  getAllPolicies() {
    return Array.from(this.policies.values());
  }

  /**
   * Get enabled policies
   * @returns {Array} - Enabled policies
   */
  getEnabledPolicies() {
    return this.getAllPolicies().filter(p => p.enabled);
  }

  /**
   * Get policies by entity type
   * @param {string} entityType - Entity type
   * @returns {Array} - Policies
   */
  getPoliciesByEntityType(entityType) {
    return this.getAllPolicies().filter(p => p.entityType === entityType);
  }

  /**
   * Get record
   * @param {string} id - Record ID
   * @returns {ArchiveRecord} - Record
   */
  getRecord(id) {
    return this.records.get(id);
  }

  /**
   * Get records for policy
   * @param {string} policyId - Policy ID
   * @returns {Array} - Records
   */
  getRecordsForPolicy(policyId) {
    return Array.from(this.records.values())
      .filter(r => r.policyId === policyId)
      .sort((a, b) => new Date(b.archivedAt) - new Date(a.archivedAt));
  }

  /**
   * Get records by original store
   * @param {string} store - Original store name
   * @returns {Array} - Records
   */
  getRecordsByOriginalStore(store) {
    return Array.from(this.records.values())
      .filter(r => r.originalStore === store)
      .sort((a, b) => new Date(b.archivedAt) - new Date(a.archivedAt));
  }

  /**
   * Delete record
   * @param {string} id - Record ID
   */
  async deleteRecord(id) {
    this.records.delete(id);
    await dDel('archive_records', id);
  }

  /**
   * Cleanup old archive records
   * @param {number} daysToKeep - Days to keep
   */
  async cleanupOldArchiveRecords(daysToKeep = 365) {
    const retentionDays = Number(daysToKeep);
    if (!Number.isFinite(retentionDays) || retentionDays < 1 || retentionDays > 36500) {
      throw new RangeError('Archive retention must be between 1 and 36500 days');
    }
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - retentionDays);

    let deletedCount = 0;

    for (const [recordId, record] of this.records) {
      const archivedAt = new Date(record.archivedAt);
      // A malformed timestamp is not proof that a record has expired. Keep it
      // for operator review instead of treating Invalid Date as old data.
      if (Number.isNaN(archivedAt.getTime()) || archivedAt >= cutoffDate) { continue; }
      // Delete durably first. If IndexedDB rejects the delete, retain the
      // in-memory entry so the UI does not falsely report successful cleanup.
      await dDel('archive_records', recordId);
      this.records.delete(recordId);
      deletedCount++;
    }

    return deletedCount;
  }

  /**
   * Get statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const policies = this.getAllPolicies();
    const records = Array.from(this.records.values());

    return {
      totalPolicies: policies.length,
      enabledPolicies: policies.filter(p => p.enabled).length,
      autoRunPolicies: policies.filter(p => p.autoRun).length,
      byEntityType: this.getEntityTypeCounts(policies),
      totalArchivedRecords: records.length,
      byOriginalStore: this.getOriginalStoreCounts(records),
      totalArchivedByPolicies: policies.reduce((sum, p) => sum + p.archivedCount, 0)
    };
  }

  /**
   * Get entity type counts
   * @param {Array} policies - Policies
   * @returns {object} - Entity type counts
   */
  getEntityTypeCounts(policies) {
    const counts = {};
    policies.forEach(p => {
      counts[p.entityType] = (counts[p.entityType] || 0) + 1;
    });
    return counts;
  }

  /**
   * Get original store counts
   * @param {Array} records - Records
   * @returns {object} - Store counts
   */
  getOriginalStoreCounts(records) {
    const counts = {};
    records.forEach(r => {
      counts[r.originalStore] = (counts[r.originalStore] || 0) + 1;
    });
    return counts;
  }
}

/**
 * Global data archiving manager instance
 */
const dataArchivingManager = new DataArchivingManager();

/**
 * Initialize data archiving
 */
async function initDataArchiving() {
  await dataArchivingManager.init();
  return dataArchivingManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.DataArchiving = {
    manager: dataArchivingManager,
    init: initDataArchiving,
    createPolicy: (config) => dataArchivingManager.createPolicy(config),
    updatePolicy: (id, updates) => dataArchivingManager.updatePolicy(id, updates),
    deletePolicy: (id) => dataArchivingManager.deletePolicy(id),
    runArchive: (policy) => dataArchivingManager.runArchive(policy),
    restoreArchivedData: (recordId, restoredBy) => dataArchivingManager.restoreArchivedData(recordId, restoredBy),
    getPolicy: (id) => dataArchivingManager.getPolicy(id),
    getAllPolicies: () => dataArchivingManager.getAllPolicies(),
    getEnabledPolicies: () => dataArchivingManager.getEnabledPolicies(),
    getPoliciesByEntityType: (entityType) => dataArchivingManager.getPoliciesByEntityType(entityType),
    getRecord: (id) => dataArchivingManager.getRecord(id),
    getRecordsForPolicy: (policyId) => dataArchivingManager.getRecordsForPolicy(policyId),
    getRecordsByOriginalStore: (store) => dataArchivingManager.getRecordsByOriginalStore(store),
    deleteRecord: (id) => dataArchivingManager.deleteRecord(id),
    cleanupOldArchiveRecords: (daysToKeep) => dataArchivingManager.cleanupOldArchiveRecords(daysToKeep),
    getStats: () => dataArchivingManager.getStatistics()
  };
}
