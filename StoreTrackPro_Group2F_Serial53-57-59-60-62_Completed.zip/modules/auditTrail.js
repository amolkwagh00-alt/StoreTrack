// Audit Trail Module - Enhanced audit logging and compliance

/**
 * Audit Log Entry class
 */
class AuditLogEntry {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.timestamp = config.timestamp || new Date().toISOString();
    this.userId = config.userId || null;
    this.username = config.username || 'System';
    this.action = config.action || 'unknown';
    this.resource = config.resource || null;
    this.resourceId = config.resourceId || null;
    this.oldValue = config.oldValue || null;
    this.newValue = config.newValue || null;
    this.ipAddress = config.ipAddress || null;
    this.userAgent = config.userAgent || null;
    this.sessionId = config.sessionId || null;
    this.category = config.category || 'general';
    this.severity = config.severity || 'info';
    this.description = config.description || '';
    this.metadata = config.metadata || {};
    this.correlationId = config.correlationId || null;
  }

  generateId() {
    return `audit-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Audit Trail Manager
 */
class AuditTrailManager {
  constructor() {
    this.retentionDays = 365;
    this.complianceMode = false;
  }

  /**
   * Initialize audit trail manager
   */
  async init() {
    await this.loadSettings();
    this.setupAutoCleanup();
  }

  /**
   * Load settings from storage
   */
  async loadSettings() {
    try {
      const settings = await gOne('audit_settings', 'settings');
      if (settings) {
        this.retentionDays = settings.retentionDays || 365;
        this.complianceMode = settings.complianceMode || false;
      }
    } catch (err) {
      console.error('Failed to load audit settings:', err);
    }
  }

  /**
   * Setup automatic cleanup
   */
  setupAutoCleanup() {
    // Run cleanup daily
    setInterval(() => {
      this.cleanupOldLogs();
    }, 24 * 60 * 60 * 1000);
  }

  /**
   * Log audit entry
   * @param {object} config - Log configuration
   * @returns {Promise<AuditLogEntry>} - Created log entry
   */
  async log(config) {
    const entry = new AuditLogEntry(config);
    
    // Add correlation ID if not provided
    if (!entry.correlationId && this.complianceMode) {
      entry.correlationId = this.generateCorrelationId();
    }

    try {
      await dPut('audit_logs', entry);
      
      // In compliance mode, also log to immutable storage
      if (this.complianceMode) {
        await this.logToImmutableStorage(entry);
      }
    } catch (err) {
      console.error('Failed to log audit entry:', err);
    }

    return entry;
  }

  /**
   * Generate correlation ID
   * @returns {string} - Correlation ID
   */
  generateCorrelationId() {
    return `corr-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Log to immutable storage (placeholder)
   * @param {AuditLogEntry} entry - Entry to log
   */
  async logToImmutableStorage(entry) {
    // This would log to an immutable storage system
    // For compliance requirements
    console.log('Logging to immutable storage:', entry.id);
  }

  /**
   * Log data change
   * @param {string} userId - User ID
   * @param {string} resource - Resource type
   * @param {string} resourceId - Resource ID
   * @param {any} oldValue - Old value
   * @param {any} newValue - New value
   * @returns {Promise<AuditLogEntry>} - Log entry
   */
  async logDataChange(userId, resource, resourceId, oldValue, newValue) {
    return this.log({
      userId,
      username: await this.getUsername(userId),
      action: 'update',
      resource,
      resourceId,
      oldValue,
      newValue,
      category: 'data_change',
      severity: 'info',
      description: `Updated ${resource} ${resourceId}`,
      metadata: {
        changedFields: this.getChangedFields(oldValue, newValue)
      }
    });
  }

  /**
   * Get username from user ID
   * @param {string} userId - User ID
   * @returns {Promise<string>} - Username
   */
  async getUsername(userId) {
    try {
      const user = await gOne('users', userId);
      return user?.username || 'Unknown';
    } catch (err) {
      return 'Unknown';
    }
  }

  /**
   * Get changed fields between two objects
   * @param {object} oldObj - Old object
   * @param {object} newObj - New object
   * @returns {Array} - Changed field names
   */
  getChangedFields(oldObj, newObj) {
    if (!oldObj || !newObj) {return [];}

    const changes = [];
    const allKeys = new Set([...Object.keys(oldObj), ...Object.keys(newObj)]);

    allKeys.forEach(key => {
      if (JSON.stringify(oldObj[key]) !== JSON.stringify(newObj[key])) {
        changes.push(key);
      }
    });

    return changes;
  }

  /**
   * Log authentication event
   * @param {string} userId - User ID
   * @param {string} action - Action (login, logout, failed_login)
   * @param {object} metadata - Additional metadata
   * @returns {Promise<AuditLogEntry>} - Log entry
   */
  async logAuthEvent(userId, action, metadata = {}) {
    return this.log({
      userId,
      username: await this.getUsername(userId),
      action,
      resource: 'auth',
      category: 'authentication',
      severity: action === 'failed_login' ? 'warning' : 'info',
      description: `Authentication ${action}`,
      metadata
    });
  }

  /**
   * Log authorization event
   * @param {string} userId - User ID
   * @param {string} resource - Resource accessed
   * @param {string} action - Action attempted
   * @param {boolean} allowed - Whether access was allowed
   * @returns {Promise<AuditLogEntry>} - Log entry
   */
  async logAuthzEvent(userId, resource, action, allowed) {
    return this.log({
      userId,
      username: await this.getUsername(userId),
      action: allowed ? 'access_granted' : 'access_denied',
      resource,
      category: 'authorization',
      severity: allowed ? 'info' : 'warning',
      description: `${allowed ? 'Granted' : 'Denied'} ${action} on ${resource}`,
      metadata: { action }
    });
  }

  /**
   * Log system event
   * @param {string} action - System action
   * @param {string} severity - Severity level
   * @param {object} metadata - Additional metadata
   * @returns {Promise<AuditLogEntry>} - Log entry
   */
  async logSystemEvent(action, severity = 'info', metadata = {}) {
    return this.log({
      userId: null,
      username: 'System',
      action,
      resource: 'system',
      category: 'system',
      severity,
      description: `System event: ${action}`,
      metadata
    });
  }

  /**
   * Get audit logs
   * @param {object} filters - Filters to apply
   * @returns {Promise<Array>} - Audit logs
   */
  async getLogs(filters = {}) {
    try {
      let logs = await gAll('audit_logs');

      if (filters.userId) {
        logs = logs.filter(l => l.userId === filters.userId);
      }

      if (filters.username) {
        logs = logs.filter(l => l.username === filters.username);
      }

      if (filters.action) {
        logs = logs.filter(l => l.action === filters.action);
      }

      if (filters.resource) {
        logs = logs.filter(l => l.resource === filters.resource);
      }

      if (filters.resourceId) {
        logs = logs.filter(l => l.resourceId === filters.resourceId);
      }

      if (filters.category) {
        logs = logs.filter(l => l.category === filters.category);
      }

      if (filters.severity) {
        logs = logs.filter(l => l.severity === filters.severity);
      }

      if (filters.sessionId) {
        logs = logs.filter(l => l.sessionId === filters.sessionId);
      }

      if (filters.correlationId) {
        logs = logs.filter(l => l.correlationId === filters.correlationId);
      }

      if (filters.startDate) {
        const start = new Date(filters.startDate);
        logs = logs.filter(l => new Date(l.timestamp) >= start);
      }

      if (filters.endDate) {
        const end = new Date(filters.endDate);
        logs = logs.filter(l => new Date(l.timestamp) <= end);
      }

      // Sort by timestamp descending
      logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

      // Apply limit
      if (filters.limit) {
        logs = logs.slice(0, filters.limit);
      }

      return logs;
    } catch (err) {
      console.error('Failed to get audit logs:', err);
      return [];
    }
  }

  /**
   * Get logs by correlation ID
   * @param {string} correlationId - Correlation ID
   * @returns {Promise<Array>} - Related logs
   */
  async getLogsByCorrelation(correlationId) {
    return this.getLogs({ correlationId });
  }

  /**
   * Get logs for resource
   * @param {string} resource - Resource type
   * @param {string} resourceId - Resource ID
   * @returns {Promise<Array>} - Resource logs
   */
  async getResourceHistory(resource, resourceId) {
    return this.getLogs({ resource, resourceId });
  }

  /**
   * Get user activity
   * @param {string} userId - User ID
   * @param {number} limit - Limit number of results
   * @returns {Promise<Array>} - User activity
   */
  async getUserActivity(userId, limit = 100) {
    return this.getLogs({ userId, limit });
  }

  /**
   * Get audit statistics
   * @param {object} filters - Filters to apply
   * @returns {Promise<object>} - Statistics
   */
  async getStatistics(filters = {}) {
    const logs = await this.getLogs(filters);

    const stats = {
      total: logs.length,
      byAction: {},
      byResource: {},
      byUser: {},
      byCategory: {},
      bySeverity: {},
      byDate: {},
      timeRange: {
        earliest: logs.length > 0 ? logs[logs.length - 1].timestamp : null,
        latest: logs.length > 0 ? logs[0].timestamp : null
      }
    };

    logs.forEach(log => {
      // By action
      stats.byAction[log.action] = (stats.byAction[log.action] || 0) + 1;

      // By resource
      if (log.resource) {
        stats.byResource[log.resource] = (stats.byResource[log.resource] || 0) + 1;
      }

      // By user
      if (log.username) {
        stats.byUser[log.username] = (stats.byUser[log.username] || 0) + 1;
      }

      // By category
      stats.byCategory[log.category] = (stats.byCategory[log.category] || 0) + 1;

      // By severity
      stats.bySeverity[log.severity] = (stats.bySeverity[log.severity] || 0) + 1;

      // By date
      const date = new Date(log.timestamp).toISOString().split('T')[0];
      stats.byDate[date] = (stats.byDate[date] || 0) + 1;
    });

    return stats;
  }

  /**
   * Export audit logs
   * @param {object} filters - Filters to apply
   * @param {string} format - Export format (csv, json)
   * @returns {Promise<string>} - Exported data
   */
  async exportLogs(filters = {}, format = 'csv') {
    const logs = await this.getLogs(filters);

    if (format === 'json') {
      return JSON.stringify(logs, null, 2);
    }

    if (format === 'csv') {
      if (logs.length === 0) {return '';}

      const headers = ['timestamp', 'username', 'action', 'resource', 'resourceId', 'category', 'severity', 'description'];
      const rows = logs.map(log => [
        log.timestamp,
        log.username,
        log.action,
        log.resource || '',
        log.resourceId || '',
        log.category,
        log.severity,
        log.description
      ]);

      return [headers.join(','), ...rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(','))].join('\n');
    }

    return '';
  }

  /**
   * Cleanup old logs
   */
  async cleanupOldLogs() {
    try {
      const logs = await gAll('audit_logs');
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - this.retentionDays);

      const logsToDelete = logs.filter(l => new Date(l.timestamp) < cutoffDate);

      for (const log of logsToDelete) {
        await dDel('audit_logs', log.id);
      }

      console.log(`Cleaned up ${logsToDelete.length} old audit logs`);
    } catch (err) {
      console.error('Failed to cleanup old logs:', err);
    }
  }

  /**
   * Set retention period
   * @param {number} days - Number of days to retain logs
   */
  async setRetentionDays(days) {
    this.retentionDays = days;
    await this.saveSettings();
  }

  /**
   * Enable/disable compliance mode
   * @param {boolean} enabled - Enable compliance mode
   */
  async setComplianceMode(enabled) {
    this.complianceMode = enabled;
    await this.saveSettings();
  }

  /**
   * Save settings
   */
  async saveSettings() {
    try {
      await dPut('audit_settings', {
        id: 'settings',
        retentionDays: this.retentionDays,
        complianceMode: this.complianceMode,
        updatedAt: new Date().toISOString()
      });
    } catch (err) {
      console.error('Failed to save audit settings:', err);
    }
  }

  /**
   * Generate compliance report
   * @param {object} filters - Filters to apply
   * @returns {Promise<object>} - Compliance report
   */
  async generateComplianceReport(filters = {}) {
    const logs = await this.getLogs(filters);
    const stats = await this.getStatistics(filters);

    return {
      generatedAt: new Date().toISOString(),
      filters,
      statistics: stats,
      logs: logs.map(l => ({
        timestamp: l.timestamp,
        username: l.username,
        action: l.action,
        resource: l.resource,
        resourceId: l.resourceId,
        category: l.category,
        severity: l.severity,
        description: l.description,
        correlationId: l.correlationId
      })),
      complianceMode: this.complianceMode,
      retentionPolicy: `${this.retentionDays} days`
    };
  }
}

/**
 * Global audit trail manager instance
 */
const auditTrailManager = new AuditTrailManager();

/**
 * Initialize audit trail
 */
async function initAuditTrail() {
  // Wait for database to be ready
  if (!window.databaseReady) {
    await new Promise(resolve => {
      document.addEventListener('databaseReady', resolve, { once: true });
    });
  }
  await auditTrailManager.init();
  return auditTrailManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.AuditTrail = {
    manager: auditTrailManager,
    init: initAuditTrail,
    log: (config) => auditTrailManager.log(config),
    logDataChange: (userId, resource, resourceId, oldVal, newVal) => auditTrailManager.logDataChange(userId, resource, resourceId, oldVal, newVal),
    logAuthEvent: (userId, action, metadata) => auditTrailManager.logAuthEvent(userId, action, metadata),
    logAuthzEvent: (userId, resource, action, allowed) => auditTrailManager.logAuthzEvent(userId, resource, action, allowed),
    logSystemEvent: (action, severity, metadata) => auditTrailManager.logSystemEvent(action, severity, metadata),
    getLogs: (filters) => auditTrailManager.getLogs(filters),
    getLogsByCorrelation: (corrId) => auditTrailManager.getLogsByCorrelation(corrId),
    getResourceHistory: (resource, resourceId) => auditTrailManager.getResourceHistory(resource, resourceId),
    getUserActivity: (userId, limit) => auditTrailManager.getUserActivity(userId, limit),
    getStatistics: (filters) => auditTrailManager.getStatistics(filters),
    exportLogs: (filters, format) => auditTrailManager.exportLogs(filters, format),
    setRetentionDays: (days) => auditTrailManager.setRetentionDays(days),
    setComplianceMode: (enabled) => auditTrailManager.setComplianceMode(enabled),
    generateComplianceReport: (filters) => auditTrailManager.generateComplianceReport(filters)
  };
}
