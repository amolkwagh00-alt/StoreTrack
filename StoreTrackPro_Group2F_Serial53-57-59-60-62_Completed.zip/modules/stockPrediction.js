// Stock Prediction Module - AI-powered stock forecasting

/**
 * Stock Prediction Engine
 */
class StockPredictionEngine {
  constructor() {
    this.models = new Map();
    this.init();
  }

  /**
   * Initialize prediction engine
   */
  init() {
    this.setupDefaultModels();
  }

  /**
   * Setup default prediction models
   */
  setupDefaultModels() {
    // Simple moving average model
    this.models.set('sma', {
      name: 'Simple Moving Average',
      predict: this.predictSMA.bind(this)
    });

    // Weighted moving average model
    this.models.set('wma', {
      name: 'Weighted Moving Average',
      predict: this.predictWMA.bind(this)
    });

    // Linear regression model
    this.models.set('linear', {
      name: 'Linear Regression',
      predict: this.predictLinear.bind(this)
    });

    // Exponential smoothing model
    this.models.set('exponential', {
      name: 'Exponential Smoothing',
      predict: this.predictExponential.bind(this)
    });
  }

  /**
   * Get historical stock data for material
   * @param {string} materialId - Material ID
   * @param {number} days - Number of days of history
   * @returns {Promise<Array>} - Historical data
   */
  async getHistoricalData(materialId, days = 30) {
    try {
      const transactions = await gAll('transactions');
      const materialTransactions = transactions.filter(t =>
        (t.barcode === materialId || String(t.itemId) === String(materialId)) &&
        ['IN', 'OUT'].includes(t.type) &&
        !['pending', 'pending-central', 'rejected', 'cancelled', 'canceled', 'void'].includes(String(t.status || '').toLowerCase())
      );
      
      // Group by date and calculate net stock change
      const dailyData = {};
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - days);

      materialTransactions.forEach(t => {
        const transactionDate = new Date(t.time || t.timestamp || t.date || t.createdAt);
        const quantity = Number(t.qty ?? t.quantity);
        if (Number.isFinite(transactionDate.getTime()) && transactionDate >= cutoffDate && Number.isFinite(quantity)) {
          const date = transactionDate.toISOString().split('T')[0];
          const change = t.type === 'IN' ? quantity : -quantity;
          dailyData[date] = (dailyData[date] || 0) + change;
        }
      });

      // Convert to array and sort by date
      const data = Object.entries(dailyData)
        .map(([date, change]) => ({ date, change }))
        .sort((a, b) => new Date(a.date) - new Date(b.date));

      return data;
    } catch (err) {
      console.error('Failed to get historical data:', err);
      return [];
    }
  }

  /**
   * Predict using Simple Moving Average
   * @param {Array} data - Historical data
   * @param {number} periods - Number of periods to predict
   * @returns {Array} - Predictions
   */
  predictSMA(data, periods = 7) {
    if (data.length < 3) {return [];}

    const windowSize = Math.min(7, Math.floor(data.length / 2));
    const predictions = [];
    const lastValue = data.slice(-windowSize).reduce((sum, d) => sum + d.change, 0) / windowSize;

    for (let i = 0; i < periods; i++) {
      predictions.push({
        period: i + 1,
        predictedChange: lastValue,
        confidence: 0.5
      });
    }

    return predictions;
  }

  /**
   * Predict using Weighted Moving Average
   * @param {Array} data - Historical data
   * @param {number} periods - Number of periods to predict
   * @returns {Array} - Predictions
   */
  predictWMA(data, periods = 7) {
    if (data.length < 3) {return [];}

    const windowSize = Math.min(7, Math.floor(data.length / 2));
    const weights = Array.from({ length: windowSize }, (_, i) => i + 1);
    const weightSum = weights.reduce((sum, w) => sum + w, 0);

    const recentData = data.slice(-windowSize);
    const lastValue = recentData.reduce((sum, d, i) => sum + d.change * weights[i], 0) / weightSum;

    const predictions = [];
    for (let i = 0; i < periods; i++) {
      predictions.push({
        period: i + 1,
        predictedChange: lastValue,
        confidence: 0.6
      });
    }

    return predictions;
  }

  /**
   * Predict using Linear Regression
   * @param {Array} data - Historical data
   * @param {number} periods - Number of periods to predict
   * @returns {Array} - Predictions
   */
  predictLinear(data, periods = 7) {
    if (data.length < 3) {return [];}

    const n = data.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;

    data.forEach((d, i) => {
      sumX += i;
      sumY += d.change;
      sumXY += i * d.change;
      sumX2 += i * i;
    });

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;

    const predictions = [];
    for (let i = 0; i < periods; i++) {
      const predictedChange = slope * (n + i) + intercept;
      predictions.push({
        period: i + 1,
        predictedChange,
        confidence: 0.7
      });
    }

    return predictions;
  }

  /**
   * Predict using Exponential Smoothing
   * @param {Array} data - Historical data
   * @param {number} periods - Number of periods to predict
   * @param {number} alpha - Smoothing factor (0-1)
   * @returns {Array} - Predictions
   */
  predictExponential(data, periods = 7, alpha = 0.3) {
    if (data.length < 3) {return [];}

    let smoothed = data[0].change;
    data.slice(1).forEach(d => {
      smoothed = alpha * d.change + (1 - alpha) * smoothed;
    });

    const predictions = [];
    for (let i = 0; i < periods; i++) {
      predictions.push({
        period: i + 1,
        predictedChange: smoothed,
        confidence: 0.65
      });
    }

    return predictions;
  }

  /**
   * Predict stock for material
   * @param {string} materialId - Material ID
   * @param {string} model - Model to use
   * @param {number} periods - Number of periods to predict
   * @returns {Promise<object>} - Prediction result
   */
  async predictStock(materialId, model = 'linear', periods = 7) {
    const historicalData = await this.getHistoricalData(materialId, 30);
    
    if (historicalData.length < 3) {
      return {
        materialId,
        model,
        predictions: [],
        error: 'Insufficient historical data'
      };
    }

    const modelFn = this.models.get(model);
    if (!modelFn) {
      return {
        materialId,
        model,
        predictions: [],
        error: 'Unknown model'
      };
    }

    const predictions = modelFn.predict(historicalData, periods);
    
    // Calculate trend
    const recentTrend = this.calculateTrend(historicalData.slice(-7));
    
    return {
      materialId,
      model,
      modelName: modelFn.name,
      predictions,
      recentTrend,
      historicalData,
      generatedAt: new Date().toISOString()
    };
  }

  /**
   * Calculate trend from data
   * @param {Array} data - Data to analyze
   * @returns {string} - Trend direction
   */
  calculateTrend(data) {
    if (data.length < 2) {return 'stable';}

    const first = data[0].change;
    const last = data[data.length - 1].change;
    const change = last - first;

    if (change > 0.1) {return 'increasing';}
    if (change < -0.1) {return 'decreasing';}
    return 'stable';
  }

  /**
   * Get available models
   * @returns {Array} - Available models
   */
  getAvailableModels() {
    return Array.from(this.models.entries()).map(([id, model]) => ({
      id,
      name: model.name
    }));
  }

  /**
   * Add custom model
   * @param {string} id - Model ID
   * @param {string} name - Model name
   * @param {Function} predictFn - Prediction function
   */
  addModel(id, name, predictFn) {
    this.models.set(id, { name, predict: predictFn });
  }
}

/**
 * Reorder Suggestion Engine
 */
class ReorderSuggestionEngine {
  constructor() {
    this.predictionEngine = new StockPredictionEngine();
  }

  /**
   * Get reorder suggestions
   * @returns {Promise<Array>} - Reorder suggestions
   */
  async getReorderSuggestions() {
    try {
      const materials = await gAll('materials');
      const suggestions = [];

      for (const material of materials) {
        const suggestion = await this.analyzeMaterial(material);
        if (suggestion) {
          suggestions.push(suggestion);
        }
      }

      // Sort by urgency
      suggestions.sort((a, b) => b.urgency - a.urgency);

      return suggestions;
    } catch (err) {
      console.error('Failed to get reorder suggestions:', err);
      return [];
    }
  }

  /**
   * Analyze material for reorder need
   * @param {object} material - Material object
   * @returns {Promise<object>} - Suggestion or null
   */
  async analyzeMaterial(material) {
    const currentStock = Number(material.stock ?? material.currentStock ?? 0) || 0;
    const minStock = Number(material.lowAlert ?? material.minStock ?? 0) || 0;
    const maxStock = Number(material.maxStock ?? minStock * 2) || minStock * 2;

    // Determine urgency
    let urgency = 0;
    let reason = '';

    if (currentStock <= 0) {
      urgency = 100;
      reason = 'Out of stock';
    } else if (currentStock <= minStock * 0.25) {
      urgency = 80;
      reason = 'Critically low';
    } else if (currentStock <= minStock * 0.5) {
      urgency = 60;
      reason = 'Low stock';
    } else if (currentStock <= minStock) {
      urgency = 40;
      reason = 'At minimum level';
    } else {
      // Check if trending low
      const prediction = await this.predictionEngine.predictStock(material.barcode, 'linear', 7);
      if (prediction.recentTrend === 'decreasing') {
        urgency = 30;
        reason = 'Stock decreasing';
      } else {
        return null; // No reorder needed
      }
    }

    // Calculate suggested order quantity
    const suggestedQty = Math.max(maxStock - currentStock, minStock - currentStock);

    return {
      materialId: material.id,
      barcode: material.barcode,
      name: material.name,
      currentStock,
      minStock,
      maxStock,
      suggestedQuantity: suggestedQty,
      urgency,
      reason,
      estimatedCost: suggestedQty * (Number(material.unitCost ?? material.unitPrice ?? 0) || 0),
      prediction: await this.predictionEngine.predictStock(material.barcode, 'linear', 7)
    };
  }

  /**
   * Get reorder suggestions by urgency
   * @param {number} minUrgency - Minimum urgency level
   * @returns {Promise<Array>} - Filtered suggestions
   */
  async getSuggestionsByUrgency(minUrgency = 50) {
    const suggestions = await this.getReorderSuggestions();
    return suggestions.filter(s => s.urgency >= minUrgency);
  }
}

/**
 * Anomaly Detection Engine
 */
class AnomalyDetectionEngine {
  constructor() {
    this.threshold = 2; // Standard deviations
  }

  /**
   * Detect anomalies in transactions
   * @returns {Promise<Array>} - Detected anomalies
   */
  async detectTransactionAnomalies() {
    try {
      const transactions = await gAll('transactions');
      const anomalies = [];

      // Group by material
      const byMaterial = {};
      transactions.forEach(t => {
        if (!byMaterial[t.barcode]) {byMaterial[t.barcode] = [];}
        byMaterial[t.barcode].push(t);
      });

      // Analyze each material
      Object.entries(byMaterial).forEach(([barcode, txs]) => {
        const materialAnomalies = this.detectQuantityAnomalies(txs);
        materialAnomalies.forEach(a => {
          anomalies.push({ ...a, barcode });
        });
      });

      return anomalies;
    } catch (err) {
      console.error('Failed to detect anomalies:', err);
      return [];
    }
  }

  /**
   * Detect quantity anomalies
   * @param {Array} transactions - Transactions to analyze
   * @returns {Array} - Anomalies
   */
  detectQuantityAnomalies(transactions) {
    const anomalies = [];
    
    if (transactions.length < 5) {return anomalies;}

    const quantities = transactions.map(t => t.quantity);
    const mean = quantities.reduce((sum, q) => sum + q, 0) / quantities.length;
    const variance = quantities.reduce((sum, q) => sum + Math.pow(q - mean, 2), 0) / quantities.length;
    const stdDev = Math.sqrt(variance);

    transactions.forEach(t => {
      const zScore = Math.abs((t.quantity - mean) / stdDev);
      if (zScore > this.threshold) {
        anomalies.push({
          type: 'quantity_anomaly',
          transactionId: t.id,
          quantity: t.quantity,
          expectedRange: [mean - stdDev, mean + stdDev],
          zScore,
          severity: zScore > 3 ? 'high' : 'medium',
          timestamp: t.time
        });
      }
    });

    return anomalies;
  }

  /**
   * Detect unusual patterns in stock levels
   * @returns {Promise<Array>} - Detected patterns
   */
  async detectStockAnomalies() {
    try {
      const materials = await gAll('materials');
      const anomalies = [];

      materials.forEach(m => {
        const currentStock = m.currentStock || 0;
        const minStock = m.minStock || 0;
        const maxStock = m.maxStock || minStock * 2;

        // Check for overstock
        if (currentStock > maxStock * 1.5) {
          anomalies.push({
            type: 'overstock',
            materialId: m.id,
            barcode: m.barcode,
            name: m.name,
            currentStock,
            maxStock,
            severity: 'medium',
            message: `Stock exceeds maximum by ${((currentStock / maxStock) * 100 - 100).toFixed(0)}%`
          });
        }

        // Check for sudden drops
        if (currentStock < minStock * 0.5 && currentStock > 0) {
          anomalies.push({
            type: 'sudden_drop',
            materialId: m.id,
            barcode: m.barcode,
            name: m.name,
            currentStock,
            minStock,
            severity: 'high',
            message: `Stock dropped below 50% of minimum level`
          });
        }
      });

      return anomalies;
    } catch (err) {
      console.error('Failed to detect stock anomalies:', err);
      return [];
    }
  }

  /**
   * Set anomaly threshold
   * @param {number} threshold - Standard deviation threshold
   */
  setThreshold(threshold) {
    this.threshold = threshold;
  }
}

/**
 * Global instances
 */
const stockPredictionEngine = new StockPredictionEngine();
const reorderSuggestionEngine = new ReorderSuggestionEngine();
const anomalyDetectionEngine = new AnomalyDetectionEngine();

/**
 * Initialize stock prediction
 */
async function initStockPrediction() {
  return stockPredictionEngine;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.StockPrediction = {
    engine: stockPredictionEngine,
    reorderEngine: reorderSuggestionEngine,
    anomalyEngine: anomalyDetectionEngine,
    init: initStockPrediction,
    predict: (id, model, periods) => stockPredictionEngine.predictStock(id, model, periods),
    getReorderSuggestions: () => reorderSuggestionEngine.getReorderSuggestions(),
    getSuggestionsByUrgency: (min) => reorderSuggestionEngine.getSuggestionsByUrgency(min),
    detectTransactionAnomalies: () => anomalyDetectionEngine.detectTransactionAnomalies(),
    detectStockAnomalies: () => anomalyDetectionEngine.detectStockAnomalies(),
    getModels: () => stockPredictionEngine.getAvailableModels()
  };
}
