'use strict';

const crypto = require('crypto');

const FORMAT = 'StoreTrackProEncryptedBackup';
const ALGORITHM = 'AES-256-GCM';

function assertKey(key) {
  if (!Buffer.isBuffer(key) || key.length !== 32) throw new TypeError('Backup key must be a 256-bit Buffer');
}

function encryptBackup(plaintext, key) {
  assertKey(key);
  if (typeof plaintext !== 'string') throw new TypeError('Backup plaintext must be a string');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  return {
    format: FORMAT,
    version: 1,
    algorithm: ALGORITHM,
    iv: iv.toString('base64'),
    authTag: cipher.getAuthTag().toString('base64'),
    ciphertext: ciphertext.toString('base64'),
  };
}

function decryptBackup(envelope, key) {
  assertKey(key);
  if (!envelope || envelope.format !== FORMAT || envelope.version !== 1 || envelope.algorithm !== ALGORITHM) {
    throw new Error('Unsupported encrypted backup format');
  }
  const iv = Buffer.from(envelope.iv, 'base64');
  const authTag = Buffer.from(envelope.authTag, 'base64');
  const ciphertext = Buffer.from(envelope.ciphertext, 'base64');
  if (iv.length !== 12 || authTag.length !== 16 || ciphertext.length === 0) throw new Error('Invalid encrypted backup envelope');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
}

module.exports = { FORMAT, ALGORITHM, encryptBackup, decryptBackup };
