/**
 * Business Intelligence Dashboard Module
 * Provides comprehensive analytics and reporting capabilities
 */

function isConfirmedForAnalytics(transaction) {
  const status = String(transaction?.status || '').toLowerCase();
  return !['pending', 'rejected', 'cancelled', 'canceled', 'void'].includes(status);
}

class BusinessIntelligence {
  constructor() {
    this.metrics = new Map();
    this.kpis = new Map();
    this.reports = new Map();
    this.dashboards = new Map();
    this.refreshInterval = 5 * 60 * 1000; // 5 minutes
    this.lastRefresh = 0;
  }

  /**
   * Initialize BI system with data sources
   * @param {Object} dataSources - Available data sources
   */
  async initialize(dataSources) {
    this.dataSources = dataSources;
    await this.calculateKPIs();
    this.buildDashboards();
    return this.getKPIs();
  }

  /**
   * Calculate Key Performance Indicators
   */
  async calculateKPIs() {
    const kpis = {
      inventoryTurnover: await this.calculateInventoryTurnover(),
      stockoutRate: await this.calculateStockoutRate(),
      orderAccuracy: await this.calculateOrderAccuracy(),
      supplierPerformance: await this.calculateSupplierPerformance(),
      demandForecastAccuracy: await this.calculateForecastAccuracy(),
      carryingCost: await this.calculateCarryingCost(),
      fillRate: await this.calculateFillRate(),
      averageLeadTime: await this.calculateAverageLeadTime()
    };

    this.kpis.set('current', kpis);
    this.lastRefresh = Date.now();
    return kpis;
  }

  /**
   * Calculate inventory turnover ratio
   */
  async calculateInventoryTurnover() {
    const materials = await this.dataSources.materials || [];
    const transactions = await this.dataSources.transactions || [];
    
    const totalValue = materials.reduce((sum, m) => sum + (m.value || 0), 0);
    const costOfGoodsSold = transactions
      .filter(t => t.type === 'OUT' && isConfirmedForAnalytics(t))
      .reduce((sum, t) => sum + (t.value || 0), 0);
    
    if (totalValue === 0) {return 0;}
    
    return {
      ratio: (costOfGoodsSold / totalValue).toFixed(2),
      totalValue,
      costOfGoodsSold,
      trend: this.calculateTrend('inventoryTurnover')
    };
  }

  /**
   * Calculate stockout rate.
   * This app doesn't log a 'stockout' transaction type -- issuing more than
   * what's in stock is simply prevented at issue-time, not recorded as an
   * event. So this always returns 0 events / not-tracked rather than fabricating
   * a rate. lowItems() (current below-reorder-threshold count) is a related
   * but different signal, shown separately on the BI dashboard.
   */
  async calculateStockoutRate() {
    const transactions = await this.dataSources.transactions || [];
    
    const stockoutEvents = transactions.filter(t => t.type === 'stockout').length;
    const totalOrders = transactions.filter(t => t.type === 'OUT' && isConfirmedForAnalytics(t)).length;
    
    if (totalOrders === 0) {return { rate: 0, events: 0, orders: 0, tracked: false };}
    
    return {
      rate: ((stockoutEvents / totalOrders) * 100).toFixed(2),
      events: stockoutEvents,
      orders: totalOrders,
      tracked: false, // stockout events are never actually logged in this app -- rate is always 0, not a real measurement
      trend: this.calculateTrend('stockoutRate')
    };
  }

  /**
   * Calculate order accuracy.
   * Transactions in this app don't carry an `errors` field, so this can't
   * distinguish "0 errors, genuinely accurate" from "errors were never
   * tracked". Rather than silently reporting a fake 100%, this checks
   * whether any transaction actually has the field before trusting the count.
   */
  async calculateOrderAccuracy() {
    const transactions = await this.dataSources.transactions || [];
    const outOrders = transactions.filter(t => t.type === 'OUT' && isConfirmedForAnalytics(t));
    const errorFieldTracked = transactions.some(t => t.errors !== undefined);
    
    if (outOrders.length === 0 || !errorFieldTracked) {
      return { accuracy: null, accurate: 0, total: outOrders.length, tracked: false };
    }
    
    const accurateOrders = outOrders.filter(t => !t.errors).length;
    
    return {
      accuracy: ((accurateOrders / outOrders.length) * 100).toFixed(2),
      accurate: accurateOrders,
      total: outOrders.length,
      tracked: true,
      trend: this.calculateTrend('orderAccuracy')
    };
  }

  /**
   * Calculate supplier performance.
   * GRN records in this app don't track an on-time/late flag against a
   * promised delivery date, so onTimeRate can't be honestly computed today.
   * Rather than reporting a fake 0% ("always late") for every supplier
   * whenever the field is simply absent, this reports totalDeliveries (real)
   * and marks onTimeRate as not tracked when no GRN anywhere has the field.
   */
  async calculateSupplierPerformance() {
    const suppliers = await this.dataSources.suppliers || [];
    const grn = await this.dataSources.grn || [];
    const onTimeTracked = grn.some(g => g.onTime !== undefined);
    
    const performance = suppliers.map(supplier => {
      const supplierGRN = grn.filter(g => g.supplierId === supplier.id);
      const onTimeDeliveries = supplierGRN.filter(g => g.onTime).length;
      const totalDeliveries = supplierGRN.length;
      
      return {
        id: supplier.id,
        name: supplier.name,
        onTimeRate: (onTimeTracked && totalDeliveries > 0) ? ((onTimeDeliveries / totalDeliveries) * 100).toFixed(2) : null,
        totalDeliveries,
        qualityScore: supplier.qualityScore ?? null
      };
    });
    
    const trackedRates = performance.filter(p => p.onTimeRate !== null).map(p => parseFloat(p.onTimeRate));
    const avgOnTimeRate = trackedRates.length > 0
      ? (trackedRates.reduce((sum, r) => sum + r, 0) / trackedRates.length).toFixed(2)
      : null;
    
    return {
      average: avgOnTimeRate,
      tracked: onTimeTracked,
      bySupplier: performance,
      trend: this.calculateTrend('supplierPerformance')
    };
  }

  /**
   * Calculate demand forecast accuracy.
   * This app doesn't persist forecast-vs-actual history, so
   * dataSources.forecasts/actuals are always empty -- this correctly reports
   * samples: 0 rather than fabricating an accuracy number.
   */
  async calculateForecastAccuracy() {
    const forecasts = await this.dataSources.forecasts || [];
    const actuals = await this.dataSources.actuals || [];
    
    if (forecasts.length === 0) {return { accuracy: null, samples: 0, tracked: false };}
    
    let totalError = 0;
    let samples = 0;
    
    forecasts.forEach(forecast => {
      const actual = actuals.find(a => a.materialId === forecast.materialId && a.period === forecast.period);
      if (actual) {
        const error = Math.abs((actual.value - forecast.value) / actual.value);
        totalError += error;
        samples++;
      }
    });
    
    const accuracy = samples > 0 ? ((1 - totalError / samples) * 100).toFixed(2) : null;
    
    return {
      accuracy,
      samples,
      tracked: samples > 0,
      trend: this.calculateTrend('forecastAccuracy')
    };
  }

  /**
   * Calculate inventory carrying cost. Needs materials[].value (stock * unit
   * cost) -- now populated from the Unit Cost field on the material form.
   */
  async calculateCarryingCost() {
    const materials = await this.dataSources.materials || [];
    const carryingCostRate = 0.25; // 25% annual carrying cost
    
    const totalInventoryValue = materials.reduce((sum, m) => sum + (m.value || 0), 0);
    const annualCarryingCost = totalInventoryValue * carryingCostRate;
    const monthlyCarryingCost = annualCarryingCost / 12;
    
    return {
      totalValue: totalInventoryValue,
      annualCost: annualCarryingCost.toFixed(2),
      monthlyCost: monthlyCarryingCost.toFixed(2),
      carryingCostRate: (carryingCostRate * 100).toFixed(2),
      trend: this.calculateTrend('carryingCost')
    };
  }

  /**
   * Calculate fill rate.
   * Transactions in this app don't carry requestedQty/filledQty (indents and
   * the OUT transaction that fulfills one aren't reconciled at that level),
   * so this can't be honestly computed yet -- reports not-tracked rather than
   * a fabricated 100%.
   */
  async calculateFillRate() {
    const transactions = await this.dataSources.transactions || [];
    const outOrders = transactions.filter(t => t.type === 'OUT' && isConfirmedForAnalytics(t));
    const fillTracked = outOrders.some(t => t.requestedQty !== undefined || t.filledQty !== undefined);
    
    if (!fillTracked) {return { rate: null, filled: 0, requested: 0, tracked: false };}
    
    const totalRequested = outOrders.reduce((sum, t) => sum + (t.requestedQty || 0), 0);
    const totalFilled = outOrders.reduce((sum, t) => sum + (t.filledQty || 0), 0);
    
    if (totalRequested === 0) {return { rate: null, filled: 0, requested: 0, tracked: false };}
    
    return {
      rate: ((totalFilled / totalRequested) * 100).toFixed(2),
      filled: totalFilled,
      requested: totalRequested,
      tracked: true,
      trend: this.calculateTrend('fillRate')
    };
  }

  /**
   * Calculate average lead time.
   * GRN records don't track leadTime (days between PO and receipt) today,
   * so this reports not-tracked rather than a fabricated 0.
   */
  async calculateAverageLeadTime() {
    const grn = await this.dataSources.grn || [];
    
    const leadTimes = grn
      .filter(g => g.leadTime !== undefined && g.leadTime !== null)
      .map(g => g.leadTime);
    
    if (leadTimes.length === 0) {return { average: null, samples: 0, tracked: false };}
    
    const average = (leadTimes.reduce((sum, lt) => sum + lt, 0) / leadTimes.length).toFixed(2);
    
    return {
      average,
      samples: leadTimes.length,
      tracked: true,
      trend: this.calculateTrend('leadTime')
    };
  }

  /**
   * Calculate trend for a metric
   */
  calculateTrend(metricName) {
    const history = this.metrics.get(metricName) || [];
    if (history.length < 2) {return 'stable';}
    
    const recent = history.slice(-5);
    const values = recent.map(h => h.value);
    
    const first = values[0];
    const last = values[values.length - 1];
    const change = ((last - first) / first) * 100;
    
    if (change > 5) {return 'increasing';}
    if (change < -5) {return 'decreasing';}
    return 'stable';
  }

  /**
   * Build dashboard configurations
   */
  buildDashboards() {
    this.dashboards.set('executive', this.buildExecutiveDashboard());
    this.dashboards.set('inventory', this.buildInventoryDashboard());
    this.dashboards.set('procurement', this.buildProcurementDashboard());
    this.dashboards.set('operations', this.buildOperationsDashboard());
  }

  /**
   * Build executive dashboard
   */
  buildExecutiveDashboard() {
    const kpis = this.kpis.get('current') || {};
    
    return {
      name: 'Executive Overview',
      widgets: [
        {
          type: 'kpi',
          title: 'Inventory Turnover',
          value: kpis.inventoryTurnover?.ratio || 0,
          format: 'number',
          trend: kpis.inventoryTurnover?.trend || 'stable'
        },
        {
          type: 'kpi',
          title: 'Stockout Rate',
          value: kpis.stockoutRate?.tracked ? kpis.stockoutRate.rate : 'N/A',
          format: 'percentage',
          trend: kpis.stockoutRate?.trend || 'stable'
        },
        {
          type: 'kpi',
          title: 'Order Accuracy',
          value: kpis.orderAccuracy?.tracked ? kpis.orderAccuracy.accuracy : 'N/A',
          format: 'percentage',
          trend: kpis.orderAccuracy?.trend || 'stable'
        },
        {
          type: 'kpi',
          title: 'Fill Rate',
          value: kpis.fillRate?.tracked ? kpis.fillRate.rate : 'N/A',
          format: 'percentage',
          trend: kpis.fillRate?.trend || 'stable'
        },
        {
          type: 'chart',
          title: 'Inventory Value Trend',
          chartType: 'line',
          dataSource: 'inventoryValue'
        },
        {
          type: 'chart',
          title: 'Order Volume',
          chartType: 'bar',
          dataSource: 'orderVolume'
        }
      ]
    };
  }

  /**
   * Build inventory dashboard
   */
  buildInventoryDashboard() {
    return {
      name: 'Inventory Management',
      widgets: [
        {
          type: 'kpi',
          title: 'Total Materials',
          value: 0,
          format: 'number'
        },
        {
          type: 'kpi',
          title: 'Total Value',
          value: 0,
          format: 'currency'
        },
        {
          type: 'chart',
          title: 'Stock by Category',
          chartType: 'pie',
          dataSource: 'stockByCategory'
        },
        {
          type: 'chart',
          title: 'Stock Movement',
          chartType: 'line',
          dataSource: 'stockMovement'
        },
        {
          type: 'table',
          title: 'Top Stockouts',
          dataSource: 'topStockouts'
        }
      ]
    };
  }

  /**
   * Build procurement dashboard
   */
  buildProcurementDashboard() {
    const kpis = this.kpis.get('current') || {};
    
    return {
      name: 'Procurement',
      widgets: [
        {
          type: 'kpi',
          title: 'Supplier On-Time Rate',
          value: kpis.supplierPerformance?.average || 0,
          format: 'percentage'
        },
        {
          type: 'kpi',
          title: 'Average Lead Time',
          value: kpis.averageLeadTime?.average || 0,
          format: 'days'
        },
        {
          type: 'chart',
          title: 'Supplier Performance',
          chartType: 'bar',
          dataSource: 'supplierPerformance'
        },
        {
          type: 'table',
          title: 'Pending POs',
          dataSource: 'pendingPOs'
        }
      ]
    };
  }

  /**
   * Build operations dashboard
   */
  buildOperationsDashboard() {
    return {
      name: 'Operations',
      widgets: [
        {
          type: 'kpi',
          title: 'Active Users',
          value: 0,
          format: 'number'
        },
        {
          type: 'kpi',
          title: 'Today\'s Transactions',
          value: 0,
          format: 'number'
        },
        {
          type: 'chart',
          title: 'Transaction Volume',
          chartType: 'line',
          dataSource: 'transactionVolume'
        },
        {
          type: 'chart',
          title: 'Activity by User',
          chartType: 'bar',
          dataSource: 'userActivity'
        }
      ]
    };
  }

  /**
   * Get dashboard data
   */
  getDashboard(dashboardName) {
    return this.dashboards.get(dashboardName);
  }

  /**
   * Get all dashboards
   */
  getAllDashboards() {
    return Array.from(this.dashboards.values());
  }

  /**
   * Generate custom report
   */
  async generateReport(reportConfig) {
    const { type, period, filters } = reportConfig;
    
    const report = {
      type,
      period,
      filters,
      generatedAt: new Date(),
      data: await this.fetchReportData(type, period, filters)
    };
    
    this.reports.set(`${type}_${Date.now()}`, report);
    return report;
  }

  /**
   * Fetch report data
   */
  async fetchReportData(type, period, filters = {}) {
    // Build reports from the same live data sources used by the KPI layer.
    // Never return an empty placeholder for a requested report.
    const sources = this.dataSources || {};
    const normalizeDate = value => {
      const d = value ? new Date(value) : null;
      return d && !Number.isNaN(d.getTime()) ? d : null;
    };
    const from = normalizeDate(filters.from || filters.startDate);
    const to = normalizeDate(filters.to || filters.endDate);
    const inPeriod = row => {
      const raw = row?.date || row?.time || row?.timestamp || row?.createdAt || row?.receivedAt;
      const d = normalizeDate(raw);
      if (!d) return !from && !to;
      if (from && d < from) return false;
      if (to && d > to) return false;
      return true;
    };
    const transactions = (await sources.transactions) || [];
    const materials = (await sources.materials) || [];
    const suppliers = (await sources.suppliers) || [];
    const grn = (await sources.grn) || [];
    const filteredTransactions = transactions.filter(inPeriod);
    const filteredGrn = grn.filter(inPeriod);
    const name = String(type || 'operations').toLowerCase();

    if (name.includes('inventory') || name.includes('stock')) {
      return materials.map(m => ({
        id: m.id, name: m.name, barcode: m.barcode, category: m.category,
        stock: Number(m.stock || 0), lowAlert: Number(m.lowAlert || 0),
        unitCost: Number(m.unitCost || 0), value: Number(m.stock || 0) * Number(m.unitCost || 0),
        lowStock: Number(m.stock || 0) === 0 || Number(m.stock || 0) < Number(m.lowAlert || 0)
      }));
    }
    if (name.includes('supplier')) {
      return suppliers.map(s => {
        const rows = filteredGrn.filter(g => g.supplierId === s.id);
        return { id: s.id, name: s.name, deliveries: rows.length,
          onTime: rows.filter(g => g.onTime === true).length,
          onTimeRate: rows.some(g => g.onTime !== undefined) && rows.length ? Number((rows.filter(g => g.onTime === true).length / rows.length * 100).toFixed(2)) : null };
      });
    }
    if (name.includes('transaction') || name.includes('movement') || name.includes('operations')) {
      const summary = filteredTransactions.reduce((acc, t) => {
        const typeKey = String(t.type || 'OTHER').toUpperCase();
        acc[typeKey] = (acc[typeKey] || 0) + Number(t.qty ?? t.quantity ?? 0);
        return acc;
      }, {});
      return { totalTransactions: filteredTransactions.length, quantitiesByType: summary, rows: filteredTransactions };
    }
    return {
      type, period, filters,
      generatedFrom: { materials: materials.length, transactions: filteredTransactions.length, suppliers: suppliers.length, grn: filteredGrn.length },
      rows: filteredTransactions
    };
  }

  /**
   * Refresh all metrics
   */
  async refresh() {
    await this.calculateKPIs();
    this.buildDashboards();
    this.lastRefresh = Date.now();
  }

  /**
   * Get current KPIs
   */
  getKPIs() {
    return this.kpis.get('current') || {};
  }

  /**
   * Export dashboard data
   */
  exportDashboard(dashboardName, format = 'json') {
    const dashboard = this.dashboards.get(dashboardName);
    if (!dashboard) {return null;}
    
    if (format === 'json') {
      return JSON.stringify(dashboard, null, 2);
    } else if (format === 'csv') {
      return this.convertToCSV(dashboard);
    }
    
    return null;
  }

  /**
   * Convert dashboard data to CSV
   */
  convertToCSV(dashboard) {
    // Simplified CSV conversion
    const headers = ['Widget', 'Title', 'Value', 'Type'];
    const rows = dashboard.widgets.map(w => [
      w.type,
      w.title,
      w.value || 'N/A',
      w.chartType || 'N/A'
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  }
}

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { BusinessIntelligence };
}

// Global BI instance -- mirrors the pattern already used by sentryIntegration.js,
// apmMonitoring.js, anomalyDetection.js, etc. Previously defined but never
// instantiated, so the BI Dashboard's KPI cards silently no-opped forever.
const businessIntelligence = new BusinessIntelligence();

if (typeof window !== 'undefined') {
  window.BusinessIntelligence = BusinessIntelligence;
  window.businessIntelligence = businessIntelligence;
}
