// Excel Export Module - Export data to Excel with formatting

/**
 * Excel Export Manager
 */
class ExcelExportManager {
  constructor() {
    this.formatters = new Map();
    this.init();
  }

  /**
   * Initialize export manager
   */
  init() {
    this.setupDefaultFormatters();
  }

  /**
   * Setup default formatters
   */
  setupDefaultFormatters() {
    this.formatters.set('number', {
      format: '#,##0.00',
      align: 'right'
    });

    this.formatters.set('currency', {
      format: '"$"#,##0.00',
      align: 'right'
    });

    this.formatters.set('percentage', {
      format: '0.00%',
      align: 'right'
    });

    this.formatters.set('date', {
      format: 'yyyy-mm-dd',
      align: 'left'
    });

    this.formatters.set('datetime', {
      format: 'yyyy-mm-dd hh:mm:ss',
      align: 'left'
    });

    this.formatters.set('text', {
      format: '@',
      align: 'left'
    });
  }

  /**
   * Add custom formatter
   * @param {string} name - Formatter name
   * @param {object} formatter - Formatter configuration
   */
  addFormatter(name, formatter) {
    this.formatters.set(name, formatter);
  }

  /**
   * Get formatter
   * @param {string} name - Formatter name
   * @returns {object} - Formatter configuration
   */
  getFormatter(name) {
    return this.formatters.get(name) || this.formatters.get('text');
  }

  /**
   * Export data to a real Excel-compatible HTML workbook.
   * This avoids silently returning an empty file when the optional XLSX
   * dependency is not installed; Excel opens the generated .xls workbook.
   * @param {Array} data - Data to export
   * @param {object} options - Export options
   * @returns {Promise<ArrayBuffer>} - UTF-8 Excel-compatible workbook buffer
   */
  async exportToExcel(data, options = {}) {
    const rows = Array.isArray(data) ? data : [];
    const columns = this.generateColumnDefinitions(rows, { headers: true, ...options });
    const esc = value => String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
    const head = columns.map(column => `<th>${esc(column.header)}</th>`).join('');
    const body = rows.map(row => `<tr>${columns.map(column => `<td>${esc(this.formatCellValue(row[column.key], column.format))}</td>`).join('')}</tr>`).join('');
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>table{border-collapse:collapse}th,td{border:1px solid #999;padding:4px}th{font-weight:bold;background:#eee}</style></head><body><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></body></html>`;
    return new TextEncoder().encode(html).buffer;
  }

  /**
   * Generate column definitions
   * @param {Array} data - Data to analyze
   * @param {object} options - Column options
   * @returns {Array} - Column definitions
   */
  generateColumnDefinitions(data, options = {}) {
    if (data.length === 0) {return [];}

    const sample = data[0];
    const columns = [];

    Object.keys(sample).forEach(key => {
      const value = sample[key];
      const type = this.detectType(value, key);
      
      columns.push({
        key,
        header: options.headers ? this.formatHeader(key) : key,
        width: this.calculateWidth(key, data, type),
        type,
        format: options.columnFormats && options.columnFormats[key] 
          ? options.columnFormats[key] 
          : this.getDefaultFormat(type)
      });
    });

    return columns;
  }

  /**
   * Detect data type
   * @param {any} value - Value to check
   * @returns {string} - Data type
   */
  detectType(value) {
    if (value === null || value === undefined) {return 'text';}
    if (typeof value === 'number') {return 'number';}
    if (typeof value === 'boolean') {return 'boolean';}
    if (this.isDate(value)) {return 'date';}
    return 'text';
  }

  /**
   * Check if value is a date
   * @param {any} value - Value to check
   * @returns {boolean} - Is date
   */
  isDate(value) {
    if (value instanceof Date) {return true;}
    if (typeof value === 'string') {
      const candidate = value.trim();
      if (!/^\d{4}-\d{2}-\d{2}(?:[Tt ][0-9]{2}:[0-9]{2}(?::[0-9]{2}(?:\.\d{1,3})?)?(?:Z|[+-][0-9]{2}:?[0-9]{2})?)?$|^\d{1,2}\/\d{1,2}\/\d{4}$/.test(candidate)) return false;
      return !Number.isNaN(new Date(candidate).getTime());
    }
    return false;
  }

  neutralizeSpreadsheetFormula(formattedValue, originalValue) {
    const text = String(formattedValue ?? '');
    let firstSignificant = 0;
    while (firstSignificant < text.length && text.charCodeAt(firstSignificant) <= 0x20) firstSignificant += 1;
    return typeof originalValue === 'string' && '=+-@'.includes(text[firstSignificant] || '') ? `'${text}` : text;
  }

  /**
   * Format header
   * @param {string} key - Field key
   * @returns {string} - Formatted header
   */
  formatHeader(key) {
    return key
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, str => str.toUpperCase())
      .trim();
  }

  /**
   * Calculate column width
   * @param {string} key - Field key
   * @param {Array} data - Data to analyze
   * @param {string} type - Data type
   * @returns {number} - Column width
   */
  calculateWidth(key, data, type) {
    const headerWidth = key.length + 2;
    
    if (data.length === 0) {return headerWidth;}

    let maxContentWidth = 0;
    const sampleSize = Math.min(data.length, 100);

    for (let i = 0; i < sampleSize; i++) {
      const value = data[i][key];
      const contentLength = String(value || '').length;
      if (contentLength > maxContentWidth) {
        maxContentWidth = contentLength;
      }
    }

    return Math.max(headerWidth, maxContentWidth + 2);
  }

  /**
   * Get default format for type
   * @param {string} type - Data type
   * @returns {string} - Format string
   */
  getDefaultFormat(type) {
    const formats = {
      number: 'number',
      currency: 'currency',
      percentage: 'percentage',
      date: 'date',
      datetime: 'datetime',
      boolean: 'text',
      text: 'text'
    };
    
    return formats[type] || 'text';
  }

  /**
   * Apply cell formatting
   * @param {any} value - Cell value
   * @param {string} format - Format type
   * @returns {string} - Formatted value
   */
  formatCellValue(value, format) {
    if (value === null || value === undefined) {return '';}

    switch (format) {
      case 'number':
        return Number(value).toLocaleString();
      case 'currency':
        return Number(value).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
      case 'percentage':
        return (Number(value) * 100).toFixed(2) + '%';
      case 'date':
        return new Date(value).toLocaleDateString();
      case 'datetime':
        return new Date(value).toLocaleString();
      default:
        return String(value);
    }
  }

  /**
   * Generate Excel-compatible CSV
   * @param {Array} data - Data to export
   * @param {object} options - Export options
   * @returns {string} - Excel-compatible CSV
   */
  generateExcelCSV(data, options = {}) {
    if (data.length === 0) {return '';}

    const columns = this.generateColumnDefinitions(data, options);
    const rows = [];

    // Header row with BOM for Excel UTF-8
    const headerRow = columns.map(col => `"${this.neutralizeSpreadsheetFormula(col.header, col.header).replace(/"/g, '""')}"`).join(',');
    rows.push('\uFEFF' + headerRow);

    // Data rows
    data.forEach(item => {
      const row = columns.map(col => {
        const value = item[col.key];
        const formatted = this.formatCellValue(value, col.format);
        const safeValue = this.neutralizeSpreadsheetFormula(formatted, value);
        return `"${String(safeValue).replace(/"/g, '""')}"`;
      });
      rows.push(row.join(','));
    });

    return rows.join('\n');
  }

  /**
   * Export to Excel-compatible CSV
   * @param {Array} data - Data to export
   * @param {object} options - Export options
   * @returns {string} - CSV string
   */
  exportToCSV(data, options = {}) {
    return this.generateExcelCSV(data, options);
  }

  /**
   * Download Excel file
   * @param {ArrayBuffer} buffer - Excel file buffer
   * @param {string} filename - File name
   */
  downloadExcel(buffer, filename) {
    const blob = new Blob([buffer], { type: 'application/vnd.ms-excel' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  /**
   * Download CSV file
   * @param {string} csv - CSV string
   * @param {string} filename - File name
   */
  downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  /**
   * Get export template
   * @param {string} storeName - Store name
   * @returns {string} - CSV template
   */
  getTemplate(storeName) {
    const templates = {
      materials: 'barcode,name,category,unit,currentStock,minStock,maxStock,unitPrice,active',
      transactions: 'barcode,itemName,type,quantity,user,time',
      users: 'username,name,role,active'
    };

    return templates[storeName] || '';
  }

  /**
   * Download template
   * @param {string} storeName - Store name
   */
  downloadTemplate(storeName) {
    const template = this.getTemplate(storeName);
    const csv = '\uFEFF' + template + '\n';
    this.downloadCSV(csv, `${storeName}_template.csv`);
  }
}

/**
 * Global export manager instance
 */
const excelExportManager = new ExcelExportManager();

/**
 * Initialize Excel export
 */
function initExcelExport() {
  return excelExportManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.ExcelExport = {
    manager: excelExportManager,
    init: initExcelExport,
    exportToExcel: (data, opts) => excelExportManager.exportToExcel(data, opts),
    exportToCSV: (data, opts) => excelExportManager.exportToCSV(data, opts),
    downloadExcel: (buf, name) => excelExportManager.downloadExcel(buf, name),
    downloadCSV: (csv, name) => excelExportManager.downloadCSV(csv, name),
    downloadTemplate: (store) => excelExportManager.downloadTemplate(store),
    addFormatter: (name, fmt) => excelExportManager.addFormatter(name, fmt),
    formatValue: (val, fmt) => excelExportManager.formatCellValue(val, fmt)
  };
}
