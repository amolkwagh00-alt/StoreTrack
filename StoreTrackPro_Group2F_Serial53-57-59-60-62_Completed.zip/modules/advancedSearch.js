// Advanced Search Module - Multi-criteria search with saved filters

/**
 * Search Criteria class
 */
class SearchCriteria {
  constructor(field, operator, value, label = '') {
    this.field = field;
    this.operator = operator;
    this.value = value;
    this.label = label || field;
    this.id = this.generateId();
  }

  generateId() {
    return `${this.field}-${this.operator}-${Date.now()}`;
  }

  /**
   * Test if item matches criteria
   * @param {object} item - Item to test
   * @returns {boolean} - Match result
   */
  matches(item) {
    const itemValue = item[this.field];
    
    switch (this.operator) {
      case 'eq':
        return itemValue === this.value;
      case 'neq':
        return itemValue !== this.value;
      case 'contains':
        return String(itemValue).toLowerCase().includes(String(this.value).toLowerCase());
      case 'not_contains':
        return !String(itemValue).toLowerCase().includes(String(this.value).toLowerCase());
      case 'starts_with':
        return String(itemValue).toLowerCase().startsWith(String(this.value).toLowerCase());
      case 'ends_with':
        return String(itemValue).toLowerCase().endsWith(String(this.value).toLowerCase());
      case 'gt':
        return itemValue > this.value;
      case 'gte':
        return itemValue >= this.value;
      case 'lt':
        return itemValue < this.value;
      case 'lte':
        return itemValue <= this.value;
      case 'between':
        return itemValue >= this.value[0] && itemValue <= this.value[1];
      case 'is_null':
        return itemValue == null;
      case 'is_not_null':
        return itemValue != null;
      case 'in':
        return Array.isArray(this.value) && this.value.includes(itemValue);
      case 'not_in':
        return Array.isArray(this.value) && !this.value.includes(itemValue);
      default:
        return true;
    }
  }
}

/**
 * Advanced Search Manager
 */
class AdvancedSearchManager {
  constructor() {
    this.criteria = [];
    this.savedFilters = new Map();
    this.searchHistory = [];
    this.dataSource = null;
    if (window.databaseReady) {
      this.init();
    } else {
      document.addEventListener('databaseReady', () => this.init(), { once: true });
    }
  }

  /**
   * Initialize search manager
   */
  init() {
    this.loadSavedFilters();
    this.loadSearchHistory();
  }

  /**
   * Set data source
   * @param {string} source - Data source name
   */
  setDataSource(source) {
    this.dataSource = source;
  }

  /**
   * Add search criteria
   * @param {string} field - Field name
   * @param {string} operator - Operator
   * @param {any} value - Value
   * @param {string} label - Field label
   */
  addCriteria(field, operator, value, label = '') {
    const criteria = new SearchCriteria(field, operator, value, label);
    this.criteria.push(criteria);
    return criteria;
  }

  /**
   * Remove criteria by ID
   * @param {string} id - Criteria ID
   */
  removeCriteria(id) {
    this.criteria = this.criteria.filter(c => c.id !== id);
  }

  /**
   * Clear all criteria
   */
  clearCriteria() {
    this.criteria = [];
  }

  /**
   * Update criteria
   * @param {string} id - Criteria ID
   * @param {object} updates - Updates to apply
   */
  updateCriteria(id, updates) {
    const criteria = this.criteria.find(c => c.id === id);
    if (criteria) {
      Object.assign(criteria, updates);
    }
  }

  /**
   * Get all criteria
   * @returns {Array} - Array of criteria
   */
  getCriteria() {
    return this.criteria;
  }

  /**
   * Search data with current criteria
   * @param {Array} data - Data to search
   * @param {string} logic - Logic operator ('and' or 'or')
   * @returns {Array} - Filtered data
   */
  search(data, logic = 'and') {
    if (this.criteria.length === 0) {
      return data;
    }

    return data.filter(item => {
      if (logic === 'and') {
        return this.criteria.every(c => c.matches(item));
      } else {
        return this.criteria.some(c => c.matches(item));
      }
    });
  }

  /**
   * Search IndexedDB with criteria
   * @param {string} storeName - Store name
   * @param {string} logic - Logic operator
   * @returns {Promise<Array>} - Filtered data
   */
  async searchDB(storeName, logic = 'and') {
    try {
      const data = await gAll(storeName);
      return this.search(data, logic);
    } catch (err) {
      console.error('Search failed:', err);
      return [];
    }
  }

  /**
   * Save current filter
   * @param {string} name - Filter name
   * @param {string} description - Filter description
   */
  async saveFilter(name, description = '') {
    const filter = {
      id: this.generateFilterId(name),
      name,
      description,
      criteria: JSON.parse(JSON.stringify(this.criteria)),
      dataSource: this.dataSource,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.savedFilters.set(filter.id, filter);
    await this.saveFiltersToStorage();
    
    // Add to history
    this.addToHistory(filter);
    
    return filter;
  }

  /**
   * Generate filter ID
   * @param {string} name - Filter name
   * @returns {string} - Filter ID
   */
  generateFilterId(name) {
    return name.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now();
  }

  /**
   * Load saved filter
   * @param {string} id - Filter ID
   */
  loadFilter(id) {
    const filter = this.savedFilters.get(id);
    if (filter) {
      this.criteria = (Array.isArray(filter.criteria) ? filter.criteria : []).map(item => {
        const criterion = new SearchCriteria(item.field, item.operator, item.value, item.label);
        if (item.id) criterion.id = item.id;
        return criterion;
      });
      this.dataSource = filter.dataSource;
    }
    return filter;
  }

  /**
   * Delete saved filter
   * @param {string} id - Filter ID
   */
  async deleteFilter(id) {
    this.savedFilters.delete(id);
    await this.saveFiltersToStorage();
  }

  /**
   * Get all saved filters
   * @returns {Array} - Array of saved filters
   */
  getSavedFilters() {
    return Array.from(this.savedFilters.values());
  }

  /**
   * Get saved filters for data source
   * @param {string} source - Data source name
   * @returns {Array} - Array of filters
   */
  getFiltersForSource(source) {
    return this.getSavedFilters().filter(f => f.dataSource === source);
  }

  /**
   * Load saved filters from storage
   */
  async loadSavedFilters() {
    try {
      const filters = await gAll('saved_filters');
      filters.forEach(filter => {
        const criteria = (Array.isArray(filter.criteria) ? filter.criteria : []).map(item => {
          const criterion = new SearchCriteria(item.field, item.operator, item.value, item.label);
          if (item.id) criterion.id = item.id;
          return criterion;
        });
        this.savedFilters.set(filter.id, { ...filter, criteria });
      });
    } catch (err) {
      console.error('Failed to load saved filters:', err);
    }
  }

  /**
   * Save filters to storage
   */
  async saveFiltersToStorage() {
    try {
      await dClr('saved_filters');
      await batchPut('saved_filters', Array.from(this.savedFilters.values()));
    } catch (err) {
      console.error('Failed to save filters:', err);
    }
  }

  /**
   * Add to search history
   * @param {object} filter - Filter to add
   */
  addToHistory(filter) {
    this.searchHistory.unshift({
      ...filter,
      searchedAt: new Date().toISOString()
    });
    
    // Keep only last 50 searches
    if (this.searchHistory.length > 50) {
      this.searchHistory = this.searchHistory.slice(0, 50);
    }
  }

  /**
   * Load search history from storage
   */
  async loadSearchHistory() {
    try {
      const history = await gAll('search_history');
      this.searchHistory = history || [];
    } catch (err) {
      console.error('Failed to load search history:', err);
    }
  }

  /**
   * Get search history
   * @returns {Array} - Search history
   */
  getSearchHistory() {
    return this.searchHistory;
  }

  /**
   * Clear search history
   */
  clearHistory() {
    this.searchHistory = [];
  }

  /**
   * Export filter as JSON
   * @param {string} id - Filter ID
   * @returns {string} - JSON string
   */
  exportFilter(id) {
    const filter = this.savedFilters.get(id);
    if (filter) {
      return JSON.stringify(filter, null, 2);
    }
    return null;
  }

  /**
   * Import filter from JSON
   * @param {string} json - JSON string
   * @returns {object} - Imported filter
   */
  importFilter(json) {
    try {
      const filter = JSON.parse(json);
      filter.id = this.generateFilterId(filter.name);
      filter.createdAt = new Date().toISOString();
      filter.updatedAt = new Date().toISOString();
      filter.criteria = (Array.isArray(filter.criteria) ? filter.criteria : []).map(item => {
        const criterion = new SearchCriteria(item.field, item.operator, item.value, item.label);
        if (item.id) criterion.id = item.id;
        return criterion;
      });
      
      this.savedFilters.set(filter.id, filter);
      this.saveFiltersToStorage();
      
      return filter;
    } catch (err) {
      console.error('Failed to import filter:', err);
      return null;
    }
  }

  /**
   * Get available operators for field type
   * @param {string} fieldType - Field type
   * @returns {Array} - Available operators
   */
  getOperatorsForType(fieldType) {
    const operators = {
      text: ['eq', 'neq', 'contains', 'not_contains', 'starts_with', 'ends_with', 'is_null', 'is_not_null'],
      number: ['eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'between', 'is_null', 'is_not_null'],
      date: ['eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'between', 'is_null', 'is_not_null'],
      boolean: ['eq', 'neq'],
      select: ['eq', 'neq', 'in', 'not_in', 'is_null', 'is_not_null']
    };
    
    return operators[fieldType] || operators.text;
  }

  /**
   * Get operator label
   * @param {string} operator - Operator code
   * @returns {string} - Operator label
   */
  getOperatorLabel(operator) {
    const labels = {
      eq: 'Equals',
      neq: 'Not Equals',
      contains: 'Contains',
      not_contains: 'Does Not Contain',
      starts_with: 'Starts With',
      ends_with: 'Ends With',
      gt: 'Greater Than',
      gte: 'Greater Than or Equal',
      lt: 'Less Than',
      lte: 'Less Than or Equal',
      between: 'Between',
      is_null: 'Is Null',
      is_not_null: 'Is Not Null',
      in: 'In',
      not_in: 'Not In'
    };
    
    return labels[operator] || operator;
  }

  /**
   * Get field definitions for data source
   * @param {string} source - Data source name
   * @returns {Array} - Field definitions
   */
  getFieldDefinitions(source) {
    const definitions = {
      materials: [
        { field: 'barcode', label: 'Barcode', type: 'text' },
        { field: 'name', label: 'Name', type: 'text' },
        { field: 'category', label: 'Category', type: 'select', options: [] },
        { field: 'currentStock', label: 'Current Stock', type: 'number' },
        { field: 'minStock', label: 'Min Stock', type: 'number' },
        { field: 'maxStock', label: 'Max Stock', type: 'number' },
        { field: 'unit', label: 'Unit', type: 'select', options: ['pcs', 'kg', 'liters', 'meters'] },
        { field: 'active', label: 'Active', type: 'boolean' }
      ],
      transactions: [
        { field: 'barcode', label: 'Barcode', type: 'text' },
        { field: 'itemName', label: 'Item Name', type: 'text' },
        { field: 'type', label: 'Type', type: 'select', options: ['IN', 'OUT', 'ADJUSTMENT'] },
        { field: 'quantity', label: 'Quantity', type: 'number' },
        { field: 'time', label: 'Date/Time', type: 'date' },
        { field: 'user', label: 'User', type: 'text' }
      ],
      users: [
        { field: 'username', label: 'Username', type: 'text' },
        { field: 'name', label: 'Name', type: 'text' },
        { field: 'role', label: 'Role', type: 'select', options: ['Admin', 'Store', 'Viewer'] },
        { field: 'active', label: 'Active', type: 'boolean' }
      ]
    };
    
    return definitions[source] || [];
  }
}

/**
 * Global search manager instance
 */
const searchManager = new AdvancedSearchManager();

/**
 * Initialize advanced search
 * @param {string} dataSource - Default data source
 */
function initAdvancedSearch(dataSource) {
  if (dataSource) {
    searchManager.setDataSource(dataSource);
  }
  return searchManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.AdvancedSearch = {
    manager: searchManager,
    init: initAdvancedSearch,
    setDataSource: (source) => searchManager.setDataSource(source),
    addCriteria: (field, op, val, label) => searchManager.addCriteria(field, op, val, label),
    removeCriteria: (id) => searchManager.removeCriteria(id),
    clearCriteria: () => searchManager.clearCriteria(),
    search: (data, logic) => searchManager.search(data, logic),
    searchDB: (store, logic) => searchManager.searchDB(store, logic),
    saveFilter: (name, desc) => searchManager.saveFilter(name, desc),
    loadFilter: (id) => searchManager.loadFilter(id),
    deleteFilter: (id) => searchManager.deleteFilter(id),
    getSavedFilters: () => searchManager.getSavedFilters(),
    getFiltersForSource: (source) => searchManager.getFiltersForSource(source),
    getHistory: () => searchManager.getSearchHistory(),
    clearHistory: () => searchManager.clearHistory(),
    exportFilter: (id) => searchManager.exportFilter(id),
    importFilter: (json) => searchManager.importFilter(json),
    getOperatorsForType: (type) => searchManager.getOperatorsForType(type),
    getOperatorLabel: (op) => searchManager.getOperatorLabel(op),
    getFieldDefinitions: (source) => searchManager.getFieldDefinitions(source)
  };
}
