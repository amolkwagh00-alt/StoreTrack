/* StoreTrack Pro — right-button drag panning for all table wrappers. */
(function () {
  'use strict';

  const state = {
    container: null,
    startX: 0,
    startY: 0,
    startScrollLeft: 0,
    startScrollTop: 0,
  };

  function tableContainer(target) {
    return target && target.closest ? target.closest('.tw') : null;
  }

  function stopPan() {
    if (!state.container) {
      return;
    }
    state.container.classList.remove('table-pan-active');
    document.body.classList.remove('table-pan-dragging');
    state.container = null;
  }

  document.addEventListener('contextmenu', (event) => {
    if (tableContainer(event.target)) {
      event.preventDefault();
    }
  });

  document.addEventListener('mousedown', (event) => {
    if (event.button !== 2) {
      return;
    }
    const container = tableContainer(event.target);
    if (!container || (container.scrollWidth <= container.clientWidth && container.scrollHeight <= container.clientHeight)) {
      return;
    }
    state.container = container;
    state.startX = event.clientX;
    state.startY = event.clientY;
    state.startScrollLeft = container.scrollLeft;
    state.startScrollTop = container.scrollTop;
    container.classList.add('table-pan-active');
    document.body.classList.add('table-pan-dragging');
    event.preventDefault();
  });

  document.addEventListener('mousemove', (event) => {
    if (!state.container) {
      return;
    }
    state.container.scrollLeft = state.startScrollLeft - (event.clientX - state.startX);
    state.container.scrollTop = state.startScrollTop - (event.clientY - state.startY);
    event.preventDefault();
  });

  document.addEventListener('mouseup', stopPan);
  document.addEventListener('mouseleave', stopPan);
  window.addEventListener('blur', stopPan);
})();

if (typeof window !== 'undefined') {
  window.StoreTrackTablePan = { enabled: true };
}

/* End of table-pan module. */
