// Caching Layer Module - Advanced caching for performance

/**
 * Cache Entry class
 */
class CacheEntry {
  constructor(config) {
    this.key = config.key || '';
    this.value = config.value || null;
    this.metadata = config.metadata || {};
    this.createdAt = config.createdAt || new Date().toISOString();
    this.lastAccessed = config.lastAccessed || new Date().toISOString();
    this.hitCount = config.hitCount || 0;
    this.ttl = config.ttl || null;
    this.expiresAt = config.expiresAt || null;
    this.size = config.size || this.calculateSize();
    this.tags = config.tags || [];
  }

  /**
   * Calculate size of entry
   * @returns {number} - Size in bytes
   */
  calculateSize() {
    const valueStr = JSON.stringify(this.value);
    return new Blob([valueStr]).size;
  }

  /**
   * Check if expired
   * @returns {boolean} - Is expired
   */
  isExpired() {
    if (!this.expiresAt) {return false;}
    return new Date() >= new Date(this.expiresAt);
  }

  /**
   * Record access
   */
  recordAccess() {
    this.hitCount++;
    this.lastAccessed = new Date().toISOString();
  }

  /**
   * Has tag
   * @param {string} tag - Tag to check
   * @returns {boolean} - Has tag
   */
  hasTag(tag) {
    return this.tags.includes(tag);
  }
}

/**
 * Cache Layer Manager
 */
class CacheLayerManager {
  constructor() {
    this.cache = new Map();
    this.indexes = new Map();
    this.maxSize = 50 * 1024 * 1024; // 50MB default
    this.maxEntries = 10000;
    this.defaultTTL = 300000; // 5 minutes
    this.currentSize = 0;
    this.statistics = {
      hits: 0,
      misses: 0,
      evictions: 0,
      sets: 0,
      deletes: 0
    };
    this.init();
  }

  /**
   * Initialize cache layer
   */
  async init() {
    await this.loadCache();
    this.startExpirationCheck();
    this.recalculateSize();
  }

  /**
   * Load cache from storage
   */
  async loadCache() {
    try {
      const cached = await gAll('cache_layer');
      cached.forEach(c => {
        const entry = new CacheEntry(c);
        if (!entry.isExpired()) {
          this.cache.set(c.key, entry);
          this.updateIndexes(entry);
        }
      });
    } catch (err) {
      console.error('Failed to load cache:', err);
    }
  }

  /**
   * Start expiration check
   */
  startExpirationCheck() {
    setInterval(() => {
      this.cleanupExpired();
    }, 60000); // Check every minute
  }

  /**
   * Recalculate total cache size
   */
  recalculateSize() {
    this.currentSize = Array.from(this.cache.values())
      .reduce((sum, entry) => sum + entry.size, 0);
  }

  /**
   * Update indexes for entry
   * @param {CacheEntry} entry - Cache entry
   */
  updateIndexes(entry) {
    // Update tag indexes
    for (const tag of entry.tags) {
      if (!this.indexes.has(tag)) {
        this.indexes.set(tag, new Set());
      }
      this.indexes.get(tag).add(entry.key);
    }
  }

  /**
   * Remove from indexes
   * @param {CacheEntry} entry - Cache entry
   */
  removeFromIndexes(entry) {
    for (const tag of entry.tags) {
      if (this.indexes.has(tag)) {
        this.indexes.get(tag).delete(entry.key);
        if (this.indexes.get(tag).size === 0) {
          this.indexes.delete(tag);
        }
      }
    }
  }

  /**
   * Set value in cache
   * @param {string} key - Cache key
   * @param {any} value - Value to cache
   * @param {object} options - Cache options
   * @returns {boolean} - Success
   */
  set(key, value, options = {}) {
    const ttl = options.ttl !== undefined ? options.ttl : this.defaultTTL;
    const tags = options.tags || [];
    const metadata = options.metadata || {};

    const entry = new CacheEntry({
      key,
      value,
      ttl,
      expiresAt: ttl ? new Date(Date.now() + ttl).toISOString() : null,
      tags,
      metadata
    });

    // Check size limits
    if (entry.size > this.maxSize) {
      console.warn(`Cache entry too large: ${entry.size} bytes`);
      return false;
    }

    // Evict if necessary
    this.ensureSpace(entry.size);

    // Remove existing entry if present
    if (this.cache.has(key)) {
      const existing = this.cache.get(key);
      this.currentSize -= existing.size;
      this.removeFromIndexes(existing);
    }

    // Add new entry
    this.cache.set(key, entry);
    this.updateIndexes(entry);
    this.currentSize += entry.size;
    this.statistics.sets++;

    return true;
  }

  /**
   * Get value from cache
   * @param {string} key - Cache key
   * @returns {any|null} - Cached value or null
   */
  get(key) {
    const entry = this.cache.get(key);

    if (!entry) {
      this.statistics.misses++;
      return null;
    }

    if (entry.isExpired()) {
      this.delete(key);
      this.statistics.misses++;
      return null;
    }

    entry.recordAccess();
    this.statistics.hits++;

    return entry.value;
  }

  /**
   * Check if key exists
   * @param {string} key - Cache key
   * @returns {boolean} - Exists
   */
  has(key) {
    const entry = this.cache.get(key);
    if (!entry) {return false;}
    if (entry.isExpired()) {
      this.delete(key);
      return false;
    }
    return true;
  }

  /**
   * Delete from cache
   * @param {string} key - Cache key
   * @returns {boolean} - Success
   */
  delete(key) {
    const entry = this.cache.get(key);
    if (entry) {
      this.currentSize -= entry.size;
      this.removeFromIndexes(entry);
      this.cache.delete(key);
      this.statistics.deletes++;
      return true;
    }
    return false;
  }

  /**
   * Clear cache
   * @param {string} tag - Tag to clear (optional)
   */
  clear(tag = null) {
    if (tag) {
      const keys = this.indexes.get(tag);
      if (keys) {
        for (const key of keys) {
          this.delete(key);
        }
      }
    } else {
      this.cache.clear();
      this.indexes.clear();
      this.currentSize = 0;
    }
  }

  /**
   * Ensure space for new entry
   * @param {number} size - Size needed
   */
  ensureSpace(size) {
    // Check entry count limit
    while (this.cache.size >= this.maxEntries && this.cache.size > 0) {
      if (!this.evictOne()) break;
    }

    // Check size limit
    while (this.currentSize + size > this.maxSize && this.cache.size > 0) {
      if (!this.evictOne()) break;
    }
  }

  /**
   * Evict one entry using LRU
   */
  evictOne() {
    let lruKey;
    let hasLruKey = false;
    let lruTime = Date.now();

    for (const [key, entry] of this.cache) {
      const entryTime = new Date(entry.lastAccessed).getTime();
      if (!hasLruKey || entryTime < lruTime) {
        lruTime = entryTime;
        lruKey = key;
        hasLruKey = true;
      }
    }

    if (hasLruKey) {
      this.delete(lruKey);
      this.statistics.evictions++;
      return true;
    }
    return false;
  }

  /**
   * Cleanup expired entries
   */
  cleanupExpired() {
    const expiredKeys = [];

    for (const [key, entry] of this.cache) {
      if (entry.isExpired()) {
        expiredKeys.push(key);
      }
    }

    for (const key of expiredKeys) {
      this.delete(key);
    }
  }

  /**
   * Get by tag
   * @param {string} tag - Tag
   * @returns {Array} - Entries with tag
   */
  getByTag(tag) {
    const keys = this.indexes.get(tag);
    if (!keys) {return [];}

    const entries = [];
    for (const key of keys) {
      const entry = this.cache.get(key);
      if (entry && !entry.isExpired()) {
        entries.push(entry.value);
      }
    }

    return entries;
  }

  /**
   * Get multiple keys
   * @param {Array} keys - Cache keys
   * @returns {object} - Key-value pairs
   */
  getMany(keys) {
    const result = {};
    for (const key of keys) {
      result[key] = this.get(key);
    }
    return result;
  }

  /**
   * Set multiple keys
   * @param {object} entries - Key-value pairs
   * @param {object} options - Cache options
   */
  setMany(entries, options = {}) {
    for (const [key, value] of Object.entries(entries)) {
      this.set(key, value, options);
    }
  }

  /**
   * Get or set (lazy loading)
   * @param {string} key - Cache key
   * @param {Function} loader - Loader function
   * @param {object} options - Cache options
   * @returns {Promise<any>} - Value
   */
  async getOrSet(key, loader, options = {}) {
    const cached = this.get(key);
    if (cached !== null) {
      return cached;
    }

    const value = await loader();
    this.set(key, value, options);
    return value;
  }

  /**
   * Increment value
   * @param {string} key - Cache key
   * @param {number} amount - Amount to increment
   * @returns {number} - New value
   */
  increment(key, amount = 1) {
    const current = this.get(key) || 0;
    const newValue = current + amount;
    this.set(key, newValue);
    return newValue;
  }

  /**
   * Decrement value
   * @param {string} key - Cache key
   * @param {number} amount - Amount to decrement
   * @returns {number} - New value
   */
  decrement(key, amount = 1) {
    return this.increment(key, -amount);
  }

  /**
   * Get cache statistics
   * @returns {object} - Statistics
   */
  getStatistics() {
    const hitRate = this.statistics.hits + this.statistics.misses > 0
      ? this.statistics.hits / (this.statistics.hits + this.statistics.misses)
      : 0;

    return {
      entries: this.cache.size,
      size: this.currentSize,
      maxSize: this.maxSize,
      maxEntries: this.maxEntries,
      hits: this.statistics.hits,
      misses: this.statistics.misses,
      evictions: this.statistics.evictions,
      sets: this.statistics.sets,
      deletes: this.statistics.deletes,
      hitRate: hitRate * 100,
      tags: this.indexes.size
    };
  }

  /**
   * Get cache info
   * @returns {object} - Cache info
   */
  getInfo() {
    const entries = Array.from(this.cache.values());
    
    return {
      ...this.getStatistics(),
      avgEntrySize: entries.length > 0 ? this.currentSize / entries.length : 0,
      oldestEntry: entries.length > 0 ? entries.reduce((oldest, e) => 
        new Date(e.createdAt) < new Date(oldest.createdAt) ? e : oldest
      ).createdAt : null,
      newestEntry: entries.length > 0 ? entries.reduce((newest, e) => 
        new Date(e.createdAt) > new Date(newest.createdAt) ? e : newest
      ).createdAt : null,
      mostAccessed: entries.length > 0 ? entries.reduce((most, e) => 
        e.hitCount > most.hitCount ? e : most
      ).key : null
    };
  }

  /**
   * Persist cache to storage
   */
  async persist() {
    try {
      await dClr('cache_layer');
      await batchPut('cache_layer', Array.from(this.cache.values()));
    } catch (err) {
      console.error('Failed to persist cache:', err);
    }
  }

  /**
   * Set max size
   * @param {number} size - Max size in bytes
   */
  setMaxSize(size) {
    this.maxSize = size;
    this.ensureSpace(0);
  }

  /**
   * Set max entries
   * @param {number} count - Max entry count
   */
  setMaxEntries(count) {
    const limit = Number(count);
    if (!Number.isFinite(limit)) throw new Error('Maximum cache entries must be a finite number');
    this.maxEntries = Math.max(1, Math.floor(limit));
    this.ensureSpace(0);
  }

  /**
   * Reset statistics
   */
  resetStatistics() {
    this.statistics = {
      hits: 0,
      misses: 0,
      evictions: 0,
      sets: 0,
      deletes: 0
    };
  }
}

/**
 * Global cache layer instance
 */
const cacheLayerManager = new CacheLayerManager();

/**
 * Initialize cache layer
 */
async function initCacheLayer() {
  await cacheLayerManager.init();
  return cacheLayerManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.CacheLayer = {
    manager: cacheLayerManager,
    init: initCacheLayer,
    get: (key) => cacheLayerManager.get(key),
    set: (key, value, options) => cacheLayerManager.set(key, value, options),
    has: (key) => cacheLayerManager.has(key),
    delete: (key) => cacheLayerManager.delete(key),
    clear: (tag) => cacheLayerManager.clear(tag),
    getByTag: (tag) => cacheLayerManager.getByTag(tag),
    getMany: (keys) => cacheLayerManager.getMany(keys),
    setMany: (entries, options) => cacheLayerManager.setMany(entries, options),
    getOrSet: (key, loader, options) => cacheLayerManager.getOrSet(key, loader, options),
    increment: (key, amount) => cacheLayerManager.increment(key, amount),
    decrement: (key, amount) => cacheLayerManager.decrement(key, amount),
    getStats: () => cacheLayerManager.getStatistics(),
    getInfo: () => cacheLayerManager.getInfo(),
    persist: () => cacheLayerManager.persist(),
    setMaxSize: (size) => cacheLayerManager.setMaxSize(size),
    setMaxEntries: (count) => cacheLayerManager.setMaxEntries(count),
    resetStats: () => cacheLayerManager.resetStatistics()
  };
}
