// Input Validation Middleware - Security for user inputs

/**
 * Validation rules for different field types
 */
const VALIDATION_RULES = {
  username: {
    minLength: 3,
    maxLength: 50,
    pattern: /^[a-zA-Z0-9_@.-]+$/,
    message: 'Username must be 3-50 characters and contain only letters, numbers, and @._-'
  },
  password: {
    minLength: 8,
    maxLength: 128,
    pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
    message: 'Password must be at least 8 characters with uppercase, lowercase, and number'
  },
  email: {
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    message: 'Invalid email format'
  },
  phone: {
    pattern: /^[\d\s\-\(\)]{10,}$/,
    message: 'Phone number must be at least 10 digits'
  },
  barcode: {
    pattern: /^[a-zA-Z0-9]+$/,
    message: 'Barcode must contain only alphanumeric characters'
  },
  number: {
    pattern: /^-?\d+(\.\d+)?$/,
    message: 'Must be a valid number'
  },
  positiveNumber: {
    pattern: /^\d+(\.\d+)?$/,
    message: 'Must be a positive number'
  },
  integer: {
    pattern: /^-?\d+$/,
    message: 'Must be an integer'
  },
  url: {
    pattern: /^https?:\/\/.+/,
    message: 'Must be a valid URL starting with http:// or https://'
  }
};

/**
 * Validate a single field against rules
 * @param {string} value - Value to validate
 * @param {string} ruleName - Name of validation rule
 * @param {object} customRules - Optional custom validation rules
 * @returns {object} - { valid: boolean, message: string }
 */
function validateField(value, ruleName, customRules = null) {
  const rules = customRules || VALIDATION_RULES[ruleName];
  
  if (!rules) {
    return { valid: true, message: '' };
  }
  
  // Check required
  if (rules.required && (value === null || value === undefined || value === '')) {
    return { valid: false, message: rules.message || 'This field is required' };
  }
  
  // Skip validation if empty and not required
  if (!rules.required && (value === null || value === undefined || value === '')) {
    return { valid: true, message: '' };
  }
  
  // Check min length
  if (rules.minLength && value.length < rules.minLength) {
    return { valid: false, message: rules.message || `Minimum length is ${rules.minLength}` };
  }
  
  // Check max length
  if (rules.maxLength && value.length > rules.maxLength) {
    return { valid: false, message: rules.message || `Maximum length is ${rules.maxLength}` };
  }
  
  // Check pattern
  if (rules.pattern && !rules.pattern.test(value)) {
    return { valid: false, message: rules.message || 'Invalid format' };
  }
  
  // Check min value (for numbers)
  if (rules.min !== undefined && parseFloat(value) < rules.min) {
    return { valid: false, message: rules.message || `Minimum value is ${rules.min}` };
  }
  
  // Check max value (for numbers)
  if (rules.max !== undefined && parseFloat(value) > rules.max) {
    return { valid: false, message: rules.message || `Maximum value is ${rules.max}` };
  }
  
  return { valid: true, message: '' };
}

/**
 * Validate multiple fields
 * @param {object} data - Object with field values
 * @param {object} schema - Object with field names and their validation rules
 * @returns {object} - { valid: boolean, errors: object }
 */
function validateSchema(data, schema) {
  const errors = {};
  let valid = true;
  
  for (const fieldName in schema) {
    const fieldRules = schema[fieldName];
    const value = data[fieldName];
    
    const result = validateField(value, null, fieldRules);
    
    if (!result.valid) {
      errors[fieldName] = result.message;
      valid = false;
    }
  }
  
  return { valid, errors };
}

/**
 * Sanitize input to prevent XSS
 * @param {string} input - Input to sanitize
 * @returns {string} - Sanitized input
 */
function sanitizeInput(input) {
  if (typeof input !== 'string') {return input;}
  
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

/**
 * Sanitize an object recursively
 * @param {object} obj - Object to sanitize
 * @returns {object} - Sanitized object
 */
function sanitizeObject(obj) {
  if (typeof obj !== 'object' || obj === null) {return obj;}
  
  if (Array.isArray(obj)) {
    return obj.map(item => sanitizeObject(item));
  }
  
  const sanitized = {};
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      sanitized[key] = sanitizeInput(obj[key]);
    } else if (typeof obj[key] === 'object') {
      sanitized[key] = sanitizeObject(obj[key]);
    } else {
      sanitized[key] = obj[key];
    }
  }
  
  return sanitized;
}

/**
 * Validate and sanitize form data
 * @param {object} formData - Form data to validate
 * @param {object} schema - Validation schema
 * @returns {object} - { valid: boolean, errors: object, data: object }
 */
function validateAndSanitize(formData, schema) {
  // First validate
  const validation = validateSchema(formData, schema);
  
  if (!validation.valid) {
    return { valid: false, errors: validation.errors, data: null };
  }
  
  // Then sanitize
  const sanitized = sanitizeObject(formData);
  
  return { valid: true, errors: {}, data: sanitized };
}

/**
 * Common validation schemas
 */
const SCHEMAS = {
  user: {
    username: { required: true, ...VALIDATION_RULES.username },
    password: { required: true, ...VALIDATION_RULES.password },
    name: { required: true, minLength: 2, maxLength: 100, message: 'Name must be 2-100 characters' },
    email: { ...VALIDATION_RULES.email },
    phone: { ...VALIDATION_RULES.phone },
    role: { required: true, pattern: /^(admin|store|viewer)$/, message: 'Role must be admin, store, or viewer' }
  },
  material: {
    name: { required: true, minLength: 2, maxLength: 200, message: 'Name is required (2-200 chars)' },
    barcode: { required: true, ...VALIDATION_RULES.barcode },
    category: { maxLength: 100 },
    unit: { maxLength: 50 },
    minStock: { ...VALIDATION_RULES.positiveNumber },
    maxStock: { ...VALIDATION_RULES.positiveNumber },
    currentStock: { ...VALIDATION_RULES.positiveNumber }
  },
  transaction: {
    barcode: { required: true, ...VALIDATION_RULES.barcode },
    quantity: { required: true, ...VALIDATION_RULES.positiveNumber },
    type: { required: true, pattern: /^(IN|OUT)$/, message: 'Type must be IN or OUT' }
  }
};

// Export for use in app
if (typeof window !== 'undefined') {
  window.Validation = {
    validateField,
    validateSchema,
    sanitizeInput,
    sanitizeObject,
    validateAndSanitize,
    SCHEMAS,
    VALIDATION_RULES
  };
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    validateField,
    validateSchema,
    sanitizeInput,
    sanitizeObject,
    validateAndSanitize,
    SCHEMAS,
    VALIDATION_RULES
  };
}
