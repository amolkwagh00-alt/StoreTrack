// Activity Tracking Module - User activity logging and monitoring

/**
 * Activity Log class
 */
class ActivityLog {
  constructor(config) {
    this.id = config.id || this.generateId();
    this.userId = config.userId || null;
    this.username = config.username || 'Unknown';
    this.action = config.action || 'unknown';
    this.resource = config.resource || null;
    this.resourceId = config.resourceId || null;
    this.details = config.details || {};
    this.ipAddress = config.ipAddress || null;
    this.userAgent = config.userAgent || null;
    this.sessionId = config.sessionId || null;
    this.timestamp = config.timestamp || new Date().toISOString();
    this.success = config.success !== false;
  }

  generateId() {
    return `activity-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

/**
 * Activity Tracking Manager
 */
class ActivityTrackingManager {
  constructor() {
    this.currentSessionId = null;
    this.sessionStartTime = null;
    this.init();
  }

  /**
   * Initialize activity tracker
   */
  async init() {
    this.startSession();
    this.setupActivityListeners();
  }

  /**
   * Start new session
   */
  startSession() {
    this.currentSessionId = this.generateSessionId();
    this.sessionStartTime = new Date().toISOString();
  }

  /**
   * Generate session ID
   * @returns {string} - Session ID
   */
  generateSessionId() {
    return `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Setup activity listeners
   */
  setupActivityListeners() {
    // Track page navigation
    window.addEventListener('hashchange', () => {
      this.logActivity('navigation', 'page', null, { path: window.location.hash });
    });

    // Track clicks on buttons
    document.addEventListener('click', (e) => {
      if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
        const btn = e.target.tagName === 'BUTTON' ? e.target : e.target.closest('button');
        this.logActivity('click', 'button', null, { text: btn.textContent });
      }
    });
  }

  /**
   * Log activity
   * @param {string} action - Action performed
   * @param {string} resource - Resource type
   * @param {string} resourceId - Resource ID
   * @param {object} details - Additional details
   * @returns {Promise<ActivityLog>} - Activity log
   */
  async logActivity(action, resource, resourceId, details = {}) {
    // Check if database is ready
    if (!window.databaseReady) {
      console.warn('Database not ready, skipping activity logging');
      return null;
    }

    const currentUser = this.getCurrentUser() || details.user || null;
    
    const log = new ActivityLog({
      userId: currentUser?.id ?? details.userId ?? null,
      username: currentUser?.username || currentUser?.name || details.username || details.userName || 'Unknown',
      action,
      resource,
      resourceId,
      details,
      sessionId: this.currentSessionId,
      success: typeof details.success === 'boolean' ? details.success : true,
      ipAddress: await this.getIPAddress(),
      userAgent: navigator.userAgent
    });

    try {
      await dPut('activity_logs', log);
    } catch (err) {
      console.error('Failed to log activity:', err);
    }

    return log;
  }

  /**
   * Get current user
   * @returns {object} - Current user
   */
  getCurrentUser() {
    return window.currentUser || window.currentUserProfile || window.Auth?.currentUser || null;
  }

  /**
   * Get IP address (placeholder)
   * @returns {Promise<string>} - IP address
   */
  async getIPAddress() {
    // This would get the actual IP address
    return null;
  }

  /**
   * Log login
   * @param {string} username - Username
   * @param {boolean} success - Login success
   */
  async logLogin(username, success = true) {
    await this.logActivity('login', 'auth', null, { username, success });
  }

  /**
   * Log logout
   * @param {string} username - Username
   */
  async logLogout(username) {
    await this.logActivity('logout', 'auth', null, { username });
    this.endSession();
  }

  /**
   * Log data access
   * @param {string} resource - Resource type
   * @param {string} resourceId - Resource ID
   * @param {string} action - Action (read, write, delete)
   */
  async logDataAccess(resource, resourceId, action) {
    await this.logActivity(action, resource, resourceId);
  }

  /**
   * Log error
   * @param {string} error - Error message
   * @param {object} details - Error details
   */
  async logError(error, details = {}) {
    await this.logActivity('error', 'system', null, { error, ...details });
  }

  /**
   * End current session
   */
  endSession() {
    this.currentSessionId = null;
    this.sessionStartTime = null;
  }

  /**
   * Get activity logs
   * @param {object} filters - Filters to apply
   * @returns {Promise<Array>} - Activity logs
   */
  async getActivityLogs(filters = {}) {
    try {
      let logs = await gAll('activity_logs');

      if (filters.userId) {
        logs = logs.filter(l => l.userId === filters.userId);
      }

      if (filters.username) {
        logs = logs.filter(l => l.username === filters.username);
      }

      if (filters.action) {
        logs = logs.filter(l => l.action === filters.action);
      }

      if (filters.resource) {
        logs = logs.filter(l => l.resource === filters.resource);
      }

      if (filters.sessionId) {
        logs = logs.filter(l => l.sessionId === filters.sessionId);
      }

      if (filters.startDate) {
        const start = new Date(filters.startDate);
        logs = logs.filter(l => new Date(l.timestamp) >= start);
      }

      if (filters.endDate) {
        const end = new Date(filters.endDate);
        logs = logs.filter(l => new Date(l.timestamp) <= end);
      }

      if (filters.success !== undefined) {
        logs = logs.filter(l => l.success === filters.success);
      }

      // Sort by timestamp descending
      logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

      return logs;
    } catch (err) {
      console.error('Failed to get activity logs:', err);
      return [];
    }
  }

  /**
   * Get user activity
   * @param {string} userId - User ID
   * @param {number} limit - Limit number of results
   * @returns {Promise<Array>} - User activity logs
   */
  async getUserActivity(userId, limit = 100) {
    const logs = await this.getActivityLogs({ userId });
    return logs.slice(0, limit);
  }

  /**
   * Get session activity
   * @param {string} sessionId - Session ID
   * @returns {Promise<Array>} - Session activity logs
   */
  async getSessionActivity(sessionId) {
    return this.getActivityLogs({ sessionId });
  }

  /**
   * Get activity statistics
   * @param {object} filters - Filters to apply
   * @returns {Promise<object>} - Activity statistics
   */
  async getStatistics(filters = {}) {
    const logs = await this.getActivityLogs(filters);

    const stats = {
      total: logs.length,
      byAction: {},
      byResource: {},
      byUser: {},
      byDate: {},
      successRate: 0,
      successful: 0,
      failed: 0
    };

    logs.forEach(log => {
      // By action
      stats.byAction[log.action] = (stats.byAction[log.action] || 0) + 1;

      // By resource
      if (log.resource) {
        stats.byResource[log.resource] = (stats.byResource[log.resource] || 0) + 1;
      }

      // By user
      if (log.username) {
        stats.byUser[log.username] = (stats.byUser[log.username] || 0) + 1;
      }

      // By date
      const date = new Date(log.timestamp).toISOString().split('T')[0];
      stats.byDate[date] = (stats.byDate[date] || 0) + 1;

      // Success rate
      if (log.success) {
        stats.successful++;
      } else {
        stats.failed++;
      }
    });

    stats.successRate = logs.length > 0 ? (stats.successful / logs.length) * 100 : 0;

    return stats;
  }

  /**
   * Get recent activity
   * @param {number} limit - Limit number of results
   * @returns {Promise<Array>} - Recent activity logs
   */
  async getRecentActivity(limit = 20) {
    const logs = await this.getActivityLogs();
    return logs.slice(0, limit);
  }

  /**
   * Clear old activity logs
   * @param {number} daysToKeep - Number of days to keep
   */
  async clearOldLogs(daysToKeep = 90) {
    try {
      const logs = await gAll('activity_logs');
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

      const logsToDelete = logs.filter(l => new Date(l.timestamp) < cutoffDate);

      for (const log of logsToDelete) {
        await dDel('activity_logs', log.id);
      }

      console.log(`Cleared ${logsToDelete.length} old activity logs`);
    } catch (err) {
      console.error('Failed to clear old logs:', err);
    }
  }

  /**
   * Export activity logs
   * @param {object} filters - Filters to apply
   * @param {string} format - Export format (csv, json)
   * @returns {Promise<string>} - Exported data
   */
  async exportLogs(filters = {}, format = 'csv') {
    const logs = await this.getActivityLogs(filters);

    if (format === 'json') {
      return JSON.stringify(logs, null, 2);
    }

    if (format === 'csv') {
      if (logs.length === 0) {return '';}

      const headers = ['timestamp', 'username', 'action', 'resource', 'resourceId', 'success', 'details'];
      const rows = logs.map(log => [
        log.timestamp,
        log.username,
        log.action,
        log.resource || '',
        log.resourceId || '',
        log.success,
        JSON.stringify(log.details)
      ]);

      return [headers.join(','), ...rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(','))].join('\n');
    }

    return '';
  }

  /**
   * Get activity timeline for user
   * @param {string} userId - User ID
   * @param {number} days - Number of days
   * @returns {Promise<Array>} - Activity timeline
   */
  async getUserTimeline(userId, days = 7) {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const logs = await this.getActivityLogs({ userId, startDate: startDate.toISOString() });

    const timeline = {};
    logs.forEach(log => {
      const date = new Date(log.timestamp).toISOString().split('T')[0];
      if (!timeline[date]) {
        timeline[date] = [];
      }
      timeline[date].push(log);
    });

    return Object.entries(timeline).map(([date, activities]) => ({
      date,
      activities,
      count: activities.length
    })).sort((a, b) => new Date(b.date) - new Date(a.date));
  }
}

/**
 * Global activity tracker instance
 */
const activityTracker = new ActivityTrackingManager();

/**
 * Initialize activity tracking
 */
async function initActivityTracking() {
  await activityTracker.init();
  return activityTracker;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.ActivityTracking = {
    tracker: activityTracker,
    init: initActivityTracking,
    logActivity: (action, resource, resourceId, details) => activityTracker.logActivity(action, resource, resourceId, details),
    logLogin: (username, success) => activityTracker.logLogin(username, success),
    logLogout: (username) => activityTracker.logLogout(username),
    logDataAccess: (resource, resourceId, action) => activityTracker.logDataAccess(resource, resourceId, action),
    logError: (error, details) => activityTracker.logError(error, details),
    getLogs: (filters) => activityTracker.getActivityLogs(filters),
    getUserActivity: (userId, limit) => activityTracker.getUserActivity(userId, limit),
    getSessionActivity: (sessionId) => activityTracker.getSessionActivity(sessionId),
    getStatistics: (filters) => activityTracker.getStatistics(filters),
    getRecent: (limit) => activityTracker.getRecentActivity(limit),
    clearOldLogs: (days) => activityTracker.clearOldLogs(days),
    exportLogs: (filters, format) => activityTracker.exportLogs(filters, format),
    getUserTimeline: (userId, days) => activityTracker.getUserTimeline(userId, days)
  };
}
