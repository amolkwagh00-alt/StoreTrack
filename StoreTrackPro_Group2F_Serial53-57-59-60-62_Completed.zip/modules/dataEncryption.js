// Data Encryption at Rest Module - Encrypt sensitive data in storage

/**
 * Data Encryption Manager
 */
class DataEncryptionManager {
  constructor() {
    this.encryptionKey = null;
    this.legacyInsecureKey = false;
    this.enabled = false;
    this.encryptedFields = new Set();
  }

  /**
   * Initialize encryption manager
   */
  async init() {
    await this.loadSettings();
    await this.loadEncryptedFields();
    if (this.enabled) {
      await this.loadOrGenerateKey();
      if (!this.encryptedFields.size) await this.setupDefaultFields();
    }
  }

  /**
   * Load settings from storage
   */
  async loadSettings() {
    const settings = await gOne('encryption_settings', 'settings');
    if (settings) this.enabled = settings.enabled === true;
  }

  /**
   * Load encrypted fields configuration
   */
  async loadEncryptedFields() {
    try {
      const config = await gOne('encryption_fields', 'config');
      if (config && config.fields) {
        config.fields.forEach(f => this.encryptedFields.add(f));
      }
    } catch (err) {
      if (this.enabled) throw new Error(`Failed to load encrypted field configuration; refusing writes while encryption is enabled: ${err.message}`);
      console.error('Failed to load encrypted fields:', err);
    }
  }

  /**
   * Load or generate encryption key
   */
  async loadOrGenerateKey() {
    const legacy = await gOne('encryption_key', 'master');
    const bridge = typeof window !== 'undefined' ? window.encryptionKeyBridge : null;
    if (!bridge || typeof bridge.getKey !== 'function' || typeof bridge.setKey !== 'function') {
      // Existing browser-only databases remain readable so users do not lose
      // access to data. New key creation is forbidden without OS key storage.
      if (legacy?.key) {
        this.encryptionKey = legacy.key;
        this.legacyInsecureKey = true;
        console.warn('[DataEncryption] Browser/unsupported platform: using the existing IndexedDB key for compatibility; new protected data cannot be created safely.');
        return;
      }
      throw new Error('Protected encryption key storage is unavailable on this platform');
    }

    const protectedKey = await bridge.getKey();
    if (!protectedKey?.available) {
      if (legacy?.key) {
        this.encryptionKey = legacy.key;
        this.legacyInsecureKey = true;
        console.warn('[DataEncryption] OS-protected key storage is unavailable; using the legacy key only to preserve reads. Encrypted writes are blocked.');
      } else {
        await this.generateKey();
      }
      return;
    }

    if (protectedKey.key) {
      if (legacy?.key && legacy.key !== protectedKey.key) {
        throw new Error('Protected and legacy encryption keys differ; refusing to risk existing encrypted data');
      }
      this.encryptionKey = protectedKey.key;
      if (legacy) await dDel('encryption_key', 'master');
      return;
    }

    if (legacy?.key) {
      await bridge.setKey(legacy.key);
      const verified = await bridge.getKey();
      if (!verified?.available || verified.key !== legacy.key) {
        throw new Error('Could not verify migrated encryption key; existing data was left unchanged');
      }
      this.encryptionKey = legacy.key;
      await dDel('encryption_key', 'master');
    } else {
      await this.generateKey();
    }
  }

  /**
   * Generate encryption key
   */
  async generateKey() {
    const key = await this.generateRandomKey();
    const bridge = typeof window !== 'undefined' ? window.encryptionKeyBridge : null;
    if (!bridge || typeof bridge.setKey !== 'function') {
      throw new Error('Protected encryption key storage is unavailable; refusing to store a key in IndexedDB');
    }
    await bridge.setKey(key);
    const verified = await bridge.getKey();
    if (!verified?.available || verified.key !== key) throw new Error('Could not verify protected encryption key storage');
    this.encryptionKey = key;
    this.legacyInsecureKey = false;
  }

  /**
   * Generate random key
   * @returns {Promise<string>} - Base64 encoded key
   */
  async generateRandomKey() {
    const key = new Uint8Array(32); // 256-bit key
    crypto.getRandomValues(key);
    return this.arrayBufferToBase64(key);
  }

  /**
   * Convert ArrayBuffer to Base64
   * @param {ArrayBuffer} buffer - Buffer to convert
   * @returns {string} - Base64 string
   */
  arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  /**
   * Convert Base64 to ArrayBuffer
   * @param {string} base64 - Base64 string
   * @returns {ArrayBuffer} - ArrayBuffer
   */
  base64ToArrayBuffer(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }

  /**
   * Encrypt data
   * @param {string} data - Data to encrypt
   * @returns {Promise<string>} - Encrypted data (Base64)
   */
  async encrypt(data) {
    if (!this.enabled) {
      return data;
    }
    if (this.legacyInsecureKey) throw new Error('OS-protected key storage is unavailable; refusing encrypted writes with the legacy key');
    if (!this.encryptionKey) throw new Error('Encryption is enabled but its key is unavailable');
    try {
      return `st-encrypted:v1:${await this.encryptWithKey(data)}`;
    } catch (err) {
      console.error('Encryption failed:', err);
      throw new Error(`Encryption failed; refusing to store plaintext: ${err.message}`);
    }
  }

  async encryptWithKey(data) {
      const encoder = new TextEncoder();
      const dataBytes = encoder.encode(String(data));
      const keyBytes = this.base64ToArrayBuffer(this.encryptionKey);
      
      const key = await crypto.subtle.importKey(
        'raw',
        keyBytes,
        { name: 'AES-GCM' },
        false,
        ['encrypt']
      );

      const iv = crypto.getRandomValues(new Uint8Array(12));
      const encrypted = await crypto.subtle.encrypt(
        { name: 'AES-GCM', iv },
        key,
        dataBytes
      );

      const combined = new Uint8Array(iv.length + encrypted.byteLength);
      combined.set(iv);
      combined.set(new Uint8Array(encrypted), iv.length);

      return this.arrayBufferToBase64(combined.buffer);
  }

  /**
   * Decrypt data
   * @param {string} encryptedData - Encrypted data (Base64)
   * @returns {Promise<string>} - Decrypted data
   */
  async decrypt(encryptedData) {
    if (!this.enabled) {
      return encryptedData;
    }
    if (!this.encryptionKey) throw new Error('Encryption is enabled but its key is unavailable');
    const versioned = typeof encryptedData === 'string' && encryptedData.startsWith('st-encrypted:v1:');
    const payload = versioned ? encryptedData.slice('st-encrypted:v1:'.length) : encryptedData;
    if (!versioned) {
      // Older app builds stored IV+ciphertext as bare base64. Keep non-base64
      // legacy values readable, but never return a plausible ciphertext after
      // authentication/decryption failure.
      if (typeof payload !== 'string' || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(payload)) return payload;
      let decoded;
      try { decoded = this.base64ToArrayBuffer(payload); } catch (_) { return payload; }
      if (decoded.byteLength < 29) return payload;
    }
    try {
      return await this.decryptWithKey(payload);
    } catch (err) {
      console.error('Decryption failed:', err);
      throw new Error(`Decryption failed; refusing to return ciphertext as plaintext: ${err.message}`);
    }
  }

  async decryptWithKey(encryptedData) {
    const combined = this.base64ToArrayBuffer(encryptedData);
    if (combined.byteLength < 29) throw new Error('Encrypted value is malformed');
    const iv = combined.slice(0, 12);
    const encrypted = combined.slice(12);
    const keyBytes = this.base64ToArrayBuffer(this.encryptionKey);
    const key = await crypto.subtle.importKey('raw', keyBytes, { name: 'AES-GCM' }, false, ['decrypt']);
    const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, encrypted);
    return new TextDecoder().decode(decrypted);
  }

  /** Always-protected envelope for credentials such as TOTP seeds, independent of the optional data-encryption setting. */
  async protectSecret(value) {
    const bridge = typeof window !== 'undefined' ? window.encryptionKeyBridge : null;
    if (!bridge || typeof bridge.getKey !== 'function' || typeof bridge.setKey !== 'function') {
      throw new Error('OS-protected key storage is unavailable; refusing to persist a 2FA seed');
    }
    const availability = await bridge.getKey();
    if (!availability?.available) throw new Error('OS-protected key storage is unavailable; refusing to persist a 2FA seed');
    if (!this.encryptionKey) await this.loadOrGenerateKey();
    if (this.legacyInsecureKey) throw new Error('Only an existing unprotected legacy key is available; refusing to persist a 2FA seed');
    if (!this.encryptionKey) throw new Error('Protected key is unavailable');
    return `st-secure:v1:${await this.encryptWithKey(value)}`;
  }

  async unprotectSecret(value) {
    if (typeof value !== 'string' || !value.startsWith('st-secure:v1:')) throw new Error('Unsupported protected secret format');
    if (!this.encryptionKey) await this.loadOrGenerateKey();
    if (this.legacyInsecureKey) throw new Error('OS-protected encryption key is unavailable for this 2FA seed');
    if (!this.encryptionKey) throw new Error('Protected key is unavailable');
    return this.decryptWithKey(value.slice('st-secure:v1:'.length));
  }

  /**
   * Encrypt object fields
   * @param {object} obj - Object to encrypt
   * @param {Array} fields - Fields to encrypt
   * @returns {Promise<object>} - Object with encrypted fields
   */
  async encryptObject(obj, fields = null) {
    const fieldsToEncrypt = fields || Array.from(this.encryptedFields);
    const result = { ...obj };

    for (const field of fieldsToEncrypt) {
      if (result[field] !== undefined && result[field] !== null) {
        result[field] = await this.encrypt(String(result[field]));
      }
    }

    return result;
  }

  /**
   * Decrypt object fields
   * @param {object} obj - Object to decrypt
   * @param {Array} fields - Fields to decrypt
   * @returns {Promise<object>} - Object with decrypted fields
   */
  async decryptObject(obj, fields = null) {
    const fieldsToDecrypt = fields || Array.from(this.encryptedFields);
    const result = { ...obj };

    for (const field of fieldsToDecrypt) {
      if (result[field] !== undefined && result[field] !== null) {
        result[field] = await this.decrypt(result[field]);
      }
    }

    return result;
  }

  /**
   * Add field to encryption list
   * @param {string} field - Field name
   */
  async addEncryptedField(field) {
    this.encryptedFields.add(field);
    try { await this.saveEncryptedFields(); } catch (error) { this.encryptedFields.delete(field); throw error; }
  }

  /**
   * Remove field from encryption list
   * @param {string} field - Field name
   */
  async removeEncryptedField(field) {
    this.encryptedFields.delete(field);
    try { await this.saveEncryptedFields(); } catch (error) { this.encryptedFields.add(field); throw error; }
  }

  /**
   * Save encrypted fields configuration
   */
  async saveEncryptedFields() {
      await dPut('encryption_fields', {
        id: 'config',
        fields: Array.from(this.encryptedFields),
        updatedAt: new Date().toISOString()
      });
  }

  /**
   * Enable encryption
   */
  async enable() {
    await this.loadOrGenerateKey();
    if (!this.encryptionKey) throw new Error('Encryption key is unavailable');
    if (this.legacyInsecureKey) throw new Error('OS-protected key storage is unavailable; encryption cannot be enabled safely');
    this.enabled = true;
    try {
      if (!this.encryptedFields.size) await this.setupDefaultFields();
      await this.saveSettings();
    } catch (error) {
      this.enabled = false;
      throw error;
    }

    // Log activity
    if (typeof window !== 'undefined' && window.AuditTrail) {
      await window.AuditTrail.logSystemEvent('encryption_enabled', 'info');
    }
  }

  /**
   * Disable encryption
   */
  async disable() {
    if (this.enabled) {
      throw new Error('Encryption cannot be disabled safely until encrypted records are migrated; the current setting and data were left unchanged');
    }

    // Log activity
    if (typeof window !== 'undefined' && window.AuditTrail) {
      await window.AuditTrail.logSystemEvent('encryption_disabled', 'warning');
    }
  }

  /**
   * Save settings
   */
  async saveSettings() {
      await dPut('encryption_settings', {
        id: 'settings',
        enabled: this.enabled,
        updatedAt: new Date().toISOString()
      });
  }

  /**
   * Rotate encryption key
   */
  async rotateKey() {
    if (!this.enabled) {
      throw new Error('Encryption must be enabled before rotating the key');
    }
    const oldKey = this.encryptionKey;
    if (!oldKey) {
      throw new Error('Current encryption key is not available');
    }
    if (this.legacyInsecureKey) throw new Error('OS-protected key storage is unavailable; refusing key rotation');

    // Read/decrypt every configured record while the old key is still active.
    // Only after the snapshot is complete do we switch to the new key.
    const snapshot = await this.collectEncryptedData();
    const newKey = await this.generateRandomKey();
    this.encryptionKey = newKey;

    try {
      for (const entry of snapshot) {
        await dPut(entry.storeName, entry.record);
      }
      const bridge = window.encryptionKeyBridge;
      if (!bridge?.setKey) throw new Error('OS-protected key storage is unavailable; cannot rotate encryption key');
      await bridge.setKey(newKey);
      const verified = await bridge.getKey();
      if (!verified?.available || verified.key !== newKey) throw new Error('Rotated protected encryption key could not be verified');
    } catch (error) {
      // Restore the old key and rewrite the snapshot so a partial rotation
      // cannot leave the database split between two encryption keys.
      this.encryptionKey = oldKey;
      for (const entry of snapshot) {
        await dPut(entry.storeName, entry.record);
      }
      const bridge = window.encryptionKeyBridge;
      if (bridge?.setKey) await bridge.setKey(oldKey);
      throw error;
    }

    if (typeof window !== 'undefined' && window.AuditTrail) {
      await window.AuditTrail.logSystemEvent('encryption_key_rotated', 'info');
    }
  }

  /** Collect records in decrypted form before changing the key. */
  async collectEncryptedData() {
    if (!window.STORES || typeof gAll !== 'function') {
      throw new Error('Database store registry is unavailable');
    }
    const excluded = new Set(['encryption_settings', 'encryption_fields', 'encryption_key']);
    const snapshot = [];
    for (const storeName of window.STORES) {
      if (excluded.has(storeName)) continue;
      const rows = await gAll(storeName);
      rows.forEach(record => snapshot.push({ storeName, record }));
    }
    return snapshot;
  }

  /**
   * Re-encrypt data with the current key. Kept public for migrations/tests;
   * rotateKey() performs the atomic snapshot/switch/rewrite workflow above.
   */
  async reencryptData(oldKey) {
    if (!oldKey) throw new Error('Old encryption key is required');
    const currentKey = this.encryptionKey;
    this.encryptionKey = oldKey;
    const snapshot = await this.collectEncryptedData();
    this.encryptionKey = currentKey;
    for (const entry of snapshot) await dPut(entry.storeName, entry.record);
    return snapshot.length;
  }

  /**
   * Prepare a record for database storage when encryption is enabled.
   * The database module calls this hook; configuration remains opt-in.
   */
  async prepareForStorage(storeName, record) {
    if (!record || ['encryption_settings', 'encryption_fields', 'encryption_key'].includes(storeName)) return record;
    if (!this.enabled) return record;
    if (!this.encryptionKey) throw new Error('Encryption is enabled but its key is unavailable');
    if (!this.encryptedFields.size) throw new Error('Encryption is enabled but no encrypted fields are configured; refusing plaintext writes');
    return this.encryptObject(record);
  }

  /** Restore encrypted fields after reading from storage. */
  async restoreFromStorage(storeName, record) {
    if (!this.enabled || !record || !this.encryptedFields.size) return record;
    if (['encryption_settings', 'encryption_fields', 'encryption_key'].includes(storeName)) return record;
    return this.decryptObject(record);
  }

  /**
   * Get encryption status
   * @returns {object} - Encryption status
   */
  getStatus() {
    return {
      enabled: this.enabled,
      hasKey: !!this.encryptionKey,
      encryptedFields: Array.from(this.encryptedFields)
    };
  }

  /**
   * Setup default encrypted fields
   */
  async setupDefaultFields() {
    const defaultFields = [
      'password',
      'email',
      'phone',
      'ssn',
      'creditCard',
      'bankAccount',
      'apiKey',
      'secret'
    ];

    for (const field of defaultFields) {
      this.encryptedFields.add(field);
    }

    await this.saveEncryptedFields();
  }

  /**
   * Hash data (for passwords)
   * @param {string} data - Data to hash
   * @returns {Promise<string>} - Hashed data
   */
  async hash(data) {
    const encoder = new TextEncoder();
    const dataBytes = encoder.encode(data);
    const hashBuffer = await crypto.subtle.digest('SHA-256', dataBytes);
    return this.arrayBufferToBase64(hashBuffer);
  }

  /**
   * Verify hash
   * @param {string} data - Data to verify
   * @param {string} hash - Hash to compare
   * @returns {Promise<boolean>} - Match
   */
  async verifyHash(data, hash) {
    const computedHash = await this.hash(data);
    return computedHash === hash;
  }
}

/**
 * Global encryption manager instance
 */
const dataEncryptionManager = new DataEncryptionManager();

/**
 * Initialize data encryption
 */
async function initDataEncryption() {
  // Wait for database to be ready
  if (!window.databaseReady) {
    await new Promise(resolve => {
      document.addEventListener('databaseReady', resolve, { once: true });
    });
  }
  await dataEncryptionManager.init();
  return dataEncryptionManager;
}

// Export for use in app
if (typeof window !== 'undefined') {
  window.DataEncryption = {
    manager: dataEncryptionManager,
    init: initDataEncryption,
    encrypt: (data) => dataEncryptionManager.encrypt(data),
    decrypt: (data) => dataEncryptionManager.decrypt(data),
    encryptObject: (obj, fields) => dataEncryptionManager.encryptObject(obj, fields),
    decryptObject: (obj, fields) => dataEncryptionManager.decryptObject(obj, fields),
    addField: (field) => dataEncryptionManager.addEncryptedField(field),
    removeField: (field) => dataEncryptionManager.removeEncryptedField(field),
    enable: () => dataEncryptionManager.enable(),
    disable: () => dataEncryptionManager.disable(),
    rotateKey: () => dataEncryptionManager.rotateKey(),
    getStatus: () => dataEncryptionManager.getStatus(),
    setupDefaults: () => dataEncryptionManager.setupDefaultFields(),
    hash: (data) => dataEncryptionManager.hash(data),
    verifyHash: (data, hash) => dataEncryptionManager.verifyHash(data, hash)
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { DataEncryptionManager, dataEncryptionManager };
}
