/* exported mspAddRow, mspDupList, mspCellBlur, mspClearAll, mspDeleteActiveList, mspDeleteRow, mspDuplicateActiveList, mspEditListMeta, mspExportActive, mspGlobalSearch, mspImportFile, mspOpenNotes, mspPrintActive, mspSaveListMeta, mspSaveNotes, mspShowAddListModal, mspSugKeyNav */
// Machine Spare Parts Module - MSP list management

let mspLists = [];
let mspActiveListId = null;
const MSP_STATUS_COL = 'Status';

// Treat all imported/user-authored MSP values as text before interpolating HTML.
function mspEscapeHtml(value) {
  return String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function mspJsArg(value) {
  return JSON.stringify(String(value == null ? '' : value)).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026');
}

// Get active MSP list
function mspActiveList() {
  return mspLists.find(l => l.id === mspActiveListId);
}

// Count low stock items in a list
function mspListLowCount(list) {
  return list.rows.filter(r => mspRowIsLow(r, list.headers)).length;
}

// Check if a row is low stock
function mspRowIsLow(row, headers) {
  const status = String(row?.[MSP_STATUS_COL] || '').trim().toLowerCase();
  if (['out of stock', 'low stock', 'critical'].includes(status)) {return true;}
  const names = Array.isArray(headers) ? headers : Object.keys(row || {});
  const qtyKey = names.find(h => /^qty|quantity|available qty$/i.test(String(h).trim()));
  const minKey = names.find(h => /^(min\.?\s*qty|minimum\s*qty|reorder\s*level|minimum\s*stock)$/i.test(String(h).trim()));
  if (!qtyKey || !minKey) {return false;}
  const qty = Number(row?.[qtyKey]); const min = Number(row?.[minKey]);
  return Number.isFinite(qty) && Number.isFinite(min) && min > 0 && qty <= min;
}

// Render MSP grid view
function mspRenderGrid() {
  const grid = document.getElementById('msp-list-grid');
  if (!grid) {return;}
  const sort = document.getElementById('msp-grid-sort')?.value || 'newest';
  const q = (document.getElementById('msp-global-search')?.value || '').toLowerCase();
  let lists = [...mspLists];

  if (q) {lists = lists.filter(l =>
    l.title.toLowerCase().includes(q) ||
    (l.machineName || '').toLowerCase().includes(q) ||
    l.rows.some(r => Object.values(r).some(v => String(v).toLowerCase().includes(q)))
  );}

  const timestamp = list => { const value = list.importedAt || list.createdAt || list.updatedAt || ''; const parsed = Date.parse(value); return Number.isFinite(parsed) ? parsed : 0; };
  if (sort === 'newest') {lists.sort((a, b) => timestamp(b) - timestamp(a) || String(b.id).localeCompare(String(a.id)));}
  else if (sort === 'oldest') {lists.sort((a, b) => timestamp(a) - timestamp(b) || String(a.id).localeCompare(String(b.id)));}
  else if (sort === 'az') {lists.sort((a, b) => a.title.localeCompare(b.title));}
  else if (sort === 'most') {lists.sort((a, b) => b.rows.length - a.rows.length);}
  else if (sort === 'low') {lists.sort((a, b) => mspListLowCount(b) - mspListLowCount(a));}

  document.getElementById('msp-grid-count').textContent = lists.length + ' of ' + mspLists.length + ' lists';

  grid.innerHTML = lists.map(l => {
    const low = mspListLowCount(l);
    const machines = [...new Set(l.rows.map(r => r[l.headers[0]] || r['Machine Name']).filter(Boolean))];
    const machStr = machines.slice(0, 3).join(', ') + (machines.length > 3 ? '…' : '');
    const statusCounts = { Available: 0, 'Out of Stock': 0, 'On Order': 0 };
    l.rows.forEach(r => { const s = r[MSP_STATUS_COL]; if (s && statusCounts[s] !== undefined) {statusCounts[s]++;} });
    const importDate = l.importedAt ? new Date(l.importedAt).toLocaleDateString() : (l.createdAt ? new Date(l.createdAt).toLocaleDateString() : '—');
    return `
    <div class="msp-list-card" data-onclick="mspOpenList(${mspEscapeHtml(mspJsArg(l.id))})">
      <div class="msp-list-card-hd">
        <span class="card-icon">⚙</span>
        <span class="card-name" title="${mspEscapeHtml(l.title)}">${mspEscapeHtml(l.title)}</span>
        <span class="card-count">${l.rows.length} parts</span>
      </div>
      <div class="msp-list-card-body" data-style="padding-bottom:6px">
        ${l.machineName ? `<div data-style="color:var(--tx2);font-weight:500;margin-bottom:4px">🔩 ${mspEscapeHtml(l.machineName)}</div>` : ''}
        ${machStr && l.machineName !== machStr ? `<div data-style="color:var(--tx3);font-size:10px;margin-bottom:4px">${mspEscapeHtml(machStr)}</div>` : ''}
        ${l.notes ? `<div data-style="color:var(--tx3);font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${mspEscapeHtml(l.notes)}</div>` : ''}
        <div data-style="color:var(--tx3);font-size:10px;margin-top:4px">📅 Imported: ${importDate}</div>
        <div data-style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">
          ${statusCounts.Available > 0 ? `<span class="bdg badge-available" data-style="font-size:9px">${statusCounts.Available} Available</span>` : ''}
          ${statusCounts['Out of Stock'] > 0 ? `<span class="bdg badge-out" data-style="font-size:9px">${statusCounts['Out of Stock']} Out</span>` : ''}
          ${statusCounts['On Order'] > 0 ? `<span class="bdg badge-onorder" data-style="font-size:9px">${statusCounts['On Order']} On Order</span>` : ''}
          ${low > 0 ? `<span class="low-badge">⚠ ${low} Low</span>` : ''}
        </div>
      </div>
      <div class="msp-list-card-actions" data-onclick="event.stopPropagation()">
        <button class="btn" data-style="font-size:10px;padding:3px 8px" data-onclick="mspEditListMeta(${mspEscapeHtml(mspJsArg(l.id))})" title="Edit title/machine/notes">✏ Edit</button>
        <button class="btn btn-s" data-style="font-size:10px;padding:3px 8px" data-onclick="mspExportList(${mspEscapeHtml(mspJsArg(l.id))})" title="Export to Excel">📊</button>
        <button class="btn" data-style="font-size:10px;padding:3px 8px" data-onclick="mspPrintList(${mspEscapeHtml(mspJsArg(l.id))})" title="Print">🖨</button>
        <button class="btn" data-style="font-size:10px;padding:3px 8px" data-onclick="mspDupList(${mspEscapeHtml(mspJsArg(l.id))})" title="Duplicate">⧉</button>
        <button class="btn btn-d" data-style="font-size:10px;padding:3px 8px;margin-left:auto" data-onclick="mspDeleteList(${mspEscapeHtml(mspJsArg(l.id))})" title="Delete">🗑</button>
      </div>
    </div>`;
  }).join('') +
    `<div class="msp-list-card msp-add-card" data-onclick="mspShowAddListModal()">
    <div data-style="font-size:28px">＋</div>
    <div data-style="font-size:12px;font-weight:600">New List</div>
  </div>`;
}

// Populate machine filter dropdown
function mspPopMachineFilter(list) {
  const sel = document.getElementById('msp-machine-filter');
  if (!sel || !list) {return;}
  const col = list.headers[0];
  const machines = [...new Set(list.rows.map(r => r[col]).filter(Boolean))].sort();
  sel.innerHTML = '<option value="">All Machines</option>' +
    machines.map(m => `<option value="${mspEscapeHtml(m)}">${mspEscapeHtml(m)}</option>`).join('');
}

// Render MSP table view
function mspRenderTable() {
  const list = mspActiveList();
  if (!list) {return;}

  const q = (document.getElementById('msp-global-search')?.value || '').toLowerCase();
  const mf = document.getElementById('msp-machine-filter')?.value || '';
  const sf = document.getElementById('msp-status-filter')?.value || '';
  const sort = document.getElementById('msp-sort-sel')?.value || 'newest';
  const machCol = list.headers[0] || 'Machine Name';

  let rows = [...list.rows];

  if (mf) {rows = rows.filter(r => r[machCol] === mf);}
  if (sf === '__low__') {rows = rows.filter(r => mspRowIsLow(r, list.headers));}
  else if (sf) {rows = rows.filter(r => r[MSP_STATUS_COL] === sf);}
  if (q) {rows = rows.filter(r => Object.values(r).some(v => String(v).toLowerCase().includes(q)));}

  const qtyKey = list.headers.find(h => /^(qty|quantity|available qty)$/i.test(String(h).trim()));
  const sourceOrder = new Map(list.rows.map((row, index) => [row, index]));
  const rowDate = row => { const parsed = Date.parse(row.updatedAt || row.createdAt || row.importedAt || ''); return Number.isFinite(parsed) ? parsed : null; };
  if (sort === 'newest') {rows.sort((a, b) => (rowDate(b) ?? sourceOrder.get(b)) - (rowDate(a) ?? sourceOrder.get(a)));}
  else if (sort === 'oldest') {rows.sort((a, b) => (rowDate(a) ?? sourceOrder.get(a)) - (rowDate(b) ?? sourceOrder.get(b)));}
  else if (sort === 'az' && machCol) {rows.sort((a, b) => String(a[machCol] || '').localeCompare(String(b[machCol] || ''), undefined, {numeric:true, sensitivity:'base'}));}
  else if (sort === 'most') {rows.sort((a, b) => Object.values(b).filter(v => String(v ?? '').trim()).length - Object.values(a).filter(v => String(v ?? '').trim()).length);}
  else if (sort === 'low') {rows.sort((a, b) => Number(mspRowIsLow(b, list.headers)) - Number(mspRowIsLow(a, list.headers)) || (qtyKey ? Number(a[qtyKey] || 0) - Number(b[qtyKey] || 0) : 0));}

  mspRenderTableRows(list, rows);
  const countEl = document.getElementById('msp-filtered-count');
  if (countEl) {countEl.textContent = `${rows.length} of ${list.rows.length} parts`; }
}

// Render the actual <thead>/<tbody> for the active list's table view
function mspRenderTableRows(list, rows) {
  const thead = document.getElementById('msp-part-thead');
  const tbody = document.getElementById('msp-part-tbody');
  if (!thead || !tbody) {return;}
  const escape = value => String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const headers = list.headers || [];
  thead.innerHTML = '<tr>' + headers.map(h => `<th>${escape(h)}</th>`).join('') + '<th data-style="width:36px"></th></tr>';
  tbody.innerHTML = rows.map(r => {
    const idx = list.rows.indexOf(r);
    return '<tr>' + headers.map(h => {
      const v = r[h] == null ? '' : r[h];
      return `<td contenteditable="true" data-row="${idx}" data-col="${escape(h)}" data-onblur="mspCellBlur(this)">${escape(v)}</td>`;
    }).join('') + `<td><button class="btn btn-d" data-style="font-size:10px;padding:2px 6px" data-onclick="mspDeleteRow(${idx})" title="Delete row">🗑</button></td></tr>`;
  }).join('');
}

// ── mspInit: entry point called by nav('machine-spare') ──────────────────────
async function mspInit() {
  if (typeof gAll === 'function') {
    await mspLoad();
  }
  const empty = document.getElementById('msp-empty');
  const gridView = document.getElementById('msp-grid-view');
  const tableView = document.getElementById('msp-table-view');
  const breadcrumb = document.getElementById('msp-breadcrumb');
  const exportBtn = document.getElementById('msp-export-btn');
  const printBtn = document.getElementById('msp-print-btn');
  const statsBar = document.getElementById('msp-stats-bar');
  const machineFilter = document.getElementById('msp-machine-filter');
  const statusFilter = document.getElementById('msp-status-filter');
  const sortSel = document.getElementById('msp-sort-sel');

  if (!mspLists.length) {
    if (empty) {empty.style.display = '';}
    if (gridView) {gridView.style.display = 'none';}
    if (tableView) {tableView.style.display = 'none';}
    if (breadcrumb) {breadcrumb.style.display = 'none';}
    return;
  }
  if (empty) {empty.style.display = 'none';}

  if (mspActiveListId && mspActiveList()) {
    if (gridView) {gridView.style.display = 'none';}
    if (tableView) {tableView.style.display = '';}
    if (breadcrumb) {breadcrumb.style.display = 'flex';}
    if (exportBtn) {exportBtn.style.display = '';}
    if (printBtn) {printBtn.style.display = '';}
    if (statsBar) {statsBar.style.display = 'flex';}
    if (machineFilter) {machineFilter.style.display = '';}
    if (statusFilter) {statusFilter.style.display = '';}
    if (sortSel) {sortSel.style.display = '';}
    mspOpenList(mspActiveListId);
  } else {
    if (gridView) {gridView.style.display = '';}
    if (tableView) {tableView.style.display = 'none';}
    if (breadcrumb) {breadcrumb.style.display = 'none';}
    if (exportBtn) {exportBtn.style.display = 'none';}
    if (printBtn) {printBtn.style.display = 'none';}
    if (statsBar) {statsBar.style.display = 'none';}
    mspRenderGrid();
  }
}

// ── Persistence ──────────────────────────────────────────────────────────────
async function mspLoad() {
  try {
    mspLists = (await gAll('machine_spares')) || [];
  } catch (e) {
    console.error('[msp] Failed to load machine spare lists:', e);
    mspLists = [];
  }
}

async function mspSave(list) {
  try {
    await dPut('machine_spares', list);
  } catch (e) {
    console.error('[msp] Failed to save machine spare list:', e);
    if (typeof toast === 'function') {toast('Failed to save spare parts list', 'er');}
  }
}

// ── Grid / table navigation ───────────────────────────────────────────────────
function mspShowGrid() {
  mspActiveListId = null;
  document.getElementById('msp-table-view').style.display = 'none';
  document.getElementById('msp-grid-view').style.display = '';
  document.getElementById('msp-breadcrumb').style.display = 'none';
  const exportBtn = document.getElementById('msp-export-btn'); if (exportBtn) {exportBtn.style.display = 'none';}
  const printBtn = document.getElementById('msp-print-btn'); if (printBtn) {printBtn.style.display = 'none';}
  const statsBar = document.getElementById('msp-stats-bar'); if (statsBar) {statsBar.style.display = 'none';}
  ['msp-machine-filter', 'msp-status-filter', 'msp-sort-sel'].forEach(id => {
    const el = document.getElementById(id); if (el) {el.style.display = 'none';}
  });
  mspRenderGrid();
}

function mspOpenList(id) {
  mspActiveListId = id;
  const list = mspActiveList();
  if (!list) {return mspShowGrid();}

  document.getElementById('msp-grid-view').style.display = 'none';
  document.getElementById('msp-table-view').style.display = '';
  document.getElementById('msp-breadcrumb').style.display = 'flex';
  document.getElementById('msp-bc-title').textContent = list.title;
  document.getElementById('msp-bc-machine').textContent = list.machineName ? '· ' + list.machineName : '';

  const exportBtn = document.getElementById('msp-export-btn'); if (exportBtn) {exportBtn.style.display = '';}
  const printBtn = document.getElementById('msp-print-btn'); if (printBtn) {printBtn.style.display = '';}
  const statsBar = document.getElementById('msp-stats-bar'); if (statsBar) {statsBar.style.display = 'flex';}
  ['msp-machine-filter', 'msp-status-filter', 'msp-sort-sel'].forEach(id2 => {
    const el = document.getElementById(id2); if (el) {el.style.display = '';}
  });

  mspPopMachineFilter(list);

  const total = list.rows.length;
  const avail = list.rows.filter(r => r[MSP_STATUS_COL] === 'Available').length;
  const out = list.rows.filter(r => r[MSP_STATUS_COL] === 'Out of Stock').length;
  const onOrder = list.rows.filter(r => r[MSP_STATUS_COL] === 'On Order').length;
  const low = mspListLowCount(list);
  const set = (id2, v) => { const el = document.getElementById(id2); if (el) {el.textContent = v;} };
  set('msp-st-total', total); set('msp-st-avail', avail);
  set('msp-st-low', low); set('msp-st-out', out); set('msp-st-order', onOrder);

  mspRenderTable();
}

// ── Add / Edit list modal ─────────────────────────────────────────────────────
function mspShowAddListModal() {
  document.getElementById('msp-edit-id').value = '';
  document.getElementById('msp-list-title-inp').value = '';
  document.getElementById('msp-list-machine-inp').value = '';
  document.getElementById('msp-list-notes-inp').value = '';
  document.getElementById('msp-list-modal-title').firstChild.textContent = '➕ New Spare Parts List';
  document.getElementById('msp-list-modal').classList.add('on');
}

function mspEditListMeta(id) {
  const list = mspLists.find(l => l.id === id);
  if (!list) {return;}
  document.getElementById('msp-edit-id').value = id;
  document.getElementById('msp-list-title-inp').value = list.title || '';
  document.getElementById('msp-list-machine-inp').value = list.machineName || '';
  document.getElementById('msp-list-notes-inp').value = list.notes || '';
  document.getElementById('msp-list-modal-title').firstChild.textContent = '✏ Edit Spare Parts List';
  document.getElementById('msp-list-modal').classList.add('on');
}

async function mspSaveListMeta() {
  const editId = document.getElementById('msp-edit-id').value;
  const title = document.getElementById('msp-list-title-inp').value.trim();
  const machineName = document.getElementById('msp-list-machine-inp').value.trim();
  const notes = document.getElementById('msp-list-notes-inp').value.trim();
  if (!title) { if (typeof toast === 'function') {toast('List title is required', 'er');} return; }

  if (editId) {
    const list = mspLists.find(l => l.id === editId);
    if (list) { list.title = title; list.machineName = machineName; list.notes = notes; await mspSave(list); }
  } else {
    const list = {
      id: generateUUID(), title, machineName, notes,
      headers: ['Machine Name', 'Part No', 'Part Name', 'Qty', 'Min Qty', MSP_STATUS_COL],
      rows: [], createdAt: new Date().toISOString()
    };
    mspLists.push(list);
    await mspSave(list);
    mspActiveListId = list.id;
  }
  document.getElementById('msp-list-modal').classList.remove('on');
  if (typeof toast === 'function') {toast('List saved', 'ok');}
  mspInit();
}

// ── Delete / duplicate ────────────────────────────────────────────────────────
async function mspDeleteList(id) {
  if (!confirm('Delete this spare parts list? This cannot be undone.')) {return;}
  try { await dDel('machine_spares', id); } catch (e) { console.error('[msp] delete failed', e); }
  mspLists = mspLists.filter(l => l.id !== id);
  if (mspActiveListId === id) {mspActiveListId = null;}
  mspInit();
}

function mspDeleteActiveList() {
  const list = mspActiveList();
  if (!list) {return;}
  mspDeleteList(list.id);
}

async function mspDupList(id) {
  const src = mspLists.find(l => l.id === id);
  if (!src) {return;}
  const copy = JSON.parse(JSON.stringify(src));
  copy.id = generateUUID();
  copy.title = src.title + ' (Copy)';
  copy.createdAt = new Date().toISOString();
  mspLists.push(copy);
  await mspSave(copy);
  if (typeof toast === 'function') {toast('List duplicated', 'ok');}
  mspInit();
}

function mspDuplicateList() {
  const list = mspActiveList();
  if (!list) {return;}
  mspDupList(list.id);
}

function mspDuplicateActiveList() { mspDuplicateList(); }

// ── Row editing ────────────────────────────────────────────────────────────────
async function mspAddRow() {
  const list = mspActiveList();
  if (!list) {return;}
  const blank = {};
  list.headers.forEach(h => { blank[h] = h === MSP_STATUS_COL ? 'Available' : ''; });
  list.rows.push(blank);
  await mspSave(list);
  mspRenderTable();
}

async function mspDeleteRow(idx) {
  const list = mspActiveList();
  if (!list) {return;}
  list.rows.splice(idx, 1);
  await mspSave(list);
  mspOpenList(list.id);
}

async function mspCellBlur(el) {
  const list = mspActiveList();
  if (!list) {return;}
  const idx = Number(el.dataset.row);
  const col = el.dataset.col;
  if (!list.rows[idx]) {return;}
  list.rows[idx][col] = el.textContent.trim();
  await mspSave(list);
  if (col === MSP_STATUS_COL || col === list.headers[0]) {mspOpenList(list.id);} // refresh stats/filters
}

// ── Notes ──────────────────────────────────────────────────────────────────────
function mspOpenNotes() {
  const list = mspActiveList();
  if (!list) {return;}
  document.getElementById('msp-notes-list-name').textContent = list.title;
  document.getElementById('msp-notes-ta').value = list.notes || '';
  document.getElementById('msp-notes-modal').classList.add('on');
}

async function mspSaveNotes() {
  const list = mspActiveList();
  if (!list) {return;}
  list.notes = document.getElementById('msp-notes-ta').value.trim();
  await mspSave(list);
  document.getElementById('msp-notes-modal').classList.remove('on');
  if (typeof toast === 'function') {toast('Notes saved', 'ok');}
}

// ── Clear all ────────────────────────────────────────────────────────────────
async function mspClearAll() {
  if (!confirm('Delete ALL machine spare parts lists? This cannot be undone.')) {return;}
  try { await dClr('machine_spares'); } catch (e) { console.error('[msp] clear failed', e); }
  mspLists = [];
  mspActiveListId = null;
  mspInit();
}

// ── Global search + keyboard suggestions ──────────────────────────────────────
function mspGlobalSearch(value) {
  const box = document.getElementById('msp-suggestions');
  if (!box) {return;}
  const q = (value || '').toLowerCase().trim();
  if (!q) { box.style.display = 'none'; box.innerHTML = ''; if (!mspActiveListId) {mspRenderGrid();} else {mspRenderTable();} return; }

  const matches = mspLists.filter(l =>
    l.title.toLowerCase().includes(q) ||
    (l.machineName || '').toLowerCase().includes(q)
  ).slice(0, 8);

  box.innerHTML = matches.map((l, i) =>
    `<div class="msp-sug-item" data-idx="${i}" data-onclick="mspOpenList(${mspEscapeHtml(mspJsArg(l.id))})" data-style="padding:6px 10px;cursor:pointer">${l.title}${l.machineName ? ' <span data-style="color:var(--tx3);font-size:10px">— ' + l.machineName + '</span>' : ''}</div>`
  ).join('');
  box.style.display = matches.length ? 'block' : 'none';

  if (!mspActiveListId) {mspRenderGrid();} else {mspRenderTable();}
}

let mspSugIdx = -1;
function mspSugKeyNav(e) {
  const box = document.getElementById('msp-suggestions');
  if (!box || box.style.display === 'none') {return;}
  const items = box.querySelectorAll('.msp-sug-item');
  if (!items.length) {return;}
  if (e.key === 'ArrowDown') { e.preventDefault(); mspSugIdx = Math.min(mspSugIdx + 1, items.length - 1); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); mspSugIdx = Math.max(mspSugIdx - 1, 0); }
  else if (e.key === 'Enter') { e.preventDefault(); items[mspSugIdx]?.click(); box.style.display = 'none'; return; }
  else if (e.key === 'Escape') { box.style.display = 'none'; return; }
  else {return;}
  items.forEach((it, i) => it.style.background = i === mspSugIdx ? 'var(--bg3)' : '');
}

// ── Export (CSV) ───────────────────────────────────────────────────────────────
function mspListToCSV(list) {
  const headers = list.headers;
  const csvCell = value => `"${String(value == null ? '' : value).replace(/"/g, '""')}"`;
  const lines = [headers.map(csvCell).join(',')];
  list.rows.forEach(r => {
    lines.push(headers.map(h => csvCell(r[h])).join(','));
  });
  return lines.join('\n');
}

function mspExportList(id) {
  const list = mspLists.find(l => l.id === id);
  if (!list) {return;}
  const csv = mspListToCSV(list);
  if (typeof _dlCSV === 'function') {_dlCSV(csv, `${list.title.replace(/[^a-z0-9]+/gi, '_')}.csv`);}
}

function mspExportActive() {
  const list = mspActiveList();
  if (!list) {return;}
  mspExportList(list.id);
}

// ── Print ────────────────────────────────────────────────────────────────────
function mspBuildPrintHtml(list) {
  const headers = list.headers;
  const rowsHtml = list.rows.map(r => '<tr>' + headers.map(h => `<td>${mspEscapeHtml(r[h])}</td>`).join('') + '</tr>').join('');
  return `<!DOCTYPE html><html><head><style>
    body{font-family:Arial,sans-serif;font-size:10pt;margin:12mm;color:#000}
    h2{margin:0 0 4px}
    table{width:100%;border-collapse:collapse;margin-top:10px}
    th,td{border:1px solid #ccc;padding:4px 6px;text-align:left}
    th{background:#f0f0f0}
  </style></head><body>
    <h2>${mspEscapeHtml(list.title)}</h2>
    ${list.machineName ? `<div>Machine: ${mspEscapeHtml(list.machineName)}</div>` : ''}
    <table><thead><tr>${headers.map(h => `<th>${mspEscapeHtml(h)}</th>`).join('')}</tr></thead><tbody>${rowsHtml}</tbody></table>
  </body></html>`;
}

function mspPrintList(id) {
  const list = mspLists.find(l => l.id === id);
  if (!list) {return;}
  window.printPopupHtml(mspBuildPrintHtml(list));
}

function mspPrintActive() {
  const list = mspActiveList();
  if (!list) {return;}
  mspPrintList(list.id);
}

// ── Import (Excel/CSV/PDF/Word) ─────────────────────────────────────────────
const MSP_MAX_ROWS = 500;
const MSP_MAX_COLS = 500;

// Build the list title from the imported file's own name (extension stripped)
function mspTitleFromFileName(fileName) {
  return fileName.replace(/\.[^.]+$/, '').trim() || fileName;
}

async function mspFinishImport(file, headers, rows) {
  if (!headers.length) { if (typeof toast === 'function') {toast('No headers found in first row', 'er');} return; }
  if (headers.length > MSP_MAX_COLS) {
    if (typeof toast === 'function') {toast(`File exceeds maximum allowed columns (${MSP_MAX_COLS})`, 'er');}
    return;
  }
  if (rows.length > MSP_MAX_ROWS) {
    if (typeof toast === 'function') {toast(`File exceeds maximum allowed rows (${MSP_MAX_ROWS}). Only the first ${MSP_MAX_ROWS} rows will be imported.`, 'er');}
    rows = rows.slice(0, MSP_MAX_ROWS);
  }
  if (!rows.length) { if (typeof toast === 'function') {toast('No data rows found in file', 'er');} return; }

  const list = {
    id: generateUUID(),
    title: mspTitleFromFileName(file.name),
    machineName: '', notes: '',
    headers, rows,
    importedAt: new Date().toISOString()
  };
  mspLists.push(list);
  await mspSave(list);
  mspActiveListId = list.id;
  if (typeof toast === 'function') {toast(`Imported ${rows.length} parts from ${file.name}`, 'ok');}
  mspInit();
}

// CSV parser preserves empty columns and supports quoted commas/newlines and escaped quotes.
function mspParseCsv(text) {
  const input = String(text == null ? '' : text);
  const records = []; let row = []; let cell = ''; let quoted = false;
  for (let i = 0; i < input.length; i += 1) {
    const ch = input[i];
    if (quoted) {
      if (ch === '"' && input[i + 1] === '"') { cell += '"'; i += 1; }
      else if (ch === '"') { quoted = false; }
      else { cell += ch; }
    } else if (ch === '"' && cell === '') { quoted = true; }
    else if (ch === ',') { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && input[i + 1] === '\n') i += 1;
      row.push(cell); records.push(row); row = []; cell = '';
    } else { cell += ch; }
  }
  if (quoted) { throw new Error('CSV contains an unclosed quoted field'); }
  if (cell !== '' || row.length || input.endsWith(',')) { row.push(cell); records.push(row); }
  return records;
}

async function mspImportFile(event) {
  const file = event.target.files && event.target.files[0];
  event.target.value = '';
  if (!file) {return;}
  const ext = file.name.split('.').pop().toLowerCase();

  if (ext === 'csv') {
    const text = await file.text();
    let records;
    try { records = mspParseCsv(text); } catch (err) {
      if (typeof toast === 'function') {toast(`CSV import failed: ${err.message}`, 'er');}
      return;
    }
    while (records.length && records[records.length - 1].every(cell => cell === '')) records.pop();
    if (!records.length || records[0].every(cell => cell.trim() === '')) { if (typeof toast === 'function') {toast('Empty CSV file', 'er');} return; }
    if (records.length - 1 > MSP_MAX_ROWS && typeof toast === 'function') {
      toast(`File exceeds maximum allowed rows (${MSP_MAX_ROWS})`, 'er');
    }
    const headers = records[0].map((value, index) => index === 0 ? value.replace(/^\uFEFF/, '').trim() : value.trim());
    if (headers.length > MSP_MAX_COLS) {
      if (typeof toast === 'function') {toast(`File exceeds maximum allowed columns (${MSP_MAX_COLS})`, 'er');}
      return;
    }
    const rows = records.slice(1, 1 + MSP_MAX_ROWS).filter(values => !values.every(cell => cell === '')).map(vals => {
      const row = {};
      headers.forEach((h, i) => { row[h] = vals[i] == null ? '' : vals[i]; });
      return row;
    });
    await mspFinishImport(file, headers, rows);
  } else if (ext === 'xlsx' || ext === 'xls' || ext === 'xlsm') {
    if (!window.xlsxBridge || typeof window.xlsxBridge.parseBuffer !== 'function') {
      if (typeof toast === 'function') {toast('Excel import is unavailable in this environment. Please use CSV for now.', 'er');}
      return;
    }
    if (typeof showLoading === 'function') {showLoading('Reading Excel file…');}
    try {
      const buffer = await file.arrayBuffer();
      const result = await window.xlsxBridge.parseBuffer(new Uint8Array(buffer));
      if (result.error) {throw new Error(result.error);}
      await mspFinishImport(file, result.headers, result.rows);
    } catch (err) {
      console.error('[MSP Import Error]', err);
      if (typeof toast === 'function') {toast('Import failed: ' + err.message, 'er');}
    } finally {
      if (typeof hideLoading === 'function') {hideLoading();}
    }
  } else {
    if (typeof toast === 'function') {toast('Unsupported format (' + ext.toUpperCase() + '). Please use CSV, XLSX, XLS, or XLSM.', 'er');}
  }
}
