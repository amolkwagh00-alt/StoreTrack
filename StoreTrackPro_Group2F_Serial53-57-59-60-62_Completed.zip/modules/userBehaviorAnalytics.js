/**
 * User Behavior Analytics Module
 * Tracks and analyzes user interactions and patterns
 */

class UserBehaviorAnalytics {
  constructor() {
    this.events = [];
    this.sessionEvents = new Map();
    this.userProfiles = new Map();
    this.currentSessionId = null;
    this.config = {
      maxEvents: 10000,
      maxSessionEvents: 1000,
      sessionTimeout: 30 * 60 * 1000, // 30 minutes
      anonymizeData: true
    };
    this.startTime = Date.now();
  }

  /**
   * Initialize analytics
   * @param {Object} config - Configuration options
   */
  initialize(config = {}) {
    this.config = { ...this.config, ...config };
    this.startSession();
    this.bindEventListeners();
  }

  /**
   * Start a new session
   */
  startSession() {
    this.currentSessionId = this.generateSessionId();
    this.sessionEvents.set(this.currentSessionId, []);
    
    this.trackEvent('session_start', {
      sessionId: this.currentSessionId,
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      screenResolution: `${window.screen.width}x${window.screen.height}`,
 viewportSize: `${window.innerWidth}x${window.innerHeight}`
    });
  }

  /**
   * Track an event
   * @param {string} eventName - Event name
   * @param {Object} eventData - Event data
   */
  trackEvent(eventName, eventData = {}) {
    const event = {
      id: this.generateEventId(),
      sessionId: this.currentSessionId,
      eventName,
      data: this.config.anonymizeData ? this.anonymizeData(eventData) : eventData,
      timestamp: Date.now(),
      url: window.location.href
    };
    
    this.events.push(event);
    
    // Add to session events
    const sessionEvents = this.sessionEvents.get(this.currentSessionId) || [];
    sessionEvents.push(event);
    this.sessionEvents.set(this.currentSessionId, sessionEvents);
    
    // Clean up old events
    if (this.events.length > this.config.maxEvents) {
      this.events = this.events.slice(-this.config.maxEvents);
    }
    
    // Clean up session events
    if (sessionEvents.length > this.config.maxSessionEvents) {
      this.sessionEvents.set(this.currentSessionId, sessionEvents.slice(-this.config.maxSessionEvents));
    }
  }

  /**
   * Track page view
   * @param {string} pageName - Page name
   */
  trackPageView(pageName) {
    this.trackEvent('page_view', {
      pageName,
      referrer: document.referrer,
      title: document.title
    });
  }

  /**
   * Track click event
   * @param {string} elementId - Element ID
   * @param {string} elementType - Element type
   */
  trackClick(elementId, elementType = 'button') {
    this.trackEvent('click', {
      elementId,
      elementType,
      text: this.getElementText(elementId)
    });
  }

  /**
   * Track form submission
   * @param {string} formId - Form ID
   * @param {Object} formData - Form data
   */
  trackFormSubmit(formId, formData = {}) {
    this.trackEvent('form_submit', {
      formId,
      fieldCount: Object.keys(formData).length,
      // Don't include actual form data for privacy
    });
  }

  /**
   * Track error event
   * @param {string} errorType - Error type
   * @param {string} errorMessage - Error message
   */
  trackError(errorType, errorMessage) {
    this.trackEvent('error', {
      errorType,
      errorMessage: this.config.anonymizeData ? this.sanitizeMessage(errorMessage) : errorMessage
    });
  }

  /**
   * Track feature usage
   * @param {string} featureName - Feature name
   * @param {Object} metadata - Additional metadata
   */
  trackFeatureUsage(featureName, metadata = {}) {
    this.trackEvent('feature_usage', {
      featureName,
      ...metadata
    });
  }

  /**
   * Track search query
   * @param {string} query - Search query
   * @param {number} resultCount - Number of results
   */
  trackSearch(query, resultCount = 0) {
    this.trackEvent('search', {
      query: this.config.anonymizeData ? this.hashQuery(query) : query,
      resultCount
    });
  }

  /**
   * Track filter usage
   * @param {string} filterType - Filter type
   * @param {Object} filterValues - Filter values
   */
  trackFilter(filterType, filterValues = {}) {
    this.trackEvent('filter', {
      filterType,
      filterCount: Object.keys(filterValues).length
    });
  }

  /**
   * Track export action
   * @param {string} exportType - Export type
   * @param {number} recordCount - Number of records exported
   */
  trackExport(exportType, recordCount = 0) {
    this.trackEvent('export', {
      exportType,
      recordCount
    });
  }

  /**
   * Track print action
   * @param {string} documentType - Document type
   */
  trackPrint(documentType) {
    this.trackEvent('print', {
      documentType
    });
  }

  /**
   * Bind event listeners for automatic tracking
   */
  bindEventListeners() {
    // Track page visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.trackEvent('page_hidden', {});
      } else {
        this.trackEvent('page_visible', {});
      }
    });
    
    // Track before unload
    window.addEventListener('beforeunload', () => {
      this.trackEvent('session_end', {
        duration: Date.now() - this.startTime,
        eventCount: this.sessionEvents.get(this.currentSessionId)?.length || 0
      });
    });
  }

  /**
   * Get session statistics
   * @param {string} sessionId - Session ID
   */
  getSessionStats(sessionId = this.currentSessionId) {
    const events = this.sessionEvents.get(sessionId) || [];
    
    if (events.length === 0) {
      return null;
    }
    
    const eventTypes = {};
    events.forEach(event => {
      eventTypes[event.eventName] = (eventTypes[event.eventName] || 0) + 1;
    });
    
    const duration = events[events.length - 1].timestamp - events[0].timestamp;
    
    return {
      sessionId,
      eventCount: events.length,
      duration,
      durationFormatted: this.formatDuration(duration),
      eventTypes,
      startTime: events[0].timestamp,
      endTime: events[events.length - 1].timestamp
    };
  }

  /**
   * Get user profile
   * @param {string} userId - User ID
   */
  getUserProfile(userId) {
    let profile = this.userProfiles.get(userId);
    
    if (!profile) {
      profile = {
        userId,
        firstSeen: Date.now(),
        lastSeen: Date.now(),
        sessionCount: 0,
        totalEvents: 0,
        featuresUsed: new Set(),
        commonActions: {}
      };
    }
    
    return profile;
  }

  /**
   * Update user profile
   * @param {string} userId - User ID
   * @param {Object} updates - Profile updates
   */
  updateUserProfile(userId, updates) {
    const profile = this.getUserProfile(userId);
    
    Object.keys(updates).forEach(key => {
      if (key === 'featuresUsed') {
        updates.featuresUsed.forEach(feature => profile.featuresUsed.add(feature));
      } else if (key === 'commonActions') {
        Object.keys(updates.commonActions).forEach(action => {
          profile.commonActions[action] = (profile.commonActions[action] || 0) + updates.commonActions[action];
        });
      } else {
        profile[key] = updates[key];
      }
    });
    
    profile.lastSeen = Date.now();
    this.userProfiles.set(userId, profile);
  }

  /**
   * Get aggregate statistics
   */
  getAggregateStats() {
    const totalEvents = this.events.length;
    const eventTypes = {};
    const pages = {};
    
    this.events.forEach(event => {
      eventTypes[event.eventName] = (eventTypes[event.eventName] || 0) + 1;
      
      if (event.data.pageName) {
        pages[event.data.pageName] = (pages[event.data.pageName] || 0) + 1;
      }
    });
    
    const topEventTypes = Object.entries(eventTypes)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10);
    
    const topPages = Object.entries(pages)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10);
    
    return {
      totalEvents,
      totalSessions: this.sessionEvents.size,
      totalUsers: this.userProfiles.size,
      uptime: Date.now() - this.startTime,
      topEventTypes,
      topPages
    };
  }

  /**
   * Get event funnel
   * @param {Array} eventNames - Event names in funnel order
   */
  getEventFunnel(eventNames) {
    const funnel = eventNames.map(name => ({
      eventName: name,
      count: this.events.filter(e => e.eventName === name).length
    }));
    
    // Calculate conversion rates
    for (let i = 1; i < funnel.length; i++) {
      const previousCount = funnel[i - 1].count;
      const currentCount = funnel[i].count;
      funnel[i].conversionRate = previousCount > 0 
        ? ((currentCount / previousCount) * 100).toFixed(2)
        : 0;
    }
    
    return funnel;
  }

  /**
   * Get user retention data
   */
  getRetentionData() {
    const sessions = Array.from(this.sessionEvents.values());
    const retention = {
      day1: 0,
      day7: 0,
      day30: 0
    };
    
    // Calculate retention based on session patterns
    // This is a simplified implementation
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;
    
    sessions.forEach(sessionEvents => {
      if (sessionEvents.length === 0) {return;}
      
      const firstEvent = sessionEvents[0];
      const daysSinceFirst = (now - firstEvent.timestamp) / dayMs;
      
      if (daysSinceFirst >= 1) {retention.day1++;}
      if (daysSinceFirst >= 7) {retention.day7++;}
      if (daysSinceFirst >= 30) {retention.day30++;}
    });
    
    return retention;
  }

  /**
   * Generate session ID
   */
  generateSessionId() {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Generate event ID
   */
  generateEventId() {
    return `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Anonymize sensitive data
   * @param {Object} data - Data to anonymize
   */
  anonymizeData(data) {
    const anonymized = { ...data };
    
    // Remove or hash sensitive fields
    const sensitiveFields = ['email', 'phone', 'ssn', 'password', 'token', 'key'];
    sensitiveFields.forEach(field => {
      if (anonymized[field]) {
        anonymized[field] = '[REDACTED]';
      }
    });
    
    return anonymized;
  }

  /**
   * Sanitize error message
   * @param {string} message - Message to sanitize
   */
  sanitizeMessage(message) {
    return message.replace(/[^\w\s.-]/g, '').substring(0, 100);
  }

  /**
   * Hash query for privacy
   * @param {string} query - Query to hash
   */
  hashQuery(query) {
    let hash = 0;
    for (let i = 0; i < query.length; i++) {
      const char = query.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return hash.toString(16);
  }

  /**
   * Get element text
   * @param {string} elementId - Element ID
   */
  getElementText(elementId) {
    const element = document.getElementById(elementId);
    return element ? element.textContent?.substring(0, 50) : '';
  }

  /**
   * Format duration
   * @param {number} ms - Duration in milliseconds
   */
  formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) {return `${hours}h ${minutes % 60}m`;}
    if (minutes > 0) {return `${minutes}m ${seconds % 60}s`;}
    return `${seconds}s`;
  }

  /**
   * Export analytics data
   */
  exportData() {
    return {
      timestamp: Date.now(),
      events: this.events,
      sessions: Array.from(this.sessionEvents.entries()).map(([id, events]) => ({
        sessionId: id,
        events,
        stats: this.getSessionStats(id)
      })),
      userProfiles: Array.from(this.userProfiles.values()),
      aggregate: this.getAggregateStats()
    };
  }

  /**
   * Clear all data
   */
  clearData() {
    this.events = [];
    this.sessionEvents.clear();
    this.userProfiles.clear();
    this.startSession();
  }

  /**
   * Set configuration
   * @param {Object} config - Configuration options
   */
  setConfig(config) {
    this.config = { ...this.config, ...config };
  }

  /**
   * Get configuration
   */
  getConfig() {
    return { ...this.config };
  }
}

// Create singleton instance
const userBehaviorAnalytics = new UserBehaviorAnalytics();

// Export for use in app
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { UserBehaviorAnalytics, userBehaviorAnalytics };
}
