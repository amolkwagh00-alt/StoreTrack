/**
 * Enterprise Cache Manager
 * Centralized caching layer for StoreTrack Pro
 */

class CacheEntryV2 {
  constructor(key, value, ttl = 3600000) {
    this.key = key;
    this.value = value;
    this.createdAt = Date.now();
    this.ttl = ttl;
    this.hits = 0;
    this.lastAccessed = Date.now();
  }

  /**
   * Check if entry is expired
   * @returns {boolean} Is expired
   */
  isExpired() {
    return Date.now() - this.createdAt > this.ttl;
  }

  /**
   * Get value and update access stats
   * @returns {*} Cached value
   */
  get() {
    this.hits++;
    this.lastAccessed = Date.now();
    return this.value;
  }
}

class CacheManager {
  constructor() {
    this.cache = new Map();
    this.stats = {
      hits: 0,
      misses: 0,
      sets: 0,
      deletes: 0,
      clears: 0
    };
    this.maxSize = 1000;
    this.defaultTTL = 3600000; // 1 hour
    this.cleanupInterval = 300000; // 5 minutes
    // Persist operations are serialized so rapid cache updates cannot reintroduce
    // an aggregate array row while an earlier write is still in progress.
    this.persistQueue = Promise.resolve();
    this.init();
  }

  /**
   * Initialize cache manager
   */
  init() {
    this.startCleanupInterval();
    this.loadPersistedCache();
  }

  /**
   * Start cleanup interval
   */
  startCleanupInterval() {
    setInterval(() => {
      this.cleanupExpired();
    }, this.cleanupInterval);
  }

  /**
   * Load persisted cache from storage
   */
  async loadPersistedCache() {
    try {
      const persisted = await gAll('cache_entries');
      const now = Date.now();
      // Versions before the per-entry persistence fix stored the entire cache
      // as one array-valued IndexedDB row. Flatten that legacy shape and rewrite
      // it as normal object rows so complete backup validation can succeed.
      const legacyAggregate = persisted.some(entry => Array.isArray(entry));
      const entries = persisted.flatMap(entry => Array.isArray(entry) ? entry : [entry])
        .filter(entry => entry && typeof entry === 'object' && !Array.isArray(entry)
          && entry.key !== undefined && Number.isFinite(Number(entry.createdAt))
          && Number.isFinite(Number(entry.ttl)));

      for (const entry of entries) {
        if (now - entry.createdAt < entry.ttl) {
          this.cache.set(entry.key, new CacheEntryV2(entry.key, entry.value, entry.ttl));
        }
      }
      if (legacyAggregate) await this.persistCache();
    } catch (err) {
      console.error('Failed to load persisted cache:', err);
    }
  }

  /**
   * Persist cache to storage
   */
  async persistCache() {
    try {
      const entries = this.entries();
      this.persistQueue = this.persistQueue.catch(() => undefined).then(async () => {
        await dClr('cache_entries');
        for (const entry of entries) await dPut('cache_entries', entry);
      });
      await this.persistQueue;
    } catch (err) {
      console.error('Failed to persist cache:', err);
    }
  }

  /**
   * Set value in cache
   * @param {string} key - Cache key
   * @param {*} value - Value to cache
   * @param {number} ttl - Time to live in milliseconds
   */
  set(key, value, ttl = this.defaultTTL) {
    // Evict oldest entry if cache is full
    if (this.cache.size >= this.maxSize) {
      this.evictOldest();
    }

    const entry = new CacheEntryV2(key, value, ttl);
    this.cache.set(key, entry);
    this.stats.sets++;
    
    // Persist to storage
    this.persistCache();
  }

  /**
   * Get value from cache
   * @param {string} key - Cache key
   * @returns {*} Cached value or null
   */
  get(key) {
    const entry = this.cache.get(key);
    
    if (!entry) {
      this.stats.misses++;
      return null;
    }

    if (entry.isExpired()) {
      this.cache.delete(key);
      this.stats.misses++;
      return null;
    }

    this.stats.hits++;
    return entry.get();
  }

  /**
   * Check if key exists in cache
   * @param {string} key - Cache key
   * @returns {boolean} Exists
   */
  has(key) {
    const entry = this.cache.get(key);
    
    if (!entry) {return false;}
    
    if (entry.isExpired()) {
      this.cache.delete(key);
      return false;
    }

    return true;
  }

  /**
   * Delete value from cache
   * @param {string} key - Cache key
   * @returns {boolean} Was deleted
   */
  delete(key) {
    const deleted = this.cache.delete(key);
    if (deleted) {
      this.stats.deletes++;
      this.persistCache();
    }
    return deleted;
  }

  /**
   * Clear all cache entries
   */
  clear() {
    this.cache.clear();
    this.stats.clears++;
    this.persistCache();
  }

  /**
   * Evict oldest entry
   */
  evictOldest() {
    let oldestKey = null;
    let oldestTime = Infinity;

    for (const [key, entry] of this.cache) {
      if (entry.lastAccessed < oldestTime) {
        oldestTime = entry.lastAccessed;
        oldestKey = key;
      }
    }

    if (oldestKey) {
      this.cache.delete(oldestKey);
    }
  }

  /**
   * Cleanup expired entries
   */
  cleanupExpired() {
    let cleaned = 0;

    for (const [key, entry] of this.cache) {
      if (entry.isExpired()) {
        this.cache.delete(key);
        cleaned++;
      }
    }

    if (cleaned > 0) {
      this.persistCache();
    }

    return cleaned;
  }

  /**
   * Get or set pattern
   * @param {string} key - Cache key
   * @param {Function} fn - Function to generate value
   * @param {number} ttl - Time to live
   * @returns {*} Cached or generated value
   */
  async getOrSet(key, fn, ttl = this.defaultTTL) {
    const cached = this.get(key);
    
    if (cached !== null) {
      return cached;
    }

    const value = await fn();
    this.set(key, value, ttl);
    return value;
  }

  /**
   * Get multiple values
   * @param {Array<string>} keys - Cache keys
   * @returns {object} Key-value pairs
   */
  getMany(keys) {
    const result = {};
    
    for (const key of keys) {
      result[key] = this.get(key);
    }

    return result;
  }

  /**
   * Set multiple values
   * @param {object} entries - Key-value pairs
   * @param {number} ttl - Time to live
   */
  setMany(entries, ttl = this.defaultTTL) {
    for (const [key, value] of Object.entries(entries)) {
      this.set(key, value, ttl);
    }
  }

  /**
   * Delete multiple keys
   * @param {Array<string>} keys - Cache keys
   */
  deleteMany(keys) {
    for (const key of keys) {
      this.delete(key);
    }
  }

  /**
   * Get cache size
   * @returns {number} Cache size
   */
  size() {
    return this.cache.size;
  }

  /**
   * Get cache keys
   * @returns {Array<string>} Cache keys
   */
  keys() {
    return Array.from(this.cache.keys());
  }

  /**
   * Get cache values
   * @returns {Array<*>} Cache values
   */
  values() {
    return Array.from(this.cache.values()).map(entry => entry.value);
  }

  /**
   * Get cache entries
   * @returns {Array<object>} Cache entries
   */
  entries() {
    return Array.from(this.cache.entries()).map(([key, entry]) => ({
      key,
      value: entry.value,
      createdAt: entry.createdAt,
      ttl: entry.ttl,
      hits: entry.hits,
      lastAccessed: entry.lastAccessed
    }));
  }

  /**
   * Get statistics
   * @returns {object} Cache statistics
   */
  getStatistics() {
    const hitRate = this.stats.hits + this.stats.misses > 0
      ? (this.stats.hits / (this.stats.hits + this.stats.misses)) * 100
      : 0;

    return {
      size: this.cache.size,
      maxSize: this.maxSize,
      hitRate: hitRate.toFixed(2) + '%',
      hits: this.stats.hits,
      misses: this.stats.misses,
      sets: this.stats.sets,
      deletes: this.stats.deletes,
      clears: this.stats.clears,
      entries: this.entries()
    };
  }

  /**
   * Reset statistics
   */
  resetStatistics() {
    this.stats = {
      hits: 0,
      misses: 0,
      sets: 0,
      deletes: 0,
      clears: 0
    };
  }

  /**
   * Set max cache size
   * @param {number} size - Max size
   */
  setMaxSize(size) {
    this.maxSize = size;
    
    // Evict entries if over new limit
    while (this.cache.size > this.maxSize) {
      this.evictOldest();
    }
  }
}

// Global cache manager instance
const cacheManager = new CacheManager();

// Expose to window
if (typeof window !== 'undefined') {
  window.CacheManager = CacheManager;
  window.cacheManager = cacheManager;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { CacheManager, cacheManager, CacheEntryV2 };
}
