# StoreTrack Pro

StoreTrack Pro 5.0.0 is an Electron inventory application with local IndexedDB and a separately deployable optional central Node/PostgreSQL service. This README summarizes the supplied repository source; use the [documentation index](docs/README.md) and [current behavior hub](docs/CURRENT_BEHAVIOR.md) for maintained logic and evidence boundaries.

## Current architecture and important boundaries

The desktop/local and optional central service are distinct application domains with separate persistence and authorization boundaries. Desktop uses IndexedDB schema v23 (`StoreTrackDB_ShankMapping_Clean_20260825`); the optional central service uses PostgreSQL migrations 001–005 and exposes a narrower API, not full CRUD. Renderer permissions, central API roles, shared-folder sync, central HTTPS/WebSocket sync and service-worker/offline behavior are distinct systems.

Shank Mapping includes station/gun mappings, part master, stock bins, replacement and lifecycle workflows, analytics and history. Pencil stock and historical-entry rules differ from standard shank flows. Atomic local stock mutation, CAS/encryption limits, central-sync cadence, performance targets (not achieved measurements), and verification caveats are summarized in [Current Behavior](docs/CURRENT_BEHAVIOR.md); operational detail is in the [Shank Mapping index](docs/SHANK_MAPPING_INDEX.md) and [user guide](docs/SHANK_MAPPING_USER_GUIDE.md).

## Development commands

```bash
npm install
npm start
npm test
npm run test:unit
npm run test:integration
npm run test:database
npm run test:smoke
npm run test:offline
npm run test:e2e
npm run lint
```

These are available commands, not pass claims by themselves. After the supplied Windows log was reviewed and code fixes applied, the provided sandbox passed 53 Jest suites / 488 tests, Playwright 3/3, smoke/offline checks, and `release:check`; lint exited 0 with 401 warnings. The Windows installer/build has not been rerun after those fixes. For a Windows NSIS package, use `npm run build` on an appropriate Windows build host. See [Testing Documentation](docs/final/Testing_Documentation.md) and the [bug-audit follow-up](docs/BUG_AUDIT_2026-11-05.md) for scope and evidence requirements.

## Documentation and release hygiene

Markdown guides and Mermaid sources are maintained; PNG/DOCX/PDF outputs and `file_inventory.json` are derived artifacts. Dated baseline audit/closure reports are historical records; see the separate [2026-11-05 bug-audit follow-up](docs/BUG_AUDIT_2026-11-05.md) for current fixes and remaining runtime caveats. Regenerate inventory with `python3 scripts/refresh-documentation.py`; synchronize central release output with `npm run central:bundle` and check using `npm run release:check`. Neither inventory generation nor release hygiene constitutes full production QA. See [documentation index](docs/README.md) and [executive summary](docs/final/Executive_Summary.md).
