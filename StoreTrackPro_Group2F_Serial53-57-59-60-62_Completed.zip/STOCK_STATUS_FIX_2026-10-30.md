# StoreTrack Stock Status Fix — 2026-10-30

## Actual stock status

The application now uses one part-level rule across Stock Status, Dashboard alerts, and stock exports:

- `Available Qty = 0` → `ZERO STOCK`
- `Available Qty < Required Qty` → `LOW STOCK`
- `Available Qty >= Required Qty` → `OK STOCK`

Required Qty is derived from the mapped Part Number occurrence count, with the configured Part Master or stored minimum used as a fallback. Equality with Required Qty is `OK STOCK`.

Unmapped candidate-only parts are excluded from operational stock counts and alerts. A candidate-only part that is actually present in Station/Gun mappings is treated as operational and included.

## Consumption and procurement forecast

Consumption history, lead time, reorder point, and safety stock remain active for procurement forecasting. They are exposed separately from actual stock status:

- No consumption history → forecast `NO DATA`; the displayed primary status uses the actual stock status.
- With consumption history → forecast may be `NORMAL`, `REORDER`, or `STOCK-OUT RISK` while the actual stock status remains available separately.

The Part Number normalization mismatch in automatic required-quantity lookup was fixed so mapped occurrence counts are applied consistently.
