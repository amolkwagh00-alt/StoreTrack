from pathlib import Path
import re
p = Path('/home/ubuntu/work_storetrack/modules/componentManagement.js')
s = p.read_text()
new = """  function openStationFromQr(value){try{const raw=String(value||'').trim();let station='',bin='',parts=[];if(/^storetrack:/i.test(raw)){const url=new URL(raw);station=url.searchParams.get('stationNo')||'';bin=url.searchParams.get('binId')||'';const packed=url.searchParams.get('d');if(packed){const data=JSON.parse(packed);station=data.s||data.stationNo||station;bin=data.b||data.binId||bin;}}else{const lines=raw.split(/\\r?\\n/);for(const line of lines){const stationMatch=line.match(/^\\s*STATION\\s*:\\s*(.*)$/i);if(stationMatch)station=stationMatch[1].trim();const binMatch=line.match(/^\\s*BIN\\s*:\\s*(.*)$/i);if(binMatch)bin=binMatch[1].trim();if(/^\\s*-\\s*(.+)/.test(line))parts.push(line.replace(/^\\s*-\\s*/,'').trim());}}if(!station&&!bin){throw new Error('Missing Station/Bin');}if(typeof window.componentOpenStationQrDetails === 'function'){return window.componentOpenStationQrDetails(station,bin,parts);}state.stationSearch={station,bin};open('matrix');toastMsg(`Station ${station||''} / Bin ${bin||''} loaded`,'suc');return {station,bin,parts};}catch(e){toastMsg('Invalid Shank Mapping QR payload','er');return null;}}"""
s2, n = re.subn(r'^  function openStationFromQr\(value\)\{.*$', lambda _m: new, s, count=1, flags=re.M)
if n != 1:
    raise SystemExit(f'QR function replacement count={n}')
p.write_text(s2)
