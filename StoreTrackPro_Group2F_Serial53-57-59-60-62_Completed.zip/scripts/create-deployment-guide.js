const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const dist = path.join(root, 'dist');
const guideDir = path.join(dist, 'StoreTrack-Deployment-Guide');
const copy = (from, to) => {
  fs.mkdirSync(path.dirname(to), { recursive: true });
  fs.copyFileSync(from, to);
};

if (!fs.existsSync(dist)) {
  throw new Error(`Build output directory does not exist: ${dist}`);
}

fs.rmSync(guideDir, { recursive: true, force: true });
fs.mkdirSync(guideDir, { recursive: true });

copy(path.join(root, 'docs', 'STORETRACK-DEPLOYMENT-GUIDE.md'), path.join(guideDir, '01-STORETRACK-DEPLOYMENT-GUIDE.md'));
copy(path.join(root, 'installer', 'Install-Central-Server.ps1'), path.join(guideDir, '02-Install-Central-Server.ps1'));
copy(path.join(root, 'installer', 'Setup-Central-Server.cmd'), path.join(guideDir, '03-Setup-Central-Server.cmd'));
copy(path.join(root, 'server', 'DEPLOYMENT.md'), path.join(guideDir, '04-Central-Server-Deployment.md'));
copy(path.join(root, 'PRODUCTION_SECURITY_SETUP.md'), path.join(guideDir, '05-Production-Security-Setup.md'));

fs.writeFileSync(
  path.join(guideDir, 'README.txt'),
  [
    'StoreTrack Pro deployment package',
    '',
    'Start with 01-STORETRACK-DEPLOYMENT-GUIDE.md.',
    'Run the PowerShell installer as Administrator only after preparing the production TLS certificate.',
    'Do not place .env files, private keys, plaintext credentials, or unencrypted database dumps in this folder.',
    '',
  ].join('\n'),
  'utf8',
);

console.log(`Deployment guide created: ${guideDir}`);
