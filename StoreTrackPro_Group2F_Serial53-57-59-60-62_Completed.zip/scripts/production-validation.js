#!/usr/bin/env node
const fs = require('fs'),
  path = require('path');
const root = path.resolve(__dirname, '..');
const checks = [];
function check(name, ok, detail, mandatory = true) {
  checks.push({ name, ok, detail, mandatory });
}
check(
  'release files',
  fs.existsSync(path.join(root, 'release', 'central-server', 'server', 'index.js')),
  'packaged central server copy exists',
);
check(
  'JWT secret configured',
  Boolean(process.env.STORETRACK_JWT_SECRET && process.env.STORETRACK_JWT_SECRET.length >= 32),
  'set STORETRACK_JWT_SECRET before starting central server',
);
check(
  'PostgreSQL URL configured',
  Boolean(process.env.DATABASE_URL || process.env.PGHOST),
  'set DATABASE_URL/PGHOST for integration test',
);
check(
  'scanner configuration',
  !process.env.REQUIRE_HARDWARE_VALIDATION || Boolean(process.env.STORETRACK_SCANNER_PORT || process.env.SCANNER_DEVICE),
  'set scanner device/port for hardware test',
  Boolean(process.env.REQUIRE_HARDWARE_VALIDATION),
);
check(
  'printer configuration',
  !process.env.REQUIRE_HARDWARE_VALIDATION || Boolean(process.env.STORETRACK_PRINTER || process.env.PRINTER_NAME),
  'set printer name/device for label test',
  Boolean(process.env.REQUIRE_HARDWARE_VALIDATION),
);
check(
  'load limit declared',
  !process.env.REQUIRE_LOAD_VALIDATION || Boolean(process.env.LOAD_TEST_ROWS || process.env.LOAD_TEST_TARGET),
  'set load-test target before performance run',
  Boolean(process.env.REQUIRE_LOAD_VALIDATION),
);
check(
  'concurrency target declared',
  !process.env.REQUIRE_LOAD_VALIDATION || Boolean(process.env.CONCURRENCY_CLIENTS),
  'set CONCURRENCY_CLIENTS before multi-client test',
  Boolean(process.env.REQUIRE_LOAD_VALIDATION),
);
for (const c of checks) console.log(`${c.ok ? 'PASS' : c.mandatory ? 'BLOCKED' : 'SKIPPED'}\t${c.name}\t${c.detail}`);
const blocked = checks.filter((c) => c.mandatory && !c.ok).length;
console.log(
  `SUMMARY: ${checks.length - blocked} pass, ${blocked} blocked by environment configuration`,
);
process.exitCode = blocked ? 1 : 0;
