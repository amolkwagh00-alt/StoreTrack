from pathlib import Path
p = Path('/home/ubuntu/work_storetrack/server/index.js')
s = p.read_text()
s = s.replace("const HOST = process.env.HOST || '0.0.0.0';\nconst CORS_ORIGIN = process.env.CORS_ORIGIN || '*';", "const HOST = process.env.HOST || '127.0.0.1';\nconst CORS_ORIGIN = process.env.CORS_ORIGIN || `http://127.0.0.1:${PORT}`;\nconst MAX_GUN_ROWS = Number(process.env.MAX_GUN_ROWS || 10000);\nconst loginAttempts = new Map();\nconst LOGIN_WINDOW_MS = 15 * 60 * 1000;\nconst LOGIN_MAX_ATTEMPTS = Number(process.env.LOGIN_MAX_ATTEMPTS || 10);")
s = s.replace("function route(req) {", """function loginAllowed(ip, username) {
  const key = `${ip}|${String(username || '').trim().toLowerCase()}`;
  const now = Date.now();
  const previous = loginAttempts.get(key) || { count: 0, since: now };
  if (now - previous.since >= LOGIN_WINDOW_MS) { previous.count = 0; previous.since = now; }
  previous.count += 1;
  loginAttempts.set(key, previous);
  if (loginAttempts.size > 10000) {
    for (const [storedKey, value] of loginAttempts) if (now - value.since >= LOGIN_WINDOW_MS) loginAttempts.delete(storedKey);
  }
  return previous.count <= LOGIN_MAX_ATTEMPTS;
}
function clearLoginAttempts(ip, username) {
  loginAttempts.delete(`${ip}|${String(username || '').trim().toLowerCase()}`);
}
function eventVisibleToUser(event, user) {
  const payload = event?.payload || {};
  const eventScope = payload.tenantId || payload.siteId || payload.locationId || payload.deviceId;
  const userScope = user?.tenantId || user?.siteId || user?.locationId || user?.deviceId;
  return !eventScope || !userScope || String(eventScope) === String(userScope);
}

function route(req) {""")
s = s.replace("      if (!username || !password)\n        return send(res, 400, { error: 'Username and password are required' });", "      if (!username || !password)\n        return send(res, 400, { error: 'Username and password are required' });\n      const ip = req.socket.remoteAddress || 'unknown';\n      if (!loginAllowed(ip, username)) return send(res, 429, { error: 'Too many login attempts. Try again later.' });")
s = s.replace("      const user = result.rows[0];\n      return send(res, 200, {", "      const user = result.rows[0];\n      clearLoginAttempts(ip, username);\n      return send(res, 200, {")
s = s.replace("      if (!Array.isArray(payload.sourceRows) || !Array.isArray(payload.mappingRows))\n        return send(res, 400, { error: 'sourceRows and mappingRows arrays are required' });", "      if (!Array.isArray(payload.sourceRows) || !Array.isArray(payload.mappingRows))\n        return send(res, 400, { error: 'sourceRows and mappingRows arrays are required' });\n      if (payload.sourceRows.length > MAX_GUN_ROWS || payload.mappingRows.length > MAX_GUN_ROWS)\n        return send(res, 413, { error: `Too many rows. Maximum is ${MAX_GUN_ROWS} per array.` });")
s = s.replace("  wss.on('connection', (ws) => {\n    clients.add(ws);", "  wss.on('connection', (ws, user) => {\n    clients.add(ws);\n    ws.storeTrackUser = user;")
s = s.replace("      requireAuth(req);\n    } catch {", "      req.storeTrackUser = requireAuth(req);\n    } catch {")
s = s.replace("    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));", "    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req.storeTrackUser));")
s = s.replace("    for (const ws of clients)\n      if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'sync.event', event: latest }));", "    for (const ws of clients)\n      if (ws.readyState === 1 && eventVisibleToUser(latest, ws.storeTrackUser)) ws.send(JSON.stringify({ type: 'sync.event', event: latest }));")
p.write_text(s)
