from pathlib import Path
p=Path('/home/ubuntu/work_storetrack/app.js'); s=p.read_text()
repls={
'${x.name} [${x.barcode}]':'${sanitizeHTML(String(x.name||""))} [${sanitizeHTML(String(x.barcode||""))}]',
'${x.name}</option>':'${sanitizeHTML(String(x.name||""))}</option>',
'${m.name} [${m.barcode}]':'${sanitizeHTML(String(m.name||""))} [${sanitizeHTML(String(m.barcode||""))}]',
'${m.name} (${m.barcode})':'${sanitizeHTML(String(m.name||""))} (${sanitizeHTML(String(m.barcode||""))})',
'${r.materialName}</td>':'${sanitizeHTML(String(r.materialName||""))}</td>',
'${r.unit}</td>':'${sanitizeHTML(String(r.unit||""))}</td>',
'${r.returnedBy||\'-\'}</td>':'${sanitizeHTML(String(r.returnedBy||"-"))}</td>',
'${r.deptName||\'-\'}</td>':'${sanitizeHTML(String(r.deptName||"-"))}</td>',
'${r.reason||\'-\'}</td>':'${sanitizeHTML(String(r.reason||"-"))}</td>',
'${r.userName}</td>':'${sanitizeHTML(String(r.userName||""))}</td>',
'${c.userName}</td>':'${sanitizeHTML(String(c.userName||""))}</td>',
'${l.desc}':'${sanitizeHTML(String(l.desc||""))}',
}
for a,b in repls.items(): s=s.replace(a,b)
p.write_text(s)
