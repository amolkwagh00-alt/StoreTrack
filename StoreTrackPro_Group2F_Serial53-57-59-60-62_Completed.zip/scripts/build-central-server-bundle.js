#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const root = path.resolve(__dirname, '..');
const outDir = path.join(root, 'release', 'central-server');
const archive = path.join(root, 'release', 'StoreTrackPro-Central-Server-v51.zip');
fs.rmSync(outDir, { recursive: true, force: true });
fs.mkdirSync(outDir, { recursive: true });
for (const item of [
  'server',
  'core/gunCountService.js',
  'installer/Install-Central-Server.ps1',
  'docs/CENTRAL_SERVER_DEPLOYMENT.md',
]) {
  const src = path.join(root, item);
  const dest = path.join(outDir, item);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  if (fs.statSync(src).isDirectory()) fs.cpSync(src, dest, { recursive: true });
  else fs.copyFileSync(src, dest);
}
fs.writeFileSync(
  path.join(outDir, 'Setup-Central-Server.cmd'),
  `@echo off\r\nif "%~1"=="" (\r\n  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','%~dp0installer\\Install-Central-Server.ps1'"\r\n) else (\r\n  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -Wait -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','%~dp0installer\\Install-Central-Server.ps1','%*'"\r\n)\r\nif errorlevel 1 pause\r\n`,
);
fs.writeFileSync(
  path.join(outDir, 'README.md'),
  '# StoreTrack Pro Central Server Bundle\n\nDeploy this bundle separately from the Electron installer. Copy server/.env.example to server/.env, set strong secrets, run migrations, and start the Node service or Docker Compose. Never commit .env or production data backups.\n',
);
fs.writeFileSync(
  path.join(outDir, 'package.json'),
  JSON.stringify(
    {
      name: 'storetrack-central-server',
      private: true,
      version: '5.0.0',
      dependencies: { bcryptjs: '^3.0.3', dotenv: '^17.4.2', pg: '^8.23.0', ws: '^8.21.3' },
    },
    null,
    2,
  ) + '\n',
);
fs.mkdirSync(path.dirname(archive), { recursive: true });
fs.rmSync(archive, { force: true });
execFileSync('zip', ['-qr', archive, '.'], { cwd: outDir, stdio: 'inherit' });
console.log(archive);
