#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const forbidden = [];
function walk(dir) {
  if (!fs.existsSync(dir)) return;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git', 'dist', 'test-results', 'coverage'].includes(entry.name)) continue;
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(file);
    else if (
      /StoreTrackData[\\/]CompleteBackups[\\/].*\.json$/i.test(file) ||
      /StoreTrackPro-backup-.*\.json$/i.test(entry.name) ||
      /(?:^|[\\/])scanner\.log$/i.test(file)
    )
      forbidden.push(path.relative(root, file));
  }
}
walk(root);
if (forbidden.length) {
  console.error('Release hygiene failed: live business backups found:\n' + forbidden.join('\n'));
  process.exit(1);
}
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (pkg.build?.extraResources?.some((item) => item?.from === 'StoreTrackData')) {
  console.error('Release hygiene failed: StoreTrackData is packaged as an extra resource.');
  process.exit(1);
}
const mainSource = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
// The app window CSP must stay strict. The print-preview partition is
// intentionally isolated and may use inline styles because it renders
// generated print/label HTML; do not treat that separate policy as an app
// CSP violation.
const appCspStart = mainSource.indexOf('mainWindow.webContents.session.webRequest.onHeadersReceived');
const appCspSource = appCspStart >= 0 ? mainSource.slice(appCspStart) : mainSource;
if (
  appCspSource.includes("'unsafe-eval'") ||
  appCspSource.includes("'unsafe-inline'") ||
  appCspSource.includes('cdn.jsdelivr.net')
) {
  console.error('Release hygiene failed: unsafe app CSP directive or CDN dependency remains.');
  process.exit(1);
}
console.log('RELEASE HYGIENE PASS');

const centralRelease = path.join(root, 'release', 'central-server');
if (!fs.existsSync(path.join(centralRelease, 'package.json')))
  throw new Error('central release package.json missing');
function compareTree(relativeDir) {
  const sourceDir = path.join(root, relativeDir);
  const releaseDir = path.join(centralRelease, relativeDir);
  function files(dir) {
    return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
      const absolute = path.join(dir, entry.name);
      return entry.isDirectory()
        ? files(absolute).map((file) => path.join(entry.name, file))
        : [entry.name];
    });
  }
  const sourceFiles = files(sourceDir).sort();
  const releaseFiles = files(releaseDir).sort();
  if (JSON.stringify(sourceFiles) !== JSON.stringify(releaseFiles))
    throw new Error(`release ${relativeDir} file list is stale`);
  for (const file of sourceFiles) {
    if (!fs.readFileSync(path.join(sourceDir, file)).equals(fs.readFileSync(path.join(releaseDir, file))))
      throw new Error(`release ${relativeDir}/${file} is stale`);
  }
}
compareTree('server');
const launcher = fs.readFileSync(path.join(centralRelease, 'Setup-Central-Server.cmd'));
if (launcher.subarray(0, 11).toString() !== '@echo off\r\n')
  throw new Error('central launcher must start with CRLF');
