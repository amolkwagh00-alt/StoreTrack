from pathlib import Path
p=Path('/home/ubuntu/work_storetrack/app.js')
s=p.read_text()
repls={
'${m.barcode}</td><td data-style="font-weight:500">${m.name}</td><td>${m.category}</td>':'${sanitizeHTML(String(m.barcode||""))}</td><td data-style="font-weight:500">${sanitizeHTML(String(m.name||""))}</td><td>${sanitizeHTML(String(m.category||""))}</td>',
'${it.name}</td><td>${it.unit}</td>':'${sanitizeHTML(String(it.name||""))}</td><td>${sanitizeHTML(String(it.unit||""))}</td>',
'${m.barcode}</td><td data-style="font-weight:500">${m.name}</td><td>${m.category}</td>':'${sanitizeHTML(String(m.barcode||""))}</td><td data-style="font-weight:500">${sanitizeHTML(String(m.name||""))}</td><td>${sanitizeHTML(String(m.category||""))}</td>',
'${r.m.barcode}</td>':'${sanitizeHTML(String(r.m.barcode||""))}</td>',
'${r.m.name}</td>':'${sanitizeHTML(String(r.m.name||""))}</td>',
'${r.m.category}</td>':'${sanitizeHTML(String(r.m.category||""))}</td>',
'${r.m.unit}</td>':'${sanitizeHTML(String(r.m.unit||""))}</td>',
'${l.zone}</td>':'${sanitizeHTML(String(l.zone||""))}</td>',
'${l.rack}</td>':'${sanitizeHTML(String(l.rack||""))}</td>',
'${l.bin}</td>':'${sanitizeHTML(String(l.bin||""))}</td>',
'${locStr}</span>':'${sanitizeHTML(String(locStr||""))}</span>',
'${m.category}</td>':'${sanitizeHTML(String(m.category||""))}</td>',
'${SP.map(s=>`<option value="${s.id}">${s.name}</option>`).join(\'\')}':'${SP.map(s=>`<option value="${s.id}">${sanitizeHTML(String(s.name||""))}</option>`).join(\'\')}',
}
for a,b in repls.items(): s=s.replace(a,b)
p.write_text(s)
