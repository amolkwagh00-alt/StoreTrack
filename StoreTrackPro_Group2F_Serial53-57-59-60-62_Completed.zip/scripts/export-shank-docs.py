#!/usr/bin/env python3
"""Generate the maintained Shank Mapping DOCX/PDF exports from docs/*.md.
Requires python-docx and the Manus manus-md-to-pdf utility for PDF generation.
"""
from pathlib import Path
import subprocess
from docx import Document
from docx.shared import Inches, Pt

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / 'docs'
OUT = DOCS / 'exports'
OUT.mkdir(parents=True, exist_ok=True)
SOURCES = [
    'SHANK_MAPPING_INDEX.md', 'SHANK_MAPPING_QUICK_START.md',
    'SHANK_MAPPING_USER_GUIDE.md', 'SHANK_MAPPING_HOW_TO.md',
    'SHANK_MAPPING_PROCESS.md', 'SHANK_MAPPING_DATA_FLOW_ENGLISH.md',
    'SHANK_MAPPING_PRODUCTION_WORKFLOW.md', 'SHANK_MAPPING_ROLE_GUIDE.md',
    'SHANK_MAPPING_TROUBLESHOOTING.md', 'STOCK_ENTRY_EXCEL_IMPORT.md',
]
lines = [
    '# StoreTrack Pro — Shank Mapping Documentation',
    '> Generated 2026-11-05 from the maintained Markdown guides in this repository. Source code/tests remain authoritative; this export is not production certification.',
]
for name in SOURCES:
    path = DOCS / name
    lines.extend(['', f'<!-- Source: docs/{name} -->', '', path.read_text(encoding='utf-8')])
markdown = '\n'.join(lines) + '\n'
tmp = Path('/tmp/storetrack-shank-docs.md')
tmp.write_text(markdown, encoding='utf-8')

# Build the editable Word export from source text.
doc = Document()
doc.add_heading('StoreTrack Pro — Shank Mapping Documentation', 0)
doc.add_paragraph('Generated 2026-11-05 from the maintained Markdown guides. Source code/tests remain authoritative; this export is not production certification.')
for line in markdown.splitlines():
    s = line.strip()
    if not s or s.startswith('<!--') or s.startswith('```'):
        continue
    if s.startswith('# '): doc.add_heading(s[2:], level=1)
    elif s.startswith('## '): doc.add_heading(s[3:], level=2)
    elif s.startswith('### '): doc.add_heading(s[4:], level=3)
    elif s.startswith('- '): doc.add_paragraph(s[2:], style='List Bullet')
    elif s.startswith('> '): doc.add_paragraph(s[2:], style='Quote')
    elif s.startswith('|'): doc.add_paragraph(s.replace('|', '  ').strip(), style='Caption')
    else: doc.add_paragraph(s)
for section in doc.sections:
    section.top_margin = Inches(.7); section.bottom_margin = Inches(.7)
    section.left_margin = Inches(.75); section.right_margin = Inches(.75)
doc.styles['Normal'].font.name = 'Arial'
doc.styles['Normal'].font.size = Pt(9)
doc.save(OUT / 'StoreTrackPro_Shank_Mapping_Documentation.docx')
subprocess.run(['manus-md-to-pdf', str(tmp), str(OUT / 'StoreTrackPro_Shank_Mapping_Documentation.pdf')], check=True)
print('Generated current DOCX and PDF Shank Mapping exports.')