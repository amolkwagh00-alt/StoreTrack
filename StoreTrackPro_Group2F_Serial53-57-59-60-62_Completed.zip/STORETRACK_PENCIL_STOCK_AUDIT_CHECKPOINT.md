# StoreTrack Pro Stock Mapping Audit — Verification Checkpoint

## Project and safety boundary

- Project root: `/home/ubuntu/work/storetrack_project`
- Version: StoreTrack Pro `5.0.0`
- Uploaded source archive: `/home/ubuntu/upload/StoreTrack-stock-receive-allocation-fixed(1).zip`
- Pristine pre-edit copy: `/home/ubuntu/work/storetrack_project-pristine.tar.gz`
- Database implementation: IndexedDB stores and transaction helpers in `modules/database.js`.
- Work was confined to the isolated extracted project. No production database, real stock rows, deployed Electron installation, or user backup file was opened or changed. New persistence/restore tests use fake IndexedDB and isolated fixture records. The backup bridge is an in-memory test adapter, not the Windows/Electron filesystem bridge.
- The uploaded archive remains untouched; the source folder is not a Git checkout.

## Fixes and findings

### Pencil stock migration and Undo

**FIXED.** `migratePencilPartStock()` now prepares cloned stock, allocation-batch, transaction, replacement, and order updates first. It persists old-row deletions and all related writes through one `dPutMany()` IndexedDB read-write transaction spanning the affected stores. In-memory state changes only after that transaction commits. If it rejects or aborts, migration state remains unchanged.

The migration keeps affected allocation batches Undo-capable by rebinding migrated allocations to the target stock row/bin, combining allocations that converge on the same bin, and updating the batch's quantity snapshot. Historical transaction quantity snapshots remain unchanged; the old bin is retained as `metadata.migratedFromBinId` while the transaction's current bin reference is updated.

`dPutMany()` now supports keyed delete operations (`{store, operation: 'delete', key}`) alongside puts in its existing atomic multi-store transaction. A fake-IndexedDB regression queues a delete and then induces a later cross-store write failure; it verifies the deleted record survives the transaction abort.

### Pencil common-stock display (`06-0519/215`)

**FIXED IN CODE.** The user confirmed `06-0519/215` is a Pencil Shank. The screenshot's `Adaptor` label is not authoritative for physical stock classification; the existing Pencil-number rule correctly routes the five-unit receipt to `PENCIL-BIN-19`. The requested behavior is now implemented as a read-only display projection: the Pencil Bin row remains Qty 5, and each mapped station/Common Bin row also displays Qty 5 with the comment `Qty 5 is held in PENCIL-BIN-19`. Stock Control and Excel/PDF exports use the same projection. No duplicate stock rows or extra physical balances are persisted; `ensureStockRecord()` also prevents new zero Common Bin records for Pencil parts. A behavioral regression verifies Pencil-bin allocation, the ECA projection and comment, and that shared displayed quantity does not create a stock write.

The five units already posted to `PENCIL-BIN-19` are correctly located; **do not undo or re-receive them**. The isolated code change did not access or mutate the live database.

### Direct Zero Stock access

**IMPLEMENTED.** A `Zero Stock List` item is directly below Stock Control in the Shank Mapping side menu. The page shows a part-level stock-status table with Station/Location, Bin ID/Location, Available Qty, Required Qty, Shortage, and Status. Its default Status filter is `ZERO STOCK`; users can select/type `BELOW REQUIRED QTY` or `OK` to view those parts, or clear the filter to show all categories. Required Qty follows the Required Quantity screen's mapping occurrence minimum (falling back to configured minimum where the part has no mapped requirement). Manual text and dropdown suggestions are available for Part No., Station, Bin, Component Type, and Status. Bin text search accepts partial manual input, and Excel/PDF exports respect the active filters and include Required Qty/Shortage. The Zero Stock Parts Dashboard card opens this same page.

### Mapping UI, quantity/consumption reports, and RH/LH display

Behavioral tests execute the actual mapping edit dialog and edit function with a Pencil-part fixture. The mapping changes while its stock quantity remains unchanged; the confirmation impact text states that the mapping edit does not modify quantity.

The Required Quantity screen is rendered from the actual function using a fixture with three occurrences across RH/LH stations. The test checks occurrence/minimum quantity `3`, maximum quantity `6`, and both station labels. Actual analytics aggregation functions are also exercised against receive, replacement, manual usage, and historical-consumption fixture records, with expected totals checked independently.

The actual RH/LH merge function is exercised for `ECA 20 RH` and `ECA 20 LH`. The two mapping identities remain distinct, both point to the shared `ECA 20 RH/LH` bin, the bin is displayed as `ECA 20 RH/LH Common Bin`, and the part balances remain separate and conserved.

### Backup/restore

The actual complete-backup module is exercised through backup creation, safety-backup creation, preview/confirmation, and restore against fake IndexedDB. The round trip verifies operational part, stock, and mapping data is restored and local user accounts are preserved/excluded. This is an application-flow end-to-end test with an in-memory bridge; it does **not** prove deployed Windows/Electron file I/O, encryption bridge behavior, or restore on a second physical PC.

## Verification commands and results

- `npm ci --ignore-scripts --no-audit --no-fund` — completed successfully in the isolated working copy.
- `npm test -- --runInBand tests/pencilBinRegression.test.js tests/database.test.js` — **2 suites / 29 tests passed**, including Pencil migration/Undo and real fake-IndexedDB transaction-abort rollback.
- `npm test -- --runInBand tests/pencilBinRegression.test.js tests/stockManagementBehavior.test.js` — **2 suites / 14 tests passed**, including correct Pencil-bin allocation, the station-row shared-quantity projection/location comment, and prevention of new zero Common Bin rows for Pencil parts.
- `npm test -- --runInBand tests/componentManagement.test.js tests/stockManagementBehavior.test.js` — **2 suites / 117 tests passed**, including actual Zero Stock rendering and Zero/Below Required/OK calculations from total on-hand quantities.
- `npm test -- --runInBand` — **42 suites / 419 tests passed**, exit code 0. Jest logged expected simulated-failure output from failure-injection tests; no suite failed.
- ESLint over the updated component module and regressions — **0 errors, 38 warnings**. Warnings are existing project style/unused-variable issues in the long component module; the updated test files have no reported errors.
- Regenerate and validate the ZIP archive after the Required Qty / OK status enhancement.

## Remaining boundaries

- **NEEDS REAL-ENVIRONMENT VERIFICATION:** run the mapping and RH/LH flows in the deployed app with a disposable IndexedDB profile, and verify physical UI interactions/rendering beyond the jsdom behavioral harness.
- Confirm the direct Zero Stock sidebar option, all three status categories, Required Qty comparisons, manual/dropdown searches, and filtered exports in the deployed app; no live database was available to inspect.
- **NEEDS REAL BACKUP DRILL:** exercise the packaged Windows/Electron bridge, encrypted file creation/read, safety backup, restore, and—if relevant—cross-PC portable restore using disposable test data. Do not use a production backup for this test.
- Confirm with the domain owner that migrated transaction `binId` should represent the current bin while the original is recorded in metadata; the implementation preserves quantity snapshots and provenance, but reporting semantics should be confirmed.

## Modified files

- `modules/componentManagement.js` — atomic Pencil migration, read-only shared Pencil-bin quantity projection/location note, prevention of zero Common Bin stock records for Pencil parts, and stock-status list with Zero/Below Required/OK, Required Qty, shortage, filters, and exports.
- `index.html` — direct Zero Stock List item in the Shank Mapping side menu.
- `modules/database.js` — extends `dPutMany()` with keyed deletes within the same multi-store transaction.
- `tests/pencilBinRegression.test.js` — behavioral migration, allocation Undo, and failed-persistence state invariance.
- `tests/database.test.js` — fake-IndexedDB rollback of a queued delete when a later store write aborts.
- `tests/stockManagementBehavior.test.js` — mapping UI invariant, report totals, ECA 20 RH/LH merge/display, Pencil-bin allocation, projected station quantity/location comment, and prevention of station-row stock writes.
- `tests/componentManagement.test.js` and `tests/shankMappingEnhancements.test.js` — direct Zero Stock navigation, actual table rendering, search/export controls, and manual partial-bin filtering.
- `tests/backupRestore.runtime.test.js` — isolated complete backup/restore flow and local-account preservation.

## Resume point

The full suite passed. Regenerate `/home/ubuntu/work/StoreTrack-stock-receive-allocation-verified.zip` with all modified files and this checkpoint (excluding `node_modules`), then validate it. The five units in `PENCIL-BIN-19` are correct; do not undo or re-receive them. Confirm the shared Pencil quantity display and all Zero/Below Required/OK categories in the deployed app, and continue with the explicitly identified backup bridge drill only on disposable test data.
