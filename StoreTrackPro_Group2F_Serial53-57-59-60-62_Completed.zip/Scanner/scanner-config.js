'use strict';
// ── scanner/scanner-config.js ─────────────────────────────────────────────────
// Scanner configuration read/write helper.
// Config file: StoreTrackData/scanner-config.json
// Config shape:
// {
//   scannerMode: "hid" | "serial",
//   hid: { inScanner: "<device_path>", outScanner: "<device_path>" },
//   serial: { inPort: "COM3", outPort: "COM4", baudRate: 9600 }
// }

const fs = require('fs');

const DEFAULT_CONFIG = {
  scannerMode: 'hid',
  hid:    { inScanner: null, outScanner: null },
  serial: { inPort: null, outPort: null, baudRate: 9600 },
};

class ScannerConfig {
  constructor(filePath) {
    this.filePath = filePath;
    this.data     = { ...DEFAULT_CONFIG };
    this._load();
  }

  _load() {
    try {
      const raw  = fs.readFileSync(this.filePath, 'utf8');
      const parsed = JSON.parse(raw);
      // Deep merge to fill any missing keys from older config versions
      this.data = {
        ...DEFAULT_CONFIG,
        ...parsed,
        hid:    { ...DEFAULT_CONFIG.hid,    ...(parsed.hid    || {}) },
        serial: { ...DEFAULT_CONFIG.serial, ...(parsed.serial || {}) },
      };
    } catch (_) {
      this.data = { ...DEFAULT_CONFIG, hid: { ...DEFAULT_CONFIG.hid }, serial: { ...DEFAULT_CONFIG.serial } };
    }
  }

  reload() { this._load(); return this.data; }

  get()    { return this.data; }

  save(partial) {
    // Deep merge incoming partial config
    if (partial.hid)    {this.data.hid    = { ...this.data.hid,    ...partial.hid };}
    if (partial.serial) {this.data.serial = { ...this.data.serial, ...partial.serial };}
    if (partial.scannerMode !== undefined) {this.data.scannerMode = partial.scannerMode;}
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2), 'utf8');
      return true;
    } catch (err) {
      console.error('[ScannerConfig] save error:', err.message);
      return false;
    }
  }

  reset() {
    this.data = { ...DEFAULT_CONFIG, hid: { ...DEFAULT_CONFIG.hid }, serial: { ...DEFAULT_CONFIG.serial } };
    // FIX: Write the reset data directly instead of calling save({}) which merges nothing
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2), 'utf8');
      return true;
    } catch (err) {
      console.error('[ScannerConfig] reset error:', err.message);
      return false;
    }
  }
}

module.exports = ScannerConfig;
