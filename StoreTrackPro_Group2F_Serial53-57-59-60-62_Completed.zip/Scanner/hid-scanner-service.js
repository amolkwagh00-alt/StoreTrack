'use strict';
// ── scanner/hid-scanner-service.js ───────────────────────────────────────────
// node-hid based scanner service.
// Listens on raw HID interface of both Zebra scanners.
// Emits 'scan' events on the shared scanner event bus.

const fs        = require('fs');
const eventBus  = require('./scanner-events');

// HID USB keycode → ASCII (US layout)
const KEY_MAP = {
  0x04:'a',0x05:'b',0x06:'c',0x07:'d',0x08:'e',0x09:'f',0x0A:'g',0x0B:'h',
  0x0C:'i',0x0D:'j',0x0E:'k',0x0F:'l',0x10:'m',0x11:'n',0x12:'o',0x13:'p',
  0x14:'q',0x15:'r',0x16:'s',0x17:'t',0x18:'u',0x19:'v',0x1A:'w',0x1B:'x',
  0x1C:'y',0x1D:'z',
  0x1E:'1',0x1F:'2',0x20:'3',0x21:'4',0x22:'5',
  0x23:'6',0x24:'7',0x25:'8',0x26:'9',0x27:'0',
  0x28:'\n',0x2D:'-',0x2E:'.',0x2F:'[',0x30:']',
  0x31:'\\',0x33:';',0x34:"'",0x36:',',0x37:'.',
};
const SHIFT_MAP = {
  0x1E:'!',0x1F:'@',0x20:'#',0x21:'$',0x22:'%',
  0x23:'^',0x24:'&',0x25:'*',0x26:'(',0x27:')',
};
const BARCODE_TIMEOUT_MS = 200; // FIX: 100ms was too tight on loaded systems; 200ms is safer

class HIDScannerService {
  constructor(logPath) {
    this.logPath  = logPath;
    this._HID     = null;
    this.devices  = { in: null, out: null };   // open HID.HID handles
    this.buffers  = { in: '',   out: ''   };
    this.timers   = { in: null, out: null };
    this.paths    = { in: null, out: null };    // configured device paths
    this._running = false;
  }

  _loadHID() {
    if (this._HID) {return this._HID;}
    try {
      this._HID = require('node-hid');
      return this._HID;
    } catch (e) {
      this._log('node-hid not available: ' + e.message);
      return null;
    }
  }

  _log(msg) {
    const line = `[${new Date().toISOString()}] [HID] ${msg}\n`;
    try { fs.appendFileSync(this.logPath, line); } catch (_) {}
    console.log('[HIDScanner]', msg);
  }

  listDevices() {
    const HID = this._loadHID();
    if (!HID) {return [];}
    try {
      return HID.devices().map(d => ({
        path:         d.path         || '',
        vendorId:     d.vendorId     || 0,
        productId:    d.productId    || 0,
        product:      d.product      || 'Unknown',
        manufacturer: d.manufacturer || '',
        serialNumber: d.serialNumber || '',
        usagePage:    d.usagePage,
        usage:        d.usage,
      }));
    } catch (err) {
      this._log('listDevices error: ' + err.message);
      return [];
    }
  }

  _closeRole(role) {
    if (this.devices[role]) {
      try { this.devices[role].removeAllListeners(); this.devices[role].close(); } catch (_) {}
      this.devices[role] = null;
    }
    if (this.timers[role]) { clearTimeout(this.timers[role]); this.timers[role] = null; }
    this.buffers[role] = '';
  }

  _openRole(devicePath, role) {
    const HID = this._loadHID();
    if (!HID || !devicePath) {return false;}
    this._closeRole(role);
    try {
      const dev = new HID.HID(devicePath);
      this.devices[role] = dev;

      dev.on('data', (data) => this._onData(data, role));
      dev.on('error', (err) => {
        this._log(`Device error [${role}]: ${err.message}`);
        eventBus.emit('scanner:deviceError', { role, error: err.message, mode: 'hid' });
        // Auto-reconnect after 2 seconds
        if (this._running) {
          setTimeout(() => {
            if (this._running) {this._openRole(devicePath, role);}
          }, 2000);
        }
      });
      this._log(`Opened ${role} HID device: ${devicePath}`);
      return true;
    } catch (err) {
      this._log(`Failed to open ${role} HID device at "${devicePath}": ${err.message}`);
      return false;
    }
  }

  _onData(data, role) {
    const modifier = data[0];
    const keycode  = data[2];
    if (keycode === 0) {return;} // key release

    let ch = null;
    if (modifier & 0x02 || modifier & 0x20) {
      ch = SHIFT_MAP[keycode] || (KEY_MAP[keycode] ? KEY_MAP[keycode].toUpperCase() : null);
    } else {
      ch = KEY_MAP[keycode] || null;
    }

    if (ch === '\n') {
      const barcode = this.buffers[role].trim();
      this.buffers[role] = '';
      if (this.timers[role]) { clearTimeout(this.timers[role]); this.timers[role] = null; }
      if (barcode.length > 0) {
        this._log(`Scan [${role}]: ${barcode}`);
        eventBus.emit('scanner:scan', { role, barcode, mode: 'hid' });
      }
    } else if (ch) {
      this.buffers[role] += ch;
      if (this.timers[role]) {clearTimeout(this.timers[role]);}
      this.timers[role] = setTimeout(() => {
        const barcode = this.buffers[role].trim();
        this.buffers[role] = '';
        if (barcode.length > 0) {
          this._log(`Scan [${role}] (timeout flush): ${barcode}`);
          eventBus.emit('scanner:scan', { role, barcode, mode: 'hid' });
        }
      }, BARCODE_TIMEOUT_MS);
    }
  }

  start(inPath, outPath) {
    this._running = true;
    this.paths = { in: inPath || null, out: outPath || null };
    if (inPath)  {this._openRole(inPath,  'in');}  else {this._log('IN scanner path not set');}
    if (outPath) {this._openRole(outPath, 'out');} else {this._log('OUT scanner path not set');}
    this._log(`HID service started. IN=${inPath||'not set'}, OUT=${outPath||'not set'}`);
  }

  stop() {
    this._running = false;
    this._closeRole('in');
    this._closeRole('out');
    this._log('HID service stopped');
  }

  // Enrollment: open all HID devices at once and capture first scan received
  // Returns Promise<{ devicePath, deviceInfo, barcode }>
  enrollNextScan(timeoutMs = 15000) {
    const HID = this._loadHID();
    if (!HID) {return Promise.reject(new Error('node-hid is not available on this system'));}

    return new Promise((resolve, reject) => {
      const handles  = [];
      const bufs     = {};
      let   settled  = false;

      const cleanup = () => {
        handles.forEach(({ dev }) => {
          try { dev.removeAllListeners(); dev.close(); } catch (_) {}
        });
        Object.values(bufs).forEach(b => { if (b._t) {clearTimeout(b._t);} });
      };

      const done = (result) => {
        if (settled) {return;}
        settled = true;
        clearTimeout(tout);
        cleanup();
        resolve(result);
      };

      const tout = setTimeout(() => {
        if (settled) {return;}
        settled = true;
        cleanup();
        reject(new Error(
          'Enrollment timeout — no scan received in ' + Math.round(timeoutMs / 1000) + ' seconds. ' +
          'Make sure the scanner is in HID mode and plugged in.'
        ));
      }, timeoutMs);

      let devList;
      try { devList = HID.devices(); } catch (e) {
        clearTimeout(tout);
        return reject(new Error('HID.devices() failed: ' + e.message));
      }

      devList.forEach(devInfo => {
        try {
          const dev = new HID.HID(devInfo.path);
          bufs[devInfo.path] = { val: '', _t: null };
          handles.push({ dev, info: devInfo });

          dev.on('data', (data) => {
            const buf = bufs[devInfo.path];
            if (!buf) {return;}
            const mod = data[0], kc = data[2];
            if (kc === 0) {return;}
            let ch = null;
            if (mod & 0x02 || mod & 0x20) {
              ch = SHIFT_MAP[kc] || (KEY_MAP[kc] ? KEY_MAP[kc].toUpperCase() : null);
            } else { ch = KEY_MAP[kc] || null; }

            if (ch === '\n') {
              const bc = buf.val.trim(); buf.val = '';
              if (bc.length > 0) {done({ devicePath: devInfo.path, deviceInfo: devInfo, barcode: bc });}
            } else if (ch) {
              buf.val += ch;
              if (buf._t) {clearTimeout(buf._t);}
              buf._t = setTimeout(() => {
                const bc2 = buf.val.trim(); buf.val = '';
                if (bc2.length > 0) {done({ devicePath: devInfo.path, deviceInfo: devInfo, barcode: bc2 });}
              }, BARCODE_TIMEOUT_MS);
            }
          });
          dev.on('error', () => {});
        } catch (_) {}
      });

      if (handles.length === 0) {
        clearTimeout(tout);
        reject(new Error('No HID devices found. Check if scanners are connected.'));
      }
    });
  }
}

module.exports = HIDScannerService;
