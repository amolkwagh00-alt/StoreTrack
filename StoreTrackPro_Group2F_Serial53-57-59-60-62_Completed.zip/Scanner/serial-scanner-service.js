'use strict';
// ── scanner/serial-scanner-service.js ────────────────────────────────────────
// SerialPort-based scanner service.
// Use when scanners are in COM/Serial mode.
// Emits 'scan' events on the shared scanner event bus.

const fs       = require('fs');
const eventBus = require('./scanner-events');

class SerialScannerService {
  constructor(logPath) {
    this.logPath  = logPath;
    this._SP      = null;    // lazy-loaded serialport module
    this.ports    = { in: null, out: null };   // open SerialPort instances
    this.buffers  = { in: '',   out: '' };
    this.comPorts = { in: null, out: null };   // configured COM port names
    this._running = false;
  }

  _loadSP() {
    if (this._SP) {return this._SP;}
    try {
      // serialport v10+ exports { SerialPort, ReadlineParser }
      const sp = require('serialport');
      this._SP = sp;
      return sp;
    } catch (e) {
      this._log('serialport not available: ' + e.message);
      return null;
    }
  }

  _log(msg) {
    const line = `[${new Date().toISOString()}] [Serial] ${msg}\n`;
    try { fs.appendFileSync(this.logPath, line); } catch (_) {}
    console.log('[SerialScanner]', msg);
  }

  // List available COM ports
  async listPorts() {
    const sp = this._loadSP();
    if (!sp) {return [];}
    try {
      const list = await sp.SerialPort.list();
      return list.map(p => ({
        path:         p.path,
        manufacturer: p.manufacturer || '',
        serialNumber: p.serialNumber || '',
        vendorId:     p.vendorId     || '',
        productId:    p.productId    || '',
        friendlyName: p.friendlyName || p.path,
      }));
    } catch (err) {
      this._log('listPorts error: ' + err.message);
      return [];
    }
  }

  _closeRole(role) {
    if (this.ports[role]) {
      try { this.ports[role].removeAllListeners(); if (this.ports[role].isOpen) {this.ports[role].close();} } catch (_) {}
      this.ports[role] = null;
    }
    this.buffers[role] = '';
  }

  _openRole(comPort, role, baudRate) {
    const sp = this._loadSP();
    if (!sp || !comPort) {return false;}
    this._closeRole(role);
    try {
      const port = new sp.SerialPort({
        path:     comPort,
        baudRate: baudRate || 9600,
        autoOpen: false,
      });

      // FIX: Most Zebra scanners in serial mode send only CR (\r), not CRLF.
      // ReadlineParser with '\r\n' would buffer forever. Use '\r' delimiter instead,
      // and trim() handles any stray '\n' characters.
      const parser = port.pipe(new sp.ReadlineParser({ delimiter: '\r' }));

      parser.on('data', (line) => {
        const barcode = String(line).trim();
        if (barcode.length > 0) {
          this._log(`Scan [${role}] via ${comPort}: ${barcode}`);
          eventBus.emit('scanner:scan', { role, barcode, mode: 'serial' });
        }
      });

      port.on('error', (err) => {
        this._log(`Port error [${role}] ${comPort}: ${err.message}`);
        eventBus.emit('scanner:deviceError', { role, error: err.message, mode: 'serial' });
        if (this._running) {
          setTimeout(() => {
            if (this._running) {this._openRole(comPort, role, baudRate);}
          }, 3000);
        }
      });

      port.on('close', () => {
        this._log(`Port closed [${role}] ${comPort}`);
        if (this._running) {
          setTimeout(() => {
            if (this._running) {this._openRole(comPort, role, baudRate);}
          }, 3000);
        }
      });

      port.open((err) => {
        if (err) {
          this._log(`Failed to open ${comPort} for [${role}]: ${err.message}`);
          eventBus.emit('scanner:deviceError', { role, error: err.message, mode: 'serial' });
        } else {
          this._log(`Opened ${role} serial port: ${comPort} @ ${baudRate||9600} baud`);
        }
      });

      this.ports[role] = port;
      return true;
    } catch (err) {
      this._log(`_openRole error [${role}]: ${err.message}`);
      return false;
    }
  }

  start(inPort, outPort, baudRate) {
    this._running = true;
    this.comPorts = { in: inPort || null, out: outPort || null };
    const baud = baudRate || 9600;
    if (inPort)  {this._openRole(inPort,  'in',  baud);} else {this._log('IN COM port not configured');}
    if (outPort) {this._openRole(outPort, 'out', baud);} else {this._log('OUT COM port not configured');}
    this._log(`Serial service started. IN=${inPort||'not set'}, OUT=${outPort||'not set'}`);
  }

  stop() {
    this._running = false;
    this._closeRole('in');
    this._closeRole('out');
    this._log('Serial service stopped');
  }
}

module.exports = SerialScannerService;
