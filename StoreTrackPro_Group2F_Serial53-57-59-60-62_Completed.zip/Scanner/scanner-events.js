'use strict';
// ── scanner/scanner-events.js ─────────────────────────────────────────────────
// Shared EventEmitter singleton for scanner events.
// All scanner services (HID, Serial) emit via this bus.
// scanner-manager.js and background-processor consume events from here.

const { EventEmitter } = require('events');

class ScannerEventBus extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(50); // FIX: 20 was too low with multiple services + renderer forwarding
  }
}

// Singleton — one bus for the entire main process
const bus = new ScannerEventBus();

module.exports = bus;
