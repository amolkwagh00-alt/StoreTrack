'use strict';
// ── scanner/scanner-manager.js ────────────────────────────────────────────────
// Orchestrates HID and Serial scanner services based on config.
// Exposes a clean API to main.js:
//   start(), stop(), getMode(), setMode(), enrollHID(), listHIDDevices(), listSerialPorts()

const fs                  = require('fs');
const ScannerConfig       = require('./scanner-config');
const HIDScannerService   = require('./hid-scanner-service');
const SerialScannerService= require('./serial-scanner-service');
const eventBus            = require('./scanner-events');

class ScannerManager {
  constructor(configPath, logPath) {
    this.config  = new ScannerConfig(configPath);
    this.logPath = logPath;
    this.hidSvc  = new HIDScannerService(logPath);
    this.serSvc  = new SerialScannerService(logPath);
    this._active = null; // 'hid' | 'serial' | null
  }

  _log(msg) {
    const line = `[${new Date().toISOString()}] [Manager] ${msg}\n`;
    try { fs.appendFileSync(this.logPath, line); } catch (_) {}
    console.log('[ScannerManager]', msg);
  }

  start() {
    const cfg  = this.config.get();
    const mode = cfg.scannerMode || 'hid';
    this._log(`Starting in mode: ${mode}`);

    this.stop(); // stop any running services first

    if (mode === 'hid') {
      this.hidSvc.start(cfg.hid.inScanner, cfg.hid.outScanner);
      this._active = 'hid';
    } else if (mode === 'serial') {
      this.serSvc.start(cfg.serial.inPort, cfg.serial.outPort, cfg.serial.baudRate);
      this._active = 'serial';
    }
  }

  stop() {
    try { this.hidSvc.stop(); } catch (_) {}
    try { this.serSvc.stop(); } catch (_) {}
    this._active = null;
  }

  getMode()  { return this._active; }
  getConfig(){ return this.config.get(); }

  // Save config and hot-restart the appropriate service
  applyConfig(partial) {
    this.config.save(partial);
    this.stop();
    this.start();
    return this.config.get();
  }

  resetConfig() {
    this.stop();
    this.config.reset();
    return this.config.get();
  }

  // ── HID-specific ────────────────────────────────────────────────────────────
  listHIDDevices() { return this.hidSvc.listDevices(); }

  // Enrollment: stop HID service, wait for next scan, save device path, restart
  async enrollHID(role, timeoutMs = 15000) {
    // FIX: Mutex guard — prevent concurrent enrollments from racing on device handles
    if (this._enrolling) {throw new Error('Enrollment already in progress');}
    this._enrolling = true;

    this._log(`Starting HID enrollment for role: ${role}`);
      // Stop current HID service to free device handles
      this.hidSvc.stop();

      let result;
      try {
        result = await this.hidSvc.enrollNextScan(timeoutMs);
      } catch (err) {
        // Restart even if enrollment fails
        this._enrolling = false;
        this.start();
        throw err;
      }

      // Save enrolled device path
      const key = role === 'in' ? 'inScanner' : 'outScanner';
      this.config.save({ hid: { [key]: result.devicePath } });
      this._log(`Enrolled [${role}] → ${result.devicePath}`);

      // Restart scanner service with updated config
      this._enrolling = false;
      this.start();

    return {
      devicePath: result.devicePath,
      deviceInfo: result.deviceInfo,
      barcode:    result.barcode,
    };
  }

  // ── Serial-specific ──────────────────────────────────────────────────────────
  listSerialPorts() { return this.serSvc.listPorts(); }

  // Expose event bus so main.js can subscribe
  get events() { return eventBus; }
}

module.exports = ScannerManager;
