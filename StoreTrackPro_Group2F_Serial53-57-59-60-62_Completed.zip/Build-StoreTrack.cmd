@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title StoreTrack - Automated Tests and Build
echo.
echo ================================================
echo StoreTrack - Automated Tests and Windows Build
echo ================================================
echo.
if not exist "package.json" (
  echo ERROR: package.json was not found.
  echo Extract this ZIP and run this CMD from the StoreTrack project root.
  goto :failed
)
where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js is not installed or is not on PATH.
  echo Install Node.js LTS, reopen Windows, and run this CMD again.
  goto :failed
)
where npm >nul 2>&1
if errorlevel 1 (
  echo ERROR: npm is not installed or is not on PATH.
  goto :failed
)
echo [1/9] Installing project dependencies...
call npm ci --no-audit --no-fund
if errorlevel 1 goto :failed
echo.
echo [2/9] Installing Playwright Chromium if needed...
call npx playwright install chromium
if errorlevel 1 goto :failed
echo.
echo [3/9] Running Jest tests...
call npm test
if errorlevel 1 goto :failed
echo.
echo [4/9] Running Playwright end-to-end tests...
call npm run test:e2e
if errorlevel 1 goto :failed
echo.
echo [5/9] Running smoke tests...
call npm run test:smoke
if errorlevel 1 goto :failed
echo.
echo [6/9] Running offline tests...
call npm run test:offline
if errorlevel 1 goto :failed
echo.
echo [7/9] Running lint...
call npm run lint
if errorlevel 1 goto :failed
echo.
echo [8/9] Running production and release validation...
call npm run production:validate
if errorlevel 1 goto :failed
call npm run release:check
if errorlevel 1 goto :failed
echo.
echo [9/9] Building the Windows installer and deployment guide...
call npm run build
if errorlevel 1 goto :failed
echo.
echo SUCCESS: Tests and checks passed.
echo The installer and deployment guide are under the dist folder.
echo.
pause
exit /b 0

:failed
echo.
echo FAILED: A command returned an error. Read the output above, fix the issue, and run this CMD again.
echo.
pause
exit /b 1
