// Service Worker for Offline Support with Advanced Caching Strategies

const CACHE_VERSION = 'v3';
const STATIC_CACHE_NAME = `storetrack-static-${CACHE_VERSION}`;
const DYNAMIC_CACHE_NAME = `storetrack-dynamic-${CACHE_VERSION}`;
const API_CACHE_NAME = `storetrack-api-${CACHE_VERSION}`;
const IMAGE_CACHE_NAME = `storetrack-images-${CACHE_VERSION}`;

// Cache strategies configuration
const CACHE_STRATEGIES = {
  static: {
    cacheName: STATIC_CACHE_NAME,
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
    maxEntries: 100
  },
  dynamic: {
    cacheName: DYNAMIC_CACHE_NAME,
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    maxEntries: 50
  },
  api: {
    cacheName: API_CACHE_NAME,
    maxAge: 5 * 60 * 1000, // 5 minutes
    maxEntries: 100
  },
  images: {
    cacheName: IMAGE_CACHE_NAME,
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    maxEntries: 200
  }
};

const STATIC_CACHE = [
  './',
  './index.html',
  './styles.css',
  './css/responsive.css',
  './app.js',
  './main.js',
  './preload.js',
  './manifest.json',
  './modules/database.js',
  './modules/utilities.js',
  './modules/encryption.js',
  './modules/printing.js',
  './modules/auth.js',
  './modules/pm.js',
  './modules/msp.js',
  './modules/centralSync.js',
  './modules/moduleLoader.js'
];

// Install service worker and cache static assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE_NAME)
      .then((cache) => {
        const supportedAssets = STATIC_CACHE.filter(asset => {
          try {
            return new URL(asset, self.location.href).protocol !== 'file:';
          } catch {
            return false;
          }
        });
        return supportedAssets.length ? cache.addAll(supportedAssets) : undefined;
      })
      .then(() => self.skipWaiting())
  );
});

// Activate service worker and clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames
            .filter((name) => name !== STATIC_CACHE_NAME && 
                           name !== DYNAMIC_CACHE_NAME &&
                           name !== API_CACHE_NAME &&
                           name !== IMAGE_CACHE_NAME)
            .map((name) => caches.delete(name))
        );
      })
      .then(() => self.clients.claim())
  );
});

// Fetch requests with multiple caching strategies
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // Skip non-GET requests
  if (event.request.method !== 'GET') {return;}
  
  // Skip Electron bridge calls
  if (url.protocol === 'file:') {return;}

  // API responses may be user-specific. Never cache them by URL alone: an
  // offline request after logout/account switching must not receive another
  // user's previously cached inventory or sync payload.
  if (url.pathname.includes('/api/')) {
    event.respondWith(fetch(event.request));
    return;
  }
  
  // Determine caching strategy based on request type
  const strategy = determineCacheStrategy(event.request, url);
  
  event.respondWith(handleRequest(event.request, strategy));
});

/**
 * Determine appropriate caching strategy
 */
function determineCacheStrategy(request, url) {
  // Static assets - cache first
  if (STATIC_CACHE.some(path => {
    try { return new URL(path, self.location.href).pathname === url.pathname; }
    catch (_) { return false; }
  })) {
    return 'cacheFirst';
  }
  
  // Images - cache first with long expiration
  if (request.destination === 'image') {
    return 'cacheFirstImages';
  }
  
  // API calls - network first with short cache
  if (url.pathname.includes('/api/')) {
    return 'networkFirst';
  }
  
  // HTML documents - network first, fallback to cache
  if (request.destination === 'document') {
    return 'networkFirst';
  }
  
  // Default - stale while revalidate
  return 'staleWhileRevalidate';
}

/**
 * Handle request with specified strategy
 */
async function handleRequest(request, strategy) {
  switch (strategy) {
    case 'cacheFirst':
      return cacheFirst(request, CACHE_STRATEGIES.static);
    
    case 'cacheFirstImages':
      return cacheFirst(request, CACHE_STRATEGIES.images);
    
    case 'networkFirst':
      return networkFirst(request, CACHE_STRATEGIES.api);
    
    case 'staleWhileRevalidate':
      return staleWhileRevalidate(request, CACHE_STRATEGIES.dynamic);
    
    default:
      return networkFirst(request, CACHE_STRATEGIES.dynamic);
  }
}

/**
 * Cache First Strategy
 * Serve from cache, fallback to network
 */
async function cacheFirst(request, cacheConfig) {
  const cache = await caches.open(cacheConfig.cacheName);
  const cached = await cache.match(request);
  
  if (cached) {
    return cached;
  }
  
  const response = await fetch(request);
  if (response.ok) {
    await cache.put(request, response.clone());
  }
  
  return response;
}

/**
 * Network First Strategy
 * Try network first, fallback to cache
 */
async function networkFirst(request, cacheConfig) {
  const cache = await caches.open(cacheConfig.cacheName);
  
  try {
    const response = await fetch(request);
    
    if (response.ok) {
      await cache.put(request, response.clone());
    }
    
    return response;
  } catch (error) {
    const cached = await cache.match(request);
    if (cached) {
      return cached;
    }
    
    // Return offline fallback for documents
    if (request.destination === 'document') {
      return caches.match('./index.html');
    }
    
    throw error;
  }
}

/**
 * Stale While Revalidate Strategy
 * Serve from cache, update in background
 */
async function staleWhileRevalidate(request, cacheConfig) {
  const cache = await caches.open(cacheConfig.cacheName);
  const cached = await cache.match(request);
  
  // Fetch in background
  const fetchPromise = fetch(request).then(response => {
    if (response.ok) {
      cache.put(request, response.clone());
    }
    return response;
  });
  
  // Return cached version immediately, or wait for network if no cache
  return cached || fetchPromise;
}

// Handle background sync for IndexedDB data
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-data') {
    event.waitUntil(syncData());
  }
});

// Sync data to server when online
async function syncData() {
  // Implementation for syncing IndexedDB data when connection is restored
  // This would integrate with the LAN sync module
}

// Handle push notifications (future enhancement)
self.addEventListener('push', (event) => {
  const options = {
    body: event.data ? event.data.text() : 'StoreTrack Pro Update',
    icon: './assets/icon-192.png',
    badge: './assets/icon-96.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    }
  };
  
  event.waitUntil(
    self.registration.showNotification('StoreTrack Pro', options)
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  event.waitUntil(
    self.clients.openWindow('/')
  );
});
