const assert = require('assert');

// 1. Test JWT secret enforcement
console.log('Testing JWT secret validation...');
try {
  delete process.env.STORETRACK_JWT_SECRET;
  process.env.NODE_ENV = 'production';
  // Re-requiring auth.js should throw when STORETRACK_JWT_SECRET is missing in production
  delete require.cache[require.resolve('../server/auth.js')];
  require('../server/auth.js');
  console.error('FAIL: Expected error when STORETRACK_JWT_SECRET is missing in production');
  process.exit(1);
} catch (err) {
  console.log('PASS: Correctly rejected missing STORETRACK_JWT_SECRET in production:', err.message);
}

try {
  process.env.STORETRACK_JWT_SECRET = 'short';
  process.env.NODE_ENV = 'production';
  delete require.cache[require.resolve('../server/auth.js')];
  require('../server/auth.js');
  console.error('FAIL: Expected error when STORETRACK_JWT_SECRET is too short in production');
  process.exit(1);
} catch (err) {
  console.log('PASS: Correctly rejected short STORETRACK_JWT_SECRET in production:', err.message);
}

try {
  process.env.STORETRACK_JWT_SECRET = 'a'.repeat(32);
  process.env.NODE_ENV = 'production';
  delete require.cache[require.resolve('../server/auth.js')];
  const auth = require('../server/auth.js');
  assert(typeof auth.signToken === 'function');
  console.log('PASS: Successfully initialized with valid 32-char secret in production');
} catch (err) {
  console.error('FAIL:', err);
  process.exit(1);
}

// 2. Test CORS enforcement
console.log('Testing CORS origin enforcement...');
process.env.CORS_ORIGIN = 'https://trusted-store.com';
process.env.NODE_ENV = 'production';
delete require.cache[require.resolve('../server/index.js')];
const serverMod = require('../server/index.js');
console.log('PASS: server/index.js loaded successfully with explicit CORS origin');

console.log('All security verification checks PASSED.');
