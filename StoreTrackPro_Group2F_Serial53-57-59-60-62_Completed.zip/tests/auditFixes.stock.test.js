const fs = require('fs');
const path = require('path');
const database = require('../modules/database.js');

const appSource = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const componentSource = fs.readFileSync(path.join(__dirname, '..', 'modules/componentManagement.js'), 'utf8');

describe('confirmed stock audit regressions', () => {
  beforeAll(async () => { await database.initDB(); });

  test('concurrent read-modify-write deductions serialize and ledger reconciles', async () => {
    const { dClr, dPut, gAll, atomicReadModifyWrite } = database;
    await dClr('materials');
    await dClr('transactions');
    await dPut('materials', { id: 'atomic-mat', stock: 5 });
    const issue = qty => atomicReadModifyWrite('materials', 'atomic-mat', current => {
      if (current.stock < qty) throw new Error('INSUFFICIENT');
      const updated = { ...current, stock: current.stock - qty };
      const ledger = { id: `issue-${qty}-${Math.random()}`, itemId: current.id, type: 'OUT', qty };
      return { record: updated, writes: [{ store: 'transactions', obj: ledger }] };
    });
    const outcomes = await Promise.allSettled([issue(3), issue(3)]);
    expect(outcomes.filter(row => row.status === 'fulfilled')).toHaveLength(1);
    expect((await gAll('materials')).find(row => row.id === 'atomic-mat').stock).toBe(2);
    const ledger = (await gAll('transactions')).filter(row => row.itemId === 'atomic-mat');
    expect(ledger.reduce((sum, row) => sum + row.qty, 0)).toBe(3);
  });

  test('failed derivation leaves stock and ledger untouched', async () => {
    const { dClr, dPut, gAll, atomicReadModifyWrite } = database;
    await dClr('materials');
    await dClr('transactions');
    await dPut('materials', { id: 'rollback-mat', stock: 1 });
    await expect(atomicReadModifyWrite('materials', 'rollback-mat', () => {
      throw new Error('simulated validation failure');
    })).rejects.toThrow('simulated validation failure');
    expect((await gAll('materials')).find(row => row.id === 'rollback-mat').stock).toBe(1);
    expect((await gAll('transactions'))).toHaveLength(0);
  });

  test('atomic mutation preserves configured encryption transforms', async () => {
    const { dClr, dPut, gAll, getDB, atomicReadModifyWrite } = database;
    await dClr('materials');
    const previous = window.DataEncryption;
    window.DataEncryption = { manager: {
      prepareForStorage: async (_store, record) => {
        const result = { ...record, stockCipher: `sealed:${record.stock}` };
        delete result.stock;
        return result;
      },
      restoreFromStorage: async (_store, record) => ({ ...record, stock: Number(String(record.stockCipher).slice(7)) })
    } };
    try {
      await dPut('materials', { id: 'encrypted-mat', stock: 4 });
      const updated = await atomicReadModifyWrite('materials', 'encrypted-mat', current => ({
        record: { ...current, stock: current.stock + 1 }
      }));
      const raw = await new Promise((resolve, reject) => {
        const request = getDB().transaction('materials', 'readonly').objectStore('materials').get('encrypted-mat');
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
      expect(updated.stock).toBe(5);
      expect(raw.stock).toBeUndefined();
      expect(raw.stockCipher).toBe('sealed:5');
      expect((await gAll('materials')).find(row => row.id === 'encrypted-mat').stock).toBe(5);
    } finally { window.DataEncryption = previous; }
  });

  test('guarded concurrent approval commits the stock deduction once', async () => {
    const { dClr, dPut, gAll, atomicReadModifyWrite } = database;
    await dClr('materials');
    await dClr('approvals');
    await dPut('materials', { id: 'approval-mat', stock: 6 });
    await dPut('approvals', { id: 'approval-1', status: 'pending' });
    const approve = () => atomicReadModifyWrite('materials', 'approval-mat', (current, records) => {
      const approval = records.approval;
      if (!approval || approval.status !== 'pending') throw new Error('already processed');
      return {
        record: { ...current, stock: current.stock - 2 },
        writes: [{ store: 'approvals', obj: { ...approval, status: 'approved' } }]
      };
    }, { guards: [{ store: 'approvals', key: 'approval-1', name: 'approval', validate: row => row?.status === 'pending' }] });
    const results = await Promise.allSettled([approve(), approve()]);
    expect(results.filter(result => result.status === 'fulfilled')).toHaveLength(1);
    expect((await gAll('materials')).find(row => row.id === 'approval-mat').stock).toBe(4);
    expect((await gAll('approvals')).find(row => row.id === 'approval-1').status).toBe('approved');
  });

  test('Material IN is not mutated before atomic persistence and preserves transaction IDs for retry', () => {
    expect(appSource).toMatch(/const itemSnapshot=inI;/);
    expect(appSource).toMatch(/window\.__pendingMaterialIn=attempt;/);
    expect(appSource).toMatch(/centralSync\.submit\(attempt\.tx\)/);
    expect(appSource).toMatch(/atomicReadModifyWrite\('materials',itemSnapshot\.id/);
    expect(appSource).toMatch(/inI=committed;window\.__pendingMaterialIn=null;/);
    expect(appSource).not.toMatch(/BOOTSTRAP_CREDENTIALS|Admin@1234|Store@1234/);
  });

  test('fractional Material OUT quantities are explicitly rejected before popup close', () => {
    const validation = appSource.indexOf('if(!Number.isFinite(qty)||!Number.isInteger(qty)||qty<=0)');
    const close = appSource.indexOf("document.getElementById('out-qty-ov').classList.remove('on')", validation);
    expect(validation).toBeGreaterThan(-1);
    expect(close).toBeGreaterThan(validation);
    expect(appSource.slice(validation, close)).toContain("document.getElementById('oqp-qty').focus()");
  });

  test('bulk approval uses the atomically returned material without reassigning its lookup binding', () => {
    const start = appSource.indexOf('async function bulkApproveSelected()');
    const end = appSource.indexOf('async function bulkRejectSelected()', start);
    const bulkApproval = appSource.slice(start, end);
    expect(bulkApproval).toContain('const material=M.find(x=>x.barcode===a.barcode)');
    expect(bulkApproval).toContain('let updatedMaterial;');
    expect(bulkApproval).toContain('updatedMaterial=await window.atomicReadModifyWrite');
    expect(bulkApproval).toContain('if(isLowStockMaterial(updatedMaterial))');
    expect(bulkApproval).not.toMatch(/\bconst\s+m\s*=M\.find[\s\S]*?\bm\s*=await\s+window\.atomicReadModifyWrite/);
  });

  test('Low Stock and natural BI query pass defined filter and period inputs', () => {
    const lowStart = appSource.indexOf('function renderLow()');
    const lowEnd = appSource.indexOf('function lowItems()', lowStart);
    const lowRenderer = appSource.slice(lowStart, lowEnd);
    expect(lowRenderer).toContain("lowStockForSupplier(M,'')");
    expect(lowRenderer).not.toContain('suppFlt');
    const queryStart = componentSource.indexOf('function runShankBINaturalQuery()');
    const queryEnd = componentSource.indexOf('function refreshBISampleOptions()', queryStart);
    const query = componentSource.slice(queryStart, queryEnd);
    expect(query).toContain('procurementRows(days)');
    expect(query).not.toContain('procurementRows(period)');
  });

  test('approval, batch and Shank stock paths use atomic balance read-modify-write', () => {
    expect(appSource).toContain("atomicReadModifyWrite('materials',material.id");
    expect(appSource).toContain("atomicReadModifyWrite('materials',item.id");
    expect(componentSource).toContain('window.atomicReadModifyWrite(STORES.stock, targetId');
    expect(componentSource).toContain("throw new Error('INSUFFICIENT STOCK')");
  });

  test('bootstrap credentials are generated securely, shown in setup UI, and never logged', () => {
    expect(appSource).toContain('window.crypto.getRandomValues(bytes)');
    expect(appSource).toContain('One-time setup credentials');
    expect(appSource).not.toMatch(/console\.(?:log|warn|error)\([^\n]*(?:password|credential|\bp[123]\b)/i);
    expect(appSource).not.toMatch(/BOOTSTRAP_CREDENTIALS|Admin@1234|Store@1234/);
    expect(appSource).toContain('u.mustChangePassword=false');
  });
});
