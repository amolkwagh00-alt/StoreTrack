'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
require('fake-indexeddb/auto');

const root = path.join(__dirname, '..');
const main = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
const renderer = fs.readFileSync(path.join(root, 'modules', 'dataBackup.js'), 'utf8');
function extract(source, name) {
  const asyncStart = source.indexOf(`async function ${name}(`);
  const start = asyncStart >= 0 ? asyncStart : source.indexOf(`function ${name}(`);
  assert.ok(start >= 0, `missing function ${name}`);
  const open = source.indexOf(') {', start) + 2; let depth = 0; let quote = null; let escaped = false;
  for (let i = open; i < source.length; i += 1) {
    const ch = source[i];
    if (quote) { if (escaped) escaped = false; else if (ch === '\\') escaped = true; else if (ch === quote) quote = null; continue; }
    if (["'", '"', '`'].includes(ch)) { quote = ch; continue; }
    if (ch === '{') depth += 1;
    if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`unterminated ${name}`);
}

test('retained backup verification reports authenticated-valid and corrupted files without changing bytes or mtime', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'storetrack-verify-'));
  try {
    const good = path.join(dir, 'StoreTrackPro-backup-2026-11-11.json');
    const bad = path.join(dir, 'StoreTrackPro-backup-2026-11-10.json');
    const payload = JSON.stringify({ format: 'StoreTrackProCompleteBackup', version: 2, stores: { items: [{ id: 'x' }] } });
    fs.writeFileSync(good, payload); fs.writeFileSync(bad, '{broken');
    const before = [good, bad].map(file => ({ bytes: fs.readFileSync(file), mtime: fs.statSync(file).mtimeMs }));
    const helper = extract(main, 'verifyRetainedBackups');
    const validate = extract(main, 'validateCompleteBackup');
    const verify = vm.runInNewContext(`${validate}\n${helper}\nverifyRetainedBackups`, { fs, path, decryptCompleteBackup: raw => raw });
    const result = verify(dir);
    assert.deepEqual(JSON.parse(JSON.stringify({ checked: result.checked, passed: result.passed, failed: result.failed })), { checked: 2, passed: 1, failed: 1 });
    assert.equal(result.files.find(file => file.fileName.endsWith('11.json')).ok, true);
    assert.equal(result.files.find(file => file.fileName.endsWith('10.json')).ok, false);
    for (const [index, file] of [good, bad].entries()) {
      assert.deepEqual(fs.readFileSync(file), before[index].bytes);
      assert.equal(fs.statSync(file).mtimeMs, before[index].mtime);
    }
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('backup status exposes verification in UI and bridge while preserving a read-only verifier', () => {
  assert.match(main, /verification = verifyRetainedBackups\(dir\)/);
  assert.match(main, /secureHandle\('backup:status'/);
  assert.match(fs.readFileSync(path.join(root, 'preload.js'), 'utf8'), /status: \(\) => ipcRenderer\.invoke\('backup:status'\)/);
  assert.match(renderer, /Retained backup integrity: \$\{verification\.passed\}/);
});

test('restore test mode writes and reads backup rows in a temporary IndexedDB database without touching live data', async () => {
  const dbName = 'StoreTrackRestoreTestFixture';
  const open = await new Promise((resolve, reject) => {
    const request = indexedDB.open(dbName, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      db.createObjectStore('stock', { keyPath: 'id' }).createIndex('binId', 'binId');
      db.createObjectStore('transactions', { keyPath: 'id' });
      db.createObjectStore('users', { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  await new Promise((resolve, reject) => {
    const tx = open.transaction('stock', 'readwrite');
    tx.objectStore('stock').put({ id: 'live-row', quantity: 11, binId: 'L1' });
    tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
  });
  const restoreFn = extract(renderer, 'restoreBackup');
  const compareFn = extract(renderer, 'compare');
  const helperNames = ['isUserStore', 'valid', 'validGRN', 'stable', 'restoreTestRowKey', 'canonicalRestoreData', 'runIsolatedRestoreTest', 'saveRestoreVerification', 'escapeBackupHtml', 'renderRestoreVerification'];
  const events = [], resultHost = { innerHTML: '' };
  const payload = { format: 'StoreTrackProCompleteBackup', version: 2, createdAt: '2026-11-16T00:00:00.000Z', stores: { stock: [{ id: 'new', quantity: 4, binId: 'L2' }] } };
  const context = {
    indexedDB, DB: dbName,
    window: { getDB: () => open, backupBridge: { read: async () => ({ ok: true, data: JSON.stringify(payload), encrypted: true, fileName: 'backup.json' }), write: async () => { events.push('backup-write'); }, writeRecoveryJournal: async () => { events.push('journal-write'); } } },
    getStoreNames: () => ['stock', 'transactions', 'users'], gAll: async () => [{ id: 'old' }],
    statusText: (message) => events.push(message), document: { getElementById: id => id === 'backup-restore-test-result' ? resultHost : null },
    localStorage: { values: {}, getItem(key) { return this.values[key] || null; }, setItem(key, value) { this.values[key] = value; } },
    confirm: () => { events.push('confirm'); return true; }, console,
  };
  vm.runInNewContext(`${helperNames.map(name => extract(renderer, name)).join('\n')}\n${compareFn}\n${restoreFn}\nthis.restore=restoreBackup; this.runIsolated=runIsolatedRestoreTest`, context);
  const result = await context.restore(undefined, undefined, { testOnly: true });
  assert.equal(result.ok, true); assert.equal(result.testOnly, true); assert.equal(result.testResult.cleaned, true);
  assert.match(result.testResult.warnings.join(' '), /Stores absent from the backup will be preserved: transactions/);
  assert.equal(result.preview.stores.stock.added, 1); assert.equal(result.preview.stores.stock.removed, 1);
  assert.match(resultHost.innerHTML, /Isolated restore test passed/);
  assert.match(resultHost.innerHTML, /1\/1 records restored and read back/);
  assert.match(events[0], /live data and backup files were not changed/);
  assert.equal(events.some(event => ['backup-write', 'journal-write', 'confirm'].includes(event)), false);
  const unchangedDb = await new Promise((resolve, reject) => { const request = indexedDB.open(dbName); request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); });
  const liveRows = await new Promise((resolve, reject) => { const request = unchangedDb.transaction('stock', 'readonly').objectStore('stock').getAll(); request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); });
  unchangedDb.close();
  assert.deepEqual(JSON.parse(JSON.stringify(liveRows)), [{ id: 'live-row', quantity: 11, binId: 'L1' }]);
  assert.equal((await indexedDB.databases()).some(db => db.name.includes('_RestoreTest_')), false);
  const incompatible = await context.runIsolated({ ...payload, stores: { stock: [{ id: 'x', quantity: 1 }], removed_from_app: [{ id: 'y' }] } });
  assert.equal(incompatible.ok, false);
  assert.match(incompatible.errors.join(' '), /unsupported by this application version: removed_from_app/);
  assert.equal(incompatible.cleaned, true);
  const duplicateKeys = await context.runIsolated({ ...payload, stores: { stock: [{ id: 'duplicate', quantity: 1 }, { id: 'duplicate', quantity: 2 }] } });
  assert.equal(duplicateKeys.ok, false);
  assert.match(duplicateKeys.errors.join(' '), /duplicate or incompatible keys/);
  assert.equal(duplicateKeys.cleaned, true);
  assert.equal((await indexedDB.databases()).some(db => db.name.includes('_RestoreTest_')), false);
  open.close();
  await new Promise(resolve => { const request = indexedDB.deleteDatabase(dbName); request.onsuccess = resolve; request.onerror = resolve; });
});

test('each newly written daily backup automatically receives a restore test result', async () => {
  const calls = [], payload = { format: 'StoreTrackProCompleteBackup', version: 2, stores: { stock: [{ id: 'x' }] } };
  const local = {}, events = [];
  const context = {
    dateKey: () => '2026-11-16', collect: async () => payload,
    runIsolatedRestoreTest: async value => { calls.push(value); return { ok: true, errors: [], warnings: [], stores: { stock: { expected: 1, restored: 1, ok: true } }, cleaned: true, checkedAt: '2026-11-16T00:00:00.000Z' }; },
    statusText: (message, type) => events.push({ message, type }),
    localStorage: { getItem: key => local[key] || null, setItem: (key, value) => { local[key] = value; } },
    window: { backupBridge: { write: async serialized => { assert.equal(JSON.parse(serialized).format, payload.format); return { ok: true, fileName: 'daily.json' }; } } },
  };
  vm.runInNewContext(`const BACKUP_KEY='storetrack_last_backup_date'; const RESTORE_TEST_KEY='storetrack_last_restore_verification'; ${extract(renderer, 'saveRestoreVerification')}\n${extract(renderer, 'createBackup')}\nthis.createBackup=createBackup;`, context);
  const result = await context.createBackup(true);
  assert.equal(result.ok, true);
  assert.equal(result.restoreVerification.ok, true);
  assert.equal(calls.length, 1);
  assert.equal(calls[0], payload);
  assert.match(events.at(-1).message, /isolated restore-tested/);
  assert.ok(local.storetrack_last_restore_verification);
});

test('portable backup export follows a successful restore test and is blocked on test failure', async () => {
  const runCase = async testPasses => {
    const events = [], local = {};
    const context = {
      confirm: () => true,
      collect: async () => ({ format: 'StoreTrackProCompleteBackup', stores: { stock: [] } }),
      validationIssue: () => '',
      runIsolatedRestoreTest: async () => { events.push('restore-test'); return { ok: testPasses, errors: testPasses ? [] : ['fixture failure'], cleaned: true }; },
      showBackupSuccess: () => events.push('display'),
      statusText: message => events.push(message), latestBackupPath: '',
      localStorage: { getItem: key => local[key] || null, setItem: (key, value) => { local[key] = value; } },
      window: { backupBridge: { exportPortable: async () => { events.push('export'); return { ok: true, fileName: 'portable.json', path: '/backup/portable.json' }; } } },
    };
    vm.runInNewContext(`const RESTORE_TEST_KEY='storetrack_last_restore_verification'; ${extract(renderer, 'saveRestoreVerification')}\n${extract(renderer, 'createPortableBackupFromButton')}\nthis.createPortable=createPortableBackupFromButton;`, context);
    return { result: await context.createPortable(), events };
  };
  const passed = await runCase(true);
  assert.equal(passed.result.ok, true);
  assert.ok(passed.events.indexOf('restore-test') < passed.events.indexOf('export'));
  const failed = await runCase(false);
  assert.equal(failed.result.ok, false);
  assert.equal(failed.result.reason, 'restore-verification');
  assert.equal(failed.events.includes('export'), false);
});

test('malformed restore input returns before backup, journal, or database mutation', async () => {
  const restoreFn = extract(renderer, 'restoreBackup'); const events = [];
  const context = { window: { backupBridge: { read: async () => ({ ok: true, data: '{bad', encrypted: true }), write: async () => events.push('write'), writeRecoveryJournal: async () => events.push('journal') } }, statusText: message => events.push(message), console };
  vm.runInNewContext(`${restoreFn}\nthis.restore=restoreBackup`, context);
  await context.restore(undefined, undefined, { testOnly: true });
  assert.deepEqual(events, ['Backup file is invalid']);
});

test('restore preview labels encryption conditionally and includes every operational store removal count', () => {
  assert.match(renderer, /raw\.encrypted === true \? 'Encrypted and authenticated backup\.'/);
  assert.match(renderer, /raw\.encrypted === false \? 'Plaintext backup; not authenticated\.'/);
  assert.match(renderer, /counts\.removed/);
  assert.match(renderer, /Replace with backup rows/);
  assert.match(renderer, /preserve current store/i);
  assert.match(renderer, /Object\.entries\(preview\.stores\)/);
});
