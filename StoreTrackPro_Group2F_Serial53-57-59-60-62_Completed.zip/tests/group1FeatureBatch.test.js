'use strict';

const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

function extractFunction(source, name, nextMarker) {
  const start = source.indexOf(`function ${name}(`);
  if (start < 0) throw new Error(`Missing ${name}`);
  if (nextMarker) {
    const end = source.indexOf(nextMarker, start);
    if (end < 0) throw new Error(`Missing end marker for ${name}`);
    return source.slice(start, end).trim();
  }
  const open = source.indexOf('{', start);
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let i = open; i < source.length; i += 1) {
    const ch = source[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') {
      quote = ch;
      continue;
    }
    if (ch === '{') depth += 1;
    else if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Unclosed function ${name}`);
}

describe('StoreTrack Pro Group 1 feature completion', () => {
  test('Help presents tailored guidance and only shows cards for the signed-in role', () => {
    const profileSource = extractFunction(app, 'helpProfileForRole', '\nfunction renderRoleHelp()');
    const renderSource = extractFunction(app, 'renderRoleHelp', '\n\n// ── Nav ──');
    const cards = [
      { dataset: { helpRoles: 'store,admin,developer' }, hidden: false },
      { dataset: { helpRoles: 'maintenance,admin,developer' }, hidden: false },
      { dataset: { helpRoles: 'admin,developer' }, hidden: false },
    ];
    const elements = {
      'help-role-title': { textContent: '' },
      'help-role-summary': { textContent: '' },
    };
    const context = {
      cu: { role: 'maintenance' },
      document: {
        getElementById: id => elements[id] || null,
        querySelectorAll: selector => selector === '[data-help-roles]' ? cards : [],
      },
    };
    vm.runInNewContext(`${profileSource}\n${renderSource}\nrenderRoleHelp();`, context);
    expect(elements['help-role-title'].textContent).toBe('Maintenance Officer quick start');
    expect(elements['help-role-summary'].textContent).toMatch(/replacement, repair, or return/i);
    expect(cards.map(card => card.hidden)).toEqual([true, false, true]);
    expect(html).toContain('id="s-help"');
    expect(html).toContain('data-help-roles="store,maintenance,admin,developer"');
    expect(html).toContain('data-help-roles="admin,developer"><strong>Diagnostics &amp; audit</strong>');
    expect(html).toContain('data-help-roles="auditor"><strong>Audit and history review</strong>');
  });

  test('important transaction and adjustment fields expose concise, associated inline guidance', () => {
    const fields = [
      ['in-bc', 'in-bc-help'], ['in-qty', 'in-qty-help'], ['in-supp', 'in-supp-help'],
      ['in-po', 'in-po-help'], ['out-bc', 'out-bc-help'], ['out-qty', 'out-qty-help'],
      ['out-dept', 'out-dept-help'], ['out-job', 'out-job-help'], ['adj-type', 'adj-type-help'],
      ['adj-qty', 'adj-qty-help'], ['adj-rsn', 'adj-rsn-help'],
    ];
    for (const [field, help] of fields) {
      expect(html).toMatch(new RegExp(`id="${field}"[^>]*aria-describedby="${help}"`));
      expect(html).toMatch(new RegExp(`id="${help}" class="field-hint"`));
    }
    expect(fs.readFileSync(path.join(root, 'styles.css'), 'utf8')).toContain('.field-hint{');
  });

  test('unmapped detector flags only confirmed stock movements without a current ID or barcode match', () => {
    const detector = extractFunction(app, 'findUnmappedStockTransactions', '\nfunction refreshUnmappedStockAlerts()');
    const context = {};
    vm.runInNewContext(`${detector}\nresult=findUnmappedStockTransactions([\n      {id:'linked-id',itemId:'1',type:'IN',status:'confirmed'},\n      {id:'linked-barcode',barcode:' b-1 ',type:'OUT',status:'confirmed'},\n      {id:'missing',itemId:'gone',barcode:'missing',type:'OUT',status:'confirmed',qty:2},\n      {id:'pending',type:'OUT',status:'pending'},\n      {id:'adjustment',type:'ADJUST',status:'confirmed'}\n    ],[{id:1,barcode:'B-1'}]);`, context);
    expect(Array.from(context.result, row => row.id)).toEqual(['missing']);
  });

  test('unmapped report renders a bounded, safely text-only table and states local read-only scope', () => {
    const detector = extractFunction(app, 'findUnmappedStockTransactions', '\nfunction refreshUnmappedStockAlerts()');
    const refresh = extractFunction(app, 'refreshUnmappedStockAlerts', '\n// Live event feed');
    const status = { textContent: '', style: {} };
    const body = { rows: [], replaceChildren() { this.rows = []; }, appendChild(row) { this.rows.push(row); } };
    const document = {
      getElementById: id => id === 'diag-unmapped-stock' ? status : id === 'diag-unmapped-stock-body' ? body : null,
      createElement: tag => ({ tag, children: [], appendChild(child) { this.children.push(child); } }),
    };
    const suspiciousName = '<img src=x onerror=alert(1)>';
    const context = {
      document,
      T: [{ id: 'tx-x', type: 'OUT', status: 'confirmed', itemId: 'gone', itemName: suspiciousName, barcode: 'B-X', qty: 2, time: '2026-11-01T10:00:00Z' }],
      M: [],
    };
    vm.runInNewContext(`${detector}\n${refresh}\nresult=refreshUnmappedStockAlerts();`, context);
    expect(context.result).toHaveLength(1);
    expect(status.textContent).toMatch(/read-only local check/i);
    expect(status.textContent).toMatch(/does not validate the central server/i);
    expect(body.rows).toHaveLength(1);
    expect(body.rows[0].children[2].textContent).toBe(suspiciousName);
    expect(body.rows[0].children[2].innerHTML).toBeUndefined();
  });

  test('attachment and correction entry workflows remain connected and preserve original ledger entries', () => {
    expect(app).toContain('async function readTransactionAttachments(direction)');
    expect(app).toContain("remarks:sanitizeText(document.getElementById('in-rem').value),attachments");
    expect(app).toContain("remarks:sanitizeText(document.getElementById('out-rem').value),attachments");
    expect(app).toContain('async function correctTransaction(originalId)');
    expect(app).toContain('correctionOf:original.id');
    expect(app).toContain("writes:[{store:'transactions',obj:correction}]");
    expect(app).toContain('Original transaction is unchanged');
  });
});
