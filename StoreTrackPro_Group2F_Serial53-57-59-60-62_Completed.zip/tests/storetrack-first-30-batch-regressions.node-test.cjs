const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const backup = fs.readFileSync(path.join(root, 'modules', 'dataBackup.js'), 'utf8');
const widgets = fs.readFileSync(path.join(root, 'modules', 'dashboardWidgets.js'), 'utf8');
const utilities = fs.readFileSync(path.join(root, 'modules', 'utilities.js'), 'utf8');
const priorRegression = fs.readFileSync(path.join(__dirname, 'storetrack-22-source-fix-regressions.node-test.cjs'), 'utf8');

function block(source, startText, endText) {
  const start = source.indexOf(startText);
  assert.notEqual(start, -1, `Missing block start: ${startText}`);
  const end = source.indexOf(endText, start);
  assert.notEqual(end, -1, `Missing block end: ${endText}`);
  return source.slice(start, end);
}
function functionText(source, functionName) {
  const start = source.indexOf(`function ${functionName}(`);
  assert.notEqual(start, -1, `Missing function ${functionName}`);
  const open = source.indexOf('{', start);
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let i = open; i < source.length; i += 1) {
    const ch = source[i];
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (ch === '\\') { escaped = true; continue; }
      if (ch === quote) { quote = null; }
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') { depth += 1; }
    if (ch === '}') {
      depth -= 1;
      if (depth === 0) { return source.slice(start, i + 1); }
    }
  }
  throw new Error(`Unclosed function ${functionName}`);
}

const batchOut = block(app, 'async function confirmBatchOut(){', '\n}\n\n// ── PIN Lock');
const materialMaster = block(app, 'function renderMaster(){', '\nconst renderMasterDebounced');
const scannerIdbHandler = block(app, 'window.scannerBridge.onIdbUpdate(async data => {', '\n  window.scannerBridge.onDeviceError');

// P01 — dashboards/widgets only use persisted canonical fields and completed movement.
test('P01-F01 default widgets are seeded when the store is empty', () => {
  assert.match(widgets, /if \(!ownConfigs\.length\) \{ this\.setDefaultWidgets\(\); await this\.saveWidgetConfigs\(\); return; \}/);
  assert.match(widgets, /\(config\.userId\s*!=\s*null\s*\?\s*String\(config\.userId\)\s*:\s*'__anonymous__'\)\s*===\s*scope/);
  assert.match(widgets, /setDefaultWidgets\(\)/);
  assert.match(widgets, /await this\.saveWidgetConfigs\(\)/);
});
test('P01-F02 widget metrics use StoreTrack material fields', () => {
  assert.match(widgets, /m\.stock\s*\?\?\s*m\.currentStock/);
  assert.match(widgets, /m\.lowAlert\s*\?\?\s*m\.minStock/);
  assert.match(widgets, /m\.unitPrice\s*\?\?\s*m\.price\s*\?\?\s*m\.rate/);
});
test('P01-F03 chart, summary, and PDF exclude unconfirmed OUT requests', () => {
  assert.match(app, /const outTxns=T\.filter\(t=>t\.type==='OUT'&&t\.status==='confirmed'/);
  assert.match(app, /const txns=T\.filter\(t=>t\.status==='confirmed'/);
  assert.match(app, /const outTxns=T\.filter\(t=>t\.type==='OUT'&&t\.status==='confirmed'/g);
});
test('P01-F04 recent activity metrics use completed movement', () => {
  assert.match(app, /T\.filter\(isCompletedMovement\)/);
  assert.match(widgets, /t\.status === 'confirmed'/);
  assert.match(priorRegression, /P01-F04 dashboard only counts completed movement/);
});

// P02 — backups and feature-gated route.
test('P02-F01 Backup Center can bypass only the Shank Mapping component gate', () => {
  assert.match(app, /function nav\(id, options = \{\}\)/);
  assert.match(app, /id==='component'&&options\?\.bypassFeatureGate===true/);
  assert.match(backup, /nav\('component',\s*\{\s*bypassFeatureGate:\s*true\s*\}\)/);
});
test('P02-F02 malformed stores/rows are rejected before restore writes', () => {
  assert.match(functionText(backup, 'valid'), /Object\.values\(payload\.stores\)\.every\(rows\s*=>\s*Array\.isArray\(rows\)\s*&&\s*rows\.every\(row\s*=>\s*row\s*&&\s*typeof row\s*===\s*'object'\s*&&\s*!Array\.isArray\(row\)\)\)/);
  const validation = backup.indexOf('if (!valid(payload))');
  const destructiveWrites = backup.indexOf('await dClr(name)');
  assert.ok(validation >= 0 && destructiveWrites > validation);
  assert.ok(backup.indexOf('if (options.testOnly)') < destructiveWrites);
});
test('P02-F03 stores absent from older backups are warned about and preserved', () => {
  assert.match(backup, /missingStores\.length[\s\S]*PRESERVED and not cleared/);
  assert.match(backup, /!Object\.prototype\.hasOwnProperty\.call\(payload\.stores, name\)\)\s*\{\s*continue;/);
  assert.match(backup, /if \(!confirm\(summary \+ '\\n\\nContinue\?'\)\) \{ return; \}/);
});
test('P02-F04 plaintext backups omit users and restore never replaces user accounts', () => {
  assert.match(backup, /SECURITY WARNING: This is a legacy plaintext backup|This backup is encrypted and authenticated/i);
  assert.match(backup, /function isUserStore\(name\)[\s\S]*?toLowerCase\(\) === 'users'/);
  assert.match(backup, /names\.filter\(name => !isUserStore\(name\)\)/);
  assert.match(backup, /for \(const name of names\) \{ if \(!isUserStore\(name\) && !Object\.prototype\.hasOwnProperty\.call\(stores, name\)\)/);
  assert.match(backup, /if \(isUserStore\(name\) \|\| !Object\.prototype\.hasOwnProperty\.call\(payload\.stores, name\)\)/);
  assert.match(backup, /readSnapshot\(names, \{ decrypt: false \}\)/);
  assert.match(backup, /restoreRawSnapshot\(currentSnapshot\)/);
  assert.match(backup, /User account records are always preserved and never restored/);
});

// P03 — quantities and the persisted/scanner-driven Material IN UI.
test('P03-F01 Material IN quantities 1, 9, and 10 remain unchanged', () => {
  const numberFn = functionText(utilities, 'sanitizeNumber');
  const integerFn = functionText(utilities, 'sanitizeInteger');
  const actual = vm.runInNewContext(`${numberFn}\n${integerFn}\n[ sanitizeInteger('1', 1), sanitizeInteger('9', 1), sanitizeInteger('10', 1) ]`);
  assert.deepEqual(Array.from(actual), [1, 9, 10]);
  assert.match(app, /sanitizeInteger\(document\.getElementById\('in-qty'\)\.value,\s*1\)/);
});
test('P03-F02 Material IN log rebuilds today\'s rows from persisted transactions', () => {
  const renderer = functionText(app, 'todaysInTransactions');
  const dateToday = new Date(2026, 9, 9, 13);
  const todayIn = new Date(2026, 9, 9, 10).toISOString();
  const todayScannerIn = new Date(2026, 9, 9, 11).toISOString();
  const yesterdayIn = new Date(2026, 9, 8, 23).toISOString();
  const result = vm.runInNewContext(`${renderer}\ntodaysInTransactions(rows, now)`, {
    rows: [
      { id: 'manual', type: 'IN', time: todayIn },
      { id: 'scanner', type: 'MATERIAL_IN', time: todayScannerIn },
      { id: 'old', type: 'IN', time: yesterdayIn },
      { id: 'out', type: 'OUT', time: todayScannerIn },
    ],
    now: dateToday,
  });
  assert.deepEqual(Array.from(result, row => row.id), ['scanner', 'manual']);
  assert.match(app, /in:renderInLog/);
  assert.match(app, /renderInLog\(\);/);
});
test('P03-F03 scanner receipts refresh the selected IN card and persisted log', () => {
  assert.match(scannerIdbHandler, /\['IN', 'MATERIAL_IN'\]\.includes\(data\.tx\.type\)/);
  assert.match(scannerIdbHandler, /inI\.stock = Number\(data\.newStock\)/);
  assert.match(scannerIdbHandler, /renderInLog\(\)/);
});
test('P03-F04 supplier modal escapes option values and labels', () => {
  assert.match(priorRegression, /P03-F04 supplier modal escapes option text and value/);
  assert.match(app, /SP\.map\(s=>`<option value="\$\{sanitizeHTML\(String\(s\.id\)\)\}">\$\{sanitizeHTML\(String\(s\.name\|\|''\)\)\}<\/option>`\)/);
});

// P04 — Batch OUT role policy, approval workflow, sync, issue-slip invalidation, atomic writes.
test('P04-F01 Batch OUT checks the action capability, not a raw role allowlist', () => {
  assert.match(batchOut, /canRoleAction\('procOut'\)/);
  assert.doesNotMatch(batchOut, /\['admin','developer','store'\]\.includes/);
});
test('P04-F02 Store Batch OUT creates a pending approval without decrementing stock', () => {
  const storeStart = batchOut.indexOf("if(cu.role==='store'){");
  const adminStart = batchOut.indexOf('}else{', storeStart);
  assert.ok(storeStart >= 0 && adminStart > storeStart);
  const storeBranch = batchOut.slice(storeStart, adminStart);
  assert.match(storeBranch, /status:'pending'/);
  assert.match(storeBranch, /store:'approvals'/);
  assert.doesNotMatch(storeBranch, /item\.stock\s*[-+]=/);
});
test('P04-F03 authorized Batch OUT submits central sync and records pending-central failure', () => {
  assert.match(batchOut, /window\.centralSync\?\.submit/);
  assert.match(batchOut, /await window\.centralSync\.submit\(tx\)/);
  assert.match(batchOut, /tx\.status='pending-central'/);
});
test('P04-F04 accepted Batch OUT invalidates any prior single-item issue slip', () => {
  assert.match(batchOut, /lastTx=null;/);
  assert.match(app, /function printIssueSlip\(\)\{\s*if\(!lastTx\)/);
});
test('P04-F05 Batch OUT requires atomic material/transaction and request/approval writes', () => {
  assert.match(batchOut, /if\(typeof window\.dPutMany!=='function'\)\{throw new Error\('Atomic batch writes are unavailable'\);\}/);
  assert.equal((batchOut.match(/await window\.dPutMany\(/g) || []).length, 1);
  assert.match(batchOut, /window\.atomicReadModifyWrite\('materials',item\.id,current=>/);
  assert.match(batchOut, /writes:\[\{store:'transactions',obj:tx\}\]/);
  assert.doesNotMatch(batchOut, /await dPut\('(materials|transactions|approvals)'/);
});

// P05 — import control, UUID identity, empty selection state, and authorization.
test('P05-F01 picker advertises only supported Excel formats', () => {
  assert.match(html, /Import Excel<input type="file" accept="\.xlsx,\.xls"/);
  assert.doesNotMatch(html, /accept="\.xlsx,\.xls,\.pdf,\.doc,\.docx"/);
});
test('P05-F02 editing preserves imported UUID keys', () => {
  assert.match(priorRegression, /P05-F02 material edit preserves existing UUID key/);
  assert.match(app, /if\(eid\)\{obj\.id=old\?old\.id:eid;\}/);
});
test('P05-F03 zero-result master filter resets select-all and hides stale controls', () => {
  assert.match(materialMaster, /if\(!f\.length\)\{const selectAll=document\.getElementById\('m-select-all'\);if\(selectAll\)\{selectAll\.checked=false;\}[^}]*updateSelectedMaterials\(\);return;/);
});
test('P05-F04 bulk delete and toggle require part-register capability', () => {
  const del = functionText(app, 'deleteSelectedMaterials');
  const toggle = functionText(app, 'toggleSelectedMaterials');
  assert.match(del, /canRoleAction\('partRegister'\)/);
  assert.match(toggle, /canRoleAction\('partRegister'\)/);
});
test('P05-F05 Smart Import picker and commit both require import capability', () => {
  assert.match(functionText(app, 'openSmartImport'), /canRoleAction\('imports'\)/);
  assert.match(functionText(app, 'siConfirmImport'), /canRoleAction\('imports'\)/);
});
test('P05-F06 selected and full material exports require export capability', () => {
  assert.match(functionText(app, 'exportSelectedCSV'), /canRoleAction\('pdfExcelExport'\)/);
  assert.match(functionText(app, 'exportAllMaterialsExcel'), /canRoleAction\('pdfExcelExport'\)/);
});

// P06 — existing source fixes are re-asserted for this batch.
test('P06-F01 Current Stock rows open the material detail modal', () => {
  assert.match(priorRegression, /P06-F01 Current Stock row opens detail modal/);
  assert.match(app, /data-onclick="openMaterialDetail\(\$\{JSON\.stringify\(String\(m\.id\)\)\}\)"/);
});
test('P06-F02 Current Stock location is HTML-escaped', () => {
  assert.match(priorRegression, /P06-F02 Current Stock location is HTML-escaped/);
  assert.match(app, /sanitizeHTML\(String\(m\.location\|\|'—'\)\)/);
});
test('P06-F03 Current Stock empty state spans nine columns', () => {
  assert.match(priorRegression, /P06-F03 Current Stock empty state spans nine columns/);
  assert.match(app, /stk-body[\s\S]{0,250}colspan="9"/);
});
test('P06-F04 malformed material name and barcode are normalized', () => {
  assert.match(priorRegression, /P06-F04 malformed material name\/barcode are normalized/);
  assert.match(app, /const name=String\(m\.name\|\|''\)\.toLowerCase\(\),barcode=String\(m\.barcode\|\|''\)\.toLowerCase\(\)/);
});

// P07 — existing source fixes are re-asserted for this batch.
test('P07-F01 Stock Adjustment fails closed without physicalStock capability', () => {
  assert.match(app, /async function doAdjust\(\)\{\s*if\(typeof canRoleAction!=='function'\|\|!canRoleAction\('physicalStock'\)\)\{return;\}/);
  assert.match(priorRegression, /P07-F01/);
});
test('P07-F02 decimal quantity is rejected instead of truncated', () => {
  assert.match(app, /Number\.isSafeInteger\(qty\)/);
  assert.match(html, /id="adj-qty"[^>]*min="1" step="1"/);
  assert.match(priorRegression, /P07-F02 decimal quantity is rejected instead of truncated/);
});
test('P07-F03 stock and adjustment history are committed atomically', () => {
  assert.match(app, /window\.dPutMany\(\[\{store:'materials',obj:updatedMaterial\},\{store:'adjustments',obj:adj\}\]\)/);
  assert.match(priorRegression, /P07-F03 stock and adjustment are committed atomically/);
});
