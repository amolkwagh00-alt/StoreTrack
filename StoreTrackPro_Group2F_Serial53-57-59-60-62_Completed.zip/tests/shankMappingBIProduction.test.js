const {
  simulate,
  forecastAccuracy,
  maintenanceCorrelation,
  freshness,
  actionCenter,
} = require('../modules/shankMappingBIProduction');
const analytics = require('../modules/shankConsumptionAnalytics');

describe('Shank Mapping BI production calculations', () => {
  test('what-if simulation is deterministic and does not mutate the forecast input', () => {
    const forecast = {
      partNo: 'P-1',
      currentStock: 10,
      averageDailyUsage: 2,
      safetyStockQty: 3,
      status: 'REORDER',
    };
    const before = JSON.stringify(forecast);
    const result = simulate(forecast, {
      usageChange: 50,
      leadTime: 5,
      stockAdjustment: 2,
      safetyAdjustment: 1,
      period: 30,
    });
    expect(result.simulatedDailyUsage).toBe(3);
    expect(result.simulated.stock).toBe(12);
    expect(result.suggestedOrderQuantity).toBe(7);
    expect(JSON.stringify(forecast)).toBe(before);
  });

  test('forecast accuracy does not fabricate values when actual usage is absent', () => {
    const rows = forecastAccuracy(
      [{ partNo: 'P-1', averageDailyUsage: 2, usageConfidence: 'LOW' }],
      [],
    );
    expect(rows[0].tracked).toBe(false);
    expect(rows[0].actualUsage).toBeUndefined();
    expect(rows[0].accuracy).toBeUndefined();
  });

  test('forecast accuracy compares explicit actual usage only', () => {
    const rows = forecastAccuracy(
      [{ partNo: 'P-1', averageDailyUsage: 2 }],
      [{ partNo: 'P-1', actualUsage: 50 }],
    );
    expect(rows[0].tracked).toBe(true);
    expect(rows[0].forecastedUsage).toBe(60);
    expect(rows[0].actualUsage).toBe(50);
    expect(rows[0].direction).toBe('Over-forecast');
  });

  test('forecast accuracy pools actual usage across normalized Part Number variants', () => {
    const forecasts = analytics.calculateForecast({
      today: '2026-09-03',
      parts: [{ partNo: '07-526/98' }, { partNo: '07-0526/98' }],
      stock: [],
      replacements: [],
    });
    const rows = forecastAccuracy(forecasts, [
      { partNo: '07-526/98', actualUsage: 8 },
      { partNo: '07-0526/98', actualUsage: 7 },
    ]);
    expect(rows).toHaveLength(1);
    expect(rows[0].tracked).toBe(true);
    expect(rows[0].actualUsage).toBe(15);
  });

  test('maintenance correlation is source-data-based and explainable', () => {
    const rows = maintenanceCorrelation(
      [
        { stationNo: 'FFA 10', partNo: 'P-1', gunReferenceNo: 'G-1', quantity: 2 },
        { stationNo: 'FFA 10', partNo: 'P-1', gunReferenceNo: 'G-1', quantity: 1 },
      ],
      [{ partNo: 'P-1', status: 'repair' }],
      [],
    );
    expect(rows).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ scope: 'Station', subject: 'FFA 10', replacements: 3 }),
        expect.objectContaining({ scope: 'Part', subject: 'P-1', repairs: 1 }),
      ]),
    );
    expect(rows.some((row) => /Review gun|machine/i.test(row.evidence))).toBe(false);
  });

  test('freshness reports missing timestamps as not tracked and stale data honestly', () => {
    const result = freshness({ Empty: [], Old: [{ updatedAt: '2020-01-01T00:00:00.000Z' }] });
    expect(result.Empty).toEqual({ latest: null, stale: null, tracked: false });
    expect(result.Old.tracked).toBe(true);
    expect(result.Old.stale).toBe(true);
  });

  test('action center emits real action identifiers for risk rows', () => {
    const html = actionCenter(
      [
        {
          partNo: 'P-1',
          status: 'ZERO STOCK',
          currentStock: 0,
          usageConfidence: 'LOW',
          usageDays: 2,
        },
      ],
      [],
      [],
      [],
      [],
    );
    expect(html).toContain('componentBiOpenStock');
    expect(html).toContain('Open Stock');
    expect(html).toContain('Low forecast confidence');
  });
});
