require('fake-indexeddb/auto');

const { initDB, dPut, dClr, gAll, getStoreNames } = require('../modules/database.js');

global.gAll = gAll;
global.dPut = dPut;
global.dClr = dClr;
global.getStoreNames = getStoreNames;
global.DB = 'StoreTrackDB_Test';

require('../modules/dataBackup.js');

describe('Complete backup/restore runtime flow with isolated IndexedDB', () => {
  const storesToClean = ['component_parts', 'component_stock', 'component_mappings', 'users'];

  beforeAll(async () => {
    await initDB();
  });

  beforeEach(async () => {
    jest.useFakeTimers();
    for (const store of storesToClean) { await dClr(store); }
  });

  afterEach(() => {
    window.backupBridge = undefined;
    window.confirm = () => false;
    jest.useRealTimers();
  });

  test('creates a complete operational snapshot and restores it without replacing local users', async () => {
    await dPut('component_parts', { id: 'part-A', partNo: '07-526/43', description: 'Pencil Shank' });
    await dPut('component_stock', { id: 'stock-A', partNo: '07-526/43', binId: 'PENCIL-BIN-01', quantity: 8 });
    await dPut('component_mappings', { id: 'mapping-A', stationNo: 'ECA 20 RH', gunReferenceNo: 'Gun 1', position: 'Fix Shank', partNo: '07-526/43' });
    await dPut('users', { id: 'local-user', username: 'local-admin', role: 'admin' });

    const writes = [];
    let sourceBackup = '';
    window.backupBridge = {
      write: async serialized => {
        writes.push(serialized);
        if (!sourceBackup) { sourceBackup = serialized; }
        return { ok: true, fileName: `isolated-${writes.length}.backup`, path: `/isolated/test-${writes.length}.backup` };
      },
      read: async () => ({ ok: true, data: sourceBackup, fileName: 'isolated-source.backup', encrypted: true }),
    };
    window.confirm = jest.fn(() => true);

    const created = await window.componentCreateCompleteBackup();
    expect(created.ok).toBe(true);
    const payload = JSON.parse(sourceBackup);
    expect(payload.format).toBe('StoreTrackProCompleteBackup');
    expect(payload.stores.component_stock).toEqual([{ id: 'stock-A', partNo: '07-526/43', binId: 'PENCIL-BIN-01', quantity: 8 }]);
    expect(payload.stores).not.toHaveProperty('users');

    await dPut('component_parts', { id: 'part-A', partNo: '07-526/43', description: 'Changed after backup' });
    await dPut('component_parts', { id: 'part-B', partNo: '07-526/48', description: 'Post-backup record' });
    await dPut('component_stock', { id: 'stock-A', partNo: '07-526/43', binId: 'PENCIL-BIN-01', quantity: 2 });

    await window.componentRestoreCompleteBackup();

    expect(writes).toHaveLength(2);
    expect(JSON.parse(writes[1]).stores.component_parts).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: 'part-A', description: 'Changed after backup' }),
      expect.objectContaining({ id: 'part-B', description: 'Post-backup record' }),
    ]));
    expect(await gAll('component_parts')).toEqual([{ id: 'part-A', partNo: '07-526/43', description: 'Pencil Shank' }]);
    expect(await gAll('component_stock')).toEqual([{ id: 'stock-A', partNo: '07-526/43', binId: 'PENCIL-BIN-01', quantity: 8 }]);
    expect(await gAll('component_mappings')).toEqual([{ id: 'mapping-A', stationNo: 'ECA 20 RH', gunReferenceNo: 'Gun 1', position: 'Fix Shank', partNo: '07-526/43' }]);
    expect(await gAll('users')).toEqual([{ id: 'local-user', username: 'local-admin', role: 'admin' }]);
    expect(window.confirm).toHaveBeenCalled();
  });
});
