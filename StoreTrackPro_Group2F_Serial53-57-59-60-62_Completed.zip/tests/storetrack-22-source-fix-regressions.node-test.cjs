'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const widgets = fs.readFileSync(path.join(root, 'modules/dashboardWidgets.js'), 'utf8');
const helperStart = app.indexOf('function isCompletedMovement(t)');
const helperEnd = app.indexOf('// ── Stock ──', helperStart);
assert.ok(helperStart >= 0 && helperEnd > helperStart, 'shared audit helper block must exist');
const ctx = { T: [], M: [], document: { getElementById(id) { return ({
  'srch-h': { value: '' }, 'flt-h-tp': { value: 'all' }, 'flt-h-f': { value: '' }, 'flt-h-t': { value: '' }
}[id] || { value: '' }); } } };
ctx.localDateRangeBounds = (from,to) => { let fromMs=null, untilMs=null; if(from){const start=new Date(`${from}T00:00:00`); if(!Number.isFinite(start.getTime())) return null; fromMs=start.getTime();} if(to){const end=new Date(`${to}T00:00:00`); if(!Number.isFinite(end.getTime())) return null; end.setDate(end.getDate()+1); untilMs=end.getTime();} if(fromMs!==null&&untilMs!==null&&fromMs>=untilMs) return null; return {fromMs,untilMs}; };
vm.runInNewContext(app.slice(helperStart, helperEnd), ctx);

const checks = [
  ['P01-F04 dashboard only counts completed movement', () => { assert.match(app, /T\.filter\(isCompletedMovement\)/); assert.match(widgets, /t\.status === 'confirmed'/); assert.match(app, /getShiftTxns\(shift\)\.filter\(isCompletedMovement\)/); }],
  ['P03-F04 supplier modal escapes option text and value', () => assert.match(app, /SP\.map\(s=>`<option value="\$\{sanitizeHTML\(String\(s\.id\)\)\}">\$\{sanitizeHTML\(String\(s\.name\|\|''\)\)\}<\/option>`\)/)],
  ['P04-F04 batch OUT invalidates prior slip only after authorization and cart validation', () => { const start = app.indexOf('async function confirmBatchOut(){'); const capability = app.indexOf("if(!canRoleAction('procOut'))", start); const cart = app.indexOf('if(!batchCart.length)', start); const invalidate = app.indexOf('lastTx=null;', start); assert.ok(start >= 0 && capability > start && cart > capability && invalidate > cart); assert.match(app, /function printIssueSlip\(\)\{\s*if\(!lastTx\)/); }],
  ['P05-F02 material edit preserves existing UUID key', () => assert.match(app, /if\(eid\)\{obj\.id=old\?old\.id:eid;\}/)],
  ['P06-F01 Current Stock row opens detail modal', () => assert.match(app, /data-onclick="openMaterialDetail\(\$\{JSON\.stringify\(String\(m\.id\)\)\}\)"/)],
  ['P06-F02 Current Stock location is HTML-escaped', () => assert.match(app, /sanitizeHTML\(String\(m\.location\|\|'—'\)\)/)],
  ['P06-F03 Current Stock empty state spans nine columns', () => assert.match(app, /stk-body[\s\S]{0,250}colspan="9"/)],
  ['P06-F04 malformed material name/barcode are normalized', () => assert.match(app, /const name=String\(m\.name\|\|''\)\.toLowerCase\(\),barcode=String\(m\.barcode\|\|''\)\.toLowerCase\(\)/)],
  ['P07-F01 Stock Adjust fails closed without physicalStock capability checker', () => assert.match(app, /async function doAdjust\(\)\{\s*if\(typeof canRoleAction!=='function'\|\|!canRoleAction\('physicalStock'\)\)\{return;\}/)],
  ['P07-F02 decimal quantity is rejected instead of truncated', () => { assert.match(app, /const tp=document\.getElementById\('adj-type'\)\.value;const qty=Number\(document\.getElementById\('adj-qty'\)\.value\)/); assert.match(html, /id="adj-qty"[^>]*min="1" step="1"/); }],
  ['P07-F03 stock and adjustment are committed atomically', () => assert.match(app, /window\.dPutMany\(\[\{store:'materials',obj:updatedMaterial\},\{store:'adjustments',obj:adj\}\]\)/)],
  ['P08-F01 history CSV and Excel share active filters', () => { assert.match(app, /historyFilteredTransactions\(\)\.forEach\(t=>rows\.push/); assert.match(app, /data=historyFilteredTransactions\(\)\.map/); }],
  ['P08-F02 history sorting uses parsed transaction timestamps', () => assert.match(app, /function sortTransactionsNewestFirst\(rows\)[\s\S]{0,250}Date\.parse\(a\?\.time/)],
  ['P08-F03 history renderer safely normalizes malformed fields', () => assert.match(app, /function historyFilteredTransactions\(\)[\s\S]{0,1200}String\(t\.itemName\|\|''\)/)],
  ['P38-F02 indent free text is escaped', () => assert.match(app, /sanitizeHTML\(String\(x\.materialName\|\|''\)\)/)],
  ['P38-F03 indent Purpose/Job and Remarks are displayed and exported', () => { assert.match(html, /<th>Purpose \/ Job No\.<\/th><th>Remarks<\/th>/); assert.match(app, /'Purpose \/ Job No\.'\,'Remarks'/); assert.match(app, /x\.job\|\|'',x\.remarks\|\|''/); }],
  ['P42-F01 consumption export applies category filter', () => assert.match(app, /if\(type==='consume'\)[\s\S]{0,600}con-cat[\s\S]{0,350}category===cat/)],
  ['P42-F02 consumption window labels match calendar-month cutoff', () => { assert.match(app, /function consumptionWindow\(months, now=new Date\(\)\)/); assert.match(app, /new Date\(now\.getFullYear\(\),now\.getMonth\(\)-count\+1,1\)/); }],
  ['P43-F02 GRN render and print escape stored fields', () => { assert.match(app, /sanitizeHTML\(String\(g\.supplierName\|\|'—'\)\)/); assert.match(app, /sanitizeHTML\(String\(it\.barcode\|\|''\)\)/); }],
  ['P43-F03 GRN CSV neutralizes formula-leading strings', () => { assert.match(app, /function csvCell\(value\)[\s\S]{0,300}typeof value!==['\"]number/); assert.match(app, /void startCSVExport\(rows,`grn_/); }],
  ['P45-F02 supplier filter is shared by reorder view and export', () => { assert.match(app, /const low=reorderCandidates\(M,suppFlt\)/); assert.match(app, /reorderCandidates\(M,document\.getElementById\('po-supp-flt'\)\?\.value\|\|''\)/); }],
  ['P48-F03 Health Monitor refreshes while visible and cleans up', () => { assert.match(app, /healthMonitorRefreshTimer=setInterval\(\(\)=>\{if\(document\.getElementById\('s-health-monitor'\)\?\.classList\.contains\('active'\)\)renderHealthMonitor\(\)/); assert.match(app, /else if\(healthMonitorRefreshTimer\)\{clearInterval\(healthMonitorRefreshTimer\)/); }],
  ['P48-F01 production performance metrics feed predictive monitoring independently of page rendering', () => { assert.match(app, /window\.eventBus\.on\('PERFORMANCE_METRIC', metric =>/); assert.match(app, /predictiveHealthMonitoring\.recordMetric\(metricName, metricValue, \{/); assert.match(app, /__storeTrackPredictiveMetricListener/); }]
];
for (const [name, fn] of checks) test(name, fn);

test('completed movement excludes pending/rejected/pending-central requests', () => {
  assert.equal(ctx.isCompletedMovement({type:'OUT',status:'confirmed'}), true);
  for (const status of ['pending','rejected','pending-central','']) assert.equal(ctx.isCompletedMovement({type:'OUT',status}), false);
  assert.equal(ctx.isCompletedMovement({type:'OUT',status:'confirmed'}), true);
});
test('CSV serializer quotes delimiters and neutralizes spreadsheet formulas', () => {
  const csv = ctx.serializeCSVRows([['Name','Value'], ['=1+1','a,"b"'], ['+cmd','@formula']]);
  assert.match(csv, /"'=1\+1"/); assert.match(csv, /"a,""b"""/); assert.match(csv, /"'\+cmd"/); assert.match(csv, /"'@formula"/);
});
test('history helper applies search/type/date filters and sorts newest first', () => {
  ctx.T = [
    {time:'2026-01-01T10:00:00Z',itemName:'Bolt',barcode:'B1',type:'OUT'},
    {time:'2026-03-01T10:00:00Z',itemName:'Nut',barcode:'N1',type:'IN'},
    {time:'2026-02-01T10:00:00Z',itemName:'Bolt Large',barcode:'B2',type:'OUT'}
  ];
  ctx.document.getElementById = id => ({
    'srch-h':{value:'bolt'},'flt-h-tp':{value:'OUT'},'flt-h-f':{value:'2026-01-15'},'flt-h-t':{value:'2026-02-28'}
  }[id]||{value:''});
  const result=ctx.historyFilteredTransactions();
  assert.equal(result.length,1); assert.equal(result[0].barcode,'B2');
});
test('consumption window returns exactly N matching calendar-month buckets', () => {
  const w=ctx.consumptionWindow(6,new Date('2026-10-09T12:00:00Z'));
  assert.equal(w.labels.length,6); assert.equal(w.labels[0],'2026-05'); assert.equal(w.labels[5],'2026-10');
  assert.equal(w.start.getFullYear(),2026); assert.equal(w.start.getMonth(),4); assert.equal(w.start.getDate(),1);
});
test('supplier filter excludes unassigned materials and keeps matching supplier only', () => {
  const rows=[{id:1,stock:0,lowAlert:2,supplierId:'S1'},{id:2,stock:1,lowAlert:2,supplierId:'S2'},{id:3,stock:0,lowAlert:2}];
  assert.deepEqual(Array.from(ctx.lowStockForSupplier(rows,'S1'),m=>m.id),[1]);
  assert.deepEqual(Array.from(ctx.lowStockForSupplier(rows,''),m=>m.id),[1,2,3]);
});
