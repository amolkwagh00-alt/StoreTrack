const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'dashboardWidgets.js'), 'utf8');
const accessibilitySource = fs.readFileSync(path.join(__dirname, '..', 'modules', 'accessibility.js'), 'utf8');
const htmlSource = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');

describe('dashboard widget accessibility and chart lifecycle regressions', () => {
  test('renders keyboard-operable move controls and wires them to persisted ordering', () => {
    expect(source).toMatch(/class="widget-move-up"[^>]*aria-label="Move \$\{config\.title\} up"[^>]*>Move up<\/button>/);
    expect(source).toMatch(/class="widget-move-down"[^>]*aria-label="Move \$\{config\.title\} down"[^>]*>Move down<\/button>/);
    expect(source).toMatch(/closest\('\.widget-move-up, \.widget-move-down'\)/);
    expect(source).toMatch(/this\.moveWidget\(widgetId, targetIndex\)/);
  });

  test('settings popup exposes dialog semantics, a labelled heading, and associated field labels', () => {
    expect(source).toMatch(/role="dialog" aria-modal="true" aria-labelledby="widget-settings-heading"/);
    expect(source).toMatch(/<h2 id="widget-settings-heading">Widget Settings:/);
    for (const field of ['widget-title', 'widget-size', 'widget-refresh']) expect(source).toContain(`<label for="${field}">`);
  });

  test('stores layouts by stable user ID and preserves all other users without a global clear', () => {
    expect(source).toContain('window.currentUser?.id');
    expect(source).toContain("'__anonymous__'");
    expect(source).toContain('const preserved =');
    expect(source).not.toContain("dClr('widget_configs')");
    expect(source).toContain('...preserved, ...configs');
    expect(source).toContain('config.userId');
  });

  test('delegates Enter/Space sidebar activation once and avoids editable/special controls', () => {
    expect(accessibilitySource).toContain("e.key !== 'Enter' && e.key !== ' '");
    expect(accessibilitySource).toContain("target.closest('.sidebar [role=\"button\"][data-onclick]')");
    expect(accessibilitySource).toContain('control.click()');
    expect(accessibilitySource).toContain('target.isContentEditable');
    expect(accessibilitySource).toContain("control.hasAttribute('data-onkeydown')");
  });

  test('associates input labels with real IDs or useful fallbacks and names MSP dialogs', () => {
    expect(accessibilitySource).toContain("input.setAttribute('aria-labelledby', label.id)");
    expect(accessibilitySource).toContain("input.setAttribute('aria-label', fallback)");
    for (const id of ['msp-list-modal', 'msp-notes-modal']) {
      expect(htmlSource).toContain(`id="${id}" role="dialog" aria-modal="true" aria-labelledby="${id}-title"`);
      expect(htmlSource).toContain(`id="${id}-title"`);
    }
  });

  test('destroys registered chart instances before clearing dashboard canvases', () => {
    const renderStart = source.indexOf('async renderWidgets()');
    const clearPosition = source.indexOf('dashboard.innerHTML =', renderStart);
    const destroyPosition = source.indexOf('this.destroyDashboardCharts();', renderStart);
    expect(destroyPosition).toBeGreaterThan(renderStart);
    expect(destroyPosition).toBeLessThan(clearPosition);
    expect(source).toMatch(/chartManager\.removeChart\(id\)/);
  });
});
