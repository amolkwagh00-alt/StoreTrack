# StoreTrack — Runtime Verification Test Cases (11 Pending Findings)

**Status:** Test cases prepared. These cases require a configured Electron app and a disposable test database. Do not mark a case PASS until executed and evidence (screenshot/log/export or DB assertion) is attached.

## Preconditions / safety
- Use a non-production copy of the StoreTrack database and a test account for each role.
- Take a backup before running backup/restore, merge/rollback, or destructive MSP actions.
- Capture build version, OS, app log, and test-data IDs in the evidence column.

| ID | Finding | Steps | Expected result | Evidence to capture |
|---|---|---|---|---|
| RT-01 | P02-F03 — complete backup restore leaves stale stores | Create Store A and Store B; export a complete backup containing only Store A; add a unique Store B record after backup; restore backup with the complete-restore option; reload and inspect stores. | Complete restore replaces the snapshot-managed stores; Store B's post-snapshot record is absent, while Store A's backed-up record exists. No unrelated stores are silently retained. | Before/after store counts and IDs; restore log. |
| RT-02 | P02-F04 — plaintext backup security warning | Export an unencrypted complete backup with a users store; observe the confirmation/warning; inspect the exported JSON in a secure test folder. Repeat with encrypted backup. | Unencrypted export explicitly warns that user/account data is included and requires secure handling; encrypted export is distinguishable and protected by its password. | Warning screenshot; backup header/format metadata (never attach real passwords). |
| RT-03 | P16-F01 — MSP destructive actions and role guards | Login as viewer/auditor/maintenance and try Add Row, Delete Row, Clear All, duplicate list via UI and direct handler invocation; repeat as authorized admin. | Unauthorized roles cannot mutate data through UI or direct handler invocation; authorized roles can, and denied attempts create no DB changes. | Role, action, before/after list IDs/row counts, console log. |
| RT-04 | P16-F04 — CSV import preserves empty columns | Import a CSV containing `A,,C`, quoted commas, escaped quotes, CRLF, and a quoted multiline value using supported import format. | Each value stays in its original column; empty cells remain empty; records are not shifted or split. Invalid rows are reported clearly. | Input CSV and imported record JSON. |
| RT-05 | P16-F05 — CSV header escaping | Export CSV with header labels containing a comma, quote, or newline in a controlled test harness; reopen using a standards-compliant CSV parser. | Header parses into the intended exact number of columns and values without corrupting the first data row. | Exported CSV and parsed header array. |
| RT-06 | P16-F06 — MSP HTML injection | In a test list, enter title, machine name, notes, and part text containing `<img src=x onerror=alert(1)>` and quotes; render list, suggestion panel, print preview. | Payload is displayed as text, no script/event executes, and print output is safe. | Screenshots, console, saved record. |
| RT-07 | P26-F01 — cross-base Station merge | Prepare RH/LH source/target stations that have different base Station keys; invoke manual merge. Then repeat with matching base and valid RH/LH. | Different base Stations are rejected without any writes; valid same-base merge remains supported. | Source/target keys and mappings before/after; user-visible message. |
| RT-08 | P26-F02 — rollback restores mappings and transactions | Snapshot source/target mappings, stock, bins, and transactions; run a successful merge that modifies target mappings/transactions; rollback; compare full before/after state. | Rollback restores all affected mappings, transactions, stock, and bin records to their exact pre-merge state. | JSON snapshots before merge, after merge, after rollback. |
| RT-09 | P38-F04 — Viewer/Auditor cannot access restricted page | Login as Viewer then Auditor; attempt navigation through menu, URL/route if applicable, and direct page handler for the restricted page. Repeat as allowed role. | Restricted roles cannot enter or operate the page by any path; allowed roles can. No restricted data is rendered. | Role, screenshots, console/network/DB evidence. |
| RT-10 | P42-F04 — category filter HTML escaping | Create a material category with HTML-like text such as `<svg onload=alert(1)>`; open Consumption category filter and change category; inspect DOM. | Category is shown as literal text; no element/script executes; category selection still filters correctly. | Screenshot and DOM text/value assertion. |
| RT-11 | P43-F04 — malformed restored GRN resilience | In a disposable backup, add GRN rows with missing/non-array items, nested object values where scalars are expected, and missing scalar fields; restore; open GRN page and export/print. | Invalid GRNs are skipped or clearly reported; GRN page and export remain usable; print rejects malformed records with a safe message rather than crashing. | Test backup fixture, restore warning, app log, export result. |

## Exit criteria
- Record PASS/FAIL/BLOCKED per case, tester, timestamp, build ID, and evidence path.
- For RT-01/02/07/08, compare persisted records, not just UI messages.
- Any failure must reopen the corresponding finding; do not set `Open = 0` until all applicable cases pass.
