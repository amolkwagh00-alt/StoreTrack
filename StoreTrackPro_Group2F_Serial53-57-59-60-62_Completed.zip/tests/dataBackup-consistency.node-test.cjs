'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'dataBackup.js'), 'utf8');
const root = path.join(__dirname, '..');
const main = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
const preload = fs.readFileSync(path.join(root, 'preload.js'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
function body(name) {
  const start = source.indexOf(`function ${name}(`) >= 0 ? source.indexOf(`function ${name}(`) : source.indexOf(`async function ${name}(`);
  assert.ok(start >= 0, `missing ${name}`);
  const open = source.indexOf(') {', start) + 2;
  assert.ok(open >= 2, `missing body for ${name}`);
  let depth = 0;
  for (let i = open; i < source.length; i += 1) {
    if (source[i] === '{') depth += 1;
    if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`unterminated ${name}`);
}

test('backup snapshots all operational stores in one IndexedDB readonly transaction', () => {
  const snapshot = body('readSnapshot');
  assert.match(snapshot, /database\.transaction\(available, 'readonly'\)/);
  assert.match(snapshot, /transaction\.objectStore\(name\)\.getAll\(\)/);
  assert.match(snapshot, /transaction\.oncomplete/);
  assert.match(body('collect'), /await readSnapshot\(names\)/);
  assert.doesNotMatch(body('collect'), /await gAll\(/);
});

test('restore journals a raw rollback snapshot in protected storage before writes', () => {
  const restore = body('restoreBackup');
  assert.ok(restore.indexOf('await writeRestoreJournal(currentSnapshot)') < restore.indexOf('await dClr(name)'));
  assert.match(restore, /readSnapshot\(names, \{ decrypt: false \}\)/);
  assert.match(restore, /await writeRestoreJournal\(\{\}, 'committed'\)/);
  assert.match(body('writeRestoreJournal'), /backupBridge\.writeRecoveryJournal/);
  assert.match(body('recoverInterruptedRestore'), /backupBridge\.readRecoveryJournal/);
  assert.match(body('recoverInterruptedRestore'), /await restoreRawSnapshot\(journal\.snapshot\)/);
  assert.match(body('restoreRawSnapshot'), /database\.transaction\(available, 'readwrite'\)/);
  assert.doesNotMatch(source, /localStorage\.(?:getItem|setItem|removeItem)\(RESTORE_JOURNAL_KEY/);
});

test('main process encrypts recovery journal and preload exposes narrow bridge methods', () => {
  assert.match(main, /secureHandle\('backup:writeRecoveryJournal'/);
  assert.match(main, /encryptCompleteBackup\(serialized\)/);
  assert.match(main, /fs\.fsyncSync\(fd\)/);
  assert.match(main, /secureHandle\('backup:readRecoveryJournal'/);
  assert.match(main, /secureHandle\('backup:clearRecoveryJournal'/);
  assert.match(preload, /writeRecoveryJournal: \(serialized\) => ipcRenderer\.invoke\('backup:writeRecoveryJournal'/);
  assert.match(preload, /readRecoveryJournal: \(\) => ipcRenderer\.invoke\('backup:readRecoveryJournal'/);
  assert.match(preload, /clearRecoveryJournal: \(\) => ipcRenderer\.invoke\('backup:clearRecoveryJournal'/);
});

test('startup recovery precedes encryption initialization', () => {
  const start = app.indexOf('initDB().then(async()=>{');
  const recover = app.indexOf('recoverInterruptedStoreTrackRestore()', start);
  const encryption = app.indexOf('window.DataEncryption?.init', start);
  assert.ok(start >= 0 && recover > start && encryption > recover);
});
