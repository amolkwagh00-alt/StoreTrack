'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { encryptBackup, decryptBackup } = require('../modules/secureBackup');

const payload = JSON.stringify({ format: 'StoreTrackProCompleteBackup', version: 2, stores: { materials: [{ id: 'm-1', partNo: 'P-1' }] } });

test('operational backup encrypts and restores valid data', () => {
  const key = crypto.randomBytes(32);
  const envelope = encryptBackup(payload, key);
  assert.equal(envelope.format, 'StoreTrackProEncryptedBackup');
  assert.equal(envelope.algorithm, 'AES-256-GCM');
  assert.notEqual(JSON.stringify(envelope).includes('P-1'), true);
  assert.equal(decryptBackup(envelope, key), payload);
});

test('operational backup rejects an incorrect key', () => {
  const envelope = encryptBackup(payload, crypto.randomBytes(32));
  assert.throws(() => decryptBackup(envelope, crypto.randomBytes(32)));
});

test('operational backup rejects tampered ciphertext and authentication metadata', () => {
  const key = crypto.randomBytes(32);
  const envelope = encryptBackup(payload, key);
  const tampered = { ...envelope, ciphertext: Buffer.from(envelope.ciphertext, 'base64').map((byte, index) => index === 0 ? byte ^ 0xff : byte).toString('base64') };
  assert.throws(() => decryptBackup(tampered, key));
  const tamperedTag = { ...envelope, authTag: Buffer.from(envelope.authTag, 'base64').map((byte, index) => index === 0 ? byte ^ 0xff : byte).toString('base64') };
  assert.throws(() => decryptBackup(tamperedTag, key));
});

test('Electron backup boundary validates store rows and malformed GRN before rotation', () => {
  const main = fs.readFileSync(path.join(__dirname, '..', 'main.js'), 'utf8');
  assert.match(main, /const validRows = rows => Array\.isArray\(rows\)/);
  assert.match(main, /Object\.values\(stores\)\.some\(rows => !validRows\(rows\)\)/);
  assert.match(main, /stores\.grn\) && stores\.grn\.some\(row => !validGRN\(row\)/);
  assert.match(main, /Backup validation failed/);
});

test('Electron backup boundary protects its key and refuses plaintext writes', () => {
  const main = fs.readFileSync(path.join(__dirname, '..', 'main.js'), 'utf8');
  assert.match(main, /safeStorage/);
  assert.match(main, /isEncryptionAvailable/);
  assert.match(main, /ENCRYPTED_BACKUP_FORMAT/);
  assert.match(main, /decryptCompleteBackup\(fs\.readFileSync\(temp/);
  assert.doesNotMatch(main, /fs\.writeFileSync\(temp, JSON\.stringify\(payload\)/);
});
