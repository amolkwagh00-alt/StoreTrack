'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadDatabaseStatus() {
  const module = { exports: {} };
  const context = { module, window: {}, performance: { now: () => 0 }, Promise, Date, console };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../modules/database.js'), 'utf8'), context);
  return module.exports.getDatabaseStatus;
}

test('local database status distinguishes not-ready, old version, missing stores, and current schema', () => {
  const getStatus = loadDatabaseStatus();
  const notReady = getStatus(null);
  assert.equal(notReady.ready, false);
  assert.equal(notReady.migrationPending, true);
  const names = ['materials', 'transactions', 'users'];
  const old = getStatus({ name: 'StoreTrackDB', version: 20, objectStoreNames: names });
  assert.equal(old.ready, true);
  assert.equal(old.migrationPending, true);
  assert.ok(old.missingStores.includes('central_queue'));
  const allExpectedStores = [...new Set([...(names), ...old.missingStores])];
  const current = getStatus({ name: 'StoreTrackDB', version: old.expectedVersion, objectStoreNames: allExpectedStores });
  assert.equal(current.migrationPending, false);
  assert.equal(current.missingStores.length, 0);
});

test('diagnostics labels status as local IndexedDB and does not claim central migration health', () => {
  const app = fs.readFileSync(path.join(__dirname, '../app.js'), 'utf8');
  const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
  assert.match(app, /does not inspect or migrate the central server/);
  assert.match(html, /reports local IndexedDB only, not the central server/);
  assert.match(html, /Check Schema/);
});
