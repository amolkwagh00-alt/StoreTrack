const assert = require('assert');
const fs = require('fs');
const path = require('path');

test('AI hardening contracts are wired', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'aiAssistants.js'), 'utf8');
  assert(source.includes('logAIAction'));
  assert(source.includes('chat_query'));
  assert(source.includes('root_cause_run'));
  assert(
    fs
      .readFileSync(path.join(__dirname, '..', 'server', 'index.js'), 'utf8')
      .includes('/api/ai/events'),
  );
  assert(fs.readFileSync(path.join(__dirname, '..', 'preload.js'), 'utf8').includes('logAIEvent'));
});
