const { page, indexBy, forEachChunk } = require('../modules/performance');

describe('large-data performance helpers', () => {
  test('pagination bounds rendered rows without truncating source data', () => {
    const rows = Array.from({ length: 10000 }, (_, i) => ({ id: i }));
    const result = page(rows, 37, 100);
    expect(result.rows).toHaveLength(100);
    expect(result.rows[0].id).toBe(3700);
    expect(result.total).toBe(10000);
    expect(result.pages).toBe(100);
  });

  test('indexed grouping avoids repeated full-list scans', () => {
    const rows = Array.from({ length: 5000 }, (_, i) => ({ station: `S${i % 25}`, id: i }));
    const index = indexBy(rows, (row) => row.station);
    expect(index.get('S7')).toHaveLength(200);
    expect(index.size).toBe(25);
  });

  test('chunked processing visits every row and reports completion', async () => {
    const rows = Array.from({ length: 1200 }, (_, i) => i);
    const visited = [];
    const progress = [];
    await forEachChunk(
      rows,
      async (row) => {
        visited.push(row);
      },
      200,
      (done, total) => progress.push([done, total]),
    );
    expect(visited).toHaveLength(1200);
    expect(visited[1199]).toBe(1199);
    expect(progress).toEqual([
      [200, 1200],
      [400, 1200],
      [600, 1200],
      [800, 1200],
      [1000, 1200],
      [1200, 1200],
    ]);
  });
});
