const fs = require('fs');
const path = require('path');
const analytics = require(path.join('..', 'modules', 'shankConsumptionAnalytics.js'));
const { BusinessIntelligence } = require(path.join('..', 'modules', 'businessIntelligence.js'));

const componentSource = fs.readFileSync(
  path.join(__dirname, '..', 'modules', 'componentManagement.js'),
  'utf8',
);
const centralSource = fs.readFileSync(
  path.join(__dirname, '..', 'modules', 'centralSync.js'),
  'utf8',
);

describe('Independent V44 Shank Mapping audit', () => {
  test('forecast status reaches LOW STOCK at safety-stock floor', () => {
    const [row] = analytics.calculateForecast({
      today: '2026-08-30',
      stock: [{ partNo: 'P1', quantity: 10 }],
      parts: [
        {
          partNo: 'P1',
          occurrenceQty: 10,
          analytics: { leadTimeDays: 0, internalProcurementDays: 0 },
        },
      ],
      replacements: [],
    });
    expect(row.status).toBe('OK STOCK');
    expect(row.stockStatus).toBe('OK STOCK');
    expect(row.forecastStatus).toBe('NO DATA');
  });

  test('forecast status keeps REORDER between low-stock floor and reorder point', () => {
    const [row] = analytics.calculateForecast({
      today: '2026-08-30',
      stock: [{ partNo: 'P1', quantity: 10.02 }],
      parts: [
        {
          partNo: 'P1',
          occurrenceQty: 10,
          analytics: { leadTimeDays: 5, internalProcurementDays: 0 },
        },
      ],
      replacements: [
        { partNo: 'P1', type: 'Replacement / Issue', quantity: 0.9, replacementDate: '2026-08-29' },
      ],
    });
    expect(row.status).toBe('REORDER');
  });

  test('ZERO STOCK revives after receiving positive pooled stock', () => {
    const input = {
      today: '2026-08-30',
      parts: [{ partNo: 'P1', occurrenceQty: 5 }],
      replacements: [],
    };
    expect(
      analytics.calculateForecast({ ...input, stock: [{ partNo: 'P1', quantity: 0 }] })[0].status,
    ).toBe('ZERO STOCK');
    expect(
      analytics.calculateForecast({ ...input, stock: [{ partNo: 'P1', quantity: 500 }] })[0].status,
    ).not.toBe('ZERO STOCK');
  });

  test('multiple stock rows are pooled by part number', () => {
    const [row] = analytics.calculateForecast({
      today: '2026-08-30',
      stock: [
        { partNo: 'P1', quantity: 0 },
        { partNo: 'P1', quantity: 40 },
      ],
      parts: [{ partNo: 'P1', occurrenceQty: 5 }],
      replacements: [],
    });
    expect(row.currentStock).toBe(40);
  });

  test('consumption excludes Receive rows and includes seven-day boundary', () => {
    const rows = [
      { partNo: 'P1', type: 'Replacement / Issue', quantity: 5, replacementDate: '2026-08-30' },
      { partNo: 'P1', type: 'Replacement / Issue', quantity: 3, replacementDate: '2026-08-24' },
      { partNo: 'P2', type: 'Receive', quantity: 99, replacementDate: '2026-08-30' },
    ];
    const result = analytics.calculateConsumption(rows, { end: '2026-08-30', periodDays: 90 });
    expect(result.find((row) => row.partNo === 'P1').last7Days).toBe(8);
    expect(result.find((row) => row.partNo === 'P2')).toBeUndefined();
  });

  test('lead time zero is safe and still allows reorder status at floor', () => {
    const [row] = analytics.calculateForecast({
      today: '2026-08-30',
      stock: [{ partNo: 'P1', quantity: 5 }],
      parts: [
        {
          partNo: 'P1',
          occurrenceQty: 5,
          analytics: { leadTimeDays: 0, internalProcurementDays: 0 },
        },
      ],
      replacements: [],
    });
    expect(row.leadTimeDays).toBe(0);
    expect(row.status).toBe('OK STOCK');
    expect(row.stockStatus).toBe('OK STOCK');
    expect(row.forecastStatus).toBe('NO DATA');
  });

  test('shared forecastStatus helper is used by the production forecast', () => {
    expect(
      analytics.forecastStatus({
        currentStock: 5,
        expectedDaysUntilZero: null,
        effectiveLeadTimeDays: 0,
        reorderPoint: 5,
        lowStockThreshold: 5,
      }),
    ).toBe('LOW STOCK');
    expect(componentSource).toContain('getForecastStatus');
    expect(componentSource).toContain('window.ShankConsumptionAnalytics?.forecastStatus');
  });

  test('Procurement no longer contains a second independent status formula', () => {
    expect(componentSource).toContain('getForecastStatus({ currentStock: total.current');
    expect(componentSource).not.toContain(
      "status = 'REORDER'; reason = 'Total Part stock is below the pooled reorder point.'; } else if (primary && total.current <= low)",
    );
  });

  test('BI initialize waits for KPIs before building dashboards', async () => {
    const bi = new BusinessIntelligence();
    await bi.initialize({
      materials: [{ value: 5000 }],
      transactions: [{ type: 'OUT', value: 3000 }],
      suppliers: [],
      grn: [],
    });
    const widget = bi
      .getDashboard('executive')
      .widgets.find((item) => item.title === 'Inventory Turnover');
    expect(widget.value).toBe('0.60');
  });

  test('central sync gates all polling behind configured status', () => {
    expect(centralSource).toContain('function checkHealth()');
    expect(centralSource).toContain('if (healthFlight) return healthFlight;');
    expect(centralSource).toContain('const status = await checkHealth();');
    expect(centralSource).toContain('if (!status?.configured) return;');
    expect(centralSource).toContain('healthTimer = setInterval(checkHealth, 30000);');
  });

  test('station identity normalizes RFA punctuation but preserves LH/RH variants', () => {
    expect(componentSource).toContain(
      'const stationVariantKey = value => normalStation(resolveStationAlias(value));',
    );
    expect(componentSource).toContain(
      'stationVariantKey(row.stationNo) === stationVariantKey(bin.stationNo)',
    );
  });

  test('required quantity remains occurrence count and double occurrence count', () => {
    expect(componentSource).toContain('minimumQty: r.sourceMappings');
    expect(componentSource).toContain('maximumQty: r.sourceMappings * 2');
  });

  test('six-component eligibility fields remain canonical', () => {
    expect(componentSource).toContain(
      "const GUN_COUNT_COMPONENT_FIELDS = ['fixShank', 'movingShank', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder'];",
    );
  });

  test('receiving allocates total quantity from selected Part No. by kit mapping', () => {
    expect(componentSource).toContain('function receiveAllocation(partNo, totalQuantity)');
    expect(componentSource).toContain('KIT_PROPORTIONAL');
  });
});
