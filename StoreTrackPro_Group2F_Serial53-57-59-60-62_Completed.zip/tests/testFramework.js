/**
 * Enterprise Unit Testing Framework
 * Lightweight testing framework for StoreTrack Pro
 */

class TestSuite {
  constructor(name) {
    this.name = name;
    this.tests = [];
    this.beforeEach = null;
    this.afterEach = null;
    this.beforeAll = null;
    this.afterAll = null;
  }

  /**
   * Add test to suite
   * @param {string} name - Test name
   * @param {Function} fn - Test function
   */
  test(name, fn) {
    this.tests.push({ name, fn, status: 'pending' });
  }

  /**
   * Setup before each test
   * @param {Function} fn - Setup function
   */
  beforeEach(fn) {
    this.beforeEach = fn;
  }

  /**
   * Teardown after each test
   * @param {Function} fn - Teardown function
   */
  afterEach(fn) {
    this.afterEach = fn;
  }

  /**
   * Setup before all tests
   * @param {Function} fn - Setup function
   */
  beforeAll(fn) {
    this.beforeAll = fn;
  }

  /**
   * Teardown after all tests
   * @param {Function} fn - Teardown function
   */
  afterAll(fn) {
    this.afterAll = fn;
  }

  /**
   * Run all tests in suite
   * @returns {Promise<object>} Test results
   */
  async run() {
    const results = {
      suite: this.name,
      total: this.tests.length,
      passed: 0,
      failed: 0,
      skipped: 0,
      duration: 0,
      tests: []
    };

    const startTime = Date.now();

    try {
      if (this.beforeAll) {
        await this.beforeAll();
      }

      for (const test of this.tests) {
        const testResult = {
          name: test.name,
          status: 'pending',
          duration: 0,
          error: null
        };

        const testStartTime = Date.now();

        try {
          if (this.beforeEach) {
            await this.beforeEach();
          }

          await test.fn();

          testResult.status = 'passed';
          results.passed++;
          test.status = 'passed';
        } catch (err) {
          testResult.status = 'failed';
          testResult.error = err.message;
          results.failed++;
          test.status = 'failed';
        } finally {
          const testDuration = Date.now() - testStartTime;
          testResult.duration = testDuration;

          if (this.afterEach) {
            try {
              await this.afterEach();
            } catch (err) {
              console.error('Error in afterEach:', err);
            }
          }
        }

        results.tests.push(testResult);
      }

      if (this.afterAll) {
        await this.afterAll();
      }
    } catch (err) {
      console.error('Error running test suite:', err);
    }

    results.duration = Date.now() - startTime;
    return results;
  }
}

class Assertion {
  /**
   * Assert value is truthy
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static assert(value, message = 'Assertion failed') {
    if (!value) {
      throw new Error(message);
    }
  }

  /**
   * Assert values are equal
   * @param {*} actual - Actual value
   * @param {*} expected - Expected value
   * @param {string} message - Error message
   */
  static equal(actual, expected, message) {
    if (actual !== expected) {
      throw new Error(message || `Expected ${expected} but got ${actual}`);
    }
  }

  /**
   * Assert values are not equal
   * @param {*} actual - Actual value
   * @param {*} expected - Expected value
   * @param {string} message - Error message
   */
  static notEqual(actual, expected, message) {
    if (actual === expected) {
      throw new Error(message || `Expected ${actual} to not equal ${expected}`);
    }
  }

  /**
   * Assert value is deep equal to expected
   * @param {*} actual - Actual value
   * @param {*} expected - Expected value
   * @param {string} message - Error message
   */
  static deepEqual(actual, expected, message) {
    const actualStr = JSON.stringify(actual);
    const expectedStr = JSON.stringify(expected);
    
    if (actualStr !== expectedStr) {
      throw new Error(message || `Expected deep equality but values differ`);
    }
  }

  /**
   * Assert value is truthy
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static ok(value, message) {
    this.assert(!!value, message || `Expected ${value} to be truthy`);
  }

  /**
   * Assert value is falsy
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static notOk(value, message) {
    this.assert(!value, message || `Expected ${value} to be falsy`);
  }

  /**
   * Assert value is null
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static null(value, message) {
    this.equal(value, null, message || `Expected null but got ${value}`);
  }

  /**
   * Assert value is not null
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static notNull(value, message) {
    this.notEqual(value, null, message || `Expected not null but got null`);
  }

  /**
   * Assert value is undefined
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static undefined(value, message) {
    this.equal(value, undefined, message || `Expected undefined but got ${value}`);
  }

  /**
   * Assert value is defined
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static defined(value, message) {
    this.notEqual(value, undefined, message || `Expected defined but got undefined`);
  }

  /**
   * Assert value is an instance of type
   * @param {*} value - Value to check
   * @param {Function} type - Type constructor
   * @param {string} message - Error message
   */
  static instanceOf(value, type, message) {
    if (!(value instanceof type)) {
      throw new Error(message || `Expected ${value} to be instance of ${type.name}`);
    }
  }

  /**
   * Assert value is a function
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static isFunction(value, message) {
    this.instanceOf(value, Function, message || `Expected function but got ${typeof value}`);
  }

  /**
   * Assert value is an object
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static isObject(value, message) {
    this.equal(typeof value, 'object', message || `Expected object but got ${typeof value}`);
  }

  /**
   * Assert value is an array
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static isArray(value, message) {
    this.ok(Array.isArray(value), message || `Expected array but got ${typeof value}`);
  }

  /**
   * Assert value is a string
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static isString(value, message) {
    this.equal(typeof value, 'string', message || `Expected string but got ${typeof value}`);
  }

  /**
   * Assert value is a number
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static isNumber(value, message) {
    this.equal(typeof value, 'number', message || `Expected number but got ${typeof value}`);
  }

  /**
   * Assert value is a boolean
   * @param {*} value - Value to check
   * @param {string} message - Error message
   */
  static isBoolean(value, message) {
    this.equal(typeof value, 'boolean', message || `Expected boolean but got ${typeof value}`);
  }

  /**
   * Assert array contains value
   * @param {Array} array - Array to check
   * @param {*} value - Value to find
   * @param {string} message - Error message
   */
  static contains(array, value, message) {
    this.ok(array.includes(value), message || `Expected array to contain ${value}`);
  }

  /**
   * Assert array length
   * @param {Array} array - Array to check
   * @param {number} length - Expected length
   * @param {string} message - Error message
   */
  static lengthOf(array, length, message) {
    this.equal(array.length, length, message || `Expected array length ${length} but got ${array.length}`);
  }

  /**
   * Assert object has property
   * @param {object} obj - Object to check
   * @param {string} prop - Property name
   * @param {string} message - Error message
   */
  static hasProperty(obj, prop, message) {
    this.ok(Object.prototype.hasOwnProperty.call(obj, prop), message || `Expected object to have property ${prop}`);
  }

  /**
   * Assert string matches regex
   * @param {string} str - String to check
   * @param {RegExp} regex - Regular expression
   * @param {string} message - Error message
   */
  static match(str, regex, message) {
    this.ok(regex.test(str), message || `Expected string to match ${regex}`);
  }

  /**
   * Assert number is greater than
   * @param {number} actual - Actual value
   * @param {number} expected - Expected value
   * @param {string} message - Error message
   */
  static greaterThan(actual, expected, message) {
    this.ok(actual > expected, message || `Expected ${actual} to be greater than ${expected}`);
  }

  /**
   * Assert number is less than
   * @param {number} actual - Actual value
   * @param {number} expected - Expected value
   * @param {string} message - Error message
   */
  static lessThan(actual, expected, message) {
    this.ok(actual < expected, message || `Expected ${actual} to be less than ${expected}`);
  }

  /**
   * Assert number is greater than or equal
   * @param {number} actual - Actual value
   * @param {number} expected - Expected value
   * @param {string} message - Error message
   */
  static greaterThanOrEqual(actual, expected, message) {
    this.ok(actual >= expected, message || `Expected ${actual} to be greater than or equal to ${expected}`);
  }

  /**
   * Assert number is less than or equal
   * @param {number} actual - Actual value
   * @param {number} expected - Expected value
   * @param {string} message - Error message
   */
  static lessThanOrEqual(actual, expected, message) {
    this.ok(actual <= expected, message || `Expected ${actual} to be less than or equal to ${expected}`);
  }

  /**
   * Assert function throws error
   * @param {Function} fn - Function to test
   * @param {string} message - Error message
   */
  static async throws(fn, message) {
    let threw = false;
    try {
      await fn();
    } catch (err) {
      threw = true;
    }
    this.assert(threw, message || 'Expected function to throw');
  }

  /**
   * Assert function does not throw error
   * @param {Function} fn - Function to test
   * @param {string} message - Error message
   */
  static async doesNotThrow(fn, message) {
    try {
      await fn();
    } catch (err) {
      throw new Error(message || `Expected function not to throw but got: ${err.message}`);
    }
  }
}

class TestRunner {
  constructor() {
    this.suites = new Map();
    this.results = [];
  }

  /**
   * Create test suite
   * @param {string} name - Suite name
   * @returns {TestSuite} Test suite
   */
  createSuite(name) {
    const suite = new TestSuite(name);
    this.suites.set(name, suite);
    return suite;
  }

  /**
   * Get suite
   * @param {string} name - Suite name
   * @returns {TestSuite} Test suite
   */
  getSuite(name) {
    return this.suites.get(name);
  }

  /**
   * Run all suites
   * @returns {Promise<object>} Combined results
   */
  async runAll() {
    const combinedResults = {
      totalSuites: this.suites.size,
      totalTests: 0,
      totalPassed: 0,
      totalFailed: 0,
      totalSkipped: 0,
      totalDuration: 0,
      suites: []
    };

    for (const [name, suite] of this.suites) {
      const results = await suite.run();
      combinedResults.suites.push(results);
      combinedResults.totalTests += results.total;
      combinedResults.totalPassed += results.passed;
      combinedResults.totalFailed += results.failed;
      combinedResults.totalSkipped += results.skipped;
      combinedResults.totalDuration += results.duration;
    }

    this.results = combinedResults;
    return combinedResults;
  }

  /**
   * Run specific suite
   * @param {string} name - Suite name
   * @returns {Promise<object>} Suite results
   */
  async runSuite(name) {
    const suite = this.suites.get(name);
    if (!suite) {
      throw new Error(`Suite ${name} not found`);
    }
    return await suite.run();
  }

  /**
   * Get results
   * @returns {object} Test results
   */
  getResults() {
    return this.results;
  }

  /**
   * Print results to console
   */
  printResults() {
    if (!this.results) {
      console.log('No test results available');
      return;
    }

    console.log('\n=== Test Results ===');
    console.log(`Total Suites: ${this.results.totalSuites}`);
    console.log(`Total Tests: ${this.results.totalTests}`);
    console.log(`Passed: ${this.results.totalPassed}`);
    console.log(`Failed: ${this.results.totalFailed}`);
    console.log(`Skipped: ${this.results.totalSkipped}`);
    console.log(`Duration: ${this.results.totalDuration}ms`);
    console.log(`Success Rate: ${((this.results.totalPassed / this.results.totalTests) * 100).toFixed(2)}%`);

    if (this.results.totalFailed > 0) {
      console.log('\n=== Failed Tests ===');
      for (const suite of this.results.suites) {
        for (const test of suite.tests) {
          if (test.status === 'failed') {
            console.log(`[${suite.suite}] ${test.name}: ${test.error}`);
          }
        }
      }
    }

    console.log('==================\n');
  }
}

// Global test runner instance
const testRunner = new TestRunner();

// Global assertion object
const assert = Assertion;

// Export for use
if (typeof window !== 'undefined') {
  window.TestRunner = TestRunner;
  window.testRunner = testRunner;
  window.TestSuite = TestSuite;
  window.Assertion = Assertion;
  window.assert = assert;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { TestRunner, testRunner, TestSuite, Assertion, assert };
}
