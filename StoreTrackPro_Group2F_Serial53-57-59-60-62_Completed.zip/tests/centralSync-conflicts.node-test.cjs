'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const appSource = fs.readFileSync(path.join(__dirname, '../app.js'), 'utf8');

function extractAppFunction(name) {
  let start = appSource.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `Missing ${name}`);
  if (appSource.slice(start - 6, start) === 'async ') start -= 6;
  const paramsEnd = appSource.indexOf(')', start);
  const open = appSource.indexOf('{', paramsEnd);
  let depth = 0, quote = null, escaped = false;
  for (let i = open; i < appSource.length; i += 1) {
    const ch = appSource[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth += 1;
    else if (ch === '}' && --depth === 0) return appSource.slice(start, i + 1);
  }
  throw new Error(`Unclosed ${name}`);
}

function harness(commitStock) {
  const rows = new Map();
  const events = [];
  const window = {
    location: { hostname: 'store-1' },
    addEventListener() {}, removeEventListener() {},
    dispatchEvent(event) { events.push(event); },
    centralBridge: { commitStock },
  };
  const context = {
    window, performance: { now: () => 1 }, Date, Math, Map, Set, Promise,
    CustomEvent: class CustomEvent { constructor(type, init) { this.type = type; this.detail = init?.detail; } },
    gOne: async (store, id) => rows.get(`${store}:${id}`) || null,
    gAll: async store => [...rows.entries()].filter(([key]) => key.startsWith(`${store}:`)).map(([, row]) => ({ ...row })),
    dPut: async (store, row) => { rows.set(`${store}:${row.id}`, { ...row }); },
    dDel: async (store, id) => rows.delete(`${store}:${id}`),
    document: { getElementById: () => null },
    console,
  };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../modules/centralSync.js'), 'utf8'), context);
  return { sync: window.centralSync, rows, events, window };
}

test('immediate 409 is preserved, shown as a conflict, and not retried by flush', async () => {
  const err = Object.assign(new Error('Insufficient stock. Available: 2'), { statusCode: 409, body: { error: 'Insufficient stock' } });
  let calls = 0;
  const { sync, rows, events } = harness(async () => { calls++; throw err; });
  const result = await sync.submit({ id: 'tx1', itemId: 'p1', qty: 5 });
  assert.equal(result.conflict, true);
  assert.equal(rows.get('central_queue:tx1').status, 'conflict');
  assert.equal(rows.get('central_queue:tx1').conflictBody.error, 'Insufficient stock');
  assert.equal(events[0].type, 'central-sync-conflict');
  await sync.flushQueue();
  assert.equal(calls, 1);
});

test('resolution requires a new ID and same item, then deletes original only after accepted response', async () => {
  const { sync, rows } = harness(async () => ({ ok: true }));
  await sync.submit({ id: 'old', itemId: 'p1', qty: 5 });
  // Seed as a conflict directly; the successful adapter above makes initial submit succeed.
  rows.set('central_queue:old', { id: 'old', transaction: { id: 'old', itemId: 'p1', qty: 5 }, status: 'conflict' });
  await assert.rejects(sync.resolveConflict('old', { id: 'old', itemId: 'p1', qty: 2 }), /new transaction ID/);
  await assert.rejects(sync.resolveConflict('old', { id: 'new', itemId: 'p2', qty: 2 }), /cannot change the original material/);
  assert.equal(rows.has('central_queue:old'), true);
  const result = await sync.resolveConflict('old', { id: 'new', itemId: 'p1', qty: 2 });
  assert.equal(result.resolvedFrom, 'old');
  assert.equal(rows.has('central_queue:old'), false);
});

test('conflicts can be explicitly discarded and invalid corrected quantities are rejected', async () => {
  const { sync, rows } = harness(async () => ({ ok: true }));
  rows.set('central_queue:c', { id: 'c', transaction: { id: 'c', itemId: 'p' }, status: 'conflict' });
  await assert.rejects(sync.resolveConflict('c', { id: 'n', itemId: 'p', qty: -1 }), /positive quantity/);
  assert.equal((await sync.discardConflict('c')).ok, true);
  assert.equal(rows.has('central_queue:c'), false);
});

test('terminal retry failure is persisted and emits one user-notification event', async () => {
  const { sync, rows, events } = harness(async () => { throw new Error('fetch failed'); });
  rows.set('central_queue:terminal', { id: 'terminal', transaction: { id: 'terminal', itemId: 'p1', qty: 1 }, status: 'queued', attempts: 0, nextAttemptAt: 0 });
  for (let i = 0; i < 10; i++) {
    await sync.flushQueue();
    const item = rows.get('central_queue:terminal');
    if (item.status !== 'failed') item.nextAttemptAt = 0;
    rows.set('central_queue:terminal', item);
  }
  assert.equal(rows.get('central_queue:terminal').status, 'failed');
  assert.equal(rows.get('central_queue:terminal').attempts, 10);
  assert.equal(events.filter(event => event.type === 'central-sync-failed').length, 1);
  await sync.flushQueue();
  assert.equal(events.filter(event => event.type === 'central-sync-failed').length, 1);
});

test('central health identifies current device and app version and retains local sync cursor', async () => {
  const { sync, rows, window } = harness(async () => ({ ok: true }));
  window.centralBridge.getStatus = async () => ({ configured: true, online: true, user: 'operator', deviceId: 'STORE-PC-4', appVersion: '5.0.0', lastSequence: 8, latencyMs: 12 });
  await sync.writeMeta({ lastSequence: 11, lastSyncAt: '2026-11-13T00:00:00.000Z' });
  const health = await sync.checkHealth();
  assert.equal(health.deviceId, 'STORE-PC-4');
  assert.equal(health.appVersion, '5.0.0');
  assert.equal(health.user, 'operator');
  assert.equal(health.lastSequence, 11);
  assert.equal(health.lastSyncAt, '2026-11-13T00:00:00.000Z');
  assert.equal(rows.get('central_meta:central-sync').deviceId, 'STORE-PC-4');
});

test('sync queue accessor returns queued, conflicted, and failed records for a unified status view', async () => {
  const { sync, rows } = harness(async () => ({ ok: true }));
  for (const status of ['queued', 'conflict', 'failed']) {
    rows.set(`central_queue:${status}`, { id: status, status, transaction: { id: status } });
  }
  const items = await sync.getQueueItems();
  assert.deepEqual(items.map(item => item.status).sort(), ['conflict', 'failed', 'queued']);
});

test('conflict view compares local data with the latest central stock/version and labels rejection text as historical', async () => {
  const host = { innerHTML: '', textContent: '' };
  const escapeHtml = value => String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const context = {
    document: { getElementById: id => id === 'central-conflict-list' ? host : null },
    window: {
      location: { hostname: 'STORE-PC-4' },
      centralHealth: { deviceId: 'STORE-PC-4' },
      centralBridge: { getMaterials: async () => ({ materials: [{ id: 'p1', name: 'Bearing', stock: 1, version: 8, updatedAt: '2026-11-16T18:00:00.000Z' }] }) },
      centralSync: { getQueueItems: async () => [
        { id: 'tx-queued', status: 'queued', transaction: { itemId: 'p1', itemName: 'Bearing', qty: 2, deviceId: 'STORE-PC-4' } },
        { id: 'tx-conflict', status: 'conflict', lastError: 'Insufficient stock. Available: 0', conflictBody: { error: 'Insufficient stock. Available: 0' }, conflictAt: '2026-11-16T17:00:00.000Z', transaction: { itemId: 'p1', itemName: 'Bearing', qty: 5, deviceId: 'STORE-PC-4' } },
        { id: 'tx-failed', status: 'failed', lastError: '<network unavailable>', transaction: { itemId: 'p1', qty: 1 } },
      ] },
    },
    M: [{ id: 'p1', name: 'Bearing', stock: 3, version: 4, updatedAt: '2026-11-15T12:00:00.000Z' }],
    sanitizeHTML: escapeHtml,
  };
  await vm.runInNewContext(`${extractAppFunction('fetchLatestCentralMaterials')}\n${extractAppFunction('renderCentralConflicts')}\nrenderCentralConflicts();`, context);
  assert.match(host.innerHTML, /Latest central record/);
  assert.match(host.innerHTML, /Stock 3 · version 4/);
  assert.match(host.innerHTML, /Stock 1 · version 8/);
  assert.match(host.innerHTML, /stock delta \(central − local\): -2/);
  assert.match(host.innerHTML, /version 4 → 8/);
  assert.match(host.innerHTML, /Insufficient stock\. Available: 0/);
  assert.match(host.innerHTML, /historical response, not current stock/);
  assert.match(host.innerHTML, /Waiting to sync/);
  assert.match(host.innerHTML, /Conflict — review required/);
  assert.match(host.innerHTML, /Failed — manual retry available/);
  assert.match(host.innerHTML, /STORE-PC-4/);
  assert.match(host.innerHTML, /&lt;network unavailable&gt;/);
  assert.match(host.innerHTML, /Correct qty &amp; retry/);
});

test('conflict view handles a missing central read API without showing stale data as current or enabling correction', async () => {
  const host = { innerHTML: '', textContent: '' };
  const context = {
    document: { getElementById: id => id === 'central-conflict-list' ? host : null },
    window: { centralSync: { getQueueItems: async () => [{ id: 'tx-c', status: 'conflict', lastError: 'Old server reply', conflictBody: { error: 'Old server reply' }, transaction: { itemId: 'p1', qty: 5 } }] } },
    M: [{ id: 'p1', stock: 2, version: 1 }],
    sanitizeHTML: value => String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'),
  };
  await vm.runInNewContext(`${extractAppFunction('fetchLatestCentralMaterials')}\n${extractAppFunction('renderCentralConflicts')}\nrenderCentralConflicts();`, context);
  assert.match(host.innerHTML, /Latest central record/);
  assert.match(host.innerHTML, /Unavailable — The desktop bridge does not expose/);
  assert.match(host.innerHTML, /Not compared — a fresh central read failed/);
  assert.match(host.innerHTML, /Old server reply/);
  assert.doesNotMatch(host.innerHTML, /Correct qty &amp; retry/);
  assert.match(host.innerHTML, /Discard/);
});

test('conflict view distinguishes a fresh central response that contains no matching material', async () => {
  const host = { innerHTML: '', textContent: '' };
  const context = {
    document: { getElementById: id => id === 'central-conflict-list' ? host : null },
    window: { centralBridge: { getMaterials: async () => ({ materials: [] }) }, centralSync: { getQueueItems: async () => [{ id: 'tx-c', status: 'conflict', transaction: { itemId: 'missing', qty: 1 } }] } },
    M: [{ id: 'missing', stock: 0, version: 2 }],
    sanitizeHTML: value => String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'),
  };
  await vm.runInNewContext(`${extractAppFunction('fetchLatestCentralMaterials')}\n${extractAppFunction('renderCentralConflicts')}\nrenderCentralConflicts();`, context);
  assert.match(host.innerHTML, /No matching material in the latest central response/);
  assert.doesNotMatch(host.innerHTML, /Correct qty &amp; retry/);
});

test('conflict correction fetches fresh central stock/version and refuses to proceed when that read fails', async () => {
  let prompts = 0, resolutions = 0, warning = '';
  let payload = null;
  const item = { id: 'old-tx', status: 'conflict', transaction: { id: 'old-tx', itemId: 'p1', qty: 5, type: 'OUT', itemName: 'Bearing' } };
  const context = {
    window: {
      centralBridge: { getMaterials: async () => ({ materials: [{ id: 'p1', stock: 1, version: 8, updatedAt: '2026-11-16T18:00:00.000Z' }] }) },
      centralSync: { getConflictQueueItems: async () => [item], resolveConflict: async (_id, corrected) => { resolutions++; payload = corrected; }, checkHealth: async () => ({}) },
    },
    M: [{ id: 'p1', stock: 3, version: 4 }],
    document: { getElementById: () => null },
    sanitizeHTML: String,
    prompt: message => { prompts++; assert.match(message, /central record: stock 1, version 8/); assert.match(message, /Local record: stock 3, version 4/); return '2'; },
    confirm: message => { assert.match(message, /rechecks current stock at commit time/); return true; },
    generateUUID: () => 'new-tx-id',
    toast: message => { warning = message; },
    renderCentralConflicts: async () => {},
  };
  await vm.runInNewContext(`${extractAppFunction('fetchLatestCentralMaterials')}\n${extractAppFunction('resolveCentralConflict')}\nresolveCentralConflict('old-tx');`, context);
  assert.equal(prompts, 1);
  assert.equal(resolutions, 1);
  assert.equal(payload.id, 'new-tx-id');
  assert.equal(payload.itemId, 'p1');
  assert.equal(payload.qty, 2);
  assert.equal(warning, 'Corrected transaction submitted');

  const blocked = { ...context, window: { centralBridge: {}, centralSync: { getConflictQueueItems: async () => [item], resolveConflict: async () => { throw new Error('must not resolve'); } } }, prompt: () => { prompts++; return '1'; }, toast: message => { warning = message; } };
  await vm.runInNewContext(`${extractAppFunction('fetchLatestCentralMaterials')}\n${extractAppFunction('resolveCentralConflict')}\nresolveCentralConflict('old-tx');`, blocked);
  assert.equal(prompts, 1);
  assert.match(warning, /Cannot safely resolve conflict without the latest central material\/version/);
});

test('health UI clearly presents the current device, app version, central user, and last successful sync', () => {
  const elements = { 'central-status': { textContent: '', style: {} }, 'central-health-details': { textContent: '' }, 'central-device-details': { textContent: '' } };
  const context = {
    document: { getElementById: id => elements[id] || null },
    window: { location: { hostname: 'STORE-PC-4' } },
    cu: { username: 'operator' },
  };
  vm.runInNewContext(`${extractAppFunction('renderCentralHealth')}\nrenderCentralHealth({state:'online',deviceId:'STORE-PC-4',appVersion:'5.0.0',user:'operator',lastSyncAt:'2026-11-13T00:00:00.000Z',queueCount:2,checkedAt:'2026-11-13T01:00:00.000Z'});`, context);
  assert.match(elements['central-device-details'].textContent, /STORE-PC-4/);
  assert.match(elements['central-device-details'].textContent, /5\.0\.0/);
  assert.match(elements['central-device-details'].textContent, /operator/);
  assert.match(elements['central-device-details'].textContent, /2026/);
  assert.match(elements['central-health-details'].textContent, /Pending sync records: 2/);
});
