const fs = require('fs');
const source = fs.readFileSync(require.resolve('../modules/componentManagement.js'), 'utf8');

describe('LH/RH merged bin station resolution regression', () => {
  test('dashboard can recover station from mapping when the stock bin row is missing/stale', () => {
    expect(source).toContain('const mappingStations = [...new Set(state.mappings.filter(m => m && String(m.binId || \'\') === String(s.binId || \'\')');
    expect(source).toContain('const stationCandidates = mappingStations.length ? mappingStations :');
    expect(source).toContain('const resolvedStations = stationCandidates.map(candidate => displayStationForBin(candidate, s.binId))');
  });

  test('merged bins preserve the requested RH/LH station identity', () => {
    expect(source).toContain('const mergedStations = Array.isArray(bin.mergedStations) ? bin.mergedStations : [];');
    expect(source).toContain('mergedStations.some(station => sameStation(station, direct))');
  });

  test('existing mappings, stock and transactions are reconciled to the canonical merged bin', () => {
    expect(source).toContain('async function reconcileRhLhCommonBinReferences()');
    expect(source).toContain('mapping.binId = canonicalBinId;');
    expect(source).toContain('row.binId = canonicalBinId;');
    expect(source).toContain('tx.binId = canonicalBinId;');
    expect(source).toContain('if (!bin || bin.binKind || String(bin.binId || \'\') === canonicalBinId) return;');
  });

  test('reconciliation runs during component initialization', () => {
    expect(source).toContain('await migrateExistingRhLhCommonBins(); await load(); await reconcileRhLhCommonBinReferences();');
  });

  test('rollback restores both source and target bin snapshots', () => {
    expect(source).toContain('if (history.sourceBin) {await dPut(STORES.bins, history.sourceBin);}');
    expect(source).toContain('if (history.targetBin) {await dPut(STORES.bins, history.targetBin);}');
  });

  test('inactive merged source bins are hidden from Bin Management and exports but retained for rollback', () => {
    const start = source.indexOf('function bins() {');
    const end = source.indexOf('function pencilBins', start);
    const binView = source.slice(start, end);
    expect(binView).toContain("const commonBins = state.bins.filter(bin => bin.binKind !== 'PENCIL_PAIR' && bin.active !== false);");
    expect(source).toContain("state.bins.filter(b => b.binKind !== 'PENCIL_PAIR' && b.active !== false).map(b => [b.binId,b.stationNo,b.location,'ACTIVE'])");
    expect(source).toContain('source.active = false;');
    expect(source).toContain('source.mergedInto = mergedBinId;');
    expect(source).toContain('sourceBins: sourceBins.map(bin => ({ ...bin }))');
  });
});

describe('LH/RH automatic Common Bin merge regression', () => {
  test('unmerged RH and LH stations do not resolve to the opposite side bin', () => {
    const lookup = source.slice(source.indexOf('function activeBinForStation'), source.indexOf('function displayStationForBin'));
    expect(lookup).toContain('const exact = state.bins.find(bin => bin.active !== false && sameStation(bin.stationNo, requested));');
    expect(lookup).toContain('const legacyCommon = state.bins.find');
    expect(lookup).toContain('return legacyCommon || null;');
    expect(lookup).not.toContain('return state.bins.find(bin => bin.active !== false && baseStationKey(bin.stationNo) === key) || null;');
  });

  test('legacy one-bin RH/LH data recovers the missing empty source bin only with shared mapping evidence', () => {
    expect(source).toContain('async function recoverLegacySharedRhLhSourceBins()');
    expect(source).toContain('if (activeSideBins.length !== 1) {continue;}');
    expect(source).toContain('if (!hasSharedMappingFor(rhStation) || !hasSharedMappingFor(lhStation)) {continue;}');
    expect(source).toContain('legacyRecoveredSource: true');
    expect(source).toContain('await recoverLegacySharedRhLhSourceBins();');
  });

  test('Excel import automatically runs LH/RH consolidation before final refresh', () => {
    expect(source).toContain('const autoRhLhMerges = await migrateExistingRhLhCommonBins();');
    expect(source).toContain('await reconcileRhLhCommonBinReferences();');
    expect(source).toContain('Auto LH/RH Common Bin merges: ${autoRhLhMerges || 0}');
  });

  test('automatic merge persists the same Common Bin metadata used by manual merge', () => {
    expect(source).toMatch(/mode:\s*'COMMON_BIN',\s*automatic:\s*true,/);
    expect(source).toContain('target.mergedStations = [...new Set([...(target.mergedStations || []), rh.stationNo, lh.stationNo])]');
    expect(source).toContain('binId: mergedBinId,');
    expect(source).toContain('name: `${baseStationName(rh.stationNo)} RH/LH Common Bin`,');
    expect(source).toContain('target.name = `${baseStationName(rh.stationNo)} RH/LH Common Bin`;');
    expect(source).toMatch(/await audit\(\s*'COMPONENT_COMMON_BIN_MERGE',\s*'Bin',\s*mergedBinId,\s*\{\s*source:\s*`\$\{rh\.stationNo\} \+ \$\{lh\.stationNo\}`\s*,\s*target:\s*target\.stationNo,\s*automatic:\s*true,/);
  });

  test('automatic merge keeps rollback snapshots for all source bins', () => {
    expect(source).toContain('sourceBins: sourceBins.map(bin => ({ ...bin }))');
    expect(source).toContain('for (const sourceBin of history.sourceBins)');
    expect(source).toContain('if (history.targetBinCreated && history.targetBin?.id) {await dDel(STORES.bins, history.targetBin.id);}');
  });
});
