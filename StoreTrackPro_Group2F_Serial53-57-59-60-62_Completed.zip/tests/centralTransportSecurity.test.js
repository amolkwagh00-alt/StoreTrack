const fs = require('fs');
const path = require('path');
const vm = require('vm');

const mainSource = fs.readFileSync(path.join(__dirname, '..', 'main.js'), 'utf8');
function extractFunction(name) {
  const start = mainSource.indexOf(`function ${name}(`);
  if (start < 0) { throw new Error(`Missing function ${name} in main.js`); }
  const bodyMarker = mainSource.indexOf(') {', start);
  if (bodyMarker < 0) { throw new Error(`Missing body for ${name}`); }
  let depth = 0;
  for (let index = bodyMarker + 2; index < mainSource.length; index++) {
    if (mainSource[index] === '{') { depth++; }
    if (mainSource[index] === '}' && --depth === 0) { return mainSource.slice(start, index + 1); }
  }
  throw new Error(`Unclosed function ${name}`);
}
function loadValidator() {
  const context = { URL, process: { env: {} } };
  vm.createContext(context);
  vm.runInContext(extractFunction('validateCentralServiceUrl'), context);
  return context.validateCentralServiceUrl;
}

describe('central-service transport security', () => {
  const validate = loadValidator();

  test('production rejects plaintext HTTP, including loopback', () => {
    expect(() => validate('http://central.example.test', 'production')).toThrow(/loopback development/);
    expect(() => validate('http://127.0.0.1:8080', 'production')).toThrow(/loopback development/);
  });

  test('HTTPS is accepted in production and normalized', () => {
    expect(validate('https://central.example.test/api/', 'production')).toBe('https://central.example.test/api');
  });

  test('development permits plaintext HTTP only on loopback hosts', () => {
    expect(validate('http://localhost:8080', 'development')).toBe('http://localhost:8080');
    expect(validate('http://127.0.0.1:8080', 'development')).toBe('http://127.0.0.1:8080');
    expect(validate('http://[::1]:8080', 'development')).toBe('http://[::1]:8080');
    expect(() => validate('http://central.example.test', 'development')).toThrow(/loopback development/);
    expect(() => validate('http://192.168.1.4:8080', 'development')).toThrow(/loopback development/);
  });

  test('URLs with embedded credentials and non-HTTP schemes are rejected', () => {
    expect(() => validate('https://user:secret@central.example.test', 'production')).toThrow(/embedded credentials/);
    expect(() => validate('ftp://central.example.test', 'production')).toThrow(/HTTP or HTTPS/);
  });

  test('authenticated HTTP and WebSocket paths validate transport before sending credentials', () => {
    expect(mainSource).toMatch(/async function centralRequest\([^]*?validateCentralServiceUrl\(centralConfig\.baseUrl\);[^]*?headers\.authorization/);
    expect(mainSource).toMatch(/function connectCentralStream\(\) \{[^]*?validateCentralServiceUrl\(centralConfig\.baseUrl\);[^]*?new WebSocket/);
    expect(mainSource).toMatch(/secureHandle\('central:configure',[^]*?baseUrl = validateCentralServiceUrl\(baseUrl\)/);
  });
});
