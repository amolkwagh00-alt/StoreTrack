const { _electron: electron } = require('playwright');
const path = require('path');

(async () => {
  const projectDir = path.resolve(__dirname, '..');
  const app = await electron.launch({ args: [projectDir], timeout: 30000 });
  const window = await app.firstWindow();
  const consoleLines = [];
  window.on('console', msg => consoleLines.push(`[${msg.type()}] ${msg.text()}`));
  await window.waitForLoadState('domcontentloaded');
  await window.waitForSelector('#lu', { state: 'visible', timeout: 30000 });
  await window.fill('#lu', 'admin');
  await window.fill('#lp', 'Admin@1234');
  await window.click('.btn-login');
  await window.waitForFunction(() => document.getElementById('app')?.classList.contains('visible'), null, { timeout: 15000 });
  const result = await window.evaluate(() => ({
    appVisible: document.getElementById('app')?.classList.contains('visible'),
    loginVisible: getComputedStyle(document.getElementById('login-wrap')).display !== 'none',
    user: document.getElementById('sb-nm')?.textContent,
    error: document.getElementById('lerr')?.textContent,
  }));
  console.log(JSON.stringify(result));
  consoleLines.filter(line => line.includes('[doLogin]')).forEach(line => console.log(line));
  await app.close();
  if (!result.appVisible || result.loginVisible) process.exit(1);
})().catch(error => {
  console.error(error.stack || error.message);
  process.exitCode = 1;
});
