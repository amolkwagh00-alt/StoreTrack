const fs = require('fs');
const path = require('path');

describe('central server contract', () => {
  const root = path.join(__dirname, '..');
  test('central API files and deployment assets exist', () => {
    for (const file of [
      'server/index.js',
      'server/db.js',
      'server/auth.js',
      'server/migrate.js',
      'server/create-admin.js',
      'server/import-backup.js',
      'server/docker-compose.yml',
      'server/DEPLOYMENT.md',
    ]) {
      expect(fs.existsSync(path.join(root, file))).toBe(true);
    }
  });
  test('offline stores are declared in the IndexedDB module', () => {
    const source = fs.readFileSync(path.join(root, 'modules/database.js'), 'utf8');
    expect(source).toContain("'central_queue'");
    expect(source).toContain("'central_meta'");
    expect(source).toContain('const VER = 23');
  });
  test('central Gun Count API uses the shared occurrence calculator contract', () => {
    const source = fs.readFileSync(path.join(root, 'server/index.js'), 'utf8');
    expect(source).toContain("require('../core/gunCountService')");
    expect(source).toContain("'/api/gun-count'");
    expect(source).toContain(
      'GunCountService.calculateMetrics(payload.sourceRows, payload.mappingRows)',
    );
  });

  test('central health endpoint exposes server timing metadata', () => {
    const source = fs.readFileSync(path.join(root, 'server/index.js'), 'utf8');
    expect(source).toContain('serverTime: new Date().toISOString()');
    expect(source).toContain('uptimeSeconds: Math.floor(process.uptime())');
    expect(source).toContain('version: process.env.npm_package_version ||');
  });

  test('client central sync monitors health and reports latency', () => {
    const source = fs.readFileSync(path.join(root, 'modules', 'centralSync.js'), 'utf8');
    expect(source).toContain('function checkHealth()');
    expect(source).toContain('if (healthFlight) return healthFlight;');
    expect(source).toContain('latencyMs');
    expect(source).toContain('healthTimer = setInterval(checkHealth, 30000);');
    expect(source).toContain('central-health-update');
  });

  test('Electron exposes the central bridge and renderer loads central sync', () => {
    expect(fs.readFileSync(path.join(root, 'preload.js'), 'utf8')).toContain(
      "exposeInMainWorld('centralBridge'",
    );
    expect(fs.readFileSync(path.join(root, 'index.html'), 'utf8')).toContain(
      'modules/centralSync.js',
    );
  });
});
