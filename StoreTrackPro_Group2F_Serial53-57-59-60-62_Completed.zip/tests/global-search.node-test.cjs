'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
function extract(source,name){const start=source.indexOf(`function ${name}(`);assert.notEqual(start,-1);const open=source.indexOf('{',start);let depth=0,quote=null,escaped=false;for(let i=open;i<source.length;i++){const c=source[i];if(quote){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c===quote)quote=null;continue;}if(c==='"'||c==="'"||c==='`'){quote=c;continue;}if(c==='{')depth++;else if(c==='}'&&--depth===0)return source.slice(start,i+1);}throw Error('Unclosed function');}
const app=fs.readFileSync(path.join(__dirname,'../app.js'),'utf8');
test('global search covers material, supplier, bin/station and transaction references with escaped rendering',()=>{
 const input={value:'press'};const drop={style:{},innerHTML:'',querySelectorAll:()=>[]};
 const safe=value=>String(value??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
 const context={document:{getElementById:id=>id==='gsearch'?input:id==='gsdrop'?drop:null},M:[{name:'Press <img>',barcode:'P-1',category:'Tools',stock:2,unit:'pc'}],SP:[{name:'Press Supplier',phone:'123'}],LOCS:[{name:'B-1',binCode:'press-bin',stationName:'Press Line'}],T:[{id:'TX-1',itemName:'Press Bolt',type:'OUT',barcode:'P-2',job:'press-job',status:'confirmed'}],sanitizeHTML:safe,Date,Number,Array,Set,console,setTimeout,nav(){},renderMaster(){},renderHist(){},renderLocs(){}};
 vm.runInNewContext(`let globalSearchResults=[]; ${extract(app,'doGSearch')}; doGSearch(); result=globalSearchResults;`,context);
 assert.ok(context.result.some(row=>row.kind==='material'));
 assert.ok(context.result.some(row=>row.kind==='supplier'));
 assert.ok(context.result.some(row=>row.kind==='location'));
 assert.ok(context.result.some(row=>row.kind==='transaction'));
 assert.doesNotMatch(drop.innerHTML, /<img>/);
 assert.match(drop.innerHTML,/&lt;img&gt;/);
});
