// Real integration tests — verify modules that are supposed to work together
// actually do, unlike tests/integrationTests.js (an unused custom framework
// class with no real test cases ever registered in it).
require('fake-indexeddb/auto');

const { initDB, dPut, gAll, dClr } = require('../modules/database.js');
const { validateSchema, SCHEMAS } = require('../modules/validation.js');
const { encryptBackup, decryptBackup } = require('../modules/encryption.js');

describe('Integration: database + validation', () => {
  beforeAll(async () => {
    await initDB();
  });
  afterEach(async () => {
    await dClr('materials');
  });

  test('a material passing validation can actually be saved and re-read from the database', async () => {
    const material = {
      barcode: 'BC1001',
      name: 'Bearing 6205',
      currentStock: 25,
      minStock: 5,
      maxStock: 100,
    };
    const check = validateSchema(material, SCHEMAS.material);
    expect(check.valid).toBe(true);

    await dPut('materials', material);
    const all = await gAll('materials');
    expect(all.find((m) => m.barcode === 'BC1001')).toBeDefined();
  });

  test('a material failing validation should not be treated as save-worthy by app.js callers', async () => {
    const badMaterial = { barcode: '', name: 'X', currentStock: -5 };
    const check = validateSchema(badMaterial, SCHEMAS.material);
    expect(check.valid).toBe(false);
  });
});

describe('Integration: database + encryption (full backup export/import cycle)', () => {
  beforeAll(async () => {
    await initDB();
  });
  afterEach(async () => {
    await dClr('materials');
  });

  test('data saved to the database can be exported as an encrypted backup and fully restored', async () => {
    await dPut('materials', { barcode: 'BC-2002', name: 'Gasket', stock: 10 });
    const before = await gAll('materials');

    const plainText = JSON.stringify({ M: before });
    const password = 'FactoryBackup2026';
    const pkg = await encryptBackup(plainText, password);

    await dClr('materials'); // simulate a fresh machine with no data
    expect(await gAll('materials')).toEqual([]);

    const restoredText = await decryptBackup(pkg, password);
    const restoredData = JSON.parse(restoredText);
    for (const m of restoredData.M) {
      await dPut('materials', m);
    }

    const after = await gAll('materials');
    expect(after).toEqual(before);
  });
});
