const fs = require('fs');
const path = require('path');

describe('enterprise truthful AI/BI features', () => {
  beforeEach(() => {
    window.gAll = jest.fn(
      async (store) =>
        ({
          materials: [{ id: 1, name: 'Bolt', barcode: 'B1', unit: 'Pcs', stock: 2, lowAlert: 5 }],
          transactions: [
            { id: 't1', type: 'OUT', qty: 3, itemId: 1, time: new Date().toISOString() },
          ],
          approvals: [{ id: 'a1', status: 'pending', time: new Date().toISOString() }],
          grn: [],
          suppliers: [],
          component_parts: [],
          component_stock: [],
          component_replacements: [],
        })[store] || [],
    );
    window.dPut = jest.fn(async () => undefined);
    window.enterpriseTruthful = undefined;
    const source = fs.readFileSync(
      path.join(__dirname, '..', 'modules', 'enterpriseTruthfulFeatures.js'),
      'utf8',
    );
    window.eval(source);
  });

  test('blocks invalid and duplicate CSV rows without importing', () => {
    const result = window.enterpriseTruthful.importPreview(
      'barcode,name,unit\nB1,Bolt,Pcs\nB1,Duplicate,Pcs\n,Broken,Pcs',
    );
    expect(result.canImport).toBe(false);
    expect(result.duplicateBarcodes).toContain('B1');
    expect(result.invalidRows.length).toBeGreaterThan(0);
    expect(window.dPut).not.toHaveBeenCalled();
  });

  test('returns actual low-stock rows for a supported report', async () => {
    const result = await window.enterpriseTruthful.report('low stock');
    expect(result.title).toBe('Low stock');
    expect(result.rows).toHaveLength(1);
    expect(result.source.records).toBe(1);
  });

  test('refuses unsupported natural-language reports instead of inventing a query', async () => {
    const result = await window.enterpriseTruthful.report('show me anything interesting');
    expect(result.rows).toHaveLength(0);
    expect(result.title).toBe('Unsupported report request');
  });
});
