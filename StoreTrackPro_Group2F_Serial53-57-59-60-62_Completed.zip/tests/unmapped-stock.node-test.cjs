'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
function extract(source,name){const start=source.indexOf(`function ${name}(`);assert.notEqual(start,-1);const open=source.indexOf('{',start);let depth=0,quote=null,escaped=false;for(let i=open;i<source.length;i++){const c=source[i];if(quote){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c===quote)quote=null;continue;}if(c==='"'||c==="'"||c==='`'){quote=c;continue;}if(c==='{')depth++;else if(c==='}'&&--depth===0)return source.slice(start,i+1);}throw Error(`Unclosed ${name}`);}
const app=fs.readFileSync(path.join(__dirname,'../app.js'),'utf8');
test('unmapped stock report detects unresolved confirmed movements but ignores mapped/non-stock rows',()=>{
 const context={};
 vm.runInNewContext(`${extract(app,'findUnmappedStockTransactions')}; result=findUnmappedStockTransactions([
  {id:'ok-id',itemId:'1',type:'OUT',status:'confirmed'},
  {id:'ok-barcode',barcode:' ab-1 ',type:'IN',status:'confirmed'},
  {id:'lost-id',itemId:'gone',barcode:'gone-bc',type:'OUT',status:'confirmed',qty:2},
  {id:'pending',type:'OUT',status:'pending'},
  {id:'adjust',type:'ADJUST',status:'confirmed'}
 ],[{id:1,barcode:'AB-1'}]);`,context);
 assert.deepEqual(JSON.parse(JSON.stringify(context.result.map(row=>row.id))),['lost-id']);
});
test('diagnostics report is read-only and clearly scopes its limitations',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');
 assert.match(html,/Unmapped Stock Movements/);
 assert.match(app,/does not validate the central server/);
 assert.match(app,/do not delete or rewrite ledger entries from this report/);
});
