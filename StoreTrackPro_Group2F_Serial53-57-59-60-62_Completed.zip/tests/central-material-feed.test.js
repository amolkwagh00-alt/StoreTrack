const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const server = fs.readFileSync(path.join(root, 'server/index.js'), 'utf8');
const clientSource = fs.readFileSync(path.join(root, 'modules/centralSync.js'), 'utf8');

describe('central material sync regressions', () => {
  test('material upsert writes its material event in the same transaction', () => {
    const start = server.indexOf("if (req.method === 'POST' && url.pathname === '/api/materials')");
    const end = server.indexOf("if (req.method === 'POST' && url.pathname === '/api/gun-count')", start);
    const handler = server.slice(start, end);
    expect(handler).toContain("await client.query('BEGIN')");
    expect(handler).toContain('ON CONFLICT (id) DO UPDATE');
    expect(handler).toContain('version=materials.version+1');
    expect(handler).toContain("INSERT INTO sync_events(event_id, entity_type, entity_id, action, payload)");
    expect(handler).toContain("'material.upserted'");
    expect(handler).toContain('payload) VALUES($1,\'material\',$2,\'material.upserted\',$3)');
    expect(handler).toContain('await client.query(\'COMMIT\')');
    expect(handler).toContain('await client.query(\'ROLLBACK\')');
  });

  test('feed scans beyond hidden scoped events and returns the scanned cursor', () => {
    const start = server.indexOf("if (req.method === 'GET' && url.pathname === '/api/sync/changes')");
    const end = server.indexOf("if (req.method === 'POST' && url.pathname === '/api/transactions/stock')", start);
    const handler = server.slice(start, end);
    expect(handler).toContain('while (visible.length < requestedLimit)');
    expect(handler).toContain('cursor = event.sequence');
    expect(handler).toContain('if (eventVisibleToUser(event, user)) visible.push(event)');
    expect(handler).toContain('{ changes: visible, cursor }');
  });

  test('polling client persists an advanced cursor even when intervening events are invisible', () => {
    expect(clientSource).toContain('const cursor = Number(result.cursor)');
    expect(clientSource).toContain('if (Number.isFinite(cursor) && cursor > current) await writeMeta({ lastSequence: cursor })');
    expect(clientSource).toContain('if (change.payload?.material) await applyMaterial(change.payload.material)');
  });

  test('a second client can receive material upserts through the sync feed', () => {
    const start = server.indexOf("if (req.method === 'POST' && url.pathname === '/api/materials')");
    const end = server.indexOf("if (req.method === 'POST' && url.pathname === '/api/gun-count')", start);
    const handler = server.slice(start, end);
    expect(handler).toContain("INSERT INTO sync_events(event_id, entity_type, entity_id, action, payload)");
    expect(handler).toContain('[crypto.randomUUID(), String(material.id), { material }]');
    expect(clientSource).toContain('if (change.payload?.material) await applyMaterial(change.payload.material)');
  });
});
