'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
function extractFunction(source, name) {
  const match = source.match(new RegExp(`(?:async\\s+)?function\\s+${name}\\s*\\(`));
  assert.ok(match, `missing ${name}`);
  const start = match.index;
  const closeParen = source.indexOf(')', start);
  const open = source.indexOf('{', closeParen);
  let depth = 0;
  for (let i = open; i < source.length; i += 1) {
    if (source[i] === '{') depth += 1;
    if (source[i] === '}') { depth -= 1; if (!depth) return source.slice(start, i + 1); }
  }
  throw new Error(`unclosed ${name}`);
}
function fields(values) {
  return Object.fromEntries(Object.entries(values).map(([id, value]) => [id, { value }]));
}

test('Serial 36 filters audit records by action, entity, user, module and inclusive date range', () => {
  const fn = extractFunction(app, 'filteredAuditRows');
  const context = {
    A: [
      { id: 1, time: '2026-11-01T10:00:00Z', action: 'CREATE', module: 'USER', user: 'alice', userName: 'Alice', resource: 'material', resourceId: 'MAT-1', details: 'created bearing' },
      { id: 2, time: '2026-11-03T10:00:00Z', action: 'UPDATE', module: 'SYSTEM', user: 'alice', userName: 'Alice', resource: 'material', resourceId: 'MAT-1', details: 'updated bearing' },
    ],
    document: { getElementById: id => context._fields[id] || { value: '' } },
    _fields: fields({ 'flt-aud-act': 'create', 'flt-aud-ent': 'MAT-1', 'flt-aud-tp': 'USER', 'flt-aud-us': 'alice', 'flt-aud-from': '2026-11-01', 'flt-aud-to': '2026-11-01', 'srch-aud': '' }),
    Date,
  };
  vm.runInNewContext(`${fn}; filteredAuditRows=filteredAuditRows;`, context);
  assert.deepEqual(context.filteredAuditRows().map(row => row.id), [1]);
});

test('Serial 37 audit export is filtered and protected by both audit-view and export permissions', () => {
  assert.match(html, /data-onclick="exportCSV\('audit'\)"/);
  assert.match(app, /canRoleAction\('auditTrail'\).*canRoleAction\('pdfExcelExport'\)/);
  assert.match(app, /Export scope: all matching entries/);
  assert.match(app, /filteredAuditRows\(\)/);
});

test('Serial 40 renders unresolved count, reason and retry guidance in one sync summary', () => {
  const fn = extractFunction(app, 'renderCentralSyncSummary');
  const host = { innerHTML: '' };
  const context = { document: { getElementById: id => id === 'central-sync-summary' ? host : null }, sanitizeHTML: value => String(value).replace(/[&<>]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch])) };
  vm.runInNewContext(`${fn}; renderCentralSyncSummary=renderCentralSyncSummary;`, context);
  context.renderCentralSyncSummary({ queueCount: 4, queueDetails: [{ status: 'failed', error: 'Timeout' }, { status: 'conflict', error: 'Stock conflict' }], error: 'Network unavailable' });
  assert.match(host.innerHTML, /Unresolved: <b>4<\/b>/);
  assert.match(host.innerHTML, /Network unavailable/);
  assert.match(host.innerHTML, /Retry Pending Sync/);
  assert.match(app, /notifyUser\('Central Sync Failed'/);
});

test('Serial 41 supports per-alert account and role targets and sync_failure preferences', () => {
  assert.match(html, /id="alert-pref-scope"/);
  assert.match(html, /value="sync_failure"/);
  assert.match(app, /`role:\${role}`/);
  assert.match(app, /getPreferencesForUser\(`role:\${String\(cu\.role\|\|'\'\)}`\)/);
  assert.match(app, /eventType:type/);
  assert.match(app, /setUserNotificationPreference\(target/);
});

test('Serial 41 applies role preferences to automated alert recipients, with explicit user preference precedence', () => {
  const source = fs.readFileSync(path.join(root, 'modules', 'automatedAlerts.js'), 'utf8');
  const start = source.indexOf('function alertRecipientId(');
  const end = source.indexOf('/**\n * Global automated alerts manager instance', start);
  const context = {};
  vm.runInNewContext(source.slice(start, end), context);
  const prefs = [
    { userId: 'role:store', channel: 'email', eventType: 'stock_low', enabled: false },
    { userId: 'alice', channel: 'email', eventType: 'stock_low', enabled: true },
  ];
  const manager = { getPreferencesForUser: id => prefs.filter(pref => pref.userId === id) };
  const recipients = [{ userId: 'bob', role: 'store' }, { userId: 'alice', role: 'store' }];
  assert.deepEqual(context.resolveAlertRecipients({ eventType: 'stock_low', recipients }, 'email', manager).map(row => row.userId), ['alice']);
});
