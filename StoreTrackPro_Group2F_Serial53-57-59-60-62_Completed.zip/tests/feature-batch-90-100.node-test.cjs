'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ROOT = path.resolve(__dirname, '..');

function extractFunction(source, name) {
  const start = new RegExp(`(?:async\\s+)?function\\s+${name}\\s*\\(`).exec(source);
  assert.ok(start, `Missing function ${name}`);
  const signatureOpen = source.indexOf('(', start.index);
  let parentheses = 0;
  let signatureQuote = null;
  let signatureEscaped = false;
  let signatureClose = -1;
  for (let i = signatureOpen; i < source.length; i += 1) {
    const char = source[i];
    if (signatureQuote) {
      if (signatureEscaped) signatureEscaped = false;
      else if (char === '\\') signatureEscaped = true;
      else if (char === signatureQuote) signatureQuote = null;
      continue;
    }
    if (char === '"' || char === "'" || char === '`') { signatureQuote = char; continue; }
    if (char === '(') parentheses += 1;
    else if (char === ')' && --parentheses === 0) { signatureClose = i; break; }
  }
  assert.ok(signatureClose >= 0, `Unclosed signature ${name}`);
  const open = source.indexOf('{', signatureClose);
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let i = open; i < source.length; i += 1) {
    const char = source[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (char === '\\') escaped = true;
      else if (char === quote) quote = null;
      continue;
    }
    if (char === '"' || char === "'" || char === '`') { quote = char; continue; }
    if (char === '{') depth += 1;
    else if (char === '}' && --depth === 0) return source.slice(start.index, i + 1);
  }
  throw new Error(`Unclosed function ${name}`);
}

test('CSV export chunks work, reports progress, safely cancels before download, and can retry a failed download', async () => {
  const app = fs.readFileSync(path.join(ROOT, 'app.js'), 'utf8');
  const dom = {
    'csv-export-progress': { style: {} },
    'csv-export-progress-bar': { value: 0 },
    'csv-export-progress-text': { textContent: '' },
    'csv-export-cancel': { style: {} },
    'csv-export-retry': { style: {} },
  };
  let downloads = [];
  let failDownloadOnce = false;
  let context;
  const helpers = ['serializeCSVRows', 'renderCsvExportStatus', 'startCSVExport', 'cancelCsvExport', 'retryCsvExport']
    .map(name => extractFunction(app, name)).join('\n');
  const source = `function csvCell(value){let text=String(value==null?'':value);if(typeof value!=='number'){let index=0;while(index<text.length&&(/\\s/.test(text[index])||text.charCodeAt(index)<=0x1f))index++;if(/^[=+\\-@]/.test(text.slice(index)))text="'"+text;}return '"'+text.replace(/"/g,'""')+'"';} let currentCsvExportJob=null; let lastCsvExportRetry=null; ${helpers}`;
  context = vm.createContext({
    document: { getElementById: id => dom[id] || null },
    _dlCSV: (csv, filename) => { if (failDownloadOnce) { failDownloadOnce = false; throw new Error('disk unavailable'); } downloads.push({ csv, filename }); },
    toast() {},
    setTimeout,
    Math,
    String,
  });
  vm.runInContext(source, context);
  const rows = [['Name', 'Formula'], ...Array.from({ length: 501 }, (_, i) => [`Item ${i + 1}`, '=1+1'])];
  assert.equal(await context.startCSVExport(rows, 'stock.csv'), true);
  assert.equal(downloads.length, 1);
  assert.match(downloads[0].csv, /'=1\+1/);
  assert.match(dom['csv-export-progress-text'].textContent, /502 rows/);
  assert.equal(dom['csv-export-progress-bar'].value, 100);

  let timerCount = 0;
  context.setTimeout = callback => {
    timerCount += 1;
    if (timerCount === 1) queueMicrotask(() => context.cancelCsvExport());
    return setTimeout(callback, 0);
  };
  assert.equal(await context.startCSVExport(rows, 'cancelled.csv'), false);
  assert.equal(downloads.length, 1, 'cancelled export must not create a partial file');
  assert.match(dom['csv-export-progress-text'].textContent, /cancelled/i);
  assert.equal(dom['csv-export-retry'].style.display, '');

  context.setTimeout = setTimeout;
  failDownloadOnce = true;
  assert.equal(await context.startCSVExport([['Header'], ['Value']], 'retry.csv'), false);
  assert.match(dom['csv-export-progress-text'].textContent, /Export failed/);
  await context.retryCsvExport();
  assert.equal(downloads.length, 2);
  assert.equal(downloads[1].filename, 'retry.csv');
});

test('Shank import progress helper clamps values and commit reports progress instead of exposing a false cancel action', () => {
  const moduleSource = fs.readFileSync(path.join(ROOT, 'modules/componentManagement.js'), 'utf8');
  const elements = {
    'cm-import-progress-bar': { value: 0, max: 0 },
    'cm-import-progress-text': { textContent: '' },
  };
  const context = vm.createContext({
    document: {
      getElementById: id => elements[id] || null,
      querySelector: selector => selector.includes('componentCancelImportProcessing') ? { disabled: false, textContent: '', setAttribute() {} } : null,
    },
    Math,
    Number,
    String,
  });
  vm.runInContext(`${extractFunction(moduleSource, 'updateImportProgress')}; ${extractFunction(moduleSource, 'setImportCommitState')};`, context);
  context.updateImportProgress(140, 'Saving rows');
  assert.equal(elements['cm-import-progress-bar'].max, 100);
  assert.equal(elements['cm-import-progress-bar'].value, 100);
  assert.equal(elements['cm-import-progress-text'].textContent, 'Saving rows');
  let cancelButton;
  context.document.querySelector = () => (cancelButton = { disabled: false, textContent: '', setAttribute() {} });
  context.setImportCommitState(true);
  assert.equal(cancelButton.disabled, true);
  assert.match(cancelButton.textContent, /cancel unavailable/i);
  assert.match(moduleSource, /Saving \$\{rowIndex \+ 1\} of \$\{pendingImport\.rows\.length\} rows/);
  assert.match(moduleSource, /componentGetImportProgress = \(\) => \(\{ progress: pendingImport\?\.commitProgress/);
  assert.match(moduleSource, /async function exportExcel\(filename, sheetName, headers, rows\)/);
  assert.match(moduleSource, /async function exportPdfTable\(title, headers, rows\)/);
  assert.match(moduleSource, /window\.componentCancelExport = cancelComponentExport/);
  assert.match(moduleSource, /window\.componentRetryExport = retryComponentExport/);
});

async function loadMigrationStatus(appliedRows) {
  const pgPool = { query: async () => ({ rows: appliedRows }) };
  const moduleObject = { exports: {} };
  const context = vm.createContext({
    module: moduleObject,
    process: { env: {} },
    require: name => name === 'pg' ? { Pool: class { constructor() { return pgPool; } } } : require(name),
    Date,
    Buffer,
    console,
  });
  vm.runInContext(fs.readFileSync(path.join(ROOT, 'server/db.js'), 'utf8'), context);
  return moduleObject.exports.getMigrationStatus();
}

test('central migration diagnostics distinguish pending and current versions without running migrations', async () => {
  const pending = await loadMigrationStatus([{ version: '001_central_schema', applied_at: '2026-01-01T00:00:00Z' }]);
  assert.equal(pending.source, 'central-postgresql');
  assert.equal(pending.currentVersion, '001_central_schema');
  assert.equal(pending.migrationPending, true);
  assert.ok(pending.pendingVersions.includes('005_session_version'));

  const expected = ['001_central_schema', '002_roles', '003_case_insensitive_usernames', '004_idempotency_retention', '005_session_version'];
  const current = await loadMigrationStatus(expected.map(version => ({ version, applied_at: '2026-01-01T00:00:00Z' })));
  assert.equal(current.migrationPending, false);
  assert.equal(current.currentVersion, '005_session_version');
  assert.deepEqual(JSON.parse(JSON.stringify(current.pendingVersions)), []);

  const route = fs.readFileSync(path.join(ROOT, 'server/index.js'), 'utf8');
  assert.match(route, /GET' && url\.pathname === '\/api\/admin\/migrations'[\s\S]*?requireRole\(user, \['developer', 'admin'\]\)[\s\S]*?getMigrationStatus\(\)/);
  assert.match(fs.readFileSync(path.join(ROOT, 'main.js'), 'utf8'), /central:getMigrationStatus.*\/api\/admin\/migrations/);
  assert.match(fs.readFileSync(path.join(ROOT, 'preload.js'), 'utf8'), /getMigrationStatus: \(\) => ipcRenderer\.invoke\('central:getMigrationStatus'\)/);
  const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  assert.match(html, /Check Central Migrations[\s\S]*?id="diag-central-migrations"/);
});
