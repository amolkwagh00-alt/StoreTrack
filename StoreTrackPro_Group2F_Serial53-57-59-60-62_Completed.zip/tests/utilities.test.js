// Unit tests for utilities module

const {
  sanitizeHTML,
  sanitizeText,
  escapeHTML,
  sanitizeNumber,
  sanitizeInteger,
  sanitizeBarcode,
  isValidEmail,
  isValidPhone,
  isSafeURL,
  generateUUID,
} = require('../modules/utilities.js');
// debounce lives in its own file (moved out of utilities.js to avoid duplication — see modules/utilities.js:124)
const { debounce } = require('../modules/debounce.js');

describe('Utilities Module', () => {
  describe('sanitizeHTML', () => {
    test('should sanitize HTML to prevent XSS', () => {
      const input = '<script>alert("xss")</script>Hello';
      const result = sanitizeHTML(input);
      expect(result).not.toContain('<script>');
      expect(result).toContain('Hello');
    });

    test('should return empty string for non-string input', () => {
      expect(sanitizeHTML(null)).toBe('');
      expect(sanitizeHTML(undefined)).toBe('');
      expect(sanitizeHTML(123)).toBe('');
      expect(sanitizeHTML({})).toBe('');
    });

    test('should handle empty string', () => {
      expect(sanitizeHTML('')).toBe('');
    });
  });

  describe('sanitizeText', () => {
    test('should remove HTML tags', () => {
      const input = '<p>Hello <b>World</b></p>';
      const result = sanitizeText(input);
      expect(result).toBe('Hello World');
    });

    test('should trim whitespace', () => {
      const input = '  Hello World  ';
      const result = sanitizeText(input);
      expect(result).toBe('Hello World');
    });

    test('should return empty string for non-string input', () => {
      expect(sanitizeText(null)).toBe('');
      expect(sanitizeText(123)).toBe('');
    });
  });

  describe('escapeHTML', () => {
    test('should escape HTML special characters', () => {
      const input = '<script>&"\'';
      const result = escapeHTML(input);
      expect(result).toContain('&lt;');
      expect(result).toContain('&gt;');
      expect(result).toContain('&amp;');
      expect(result).toContain('&quot;');
      expect(result).toContain('&#039;');
    });

    test('should return empty string for non-string input', () => {
      expect(escapeHTML(null)).toBe('');
      expect(escapeHTML(123)).toBe('');
    });
  });

  describe('sanitizeNumber', () => {
    test('should sanitize valid number', () => {
      expect(sanitizeNumber('42')).toBe(42);
      expect(sanitizeNumber('3.14')).toBe(3.14);
    });

    test('should clamp to min and max', () => {
      expect(sanitizeNumber(150, 0, 100)).toBe(100);
      expect(sanitizeNumber(-10, 0, 100)).toBe(0);
    });

    test('should return default for invalid input', () => {
      expect(sanitizeNumber('abc')).toBe(0);
      expect(sanitizeNumber(null, 0, 100, 5)).toBe(5);
    });
  });

  describe('sanitizeInteger', () => {
    test('should return integer', () => {
      expect(sanitizeInteger('3.7')).toBe(3);
      expect(sanitizeInteger('42')).toBe(42);
    });

    test('should clamp to min and max', () => {
      expect(sanitizeInteger(150, 0, 100)).toBe(100);
    });
  });

  describe('sanitizeBarcode', () => {
    test('should remove non-alphanumeric characters', () => {
      expect(sanitizeBarcode('ABC-123!@#')).toBe('ABC123');
    });

    test('should convert to uppercase', () => {
      expect(sanitizeBarcode('abc123')).toBe('ABC123');
    });

    test('should return empty string for non-string input', () => {
      expect(sanitizeBarcode(null)).toBe('');
      expect(sanitizeBarcode(123)).toBe('');
    });
  });

  describe('isValidEmail', () => {
    test('should validate correct email format', () => {
      expect(isValidEmail('test@example.com')).toBe(true);
      expect(isValidEmail('user.name@domain.co.uk')).toBe(true);
    });

    test('should reject invalid email format', () => {
      expect(isValidEmail('invalid')).toBe(false);
      expect(isValidEmail('@example.com')).toBe(false);
      expect(isValidEmail('test@')).toBe(false);
      expect(isValidEmail('test example.com')).toBe(false);
    });
  });

  describe('isValidPhone', () => {
    test('should validate correct phone format', () => {
      expect(isValidPhone('1234567890')).toBe(true);
      expect(isValidPhone('(123) 456-7890')).toBe(true);
      expect(isValidPhone('123-456-7890')).toBe(true);
    });

    test('should reject invalid phone format', () => {
      expect(isValidPhone('123')).toBe(false);
      expect(isValidPhone('abc')).toBe(false);
    });
  });

  describe('isSafeURL', () => {
    test('should accept safe protocols', () => {
      expect(isSafeURL('http://example.com')).toBe(true);
      expect(isSafeURL('https://example.com')).toBe(true);
      expect(isSafeURL('data:image/png;base64,abc')).toBe(true);
    });

    test('should reject unsafe protocols', () => {
      expect(isSafeURL('javascript:alert(1)')).toBe(false);
      expect(isSafeURL('file:///etc/passwd')).toBe(false);
    });

    test('should reject invalid URLs', () => {
      expect(isSafeURL('not-a-url')).toBe(false);
    });
  });

  describe('generateUUID', () => {
    test('should generate valid UUID v4 format', () => {
      const uuid = generateUUID();
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
      expect(uuid).toMatch(uuidRegex);
    });

    test('should generate unique UUIDs', () => {
      const uuid1 = generateUUID();
      const uuid2 = generateUUID();
      expect(uuid1).not.toBe(uuid2);
    });
  });

  describe('debounce', () => {
    test('should debounce function calls', (done) => {
      let count = 0;
      const fn = debounce(() => {
        count++;
      }, 100);

      fn();
      fn();
      fn();

      expect(count).toBe(0);

      setTimeout(() => {
        expect(count).toBe(1);
        done();
      }, 150);
    });

    test('should execute immediately with immediate flag', (done) => {
      let count = 0;
      const fn = debounce(
        () => {
          count++;
        },
        100,
        true,
      );

      fn();
      expect(count).toBe(1);

      setTimeout(() => {
        fn();
        expect(count).toBe(2);
        done();
      }, 150);
    });
  });
});
