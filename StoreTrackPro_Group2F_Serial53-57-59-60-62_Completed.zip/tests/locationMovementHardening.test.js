const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

function extractFunction(source, declaration) {
  const escaped = declaration.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const match = source.match(new RegExp(`${escaped}\\{[\\s\\S]*?\\n\\}`));
  if (!match) { throw new Error(`Function not found: ${declaration}`); }
  return match[0];
}

function movementHarness({ quantity = '', writeError = null, from = 'A-R1-B1' } = {}) {
  const elements = {
    'mov-item': { value: '101' },
    'mov-to': { value: 'B-R2-B2' },
    'mov-from': { value: from },
    'mov-qty': { value: quantity },
    'mov-reason': { value: 'reorganization' },
  };
  const document = { getElementById: (id) => elements[id] || null };
  const M = [{ id: 101, name: 'Shank', barcode: 'S-101', unit: 'pcs', stock: 10, lowAlert: 1, active: true, binLocationId: 1 }];
  const LOCS = [
    { id: 1, zone: 'A', rack: 'R1', bin: 'B1', capacity: 20 },
    { id: 2, zone: 'B', rack: 'R2', bin: 'B2', capacity: 20 },
  ];
  const MOVS = [];
  const writes = [];
  const messages = [];
  const window = { dPutMany: async (batch) => { writes.push(batch); if (writeError) { throw writeError; } } };
  const fnSource = extractFunction(app, 'async function confirmMove()');
  const confirmMove = new Function('document', 'M', 'LOCS', 'MOVS', 'locCode', 'toast', 'window', 'cu', 'addAudit', 'clrMove', 'renderLocs', 'renderLocStock', 'renderMovHist', `return (${fnSource});`)(
    document, M, LOCS, MOVS, (l) => `${l.zone}-${l.rack}-${l.bin}`, (message) => messages.push(message), window,
    { username: 'auditor', name: 'Auditor' }, async () => {}, () => {}, () => {}, () => {}, () => {},
  );
  return { confirmMove, M, MOVS, writes, messages };
}

describe('Bin Location movement integrity', () => {
  test.each(['0', 'abc', '-1'])('rejects explicitly invalid movement quantity %s instead of interpreting it as all stock', async (quantity) => {
    const h = movementHarness({ quantity });
    await h.confirmMove();
    expect(h.writes).toHaveLength(0);
    expect(h.M[0].binLocationId).toBe(1);
  });

  test('rejects partial movement because a material currently has only one persisted location', async () => {
    const h = movementHarness({ quantity: '2' });
    await h.confirmMove();
    expect(h.writes).toHaveLength(0);
    expect(h.messages.join(' ')).toContain('Partial location movement is not supported');
  });

  test('commits full-stock location change and movement history in one transaction', async () => {
    const h = movementHarness();
    await h.confirmMove();
    expect(h.writes).toHaveLength(1);
    expect(h.writes[0].map((entry) => entry.store)).toEqual(['materials', 'movements']);
    expect(h.writes[0][0].obj.binLocationId).toBe(2);
    expect(h.writes[0][1].obj.qty).toBe(10);
    expect(h.M[0].binLocationId).toBe(2);
    expect(h.MOVS).toHaveLength(1);
  });

  test('database failure leaves both in-memory location and movement history unchanged', async () => {
    const h = movementHarness({ writeError: new Error('simulated transaction failure') });
    await h.confirmMove();
    expect(h.M[0].binLocationId).toBe(1);
    expect(h.MOVS).toHaveLength(0);
    expect(h.messages.join(' ')).toContain('Movement failed');
  });

  test('prevents deleting any location still referenced by a material', async () => {
    const fnSource = extractFunction(app, 'async function delLoc(id)');
    const material = { id: 101, binLocationId: '1' };
    const locations = [{ id: 1, zone: 'A', rack: 'R1', bin: 'B1' }];
    const messages = [];
    let deleted = false;
    const delLoc = new Function('LOCS', 'M', 'locCode', 'toast', 'confirm', 'dDel', 'renderLocs', 'popLocSelects', 'canRoleAction', `return (${fnSource});`)(
      locations, [material], () => 'A-R1-B1', (message) => messages.push(message), () => true,
      async () => { deleted = true; }, () => {}, () => {},
      () => true,
    );
    await delLoc(1);
    expect(deleted).toBe(false);
    expect(messages.join(' ')).toContain('still reference this Bin Location');
  });

  test('populates material Bin suggestions at startup and escapes user-controlled location output', () => {
    expect(app).toContain('await loadAll();await seedData();popLocSelects();');
    expect(app).toContain('${sanitizeHTML(String(code||\'\'))}');
    expect(app).toContain('${sanitizeHTML(String(mv.itemName||\'\'))}');
    expect(app).toContain('${sanitizeHTML(String(m.name||\'\'))}');
    expect(app).toContain('${sanitizeHTML(String(co))}');
    expect(html).toContain('partial moves are not supported');
  });
});
