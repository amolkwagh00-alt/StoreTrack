#!/usr/bin/env node
// Real smoke test — verifies the app is in a launchable state without actually
// opening an Electron window (no display available in CI). Checks:
//   1. index.html exists and every <script src="modules/..."> it references
//      actually exists on disk (a missing file here means a blank white screen
//      on launch — the single most common way this kind of app breaks).
//   2. Every module/core JS file plus app.js and main.js parses without a
//      syntax error.
//   3. package.json itself is valid JSON.
// This intentionally does NOT hit a staging/production URL — this is a
// downloadable Electron desktop app, not a hosted web service.
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const root = path.join(__dirname, '..');
let failures = 0;

function fail(msg) {
  console.error('✗ ' + msg);
  failures++;
}
function ok(msg) {
  console.log('✓ ' + msg);
}

// 1. package.json parses
try {
  JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  ok('package.json is valid JSON');
} catch (e) {
  fail('package.json failed to parse: ' + e.message);
}

// 2. index.html exists, and every referenced modules/*.js file exists
const indexPath = path.join(root, 'index.html');
if (!fs.existsSync(indexPath)) {
  fail('index.html is missing');
} else {
  const html = fs.readFileSync(indexPath, 'utf8');
  const scriptRefs = [...html.matchAll(/<script src="(modules\/[^\"]+)"/g)].map(
    (m) => m[1].split('?')[0],
  );
  let missing = 0;
  for (const ref of scriptRefs) {
    if (!fs.existsSync(path.join(root, ref))) {
      fail('index.html references missing file: ' + ref);
      missing++;
    }
  }
  if (missing === 0) {
    ok(`all ${scriptRefs.length} module <script> references in index.html resolve to real files`);
  }
}

// 3. every JS file the app actually loads parses cleanly
const jsFiles = [];
function collect(dir) {
  for (const f of fs.readdirSync(dir)) {
    const full = path.join(dir, f);
    if (fs.statSync(full).isDirectory()) {
      if (!['node_modules', '.git', 'StoreTrackData', 'Scanner'].includes(f)) {
        collect(full);
      }
    } else if (f.endsWith('.js')) {
      jsFiles.push(full);
    }
  }
}
collect(path.join(root, 'modules'));
collect(path.join(root, 'core'));
jsFiles.push(path.join(root, 'app.js'), path.join(root, 'main.js'), path.join(root, 'preload.js'));

let syntaxErrors = 0;
for (const f of jsFiles) {
  try {
    execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' });
  } catch (e) {
    fail('syntax error in ' + path.relative(root, f) + ': ' + e.stderr.toString().split('\n')[0]);
    syntaxErrors++;
  }
}
if (syntaxErrors === 0) {
  ok(`all ${jsFiles.length} app JS files parse without syntax errors`);
}

console.log('');
if (failures > 0) {
  console.error(`SMOKE TEST FAILED: ${failures} problem(s) found`);
  process.exit(1);
} else {
  console.log('SMOKE TEST PASSED — app is in a launchable state');
  process.exit(0);
}
