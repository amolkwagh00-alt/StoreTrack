// Focused dependency-free StoreTrack regressions for original findings 101–120.
// These execute extracted production functions with controlled Node mocks; they are not Electron, IndexedDB, Playwright, or production-runtime tests.
// Run: node --test tests/storetrack-batch5-101-120.node-test.cjs
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = process.env.STORETRACK_ROOT || path.resolve(__dirname, '..');
const cm = fs.readFileSync(path.join(ROOT, 'modules/componentManagement.js'), 'utf8');
const ui = fs.readFileSync(path.join(ROOT, 'modules/shankConsumptionAnalyticsUI.js'), 'utf8');
const biSource = fs.readFileSync(path.join(ROOT, 'modules/shankMappingBIProduction.js'), 'utf8');
const pmSource = fs.readFileSync(path.join(ROOT, 'modules/pm.js'), 'utf8');

function extractFunction(source, name) {
  const match = new RegExp(`(?:async\\s+)?function\\s+${name}\\s*\\(`).exec(source);
  assert.ok(match, `function ${name} exists`);
  const open = source.indexOf('(', match.index); let parens = 0, quote = '', escape = false, close = -1;
  for (let i = open; i < source.length; i += 1) {
    const c = source[i];
    if (quote) { if (escape) escape = false; else if (c === '\\') escape = true; else if (c === quote) quote = ''; continue; }
    if (c === "'" || c === '"' || c === '`') { quote = c; continue; }
    if (c === '(') parens += 1; else if (c === ')' && --parens === 0) { close = i; break; }
  }
  assert.ok(close >= 0, `${name} signature closes`);
  const bodyOpen = source.indexOf('{', close); let depth = 0, state = 'code', escaped = false, lineComment = false, blockComment = false; const interpolations = [];
  for (let i = bodyOpen; i < source.length; i += 1) {
    const c = source[i], n = source[i + 1];
    if (lineComment) { if (c === '\n') lineComment = false; continue; }
    if (blockComment) { if (c === '*' && n === '/') { blockComment = false; i += 1; } continue; }
    if (state === 'single' || state === 'double') { if (escaped) escaped = false; else if (c === '\\') escaped = true; else if ((state === 'single' && c === "'") || (state === 'double' && c === '"')) state = 'code'; continue; }
    if (state === 'template') { if (escaped) escaped = false; else if (c === '\\') escaped = true; else if (c === '`') state = 'code'; else if (c === '$' && n === '{') { depth += 1; interpolations.push(depth); state = 'code'; i += 1; } continue; }
    if (c === '/' && n === '/') { lineComment = true; i += 1; continue; }
    if (c === '/' && n === '*') { blockComment = true; i += 1; continue; }
    if (c === "'") { state = 'single'; continue; } if (c === '"') { state = 'double'; continue; } if (c === '`') { state = 'template'; continue; }
    if (c === '{') depth += 1; else if (c === '}') { depth -= 1; if (interpolations.length && depth === interpolations[interpolations.length - 1] - 1) { interpolations.pop(); state = 'template'; continue; } if (depth === 0) return source.slice(match.index, i + 1); }
  }
  throw new Error(`Could not find end of ${name}`);
}
function makeContext(source, names, globals = {}) {
  const ctx = vm.createContext(globals);
  vm.runInContext(names.map(name => extractFunction(source, name)).join('\n'), ctx, { timeout: 3000 });
  return ctx;
}
const esc = value => String(value == null ? '' : value);
const sameStation = (a, b) => String(a || '').toLowerCase().replace(/[^a-z0-9]/g, '') === String(b || '').toLowerCase().replace(/[^a-z0-9]/g, '');

// 101 — bin-location changes must stop before prompting/writing when the bin capability is denied.
test('P29-F05 denied bin capability blocks Edit Bin dialog and mutation', async () => {
  const events = [];
  const ctx = makeContext(cm, ['editBin'], {
    canComponent: capability => { events.push(['capability', capability]); return false; },
    state: { bins: [{ id: 'b1', location: 'Rack A' }] },
    componentInputDialog: async () => { events.push(['dialog']); return 'Rack B'; },
    dPut: async () => events.push(['write']), audit: async () => events.push(['audit'])
  });
  await ctx.editBin('b1');
  assert.deepEqual(JSON.parse(JSON.stringify(events)), [['capability', 'bin']]);
});

// 102 — the rendered row set and the initial summary use the same active common-bin collection.
test('P29-F06 initial Common Bin summary excludes inactive and Pencil bins', () => {
  let html = '';
  const ctx = makeContext(cm, ['bins'], {
    state: { bins: [{ binId: 'COMMON-1', stationNo: 'S1', active: true }, { binId: 'OLD-1', stationNo: 'S2', active: false }, { binId: 'PENCIL-1', stationNo: 'S3', active: true, binKind: 'PENCIL_PAIR' }], gunRows: [], mappings: [] },
    normalStation: value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, ''),
    binGunAllocations: () => '', stationVariantKey: value => String(value || '').toLowerCase(),
    calculateGunCount: () => 0, gunCountMetrics: () => ({ source: 0, mapped: 0, allocated: 0, unassigned: 0 }),
    validMappedPartNo: value => Boolean(value), esc, btn: label => `<button>${label}</button>`,
    table: (_headers, rows) => rows, shell: (_title, body) => { html = body; }
  });
  ctx.bins();
  assert.match(html, /Showing 1 of 1/);
  assert.match(html, /COMMON-1/);
  assert.doesNotMatch(html, /OLD-1|PENCIL-1/);
});

// 103 — lifecycle page wording agrees with the persisted terminal status.
test('P30-F01 Repair page names the terminal status as Returned to Stock', () => {
  let body = '';
  const ctx = makeContext(cm, ['repair'], {
    state: { repairs: [{ id: 'r1', partNo: 'PN-1', stationNo: 'S1', gunReferenceNo: 'G1', status: 'RETURNED TO STOCK', reason: 'Used', username: 'Tech' }] },
    partDisplayWithComment: value => String(value),
    esc, btn: label => `<button>${label}</button>`, table: (_headers, rows) => rows,
    shell: (_title, value) => { body = value; }
  });
  ctx.repair();
  assert.match(body, /Returned to Stock/);
  assert.match(body, /RETURNED TO STOCK/);
  assert.doesNotMatch(body, /Repair Completed → Available/);
});

// 104 — concurrent activations during a slow atomic write commit one stock transaction only.
test('P30-F02 rapid duplicate Repair Return submits only one atomic transaction', async () => {
  let release; const gate = new Promise(resolve => { release = resolve; });
  const stock = { id: 'stock1', partNo: 'PN-1', binId: 'BIN-1', quantity: 4, minimumStock: 1 };
  const lifecycle = { id: 'life1', partNo: 'PN-1', stationNo: 'S1', gunReferenceNo: 'G1', quantity: 2, status: 'REPAIR COMPLETED' };
  const commits = []; let id = 0;
  const ctx = makeContext(cm, ['repairReturn'], {
    repairReturnInProgress: new Set(), canComponent: () => true,
    state: { repairs: [lifecycle], stock: [stock], bins: [], tx: [] },
    lifecyclePartIdentityValid: () => true, isPencilPart: () => false, partKey: value => String(value).toLowerCase(),
    activeBinForStation: () => ({ binId: 'BIN-1' }), partByNo: () => ({ minimumStock: 1 }),
    autoSafetyQuantity: () => 1, stockFor: () => stock, statusFor: () => 'OK',
    STORES: { stock: 'stock', tx: 'tx', repair: 'repair', audit: 'audit' },
    uid: prefix => `${prefix}-${++id}`, nowIso: () => '2026-10-10T00:00:00.000Z',
    user: () => ({ id: 'u1', username: 'tester' }), window: { atomicReadModifyWrite: async (storeName, key, derive) => { const outcome = derive(lifecycle, { stock }); commits.push(outcome.writes); await gate; return outcome.record; } },
    toastMsg() {}, load: async () => {}, repair() {}
  });
  const first = ctx.repairReturn('life1');
  const duplicate = ctx.repairReturn('life1');
  await duplicate;
  assert.equal(commits.length, 1);
  release(); await first;
  assert.equal(commits.length, 1);
  assert.equal(commits[0].filter(row => row.store === 'tx').length, 1);
  assert.equal(ctx.state.stock[0].quantity, 6);
  assert.equal(ctx.state.repairs[0].status, 'RETURNED TO STOCK');
});

// 105 — table filtering and export both accept the visible partial Station and Gun terms.
test('P31-F01 visible History rows and exported rows agree on partial Station and Gun filters', () => {
  const inputs = { 'ch-filter': '', 'ch-type-filter': 'ALL', 'ch-part-filter': '', 'ch-station-filter': 'north', 'ch-gun-filter': '04', 'ch-from-date': '', 'ch-to-date': '' };
  const matching = { id: 'match', stationNo: 'Station North-12', gunReferenceNo: 'Gun-04', replacementDate: '2026-10-01' };
  const excluded = { id: 'excluded', stationNo: 'Station South-12', gunReferenceNo: 'Gun-04', replacementDate: '2026-10-01' };
  const domRows = [matching, excluded].map(value => ({
    dataset: { historyType: 'LIVE', historyPart: '', historyStation: value.stationNo, historyGun: value.gunReferenceNo },
    cells: [{ textContent: value.replacementDate }], textContent: JSON.stringify(value), style: {}
  }));
  const makeDoc = () => ({ getElementById: id => ({ value: inputs[id] ?? '' }), querySelectorAll: () => domRows });
  const filter = makeContext(cm, ['filterHistory'], { document: makeDoc(), sameStation, componentRefreshPager() {} });
  filter.filterHistory('');
  const exportCtx = makeContext(cm, ['historyExportRows'], { document: makeDoc(), state: { replacements: [matching, excluded], historicalConsumption: [] }, sameStation });
  const visibleIds = domRows.filter(row => row.style.display !== 'none').map(row => row.dataset.historyStation);
  const exportIds = exportCtx.historyExportRows().map(row => row.stationNo);
  assert.deepEqual(visibleIds, ['Station North-12']);
  assert.deepEqual(JSON.parse(JSON.stringify(exportIds)), visibleIds);
});

// 106 — explicit replacement linkage prevents tuple collisions in drill-down.
test('P31-F02 drill-down includes only transactions explicitly linked to that replacement', () => {
  let body = '';
  const ctx = makeContext(cm, ['replacementDrillDown'], {
    state: {
      replacements: [{ id: 'rep-A', oldPartNo: 'OLD', newPartNo: 'NEW', stationNo: 'S1', gunReferenceNo: 'G1', quantity: 1 }],
      repairs: [],
      tx: [
        { id: 'tx-A', type: 'Replacement / Issue', date: '2026-01-01', direction: 'OUT', quantity: 1, metadata: { id: 'rep-A' } },
        { id: 'tx-B', type: 'Replacement / Issue', date: '2026-01-02', direction: 'OUT', quantity: 1, metadata: { id: 'rep-B' } }
      ]
    }, esc, partDisplayWithComment: value => String(value), table: (_headers, rows) => rows, shell: (_title, value) => { body = value; }
  });
  ctx.replacementDrillDown('rep-A');
  assert.match(body, /2026-01-01/);
  assert.doesNotMatch(body, /2026-01-02/);
});

// 107 — direct reports rendering enforces both view and report capability checks.
test('P32-F01 Reports renderer blocks a role with Shank Mapping view denied', () => {
  const calls = []; let rendered = false;
  const ctx = makeContext(cm, ['reports'], {
    canComponent: capability => { calls.push(capability); return capability !== 'view'; },
    shell: () => { rendered = true; }
  });
  ctx.reports();
  assert.deepEqual(JSON.parse(JSON.stringify(calls)), ['view']);
  assert.equal(rendered, false);
});

// 108 — saved transaction business date is the user's selected replacement date/time.
test('P32-F02 backdated replacement writes its selected date into accounting transaction', async () => {
  const values = {
    'cr-person': 'Tech', 'cr-part': 'NEW-PART', 'cr-old-part': 'OLD-PART', 'cr-station': 'ST-1', 'cr-gun': 'G-1', 'cr-component': 'Fix Shank',
    'cr-bin': 'BIN-1', 'cr-qty': '2', 'cr-date': '2025-01-31', 'cr-time': '23:45', 'cr-shift': '1st Shift', 'cr-condition': 'Used', 'cr-action': 'Repair',
    'cr-team': 'Maintenance', 'cr-remarks': 'Backdated audit entry'
  };
  const fields = Object.keys(values).map(key => ({ value: values[key] }));
  const stock = { id: 'stock1', partNo: 'NEW-PART', binId: 'BIN-1', quantity: 5, minimumStock: 1 };
  const state = { people: [{ id: 'tech1', name: 'Tech' }], mappings: [{ partNo: 'NEW-PART', stationNo: 'ST-1', gunReferenceNo: 'G-1', position: 'Fix Shank' }], bins: [{ binId: 'BIN-1' }], stock: [stock], tx: [], replacements: [], repairs: [] };
  let writeRows = []; let uid = 0;
  const ctx = makeContext(cm, ['saveReplacement'], {
    canComponent: () => true, state, val: id => String(values[id] ?? '').trim(), sel: id => values[id] ?? '',
    knownComponentPartNo: () => true, SHIFTS: ['1st Shift'], CONDITIONS: ['Used'], ACTIONS: ['Repair'],
    partKey: value => String(value).toLowerCase(), sameStation, normalGunReference: value => String(value).toLowerCase(),
    isPencilPart: () => false, activeBinForStation: () => ({ binId: 'BIN-1' }), replacementMappingMatchesBin: () => true,
    stockFor: () => stock, statusFor: () => 'LOW', user: () => ({ id: 'u1', username: 'tester' }), partByNo: () => ({ componentType: 'Copper Shank' }),
    uid: prefix => `${prefix}-${++uid}`, nowIso: () => '2026-10-10T00:00:00.000Z', STORES: { stock: 'stock', tx: 'tx', replacements: 'replacements', repair: 'repair', audit: 'audit' },
    window: { dPutMany: async rows => { writeRows = rows; } }, toastMsg() {}, open() {}
  });
  await ctx.saveReplacement();
  const transaction = writeRows.find(row => row.store === 'tx')?.obj;
  assert.equal(transaction.date, '2025-01-31T23:45:00');
  assert.equal(writeRows.find(row => row.store === 'replacements')?.obj.replacementDateTime, transaction.date);
});

// 109 — a reopened close record can be locked again despite retaining its historical closedAt timestamp.
test('P32-F03 reopened month can be closed again as a fresh CLOSED state', async () => {
  const close = { id: 'close-2026-02', month: '2026-02', balances: { 'PN-1': 4 }, closedAt: '2026-03-01T00:00:00Z', status: 'CLOSED' };
  const state = { monthCloses: [close] }; const writes = []; const messages = [];
  const globals = {
    canComponent: () => true, state, confirm: () => true, user: () => ({ id: 'u1' }), nowIso: () => '2026-10-10T00:00:00Z', today: () => '2026-10-10',
    STORES: { monthCloses: 'monthCloses' }, dPut: async (store, row) => writes.push([store, row]), audit: async () => {},
    toastMsg: value => messages.push(value), reports() {}
  };
  const ctx = makeContext(cm, ['reopenMonth', 'closeMonth'], globals);
  await ctx.reopenMonth('2026-02');
  assert.equal(state.monthCloses[0].status, 'REOPENED');
  await ctx.closeMonth('2026-02');
  assert.equal(state.monthCloses[0].status, 'CLOSED');
  assert.equal(writes.length, 2);
  assert.equal(messages.some(value => /already locked/.test(value)), false);
});

// 110 — evaluate the actual date-only helper under a west-of-UTC process timezone.
test('P32-F04 calendar month end retains the final date in a west-of-UTC timezone', () => {
  const helperLine = cm.split('\n').find(line => line.includes('const calendarMonthEndDate ='));
  assert.ok(helperLine);
  const start = helperLine.indexOf('const calendarMonthEndDate =') + 'const calendarMonthEndDate ='.length;
  const expression = helperLine.slice(start, helperLine.lastIndexOf(';')).trim();
  const dateOnly = vm.runInNewContext(`(${expression})`);
  const previousTZ = process.env.TZ;
  try {
    process.env.TZ = 'America/Los_Angeles';
    assert.equal(dateOnly('2024-02'), '2024-02-29');
    assert.equal(dateOnly('2026-10'), '2026-10-31');
  } finally { process.env.TZ = previousTZ; }
});

// 111 — ORDER NOW export uses the same explicit analysis context as the visible page.
test('P33-F01 ORDER NOW export passes active end, period, occurrences, and forecast config', async () => {
  let input; let downloaded;
  const data = { parts: [{ partNo: 'PN-1' }], stock: [{ partNo: 'PN-1', quantity: 2 }], replacements: [], occurrenceByPart: { 'PN-1': 4 }, config: { usagePeriodDays: 45, leadTimeDays: 8 } };
  const ctx = makeContext(ui, ['exportOrderNow'], {
    load: async () => data,
    window: { componentConsumptionAnalyticsState: { end: '2026-09-30', periodDays: 21 }, ShankConsumptionAnalytics: { orderNowRows: value => { input = value; return [{ partNo: 'PN-1', currentStock: 2, averageDailyUsage: 1, leadTimeDays: 8, safetyStockQty: 3, reorderPoint: 11, status: 'REORDER' }]; } } },
    csv: rows => JSON.stringify(rows), download: (...args) => { downloaded = args; }
  });
  await ctx.exportOrderNow();
  assert.equal(input.today, '2026-09-30');
  assert.equal(input.periodDays, 21);
  assert.deepEqual(JSON.parse(JSON.stringify(input.occurrenceByPart)), data.occurrenceByPart);
  assert.deepEqual(JSON.parse(JSON.stringify(input.config)), data.config);
  assert.match(downloaded[0], /2026-09-30/);
});

// 112 — detail recalculates and filters history using the currently selected analytics context.
test('P33-F02 part drill-down honors active date and usage period', async () => {
  let forecastInput; let drillRows; let page = '';
  const history = [
    { partNo: 'PN-1', date: '2026-09-10', quantity: 1 },
    { partNo: 'PN-1', date: '2026-09-11', quantity: 2 },
    { partNo: 'PN-1', date: '2026-10-10', quantity: 3 },
    { partNo: 'PN-1', date: '2026-10-11', quantity: 4 }
  ];
  const ctx = makeContext(ui, ['detail'], {
    load: async () => ({ parts: [{ partNo: 'PN-1' }], stock: [], replacements: history, occurrenceByPart: { 'PN-1': 1 }, config: { usagePeriodDays: 90 } }),
    window: { componentConsumptionAnalyticsState: { end: '2026-10-10', periodDays: 30 }, ShankConsumptionAnalytics: {
      calculateForecast: input => { forecastInput = input; return [{ partNo: 'PN-1', currentStock: 5, averageDailyUsage: 1, expectedZeroDate: '2026-10-15', status: 'LOW STOCK' }]; },
      transactionDrillDown: rows => { drillRows = rows; return rows; }
    } },
    shell: (_title, body) => { page = body; }, esc, n: value => Number(value) || 0, cardMetric: (value, label) => `${label}:${value}`,
    table: (_headers, rows) => rows
  });
  await ctx.detail('PN-1');
  assert.equal(forecastInput.today, '2026-10-10');
  assert.equal(forecastInput.periodDays, 30);
  assert.deepEqual(drillRows.map(row => row.date), ['2026-09-11', '2026-10-10']);
  assert.match(page, /LOW STOCK/);
});

// 113 — saving Usage Period overrides stale in-memory period and drives the next forecast calculation.
test('P33-F03 saved Usage Period immediately becomes the forecast period', async () => {
  let forecastInput; let savedConfig;
  const values = { 'cm-analytics-lead-time': '10', 'cm-analytics-internal-days': '25', 'cm-analytics-usage-period': '30' };
  const ctx = makeContext(ui, ['open', 'saveSettings'], {
    window: {
      componentConsumptionAnalyticsState: { end: '2026-10-01', periodDays: 90 },
      ShankConsumptionAnalytics: {
        calculateForecast: input => { forecastInput = input; return []; }, calculateConsumption: () => [],
        saveConfig: async config => { savedConfig = config; }
      }, ShankMappingBIProduction: { render: async () => '' }, gAll: async () => [], dPut: async () => {}, toastMsg() {}
    },
    load: async () => ({ parts: [], stock: [], replacements: [], occurrenceByPart: {}, config: savedConfig || { usagePeriodDays: 90 } }),
    val: id => values[id] || '', n: value => Number(value) || 0, todayString: () => '2026-10-10',
    esc, btn: () => '', table: () => '', cardMetric: () => '', shell() {},
    document: { querySelectorAll: () => [], getElementById: () => null }, gAll: async () => [],
  });
  await ctx.saveSettings();
  assert.equal(savedConfig.usagePeriodDays, 30);
  assert.equal(ctx.window.componentConsumptionAnalyticsState.periodDays, 30);
  assert.equal(forecastInput.periodDays, 30);
  assert.equal(forecastInput.today, '2026-10-01');
});

// 114 — simulation period changes projected usage while ordering remains lead-time based.
test('P33-F04 What-if Simulation period affects simulated horizon math', () => {
  const bi = require(path.join(ROOT, 'modules/shankMappingBIProduction.js'));
  const forecast = { partNo: 'PN-1', currentStock: 20, averageDailyUsage: 1, safetyStockQty: 2, status: 'NORMAL' };
  const short = bi.simulate(forecast, { period: 7, leadTime: 5 });
  const long = bi.simulate(forecast, { period: 60, leadTime: 5 });
  assert.equal(short.projectedHorizonUsage, 7);
  assert.equal(long.projectedHorizonUsage, 60);
  assert.equal(short.suggestedOrderQuantity, long.suggestedOrderQuantity);
  assert.equal(short.suggestedOrderQuantity, 0);
});

// 115 — action center routes pass the subject; destination helpers retain/use it for filters.
test('P33-F05 AI action navigation carries part, station, and approval subjects into destinations', async () => {
  const bi = require(path.join(ROOT, 'modules/shankMappingBIProduction.js'));
  const actions = bi.actionCenter([{ partNo: 'PN-10', status: 'ZERO STOCK' }, { partNo: 'PN-11', status: 'REORDER' }], [{ stationNo: 'ST-44', partNo: '' }], [], [{ id: 'a1', partNo: 'PN-77', status: 'Pending', type: 'substitute' }], []);
  assert.match(actions, /componentBiOpenStock\('PN-10'\)/);
  assert.match(actions, /componentBiCreateOrder\('PN-11'\)/);
  assert.match(actions, /componentBiOpenMappingReview\('ST-44'\)/);
  assert.match(actions, /componentBiOpenApprovals\('PN-77'\)/);
  assert.deepEqual(bi.approvalRowsForSubject([{ partNo: 'PN-77' }, { partNo: 'PN-88' }], 'PN-77'), [{ partNo: 'PN-77' }]);

  const savedWindow = global.window; const savedDocument = global.document; const savedOpen = global.componentOpen;
  const savedProcurement = global.componentOpenProcurement; const savedCan = global.canShankComponent;
  const savedAnalytics = global.componentConsumptionAnalyticsOpen; const savedDetail = global.componentConsumptionAnalyticsDetail;
  try {
    global.window = global; global.document = { getElementById: id => id === 'cm-bi-approvals' ? { scrollIntoView() { global.didApprovalScroll = true; } } : null };
    const destinations = []; global.componentOpen = route => destinations.push(route); global.canShankComponent = () => true;
    global.componentOpenProcurement = () => destinations.push('procurement');
    global.componentBiOpenStock('PN-10');
    assert.deepEqual(destinations, ['stock']);
    assert.equal(global.componentBiNavigationContext.partNo, 'PN-10');
    global.componentBiCreateOrder('PN-11');
    assert.deepEqual(destinations, ['stock', 'procurement']);
    assert.equal(global.componentBiNavigationContext.partNo, 'PN-11');
    global.componentBiOpenStation('ST-44');
    assert.deepEqual(destinations, ['stock', 'procurement', 'matrix']);
    assert.equal(global.componentBiNavigationContext.stationNo, 'ST-44');
    global.componentBiOpenMappingReview('ST-44');
    assert.deepEqual(destinations, ['stock', 'procurement', 'matrix', 'matrix']);
    assert.equal(global.componentBiNavigationContext.stationNo, 'ST-44');
    global.componentBiOpenPart('PN-12');
    assert.equal(destinations.at(-1), 'parts');
    assert.equal(global.componentBiNavigationContext.partNo, 'PN-12');
    let anomalyPart;
    global.componentConsumptionAnalyticsDetail = async part => { anomalyPart = part; };
    global.componentBiOpenAnomaly('PN-13');
    assert.equal(anomalyPart, 'PN-13');
    let approvalContext;
    global.componentConsumptionAnalyticsOpen = async () => { approvalContext = global.componentBiNavigationContext.approvalSubject; };
    await global.componentBiOpenApprovals('PN-77');
    assert.equal(approvalContext, 'PN-77');
    assert.equal(global.didApprovalScroll, true);
  } finally {
    global.window = savedWindow; global.document = savedDocument; global.componentOpen = savedOpen; global.componentOpenProcurement = savedProcurement;
    global.canShankComponent = savedCan; global.componentConsumptionAnalyticsOpen = savedAnalytics; global.componentConsumptionAnalyticsDetail = savedDetail;
    delete global.componentBiNavigationContext; delete global.didApprovalScroll;
  }
});

// 116 — editing a source-only row to a valid mapped component promotes it into an importable row.
test('P36-F01 preview edit recomputes source-only status and creates a mapped part pair', () => {
  const row = { stationNo: 'ST-1', gunReferenceNo: 'G-1', fixShank: '', sourceOnly: true, status: 'Missing Component', boldParts: {} };
  const ctx = makeContext(cm, ['importPreviewCell'], {
    pendingImport: { rows: [row] }, MAPPED_PART_FIELDS: ['fixShank', 'movingShank', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder'],
    splitBoldPartText: value => String(value).split(',').map(item => item.trim()).filter(Boolean),
    componentPairsForRow: value => Object.entries(value.boldParts || {}).flatMap(([field, parts]) => parts.map(part => [field, part])),
    validMappedPartNo: value => Boolean(String(value).trim())
  });
  ctx.importPreviewCell(0, 'fixShank', 'FS-100');
  assert.equal(row.sourceOnly, false);
  assert.equal(row.status, 'Ready for Mapping');
  assert.deepEqual(JSON.parse(JSON.stringify(ctx.componentPairsForRow(row))), [['fixShank', 'FS-100']]);
});

// 117 — the resolved Station variation is written back to the retained Gun Row before returning.
test('P36-F02 canonical Station resolution persists to the retained Gun Row (behavior plus source wiring assertion)', async () => {
  const row = { id: 'gun-1', sourceKey: 'book.xlsx:Sheet1:2', stationNo: 'ST-01', gunReferenceNo: 'G-1' }; const writes = [];
  const ctx = makeContext(cm, ['persistResolvedGunRowStation'], {
    resolveImportStation: value => value === 'ST-1' ? 'ST-CANONICAL' : value,
    gAll: async store => { assert.equal(store, 'component_gun_rows'); return [row]; },
    dPut: async (store, value) => writes.push([store, { ...value }]), nowIso: () => '2026-10-10T00:00:00Z'
  });
  const resolved = await ctx.persistResolvedGunRowStation('book.xlsx:Sheet1:2', 'ST-1');
  assert.equal(resolved, 'ST-CANONICAL');
  assert.equal(row.stationNo, 'ST-CANONICAL');
  assert.equal(writes.length, 1);
  assert.equal(writes[0][1].stationNo, 'ST-CANONICAL');
  // Static-only wiring supplement: confirm commitImport invokes this behavior-tested persistence helper.
  assert.match(extractFunction(cm, 'commitImport'), /await persistResolvedGunRowStation\(fullSourceKey, row\.stationNo\)/);
});

// 118 — protected permanent imports do not write an unreachable full-store snapshot.
test('P36-F03 permanent import skips full pre-import snapshot creation', async () => {
  let reads = 0; let writes = 0;
  const ctx = makeContext(cm, ['snapshotBeforeImport'], {
    pendingImport: { importMode: 'PERMANENT', trial: false, fileName: 'workbook.xlsx' },
    COMPONENT_IMPORT_DATA_STORES: ['component_parts', 'component_stock'], uid: () => 'snap1', nowIso: () => '2026-10-10T00:00:00Z',
    user: () => ({ id: 'u1' }), gAll: async () => { reads += 1; return []; }, dPut: async () => { writes += 1; }, audit: async () => {}
  });
  assert.equal(await ctx.snapshotBeforeImport(), null);
  assert.equal(reads, 0);
  assert.equal(writes, 0);
});

// 119 — loading persisted schedules triggers both the normal list and grouped-slip renderers.
test('P37-F01 PM startup load renders persisted grouped slips after schedules load', async () => {
  const calls = []; const ctx = makeContext(pmSource, ['pmLoadData'], {
    pmSchedules: [], pmChecklistFileMap: {}, gAll: async store => store === 'pm_schedules' ? [{ id: 's1', who: 'Alex', equipment: 'Press 1' }] : [],
    pmRenderList: () => calls.push('list'), pmRenderPersonGroups: () => calls.push('groups'), console
  });
  await ctx.pmLoadData();
  assert.deepEqual(JSON.parse(JSON.stringify(calls)), ['list', 'groups']);
  assert.equal(ctx.pmSchedules.length, 1);
});

// 120 — preview, single print, and bulk print render parser items (main-process parser shape is {items}).
test('P37-F02 checksheet preview and print use parsed checklist content rather than only the linked path', async () => {
  const parsedItem = { inspectionItem: 'Inspect guard', standard: 'No cracks', ok: 'Pass', ng: 'Fail', remarks: 'Record damage' };
  const nodes = new Map(); const parsedHost = {};
  const content = {};
  Object.defineProperty(content, 'innerHTML', { get() { return this._html || ''; }, set(value) { this._html = value; if (String(value).includes('pm-checksheet-parsed')) nodes.set('pm-checksheet-parsed', parsedHost); } });
  Object.defineProperty(parsedHost, 'innerHTML', { get() { return this._html || ''; }, set(value) { this._html = value; this._parent._html = this._parent._html.replace(/(<div id="pm-checksheet-parsed"[^>]*>)[\s\S]*?(<\/div>)/, `$1${value}$2`); } });
  parsedHost._parent = content;
  const info = { innerHTML: '' }; const manualBox = { style: {} }; const manualSelect = { innerHTML: '' };
  const modal = { classList: { add(value) { this.value = value; } } };
  const nodeById = { 'pm-checksheet-info': info, 'pm-checksheet-content': content, 'pm-checksheet-manual-match': manualBox, 'pm-manual-match-select': manualSelect, 'pm-checksheet-ov': modal };
  const printed = [];
  const windowObj = { printPopupHtml: html => printed.push(html), pmBridge: { parseChecklistFile: async () => ({ items: [parsedItem] }), listChecklistFiles: async () => ({ files: [] }), printPopupHtml: html => printed.push(html) } };
  const globals = {
    pmSchedules: [{ id: 's1', equipment: 'Press 1', location: 'Line 3', priority: 'High', shift: '1st Shift', checksheetQty: 1 }],
    pmChecklistFileMap: { 'Press 1': { path: '/PM_Checksheet/press.xlsx', type: '.xlsx' } },
    document: { getElementById: id => id === 'pm-checksheet-parsed' ? nodes.get(id) || null : nodeById[id] || null },
    window: windowObj, sanitizeHTML: value => String(value).replace(/</g, '&lt;').replace(/>/g, '&gt;'), toast() {},
    console: { warn() {}, error() {} }
  };
  const ctx = makeContext(pmSource, ['pmPreviewChecksheet', 'pmPrintChecksheetFromPreview', 'pmBulkPrintChecksheets', 'pmChecksheetItems', 'pmChecksheetItemHtml'], globals);
  await ctx.pmPreviewChecksheet('s1');
  assert.match(parsedHost.innerHTML, /Inspect guard/);
  assert.match(parsedHost.innerHTML, /No cracks/);
  ctx.pmPrintChecksheetFromPreview();
  assert.match(printed[0], /Inspect guard/);
  assert.doesNotMatch(printed[0], /Loading checksheet content/);
  await ctx.pmBulkPrintChecksheets();
  assert.match(printed[1], /Inspect guard/);
  assert.match(printed[1], /Record damage/);
});
