const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const centralGuide = fs.readFileSync(path.join(root, 'docs/CENTRAL_INSTALLER_GUIDE.md'), 'utf8');
const deploymentGuide = fs.readFileSync(path.join(root, 'docs/STORETRACK-DEPLOYMENT-GUIDE.md'), 'utf8');
const generator = fs.readFileSync(path.join(root, 'scripts/create-deployment-guide.js'), 'utf8');

test('central recovery drill documents an isolated destructive restore target and stop conditions', () => {
  for (const required of [
    'Same-host disaster-recovery drill record (dated 2026-11-12)',
    '`pg_restore --clean --if-exists`',
    'Never point the helper at the live/production `.env` for a drill',
    'disposable isolated database',
    'host, port, and database name',
    'Stop immediately on unexpected service, database, or data impact',
    'Rollback means stop the drill',
    'SHA-256',
    'representative records',
    'application/API health',
    'Operator sign-off/date',
    'Reviewer sign-off/date',
  ]) {
    assert.ok(centralGuide.includes(required), `missing recovery drill safeguard/evidence: ${required}`);
  }
});

test('deployment guide requires evidence-based verification and generated bundle includes it', () => {
  for (const required of [
    'recorded evidence',
    'dump identity, modified time, byte size, SHA-256',
    'isolated target identity',
    'explicitly “not run”',
  ]) assert.ok(deploymentGuide.includes(required), `missing deployment verification requirement: ${required}`);

  assert.match(generator, /STORETRACK-DEPLOYMENT-GUIDE\.md/);
  assert.match(generator, /01-STORETRACK-DEPLOYMENT-GUIDE\.md/);
});
