const fs = require('fs');
const path = require('path');
const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'componentManagement.js'), 'utf8');

function sourceFunction(start, end) {
  const startIndex = source.indexOf(start);
  const endIndex = source.indexOf(end, startIndex);
  if (startIndex < 0 || endIndex < 0) { throw new Error(`Missing function boundary: ${start}`); }
  return source.slice(startIndex, endIndex).trim();
}

function isolatedMigration(state, persisted, commit = async writes => persisted.migrationWrites.push(structuredClone(writes))) {
  const migrateSource = sourceFunction('async function migratePencilPartStock(partNo, binId) {', '  async function ensurePencilBins()');
  return new Function('state', 'STORES', 'ALLOCATION_BATCH_STORE', 'pencilPartKey', 'uid', 'nowIso', 'partByNo', 'autoSafetyQuantity', 'statusFor', 'window', `return (${migrateSource});`)(
    state,
    { stock: 'component_stock', tx: 'component_stock_transactions', replacements: 'component_replacements', orders: 'component_procurement_orders' },
    'component_allocation_batches',
    value => String(value || '').toLowerCase(),
    prefix => `${prefix}-fixture`,
    () => '2026-10-27T00:00:00.000Z',
    () => null,
    () => 0,
    quantity => Number(quantity) === 0 ? 'OUT OF STOCK' : 'OK',
    { dPutMany: commit },
  );
}

function isolatedUndo(state, persisted, messages) {
  const undoSource = sourceFunction('async function undoAllocation(batchId) {', '  async function receiveStock()');
  const window = { dPutMany: async writes => { persisted.writes.push(structuredClone(writes)); } };
  return new Function('state', 'canComponent', 'toastMsg', 'confirm', 'user', 'uid', 'nowIso', 'statusFor', 'window', 'STORES', 'ALLOCATION_BATCH_STORE', 'stockFor', 'stock', `return (${undoSource});`)(
    state,
    () => true,
    message => messages.push(message),
    () => true,
    () => ({ id: 'fixture-user', username: 'fixture-user' }),
    prefix => `${prefix}-fixture`,
    () => '2026-10-27T00:01:00.000Z',
    quantity => Number(quantity) === 0 ? 'OUT OF STOCK' : 'OK',
    window,
    { stock: 'component_stock', tx: 'component_stock_transactions', audit: 'component_audit_log' },
    'component_allocation_batches',
    (partNo, binId) => state.stock.find(row => row.partNo === partNo && row.binId === binId),
    () => {},
  );
}

describe('Pencil stock migration behavior with isolated in-memory fixtures', () => {
  function fixture() {
    const state = {
      stock: [
        { id: 'legacy-a', partNo: '07-526/43', binId: 'SHANK-A', quantity: 2, minimumStock: 1 },
        { id: 'legacy-b', partNo: '07-526/43', binId: 'SHANK-B', quantity: 2, minimumStock: 0 },
        { id: 'pencil-stock', partNo: '07-526/43', binId: 'PENCIL-BIN-01', quantity: 2, minimumStock: 0 },
        { id: 'other-part-stock', partNo: '07-526/48', binId: 'SHANK-A', quantity: 5, minimumStock: 0 },
      ],
      tx: [
        { id: 'legacy-tx-a', partNo: '07-526/43', binId: 'SHANK-A', type: 'Receive', quantity: 2, beforeQuantity: 0, afterQuantity: 2, date: '2026-10-01T00:00:00Z' },
        { id: 'legacy-tx-b', partNo: '07-526/43', binId: 'SHANK-B', type: 'Receive', quantity: 2, beforeQuantity: 0, afterQuantity: 2, date: '2026-10-02T00:00:00Z' },
      ],
      replacements: [],
      orders: [],
      allocationBatches: [
        { id: 'legacy-batch', partNo: '07-526/43', totalQuantity: 4, status: 'COMMITTED', createdAt: '2026-10-02T00:00:00Z', allocations: [
          { stockId: 'legacy-a', binId: 'SHANK-A', quantity: 2, beforeQuantity: 0, afterQuantity: 2 },
          { stockId: 'legacy-b', binId: 'SHANK-B', quantity: 2, beforeQuantity: 0, afterQuantity: 2 },
        ] },
        { id: 'target-batch', partNo: '07-526/43', totalQuantity: 2, status: 'COMMITTED', allocations: [
          { stockId: 'pencil-stock', binId: 'PENCIL-BIN-01', quantity: 2, beforeQuantity: 0, afterQuantity: 2 },
        ] },
      ],
    };
    return { state, persisted: { migrationWrites: [], writes: [] } };
  }

  test('moves stock once, preserves ledger snapshots, and rebinds a multi-bin batch for one valid Undo', async () => {
    const { state, persisted } = fixture();
    const migrate = isolatedMigration(state, persisted);
    await migrate('07-526/43', 'PENCIL-BIN-01');

    expect(state.stock.find(row => row.id === 'pencil-stock').quantity).toBe(6);
    expect(state.stock.some(row => row.id === 'legacy-a' || row.id === 'legacy-b')).toBe(false);
    expect(state.stock.find(row => row.id === 'other-part-stock').quantity).toBe(5);
    const batch = state.allocationBatches.find(row => row.id === 'legacy-batch');
    expect(batch.allocations).toEqual([expect.objectContaining({ stockId: 'pencil-stock', binId: 'PENCIL-BIN-01', quantity: 4, beforeQuantity: 2, afterQuantity: 6 })]);
    expect(state.tx.map(row => [row.beforeQuantity, row.afterQuantity])).toEqual([[0, 2], [0, 2]]);
    expect(state.tx.map(row => row.metadata.migratedFromBinId)).toEqual(['SHANK-A', 'SHANK-B']);

    await migrate('07-526/43', 'PENCIL-BIN-01');
    expect(state.stock.find(row => row.id === 'pencil-stock').quantity).toBe(6);
    expect(persisted.migrationWrites).toHaveLength(1);
    expect(persisted.migrationWrites[0].filter(write => write.operation === 'delete')).toHaveLength(2);

    const messages = [];
    await isolatedUndo(state, persisted, messages)('legacy-batch');
    expect(state.stock.find(row => row.id === 'pencil-stock').quantity).toBe(2);
    expect(state.allocationBatches.find(row => row.id === 'legacy-batch').status).toBe('REVERSED');
    expect(persisted.writes).toHaveLength(1);
    expect(messages).toContain('Allocation batch legacy-batch was undone atomically.');
  });

  test('a failed atomic persistence call leaves stock, transactions, and batch references unchanged', async () => {
    const { state, persisted } = fixture();
    const before = structuredClone(state);
    const migrate = isolatedMigration(state, persisted, async writes => {
      persisted.attemptedWrites = structuredClone(writes);
      throw new Error('Injected IndexedDB transaction abort');
    });

    await expect(migrate('07-526/43', 'PENCIL-BIN-01')).rejects.toThrow('Injected IndexedDB transaction abort');
    expect(state).toEqual(before);
    expect(persisted.attemptedWrites.filter(write => write.operation === 'delete')).toHaveLength(2);
  });
});

describe('Pencil Bin implementation contract', () => {
  const root = path.join(__dirname, '..');
  const manual = fs.readFileSync(path.join(root, 'docs', 'final', 'End_User_Manual.md'), 'utf8');

  test('recognizes Pencil formats independently of a stale Part Master display type', () => {
    expect(source).toContain(
      'const PENCIL_PART_FORMAT = /^(?:07-\\d{2,4}(?:\\/l?\\d+)?|06-\\d{3}\\/l?\\d+)$/i;',
    );
    expect(source).toContain(".replace(/\\/l/g, '/')");
    const keySource = sourceFunction('const pencilPartKey = value => {', 'const isPencilPart = value =>');
    const classifierSource = sourceFunction('const isPencilPart = value =>', '  function stockRowsForView');
    const pencilPartKey = new Function('vendorPartNo', `${keySource}; return pencilPartKey;`)(value => value == null ? '' : String(value));
    const isPencilPart = new Function('PENCIL_PART_FORMAT', 'pencilPartKey', `${classifierSource}; return isPencilPart;`)(
      /^(?:07-\d{2,4}(?:\/l?\d+)?|06-\d{3}\/l?\d+)$/i,
      pencilPartKey,
    );
    expect(isPencilPart('06-0519/215')).toBe(true);
    expect(isPencilPart('06-417/L30')).toBe(true);
    expect(isPencilPart('06-417/L35')).toBe(true); // legacy format fallback when no Part Master row exists
    expect(isPencilPart('05-0589')).toBe(false);
    expect(manual).toContain('05-0589');
  });

  test('uses same-base grouping, numeric suffix sorting, and two-part pairing', () => {
    expect(source).toContain('const series = pencilSeriesKey(partNo);');
    expect(source).toContain(
      'const parts = [...group.parts.values()].sort((a, b) => a.suffix - b.suffix',
    );
    expect(source).toContain('for (let index = 0; index < parts.length; index += 2)');
    expect(source).toContain('group.parts.set(key');
    expect(manual).toContain('07-0526/43');
    expect(manual).toContain('07-0526/48');
    expect(manual).toContain('06-417/L30');
    expect(manual).toContain('06-417/L35');
  });

  test('creates station-independent Pencil bins and includes single leftovers', () => {
    expect(source).toContain(
      "const stableBinId = existingBin?.binId || `PENCIL-BIN-${String(nextSeq).padStart(2, '0')}`;",
    );
    expect(source).toContain('bin.binId = existingBin?.binId || stableBinId;');
    expect(source).toContain("binKind: 'PENCIL_PAIR'");
    expect(source).toContain("stationNo: ''");
    expect(source).toContain('A single leftover Part gets its own Bin');
    expect(manual).toContain('single-item Pencil Bin');
    expect(manual).toContain('Different base series never pair');
  });

  test('Receive calculates automatic kit-based Bin allocation', () => {
    expect(source).toContain('<input class="fi" id="cs-part" list="cs-part-options"');
    expect(source).toContain('<datalist id="cs-part-options">');
    expect(source).toContain('function receiveAllocation(partNo, totalQuantity)');
    expect(source).toContain('kitQty: Math.max(1, mappedRows.length)');
    expect(source).toContain('id="cs-allocation-preview"');
    expect(source).toContain('KIT_PROPORTIONAL');
    expect(source).toContain('receiveMappedBinOptions(partNo)');
    expect(source).toContain('automatically split');
    expect(source).toContain("b.binKind === 'PENCIL_PAIR' ? 'Pencil Common'");
  });

  test('Verification and QR labels expose Pencil Bin identity and both part quantities', () => {
    expect(source).toContain(
      "['Part No.', 'Station / Scope', 'Location', 'Bin', 'System Qty', 'Physical Qty', 'Reason']",
    );
    expect(source).toContain(
      'Pencil Parts are verified independently inside their own Pencil Bin.',
    );
    expect(source).toContain('pencilQrPayload');
    expect(source).toContain(
      "const dataUrl = typeof result === 'string' ? result : result?.dataURL;",
    );
    expect(source).toContain('<th>PART NO.</th><th>QTY</th>');
    expect(source).toContain('data-qr-index');
    expect(source).not.toContain('STATION NO.');
    expect(source).toContain('pencil-label-head');
    expect(source).toContain('pencil-label-table-wrap');
    expect(source).toContain('PENCIL PART LABEL');
  });

  test('startup backfills existing imported Pencil mappings and Part Master rows', () => {
    expect(source).toContain('await ensurePencilBins(); await load();');
    expect(source).toContain('Pencil Shank ${part.partNo}');
    expect(source).toContain('await ensureStockRecord(part.partNo, bin.binId);');
    expect(source).toContain('migratePencilPartStock(part.partNo, bin.binId);');
  });

  test('pools Pencil stock in low-stock, procurement, BI, and export views', () => {
    expect(source).toContain("b?.binKind === 'PENCIL_PAIR' ? 'Pencil Common'");
    expect(source).toContain("b.binKind === 'PENCIL_PAIR' ? 'Pencil Common' : b.stationNo || ''");
    expect(source).toContain("x.stations.add('Pencil Common')");
    expect(source).toContain('Pooled Part stock is');
  });

  test('blocks Pencil stock mutation against any non-Pencil Bin', () => {
    expect(source).toContain("throw new Error('PENCIL_PART_REQUIRES_PENCIL_BIN')");
    expect(source).toContain('Pencil Part can use only its Pencil Bin');
    expect(source).toContain('commonBin: binId');
  });
});

module.exports = {};
