const { AutomatedIssueDetection } = require('../modules/automatedIssueDetection');

describe('Automated Issue Detection live data wiring', () => {
  afterEach(() => {
    delete window.performanceMonitor;
    delete window.centralHealth;
    delete window.errorHandler;
  });

  test('performDetection evaluates real performance and central health data', () => {
    window.performanceMonitor = {
      getRecentMetrics: () => [
        { name: 'resource_load_time', value: 6001, unit: 'ms', timestamp: Date.now() },
        { name: 'memory_used', value: 950, unit: 'bytes', timestamp: Date.now() },
        { name: 'memory_limit', value: 1000, unit: 'bytes', timestamp: Date.now() },
      ],
    };
    window.centralHealth = { online: false, state: 'offline' };

    const detector = new AutomatedIssueDetection();
    detector.loadDefaultRules();
    detector.performDetection();

    expect(detector.getIssues({ status: 'open' }).map((issue) => issue.ruleId)).toEqual(
      expect.arrayContaining(['high_response_time', 'memory_leak', 'sync_failure']),
    );
  });

  test('performDetection evaluates network errors from the existing error handler', () => {
    window.errorHandler = {
      getErrorLog: () => [
        {
          name: 'NetworkError',
          message: 'request timed out',
          timestamp: new Date().toISOString(),
        },
      ],
      getStatistics: () => ({ total: 1 }),
    };

    const detector = new AutomatedIssueDetection();
    detector.loadDefaultRules();
    detector.performDetection();

    expect(detector.getIssues({ category: 'network', status: 'open' })).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          ruleId: 'network_timeout',
          data: expect.objectContaining({ source: 'errorHandler' }),
        }),
      ]),
    );
  });

  test('does not invent an error rate when the existing handler provides no rate', () => {
    window.errorHandler = {
      getErrorLog: () => [],
      getStatistics: () => ({ total: 3 }),
    };

    const detector = new AutomatedIssueDetection();
    detector.loadDefaultRules();
    detector.performDetection();

    expect(detector.getIssues({ category: 'error' })).toHaveLength(0);
  });
});

afterAll(() => {
  jest.useRealTimers();
});
