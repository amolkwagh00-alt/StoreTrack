'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { ErrorHandler } = require('../core/errorHandler.js');

test('error guidance provides safe operation-specific recovery steps and honors overrides', () => {
  const handler = new ErrorHandler();
  assert.match(handler.getUserMessage(new Error('x'), { operation: 'save' }), /verify it before repeating/i);
  assert.match(handler.getUserMessage(new Error('Failed to fetch'), {}), /check your network/i);
  assert.match(handler.getUserMessage(new Error('Unknown'), {}), /check whether it completed before retrying/i);
  assert.equal(handler.getUserMessage(new Error('x'), { operation: 'restore', userMessage: 'Custom' }), 'Custom');
});

function extractFunction(source, name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `missing ${name}`);
  const open = source.indexOf('{', start);
  let depth = 0;
  for (let i = open; i < source.length; i += 1) {
    if (source[i] === '{') depth += 1;
    else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`unterminated ${name}`);
}

test('audit search includes user and module and safely handles malformed legacy rows', () => {
  const app = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  const renderAudit = extractFunction(app, 'renderAudit');
  const filtered = extractFunction(app, 'filteredAuditRows');
  const elements = {
    'srch-aud': { value: 'warehouse' }, 'flt-aud-tp': { value: 'all' }, 'flt-aud-us': { value: 'all' },
    'aud-body': { innerHTML: '' }, 'aud-limit-notice': { textContent: '' },
  };
  const context = { A: [{ action: 'Changed', details: 'x', userName: 'Warehouse clerk', module: 'IN' }, { action: null, details: null }], document: { getElementById: id => elements[id] || null }, sanitizeHTML: value => String(value ?? ''), Date };
  vm.runInNewContext(`${filtered}; ${renderAudit}; renderAudit();`, context);
  assert.match(elements['aud-body'].innerHTML, /Warehouse clerk/);
  assert.equal((elements['aud-body'].innerHTML.match(/<tr>/g) || []).length, 1);

  elements['srch-aud'].value = '';
  context.A = Array.from({ length: 305 }, (_, i) => ({ action: `Action ${i}`, details: '', userName: 'u', module: 'IN', time: '2026-01-01' }));
  vm.runInNewContext(`${filtered}; ${renderAudit}; renderAudit();`, context);
  assert.match(elements['aud-limit-notice'].textContent, /newest 300 of 305/);
});

test('audit CSV export reuses filters and previews all matches rather than the 300-row screen slice', () => {
  const app = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  const filtered = extractFunction(app, 'filteredAuditRows');
  const elements = { 'srch-aud': { value: 'variance' }, 'flt-aud-tp': { value: 'all' }, 'flt-aud-us': { value: 'all' } };
  const context = { A: [
    { details: 'variance at bin 1', action: 'Adjust', userName: 'A', module: 'ADJUST', time: '2026-01-01' },
    { details: 'received stock', action: 'IN', userName: 'B', module: 'IN', time: '2026-01-02' },
  ], document: { getElementById: id => elements[id] || null } };
  vm.runInNewContext(`${filtered}; result = filteredAuditRows();`, context);
  assert.equal(context.result.length, 1);
  assert.match(app, /Export scope: all matching entries \(the screen may show only the newest 300\)/);
  assert.match(app, /if\(!confirm\(preview\)\)\{return;\}/);
});
