const fs = require('fs');
const path = require('path');

describe('Material IN duplicate-posting regression', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
  const start = source.indexOf("const committed=await window.atomicReadModifyWrite('materials'");
  const end = source.indexOf('inI=committed;', start);
  const posting = source.slice(start, end);

  test('receipt transaction ID is CAS-guarded with the stock increment', () => {
    expect(start).toBeGreaterThanOrEqual(0);
    expect(posting).toContain('guards.receiptTransaction');
    expect(posting).toContain("store:'transactions',key:attempt.tx.id,name:'receiptTransaction'");
    expect(posting).toContain("writes:[{store:'transactions',obj:attempt.tx},{store:'grn',obj:grn}]");
    expect(posting).toContain('if(guards.receiptTransaction){return {record:current,writes:[]};}');
  });

  test('reconciliation reuses the persisted attempt ID and does not duplicate the local transaction', () => {
    expect(source).toContain('T.some(saved=>String(saved.id)===String(attempt.tx.id))');
    expect(source).toContain('T.push(attempt.tx)');
  });
});
