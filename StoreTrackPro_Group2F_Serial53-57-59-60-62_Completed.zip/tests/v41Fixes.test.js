const fs = require('fs');
const path = require('path');
const vm = require('vm');

describe('v41 supplier performance fixes', () => {
  beforeEach(() => {
    jest.resetModules();
    global.gAll = jest.fn(async (store) => {
      if (store === 'supplier_performance_metrics' || store === 'supplier_evaluations') {
        return [];
      }
      if (store === 'supplier_items') {
        return [{ supplierId: 'supplier-1', barcode: 'A-1', leadTime: 7 }];
      }
      if (store === 'transactions') {
        return [
          {
            id: 'tx-1',
            type: 'IN',
            barcode: 'A-1',
            quantity: 10,
            unitPrice: 2,
            time: new Date().toISOString(),
            fillRate: 0.8,
            responseTimeHours: 6,
            complaints: 1,
          },
        ];
      }
      return [];
    });
    global.dPut = jest.fn(async () => {});
    global.setInterval = jest.fn();
  });

  afterEach(() => {
    delete global.gAll;
    delete global.dPut;
    jest.restoreAllMocks();
  });

  test('uses transaction values for fill rate, response time, and complaints', async () => {
    require(path.join(__dirname, '..', 'modules', 'supplierPerformanceTracking.js'));
    const manager = window.SupplierPerformanceTracking.manager;
    const metric = await manager.calculateMetricsForSupplier('supplier-1');

    expect(metric.fillRate).toBeCloseTo(0.8);
    expect(metric.responseTime).toBeCloseTo(6);
    expect(metric.complaints).toBe(1);
    expect(metric.score).toBeCloseTo(88.5);
  });

  test('excludes missing optional metrics and renormalizes the remaining weights', async () => {
    global.gAll.mockImplementation(async (store) => {
      if (store === 'supplier_performance_metrics' || store === 'supplier_evaluations') {
        return [];
      }
      if (store === 'supplier_items') {
        return [{ supplierId: 'supplier-1', barcode: 'A-1', leadTime: 7 }];
      }
      if (store === 'transactions') {
        return [
          {
            id: 'tx-1',
            type: 'IN',
            barcode: 'A-1',
            quantity: 10,
            unitPrice: 2,
            time: new Date().toISOString(),
          },
        ];
      }
      return [];
    });
    require(path.join(__dirname, '..', 'modules', 'supplierPerformanceTracking.js'));
    const manager = window.SupplierPerformanceTracking.manager;
    const metric = await manager.calculateMetricsForSupplier('supplier-1');

    expect(metric.fillRate).toBeNull();
    expect(metric.responseTime).toBeNull();
    expect(metric.complaints).toBeNull();
    expect(metric.score).toBeCloseTo(100);
  });

  test('excludes transactions from the previous calendar month', async () => {
    const previousMonth = new Date();
    previousMonth.setDate(1);
    previousMonth.setMonth(previousMonth.getMonth() - 1);
    global.gAll.mockImplementation(async (store) => {
      if (store === 'supplier_performance_metrics' || store === 'supplier_evaluations') return [];
      if (store === 'supplier_items') return [{ supplierId: 'supplier-1', barcode: 'A-1', leadTime: 7 }];
      if (store === 'transactions') {
        return [{ id: 'old-tx', type: 'IN', barcode: 'A-1', qty: 10, unitCost: 2, time: previousMonth.toISOString() }];
      }
      return [];
    });
    require(path.join(__dirname, '..', 'modules', 'supplierPerformanceTracking.js'));
    const metric = await window.SupplierPerformanceTracking.manager.calculateMetricsForSupplier('supplier-1');

    expect(metric.totalOrders).toBe(0);
    expect(metric.totalValue).toBe(0);
  });
});

describe('v41 central sync queue fixes', () => {
  function loadCentralSync(items, commitStock) {
    const records = new Map(items.map((item) => [item.id, { ...item }]));
    const events = [];
    const context = {
      console,
      document: { getElementById: () => null },
      CustomEvent: function CustomEvent(type, init) {
        this.type = type;
        this.detail = init.detail;
      },
      window: {
        centralBridge: {
          commitStock,
          getStatus: async () => ({ configured: true, online: true, latencyMs: 1 }),
        },
        addEventListener: () => {},
        dispatchEvent: (event) => events.push(event),
        CustomEvent: function CustomEvent(type, init) {
          this.type = type;
          this.detail = init.detail;
        },
      },
      gAll: async (store) => (store === 'central_queue' ? Array.from(records.values()) : []),
      gOne: async (store, id) =>
        store === 'central_meta' && id === 'central-sync' ? { id, lastSequence: 0 } : null,
      dPut: async (store, item) => {
        if (store === 'central_queue') {
          records.set(item.id, { ...item });
        }
      },
      dDel: async (store, id) => {
        if (store === 'central_queue') {
          records.delete(id);
        }
      },
    };
    vm.runInNewContext(
      fs.readFileSync(path.join(__dirname, '..', 'modules', 'centralSync.js'), 'utf8'),
      context,
      { filename: 'centralSync.js' },
    );
    return { sync: context.window.centralSync, records };
  }

  test('a permanent 4xx item does not block later queued items', async () => {
    const commitStock = jest
      .fn()
      .mockRejectedValueOnce(Object.assign(new Error('bad transaction'), { statusCode: 400 }))
      .mockResolvedValueOnce({ ok: true });
    const { sync, records } = loadCentralSync(
      [
        {
          id: 'bad',
          transaction: { id: 'bad' },
          status: 'queued',
          attempts: 0,
          queuedAt: '2026-09-01T00:00:00.000Z',
        },
        {
          id: 'good',
          transaction: { id: 'good' },
          status: 'queued',
          attempts: 0,
          queuedAt: '2026-09-01T00:01:00.000Z',
        },
      ],
      commitStock,
    );

    await sync.flushQueue();

    expect(commitStock).toHaveBeenCalledTimes(2);
    expect(records.get('bad').status).toBe('queued');
    expect(records.get('bad').attempts).toBe(1);
    expect(records.has('good')).toBe(false);
  });

  test('moves an item to failed after the maximum attempts without deleting it', async () => {
    const commitStock = jest
      .fn()
      .mockRejectedValue(Object.assign(new Error('permanent failure'), { statusCode: 400 }));
    const { sync, records } = loadCentralSync(
      [
        {
          id: 'bad',
          transaction: { id: 'bad' },
          status: 'queued',
          attempts: 9,
          queuedAt: '2026-09-01T00:00:00.000Z',
        },
      ],
      commitStock,
    );

    await sync.flushQueue();

    expect(commitStock).toHaveBeenCalledTimes(1);
    expect(records.get('bad')).toEqual(expect.objectContaining({ status: 'failed', attempts: 10 }));
  });
});
