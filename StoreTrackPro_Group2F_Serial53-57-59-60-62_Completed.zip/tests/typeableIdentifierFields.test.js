const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const component = fs.readFileSync(path.join(root, 'modules', 'componentManagement.js'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

describe('typeable identifier fields with suggestions', () => {
  test('Replacement Entry Part, Station, Gun and Component accept typing and list mapped suggestions', () => {
    for (const [id, list] of [
      ['cr-part', 'cr-part-options'],
      ['cr-station', 'cr-station-options'],
      ['cr-gun', 'cr-gun-options'],
      ['cr-component', 'cr-component-options'],
    ]) {
      expect(component).toContain(`id="${id}" list="${list}"`);
      expect(component).toContain(`<datalist id="${list}">`);
    }
    expect(component).toContain("for (const event of ['input', 'change'])");
    expect(component).toContain('function mappingsForReplacementPart()');
    expect(component).toContain('function activeBinForStation');
  });

  test('stock, history, verification, merge and BI filters have text inputs and suggestions', () => {
    for (const [id, list] of [
      ['cm-stock-station-search', 'cm-stock-station-options'],
      ['cm-stock-bin-search', 'cm-stock-bin-options'],
      ['ch-part-filter', 'ch-part-filter-options'],
      ['ch-station-filter', 'ch-station-filter-options'],
      ['ch-gun-filter', 'ch-gun-filter-options'],
      ['cm-verify-part-filter', 'cm-verify-part-options'],
      ['cm-merge-source', 'cm-merge-stations'],
      ['cm-merge-target', 'cm-merge-stations'],
      ['cm-bi-part', 'cm-bi-parts'],
      ['cm-bi-station', 'cm-bi-stations'],
    ]) {
      expect(component).toContain(`id="${id}" list="${list}"`);
    }
    expect(component).toContain('function setIdentifierSuggestions');
    expect(component).toContain('String(row.dataset.historyGun || \'\').toLowerCase().includes(gun)');
    expect(component).toContain('cmMatch(row.dataset.station, station)');
  });

  test('dynamically resolved ambiguous Part No. fields allow typing plus original/latest suggestions', () => {
    expect(component).toContain('class="fi cm-ambiguous-part" list="cm-ambiguous-part-${itemIndex}-${choiceIndex}"');
    expect(component).toContain("if (selects.some(input => input.value && !validMappedPartNo(input.value)))");
    expect(component).toContain('Type the correct Part No. or choose an Original/Latest suggestion');
  });

  test('main Material Bin Location accepts text but only saves an existing location', () => {
    expect(html).toContain('id="m-binloc" list="m-binloc-options"');
    expect(html).toContain('<datalist id="m-binloc-options"></datalist>');
    expect(html).toContain('id="mov-from" list="mov-location-options"');
    expect(html).toContain('id="mov-to" list="mov-location-options"');
    expect(html).toContain('id="flt-loc-report" list="flt-loc-report-options"');
    expect(app).toContain('const binLocationText=(document.getElementById(\'m-binloc\')?.value||\'\').trim();');
    expect(app).toContain("if(binLocationText&&!binLoc){toast('Select or enter an existing Bin Location.");
    expect(app).toContain('list.innerHTML=LOCS.map');
    expect(app).toContain('if(sel&&bin) {sel.value=locCode(bin);}');
    expect(app).toContain('const toText=(document.getElementById(\'mov-to\')?.value||\'\').trim();');
    expect(app).toContain("Select an existing To Location from the suggestions.");
    expect(app).toContain('From Location must match the Item’s current Bin Location.');
    expect(app).toContain('const locationQuery=(document.getElementById(\'flt-loc-report\')?.value||\'\').trim().toLowerCase();');
  });

  test('shared suggestions preserve valid entries, populate options, and never disable manual entry', () => {
    const helper = component.match(/function setIdentifierSuggestions\([^\n]+/);
    expect(helper).not.toBeNull();
    const input = {
      value: 'Part-1',
      disabled: true,
      placeholder: '',
      getAttribute: () => 'part-options',
    };
    const list = { innerHTML: '' };
    const document = { getElementById: (id) => ({ part: input, 'part-options': list }[id] || null) };
    const setIdentifierSuggestions = new Function('document', 'esc', `${helper[0]}; return setIdentifierSuggestions;`)(document, (value) => value);
    setIdentifierSuggestions('part', 'Type or select Part', ['Part-1', 'Part-2']);
    expect(input.disabled).toBe(false);
    expect(input.value).toBe('Part-1');
    expect(list.innerHTML).toContain('Part-2');
    expect(input.placeholder).toBe('Type or select Part');
    input.value = 'stale value';
    setIdentifierSuggestions('part', 'No mapped suggestions — type to search', []);
    expect(input.disabled).toBe(false);
    expect(list.innerHTML).toBe('');
  });
});
