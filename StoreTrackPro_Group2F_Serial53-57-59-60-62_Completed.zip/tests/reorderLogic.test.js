const fs = require('fs');
const path = require('path');

const appSource = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
function sourceSection(start, end) {
  const startIndex = appSource.indexOf(start);
  const endIndex = appSource.indexOf(end, startIndex);
  if (startIndex < 0 || endIndex < 0) {
    throw new Error(`Missing app.js source boundary: ${start}`);
  }
  return appSource.slice(startIndex, endIndex);
}

const stockRulesSource = sourceSection('function materialSupplierId(m)', '// ── Stock ──');
const stockRules = new Function(
  `${stockRulesSource}; return { suggestedOrderQty, isLowStockMaterial, reorderCandidates };`,
)();

describe('Main Store Low Alert target and reorder quantity', () => {
  test.each([
    [3, 5, 2],
    [0, 5, 5],
    [5, 5, 0],
    [8, 5, 0],
  ])('stock %s against required level %s suggests %s', (stock, lowAlert, expected) => {
    expect(stockRules.suggestedOrderQty({ stock, lowAlert })).toBe(expected);
  });

  test('exactly meeting Low Alert is OK; zero or below-target stock remains low', () => {
    expect(stockRules.isLowStockMaterial({ active: true, stock: 5, lowAlert: 5 })).toBe(false);
    expect(stockRules.isLowStockMaterial({ active: true, stock: 4, lowAlert: 5 })).toBe(true);
    expect(stockRules.isLowStockMaterial({ active: true, stock: 0, lowAlert: 0 })).toBe(true);
    expect(stockRules.isLowStockMaterial({ active: false, stock: 0, lowAlert: 5 })).toBe(false);
  });

  test('only positive suggested quantities are candidates and supplier filtering is respected', () => {
    const materials = [
      { id: 1, stock: 3, lowAlert: 5, preferredSupplierId: 'SUP-A' },
      { id: 2, stock: 5, lowAlert: 5, preferredSupplierId: 'SUP-A' },
      { id: 3, stock: 0, lowAlert: 8, supplierId: 'SUP-B' },
      { id: 4, stock: 1, lowAlert: 8, supplierId: 'SUP-B', active: false },
    ];
    expect(stockRules.reorderCandidates(materials).map((item) => item.id)).toEqual([1, 3]);
    expect(stockRules.reorderCandidates(materials, 'SUP-A').map((item) => item.id)).toEqual([1]);
    expect(stockRules.reorderCandidates(materials, 'SUP-B').map((item) => item.id)).toEqual([3]);
  });

  test('the PO draft and reorder screen use calculated suggestions, not stored batch quantities', () => {
    const reorderSource = sourceSection('function renderReorder(){', 'function togglePO');
    const poSource = sourceSection('function genPODraft(){', 'function printPO()');
    expect(reorderSource).toContain('reorderCandidates(M,suppFlt)');
    expect(reorderSource).toContain('suggestedOrderQty(m)');
    expect(poSource).toContain('reorderCandidates(M,supplierId)');
    expect(poSource).toContain('const qty=suggestedOrderQty(m)');
    expect(poSource).not.toContain('m.reorderQty');
    expect(appSource).toContain('function toggleAllPO(cb){const supplierId=document.getElementById(\'po-supp-flt\')?.value||\'\'');
  });
});
