const fs = require('fs');
const path = require('path');

const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'tablePan.js'), 'utf8');
require('../modules/tablePan.js');

describe('table right-button drag panning', () => {
  let container;
  let cell;

  beforeEach(() => {
    document.body.innerHTML =
      '<div class="tw"><table><tbody><tr><td>Long table content</td></tr></tbody></table></div>';
    container = document.querySelector('.tw');
    cell = container.querySelector('td');
    Object.defineProperties(container, {
      clientWidth: { configurable: true, value: 100 },
      clientHeight: { configurable: true, value: 80 },
      scrollWidth: { configurable: true, value: 500 },
      scrollHeight: { configurable: true, value: 400 },
    });
    container.scrollLeft = 20;
    container.scrollTop = 15;
  });

  test('is loaded as a reusable module for all .tw wrappers', () => {
    expect(source).toContain("target.closest('.tw')");
    expect(source).toContain('event.button !== 2');
    expect(window.StoreTrackTablePan).toEqual({ enabled: true });
  });

  test('pans horizontally and vertically while the right button is held', () => {
    const down = new MouseEvent('mousedown', {
      bubbles: true,
      button: 2,
      clientX: 100,
      clientY: 100,
    });
    cell.dispatchEvent(down);
    expect(container.classList.contains('table-pan-active')).toBe(true);

    document.dispatchEvent(
      new MouseEvent('mousemove', { bubbles: true, clientX: 40, clientY: 55 }),
    );
    expect(container.scrollLeft).toBe(80);
    expect(container.scrollTop).toBe(60);

    document.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, button: 2 }));
    expect(container.classList.contains('table-pan-active')).toBe(false);
    expect(document.body.classList.contains('table-pan-dragging')).toBe(false);
  });

  test('prevents the browser context menu inside table wrappers', () => {
    const contextMenu = new MouseEvent('contextmenu', {
      bubbles: true,
      cancelable: true,
      button: 2,
    });
    cell.dispatchEvent(contextMenu);
    expect(contextMenu.defaultPrevented).toBe(true);
  });
});
