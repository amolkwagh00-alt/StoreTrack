// Unit tests for encryption module
// modules/encryption.js provides password-based AES-GCM encryption, used for
// optional password-protected backups in app.js (exportBackup/importBackup).

const {
  encrypt,
  decrypt,
  generateKey,
  encryptBackup,
  decryptBackup,
} = require('../modules/encryption.js');

describe('Encryption Module', () => {
  const testPassword = 'MyStrongPassword123';
  let testSalt, testKey;

  beforeAll(async () => {
    testSalt = crypto.getRandomValues(new Uint8Array(16));
    testKey = await generateKey(testPassword, testSalt);
  });

  describe('generateKey', () => {
    test('should derive a valid AES-GCM key from a password + salt', async () => {
      const key = await generateKey(testPassword, testSalt);
      expect(key).toBeDefined();
      expect(key.algorithm.name).toBe('AES-GCM');
    });

    test('same password + same salt should derive the same usable key', async () => {
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const keyA = await generateKey(testPassword, salt);
      const keyB = await generateKey(testPassword, salt);
      // Keys aren't directly comparable, so prove equivalence via encrypt/decrypt
      const enc = await encrypt('check', keyA);
      const dec = await decrypt(enc.encrypted, enc.iv, keyB);
      expect(dec).toBe('check');
    });

    test('different salts should derive different (incompatible) keys', async () => {
      const saltA = crypto.getRandomValues(new Uint8Array(16));
      const saltB = crypto.getRandomValues(new Uint8Array(16));
      const keyA = await generateKey(testPassword, saltA);
      const keyB = await generateKey(testPassword, saltB);
      const enc = await encrypt('check', keyA);
      await expect(decrypt(enc.encrypted, enc.iv, keyB)).rejects.toThrow();
    });
  });

  describe('encrypt', () => {
    test('should encrypt plain text', async () => {
      const plaintext = 'Hello, World!';
      const encrypted = await encrypt(plaintext, testKey);
      expect(encrypted).toBeDefined();
      expect(encrypted.iv).toBeDefined();
      expect(encrypted.encrypted).toBeDefined();
      expect(encrypted.encrypted).not.toEqual(plaintext);
    });

    test('should handle empty string', async () => {
      const encrypted = await encrypt('', testKey);
      expect(encrypted).toBeDefined();
    });

    test('should handle special characters', async () => {
      const plaintext = 'Test@#$%^&*()_+-={}[]|\\:";\'<>?,./';
      const encrypted = await encrypt(plaintext, testKey);
      expect(encrypted).toBeDefined();
    });
  });

  describe('decrypt', () => {
    test('should decrypt encrypted text', async () => {
      const plaintext = 'Hello, World!';
      const encrypted = await encrypt(plaintext, testKey);
      const decrypted = await decrypt(encrypted.encrypted, encrypted.iv, testKey);
      expect(decrypted).toBe(plaintext);
    });

    test('should handle empty string', async () => {
      const encrypted = await encrypt('', testKey);
      const decrypted = await decrypt(encrypted.encrypted, encrypted.iv, testKey);
      expect(decrypted).toBe('');
    });

    test('should handle special characters', async () => {
      const plaintext = 'Test@#$%^&*()_+-={}[]|\\:";\'<>?,./';
      const encrypted = await encrypt(plaintext, testKey);
      const decrypted = await decrypt(encrypted.encrypted, encrypted.iv, testKey);
      expect(decrypted).toBe(plaintext);
    });

    test('should fail with wrong key', async () => {
      const plaintext = 'Secret Message';
      const encrypted = await encrypt(plaintext, testKey);
      const wrongSalt = crypto.getRandomValues(new Uint8Array(16));
      const wrongKey = await generateKey('DifferentPassword', wrongSalt);
      await expect(decrypt(encrypted.encrypted, encrypted.iv, wrongKey)).rejects.toThrow();
    });

    test('should fail with tampered data', async () => {
      const plaintext = 'Secret Message';
      const encrypted = await encrypt(plaintext, testKey);
      // Tamper with the last byte of the ciphertext
      const tampered = { ...encrypted, encrypted: [...encrypted.encrypted] };
      tampered.encrypted[tampered.encrypted.length - 1] ^= 0xff;
      await expect(decrypt(tampered.encrypted, tampered.iv, testKey)).rejects.toThrow();
    });
  });

  describe('round-trip encryption', () => {
    test('should maintain data integrity through multiple encrypt/decrypt cycles', async () => {
      const plaintext = 'Test data for round-trip encryption';
      let current = plaintext;
      for (let i = 0; i < 5; i++) {
        const encrypted = await encrypt(current, testKey);
        current = await decrypt(encrypted.encrypted, encrypted.iv, testKey);
      }
      expect(current).toBe(plaintext);
    });
  });

  describe('encryptBackup / decryptBackup (used by app.js export/import)', () => {
    test('should round-trip a JSON backup with the correct password', async () => {
      const data = JSON.stringify({ materials: [{ id: 1, name: 'Bearing' }] });
      const pkg = await encryptBackup(data, testPassword);
      expect(pkg.encrypted).toBe(true);
      expect(pkg.salt).toBeDefined();
      expect(pkg.iv).toBeDefined();

      const restored = await decryptBackup(pkg, testPassword);
      expect(restored).toBe(data);
    });

    test('should reject the wrong password', async () => {
      const data = JSON.stringify({ hello: 'world' });
      const pkg = await encryptBackup(data, testPassword);
      await expect(decryptBackup(pkg, 'WrongPassword')).rejects.toThrow();
    });
  });
});
