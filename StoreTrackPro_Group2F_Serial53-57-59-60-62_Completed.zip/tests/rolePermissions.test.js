// Regression tests for StoreTrack Pro v5 role permissions.
global.addAudit = jest.fn();
global.toast = jest.fn();
global.nav = jest.fn();
global._removeAllEventListeners = jest.fn();

const auth = require('../modules/auth.js');

describe('role permission matrix', () => {
  beforeEach(() => {
    cu = null;
    auth.passwordChangeRequired = false;
    global.toast.mockClear();
  });

  test('Store Person can register, receive, verify, and export, but not maintenance actions', () => {
    cu = { role: 'store', active: true };
    expect(auth.canRoleAction('partRegister')).toBe(true);
    expect(auth.canRoleAction('stockReceive')).toBe(true);
    expect(auth.canRoleAction('physicalStock')).toBe(true);
    expect(auth.canRoleAction('pdfExcelExport')).toBe(true);
    expect(auth.canRoleAction('replacement')).toBe(false);
    expect(auth.canRoleAction('repairScrap')).toBe(false);
  });

  test('Maintenance Officer can consume, replace, repair/scrap, import history, and export', () => {
    cu = { role: 'maintenance', active: true };
    for (const action of [
      'consumption',
      'replacement',
      'repairScrap',
      'consumptionImport',
      'transactionHistory',
      'pdfExcelExport',
    ]) {
      expect(auth.canRoleAction(action)).toBe(true);
    }
    expect(auth.canRoleAction('stockReceive')).toBe(false);
    expect(auth.canRoleAction('physicalStock')).toBe(false);
  });

  test('Auditor is read-only for month-end, zero-stock, history, audit trail, and exports', () => {
    cu = { role: 'auditor', active: true };
    for (const action of [
      'reports',
      'monthEndReports',
      'zeroStockReports',
      'transactionHistory',
      'auditTrail',
      'pdfExcelExport',
    ]) {
      expect(auth.canRoleAction(action)).toBe(true);
    }
    expect(auth.canRoleAction('monthEndClose')).toBe(false);
    expect(auth.canRoleAction('replacement')).toBe(false);
  });

  test('Admin is limited by explicit Developer permission overrides', () => {
    cu = { role: 'admin', active: true, permissions: { stockReceive: false, reports: true } };
    expect(auth.canRoleAction('stockReceive')).toBe(false);
    expect(auth.canRoleAction('reports')).toBe(true);
  });

  test('button-level actions resolve through aliases', () => {
    cu = { role: 'store', active: true };
    expect(auth.canRoleAction('procIn')).toBe(true);
    expect(auth.canRoleAction('saveMat')).toBe(true);
    expect(auth.canRoleAction('saveReturn')).toBe(true);
    expect(auth.canRoleAction('procOut')).toBe(true);

    cu = { role: 'maintenance', active: true };
    expect(auth.canRoleAction('procOut')).toBe(true);
    expect(auth.canRoleAction('saveReturn')).toBe(true);
    expect(auth.canRoleAction('procIn')).toBe(false);
  });

  test('Developer remains unrestricted', () => {
    cu = { role: 'developer', active: true };
    expect(auth.canRoleAction('anythingTheDeveloperAllows')).toBe(true);
  });
});
