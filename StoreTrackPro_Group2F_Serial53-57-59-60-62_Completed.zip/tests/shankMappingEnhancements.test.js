const fs = require('fs');
const path = require('path');

describe('Shank Mapping production enhancements', () => {
  const moduleSource = fs.readFileSync(
    path.join(__dirname, '..', 'modules', 'componentManagement.js'),
    'utf8',
  );
  const indexSource = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');

  test('has a dedicated Station Alias Master UI and normalized identity support', () => {
    expect(indexSource).toContain("componentOpen('aliases')");
    expect(moduleSource).toContain('function stationAliases()');
    expect(moduleSource).toContain('normalStation');
    expect(moduleSource).toContain('componentSaveStationAlias');
  });

  test('Stock search cascades from Part No. to matching Station and Bin', () => {
    expect(moduleSource).toContain('stockFilterRowsForPart');
    expect(moduleSource).toContain('componentRefreshStockFilterControls()');
    expect(moduleSource).toContain('componentRefreshStockFilterBins()');
    expect(moduleSource).toContain("sameStation(row.dataset.station || '', station)");
    expect(moduleSource).toContain("cmMatch(row.dataset.bin || '', bin)");
    expect(moduleSource).toContain('Type or select Part No. first');
    expect(moduleSource).toContain('Type or select Station first');
  });

  test('creates automatic month-opening snapshots without replacing manual snapshots', () => {
    expect(moduleSource).toContain('ensureAutomaticOpeningSnapshot');
    expect(moduleSource).toContain('opening-auto-${month}');
    expect(moduleSource).toContain('automatic: true');
    expect(moduleSource).toContain('Save Opening Snapshot');
  });

  test('exposes editable import preview decisions', () => {
    expect(moduleSource).toContain('cm-import-edit');
    expect(moduleSource).toContain('Apply Preview Edits');
    expect(moduleSource).toContain('quantitySource');
    expect(moduleSource).toContain('componentApplyImportPreviewEdits');
  });

  test('provides granular replacement lifecycle drill-down', () => {
    expect(moduleSource).toContain('function replacementDrillDown');
    expect(moduleSource).toContain('componentReplacementDrillDown');
    expect(moduleSource).toContain('Confirm Repair Return');
    expect(moduleSource).toContain("'Repair Return'");
  });

  test('preserves the approved physical label contract', () => {
    expect(moduleSource).toContain(
      '<div class="label-meta"><div class="title">${esc(r.stationNo)} <span>|</span> ${esc(r.binId)}</div></div>',
    );
    expect(moduleSource).toContain('FIX SHANK PART NO.');
    expect(moduleSource).toContain('MOVING SHANK PART NO.');
    expect(moduleSource).toContain(
      '@page{size:${dimensions.width}mm ${dimensions.height}mm;margin:0}',
    );
    expect(moduleSource).toContain(
      '.pencil-label:last-child{page-break-after:auto;break-after:auto}',
    );
    expect(moduleSource).toContain('min-width:0;border-collapse:collapse');
  });

  test('Common Bin labels keep all guns on one physical label without pagination', () => {
    expect(moduleSource).toContain('Physical bin sticker: one Common Bin = one sticker');
    expect(moduleSource).toContain('const labelHtml = layouts.map(({ r,');
    expect(moduleSource).toContain('const pages = []');
    expect(moduleSource).not.toContain(
      'const rowsPerPage = Math.max(1, Math.floor(usableHeight / rowHeight) - 1)',
    );
    expect(moduleSource).not.toContain('for (let i = 0; i < sourceRows.length; i += rowsPerPage)');
    expect(moduleSource).not.toContain('continuation: i > 0');
  });

  test('keeps the full import preview compact while retaining source data on demand', () => {
    expect(moduleSource).toContain('cm-import-preview-table');
    expect(moduleSource).toContain('max-height:70vh');
    expect(moduleSource).toContain('<details class="cm-source-details">');
    expect(moduleSource).toContain('View source component fields');
  });
});
