const fs = require('fs');
const path = require('path');
const vm = require('vm');

function loadBrowserModule(relativePath, exportsExpression, overrides = {}) {
  const windowObject = {
    databaseReady: false,
    addEventListener: jest.fn(),
    ...(overrides.window || {})
  };
  const context = vm.createContext({
    console,
    Date,
    Math,
    Map,
    Set,
    Promise,
    Number,
    String,
    Object,
    Array,
    Error,
    JSON,
    RegExp,
    Blob,
    window: windowObject,
    document: {
      readyState: 'complete',
      addEventListener: jest.fn(),
      querySelector: jest.fn(() => null),
      ...(overrides.document || {})
    },
    navigator: { userAgent: 'audit-test' },
    gAll: jest.fn(async () => []),
    gOne: jest.fn(async () => null),
    dPut: jest.fn(async () => {}),
    setInterval: jest.fn(() => 1),
    clearInterval: jest.fn(),
    setTimeout: jest.fn(() => 1),
    ...(overrides.globals || {})
  });
  const source = fs.readFileSync(path.join(__dirname, '..', relativePath), 'utf8');
  return vm.runInContext(`${source}\n;(${exportsExpression})`, context, { filename: relativePath });
}

describe('audit inventory regressions', () => {
  test('purchase order discounts and cumulative partial receipts remain correct and idempotent', async () => {
    const materials = new Map([['B1', { id: 'B1', barcode: 'B1', stock: 0 }]]);
    const dPutMany = jest.fn(async (entries) => {
      entries.forEach(({ store, obj }) => {
        if (store === 'materials') materials.set(obj.barcode, obj);
      });
    });
    const { PurchaseOrder, PurchaseOrderManager } = loadBrowserModule(
      'modules/purchaseOrderManagement.js',
      '({ PurchaseOrder, PurchaseOrderManager })',
      {
        window: { dPutMany },
        globals: { gOne: jest.fn(async (_store, barcode) => materials.get(barcode)) }
      }
    );
    const order = new PurchaseOrder({
      id: 'po-1',
      status: 'ordered',
      items: [{ id: 'line-1', barcode: 'B1', quantity: 10, unitPrice: 5, discount: 20 }]
    });
    order.calculateTotals();
    expect(order.subtotal).toBe(40);

    const manager = Object.create(PurchaseOrderManager.prototype);
    manager.orders = new Map([['po-1', order]]);
    await manager.receiveOrder('po-1', { items: [{ barcode: 'B1', quantity: 4 }] }, 'receiver');
    expect(order.status).toBe('partially_received');
    expect(materials.get('B1').stock).toBe(4);

    await manager.receiveOrder('po-1', { items: [{ barcode: 'B1', quantity: 4 }] }, 'receiver');
    expect(materials.get('B1').stock).toBe(4);
    await manager.receiveOrder('po-1', { items: [{ barcode: 'B1', quantity: 10 }] }, 'receiver');
    expect(order.status).toBe('received');
    expect(materials.get('B1').stock).toBe(10);
  });

  test('failed atomic receipt commit leaves the order and material unchanged', async () => {
    const materials = new Map([['B1', { id: 'B1', barcode: 'B1', stock: 0 }]]);
    const { PurchaseOrder, PurchaseOrderManager } = loadBrowserModule(
      'modules/purchaseOrderManagement.js',
      '({ PurchaseOrder, PurchaseOrderManager })',
      {
        window: { dPutMany: jest.fn(async () => { throw new Error('simulated write failure'); }) },
        globals: { gOne: jest.fn(async (_store, barcode) => materials.get(barcode)) }
      }
    );
    const order = new PurchaseOrder({
      id: 'po-2',
      status: 'ordered',
      items: [{ id: 'line-2', barcode: 'B1', quantity: 5, receivedQuantity: 0 }]
    });
    const manager = Object.create(PurchaseOrderManager.prototype);
    manager.orders = new Map([['po-2', order]]);

    await expect(manager.receiveOrder('po-2', { items: [{ barcode: 'B1', quantity: 2 }] }, 'receiver'))
      .rejects.toThrow('simulated write failure');
    expect(order.status).toBe('ordered');
    expect(order.items[0].receivedQuantity).toBe(0);
    expect(materials.get('B1').stock).toBe(0);
  });

  test('packing completion requires every ordered unit to be packed', async () => {
    const { PackingList, PackingShippingManager } = loadBrowserModule(
      'modules/packingShipping.js',
      '({ PackingList, PackingShippingManager })'
    );
    const packingList = new PackingList({ id: 'pack-1', items: [{ id: 'item-1', quantity: 10 }] });
    const manager = Object.create(PackingShippingManager.prototype);
    manager.packingLists = new Map([['pack-1', packingList]]);
    manager.savePackingList = jest.fn(async () => {});

    await manager.packItem('pack-1', 'item-1', 1);
    expect(packingList.isComplete()).toBe(false);
    expect(packingList.getProgress()).toBe(10);
    await expect(manager.completePacking('pack-1')).rejects.toThrow('all required quantities');
    await manager.packItem('pack-1', 'item-1', 9);
    expect(packingList.isComplete()).toBe(true);
    expect(packingList.getProgress()).toBe(100);
  });

  test('bin assignment rejects another SKU and capacity overflow without replacing the stored SKU', async () => {
    const { BinLocation, BinLocationManager } = loadBrowserModule(
      'modules/binLocationManagement.js',
      '({ BinLocation, BinLocationManager })'
    );
    const bin = new BinLocation({
      id: 'bin-1', binCode: 'B-1', capacity: 10,
      itemId: 'sku-1', barcode: 'A-1', quantity: 8, currentLoad: 8
    });
    const manager = Object.create(BinLocationManager.prototype);
    manager.bins = new Map([['bin-1', bin]]);
    manager.saveBin = jest.fn(async () => {});

    await expect(manager.assignItemToBin('bin-1', { itemId: 'sku-2', barcode: 'B-2', quantity: 1 }))
      .rejects.toThrow(/different item/i);
    await expect(manager.assignItemToBin('bin-1', { itemId: 'sku-1', barcode: 'A-1', quantity: 11 }))
      .rejects.toThrow(/capacity/i);
    expect(bin.itemId).toBe('sku-1');
    expect(bin.currentLoad).toBe(8);
  });
});
