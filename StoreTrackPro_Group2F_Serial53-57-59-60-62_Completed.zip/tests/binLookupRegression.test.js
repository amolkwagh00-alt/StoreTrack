const fs = require('fs');
const path = require('path');
const { partKey } = require('../core/partNumber');

describe('Stock receiving Bin lookup', () => {
  const source = fs.readFileSync(
    path.join(__dirname, '..', 'modules', 'componentManagement.js'),
    'utf8',
  );

  test('uses canonical partKey for receive Bin lookup', () => {
    expect(source).toContain('function receiveMappedBinOptions(partNo) {');
    expect(source).toContain('const keys = new Set(family.map(partKey));');
  });

  test('normalizes 05-7265 consistently with mapping and stock keys', () => {
    expect(partKey('05-7265')).toBe(partKey('5-7265'));
    expect(partKey(' 05 - 7265 ')).toBe(partKey('05-7265'));
  });
});

module.exports = {};
