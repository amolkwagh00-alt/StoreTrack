const fs = require('fs');
const path = require('path');

const source = fs.readFileSync(path.join(__dirname, '../modules/centralSync.js'), 'utf8');
let stores;

function put(table, value) {
  const key = value.id;
  stores[table].set(key, { ...value });
}
function installSync(bridge) {
  stores = { central_meta: new Map(), central_queue: new Map(), materials: new Map(), transactions: new Map() };
  window.gOne = async (table, id) => stores[table].get(id) || null;
  window.gAll = async table => [...stores[table].values()].map(item => ({ ...item }));
  window.dPut = async (table, value) => put(table, value);
  window.dDel = async (table, id) => stores[table].delete(id);
  window.centralBridge = bridge;
  window.renderMaster = jest.fn();
  window.updateDash = jest.fn();
  window.eval(source);
  return window.centralSync;
}

beforeEach(() => {
  jest.useFakeTimers();
  jest.setSystemTime(new Date('2026-01-01T00:00:00Z'));
  window.centralBridge = undefined;
  window.M = [];
});
afterEach(() => {
  jest.useRealTimers();
  delete window.centralSync;
  delete window.gOne;
  delete window.gAll;
  delete window.dPut;
  delete window.dDel;
  delete window.centralBridge;
});

test('overlapping pulls are single-flight; an empty pull does not render or health-check', async () => {
  let resolvePull;
  const pullChanges = jest.fn(() => new Promise(resolve => { resolvePull = resolve; }));
  const getStatus = jest.fn(async () => ({ configured: true, online: true, latencyMs: 1 }));
  const sync = installSync({ pullChanges, getStatus });
  const first = sync.pullChanges();
  const second = sync.pullChanges();
  await Promise.resolve();
  await Promise.resolve();
  expect(pullChanges).toHaveBeenCalledTimes(1);
  resolvePull({ changes: [] });
  await Promise.all([first, second]);
  expect(window.renderMaster).not.toHaveBeenCalled();
  expect(window.updateDash).not.toHaveBeenCalled();
  expect(getStatus).not.toHaveBeenCalled();
});

test('overlapping health checks share one status request', async () => {
  let resolveStatus;
  const getStatus = jest.fn(() => new Promise(resolve => { resolveStatus = resolve; }));
  const sync = installSync({ getStatus });
  const first = sync.checkHealth();
  const second = sync.checkHealth();
  expect(getStatus).toHaveBeenCalledTimes(1);
  resolveStatus({ configured: true, online: true, latencyMs: 10 });
  await Promise.all([first, second]);
});

test('queue retries use bounded jittered backoff and defer ineligible records', async () => {
  const commitStock = jest.fn().mockRejectedValue(new Error('temporary outage'));
  const getStatus = jest.fn(async () => ({ configured: true, online: false, latencyMs: 0 }));
  const sync = installSync({ commitStock, getStatus });
  await sync.submit({ id: 'txn-1' });
  await sync.flushQueue();
  let queued = stores.central_queue.get('txn-1');
  expect(queued.attempts).toBe(1);
  expect(queued.nextAttemptAt).toBeGreaterThanOrEqual(Date.now() + 4000);
  expect(queued.nextAttemptAt).toBeLessThanOrEqual(Date.now() + 6000);
  commitStock.mockClear();
  await sync.flushQueue();
  expect(commitStock).not.toHaveBeenCalled();
  jest.setSystemTime(new Date(queued.nextAttemptAt + 1));
  await sync.flushQueue();
  queued = stores.central_queue.get('txn-1');
  expect(commitStock).toHaveBeenCalledTimes(1);
  expect(queued.attempts).toBe(2);
  expect(queued.nextAttemptAt - Date.now()).toBeGreaterThanOrEqual(12000);
  expect(queued.nextAttemptAt - Date.now()).toBeLessThanOrEqual(18000);
});

test('non-conflict central client errors are not retried as transient transport failures', async () => {
  const error = Object.assign(new Error('Invalid quantity'), { statusCode: 400 });
  const sync = installSync({ commitStock: jest.fn().mockRejectedValue(error) });
  await expect(sync.submit({ id: 'invalid-txn' })).rejects.toBe(error);
  expect(stores.central_queue.size).toBe(0);
});

test('immediate 409 responses are saved in conflict state for operator review', async () => {
  const error = Object.assign(new Error('Insufficient stock. Available: 2'), { statusCode: 409, body: { error: 'Insufficient stock' } });
  const sync = installSync({ commitStock: jest.fn().mockRejectedValue(error) });
  await expect(sync.submit({ id: 'direct-conflict', itemId: 'part-1', qty: 5 })).resolves.toMatchObject({ conflict: true });
  expect(stores.central_queue.get('direct-conflict')).toMatchObject({ status: 'conflict', errorStatus: 409 });
});

test('terminal queue failures stay visible and can be explicitly retried', async () => {
  const commitStock = jest.fn().mockRejectedValue(new Error('still unavailable'));
  const sync = installSync({ commitStock, getStatus: async () => ({ configured: true, online: false }) });
  put('central_queue', { id: 'old', transaction: { id: 'old' }, status: 'queued', attempts: 9, queuedAt: '2025-01-01' });
  await sync.flushQueue();
  expect((await sync.getFailedQueueItems()).map(item => item.id)).toEqual(['old']);
  expect(stores.central_queue.get('old').status).toBe('failed');
  commitStock.mockResolvedValue({ ok: true });
  await expect(sync.retryFailedQueueItem('old')).resolves.toEqual({ retried: 1, items: ['old'] });
  expect(stores.central_queue.has('old')).toBe(false);
  expect(commitStock).toHaveBeenCalledTimes(2);
});

test('409 queue conflicts are preserved for review and are never automatically retried', async () => {
  const conflict = Object.assign(new Error('Insufficient stock. Available: 2'), { statusCode: 409, body: { error: 'Insufficient stock' } });
  const commitStock = jest.fn().mockRejectedValue(conflict);
  const sync = installSync({ commitStock });
  put('central_queue', { id: 'tx-conflict', transaction: { id: 'tx-conflict', itemId: 'part-1', qty: 5 }, status: 'queued', attempts: 0, queuedAt: '2026-01-01' });
  await sync.flushQueue();
  const saved = stores.central_queue.get('tx-conflict');
  expect(saved.status).toBe('conflict');
  expect(saved.conflictBody).toEqual({ error: 'Insufficient stock' });
  expect(saved.nextAttemptAt).toBeNull();
  expect((await sync.getConflictQueueItems()).map(item => item.id)).toEqual(['tx-conflict']);
  commitStock.mockClear();
  await sync.flushQueue();
  expect(commitStock).not.toHaveBeenCalled();
});

test('conflict correction validates same material and fresh transaction ID before removing original', async () => {
  const sync = installSync({ commitStock: jest.fn().mockResolvedValue({ ok: true }) });
  put('central_queue', { id: 'tx-old', transaction: { id: 'tx-old', itemId: 'part-1', qty: 5 }, status: 'conflict' });
  await expect(sync.resolveConflict('tx-old', { id: 'tx-old', itemId: 'part-1', qty: 2 })).rejects.toThrow(/new transaction ID/);
  await expect(sync.resolveConflict('tx-old', { id: 'tx-new', itemId: 'part-2', qty: 2 })).rejects.toThrow(/cannot change the original material/);
  expect(stores.central_queue.has('tx-old')).toBe(true);
  await expect(sync.resolveConflict('tx-old', { id: 'tx-new', itemId: 'part-1', qty: 2 })).resolves.toMatchObject({ ok: true, resolvedFrom: 'tx-old' });
  expect(stores.central_queue.has('tx-old')).toBe(false);
});
