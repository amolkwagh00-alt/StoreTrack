const fs = require('fs');
const path = require('path');
const vm = require('vm');

const appSource = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');

function extractFunction(source, name) {
  const match = source.match(new RegExp(`(?:async\\s+)?function\\s+${name}\\s*\\(`));
  if (!match) { throw new Error(`Missing function ${name}`); }
  const start = match.index;
  const open = source.indexOf('{', start);
  let depth = 0;
  for (let i = open; i < source.length; i += 1) {
    if (source[i] === '{') { depth += 1; }
    if (source[i] === '}') {
      depth -= 1;
      if (depth === 0) { return source.slice(start, i + 1); }
    }
  }
  throw new Error(`Unclosed function ${name}`);
}

function createFakeDatabase(initial = {}) {
  const rows = Object.fromEntries(Object.entries(initial).map(([store, values]) => [store, structuredClone(values)]));
  let failNextPut = false;
  return {
    rows,
    failNextPut() { failNextPut = true; },
    database: {
      transaction(stores) {
        const staged = Object.fromEntries(stores.map(store => [store, structuredClone(rows[store] || [])]));
        const actions = [];
        const tx = {
          objectStore(store) {
            return {
              clear() { actions.push(() => { staged[store] = []; }); },
              put(row) {
                actions.push(() => {
                  if (failNextPut) { failNextPut = false; throw new Error('simulated write failure'); }
                  staged[store].push(structuredClone(row));
                });
              },
            };
          },
          abort() { tx.aborted = true; },
        };
        queueMicrotask(() => {
          if (tx.aborted) { tx.onabort?.(); return; }
          try {
            actions.forEach(action => action());
            stores.forEach(store => { rows[store] = staged[store]; });
            tx.oncomplete?.();
          } catch (error) {
            tx.error = error;
            tx.onerror?.();
          }
        });
        return tx;
      },
    },
  };
}

describe('StoreTrack app.js audit-fix regressions', () => {
  test('forced password change and admin reset use the exposed basic-plus-common-password validator', () => {
    const passStrong = extractFunction(appSource, 'passStrong');
    const context = { window: { passwordPolicy: { isCommonPassword: password => password.toLowerCase() === 'password1' } } };
    vm.runInNewContext(`${passStrong}; window.passStrong=passStrong;`, context);
    expect(context.window.passStrong('abc123')).toBe(true);
    expect(context.window.passStrong('short')).toBe(false);
    expect(context.window.passStrong('password1')).toBe(false);
    const changePassword = extractFunction(appSource, 'changePassword');
    const adminReset = extractFunction(appSource, 'doAdminResetPw');
    expect(changePassword).toContain('window.passStrong(nw)');
    expect(adminReset).toContain('window.passStrong(pw)');
    expect(appSource).toContain('window.passStrong=passStrong;');
  });

  test('mark-all-read and single-read reject notifications outside the current user/role audience', async () => {
    const visible = extractFunction(appSource, 'isNotificationVisibleToCurrentUser');
    const markAll = extractFunction(appSource, 'markAllNotifsRead');
    const markOne = extractFunction(appSource, 'markNotifRead');
    const records = [
      { id: 'visible', userId: 12, audienceRoles: ['admin'], read: false },
      { id: 'other-user', userId: 99, audienceRoles: ['admin'], read: false },
      { id: 'other-role', userId: null, audienceRoles: ['developer'], read: false },
      { id: 'legacy-public', read: false },
    ];
    const writes = [];
    const context = {
      cu: { id: 12, role: 'admin' },
      Date,
      gAll: async () => records,
      gOne: async id => records.find(row => row.id === id),
      dPut: async (store, row) => writes.push(row.id),
      renderNotifDropdown: async () => {},
    };
    vm.runInNewContext(`${visible}; ${markAll}; ${markOne};`, context);
    expect(records.map(row => context.isNotificationVisibleToCurrentUser(row))).toEqual([true, false, false, true]);
    await context.markAllNotifsRead();
    expect(writes.sort()).toEqual(['legacy-public', 'visible']);
    expect(records.find(row => row.id === 'other-user').read).toBe(false);
    expect(records.find(row => row.id === 'other-role').read).toBe(false);
    await context.markNotifRead('other-user');
    expect(writes).toHaveLength(2);
  });

  test('complete restore prevalidates stores and a failed IndexedDB transaction leaves originals intact', async () => {
    const validate = extractFunction(appSource, 'validateCompleteRestoreStores');
    const replace = extractFunction(appSource, 'replaceStoresAtomically');
    const fake = createFakeDatabase({ materials: [{ id: 'old', stock: 3 }], transactions: [{ id: 'old-tx' }] });
    const context = { window: { getStoreNames: () => ['materials', 'transactions'], getDB: () => fake.database } };
    vm.runInNewContext(`${validate}; ${replace};`, context);
    expect(() => context.validateCompleteRestoreStores({ materials: [{ id: 'new' }], missing: [] })).toThrow('Unknown backup store');
    expect(() => context.validateCompleteRestoreStores({ materials: [{ stock: 2 }] })).toThrow('Invalid record');
    expect(fake.rows.materials).toEqual([{ id: 'old', stock: 3 }]);

    fake.failNextPut();
    await expect(context.replaceStoresAtomically({ materials: [{ id: 'new', stock: 8 }], transactions: [] }))
      .rejects.toThrow('simulated write failure');
    expect(fake.rows.materials).toEqual([{ id: 'old', stock: 3 }]);
    expect(fake.rows.transactions).toEqual([{ id: 'old-tx' }]);
    expect(appSource).toContain('await replaceStoresAtomically(storesToRestore)');
    expect(appSource).toContain('await replaceStoresAtomically(previousStores)');
  });

  test('material and transaction writes invalidate the stock forecast cache, including approval batch writes', async () => {
    const start = appSource.indexOf('// The stock forecast consumes both material stock');
    const end = appSource.indexOf('async function loadAll()', start);
    expect(start).toBeGreaterThanOrEqual(0);
    expect(end).toBeGreaterThan(start);
    const wrappers = appSource.slice(start, end);
    const cacheDelete = jest.fn();
    const context = {
      window: {
        cacheManager: { delete: cacheDelete },
        dPut: async () => 'one',
        dPutMany: async () => 'many',
        batchPut: async () => 'batch',
        dDel: async () => 'delete',
        dClr: async () => 'clear',
      },
    };
    vm.runInNewContext(wrappers, context);
    await context.window.dPut('materials', { id: 1 });
    expect(cacheDelete).toHaveBeenCalledWith('stock-forecast');
    cacheDelete.mockClear();
    await context.window.dPutMany([{ store: 'approvals', obj: { id: 1 } }, { store: 'transactions', obj: { id: 2 } }]);
    expect(cacheDelete).toHaveBeenCalledWith('stock-forecast');
    cacheDelete.mockClear();
    await context.window.batchPut('users', [{ id: 2 }]);
    expect(cacheDelete).not.toHaveBeenCalled();
    await context.window.batchPut('materials', [{ id: 3 }]);
    expect(cacheDelete).toHaveBeenCalledWith('stock-forecast');
    cacheDelete.mockClear();
    await context.window.dDel('transactions', 'tx-1');
    expect(cacheDelete).toHaveBeenCalledWith('stock-forecast');
    cacheDelete.mockClear();
    await context.window.dClr('materials');
    expect(cacheDelete).toHaveBeenCalledWith('stock-forecast');
  });
});
