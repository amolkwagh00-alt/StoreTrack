const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'dashboardWidgets.js'), 'utf8');

function createWidgetHarness() {
  const document = {
    addEventListener() {},
    querySelector() { return null; },
    createElement() {
      const title = { textContent: '' };
      return {
        className: '',
        dataset: {},
        draggable: false,
        _innerHTML: '',
        get innerHTML() { return this._innerHTML; },
        set innerHTML(value) { this._innerHTML = value; },
        querySelector(selector) { return selector === '.widget-title' ? title : null; },
        title
      };
    }
  };
  const context = {
    document,
    window: {},
    console,
    gAll: async () => [],
    dClr: async () => {},
    batchPut: async () => {}
  };
  vm.createContext(context);
  vm.runInContext(`${source}\nglobalThis.WidgetManagerForTest = WidgetManager;`, context);
  return new context.WidgetManagerForTest();
}

test('each default dashboard widget receives its own semantic inline SVG icon', () => {
  const manager = createWidgetHarness();
  const expected = {
    'total-materials': 'materials',
    'low-stock': 'low-stock',
    'today-transactions': 'transactions',
    'stock-value': 'value',
    'recent-activity': 'activity',
    'stock-by-category': 'category'
  };

  for (const [id, iconName] of Object.entries(expected)) {
    const markup = manager.getWidgetIcon(id);
    expect(markup).toContain(`data-widget-icon="${iconName}"`);
    expect(markup).toContain('<svg');
    expect(markup).toContain('aria-hidden="true"');
  }
});

test('widget controls use inline SVGs and retain accessible action labels', async () => {
  const manager = createWidgetHarness();
  const widget = await manager.renderWidget({
    id: 'total-materials',
    title: 'Total Materials',
    type: 'metric',
    size: 'medium'
  });

  expect(widget.innerHTML).toContain('aria-label="Change widget size"');
  expect(widget.innerHTML).toContain('aria-label="Edit widget settings"');
  expect(widget.innerHTML).toContain('aria-label="Remove widget"');
  expect(widget.innerHTML).toContain('class="widget-control-icon"');
  expect(widget.innerHTML).not.toMatch(/[⬌⚙✕]/u);
});

test('custom widget titles are assigned as text instead of injected as HTML', async () => {
  const manager = createWidgetHarness();
  const hostileTitle = '<img src=x onerror=alert(1)>';
  const widget = await manager.renderWidget({
    id: 'total-materials',
    title: hostileTitle,
    type: 'metric',
    size: 'medium'
  });

  expect(widget.title.textContent).toBe(hostileTitle);
  expect(widget.innerHTML).not.toContain(hostileTitle);
});
