const fs = require('fs');
const path = require('path');
const analytics = require(path.join('..', 'modules', 'shankConsumptionAnalytics.js'));

describe('Historical Shank Consumption import', () => {
  const root = path.join(__dirname, '..');
  const database = fs.readFileSync(path.join(root, 'modules', 'database.js'), 'utf8');
  const component = fs.readFileSync(path.join(root, 'modules', 'componentManagement.js'), 'utf8');
  const ui = fs.readFileSync(path.join(root, 'modules', 'shankConsumptionAnalyticsUI.js'), 'utf8');

  test('declares a dedicated IndexedDB store and version upgrade', () => {
    expect(database).toContain('const VER = 23');
    expect(database).toContain("'component_historical_consumption'");
  });

  test('historical mode is visible in the Replacement List Import UI', () => {
    expect(component).toContain('Historical Consumption — analytics only');
    expect(component).toContain('cr-import-mode');
  });

  test('historical commit validates Part Master, date, quantity, and stock immutability', () => {
    expect(component).toContain('partByNo(partNo)');
    expect(component).toContain('Number.isInteger(quantity)');
    expect(component).toContain('quantity < 1');
    expect(component).toContain('stockChanged: false');
  });

  test('preview, batch lifecycle, progress, and rejected-row export are wired', () => {
    expect(component).toContain('historicalPreviewSummary');
    expect(component).toContain('downloadHistoricalRejected');
    expect(component).toContain('importBatchId');
    expect(component).toContain('deleteHistoricalImportBatch');
    expect(component).toContain('validCount');
    expect(component).toContain('duplicateCount');
    expect(component).toContain('cr-import-progress');
    expect(component).toContain('componentDownloadHistoricalTemplate');
  });

  test('manual historical entry rejects duplicates before saving', () => {
    expect(component).toContain('Duplicate historical consumption entry detected');
    expect(component).toContain('historicalFingerprint');
    expect(component).toContain('current stock was not changed');
  });

  test('historical rows are merged into Consumption Analytics and Procurement inputs', () => {
    expect(component).toContain('function consumptionRows()');
    expect(component).toContain('calculateConsumption(consumptionRows()');
    expect(component).toContain(
      'calculateForecast({today: monthEndDate, parts: state.parts, stock: state.stock, replacements: consumptionRows()',
    );
    expect(ui).toContain("window.gAll('component_historical_consumption')");
    expect(ui).toContain('const allConsumption = [...replacements, ...historical]');
  });

  test('historical rows influence usage calculations without being stock transactions', () => {
    const rows = [
      { partNo: 'P1', type: 'Replacement / Issue', quantity: 12, replacementDate: '2026-08-20' },
    ];
    const consumption = analytics.calculateConsumption(rows, { end: '2026-08-30', periodDays: 90 });
    expect(consumption.find((row) => row.partNo === 'P1').totalConsumption).toBe(12);
    expect(100).toBe(100);
  });

  test('analytics treats historical records as Replacement / Issue rows and preserves dates', () => {
    const [row] = analytics.calculateForecast({
      today: '2026-08-30',
      stock: [{ partNo: 'P1', quantity: 100 }],
      parts: [{ partNo: 'P1', occurrenceQty: 5 }],
      replacements: [
        { partNo: 'P1', type: 'Replacement / Issue', quantity: 10, date: '2026-08-29' },
      ],
    });
    expect(row.last7Days).toBe(10);
    expect(row.currentStock).toBe(100);
  });

  test('historical store participates in import rollback snapshots and backup export', () => {
    expect(component).toContain('STORES.historicalConsumption');
    expect(component).toContain('componentExportBackupData');
  });

  test('Central Sync explicitly excludes historical rows', () => {
    const central = fs.readFileSync(path.join(root, 'modules', 'centralSync.js'), 'utf8');
    expect(central).toContain('historical-local-only');
    expect(central).toContain('item.transaction?.historical');
  });

  test('History has separate type filter, batch entries, rollback, and manual entry', () => {
    expect(component).toContain('ch-type-filter');
    expect(component).toContain('LIVE');
    expect(component).toContain('HISTORICAL');
    expect(component).toContain('historicalBatches');
    expect(component).toContain('Delete Historical Batch');
    expect(component).toContain('cr-manual-historical-part');
    expect(component).toContain('componentSaveManualHistoricalConsumption');
  });

  test('manual historical entry auto-populates mapped station, gun, and component selectors', () => {
    expect(component).toContain('historicalPartOptions');
    expect(component).toContain('historicalMappingsForPart');
    expect(component).toContain('populateHistoricalPartDetails');
    expect(component).toContain('populateHistoricalGuns');
    expect(component).toContain('id="cr-manual-historical-station" list="cr-manual-historical-station-options"');
    expect(component).toContain('id="cr-manual-historical-gun" list="cr-manual-historical-gun-options"');
    expect(component).toContain('readonly');
    expect(component).toContain("for (const event of ['input', 'change']) { document.getElementById('cr-manual-historical-part')?.addEventListener(event, populateHistoricalPartDetails)");
    expect(component).toContain("document.getElementById('cr-manual-historical-station')?.addEventListener(event, populateHistoricalGuns)");
  });

  test('Shank Mapping BI Dashboard includes historical usage in metrics and trend source', () => {
    expect(component).toContain("consumptionRows().filter(t => t.type === 'Replacement / Issue'");
    expect(component).toContain('Historical Usage in Period');
    expect(component).toContain(
      'Usage metrics combine Live Replacement/Issue and Historical Consumption',
    );
  });
  test('BI Dashboard exposes Critical Awareness from Part Master configuration', () => {
    expect(component).toContain('Critical Awareness');
    expect(component).toContain('criticalRows');
    expect(component).toContain('criticalCount');
    expect(component).toContain('Critical Part No.');
  });
});
