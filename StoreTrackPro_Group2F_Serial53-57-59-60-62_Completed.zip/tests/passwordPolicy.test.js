// Unit tests for password policy module
const { PasswordPolicy } = require('../modules/passwordPolicy.js');

describe('Password Policy Module', () => {
  let passwordPolicy;

  beforeEach(() => {
    passwordPolicy = new PasswordPolicy();
  });

  describe('validate', () => {
    test('should reject password shorter than minimum length', () => {
      const result = passwordPolicy.validate('Ab1!');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Password must be at least 8 characters');
    });

    test('should reject password longer than maximum length', () => {
      const result = passwordPolicy.validate('A'.repeat(129));
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Password must not exceed 128 characters');
    });

    test('should reject password without uppercase', () => {
      const result = passwordPolicy.validate('abcdefgh1!');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Password must contain at least one uppercase letter');
    });

    test('should reject password without lowercase', () => {
      const result = passwordPolicy.validate('ABCDEFGH1!');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Password must contain at least one lowercase letter');
    });

    test('should reject password without number', () => {
      const result = passwordPolicy.validate('Abcdefgh!');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Password must contain at least one number');
    });

    test('should reject password without special character', () => {
      const result = passwordPolicy.validate('Abcdefgh1');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Password must contain at least one special character');
    });

    test('should accept valid strong password', () => {
      const result = passwordPolicy.validate('StrongP@ssw0rd');
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    test('should reject common passwords', () => {
      const result = passwordPolicy.validate('password123');
      expect(result.valid).toBe(false);
      expect(result.errors).toContain('Password is too common. Please choose a stronger password');
    });

    test('should warn about passwords containing user info', () => {
      const userInfo = { username: 'john', email: 'john@example.com' };
      const result = passwordPolicy.validate('John123!', userInfo);
      expect(result.warnings).toContain('Password should not contain personal information');
    });
  });

  describe('isCommonPassword', () => {
    test('should identify common passwords', () => {
      expect(passwordPolicy.isCommonPassword('password')).toBe(true);
      expect(passwordPolicy.isCommonPassword('123456')).toBe(true);
      expect(passwordPolicy.isCommonPassword('qwerty')).toBe(true);
    });

    test('should not identify uncommon passwords as common', () => {
      expect(passwordPolicy.isCommonPassword('MySecureP@ss123')).toBe(false);
      expect(passwordPolicy.isCommonPassword('RandomXk9#mL')).toBe(false);
    });
  });

  describe('recordFailedAttempt', () => {
    test('should record failed login attempt', () => {
      passwordPolicy.recordFailedAttempt('testuser');
      expect(passwordPolicy.failedAttempts.has('testuser')).toBe(true);
    });

    test('should increment attempt count for repeated failures', () => {
      passwordPolicy.recordFailedAttempt('testuser');
      passwordPolicy.recordFailedAttempt('testuser');
      // failedAttempts stores a plain count per user, not a {count, ...} object.
      const attempts = passwordPolicy.failedAttempts.get('testuser');
      expect(attempts).toBe(2);
    });
  });

  describe('isAccountLocked', () => {
    test('should lock account after max failed attempts', () => {
      for (let i = 0; i < 5; i++) {
        passwordPolicy.recordFailedAttempt('testuser');
      }
      expect(passwordPolicy.isAccountLocked('testuser')).toBe(true);
    });

    test('should not lock account below max attempts', () => {
      for (let i = 0; i < 4; i++) {
        passwordPolicy.recordFailedAttempt('testuser');
      }
      expect(passwordPolicy.isAccountLocked('testuser')).toBe(false);
    });

    test('should unlock after lockout duration', () => {
      // Mock the lock time to be in the past
      const pastTime = Date.now() - 16 * 60 * 1000; // 16 minutes ago

      for (let i = 0; i < 5; i++) {
        passwordPolicy.recordFailedAttempt('testuser');
      }

      // Manually set lock time to past
      const lockData = passwordPolicy.lockedAccounts.get('testuser');
      if (lockData) {
        lockData.lockedAt = pastTime;
      }

      expect(passwordPolicy.isAccountLocked('testuser')).toBe(false);
    });
  });

  describe('clearFailedAttempts', () => {
    test('should clear failed attempts on successful login', () => {
      passwordPolicy.recordFailedAttempt('testuser');
      passwordPolicy.clearFailedAttempts('testuser');
      expect(passwordPolicy.failedAttempts.has('testuser')).toBe(false);
    });
  });

  describe('getRemainingLockTime', () => {
    test('should return remaining lock time in milliseconds', () => {
      passwordPolicy.recordFailedAttempt('testuser');
      passwordPolicy.recordFailedAttempt('testuser');
      passwordPolicy.recordFailedAttempt('testuser');
      passwordPolicy.recordFailedAttempt('testuser');
      passwordPolicy.recordFailedAttempt('testuser');

      const remaining = passwordPolicy.getRemainingLockTime('testuser');
      expect(remaining).toBeGreaterThan(0);
      expect(remaining).toBeLessThanOrEqual(15 * 60 * 1000);
    });

    test('should return 0 if account not locked', () => {
      const remaining = passwordPolicy.getRemainingLockTime('nonexistent');
      expect(remaining).toBe(0);
    });
  });

  describe('password history (isInHistory / addToHistory)', () => {
    test('should prevent reuse of recent passwords', () => {
      const userId = 'testuser';
      const oldPasswords = ['OldPass1!', 'OldPass2!', 'OldPass3!'];

      oldPasswords.forEach((pwd) => {
        passwordPolicy.addToHistory(userId, pwd);
      });

      expect(passwordPolicy.isInHistory(userId, 'OldPass1!')).toBe(true);
    });

    test('should allow new passwords not in history', () => {
      const userId = 'testuser';
      passwordPolicy.addToHistory(userId, 'OldPass1!');

      expect(passwordPolicy.isInHistory(userId, 'NewPass2!')).toBe(false);
    });
  });

  describe('calculateStrength', () => {
    // calculateStrength() uses a 0-10 point scale (see maxScore) with a
    // `level` label — weak < 3, fair >= 3, good >= 5, strong >= 7,
    // excellent >= 9. This matches how app.js reads it: `const {level} =
    // window.passwordPolicy.calculateStrength(p)`.
    test('should calculate strength for weak passwords', () => {
      const strength = passwordPolicy.calculateStrength('weak');
      expect(strength.score).toBeLessThan(3);
      expect(strength.level).toBe('weak');
    });

    test('should calculate strength for strong passwords', () => {
      const strength = passwordPolicy.calculateStrength('Str0ng!P@ssw0rd');
      expect(strength.score).toBeGreaterThanOrEqual(7);
      expect(strength.level).toMatch(/strong|excellent/);
    });

    test('should calculate strength for medium passwords', () => {
      const strength = passwordPolicy.calculateStrength('Med1ump@ss');
      expect(strength.score).toBeGreaterThanOrEqual(3);
      expect(strength.score).toBeLessThan(7);
      expect(strength.level).toMatch(/fair|good/);
    });
  });
});
