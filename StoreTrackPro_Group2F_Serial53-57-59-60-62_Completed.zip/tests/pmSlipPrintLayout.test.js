const fs = require('fs');
const path = require('path');

const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'pm.js'), 'utf8');

function section(startMarker, endMarker) {
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start);
  if (start < 0 || end < 0) {
    throw new Error(`Could not locate source section: ${startMarker}`);
  }
  return source.slice(start, end);
}

describe('PM slip print layout', () => {
  test('slip body uses fixed, explicit column widths and safely escapes imported values', () => {
    const bodySource = section('function pmBuildSlipBodyHtml(', '// Full-size slip');
    const buildSlipBody = new Function(`${bodySource}; return pmBuildSlipBodyHtml;`)();
    const html = buildSlipBody('A & B', [{ equipment: 'Pump <A>', location: 'Bay 1', priority: 'High', weeklyPlan: '12', shift: '1st' }], 1);
    const cardSource = section('function pmBuildSlipHtml(', 'function pmGenerateCombinedSlipForPerson(');
    const buildSlipCard = new Function(`${bodySource}; ${cardSource}; return pmBuildSlipHtml;`)();
    const card = buildSlipCard('A & B', [{ equipment: 'Pump <A>' }]);

    expect(html).toContain('table-layout:fixed');
    expect(html).toContain('<colgroup><col style="width:42%"><col style="width:18%"><col style="width:12%"><col style="width:18%"><col style="width:10%"></colgroup>');
    expect(html).toContain('A &amp; B');
    expect(html).toContain('Pump &lt;A&gt;');
    expect(html).toContain('vertical-align:top');
    expect(card).toContain('class="pm-slip-card"');
    expect(card).toContain('max-width:125mm;margin:0 auto;padding:4mm;border:1px solid #333');
  });

  test('combined slip print uses the preserved styled markup instead of CSP data-style preview markup', () => {
    const generation = section('function pmGenerateCombinedSlipForPerson(', 'function pmGenerateCombinedSlipForSelected()');
    const print = section('function pmPrintSlip()', 'function pmBulkPrintSlips()');

    expect(generation).toContain('pmCurrentSlipPrintHtml = pmBuildSlipHtml(name, items)');
    expect(print).toContain('pmCurrentSlipPrintHtml || content.innerHTML.replace(/\\bdata-style="/g');
    expect(print).toContain('@page{size:A5 portrait;margin:7mm}');
    expect(print).toContain('.pm-slip-card{width:100%;max-width:125mm;margin:0 auto}');
  });

  test('separate slips are compact A5 pages and 5-up grid uses equal-height A4 cells', () => {
    const separate = section('function pmBulkPrintSlips()', '// Multi-up printing:');
    const grid = section('function pmPrintSlipsGrid(', 'function pmChecksheetItems(');

    expect(separate).toContain('@page{size:A5 portrait;margin:7mm}');
    expect(separate).toContain('pmBuildSlipHtml(n, pmDedupeItems(pmSchedules.filter(s => (s.who || \'Unassigned\') === n)), 0.92)');
    expect(separate).toContain('.pm-slip-page{width:100%;min-height:58mm;margin:0;padding:0');
    expect(grid).toContain('@page{size:A4 portrait;margin:6mm}');
    expect(grid).toContain('const fontScale = 0.92');
    expect(grid).toContain('perPage = 5; // fixed: 5 slips per page');
    expect(grid).toContain('pmBuildSlipHtml(n, pmDedupeItems(pmSchedules.filter(s => (s.who || \'Unassigned\') === n)), fontScale)');
    expect(grid).toContain('.pm-slip-page > tbody > tr{height:82mm}');
    expect(grid).toContain('.pm-slip-cell .pm-slip-card{min-height:78mm;margin:0 auto}');
    expect(grid).toContain('.pm-slip-cell-empty{border:none;background:transparent}');
    expect(grid).not.toContain('min-height:88mm');
  });
});
