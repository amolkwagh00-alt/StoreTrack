'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'dataBackup.js'), 'utf8');

function functionText(name) {
  const asyncStart = source.indexOf(`async function ${name}(`);
  const syncStart = source.indexOf(`function ${name}(`);
  const start = asyncStart >= 0 ? asyncStart : syncStart;
  assert.ok(start >= 0, `missing ${name}`);
  const open = source.indexOf(') {', start) + 2;
  assert.ok(open >= 2, `missing body for ${name}`);
  let depth = 0; let quote = null; let escaped = false;
  for (let i = open; i < source.length; i += 1) {
    const ch = source[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth += 1;
    if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`unterminated ${name}`);
}

function makeHarness({ confirmResult, failRestore = false } = {}) {
  const db = {
    storeA: [{ id: 'a-current', value: 'current' }],
    storeB: [{ id: 'b-current', value: 'preserve-me' }],
    users: [{ id: 'admin', passwordHash: 'secret' }],
  };
  const events = [];
  const local = {};
  let failOnce = failRestore;
  const host = { innerHTML: '' };
  const currentPayload = {
    format: 'StoreTrackProCompleteBackup',
    version: 2,
    createdAt: '2026-10-10T00:00:00.000Z',
    stores: { storeA: [{ id: 'a-backup', value: 'restored' }] },
  };
  const context = {
    console,
    setTimeout: () => 1,
    setInterval: () => 1,
    clearInterval() {},
    document: { getElementById: id => id === 'backup-restore-preview' ? host : null, readyState: 'complete', addEventListener() {}, querySelectorAll: () => [] },
    localStorage: { getItem: key => local[key] || null, setItem: (key, value) => { local[key] = value; }, removeItem: key => { delete local[key]; } },
    confirm: message => { events.push({ type: 'confirm', message }); return confirmResult; },
    toast: (message, type) => events.push({ type: 'toast', message, level: type }),
    audit: async (...args) => events.push({ type: 'audit', args }),
    window: {},
    DB: 'TestDB',
    STORES: ['storeA', 'storeB', 'users'],
    db,
    events,
    BACKUP_KEY: 'storetrack_last_backup_date',
    SECURITY_ACK_KEY: 'storetrack_plaintext_backup_warning_ack',
    getStoreNames: () => ['storeA', 'storeB', 'users'],
    gAll: async name => (db[name] || []).map(row => ({ ...row })),
    dClr: async name => { events.push({ type: 'clear', name }); db[name] = []; },
    dPut: async (name, row) => {
      events.push({ type: 'put', name, row: { ...row } });
      if (failOnce && name === 'storeA') { failOnce = false; throw new Error('injected restore failure'); }
      db[name] = db[name] || [];
      db[name].push({ ...row });
    },
  };
  context.rawRollback = async snapshot => {
    for (const [name, rows] of Object.entries(snapshot)) { if (name !== 'users') db[name] = rows.map(row => ({ ...row })); }
    events.push({ type: 'raw-rollback' });
  };
  context.window.backupBridge = {
    read: async () => ({ ok: true, fileName: 'older.json', data: JSON.stringify(currentPayload) }),
    write: async () => { events.push({ type: 'safety-backup' }); return { ok: true, fileName: 'safety.json' }; },
    writeRecoveryJournal: async serialized => { local.recoveryJournal = serialized; events.push({ type: 'journal-write' }); return { ok: true }; },
    readRecoveryJournal: async () => ({ ok: true, data: local.recoveryJournal || null }),
    clearRecoveryJournal: async () => { delete local.recoveryJournal; events.push({ type: 'journal-clear' }); return { ok: true }; },
  };
  const funcs = ['dateKey', 'statusText', 'isUserStore', 'readSnapshot', 'writeRestoreJournal', 'clearRestoreJournal', 'restoreRawSnapshot', 'recoverInterruptedRestore', 'collect', 'valid', 'validGRN', 'stable', 'compare', 'restoreTestRowKey', 'canonicalRestoreData', 'runIsolatedRestoreTest', 'saveRestoreVerification', 'escapeBackupHtml', 'createBackup', 'restoreBackup'];
  vm.runInNewContext(`const BACKUP_KEY='storetrack_last_backup_date'; const RESTORE_TEST_KEY='storetrack_last_restore_verification'; const SECURITY_ACK_KEY='storetrack_plaintext_backup_warning_ack'; ${funcs.map(functionText).join('\n')}\nreadSnapshot = async names => Object.fromEntries(names.filter(name => name !== 'users').map(name => [name, (db[name] || []).map(row => ({...row}))])); restoreRawSnapshot = rawRollback; this.restoreBackup=restoreBackup;`, context);
  return { context, db, events, host };
}

test('P02-F03 warning is visible and cancellation prevents restore', async () => {
  const h = makeHarness({ confirmResult: false });
  await h.context.restoreBackup();
  assert.match(h.host.innerHTML, /Partial restore warning/);
  assert.match(h.host.innerHTML, /storeB/);
  assert.match(h.host.innerHTML, /preserved/i);
  assert.equal(h.events.filter(e => e.type === 'confirm').length, 1);
  assert.equal(h.events.filter(e => e.type === 'safety-backup').length, 0);
  assert.deepEqual(h.db.storeA, [{ id: 'a-current', value: 'current' }]);
  assert.deepEqual(h.db.storeB, [{ id: 'b-current', value: 'preserve-me' }]);
});

test('P02-F03 explicit confirmation restores present stores and preserves absent stores', async () => {
  const h = makeHarness({ confirmResult: true });
  await h.context.restoreBackup();
  assert.equal(h.events.filter(e => e.type === 'confirm').length, 1);
  assert.equal(h.events.filter(e => e.type === 'safety-backup').length, 1);
  assert.deepEqual(h.db.storeA, [{ id: 'a-backup', value: 'restored' }]);
  assert.deepEqual(h.db.storeB, [{ id: 'b-current', value: 'preserve-me' }]);
  assert.deepEqual(h.db.users, [{ id: 'admin', passwordHash: 'secret' }]);
});

test('P02-F03 restore failure rolls back all touched stores and preserves absent stores', async () => {
  const h = makeHarness({ confirmResult: true, failRestore: true });
  await h.context.restoreBackup();
  assert.deepEqual(h.db.storeA, [{ id: 'a-current', value: 'current' }]);
  assert.deepEqual(h.db.storeB, [{ id: 'b-current', value: 'preserve-me' }]);
  assert.match(h.events.filter(e => e.type === 'toast').at(-1).message, /previous data was restored/i);
});
