const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { pathToFileURL } = require('url');

const mainSource = fs.readFileSync(path.join(__dirname, '..', 'main.js'), 'utf8');
const preloadSource = fs.readFileSync(path.join(__dirname, '..', 'preload.js'), 'utf8');

function extractFunction(name) {
  const start = mainSource.indexOf(`function ${name}(`);
  if (start < 0) { throw new Error(`Missing function ${name} in main.js`); }
  const bodyMarker = mainSource.indexOf(') {', start);
  if (bodyMarker < 0) { throw new Error(`Missing body for function ${name} in main.js`); }
  const open = bodyMarker + 2;
  let depth = 0;
  for (let index = open; index < mainSource.length; index++) {
    if (mainSource[index] === '{') { depth++; }
    if (mainSource[index] === '}') {
      depth--;
      if (depth === 0) { return mainSource.slice(start, index + 1); }
    }
  }
  throw new Error(`Unclosed function ${name} in main.js`);
}

function loadFunctions(names, bindings = {}) {
  const context = { URL, path, pathToFileURL, __dirname: path.join(__dirname, '..'), ...bindings };
  vm.createContext(context);
  vm.runInContext(names.map(extractFunction).join('\n'), context);
  return context;
}

describe('Electron main-process audit regressions', () => {
  test('privileged sender accepts only the canonical app document and its exact main frame', () => {
    const context = loadFunctions(['canonicalAppUrl', 'isCanonicalAppUrl', 'assertTrustedSender'], {
      mainWindow: null
    });
    const expected = pathToFileURL(path.join(__dirname, '..', 'index.html')).href;
    const sender = { mainFrame: null };
    const mainFrame = { url: expected };
    sender.mainFrame = mainFrame;

    expect(() => context.assertTrustedSender({ sender, senderFrame: mainFrame })).not.toThrow();
    expect(() => context.assertTrustedSender({ sender, senderFrame: { url: pathToFileURL(path.join(__dirname, '..', 'other.html')).href } })).toThrow(/Untrusted/);
    expect(() => context.assertTrustedSender({ sender, senderFrame: { url: expected } })).toThrow(/Untrusted/);
    expect(() => context.assertTrustedSender({ sender: { mainFrame }, senderFrame: mainFrame })).not.toThrow();
  });

  test('top-level navigation permits only canonical main document, blocking local-file and web redirects', () => {
    const context = loadFunctions(['canonicalAppUrl', 'isCanonicalAppUrl', 'shouldAllowMainNavigation']);
    const appUrl = pathToFileURL(path.join(__dirname, '..', 'index.html')).href;
    const otherFile = pathToFileURL(path.join(__dirname, '..', 'attacker.html')).href;

    expect(context.shouldAllowMainNavigation(appUrl)).toBe(true);
    expect(context.shouldAllowMainNavigation(otherFile)).toBe(false);
    expect(context.shouldAllowMainNavigation('https://example.invalid/redirect')).toBe(false);
    expect(mainSource).toMatch(/on\('will-navigate',[\s\S]*?shouldAllowMainNavigation/);
    expect(mainSource).toMatch(/on\('will-redirect',[\s\S]*?shouldAllowMainNavigation/);
  });

  test('retry delays are exponential, jittered, and capped at 60 seconds', () => {
    const { reconnectDelay } = loadFunctions(['reconnectDelay']);
    const lowerJitter = () => 0;
    const upperJitter = () => 0.999999;
    expect(reconnectDelay(0, lowerJitter)).toBe(2400);
    expect(reconnectDelay(1, lowerJitter)).toBe(4800);
    expect(reconnectDelay(2, lowerJitter)).toBe(9600);
    expect(reconnectDelay(99, lowerJitter)).toBe(48000);
    expect(reconnectDelay(99, upperJitter)).toBe(60000);
  });

  test('terminal authentication close codes/reasons are distinguishable from transient failures', () => {
    const { isTerminalSocketAuthError } = loadFunctions(['isTerminalSocketAuthError']);
    expect(isTerminalSocketAuthError(4401)).toBe(true);
    expect(isTerminalSocketAuthError(1008, 'invalid token')).toBe(true);
    expect(isTerminalSocketAuthError(1006, 'connection reset')).toBe(false);
    expect(mainSource).toMatch(/unexpected-response',[\s\S]*?\[401, 403\]/);
    expect(mainSource).toMatch(/central:logout',[\s\S]*?clearCredentials: true/);
    expect(preloadSource).toMatch(/logout:[^\n]*ipcRenderer\.invoke\('central:logout'\)/);
  });

  test('stream reset cancels a pending retry and invalidates stale socket callbacks', () => {
    const callbacks = new Map();
    const cleared = [];
    const fakeSetTimeout = jest.fn((callback, id) => { callbacks.set(id, callback); return id; });
    const fakeClearTimeout = jest.fn(id => { cleared.push(id); callbacks.delete(id); });
    const context = loadFunctions(['cancelCentralReconnect', 'resetCentralStream'], {
      centralReconnectTimer: 23,
      centralReconnectAttempt: 4,
      centralSocketGeneration: 9,
      centralConfig: { socket: { close: jest.fn() }, token: 'token', user: { id: 1 } },
      clearTimeout: fakeClearTimeout,
      setTimeout: fakeSetTimeout
    });
    context.resetCentralStream({ clearCredentials: true });
    expect(cleared).toEqual([23]);
    expect(context.centralReconnectTimer).toBeNull();
    expect(context.centralReconnectAttempt).toBe(0);
    expect(context.centralSocketGeneration).toBe(10);
    expect(context.centralConfig.socket).toBeNull();
    expect(context.centralConfig.token).toBe('');
    expect(context.centralConfig.user).toBeNull();
  });
});
