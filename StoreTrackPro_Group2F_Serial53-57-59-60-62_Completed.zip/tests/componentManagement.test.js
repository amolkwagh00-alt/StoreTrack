const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');
const vm = require('vm');

describe('Component Management implementation contract', () => {
  const root = path.join(__dirname, '..');
  const db = fs.readFileSync(path.join(root, 'modules/database.js'), 'utf8');
  const moduleSource = fs.readFileSync(path.join(root, 'modules/componentManagement.js'), 'utf8');
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

  test('stock receiving initializes sourceType before validating it', () => {
    const receiveStart = moduleSource.indexOf('async function receiveStock()');
    const receiveEnd = moduleSource.indexOf('function verify()', receiveStart);
    const receiveSource = moduleSource.slice(receiveStart, receiveEnd);
    const sourceDeclaration = receiveSource.indexOf("const sourceType = val('cs-source-type') || 'Supplier';");
    const sourceValidation = receiveSource.indexOf("!['Supplier', 'Arrangement'].includes(sourceType)");

    expect(receiveStart).toBeGreaterThanOrEqual(0);
    expect(sourceDeclaration).toBeGreaterThanOrEqual(0);
    expect(sourceValidation).toBeGreaterThan(sourceDeclaration);
  });

  test('Shank Receiving Enter shortcut activates the existing receive button only when confirmation is ready', () => {
    const start = moduleSource.indexOf('function wireReceiveEnterShortcut()');
    const end = moduleSource.indexOf('function ', start + 10);
    const helperSource = moduleSource.slice(start, end);
    expect(start).toBeGreaterThanOrEqual(0);
    expect(end).toBeGreaterThan(start);
    const dom = new JSDOM('<!doctype html><input id="cs-qty"><div id="cs-receive-confirmation" style="display:block"></div><button id="cs-receive-button"></button>');
    const helper = new Function('document', `${helperSource}; return wireReceiveEnterShortcut;`)(dom.window.document);
    helper();
    const button = dom.window.document.getElementById('cs-receive-button');
    let clicks = 0;
    button.addEventListener('click', () => { clicks += 1; });
    const quantityInput = dom.window.document.getElementById('cs-qty');
    const enter = new dom.window.KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true });
    quantityInput.dispatchEvent(enter);
    expect(enter.defaultPrevented).toBe(true);
    expect(clicks).toBe(1);
    dom.window.document.getElementById('cs-receive-confirmation').style.display = 'none';
    quantityInput.dispatchEvent(new dom.window.KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true }));
    expect(clicks).toBe(1);
    expect(moduleSource).toContain('Press Enter in the Quantity field to receive now');
    expect(moduleSource).toContain('id="cs-receive-button"');
    dom.window.close();
  });

  test('successful Shank receipt restores and selects the received Part No. while leaving quantity blank', () => {
    const start = moduleSource.indexOf('function restoreReceivedPartNoFocus()');
    const end = moduleSource.indexOf('function ', start + 10);
    const helperSource = moduleSource.slice(start, end);
    expect(start).toBeGreaterThanOrEqual(0);
    expect(end).toBeGreaterThan(start);
    const dom = new JSDOM('<!doctype html><input id="cs-part"><input id="cs-qty">');
    const harness = new Function('document', 'initialPartNo', `let receivePartNoAfterCommit = initialPartNo; ${helperSource}; return { run: restoreReceivedPartNoFocus, pending: () => receivePartNoAfterCommit };`)(dom.window.document, 'SHANK-0042');
    harness.run();
    const partInput = dom.window.document.getElementById('cs-part');
    expect(partInput.value).toBe('SHANK-0042');
    expect(dom.window.document.activeElement).toBe(partInput);
    expect(partInput.selectionStart).toBe(0);
    expect(partInput.selectionEnd).toBe('SHANK-0042'.length);
    expect(harness.pending()).toBe('');
    expect(dom.window.document.getElementById('cs-qty').value).toBe('');
    expect(moduleSource).toContain('receivePartNoAfterCommit = partNo; stock();');
    dom.window.close();
  });

  test('Enter after Part No dropdown selection moves focus to Total Received Quantity', async () => {
    const start = moduleSource.indexOf('function wireReceivePartNoEnterShortcut()');
    const end = moduleSource.indexOf('function ', start + 10);
    const helperSource = moduleSource.slice(start, end);
    expect(start).toBeGreaterThanOrEqual(0);
    expect(end).toBeGreaterThan(start);
    const dom = new JSDOM('<!doctype html><input id="cs-part" list="cs-parts"><datalist id="cs-parts"><option value="SHANK-0042"></datalist><input id="cs-qty" type="number">');
    const refresh = jest.fn();
    const helper = new Function('document', 'window', 'refreshReceiveMappedBins', `${helperSource}; return wireReceivePartNoEnterShortcut;`)(dom.window.document, dom.window, refresh);
    helper();
    const partInput = dom.window.document.getElementById('cs-part');
    const quantityInput = dom.window.document.getElementById('cs-qty');
    partInput.value = 'SHANK-0042'; // Represents the native datalist selection applied by Chromium.
    partInput.focus();
    const enter = new dom.window.KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true });
    partInput.dispatchEvent(enter);
    expect(enter.defaultPrevented).toBe(false); // Preserve Chromium's native datalist Enter selection.
    await new Promise(resolve => dom.window.setTimeout(resolve, 10));
    expect(refresh).toHaveBeenCalledTimes(1);
    expect(dom.window.document.activeElement).toBe(quantityInput);
    dom.window.close();
  });

  test('stock allocation preview explains missing mappings and target-max overflow', () => {
    const previewStart = moduleSource.indexOf('function renderReceiveAllocationPreview()');
    const previewEnd = moduleSource.indexOf('function refreshReceiveMappedBins()', previewStart);
    const previewSource = moduleSource.slice(previewStart, previewEnd);

    expect(previewSource).toContain('No active mapped Common Bin was found');
    expect(previewSource).toContain('Unable to calculate an allocation');
    expect(previewSource).toContain('exceed target max; the full receipt will still be recorded');
    expect(previewSource).toContain('preview.innerHTML');
  });

  test('stock receipt is fully allocated when all bins exceed their planning targets', () => {
    const planStart = moduleSource.indexOf('function allocationPlan(');
    const planEnd = moduleSource.indexOf('function applyAllocationOverrides(', planStart);
    const planSource = moduleSource.slice(planStart, planEnd);
    const roles = { family: ['PART-1'], original: ['PART-1'], alternatives: [] };
    const allocationPlan = vm.runInNewContext(`(${planSource})`, {
      partByNo: () => ({ minimumStock: 0 }),
      receivePartFamilyRoles: () => roles,
      receiveMappedBinOptions: () => [
        { binId: 'BIN-1', stationNo: 'ST-1', kitQty: 1 },
        { binId: 'BIN-2', stationNo: 'ST-2', kitQty: 1 },
      ],
      combinedStockQuantity: () => 0,
      partKey: value => String(value),
      autoSafetyQuantity: () => 0,
      allocationRecentConsumption: () => 0,
      allocationExpectedStockOut: () => ({ dailyUsage: 0, daysUntilZero: null, date: null }),
      compareAllocationPriority: (a, b) => (a.currentQty + a.quantity) - (b.currentQty + b.quantity)
        || String(a.binId).localeCompare(String(b.binId)),
    });

    const plan = allocationPlan('PART-1', 7);
    expect(plan.reduce((sum, row) => sum + row.quantity, 0)).toBe(7);
    expect(plan.some(row => row.currentQty + row.quantity > row.maximumQty)).toBe(true);
  });

  test('Parts Master supports low/zero stock, critical-part filters, and sorting', () => {
    expect(moduleSource).toContain('value="LOW STOCK"');
    expect(moduleSource).toContain('value="ZERO STOCK"');
    expect(moduleSource).toContain('cm-part-critical-filter');
    expect(moduleSource).toContain('Critical Parts');
    expect(moduleSource).toContain('cm-part-sort');
    expect(moduleSource).toContain('stock-asc');
    expect(moduleSource).toContain('stock-desc');
    expect(moduleSource).toContain('sortPartMasterRows()');
  });

  test('Parts Master supports activity and stock-status filtering', () => {
    expect(moduleSource).toContain('cm-part-active-filter');
    expect(moduleSource).toContain('cm-part-stock-filter');
    expect(moduleSource).toContain('data-active=');
    expect(moduleSource).toContain('data-stock-status=');
    expect(moduleSource).toContain('All Activity');
    expect(moduleSource).toContain('All Stock Status');
  });

  test('Parts Master supports description and component-type filtering', () => {
    expect(moduleSource).toContain('cm-part-description-filter');
    expect(moduleSource).toContain('cm-part-type-filter');
    expect(moduleSource).toContain('filterPartMasterRows()');
    expect(moduleSource).toContain('componentClearPartMasterFilters');
    expect(moduleSource).toContain('data-description=');
    expect(moduleSource).toContain('data-component-type=');
  });

  test('Part Master search provides an all-part dropdown while preserving manual search', () => {
    expect(moduleSource).toContain('list="cm-part-master-options"');
    expect(moduleSource).toContain('id="cm-part-master-options"');
    expect(moduleSource).toContain('state.parts.filter(p => validMappedPartNo(p.partNo))');
    expect(moduleSource).toContain('Type or select Part No.');
    expect(moduleSource).toContain('searchPartMaster()');
  });

  test('Manual Historical Consumption accepts a typed Part No. and keeps unlisted history analytics-only', () => {
    const saveStart = moduleSource.indexOf('async function saveManualHistoricalConsumption()');
    const saveEnd = moduleSource.indexOf('function historicalPartOptions()', saveStart);
    const manualSaveSource = moduleSource.slice(saveStart, saveEnd);
    expect(moduleSource).toContain('id="cr-manual-historical-part" list="cr-manual-historical-parts"');
    expect(moduleSource).toContain('id="cr-manual-historical-parts"');
    expect(manualSaveSource).toContain('if (!partNo || !date || !Number.isInteger(quantity) || quantity < 1)');
    expect(manualSaveSource).not.toContain('!partByNo(partNo)');
    expect(moduleSource).toContain('An unlisted historical Part No. can be entered manually');
    expect(moduleSource).toContain('component.readOnly = Boolean(part)');
    expect(moduleSource).toContain('stock was not changed.');
  });

  test('manual historical save accepts an unlisted Part No. without changing stock', async () => {
    const saveStart = moduleSource.indexOf('async function saveManualHistoricalConsumption()');
    const saveEnd = moduleSource.indexOf('function historicalPartOptions()', saveStart);
    const manualSaveSource = moduleSource.slice(saveStart, saveEnd);
    const values = {
      'cr-manual-historical-part': 'OLD-PENCIL-777',
      'cr-manual-historical-date': '2026-10-01',
      'cr-manual-historical-qty': '4',
      'cr-manual-historical-type': 'Pencil Shank',
      'cr-manual-historical-station': '',
      'cr-manual-historical-gun': '',
    };
    const saved = [];
    const auditEvents = [];
    let id = 0;
    const sandbox = {
      canComponent: () => true,
      val: key => values[key] || '',
      replacementImportNormalize: value => String(value || '').trim(),
      replacementImportDate: value => String(value || '').trim(),
      partByNo: () => null,
      canonicalStation: value => value,
      replacementMappingStatus: () => 'PART_NOT_FOUND',
      historicalFingerprint: row => JSON.stringify(row),
      gAll: async () => [],
      STORES: { historicalConsumption: 'historical-consumption', audit: 'audit' },
      uid: prefix => `${prefix}-${++id}`,
      window: { dPutMany: async writes => saved.push(...writes) },
      addAudit: async (...args) => auditEvents.push(args),
      nowIso: () => '2026-10-07T00:00:00.000Z',
      user: () => ({ username: 'tester' }),
      load: async () => {},
      replacementImportView: () => {},
      toastMsg: () => {},
    };
    vm.runInNewContext(manualSaveSource, sandbox);
    await sandbox.saveManualHistoricalConsumption();
    expect(saved).toHaveLength(2);
    expect(saved.map(write => write.store)).toEqual(['historical-consumption', 'audit']);
    expect(saved[0].obj).toMatchObject({
      partNo: 'OLD-PENCIL-777',
      newPartNo: 'OLD-PENCIL-777',
      quantity: 4,
      componentType: 'Pencil Shank',
      mappingStatus: 'PART_NOT_FOUND',
      historical: true,
    });
    expect(saved[1].obj.details).toMatchObject({ stockChanged: false });
    expect(auditEvents).toHaveLength(1);
  });

  test('manual historical entry preserves typed Station and Gun as mapping review without changing stock', async () => {
    const saveStart = moduleSource.indexOf('async function saveManualHistoricalConsumption()');
    const saveEnd = moduleSource.indexOf('function historicalPartOptions()', saveStart);
    const manualSaveSource = moduleSource.slice(saveStart, saveEnd);
    const values = {
      'cr-manual-historical-part': 'PART-REVIEW-1',
      'cr-manual-historical-date': '2026-10-02',
      'cr-manual-historical-qty': '2',
      'cr-manual-historical-type': 'Fix Shank',
      'cr-manual-historical-station': 'Station Manual 9',
      'cr-manual-historical-gun': 'Gun Manual 4',
    };
    const saved = [];
    const toasts = [];
    let id = 0;
    const sandbox = {
      canComponent: () => true,
      val: key => values[key] || '',
      replacementImportNormalize: value => String(value || '').trim(),
      replacementImportDate: value => String(value || '').trim(),
      partByNo: () => ({ componentType: 'Fix Shank' }),
      canonicalStation: value => String(value || '').trim(),
      replacementMappingForRow: () => ({ mapping: null }),
      replacementMappingStatus: () => 'MISMATCH',
      historicalFingerprint: row => JSON.stringify(row),
      gAll: async () => [],
      STORES: { historicalConsumption: 'historical-consumption', audit: 'audit' },
      uid: prefix => `${prefix}-${++id}`,
      window: { dPutMany: async writes => saved.push(...writes) },
      addAudit: async () => {},
      nowIso: () => '2026-10-07T00:00:00.000Z',
      user: () => ({ username: 'tester' }),
      load: async () => {},
      replacementImportView: () => {},
      toastMsg: (message, type) => toasts.push({ message, type }),
    };
    vm.runInNewContext(manualSaveSource, sandbox);
    await sandbox.saveManualHistoricalConsumption();
    expect(saved).toHaveLength(2);
    expect(saved[0].obj).toMatchObject({
      stationNo: 'Station Manual 9',
      gunReferenceNo: 'Gun Manual 4',
      mappingStatus: 'MISMATCH',
      historical: true,
    });
    expect(saved[1].obj.details).toMatchObject({ stockChanged: false });
    expect(toasts[0].message).toMatch(/mapping status MISMATCH.*stock was not changed/i);
  });

  test('opt-in table searches filter each selected column, including editable cell values, and can be cleared', () => {
    const start = moduleSource.indexOf('function tableSearchIndexes(');
    const end = moduleSource.indexOf('const cmSearchValue', start);
    expect(start).toBeGreaterThanOrEqual(0);
    expect(end).toBeGreaterThan(start);
    const helperSource = moduleSource.slice(start, end);
    const dom = new JSDOM('<!doctype html><div id="root"></div>');
    const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
    const helpers = new Function('document', 'esc', `${helperSource}; return { table, initTableColumnSearch };`)(dom.window.document, escapeHtml);
    const root = dom.window.document.getElementById('root');
    const rows = '<tr><td>ST-01</td><td><input value="PART-001"></td><td>GUN-A</td><td>FIX-AD-A</td></tr><tr><td>ST-02</td><td><input value="PART-002"></td><td>GUN-B</td><td>FIX-AD-B</td></tr>';
    root.innerHTML = helpers.table(['Station', 'Part No.', 'Gun Reference', 'Fix Adaptor'], rows, '', '', ['Station', 'Part No.', 'Gun Reference', 'Fix Adaptor']);
    helpers.initTableColumnSearch(root);
    const inputs = [...root.querySelectorAll('.cm-table-column-search')];
    const dataRows = [...root.querySelectorAll('tbody tr')];
    expect(inputs).toHaveLength(4);

    inputs[0].value = 'ST-02';
    inputs[0].dispatchEvent(new dom.window.Event('input', { bubbles: true }));
    expect(dataRows.map(row => row.style.display)).toEqual(['none', '']);
    expect(root.querySelector('.cm-table-search-summary').textContent).toBe('Showing 1 of 2');

    inputs[0].value = '';
    inputs[1].value = 'PART-002';
    inputs[3].value = 'FIX-AD-B';
    inputs[1].dispatchEvent(new dom.window.Event('input', { bubbles: true }));
    expect(dataRows.map(row => row.style.display)).toEqual(['none', '']);

    inputs[1].value = 'NOT-FOUND';
    inputs[1].dispatchEvent(new dom.window.Event('input', { bubbles: true }));
    expect(root.querySelector('.cm-table-search-empty')?.textContent).toBe('No matching records found.');
    root.querySelector('[data-table-search-clear]').click();
    expect(inputs.every(input => input.value === '')).toBe(true);
    expect(dataRows.map(row => row.style.display)).toEqual(['', '']);
    expect(root.querySelector('.cm-table-search-summary').textContent).toBe('Showing 2 of 2');
    dom.window.close();
  });

  test('major unfiltered tables expose relevant searches without duplicating existing Station/Part filters', () => {
    for (const token of [
      "['Station','Gun Reference','Position','Part No.','Bin ID','Exact Reason']",
      "['Gun References','Fix Shanks','Moving Shanks','All Mappings','Stock Availability']",
      "['Component Type','Bin','Stations','Gun References','Mapping Status']",
      "['Canonical Station','Alias']",
      'id="cm-life-gun-search"',
      'cm-table-search-summary',
      'Search Station, Gun, Part No., Components, Sheet',
    ]) {
      expect(moduleSource).toContain(token);
    }
    expect(moduleSource).toContain("['Station','Location','Bin']");
    expect(moduleSource).toContain("['Component Type','Bin','Stations','Gun References','Mapping Status']");
    expect(moduleSource).toContain("['Gun References','Fix Shanks','Moving Shanks','All Mappings','Stock Availability']");
    expect(moduleSource).toContain('function filterLifecycleRows()');
    expect(moduleSource).toContain('cmMatch(row.dataset.gun, gun)');
  });

  test('Gun Matrix preview searches all rows across pages and retains original edit indexes', () => {
    const start = moduleSource.indexOf('function importPreviewPageHtml(');
    const end = moduleSource.indexOf('function chooseImport()', start);
    expect(start).toBeGreaterThanOrEqual(0);
    expect(end).toBeGreaterThan(start);
    const helperSource = moduleSource.slice(start, end);
    const rows = Array.from({ length: 101 }, (_, index) => ({
      srNo: index + 1,
      sourceOrder: index + 1,
      status: 'Ready for Mapping',
      stationNo: `ST-${index}`,
      gunReferenceNo: `GUN-${index}`,
      quantity: 1,
      quantitySource: 'default',
      requiredQty: 1,
      sourceSheet: 'Sheet1',
      sourceRow: index + 2,
      fixShank: index === 100 ? 'SPECIAL-PN' : `FS-${index}`,
      movingShank: `MS-${index}`,
      fixAdaptor: `FA-${index}`,
      movingAdaptor: `MA-${index}`,
      fixHolder: `FH-${index}`,
      movingHolder: `MH-${index}`,
      pencilShank: `PS-${index}`,
      sourceHeaders: [],
      sourceValues: [],
    }));
    const escapedRows = JSON.stringify(rows);
    const script = `let pendingImport = { rows: ${escapedRows}, previewFilters: { partNo: 'SPECIAL-PN', fixAdaptor: 'FA-100' }, previewPage: 0 };\n` +
      `const MAPPED_PART_FIELDS = ['fixShank','movingShank','fixAdaptor','movingAdaptor','fixHolder','movingHolder','pencilShank'];\n` +
      `const IMPORT_PREVIEW_PAGE_SIZE = 100;\n` +
      `const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));\n` +
      `const btn = (label, action) => '<button>' + label + '</button>';\n` +
      `const table = (headers, body, empty) => '<table><thead><tr>' + headers.map(h => '<th>' + h + '</th>').join('') + '</tr></thead><tbody>' + (body || empty) + '</tbody></table>';\n` +
      `const vendorPartNo = value => String(value || '');\n` + helperSource +
      `JSON.stringify({ matches: importPreviewFilteredRows().map(item => item.index), page: renderImportPreviewPage() });`;
    const result = JSON.parse(vm.runInNewContext(script));
    expect(result.matches).toEqual([100]);
    expect(result.page).toContain('data-row="100"');
    expect(result.page).toContain('SPECIAL-PN');
    expect(result.page).toContain('1 matching; 101 total rows retained');
    for (const key of ['stationNo', 'partNo', 'gunReferenceNo', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder', 'fixShank', 'movingShank', 'pencilShank']) {
      expect(moduleSource).toContain(`key: '${key}'`);
    }
  });

  test('Import Preview shows Gun Reference No. and hides Gun Qty and X/C-GUN display fields', () => {
    expect(moduleSource).toContain("['Gun Reference No.', 'gunReferenceNo']");
    expect(moduleSource).toContain('hiddenImportPreviewHeader');
    expect(moduleSource).toContain('function hiddenImportPreviewHeader(header)');
    expect(moduleSource).toContain('x\\s*[-_]?\\s*gun');
    expect(moduleSource).toContain('c\\s*[-_]?\\s*gun');
    expect(moduleSource).not.toContain("['Gun', 'gunReferenceNo']");
    expect(moduleSource).not.toContain("['Qty', 'quantity']");
    expect(moduleSource).not.toContain("['Qty Source', 'quantitySource']");
  });

  test('all twelve source-row improvements are wired', () => {
    for (const token of [
      'component_gun_rows',
      'sourceKey',
      'sourceGunRows',
      'componentMappingRows',
      'duplicateSourceRows',
      'invalidRows',
      'reconciliation',
      'Station Pending',
      'Missing Component',
      'Ready for Mapping',
      'function gunRegister()',
      "'gun-register'",
      'BALANCED',
    ]) {
      expect(moduleSource).toContain(token);
    }
  });

  test('Bin Management reports valid Guns without Bin IDs before Stations without allocated Bins', () => {
    for (const token of [
      'function missingBinRecords()',
      "'Valid Gun — Bin ID Missing': 1",
      "'Station Assigned — Bin Not Allocated': 2",
      'MAPPING_BIN_ID_EMPTY',
      'STATION_COMMON_BIN_RECORD_MISSING',
      'BIN_REFERENCE_NOT_FOUND',
      'SOURCE_STATION_EMPTY',
      'SOURCE_GUN_REFERENCE_EMPTY',
      'SOURCE_HAS_NO_VALID_COMPONENT',
      'SOURCE_MAPPING_NOT_PERSISTED',
      'sourceKey=',
      'validComponentCount=',
      'No generic or random reason is generated.',
      "btn('Unallocated / Missing Bins', 'componentOpenMissingBinAllocations()')",
      'cm-missing-bin-table',
    ]) {
      expect(moduleSource).toContain(token);
    }
  });

  test('component domain stores and safe migration are declared', () => {
    expect(db).toContain('const VER = 23');
    expect(db).toContain("'component_gun_counts'");
    for (const store of [
      'component_parts',
      'component_mappings',
      'component_bins',
      'component_stock',
      'component_stock_transactions',
      'component_repair_scrap',
      'component_import_history',
      'component_audit_log',
      'component_replacements',
      'component_import_snapshots',
      'component_mapping_revisions',
      'component_station_aliases',
      'component_import_configs',
      'component_month_end_closes',
      'component_printer_profiles',
      'component_qr_audit',
    ]) {
      expect(db).toContain(`'${store}'`);
    }
    expect(db).toContain('if (!store.indexNames.contains(indexName))');
    expect(db).toContain('onupgradeneeded');
  });

  test('required workflow screens, guide, renamed navigation, and parser are wired', () => {
    for (const tab of [
      'guide',
      'dashboard',
      'replacement',
      'stock',
      'stock-zero',
      'parts',
      'matrix',
      'bins',
      'repair',
      'history',
      'reports',
      'labels',
      'import',
      'verify',
    ]) {
      expect(moduleSource).toContain(tab);
    }
    expect(html).toContain('aria-label="Shank Mapping"');
    expect(html).toContain("componentOpen('guide')");
    expect(html).toContain('assets/vendor/xlsx.full.min.js');
    expect(html).not.toContain('./node_modules/xlsx/dist/xlsx.full.min.js');
    expect(moduleSource).toContain('function getXlsxParser()');
    expect(moduleSource).toContain('parser.utils?.sheet_to_json');
  });

  test('Stock Status has one searchable sidebar route and replaces the separate Low Stock view', () => {
    expect(html).toContain(`componentOpen('stock-zero')`);
    expect(html).toContain('aria-label="Stock Status"');
    expect(moduleSource).toContain("'stock-zero': zeroStockView");
    expect(moduleSource).toContain("stockStatus: 'LOW STOCK' }; zeroStockView();");
    expect(moduleSource).not.toContain('function groupedAlertStockRows');
    const dashboardStart = moduleSource.indexOf('function dashboard()');
    const dashboardEnd = moduleSource.indexOf('function guide()', dashboardStart);
    const dashboardSource = moduleSource.slice(dashboardStart, dashboardEnd);
    expect(dashboardSource).not.toContain('Low / Zero Stock Alert');
    expect(dashboardSource).not.toContain('cm-dashboard-alert-table');
    expect(dashboardSource).toContain("cardMetric(low, 'Below Required Qty'");
    expect(moduleSource).toContain("function zeroStockView()");
    expect(moduleSource).toContain('function stockStatusRows()');
    expect(moduleSource).toContain('stockStatusRows()');
    expect(moduleSource).toContain('BELOW REQUIRED QTY');
    expect(moduleSource).toContain('Required Qty');
    expect(moduleSource).toContain('Shortage');
    for (const filter of [
      'cm-stock-part-search',
      'cm-stock-station-search',
      'cm-stock-bin-search',
      'cm-stock-type-search',
      'cm-stock-status-search',
    ]) {
      expect(moduleSource).toContain(filter);
    }
    expect(moduleSource).toContain('Type or select Part No.');
    expect(moduleSource).toContain('Type or select Station');
    expect(moduleSource).toContain('Type or select Bin');
    expect(moduleSource).toContain("btn('Export Excel', 'componentExportStockExcel()')");
    expect(moduleSource).toContain("btn('Export PDF', 'componentExportStockPdf()', true)");
  });

  test('Zero Stock renderer shows the zero row with Station/Bin and typed/dropdown search controls', () => {
    const start = moduleSource.indexOf('function zeroStockView() {');
    const end = moduleSource.indexOf('function stock()', start);
    const rendererSource = moduleSource.slice(start, end);
    let renderedTitle = '';
    let renderedMarkup = '';
    const zeroStockView = new Function(
      'window', 'stockStatusRows', 'partUsageComment', 'esc', 'shell', 'btn', 'table', 'refreshStockFilterControls', 'filterStockRows',
      `${rendererSource}; return zeroStockView;`,
    )(
      { componentBiNavigationContext: {} },
      () => [{ partNo: 'PART-ZERO', description: 'Part description', type: 'Pencil Shank', stationNo: 'ECA 20 RH/LH', binId: 'ECA-COMMON-20', quantity: 0, requiredQty: 2, minimumStock: 2, shortage: 2, status: 'ZERO STOCK', critical: true, locationComment: 'Pencil shared Qty 2 is held in PENCIL-BIN-01' }],
      () => 'Pencil Shank',
      value => String(value == null ? '' : value),
      (title, markup) => { renderedTitle = title; renderedMarkup = markup; },
      label => `<button>${label}</button>`,
      (headers, body, empty) => `<table><thead>${headers.join('|')}</thead><tbody>${body}</tbody><tfoot>${empty || ''}</tfoot></table>`,
      () => {},
      () => {},
    );

    zeroStockView();
    expect(renderedTitle).toBe('Shank Mapping — Stock Status & Zero Stock');
    expect(renderedMarkup).toContain('PART-ZERO');
    expect(renderedMarkup).toContain('ECA 20 RH/LH');
    expect(renderedMarkup).toContain('ECA-COMMON-20');
    expect(renderedMarkup).toContain('Required Qty');
    expect(renderedMarkup).toContain('Shortage Qty');
    expect(renderedMarkup).toContain('<td>0</td><td>2</td><td>2</td>');
    expect(renderedMarkup).toContain('CRITICAL');
    expect(renderedMarkup).toContain('PENCIL-BIN-01');
    expect(renderedMarkup).toContain('As of:');
    expect(renderedMarkup).toContain('Highest Shortage');
    expect(renderedMarkup).toContain('LOW STOCK');
    expect(renderedMarkup).toContain('Search Part No.');
    expect(renderedMarkup).toContain('Search Station');
    expect(renderedMarkup).toContain('Search Bin ID / Location');
    expect(renderedMarkup).toContain('Type or select Part No.');
    expect(renderedMarkup).toContain('Type or select Station');
    expect(renderedMarkup).toContain('Type or select Bin');
    expect(renderedMarkup).toContain('Export Excel');
    expect(renderedMarkup).toContain('Export PDF');
  });

  test('Stock Status sort orders shortage, available quantity, station, and part number', () => {
    const start = moduleSource.indexOf('  function sortStockStatusRows(');
    const end = moduleSource.indexOf('  function sortStockStatusTable()', start);
    const helperSource = moduleSource.slice(start, end).trim();
    const sortStockStatusRows = new Function(`${helperSource}; return sortStockStatusRows;`)();
    const rows = [
      { partNo: 'P-C', stationNo: 'ST-3', quantity: 1, shortage: 2 },
      { partNo: 'P-A', stationNo: 'ST-2', quantity: 0, shortage: 4 },
      { partNo: 'P-B', stationNo: 'ST-1', quantity: 2, shortage: 1 },
    ];
    expect(sortStockStatusRows(rows, 'shortage-desc').map(row => row.partNo)).toEqual(['P-A', 'P-C', 'P-B']);
    expect(sortStockStatusRows(rows, 'available-asc').map(row => row.partNo)).toEqual(['P-A', 'P-C', 'P-B']);
    expect(sortStockStatusRows(rows, 'station-asc').map(row => row.partNo)).toEqual(['P-B', 'P-A', 'P-C']);
    expect(sortStockStatusRows(rows, 'part-asc').map(row => row.partNo)).toEqual(['P-A', 'P-B', 'P-C']);
  });
  test('Stock Status report distinguishes Zero, Below Required Qty, and OK from total on-hand quantities', () => {
    const start = moduleSource.indexOf('function stockStatusRows() {');
    const end = moduleSource.indexOf('const STOCK_IMPORT_HEADERS', start);
    const aggregationSource = moduleSource.slice(start, end);
    const parts = [
      { partNo: 'PART-ZERO', minimumStock: 1 },
      { partNo: 'PART-SHORT', minimumStock: 0 },
      { partNo: 'PART-OK', minimumStock: 0 },
    ];
    const state = {
      parts,
      mappings: [
        { partNo: 'PART-ZERO', stationNo: 'ST-1' },
        { partNo: 'PART-SHORT', stationNo: 'ST-2' },
        { partNo: 'PART-OK', stationNo: 'ST-3' },
      ],
      stock: [
        { partNo: 'PART-ZERO', binId: 'BIN-1', quantity: 0, minimumStock: 1 },
        { partNo: 'PART-SHORT', binId: 'BIN-2', quantity: 1, minimumStock: 1 },
        { partNo: 'PART-OK', binId: 'BIN-3', quantity: 3, minimumStock: 3 },
      ],
      bins: [
        { binId: 'BIN-1', stationNo: 'ST-1' },
        { binId: 'BIN-2', stationNo: 'ST-2' },
        { binId: 'BIN-3', stationNo: 'ST-3' },
      ],
    };
    const stockStatusRows = new Function(
      'state', 'validMappedPartNo', 'vendorPartNo', 'partKey', 'partByNo', 'autoSafetyQuantity', 'canonicalStation',
      `${aggregationSource}; return stockStatusRows;`,
    )(
      state,
      value => Boolean(value),
      value => String(value || ''),
      value => String(value || '').toLowerCase(),
      partNo => parts.find(part => part.partNo === partNo),
      partNo => ({ 'PART-ZERO': 2, 'PART-SHORT': 3, 'PART-OK': 3 }[partNo] || 0),
      value => value,
    );
    const rows = stockStatusRows();
    expect(rows.map(row => [row.status, row.quantity, row.requiredQty, row.shortage])).toEqual([
      ['OK STOCK', 3, 3, 0],
      ['LOW STOCK', 1, 3, 2],
      ['ZERO STOCK', 0, 2, 2],
    ]);
  });

  test('Gun Matrix import has a bundled XLSX parser fallback', () => {
    expect(moduleSource).toContain('const parser = getXlsxParser()');
    expect(moduleSource).toContain(
      "parser.read(data, { type: 'array', cellHTML: true, cellStyles: true, cellNF: true, bookFiles: true })",
    );
    expect(moduleSource).toContain(
      'XLSX parser is unavailable. Restart the application or reinstall the bundled parser.',
    );
  });

  test('Gun Reference resolution excludes GUN TYPE and preserves X GUN/C GUN references', () => {
    expect(moduleSource).toContain("gunReferenceNo: ['gunno', 'gunreference'");
    expect(moduleSource).not.toContain("gunReferenceNo: ['gun',");
    expect(moduleSource).toContain(
      'const matches = (values || []).filter(cell => COLUMN_FIELDS.some(field => likelyField(cell, field))).length;',
    );
    expect(moduleSource).toContain('return matches >= 2;');
  });

  test('detected columns are visibly selected in the import mapping controls', () => {
    expect(moduleSource).toContain('const selected = d.columnMappings?.[f] || d.suggested?.[f] ||');
    expect(moduleSource).toContain("${String(h) === String(selected) ? 'selected' : ''}");
    expect(moduleSource).not.toContain(
      "fixAdaptor: ['fixadaptor', 'fixedadaptor', 'fixadapter', 'fixedadapter', 'movadaptor', 'movadapter']",
    );
  });

  test('replacement list import supports typed Excel/CSV intake only', () => {
    for (const token of [
      'Replacement List Import',
      'Import Excel/CSV',
      'parseReplacementCsv',
      'readReplacementImportFile',
      'inferReplacementOldPart',
      'componentCommitReplacementImport',
    ]) {
      expect(moduleSource).toContain(token);
    }
    expect(moduleSource).not.toContain('Import Handwritten Photo');
    expect(moduleSource).not.toContain('photoDataUrl');
    expect(moduleSource).not.toContain('tesseract.js');
    expect(moduleSource).not.toContain('readReplacementImageFile');
  });

  test('replacement import defaults to Historical Consumption and requires explicit LIVE selection to deduct stock', () => {
    expect(moduleSource).toContain("const importMode = pendingReplacementImport?.importMode || 'HISTORICAL'");
    expect(moduleSource).toContain("importMode: val('cr-import-mode') || 'HISTORICAL'");
    expect(moduleSource).toContain("const importMode = val('cr-import-mode') || pendingReplacementImport?.importMode || 'HISTORICAL'");
    expect(moduleSource).toContain('Historical Consumption (default) adds past usage to analytics only');
    expect(moduleSource).toContain('Explicitly choose Live Replacement to deduct stock');
    expect(moduleSource).toContain('stockChanged: false');
    expect(moduleSource).toContain('if (importMode === \'HISTORICAL\')');
    expect(moduleSource).toContain("option value=\"LIVE\"");
    expect(moduleSource).toContain("option value=\"HISTORICAL\"");
  });

  test('replacement import requires a verified Old Part instead of silently substituting the New Part', () => {
    expect(moduleSource).toContain('function inferReplacementOldPart(row)');
    expect(moduleSource).toContain('normalGunReference(mapping.gunReferenceNo) === normalGunReference(row.gunReferenceNo)');
    expect(moduleSource).toContain('data-field="oldPartNo"');
    expect(moduleSource).not.toContain('inferReplacementOldPart(row) || newPartNo');
    expect(moduleSource).toContain('function replacementMappingForRow(row)');
    expect(moduleSource).toContain('Component Type does not match the mapped component');
  });

  test('replacement list import preserves accountability and lifecycle posting', () => {
    for (const token of [
      'cr-import-person',
      'cr-import-team',
      'COMPONENT_REPLACEMENT_IMPORT_CREATE',
      'await window.dPutMany(writes)',
      "store: STORES.repair",
      "store: STORES.tx",
      'componentType: mapping.position',
    ]) {
      expect(moduleSource).toContain(token);
    }
  });

  test('live replacement import validates every row before its one atomic write', () => {
    const start = moduleSource.indexOf('async function commitReplacementImport()');
    const end = moduleSource.indexOf('async function saveReplacement()', start);
    const source = moduleSource.slice(start, end);
    const liveStart = source.indexOf("const personInput = val('cr-import-person')");
    const live = source.slice(liveStart);
    expect(live).toContain('replacementMappingForRow(row)');
    expect(live).toContain('No rows were imported.');
    expect(live).toContain('stagedStock');
    expect(live).toContain('await window.dPutMany(writes)');
    expect(live).not.toContain('await changeStock(');
    expect(live).not.toContain('await dPut(');
    expect(live).not.toContain('await createLifecycle(');
    expect(live.indexOf('Validate every row and compute all stock effects before writing any data.')).toBeLessThan(
      live.indexOf('await window.dPutMany(writes)'),
    );
    expect(live).toContain('state.replacements.unshift(...replacementsByRow)');
  });

  test('replacement mapping resolver rejects wrong components and ambiguous mappings', () => {
    const start = moduleSource.indexOf('function replacementMappingForRow(row)');
    const end = moduleSource.indexOf('function replacementMappingMatchesBin(', start);
    const helper = moduleSource.slice(start, end);
    const resolve = new Function(
      'state', 'replacementImportNormalize', 'canonicalStation', 'partKey', 'sameStation',
      'normalGunReference', 'pencilPositionKey', 'POSITIONS',
      `${helper}; return replacementMappingForRow;`,
    );
    const mappings = [
      { partNo: 'PART-01', stationNo: 'ST-01 RH', gunReferenceNo: 'GUN-1', position: 'Fix Shank', binId: 'BIN-COMMON' },
      { partNo: 'PART-01', stationNo: 'ST-01 RH', gunReferenceNo: 'GUN-1', position: 'Moving Shank', binId: 'BIN-COMMON' },
    ];
    const canonical = resolve(
      { mappings }, value => String(value || '').trim(), value => String(value || '').trim(),
      value => String(value || '').trim().toLowerCase(),
      (left, right) => String(left || '').toLowerCase() === String(right || '').toLowerCase(),
      value => String(value || '').replace(/[^a-z0-9]/gi, '').toLowerCase(),
      value => String(value || '').replace(/\bfixed\b/gi, 'fix').replace(/\bmobile\b/gi, 'moving'),
      ['Fix Shank', 'Moving Shank', 'Fix Adaptor', 'Moving Adaptor', 'Fix Holder', 'Moving Holder', 'Pencil Shank'],
    );
    expect(canonical({ newPartNo: 'PART-01', stationNo: 'ST-01 RH', gunReferenceNo: 'GUN-1', componentType: 'Fix Shank' }).mapping.position).toBe('Fix Shank');
    expect(canonical({ newPartNo: 'PART-01', stationNo: 'ST-01 RH', gunReferenceNo: 'GUN-1', componentType: 'Fix Holder' }).mapping).toBeNull();
    expect(canonical({ newPartNo: 'PART-01', stationNo: 'ST-01 RH', gunReferenceNo: 'GUN-1' }).mapping).toBeNull();

    const binStart = moduleSource.indexOf('function replacementMappingMatchesBin(');
    const binEnd = moduleSource.indexOf('function replacementMappingStatus(', binStart);
    const matchesBin = new Function('state', `${moduleSource.slice(binStart, binEnd)}; return replacementMappingMatchesBin;`)(
      { bins: [{ binId: 'OLD-LH', mergedInto: 'COMMON-RH-LH' }, { binId: 'COMMON-RH-LH', active: true }] },
    );
    expect(matchesBin({ binId: 'OLD-LH' }, { binId: 'COMMON-RH-LH' })).toBe(true);
    expect(matchesBin({ binId: 'OTHER-STATION' }, { binId: 'COMMON-RH-LH' })).toBe(false);
    expect(matchesBin({}, { binId: 'COMMON-RH-LH' })).toBe(false);
  });

  test('Old Part inference normalizes Gun references and rejects ambiguous matches', () => {
    const start = moduleSource.indexOf('function inferReplacementOldPart(row)');
    const end = moduleSource.indexOf('function replacementImportRowsHtml()', start);
    const helper = moduleSource.slice(start, end);
    const infer = new Function(
      'state', 'sameStation', 'normalGunReference', 'partByNo', 'replacementImportNormalize', 'pencilPositionKey', 'partKey',
      `${helper}; return inferReplacementOldPart;`,
    );
    const args = [
      (left, right) => String(left || '').toLowerCase() === String(right || '').toLowerCase(),
      value => String(value || '').replace(/[^a-z0-9]/gi, '').toLowerCase(),
      () => null,
      value => String(value || '').trim(),
      value => String(value || ''),
      value => String(value || '').trim().toLowerCase(),
    ];
    const unique = infer({ mappings: [{ partNo: 'OLD-PART', stationNo: 'ST-01 RH', gunReferenceNo: 'GUN-01', position: 'Fix Shank' }] }, ...args);
    expect(unique({ newPartNo: 'NEW-PART', stationNo: 'ST-01 RH', gunReferenceNo: 'Gun 01', componentType: 'Fix Shank' })).toBe('OLD-PART');
    const ambiguous = infer({ mappings: [
      { partNo: 'OLD-A', stationNo: 'ST-01 RH', gunReferenceNo: 'GUN-01', position: 'Fix Shank' },
      { partNo: 'OLD-B', stationNo: 'ST-01 RH', gunReferenceNo: 'Gun 01', position: 'Fix Shank' },
    ] }, ...args);
    expect(ambiguous({ newPartNo: 'NEW-PART', stationNo: 'ST-01 RH', gunReferenceNo: 'GUN-01', componentType: 'Fix Shank' })).toBe('');
  });

  test('Historical file import commits rows and audit in one database batch', () => {
    const start = moduleSource.indexOf('async function commitReplacementImport()');
    const end = moduleSource.indexOf('async function saveReplacement()', start);
    const historical = moduleSource.slice(start, end);
    expect(historical).toContain('Saving ${records.length} historical rows atomically');
    expect(historical).toContain('await window.dPutMany([...records.map(obj => ({ store: STORES.historicalConsumption, obj }))');
    expect(historical).not.toContain('Promise.all(chunk.map(record => dPut(STORES.historicalConsumption, record)))');
  });

  test('replacement entry and import use the active merged bin and reject stale manual bins', () => {
    const refreshStart = moduleSource.indexOf('function refreshReplacementBin()');
    const refreshEnd = moduleSource.indexOf('function replacementImportNormalize(', refreshStart);
    const refreshSource = moduleSource.slice(refreshStart, refreshEnd);
    expect(refreshSource).toContain('activeBinForStation(station)?.binId');

    const importStart = moduleSource.indexOf('async function commitReplacementImport()');
    const saveStart = moduleSource.indexOf('async function saveReplacement()', importStart);
    const importSource = moduleSource.slice(importStart, saveStart);
    expect(importSource.match(/activeBinForStation\(row\.stationNo\)/g)).toHaveLength(2);
    expect(importSource).not.toContain('binByStation(row.stationNo)');
    expect(importSource).toContain('no active bin is configured for Station');

    const saveEnd = moduleSource.indexOf('async function ensureStockRecord(', saveStart);
    const saveSource = moduleSource.slice(saveStart, saveEnd);
    expect(saveSource).toContain('activeBinForStation(stationNo)');
    expect(saveSource).toContain('String(binId) !== String(resolvedBin.binId)');
    expect(saveSource).toContain('replacementMappingMatchesBin(mapping, resolvedBin)');
  });

  test('live Replacement commits Old/New Part lifecycle, stock and audit in one transaction', () => {
    const saveStart = moduleSource.indexOf('async function saveReplacement()');
    const saveEnd = moduleSource.indexOf('async function ensureStockRecord(', saveStart);
    const save = moduleSource.slice(saveStart, saveEnd);
    expect(save).toContain('partNo: entry.oldPartNo || entry.partNo');
    expect(save).toContain('newPartNo: entry.newPartNo || entry.partNo');
    expect(save).toContain('await window.dPutMany([');
    expect(save).toContain('store: STORES.stock, obj: stockRow');
    expect(save).toContain('store: STORES.replacements, obj: entry');
    expect(save).toContain('store: STORES.repair, obj: lifecycle');
    expect(save).toContain('...auditRows.map(obj => ({ store: STORES.audit, obj }))');
    const start = moduleSource.indexOf('function lifecyclePartIdentityValid(row)');
    const end = moduleSource.indexOf('function repair() {', start);
    const lifecycle = moduleSource.slice(start, end);
    expect(lifecycle).toContain('function lifecyclePartIdentityValid(row)');
    expect(lifecycle).toContain('partKey(row.partNo) === partKey(expectedOldPart)');
    expect(lifecycle).toContain('partKey(row.newPartNo) === partKey(expectedNewPart)');
    expect(lifecycle).toContain('activeBinForStation(row.stationNo)');
    expect(lifecycle).toContain("type: 'Repair Return'");
    expect(lifecycle).toContain('await window.dPutMany([');
    expect(lifecycle).toContain('store: STORES.repair, obj: updatedLifecycle');

    const identityStart = lifecycle.indexOf('function lifecyclePartIdentityValid(row)');
    const identityEnd = lifecycle.indexOf('async function completeRepair(', identityStart);
    const identityValid = new Function(
      'state', 'partKey', `${lifecycle.slice(identityStart, identityEnd)}; return lifecyclePartIdentityValid;`,
    )({ replacements: [{ id: 'replacement-1', action: 'Repair', oldPartNo: 'OLD-B', newPartNo: 'NEW-A' }] }, value => String(value || '').toLowerCase());
    expect(identityValid({ sourceReplacementId: 'replacement-1', partNo: 'OLD-B', newPartNo: 'NEW-A' })).toBe(true);
    expect(identityValid({ sourceReplacementId: 'replacement-1', partNo: 'NEW-A', newPartNo: 'NEW-A' })).toBe(false);
    expect(identityValid({ sourceReplacementId: 'replacement-1', partNo: 'OLD-B', newPartNo: 'WRONG' })).toBe(false);
  });

  test('Shank Mapping tables and import inputs preserve complete digits and Part Numbers', () => {
    const styles = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');
    expect(styles).toContain('.cm-import-preview-table table{table-layout:auto;min-width:2400px}');
    expect(styles).toContain(
      '.cm-import-preview-table input{width:180px;min-width:180px;max-width:none',
    );
    expect(styles).toContain('text-overflow: clip;');
    expect(styles).toContain('overflow-wrap: anywhere;');
    expect(styles).toContain('word-break: break-word;');
    expect(styles).toContain('#component-management-content .tw { overflow-x: auto;');
  });

  test('Gun Matrix preview detects title-row and split-row headers from real workbook patterns', () => {
    for (const token of [
      'function detectHeaderInfo(matrix)',
      'function resolveSheetColumn(headers, field, selectedHeader)',
      'const sheetMeta = {}',
      'meta.dataStart',
      'gunreferncenumber',
      'while (dataStart < matrix.length',
      'const headers = meta.headers || []',
      'sourceRow = meta.dataStart + index + 1',
    ]) {
      expect(moduleSource).toContain(token);
    }
    expect(moduleSource).toContain(
      'sheetRows[sheetName] = Math.max(0, rows.length - meta.dataStart)',
    );
  });

  test('Spare Matrix keeps complete source data, including rows without mapped components', () => {
    expect(moduleSource).toContain('row.sourceOnly = !');
    expect(moduleSource).toContain('pendingImport.rows.push(row)');
    expect(moduleSource).toContain("['Complete Source Data', 'sourceData']");
    expect(moduleSource).toContain('sourceOnlyRows: pendingImport.sourceOnlyCount || 0');
    expect(moduleSource).toContain('if (row.sourceOnly) { continue; }');
  });

  test('Manual New Gun uses the Newly Added Guns parser and shared rollback-capable commit path', () => {
    for (const token of [
      'function openManualGunForm()',
      "const sheetName = 'Newly Added Guns'",
      'Max Qty',
      'manualEntry: true',
      'componentBuildImportPreview();',
      'Total source Gun rows: 1',
      'Source-only / Mapping Pending',
      'Stock quantity will not be increased.',
      "pendingImport.importMode = pendingImport.manualEntry ? 'MANUAL'",
      'protected: pendingImport.importMode === \'PERMANENT\'',
      "'COMPONENT_GUN_MANUAL_ADD'",
    ]) {
      expect(moduleSource).toContain(token);
    }
    expect(moduleSource).toContain('const duplicateConfirmed = Boolean(overlay.querySelector');
    expect(moduleSource).toContain('Canonical counts may still deduplicate identical Station + Gun references.');
    expect(moduleSource).toContain('if (row.sourceOnly) { continue; }');
  });

  test('Spare Matrix Dry Run ignores blank tail rows and distinguishes unavailable columns', () => {
    expect(moduleSource).toContain('const rowHasContent = values =>');
    expect(moduleSource).toContain(
      'if (!rowHasContent(values) || !pendingImport.manualEntry && rowLooksLikeHeader(values, headers))',
    );
    expect(moduleSource).toContain('const hasStationColumn = idx.stationNo >= 0');
    expect(moduleSource).toContain('if (!station && hasStationColumn)');
    expect(moduleSource).toContain('if (!gun && hasGunColumn)');
  });

  test('Spare Matrix import preserves the source display format and row snapshot', () => {
    expect(moduleSource).toContain("header: 1, defval: '', raw: false");
    expect(moduleSource).toContain('sourceHeaders: headers.slice(), sourceValues: values.slice()');
    expect(moduleSource).toContain('sourceSheets: Object.fromEntries');
    expect(moduleSource).toContain('sourceValues: row.sourceValues');
  });

  test('Modify suffix /M remains part of one Part No. during bold parsing', () => {
    expect(moduleSource).toContain("/^M$/i.test(slashParts[1])");
    expect(moduleSource).toContain("return [clean];");
  });

  test('Bold-only Part Number extraction supports one or many bold codes per cell', () => {
    expect(moduleSource).toContain('function boldPartsFromCell(cell, cellIsBold = false)');
    expect(moduleSource).toContain('function splitBoldPartText(value)');
    expect(moduleSource).toContain('boldParts: Object.fromEntries');
    expect(moduleSource).toContain('const selectedValueFor = field =>');
    expect(moduleSource).toContain('boldStyleCells(wb, sheetIndex)');
  });

  test('Bold Part No. is Original and non-bold values remain selectable Alternatives', () => {
    expect(moduleSource).toContain('partOptions: Object.fromEntries');
    expect(moduleSource).toContain('const original = bold[0] ||');
    expect(moduleSource).toContain('const alternatives = bold.length ? raw.filter');
    expect(moduleSource).not.toContain('const original = boldValueFor(field)[0] || raw[0]');
    expect(moduleSource).toContain('function partStockQuantity(partNo)');
    expect(moduleSource).toContain('select Original or Alternative');
    expect(moduleSource).toContain('Part Selection Pending — Original / Alternative');
    expect(moduleSource).toContain('return candidates.length > 1 && !original');
    expect(moduleSource).not.toContain('originalUnavailable');
  });

  test('Mov. Adaptor Excel header is detected as Moving Adaptor', () => {
    expect(moduleSource).toContain(
      "movingAdaptor: ['movingadaptor', 'movingadapter', 'movadaptor', 'movadapter']",
    );
    expect(moduleSource).toContain("['Moving Adaptor', 'movingAdaptor']");
  });

  test('Gun Matrix import preserves blank and N/A values and adds serial numbers', () => {
    expect(moduleSource).toContain('vendorPartNo(values[column])');
    expect(moduleSource).toContain(
      'const existingGunSerialBase = persistedGunSerials.length ? Math.max(...persistedGunSerials) : 0;',
    );
    expect(moduleSource).toContain('const sourceOrder = pendingImport.rows.length + 1;');
    expect(moduleSource).toContain(
      'const assignedSerial = Number(pendingImport.serialBase || 0) + sourceOrder;',
    );
    expect(moduleSource).toContain('sourceOrder, stationNo: station ||');
    expect(moduleSource).toContain("['SR No.', 'srNo']");
    expect(moduleSource).toContain('N/A remains N/A; blank remains blank');
  });

  test('QR label rows remain station-scoped and preserve repeated Part Numbers', () => {
    expect(moduleSource).toContain('const stationKey = baseStationKey(m.stationNo)');
    expect(moduleSource).toContain('const stations = new Map()');
    expect(moduleSource).toContain('station.guns.set(gunReferenceNo');
    expect(moduleSource).toContain(
      "binId: binByStation(m.stationNo)?.binId || state.bins.find(b => baseStationKey(b.stationNo) === stationKey)?.binId || ''",
    );
    expect(moduleSource).toContain('const sourceKey = Array.isArray(m.sourceRows)');
    expect(moduleSource).toContain('row.fixShank');
    expect(moduleSource).toContain('row.movingShank');
  });

  test('Fix Holder falls back into the Fix Shank label column when Fix Shank is absent', () => {
    expect(moduleSource).toContain(
      "['Fix Shank', 'Fix Adaptor', 'Fix Holder', 'Moving Shank', 'Moving Adaptor', 'Moving Holder']",
    );
    expect(moduleSource).toContain(
      "const fieldByPosition = { 'Fix Shank': 'fixShank', 'Fix Adaptor': 'fixAdaptor', 'Fix Holder': 'fixHolder', 'Moving Shank': 'movingShank', 'Moving Adaptor': 'movingAdaptor', 'Moving Holder': 'movingHolder' }",
    );
    expect(moduleSource).toContain('if (field) {row[field] = vendorPartNo(m.partNo);}');
  });

  test('Label markup prevents overlap and preserves complete Part Numbers', () => {
    expect(moduleSource).toContain('grid-template-rows:auto minmax(0,1fr)');
    expect(moduleSource).toContain('overflow-wrap:anywhere');
    expect(moduleSource).toContain('word-break:break-word');
    expect(moduleSource).toContain('label-table-wrap');
    expect(moduleSource).toContain('break-after:page');
    expect(moduleSource).toContain(
      '<div class="label-meta"><div class="title">${esc(r.stationNo)} <span>|</span> ${esc(r.binId)}</div></div>',
    );
    expect(moduleSource).toContain(
      "headers: ['FIX SHANK PART NO.', 'FIX ADAPTOR PART NO.', 'FIX HOLDER PART NO.', 'MOVING SHANK PART NO.', 'MOVING ADAPTOR PART NO.', 'MOVING HOLDER PART NO.']",
    );
    expect(moduleSource).toContain("headers: ['FIX PART NO.', 'MOVING PART NO.']");
  });

  test('printed label QR includes readable Station, Bin, and part data at scan-friendly size', () => {
    expect(moduleSource).toContain('`STATION: ${oneLine(row.stationNo)}`');
    expect(moduleSource).toContain('`BIN: ${oneLine(row.binId)}`');
    expect(moduleSource).toContain('`- FIX | ${oneLine(item.value)} | QTY: ${item.quantity}`');
    expect(moduleSource).toContain('`- MOVING | ${oneLine(item.value)} | QTY: ${item.quantity}`');
    expect(moduleSource).toContain("storetrack://station?stationNo=");
    expect(moduleSource).toContain('width:600,margin:4,errorCorrectionLevel:\'M\'');
    expect(moduleSource).toContain('Math.min(24, Math.max(20, cardH * 0.5))');
    expect(moduleSource).toContain('print-color-adjust:exact;-webkit-print-color-adjust:exact');
    const analyticsUiSource = fs.readFileSync(path.join(root, 'modules/shankConsumptionAnalyticsUI.js'), 'utf8');
    expect(analyticsUiSource).toContain('async function openQrDetails(stationNo, binId, scannedParts = [])');
    expect(analyticsUiSource).toContain('Part Details from Scanned Label');
    expect(analyticsUiSource).toContain('scannedPartBody');
    const appSource = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
    expect(appSource).toContain("return '';");
    expect(appSource).not.toContain('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAY');
  });

  test('Import preview renders all rows instead of truncating at 100', () => {
    expect(moduleSource).toContain('const pageSize = IMPORT_PREVIEW_PAGE_SIZE');
    expect(moduleSource).toContain('matchingRows.slice(pageStart, pageStart + pageSize)');
    expect(moduleSource).toContain('function importPreviewFilteredRows()');
    expect(moduleSource).toContain('map(({ row, index: rowIndex })');
    expect(moduleSource).toContain('data-row="${rowIndex}"');
    expect(moduleSource).not.toContain('pendingImport.rows.slice(0, 100)');
    expect(moduleSource).toContain(
      'Rows Scanned: ${pendingImport.rows.length + pendingImport.skipped.length}',
    );
  });

  test('Same Gun Reference at different Stations remains station-scoped', () => {
    expect(moduleSource).toContain('const mappingIdentity = (stationNo, gunReferenceNo, position)');
    expect(moduleSource).toContain(
      'mappingIdentity(m.stationNo, m.gunReferenceNo, m.position) === mappingIdentity(row.stationNo, row.gunReferenceNo, position)',
    );
    expect(moduleSource).toContain('activeBinForStation(stationNo) || binByStation(stationNo)');
    expect(moduleSource).toContain('srNo: `${row.stationNo}-${row.gunReferenceNo}-${position}`');
  });

  test('merged RH/LH active bin is the canonical station display source', () => {
    expect(moduleSource).toContain('function activeBinForStation(stationNo)');
    expect(moduleSource).toContain('(bin.mergedStations || []).some(station => baseStationKey(station) === key)');
    expect(moduleSource).toContain('function displayStationForBin(stationNo, binId)');
    expect(moduleSource).toContain("if (direct && direct !== 'Station Not Assigned' && mergedStations.some(station => sameStation(station, direct)))");
    expect(moduleSource).toContain("const sourceBin = binId ? state.bins.find(item => String(item.binId || '') === String(binId)) : null;");
    expect(moduleSource).toContain('const mergedActive = sourceBin?.mergedInto');
    expect(moduleSource).toContain("const mappingStations = [...new Set(state.mappings.filter(m => m && String(m.binId || '') === String(s.binId || '')");
    expect(moduleSource).toContain('const resolvedStation = displayStationForBin(stationNo, bin?.binId)');
  });

  test('LH/RH Common Bin merge is allowed only for 1 or 2 guns on each side', () => {
    expect(moduleSource).toContain('function mergeStationGunCount(station)');
    expect(moduleSource).toContain('const sourceGuns = mergeStationGunCount(source);');
    expect(moduleSource).toContain('const targetGuns = mergeStationGunCount(target);');
    expect(moduleSource).toContain('sourceGuns < 1 || sourceGuns > 2 || targetGuns < 1 || targetGuns > 2');
    expect(moduleSource).toContain('RH/LH Common Bin merge is allowed only when each side has 1 or 2 guns.');
  });

  test('Common Bin merge updates stock and transactions to the canonical merged bin', () => {
    expect(moduleSource).toContain("for (const row of state.stock.filter(item => String(item.binId || '') === String(previousTargetBinId)))");
    expect(moduleSource).toContain("for (const row of state.tx.filter(item => String(item.binId || '') === String(previousTargetBinId)))");
    expect(moduleSource).toContain('row.binId = mergedBinId;');
    expect(moduleSource).toContain('samePartNo(item.partNo, row.partNo)');
    expect(moduleSource).toContain('duplicate.quantity = Number(duplicate.quantity || 0) + Number(row.quantity || 0);');
  });

  test('Existing Common Bin cannot be merged a second time', () => {
    expect(moduleSource).toContain('const existingCommonBin = state.bins.find(bin => {');
    expect(moduleSource).toContain('stations.some(station => sameStation(station, source)) && stations.some(station => sameStation(station, target))');
    expect(moduleSource).toContain('are already assigned to Common Bin');
  });

  test('Imported mappings support edit, selected delete, and rollback/delete actions', () => {
    for (const token of [
      'async function editMapping(id)',
      'async function deleteMapping(id)',
      'async function deleteSelectedMappings()',
      'async function deleteImport(importId, snapshotId)',
      'await dDel(STORES.mappings, id)',
      'COMPONENT_MAPPING_EDIT',
      'COMPONENT_MAPPING_DELETE',
      'ROLLED_BACK',
    ]) {
      expect(moduleSource).toContain(token);
    }
  });

  test('Gun Matrix preview displays and preserves adaptor and holder fields', () => {
    for (const token of [
      "['Fix Adaptor', 'fixAdaptor']",
      "['Moving Adaptor', 'movingAdaptor']",
      "['Fix Holder', 'fixHolder']",
      "['Moving Holder', 'movingHolder']",
      'row.fixAdaptor',
      'row.movingAdaptor',
      'row.fixHolder',
      'row.movingHolder',
      "['Fix Adaptor', 'fixAdaptor']",
      "['Moving Adaptor', 'movingAdaptor']",
      "['Fix Holder', 'fixHolder']",
      "['Moving Holder', 'movingHolder']",
    ]) {
      expect(moduleSource).toContain(token);
    }
  });

  test('dynamic workbook inspection, manual mapping, preview, summary, and rollback are implemented', () => {
    for (const token of [
      'wb.SheetNames',
      'selectedSheets',
      'columnMappings',
      'Build Import Preview',
      'Commit Permanent Import',
      'Rows Scanned',
      'newCount',
      'updatedCount',
      'duplicateCount',
      'skippedCount',
      'warningCount',
      'snapshotBeforeImport',
      'componentRollbackImport',
      'component_import_snapshots',
      'component_import_configs',
    ]) {
      expect(moduleSource).toContain(token);
    }
    expect(moduleSource).toContain('rawSheets');
    expect(moduleSource).toContain('sourceRow');
    expect(moduleSource).toContain('row.sourceOnly = !');
    expect(moduleSource).toContain("['Complete Source Data', 'sourceData']");
    expect(moduleSource).toContain('Existing mapping updates will require separate confirmation');
  });

  test('station and mapping integrity preserves repeated rows and protects station variations', () => {
    expect(moduleSource).toContain('normalStation');
    expect(moduleSource).toContain('may match existing Station');
    expect(moduleSource).toContain('const stationKey = baseStationKey(m.stationNo)');
    expect(moduleSource).toContain("const gunReferenceNo = String(m.gunReferenceNo ?? '')");
    expect(moduleSource).toContain('const stations = new Map()');
    expect(moduleSource).toContain('function stationMergePlan(source, target)');
    expect(moduleSource).toContain('component_station_merge_history');
    expect(moduleSource).toContain("dPut('component_gun_rows'");
    expect(moduleSource).toContain('sourceOnly: Boolean(row.sourceOnly)');
    expect(moduleSource).toContain('COMPONENT_STATION_MERGE_ROLLBACK');
    expect(moduleSource).toContain('previousPartNo');
    expect(moduleSource).toContain('COMPONENT_MAPPING_UPDATE');
    expect(moduleSource).toContain('Pencil Shank');
  });

  test('Required Qty is calculated from every Part Number occurrence across all Guns', () => {
    expect(moduleSource).not.toContain("quantity: ['requiredqty', 'requiredquantity', 'reqqty'");
    expect(moduleSource).toContain(
      'function derivedRequiredQuantity(values, headers, gunQuantity, sourceSheet)',
    );
    expect(moduleSource).toContain("['maxqty', 'maximumqty', 'maxquantity']");
    expect(moduleSource).toContain('const key = partNo.toLowerCase()');
    expect(moduleSource).toContain('minimumQty: r.sourceMappings');
    expect(moduleSource).toContain('maximumQty: r.sourceMappings * 2');
    expect(moduleSource).toContain('const MAPPED_PART_POSITIONS');
  });

  test('Electrode fields are excluded from Shank Mapping scope', () => {
    expect(moduleSource).toContain(
      "const POSITIONS = ['Fix Shank', 'Moving Shank', 'Fix Adaptor', 'Moving Adaptor', 'Fix Holder', 'Moving Holder', 'Pencil Shank']",
    );
    expect(moduleSource).not.toContain("['Fixed Electrode'");
    expect(moduleSource).not.toContain("['Mov. Electrode'");
  });

  test('source-row-safe label pairing and complete replacement component scope are implemented', () => {
    expect(moduleSource).toContain('Pair Fix and');
    expect(moduleSource).toContain('const sourceKey = Array.isArray(m.sourceRows)');
    expect(moduleSource).toContain('optionList(POSITIONS)');
    expect(moduleSource).toContain('Ignored unsupported component column');
    expect(moduleSource).toContain('repeated rows are aggregated separately');
  });

  test('final workbook quantity and Station identity rules are implemented', () => {
    expect(moduleSource).toContain('function rowEndingQuantity(values, headers)');
    expect(moduleSource).toContain("!lastHeader.includes('minqty')");
    expect(moduleSource).toContain('const trailing = rowEndingQuantity(values, headers)');
    expect(moduleSource).toMatch(/function sameStation\(a, b\)\s*\{[\s\S]*normalStation\(resolveStationAlias\(a\)\)/);
    expect(moduleSource).toContain(
      'mappingIdentity = (stationNo, gunReferenceNo, position) => `${normalStation(stationNo)}',
    );
    expect(moduleSource).toContain('sameIncoming = pendingImport.rows.find');
    expect(moduleSource).toContain('Max Qty is applied per imported source row');
  });

  test('selected report month filters replacement summaries and exports', () => {
    expect(moduleSource).toContain('const reportReplacements = state.replacements.filter');
    expect(moduleSource).toContain('component-replacement-${month}.csv');
    expect(moduleSource).toContain("['Report Month', month]");
  });

  test('exact label table, repeated mapping rows, sizing, selection, and real print workflow are implemented', () => {
    expect(moduleSource).toContain(
      "headers: ['FIX SHANK PART NO.', 'FIX ADAPTOR PART NO.', 'FIX HOLDER PART NO.', 'MOVING SHANK PART NO.', 'MOVING ADAPTOR PART NO.', 'MOVING HOLDER PART NO.']",
    );
    expect(moduleSource).toContain("headers: ['FIX PART NO.', 'MOVING PART NO.']");
    expect(moduleSource).toContain('@page{size:${dimensions.width}mm ${dimensions.height}mm');
    expect(moduleSource).toContain('width:${dimensions.width}mm;height:${dimensions.height}mm');
    expect(moduleSource).toContain('w.print()');
    expect(moduleSource).toContain("componentPrintLabels('selected')");
    expect(moduleSource).toContain("componentPrintLabels('all')");
    expect(moduleSource).not.toContain('<th>Gun</th>');
    expect(moduleSource).not.toContain('<th>Quantity</th>');
    expect(moduleSource).toContain('FIX HOLDER PART NO.');
    expect(moduleSource).toContain('MOVING HOLDER PART NO.');
    expect(moduleSource).toContain('FIX ADAPTOR PART NO.');
    expect(moduleSource).toContain('MOVING ADAPTOR PART NO.');
    expect(moduleSource).not.toContain('<th>Pencil Shank</th>');
  });

  test('physical printed label includes Station and Bin and excludes forbidden fields', () => {
    expect(moduleSource).toContain(
      '<div class="label-meta"><div class="title">${esc(r.stationNo)} <span>|</span> ${esc(r.binId)}</div></div>',
    );
    expect(moduleSource).toContain('<span>|</span> ${esc(r.binId)}</div></div>');
    expect(moduleSource).toContain(
      "headers: ['FIX SHANK PART NO.', 'FIX ADAPTOR PART NO.', 'FIX HOLDER PART NO.', 'MOVING SHANK PART NO.', 'MOVING ADAPTOR PART NO.', 'MOVING HOLDER PART NO.']",
    );
    expect(moduleSource).toContain("headers: ['FIX PART NO.', 'MOVING PART NO.']");
    expect(moduleSource).not.toContain('<th>Gun Number</th>');
    expect(moduleSource).not.toContain('<th>Actual Quantity</th>');
    expect(moduleSource).not.toContain('<th>Quantity</th>');
    expect(moduleSource).toContain('FIX HOLDER PART NO.');
    expect(moduleSource).toContain('MOVING HOLDER PART NO.');
    expect(moduleSource).toContain('FIX ADAPTOR PART NO.');
    expect(moduleSource).toContain('MOVING ADAPTOR PART NO.');
    expect(moduleSource).not.toContain('<th>Pencil Shank</th>');
  });

  test('Station-name variation requires an explicit decision before a new Station/Bin', () => {
    expect(moduleSource).toContain('stationVariationFor');
    expect(moduleSource).toContain('normalStation(existing) === normalStation(stationNo)');
    expect(moduleSource).toContain('explicit decision required before creating a new Station/Bin');
    expect(moduleSource).toContain('Click OK to create a NEW Station/Bin');
    expect(moduleSource).toContain('click Cancel to use existing Station');
    expect(moduleSource).toContain('pendingImport.stationDecisions');
    expect(moduleSource).toContain('row.stationNo = resolveImportStation(row.stationNo)');
  });

  test('stock, verification, replacement, lifecycle, and accounting formula are implemented', () => {
    for (const token of [
      'componentReceiveStock',
      'componentSaveVerification',
      'Reason required',
      'INSUFFICIENT STOCK',
      'Repair Return',
      'COMPONENT_REPAIR_COMPLETE',
      'COMPONENT_REPAIR_RETURN',
      'componentRepairReturn',
      'lifecycleQuantity',
      'COMPONENT_STOCK_TRANSACTION',
      'COMPONENT_REPLACEMENT_CREATE',
    ]) {
      expect(moduleSource).toContain(token);
    }
    expect(moduleSource).toContain('const snapshot = state.monthCloses.find');
    expect(moduleSource).toContain('before.reduce');
    expect(moduleSource).toContain(
      'const closing = opening + receive + repairReturn - replacement - scrap + adjustment',
    );
    expect(moduleSource).toContain('Zero Stock Report');
    expect(moduleSource).toContain('Month-end Accounting');
    expect(moduleSource).toContain('componentSelectReportMonth');
  });

  test('Section 35 accountability and complete audit history are implemented', () => {
    for (const field of [
      'maintenancePerson',
      'maintenanceTeam',
      'replacementDate',
      'replacementTime',
      'shift',
      'stationNo',
      'gunReferenceNo',
      'componentType',
      'partNo',
      'quantity',
      'oldPartCondition',
      'action',
      'commonBin',
      'loggedInUser',
    ]) {
      expect(moduleSource).toContain(field);
    }
    expect(moduleSource).toContain('maintenance_people');
    expect(moduleSource).toContain('COMPONENT_MATRIX_IMPORT');
    expect(moduleSource).toContain('COMPONENT_LABEL_PRINT');
    expect(moduleSource).toContain('COMPONENT_IMPORT_ROLLBACK');
  });

  test('feature-specific permissions use existing role authorization and explicit capability overrides', () => {
    expect(moduleSource).toContain('COMPONENT_CAPABILITIES');
    expect(moduleSource).toContain('shankMapping.view');
    expect(moduleSource).toContain('shankMapping.import');
    expect(moduleSource).toContain('current.permissions?.[key]');
    expect(moduleSource).toContain('window.canAdmin');
    expect(moduleSource).toContain('window.canMutate');
  });

  test('Guide Line contains every A-AF section and is integrated into the Dashboard', () => {
    for (const section of [
      'A. SYSTEM PURPOSE',
      'B. FIRST-TIME SETUP',
      'C. GUN MATRIX IMPORT',
      'D. STATION NOT ASSIGNED',
      'E. HOW SHANK MAPPING IS CREATED',
      'F. AUTOMATIC BIN CREATION',
      'G. PART MASTER',
      'H. STOCK RECEIVING',
      'I. STOCK AVAILABILITY',
      'J. REPLACEMENT PROCESS',
      'K. REPLACEMENT ENTRY',
      'L. INSUFFICIENT STOCK',
      'M. REPAIR / SCRAP',
      'N. REPAIR RETURN',
      'O. SCRAP',
      'P. LABEL PRINTING',
      'Q. LABEL PRINTING OPTIONS',
      'R. SEARCH STATION',
      'S. SEARCH PART NUMBER',
      'T. PHYSICAL STOCK VERIFICATION',
      'U. IMPORT HISTORY',
      'V. MAPPING CHANGE HISTORY',
      'W. AUDIT',
      'X. MONTH-END PROCESS',
      'Y. HOW TO FIND ZERO STOCK AT MONTH-END',
      'Z. HOW TO FIND WHY A SHANK BECAME ZERO',
      'AA. DAILY STORE WORKFLOW',
      'AB. MAINTENANCE DAILY WORKFLOW',
      'AC. MONTH-END DAILY MANUAL WORK SHOULD BE ELIMINATED',
      'AD. TROUBLESHOOTING',
      'AE. ROLE-BASED GUIDE',
      'AF. GUIDE DESIGN',
    ]) {
      expect(moduleSource).toContain(section);
    }
    expect(moduleSource).toContain('Start Here');
    expect(moduleSource).toContain('cm-guide-filter');
    expect(moduleSource).toContain('cm-guide-section');
    expect(moduleSource).toContain('componentGuidePrint');
    expect(moduleSource).toContain('componentGuideExport');
    expect(moduleSource).toContain("componentOpen('guide')");
    expect(moduleSource).toContain('Import Gun Matrix');
    expect(moduleSource).toContain('Month-End Report');
    expect(moduleSource).toContain('Find Low/Zero Stock');
  });

  test('pasted_content_5 template, QR, analytics, mobile, and low-stock features are wired', () => {
    expect(moduleSource).toContain('Shank-Mapping-Import-Template.xlsx');
    expect(moduleSource).toContain('Station No.');
    expect(moduleSource).toContain('Gun Reference No.');
    expect(moduleSource).toContain('Pencil Shank');
    expect(moduleSource).toContain('qrBridge?.toDataURL');
    expect(moduleSource).toContain('storetrack://station?stationNo=');
    expect(moduleSource).toContain('Top Consumed Shanks');
    expect(moduleSource).toContain('Most Replaced Stations');
    expect(moduleSource).toContain('componentAnalyticsBreakdown');
    expect(moduleSource).toContain('cm-mobile-stack');
    expect(moduleSource).not.toContain('componentFilterLowStock');
    expect(moduleSource).toContain('componentExportLowStock');
    expect(moduleSource).toContain('componentEmailLowStock');
    expect(moduleSource).toContain('minimumStock');
  });

  test('pasted_content_5 UI controls and QR scan helper are present', () => {
    expect(moduleSource).toContain('Download Import Template');
    expect(moduleSource).toContain('Refresh Analytics');
    expect(moduleSource).toContain('Export Analytics');
    expect(moduleSource).not.toContain('Filter low stock report');
    expect(moduleSource).toContain('componentOpenStationFromQr');
  });

  test('Shank Mapping preserves vendor Part Numbers and never invokes auto-generation', () => {
    expect(moduleSource).toContain('PRESERVE_VENDOR_PART_NUMBER_EXACTLY');
    expect(moduleSource).toContain('function vendorPartNo(value)');
    expect(moduleSource).toContain(
      'const partByNo = partNo => state.parts.find(p => vendorPartNo(p.partNo) === vendorPartNo(partNo));',
    );
    expect(moduleSource).toContain("document.getElementById('cp-no')?.value ?? ''");
    expect(moduleSource).toContain('const newPartNo = vendorPartNo(enteredNo).trim()');
    expect(moduleSource).toContain('correctPartNumberEverywhere(part.partNo, newPartNo');
    expect(moduleSource).not.toContain('part.partNo = no.trim()');
    expect(moduleSource).toContain("fixShank: getPart('fixShank')");
    expect(moduleSource).toContain("movingShank: getPart('movingShank')");
    expect(moduleSource).toContain("fixAdaptor: getPart('fixAdaptor')");
    expect(moduleSource).toContain("movingAdaptor: getPart('movingAdaptor')");
    expect(moduleSource).toContain("fixHolder: getPart('fixHolder')");
    expect(moduleSource).toContain("movingHolder: getPart('movingHolder')");
    expect(moduleSource).toContain("pencilShank: getPart('pencilShank')");
    expect(moduleSource).not.toContain('generatePartNumber(');
    expect(moduleSource).not.toContain('generatePartNo(');
    expect(moduleSource).not.toContain('nextPartNumber(');
    expect(moduleSource).not.toContain('renumberPart');
  });

  test('unrelated StoreTrack auto-numbering source remains present and outside Shank Mapping', () => {
    const unrelated = fs.readFileSync(
      path.join(root, 'modules/purchaseOrderManagement.js'),
      'utf8',
    );
    expect(unrelated).toContain('generateOrderNumber');
    expect(moduleSource).not.toContain('generateOrderNumber');
  });

  test('historical month-end selector and closing calculation are implemented', () => {
    expect(moduleSource).toContain('type="month"');
    expect(moduleSource).toContain('state.reportMonth');
    expect(moduleSource).toContain('monthStart');
    expect(moduleSource).toContain('monthEnd');
    expect(moduleSource).toContain(
      'opening + receive + repairReturn - replacement - scrap + adjustment',
    );
    expect(moduleSource).toContain('componentGetMonthEndRows');
  });

  test('zero stock opens an actual transaction drill-down', () => {
    expect(moduleSource).toContain('function zeroDrillDown(partNo, binId)');
    expect(moduleSource).toContain('Running Balance');
    expect(moduleSource).toContain('componentZeroDrillDown');
    expect(moduleSource).toContain('No stored transactions found.');
  });

  test('dedicated Station and Part Number searches are implemented', () => {
    expect(moduleSource).toContain('function searchStation(query)');
    expect(moduleSource).toContain('function searchPart(query)');
    expect(moduleSource).toContain('componentSearchStation');
    expect(moduleSource).toContain('componentSearchPart');
    expect(moduleSource).toContain('Station Search');
    expect(moduleSource).toContain('Part Number Search');
  });

  test('Historical imports expose mapping review status without stock mutation', () => {
    expect(moduleSource).toContain('function replacementMappingStatus');
    expect(moduleSource).toContain("row._status === 'MAPPING REVIEW'");
    expect(moduleSource).toContain('mappingReviewCount');
    expect(moduleSource).toContain('stockChanged: false');
  });

  test('History exports honor active filters and mapping edits require confirmation', () => {
    expect(moduleSource).toContain('function historyExportRows');
    expect(moduleSource).toContain('ch-from-date');
    expect(moduleSource).toContain('ch-to-date');
    expect(moduleSource).toContain('Confirm mapping change?');
  });

  test('Replacement Entry uses Part No. first and prevents invalid mapping combinations', () => {
    expect(moduleSource).toContain('Type or select Part No.');
    expect(moduleSource).toContain('populateStationsForPart');
    expect(moduleSource).toContain('populateGunsForPart');
    expect(moduleSource).toContain('populateComponentsForPart');
    expect(moduleSource).toContain('Invalid Part No. → Station → Gun → Component mapping');
    expect(moduleSource).toContain('m.position) === String(component)');
  });

  test('Replacement History provides Part No.-based Station and Gun filters', () => {
    expect(moduleSource).toContain('ch-part-filter');
    expect(moduleSource).toContain('ch-station-filter');
    expect(moduleSource).toContain('ch-gun-filter');
    expect(moduleSource).toContain('historyMappingsForPart');
    expect(moduleSource).toContain('componentHistoryPartChanged');
    expect(moduleSource).toContain('componentHistoryStationChanged');
    expect(moduleSource).toContain('data-history-part=');
  });

  test('Replacement Entry filters active mapped parts by selected component and shows mapped details', () => {
    expect(moduleSource).toContain('id="cr-mapped-component"');
    expect(moduleSource).toContain('id="cr-part" list="cr-part-options"');
    expect(moduleSource).toContain('id="cr-station" list="cr-station-options"');
    expect(moduleSource).toContain('id="cr-gun" list="cr-gun-options"');
    expect(moduleSource).toContain('id="cr-component" list="cr-component-options"');
    expect(moduleSource).toContain("for (const event of ['input', 'change'])");
    expect(moduleSource).toContain('String(m.position) === String(component)');
    expect(moduleSource).toContain('Old Part No. and New Part No. cannot be the same');
    expect(moduleSource).toContain('CRITICAL PART');
    expect(moduleSource).toContain('p.active !== false');
    expect(moduleSource).toContain('updateMappedComponent()');
  });

  test('replacement history preserves Old Part No. and New Part No.', () => {
    expect(moduleSource).toContain('id="cr-old-part"');
    expect(moduleSource).toContain('id="cr-part"');
    expect(moduleSource).toContain('oldPartNo');
    expect(moduleSource).toContain('newPartNo');
    expect(moduleSource).toContain('Old Part No.');
    expect(moduleSource).toContain('New Part No.');
    expect(moduleSource).toContain('entry.oldPartNo || entry.partNo');
  });

  test('Accountability Export uses the selected historical month, not the current month', () => {
    expect(moduleSource).toContain(
      "const month = /^\\d{4}-\\d{2}$/.test(String(state.reportMonth || '')) ? state.reportMonth : today().slice(0, 7);",
    );
    expect(moduleSource).toContain('monthEndRows(month)');
    expect(moduleSource).toContain('component-stock-accountability-${month}.csv');
    expect(moduleSource).toContain("['Report Month', month]");
    expect(moduleSource).not.toContain(
      'function exportAccountability() {\n    const month = today().slice(0, 7);',
    );
  });

  test('labelRows groups LH/RH under one base Station and resolves the Common Bin by baseStationKey', () => {
    expect(moduleSource).toContain('const key = baseStationKey(stationNo)');
    expect(moduleSource).toContain('baseStationKey(b.stationNo) === key');
    expect(moduleSource).toContain(
      'const rowForMapping = mapping => { let station = stations.get(baseStationKey(mapping.stationNo));',
    );
  });

  test('labels aggregate every Gun into one table per base Station including LH and RH variants', () => {
    expect(moduleSource).toContain('const baseStationName = value =>');
    expect(moduleSource).toContain(
      'const baseStationKey = value => normalStation(baseStationName(value))',
    );
    expect(moduleSource).toContain('const stationKey = baseStationKey(m.stationNo)');
    expect(moduleSource).toContain("replace(/(?:[\\s_-]+)(?:LH|RH)[/\\\\.,;:]*$/i, '')");
    expect(moduleSource).toContain(
      'state.bins.find(b => baseStationKey(b.stationNo) === stationKey)',
    );
  });

  test('labels aggregate every source Gun into one base-Station table without stale mapping inflation', () => {
    expect(moduleSource).toContain('const sourceGunRowsByBaseStation = new Map()');
    expect(moduleSource).toContain('const hasSourceGunRows = sourceGunRowsByBaseStation.size > 0');
    expect(moduleSource).toContain('const mappingBelongsToSource = m =>');
    expect(moduleSource).toContain('mappedSourceKeys: new Set()');
    expect(moduleSource).toContain('const gunCountService = window.GunCountService');
    expect(moduleSource).toContain('gunCountService.calculateGunCount');
    expect(moduleSource).not.toContain('allocations.match(/<div>/g)');
    expect(moduleSource).toContain('occurrenceCount: calculateGunCount(r.sourceMappings)');
    expect(moduleSource).toContain('const stationKey = baseStationKey(m.stationNo)');
    expect(moduleSource).toContain('function labelTable(r)');
    expect(moduleSource).toContain('r.rows.map((row, i)');
  });

  test('TG 30 and EV TG 30 remain separate source counts while LH/RH variants share a base Station', () => {
    expect(moduleSource).toContain('baseStationKey(sourceRow.stationNo)');
    expect(moduleSource).toContain(
      'const stationRows = sourceGunRowsByBaseStation.get(baseStationKey(m.stationNo))',
    );
    expect(moduleSource).toContain(
      'rows.push({ key: `station:${baseStationKey(station.stationNo)}`',
    );
    expect(moduleSource).toContain('sourceKeyOf = row => String(row?.sourceKey');
  });

  test('bin sticker tables auto-fit their content and pack complete labels on A4 portrait pages', () => {
    expect(moduleSource).toContain('function labelFitHeight(r, cardW, cardH, rowQrSize, rowCellFont)');
    expect(moduleSource).toContain('labelHeight: labelFitHeight(r, cardW, cardH, rowQrSize, rowCellFont)');
    expect(moduleSource).toContain('height:${labelHeight}mm;min-height:${labelHeight}mm;max-height:${labelHeight}mm;');
    expect(moduleSource).toContain('<div class="label-table-wrap">${labelTable(r)}</div>');
    expect(moduleSource).toContain('@page{size:A4 portrait');
    expect(moduleSource).toContain(
      'const rowsPerPage = Math.max(1, Math.floor((297 - (pageMargin * 2) + gap) / (layoutCardH + gap)));',
    );
    expect(moduleSource).toContain('const labelsPerPage = cols * rowsPerPage;');
    expect(moduleSource).toContain('section class="label-page"');
    expect(moduleSource).toContain(
      'grid-template-columns:repeat(${cols},${dimensions.width}mm)',
    );
    expect(moduleSource).toContain('grid-template-rows:repeat(${rowsPerPage},${layoutCardH}mm)');
    expect(moduleSource).toContain('.label-table-2 th:not(:first-child),.label-table-2 td:not(:first-child){width:46%}');
    expect(moduleSource).toContain('.label-table-6 th:not(:first-child),.label-table-6 td:not(:first-child){width:15.333%}');
    expect(moduleSource).toContain('Dense Common Bin tables were given extra height');
    expect(moduleSource).not.toContain('(CONTINUED)');
  });

  test('labels use all six columns only when complete and otherwise apply side priorities', () => {
    expect(moduleSource).toContain('const full = Object.values(values).every(Boolean)');
    expect(moduleSource).toContain(
      "values.fixShank || values.fixAdaptor || values.fixHolder || ''",
    );
    expect(moduleSource).toContain(
      "values.movingShank || values.movingHolder || values.movingAdaptor || ''",
    );
    expect(moduleSource).toContain("headers: ['FIX PART NO.', 'MOVING PART NO.']");
    expect(moduleSource).toContain(
      "headers: ['FIX SHANK PART NO.', 'FIX ADAPTOR PART NO.', 'FIX HOLDER PART NO.', 'MOVING SHANK PART NO.', 'MOVING ADAPTOR PART NO.', 'MOVING HOLDER PART NO.']",
    );
  });

  test('BI Dashboard Part and Station filters accept typing and show datalist suggestions', () => {
    expect(moduleSource).toContain('function biPartOptions(selected = \'\')');
    expect(moduleSource).toContain('id="cm-bi-part" list="cm-bi-parts"');
    expect(moduleSource).toContain('id="cm-bi-station" list="cm-bi-stations"');
    expect(moduleSource).toContain('${biPartOptions(partQuery)}');
    expect(moduleSource).toContain('value="${esc(partQuery)}"');
    expect(moduleSource).toContain('value="${esc(stationQuery)}"');
  });
});

describe('Affected workbook-row import regression', () => {
  const fs = require('fs');
  const path = require('path');
  const root = path.join(__dirname, '..');
  const source = fs.readFileSync(path.join(root, 'modules/componentManagement.js'), 'utf8');

  test('component values are resolved per sheet when the selected global header is empty or unavailable', () => {
    expect(source).toContain('const fallbackColumns = headers.map((header, column)');
    expect(source).toContain('likelyField(candidate.header, field)');
    expect(source).toContain('const selectedValueFor = field =>');
  });

  test('holder/adaptor-only rows remain valid component rows instead of being dropped as source-only', () => {
    expect(source).toContain(
      "'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder', 'pencilShank'",
    );
    expect(source).toContain('row.sourceOnly = !');
    expect(source).toContain('sourceValues: values.slice()');
    expect(source).toContain("'Missing Component'");
  });
});

describe('Large-data performance safeguards', () => {
  const root = path.join(__dirname, '..');
  const source = fs.readFileSync(path.join(root, 'modules/componentManagement.js'), 'utf8');

  test('Import Preview uses bounded pages and preserves global row indexes for edits', () => {
    expect(source).toContain('const IMPORT_PREVIEW_PAGE_SIZE = 100');
    expect(source).toContain('matchingRows.slice(pageStart, pageStart + pageSize)');
    expect(source).toContain('index: rowIndex');
    expect(source).toContain('data-row="${rowIndex}"');
    expect(source).toContain('IMPORT_PREVIEW_SEARCH_FIELDS');
    expect(source).toContain('function filterImportPreview(root = document)');
    expect(source).toContain('componentPreviewPage');
    expect(source).toContain('rows retained');
  });
});

describe('Shank Mapping database migration regression', () => {
  const fs = require('fs');
  const path = require('path');
  const source = fs.readFileSync(path.join(__dirname, '..', 'modules/database.js'), 'utf8');
  test('migration is bumped so existing databases receive Shank Mapping stores', () => {
    expect(source).toContain('const VER = 23');
    expect(source).toContain("'component_mappings'");
    expect(source).toContain("'component_parts'");
    expect(source).toContain("'component_bins'");
    expect(source).toContain("'component_gun_rows'");
  });
});
describe('Import Commit persistence regression', () => {
  const fs = require('fs');
  const path = require('path');
  const source = fs.readFileSync(
    path.join(__dirname, '..', 'modules/componentManagement.js'),
    'utf8',
  );
  test('commit writes component mappings and reloads state from the same component_mappings store', () => {
    expect(source).toContain('dPut(STORES.mappings, map)');
    expect(source).toContain('await load()');
    expect(source).toContain(
      'const expectedMappings = state.gunRows.filter(r => r.sourceFile === record.sourceFile && !r.sourceOnly).length',
    );
    expect(source).toContain('Import saved source rows but mappings could not be reloaded');
  });
  test('commit-time reviewed component values are not lost through a stale sourceOnly flag', () => {
    expect(source).toContain('function componentPairsForRow(row)');
    expect(source).toContain('const pairs = componentPairsForRow(row)');
    expect(source).toContain(
      "const MAPPED_PART_FIELDS = ['fixShank', 'movingShank', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder']",
    );
    expect(source).toContain('function validMappedPartNo(value)');
    expect(source).toContain('.filter(validMappedPartNo)');
    expect(source).not.toContain("['Pencil Shank', vendorPartNo(row.pencilShank)]");
  });
  test('startup recovers mappings from retained imported Gun Rows', () => {
    expect(source).toContain('function recoveredPairsFromGunRow(gunRow)');
    expect(source).toContain('async function backfillMappingsFromGunRows()');
    expect(source).toContain('await dPut(STORES.mappings, map)');
    expect(source).toContain('const recovered = await backfillMappingsFromGunRows()');
  });
  test('Labels and Required Quantity remain downstream projections of reloaded mappings', () => {
    expect(source).toContain('function requiredQuantityRows()');
    expect(source).toContain('state.mappings');
    expect(source).toContain('function labelRows()');
    expect(source).toContain('state.mappings.filter');
  });
});

describe('Trial import purge and committed-data boundary', () => {
  const root = path.join(__dirname, '..');
  const component = fs.readFileSync(path.join(root, 'modules', 'componentManagement.js'), 'utf8');

  test('trial purge removes workbook lineage and preserves unrelated imports', () => {
    expect(component).toContain('async function purgeImportedWorkbook(snapshotId)');
    expect(component).toContain(
      "const legacyImportedGunRows = (await gAll('component_gun_rows')).filter(row => row.sourceFile === fileName)",
    );
    expect(component).toContain('await dDel(store, row.id)');
    expect(component).toContain("await dDel('component_import_snapshots', snapshotId)");
    expect(component).toContain("'component_label_versions'");
    expect(component).toContain('window.componentPurgeImportedWorkbook = purgeImportedWorkbook');
  });

  test('delete also uses the linked backup snapshot and removes import configuration', () => {
    expect(component).toContain('const linkedSnapshotId = snapshotId || row?.backupId');
    expect(component).toContain("for (const cfg of await gAll('component_import_configs'))");
    expect(component).toContain("await dDel('component_import_configs', cfg.id)");
  });

  test('Gun Mapping renders one row per Station and Gun with all component columns grouped', () => {
    expect(component).toContain('function gunMappingGroups()');
    expect(component).toContain('One row represents one imported Station + Gun source occurrence');
    for (const position of [
      'Fix Shank',
      'Moving Shank',
      'Fix Adaptor',
      'Moving Adaptor',
      'Fix Holder',
      'Moving Holder',
      'Pencil Shank',
    ]) {
      expect(component).toContain(`<strong>${position}:</strong>`);
    }
    expect(component).toContain('class="cm-map-select cm-map-group-select"');
    expect(component).toContain('componentDeleteGunGroup');
  });

  test('Bin Management allocates every Station Gun with all valid components to one common Bin', () => {
    expect(component).toContain('function binGunAllocations(bin)');
    expect(component).toContain('All Guns of that Station are allocated to the same Bin');
    expect(component).toContain('Gun-wise Component Allocation');
    expect(component).toContain('POSITIONS.includes(mapping.position)');
    expect(component).toContain('validMappedPartNo(mapping.partNo)');
    expect(component).toContain('sameStation(mapping.stationNo, bin.stationNo)');
  });

  test('Gun Mapping follows Excel source serial order', () => {
    expect(component).toContain('const sourceSerial = Number(mapping.sourceSrNo)');
    expect(component).toContain('const sourceRow = Number(mapping.sourceRow)');
    expect(component).toContain(
      'return [...grouped.values()].sort((a, b) => a.order - b.order || a.firstIndex - b.firstIndex)',
    );
    expect(component).toContain('sourceSrNo: row.srNo || null');
  });

  test('grouped Matrix keeps component-level mappings for downstream projections', () => {
    expect(component).toContain(
      'underlying component mappings remain separate for Stock, Required Quantity, Labels and replacement processing',
    );
    expect(component).toContain('group.mappings.map(mapping => btn(`Edit ${mapping.position}`');
    expect(component).toContain('group.ids');
  });

  test('preview remains separate from committed downstream data', () => {
    expect(component).toContain('state.importDraft = pendingImport');
    expect(component).toContain('pendingImport = null; state.importDraft = null; await load();');
    expect(component).toContain('function selectedLabelRows(mode)');
    expect(component).toContain('const rows = labelRows();');
    expect(component).toContain('state.mappings');
  });
});

module.exports = {};


describe('Stock Control Excel import', () => {
  const root = path.join(__dirname, '..');
  const moduleSource = fs.readFileSync(path.join(root, 'modules/componentManagement.js'), 'utf8');

  test('template and Stock Control expose the requested fields and preview-first import actions', () => {
    for (const header of ["'Sr No.'", "'Station No.'", "'Gun Reference No.'", "'Fix Qty'", "'Moving Qty'", "'Required Qty'", "'Bin Location'"]) {
      expect(moduleSource).toContain(header);
    }
    expect(moduleSource).toContain('New Stock Entry — Excel Import');
    expect(moduleSource).toContain('Download Excel Template');
    expect(moduleSource).toContain('Stock changes only after you choose Receive.');
    expect(moduleSource).toContain('componentCommitStockImport()');
    expect(moduleSource).toContain("type: 'Excel Stock Entry'");
    expect(moduleSource).toContain('COMPONENT_STOCK_EXCEL_RECEIVE');
  });

  test('stock import parser maps column headers and ignores empty rows', () => {
    const start = moduleSource.indexOf('const STOCK_IMPORT_HEADERS');
    const end = moduleSource.indexOf('function stockImportQuantity', start);
    const parserSource = moduleSource.slice(start, end);
    const result = JSON.parse(vm.runInNewContext(`${parserSource}; JSON.stringify(stockImportParseMatrix([
      ['Sr No.', 'Station No.', 'Gun Reference No.', 'Fix Qty', 'Moving Qty', 'Required Qty', 'Bin Location'],
      ['7', 'ST-01', 'Gun 2', '3', '4', '6', 'Rack A-1'],
      ['', '', '', '', '', '', '']
    ]))`));
    expect(result).toEqual([{
      sourceRow: 2,
      srNo: '7',
      stationNo: 'ST-01',
      gunReferenceNo: 'Gun 2',
      fixQty: '3',
      movingQty: '4',
      requiredQty: '6',
      binLocation: 'Rack A-1',
    }]);
  });

  test('preview resolves Fix/Moving parts from Station and Gun and rejects a mismatched bin location', () => {
    const start = moduleSource.indexOf('function stockImportQuantity(');
    const end = moduleSource.indexOf('function stockImportPreviewMarkup()', start);
    const validationSource = moduleSource.slice(start, end);
    const normalize = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const sandbox = {
      state: { mappings: [
        { stationNo: 'ST-01', gunReferenceNo: 'Gun 2', position: 'Fix Shank', partNo: 'FS-1' },
        { stationNo: 'ST-01', gunReferenceNo: 'Gun 2', position: 'Moving Shank', partNo: 'MS-1' },
      ] },
      canonicalStation: value => String(value || '').trim(),
      activeBinForStation: () => ({ binId: 'BIN-01', stationNo: 'ST-01', location: 'Rack A-1', active: true }),
      sameStation: (left, right) => normalize(left) === normalize(right),
      normalGunReference: normalize,
      pencilPositionKey: value => String(value || '').toLowerCase(),
      validMappedPartNo: Boolean,
      partKey: value => String(value || '').toLowerCase(),
      partByNo: partNo => ({ partNo, active: true }),
      stockImportHeaderKey: normalize,
    };
    const rows = JSON.parse(vm.runInNewContext(`${validationSource}; JSON.stringify(stockImportResolveRows([
      { srNo: '1', stationNo: 'ST-01', gunReferenceNo: 'Gun 2', fixQty: '3', movingQty: '4', requiredQty: '6', binLocation: 'Rack A-1', sourceRow: 2 },
      { srNo: '2', stationNo: 'ST-01', gunReferenceNo: 'Gun 2', fixQty: '1', movingQty: '0', requiredQty: '6', binLocation: 'Rack Wrong', sourceRow: 3 },
    ]))`, sandbox));
    expect(rows[0]).toMatchObject({ valid: true, fixPartNo: 'FS-1', movingPartNo: 'MS-1', binId: 'BIN-01' });
    expect(rows[1].valid).toBe(false);
    expect(rows[1].errors.join(' ')).toMatch(/Bin Location does not match/i);
  });

  test('invalid preview rows cannot write stock, and valid import writes stock, transactions, and audit atomically', async () => {
    const start = moduleSource.indexOf('async function commitStockImport()');
    const end = moduleSource.indexOf('function stock()', start);
    const commitSource = moduleSource.slice(start, end);
    const writes = [];
    const toasts = [];
    let nextId = 0;
    const sandbox = {
      pendingStockImport: { fileName: 'stock.xlsx', rows: [{ valid: false }] },
      state: { stock: [], tx: [] },
      STORES: { stock: 'stock', tx: 'tx', audit: 'audit' },
      canComponent: () => true,
      toastMsg: message => toasts.push(message),
      partKey: value => String(value || '').toLowerCase(),
      stockFor: () => null,
      nowIso: () => '2026-10-25T00:00:00.000Z',
      uid: prefix => `${prefix}-${++nextId}`,
      autoSafetyQuantity: () => 0,
      statusFor: (quantity, minimum) => quantity <= minimum ? 'LOW STOCK' : 'OK',
      user: () => ({ username: 'tester' }),
      addAudit: async () => {},
      stock: () => {},
      console,
      window: { dPutMany: async batch => { writes.push(...batch); } },
    };
    await vm.runInNewContext(`${commitSource}; commitStockImport()`, sandbox);
    expect(writes).toHaveLength(0);
    expect(toasts[0]).toMatch(/no stock was changed/i);

    sandbox.pendingStockImport = {
      fileName: 'stock.xlsx',
      rows: [{ valid: true, srNo: '1', sourceRow: 2, stationNo: 'ST-01', gunReferenceNo: 'Gun 2', fixQty: 3, movingQty: 4, requiredQty: 6, fixPartNo: 'FS-1', movingPartNo: 'MS-1', binId: 'BIN-01' }],
    };
    await vm.runInNewContext(`${commitSource}; commitStockImport()`, sandbox);
    expect(writes).toHaveLength(6);
    expect(writes.filter(write => write.store === 'stock').map(write => [write.obj.partNo, write.obj.quantity, write.obj.minimumStock])).toEqual([['FS-1', 3, 6], ['MS-1', 4, 6]]);
    expect(writes.filter(write => write.store === 'tx').map(write => write.obj.type)).toEqual(['Excel Stock Entry', 'Excel Stock Entry']);
    expect(writes.filter(write => write.store === 'audit').every(write => write.obj.action === 'COMPONENT_STOCK_EXCEL_RECEIVE')).toBe(true);
  });
});

describe('Canonical occurrence-based Gun Count contract', () => {
  const fs = require('fs');
  const path = require('path');
  const source = fs.readFileSync(
    path.join(__dirname, '..', 'modules', 'componentManagement.js'),
    'utf8',
  );

  test('counts unique Station + Gun occurrences and never uses quantity as Gun Count', () => {
    expect(source).toContain('const gunCountService = window.GunCountService');
    expect(source).toContain('every unique Station + Gun occurrence counts as one Gun');
    expect(source).toContain('calculateGunCount');
    expect(source).not.toContain('row.gunCount += quantity;');
  });

  test('keeps quantity and required quantity as separate measures', () => {
    expect(source).toContain('Quantity and Required Qty are separate measures');
    expect(source).toContain('minimumQty: r.sourceMappings');
    expect(source).toContain('maximumQty: r.sourceMappings * 2');
  });
});

module.exports = {};
