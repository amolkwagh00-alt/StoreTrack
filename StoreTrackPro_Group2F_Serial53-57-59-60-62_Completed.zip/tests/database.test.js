// Unit tests for database module

const {
  initDB,
  gAll,
  dPut,
  batchPut,
  dPutMany,
  dDel,
  dClr,
  gOne,
  getDB,
  getStoreNames,
  STORES,
} = require('../modules/database.js');

describe('Database Module', () => {
  beforeAll(async () => {
    // Ensure the database module is initialized before assertions.
    getDB();
  });

  afterAll(() => {
    // Cleanup test database if needed
  });

  describe('getStoreNames', () => {
    test('should return array of store names', () => {
      const stores = getStoreNames();
      expect(Array.isArray(stores)).toBe(true);
      expect(stores).toContain('materials');
      expect(stores).toContain('users');
      expect(stores).toContain('transactions');
    });
  });

  describe('initDB', () => {
    test('should initialize database', async () => {
      await initDB();
      const db = getDB();
      expect(db).toBeDefined();
      expect(db.name).toBe('StoreTrackDB_ShankMapping_Clean_20260825');
    });

    test('should create object stores', async () => {
      await initDB();
      const db = getDB();
      STORES.forEach((store) => {
        expect(db.objectStoreNames.contains(store)).toBe(true);
      });
    });
  });

  describe('dPut', () => {
    test('should put a record into a store', async () => {
      await initDB();
      const testRecord = { name: 'Test Item', value: 42 };
      const key = await dPut('materials', testRecord);

      expect(key).toBeDefined();
      expect(typeof key).toBe('number');
    });

    test('should update an existing record', async () => {
      await initDB();
      const testRecord = { id: 1, name: 'Original' };
      const key = await dPut('materials', testRecord);

      const updatedRecord = { id: key, name: 'Updated' };
      await dPut('materials', updatedRecord);

      const retrieved = await gOne('materials', key);
      expect(retrieved.name).toBe('Updated');
    });
  });

  describe('gOne', () => {
    test('should retrieve a record by key', async () => {
      await initDB();
      const testRecord = { name: 'Test Item', value: 42 };
      const key = await dPut('materials', testRecord);

      const retrieved = await gOne('materials', key);
      expect(retrieved).toBeDefined();
      expect(retrieved.name).toBe('Test Item');
      expect(retrieved.value).toBe(42);
    });

    test('should return null for non-existent record', async () => {
      await initDB();
      const retrieved = await gOne('materials', 999999);
      expect(retrieved).toBeNull();
    });
  });

  describe('gAll', () => {
    test('should retrieve all records from a store', async () => {
      await initDB();
      await dClr('materials');

      const records = [{ name: 'Item 1' }, { name: 'Item 2' }, { name: 'Item 3' }];

      for (const record of records) {
        await dPut('materials', record);
      }

      const allRecords = await gAll('materials');
      expect(allRecords.length).toBeGreaterThanOrEqual(3);
    });

    test('should return empty array for empty store', async () => {
      await initDB();
      await dClr('materials');

      const allRecords = await gAll('materials');
      expect(Array.isArray(allRecords)).toBe(true);
      expect(allRecords.length).toBe(0);
    });
  });

  describe('dDel', () => {
    test('should delete a record', async () => {
      await initDB();
      const testRecord = { name: 'To Delete' };
      const key = await dPut('materials', testRecord);

      await dDel('materials', key);

      const retrieved = await gOne('materials', key);
      expect(retrieved).toBeNull();
    });

    test('should handle deleting non-existent record', async () => {
      await initDB();
      // Should not throw error
      await expect(dDel('materials', 999999)).resolves.not.toThrow();
    });
  });

  describe('dClr', () => {
    test('should clear all records from a store', async () => {
      await initDB();

      // Add some records
      await dPut('materials', { name: 'Item 1' });
      await dPut('materials', { name: 'Item 2' });

      await dClr('materials');

      const allRecords = await gAll('materials');
      expect(allRecords.length).toBe(0);
    });
  });

  describe('getDB', () => {
    test('should return database instance', async () => {
      await initDB();
      const db = getDB();
      expect(db).toBeDefined();
      expect(typeof db).toBe('object');
    });
  });

  describe('validation and batch operations', () => {
    test('rejects unknown stores consistently', async () => {
      await expect(gAll('does-not-exist')).rejects.toThrow('Unknown database store');
      await expect(dPut('does-not-exist', {})).rejects.toThrow('Unknown database store');
      await expect(dPutMany([{ store: 'does-not-exist', obj: {} }])).rejects.toThrow(
        'Unknown database store',
      );
    });

    test('supports batchPut and dPutMany, including empty input', async () => {
      await initDB();
      await dClr('materials');
      await expect(batchPut('materials', [{ name: 'Batch A' }, { name: 'Batch B' }])).resolves.toBeUndefined();
      const keys = await dPutMany([
        { store: 'materials', obj: { name: 'Many A' } },
        { store: 'transactions', obj: { type: 'IN', quantity: 2 } },
      ]);
      expect(keys).toHaveLength(2);
      expect(await dPutMany([])).toEqual([]);
      expect(await dPutMany(null)).toEqual([]);
    });

    test('dPutMany rolls back writes across stores when a batch operation fails', async () => {
      await initDB();
      await dClr('materials');
      await dClr('transactions');
      await expect(dPutMany([
        { store: 'materials', obj: { name: 'Must Roll Back' } },
        { store: 'transactions', obj: { id: { invalid: true }, type: 'IN', quantity: 1 } },
      ])).rejects.toThrow();
      expect(await gAll('materials')).toHaveLength(0);
      expect(await gAll('transactions')).toHaveLength(0);
    });

    test('dPutMany atomically rolls back deletes when a later put aborts the transaction', async () => {
      await initDB();
      await dClr('materials');
      await dClr('transactions');
      const retainedId = await dPut('materials', { name: 'Must Survive Abort' });

      await expect(dPutMany([
        { store: 'materials', operation: 'delete', key: retainedId },
        { store: 'transactions', obj: { id: { invalid: true }, type: 'IN', quantity: 1 } },
      ])).rejects.toThrow();

      expect(await gOne('materials', retainedId)).toEqual(expect.objectContaining({ name: 'Must Survive Abort' }));
      expect(await gAll('transactions')).toHaveLength(0);
    });

    test('uses encryption hooks for writes and reads when configured', async () => {
      await initDB();
      const original = window.DataEncryption;
      window.DataEncryption = {
        manager: {
          prepareForStorage: jest.fn(async (store, value) => ({ ...value, encryptedStore: store })),
          restoreFromStorage: jest.fn(async (store, value) =>
            value ? { ...value, restoredStore: store } : value,
          ),
        },
      };
      try {
        await dClr('materials');
        const key = await dPut('materials', { name: 'Encrypted' });
        const one = await gOne('materials', key);
        const all = await gAll('materials');
        expect(one.restoredStore).toBe('materials');
        expect(all[0].encryptedStore).toBe('materials');
        await batchPut('materials', [{ name: 'Batch encrypted' }]);
        await dPutMany([{ store: 'materials', obj: { name: 'Many encrypted' } }]);
        expect(window.DataEncryption.manager.prepareForStorage).toHaveBeenCalled();
      } finally {
        window.DataEncryption = original;
      }
    });

    test('rejects unknown stores in clear and single-read operations', async () => {
      await expect(dClr('does-not-exist')).rejects.toThrow();
      await expect(gOne('does-not-exist', 1)).rejects.toThrow();
    });
  });
});
