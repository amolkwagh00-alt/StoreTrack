const fs = require('fs');
const path = require('path');
const vm = require('vm');

const projectRoot = path.join(__dirname, '..');

function extractFunction(source, name) {
  const match = source.match(new RegExp(`(?:async\\s+)?function ${name}\\s*\\(`));
  if (!match) throw new Error(`Missing function ${name}`);
  const start = match.index;
  const open = source.indexOf('{', start);
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let index = open; index < source.length; index += 1) {
    const character = source[index];
    if (quote) {
      if (escaped) escaped = false;
      else if (character === '\\') escaped = true;
      else if (character === quote) quote = null;
      continue;
    }
    if (character === '"' || character === "'" || character === '`') {
      quote = character;
      continue;
    }
    if (character === '{') depth += 1;
    if (character === '}' && --depth === 0) return source.slice(start, index + 1);
  }
  throw new Error(`Unterminated function ${name}`);
}

describe('persistence audit regressions', () => {
  test('an archive write failure keeps the source record and does not cache an undurable archive', async () => {
    const source = fs.readFileSync(path.join(projectRoot, 'modules', 'dataArchiving.js'), 'utf8');
    const deleted = [];
    const context = {
      console: { error: jest.fn() },
      setInterval: () => 0,
      gAll: async store => store === 'materials' ? [{ id: 'material-1', status: 'old' }] : [],
      dPut: async store => {
        if (store === 'archive_records') throw new Error('disk write failed');
      },
      dDel: async (store, id) => deleted.push({ store, id }),
      window: {},
    };
    vm.runInNewContext(`${source}\nthis.archiveManagerUnderTest = dataArchivingManager;`, context);

    const policy = {
      id: 'policy-1', name: 'Old materials', entityType: 'materials',
      archiveStore: 'archive_records', criteria: { custom: { status: 'old' } },
      archivedCount: 0,
    };
    const result = await context.archiveManagerUnderTest.runArchive(policy);

    expect(result.archivedCount).toBe(0);
    expect(result.errors).toEqual([{ itemId: 'material-1', error: 'disk write failed' }]);
    expect(deleted).toEqual([]);
    expect(context.archiveManagerUnderTest.records.size).toBe(0);
  });

  test('restore conflict comparison detects nested differences deterministically and ignores timestamps', async () => {
    const source = fs.readFileSync(path.join(projectRoot, 'modules', 'dataBackup.js'), 'utf8');
    const harness = `${extractFunction(source, 'stable')}\n${extractFunction(source, 'compare')}\nthis.compareUnderTest = compare;`;
    const stores = {
      component_parts: [{ id: 'part-1', settings: { left: { value: 1, createdAt: 'old' }, right: true }, updatedAt: 'old' }],
      component_stock: [],
      component_mappings: [],
    };
    const context = {
      getStoreNames: () => Object.keys(stores),
      gAll: async name => stores[name] || [],
    };
    vm.runInNewContext(harness, context);

    const payload = { stores: { component_parts: [
      { id: 'part-1', settings: { right: true, left: { createdAt: 'new', value: 2 } }, updatedAt: 'new' },
      { id: 'part-2', settings: { value: 'new' } },
    ] } };
    const comparison = await context.compareUnderTest(payload);
    expect(comparison.parts.changed).toBe(1);
    expect(comparison.parts.conflicts).toBe(1);
    expect(comparison.parts.added).toBe(1);
    expect(comparison.totalConflicts).toBe(1);
    expect(comparison.totalNew).toBe(1);

    stores.component_parts[0].settings.left.value = 1;
    stores.component_parts[0].settings.right = true;
    const timestampOnlyPayload = { stores: { component_parts: [
      { id: 'part-1', settings: { left: { value: 1, createdAt: 'later' }, right: true }, updatedAt: 'later' },
    ] } };
    const timestampOnly = await context.compareUnderTest(timestampOnlyPayload);
    expect(timestampOnly.parts.changed).toBe(0);
    expect(timestampOnly.totalConflicts).toBe(0);
  });

  test('a PostgreSQL import statement failure rolls back and never prints a success report', async () => {
    const source = fs.readFileSync(path.join(projectRoot, 'server', 'import-backup.js'), 'utf8');
    const statements = [];
    const output = [];
    const client = {
      async query(sql) {
        const normalized = String(sql).trim();
        statements.push(normalized);
        if (normalized.startsWith('INSERT INTO materials')) throw new Error('constraint violation');
        return { rowCount: 0, rows: [] };
      },
      release: jest.fn(),
    };
    const pool = { connect: async () => client, end: jest.fn(async () => {}) };
    const backup = JSON.stringify({ M: [{ id: 'm-1', barcode: 'b-1', name: 'Part' }], T: [] });
    const sandbox = {
      require(name) {
        if (name === 'dotenv') return { config: jest.fn() };
        if (name === 'fs') return { readFileSync: () => backup };
        if (name === 'path') return { join: (...parts) => parts.join('/'), resolve: value => value };
        if (name === './db') return { pool, migrate: async () => {}, toMaterial: value => value };
        if (name === 'crypto') return { randomUUID: () => 'event-1' };
        throw new Error(`Unexpected require: ${name}`);
      },
      __dirname: path.join(projectRoot, 'server'),
      process: { argv: ['node', 'server/import-backup.js', 'backup.json'], includes: () => false, exitCode: 0 },
      console: {
        log: value => output.push({ level: 'log', value }),
        error: (...values) => output.push({ level: 'error', values }),
      },
      JSON,
      Math,
      Date,
      Set,
      Number,
      String,
      Error,
      Promise,
    };
    vm.runInNewContext(source, sandbox);
    await new Promise(resolve => setTimeout(resolve, 0));

    expect(statements).toContain('BEGIN');
    expect(statements).toContain('ROLLBACK');
    expect(statements).not.toContain('COMMIT');
    expect(output.some(entry => entry.level === 'log')).toBe(false);
    expect(sandbox.process.exitCode).toBe(1);
    expect(client.release).toHaveBeenCalledTimes(1);
  });
});
