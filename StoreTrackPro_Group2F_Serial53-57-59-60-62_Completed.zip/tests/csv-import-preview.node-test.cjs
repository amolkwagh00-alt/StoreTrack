'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function functionSource(source, name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `Missing ${name}`);
  const open = source.indexOf('{', start); let depth = 0; let quote = null; let escaped = false;
  for (let i = open; i < source.length; i++) {
    const ch = source[i];
    if (quote) { if (escaped) escaped = false; else if (ch === '\\') escaped = true; else if (ch === quote) quote = null; continue; }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth++;
    else if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Unclosed ${name}`);
}
const app = fs.readFileSync(path.join(__dirname, '../app.js'), 'utf8');
const parseFn = functionSource(app, 'parseImportCSV');
const importFn = functionSource(app, 'importCSV');

test('CSV parser supports commas, escaped quotes, CRLF, and quoted newlines; rejects unclosed quotes', () => {
  const context = {};
  vm.runInNewContext(`${parseFn};`, context);
  const rows = context.parseImportCSV('barcode,name,category\r\nA1,"Bolt, large","line 1\nline 2"\r\nA2,"Quote ""x""",General');
  assert.deepEqual(JSON.parse(JSON.stringify(rows)), [['barcode', 'name', 'category'], ['A1', 'Bolt, large', 'line 1\nline 2'], ['A2', 'Quote "x"', 'General']]);
  assert.throws(() => context.parseImportCSV('barcode,name\nA1,"unfinished'), /unclosed quoted field/i);
});

test('CSV import shows preview categories and writes nothing when confirmation is declined', async () => {
  const writes = []; const status = { style: {} }; const label = { textContent: '' }; const bar = { value: 0, max: 1 };
  let confirmMessage = '';
  class FakeFileReader { readAsText() { queueMicrotask(() => this.onload({ target: { result: 'barcode,name,stock\nNEW-1,New Bolt,4\nOLD-1,Duplicate,3\n,Missing barcode,2\nNEW-2,"New, Cable",2' } })); } }
  const context = {
    M: [{ id: 'old', barcode: 'OLD-1', name: 'Old' }],
    FileReader: FakeFileReader, Date, Set, Number, String, Math,
    generateUUID: (() => { let id = 0; return () => `id-${++id}`; })(),
    confirm: message => { confirmMessage = message; return false; },
    toast() {},
    document: { getElementById: id => ({ 'csv-import-progress': status, 'csv-import-progress-text': label, 'csv-import-progress-bar': bar }[id] || null) },
    dPut: async (...args) => writes.push(args),
  };
  vm.runInNewContext(`${parseFn}; ${importFn};`, context);
  context.importCSV({ target: { files: [{ name: 'test.csv' }], value: 'test.csv' } });
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.equal(writes.length, 0);
  assert.match(confirmMessage, /Ready to add: 2/);
  assert.match(confirmMessage, /Invalid rows: 1/);
  assert.match(confirmMessage, /Duplicate rows: 1/);
  assert.match(label.textContent, /Preview canceled.*no writes/i);
});

test('CSV import UI provides an aria-live progress/status element', () => {
  const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
  assert.match(html, /id="csv-import-progress" role="status" aria-live="polite"/);
  assert.match(importFn, /Importing \$\{i\+1\} of \$\{validRows\.length\}/);
});
