// Unit tests for authentication module
//
// modules/auth.js is loaded as a plain global <script> in the real app, so it
// calls a few functions (addAudit, toast) and reads a few DOM elements that
// live in app.js / index.html rather than in auth.js itself. Those are stubbed
// here the same way the browser's shared global scope would provide them --
// this test suite is only responsible for auth.js's own logic, not for
// re-testing addAudit/toast/the DOM.
global.addAudit = jest.fn();
global.toast = jest.fn();
global._removeAllEventListeners = jest.fn();
global.nav = jest.fn();

const auth = require('../modules/auth.js');
const {
  doLogin,
  doLogout,
  isViewer,
  canMutate,
  canAdmin,
  markDefaultCredentialIfNeeded,
  applyRolePermissions,
} = auth;

describe('Authentication Module', () => {
  beforeEach(() => {
    // Reset global state before each test
    if (typeof cu !== 'undefined') {
      cu = null;
    }
    // auth.js's own `passwordChangeRequired` is a module-private `let`, only
    // reachable through the live getter/setter auth.js exports for tests --
    // a bare `passwordChangeRequired = false` here would just create an
    // unrelated global and never touch the real state auth.js reads.
    auth.passwordChangeRequired = false;
    global.addAudit.mockClear();
    global.toast.mockClear();
    global._removeAllEventListeners.mockClear();
    global.nav.mockClear();

    // Minimal DOM fixture for doLogout(), which reads/toggles a handful of
    // real index.html elements (#app, #login-wrap, #lp, #store-note,
    // #n-users/#n-audit/#n-diag).
    document.body.innerHTML = `
      <div id="app" class="visible"></div>
      <div id="login-wrap" style="display:none"></div>
      <input id="lp" value="" />
      <div id="store-note"></div>
      <div id="n-users"></div>
      <div id="n-audit"></div>
      <div id="n-diag"></div>
    `;
  });

  describe('isViewer', () => {
    test('should return true for viewer role', () => {
      cu = { role: 'viewer' };
      expect(isViewer()).toBe(true);
    });

    test('should return false for non-viewer roles', () => {
      cu = { role: 'admin' };
      expect(isViewer()).toBe(false);

      cu = { role: 'store' };
      expect(isViewer()).toBe(false);
    });

    test('should return false when no user logged in', () => {
      cu = null;
      expect(isViewer()).toBe(false);
    });
  });

  describe('canMutate', () => {
    test('should return false when no user logged in', () => {
      cu = null;
      expect(canMutate()).toBe(false);
    });

    test('should return false for viewer role', () => {
      cu = { role: 'viewer' };
      expect(canMutate()).toBe(false);
    });

    test('should return true for admin role', () => {
      cu = { role: 'admin' };
      auth.passwordChangeRequired = false;
      expect(canMutate()).toBe(true);
    });

    test('should return true for store role', () => {
      cu = { role: 'store' };
      auth.passwordChangeRequired = false;
      expect(canMutate()).toBe(true);
    });

    test('should return false when password change required', () => {
      cu = { role: 'admin' };
      auth.passwordChangeRequired = true;
      expect(canMutate()).toBe(false);
    });
  });

  describe('canAdmin', () => {
    test('should return false when no user logged in', () => {
      cu = null;
      expect(canAdmin()).toBe(false);
    });

    test('should return false for viewer role', () => {
      cu = { role: 'viewer' };
      expect(canAdmin()).toBe(false);
    });

    test('should return false for store role', () => {
      cu = { role: 'store' };
      auth.passwordChangeRequired = false;
      expect(canAdmin()).toBe(false);
    });

    test('should return true for admin role', () => {
      cu = { role: 'admin' };
      auth.passwordChangeRequired = false;
      expect(canAdmin()).toBe(true);
    });

    test('should return false when password change required', () => {
      cu = { role: 'admin' };
      auth.passwordChangeRequired = true;
      expect(canAdmin()).toBe(false);
    });
  });

  describe('markDefaultCredentialIfNeeded', () => {
    test('should mark default admin credential', () => {
      const user = { username: 'admin' };
      const result = markDefaultCredentialIfNeeded(user, 'admin123');
      expect(result).toBe(true);
      expect(auth.passwordChangeRequired).toBe(true);
      expect(user.mustChangePassword).toBe(true);
    });

    test('should mark default store credential', () => {
      const user = { username: 'store' };
      const result = markDefaultCredentialIfNeeded(user, 'store123');
      expect(result).toBe(true);
      expect(auth.passwordChangeRequired).toBe(true);
      expect(user.mustChangePassword).toBe(true);
    });

    test('should not mark non-default credential', () => {
      const user = { username: 'admin' };
      const result = markDefaultCredentialIfNeeded(user, 'SecurePassword123!');
      expect(result).toBe(false);
      expect(auth.passwordChangeRequired).toBe(false);
    });

    test('should respect existing mustChangePassword flag', () => {
      const user = { username: 'admin', mustChangePassword: true };
      const result = markDefaultCredentialIfNeeded(user, 'AnyPassword');
      expect(result).toBe(true);
      expect(auth.passwordChangeRequired).toBe(true);
    });
  });

  describe('doLogout', () => {
    test('should clear user session', () => {
      cu = { username: 'test', role: 'admin' };
      auth.passwordChangeRequired = true;

      doLogout();

      expect(cu).toBeNull();
      expect(auth.passwordChangeRequired).toBe(false);
    });
  });
});
