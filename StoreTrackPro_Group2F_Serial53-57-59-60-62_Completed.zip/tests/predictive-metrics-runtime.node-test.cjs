'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const test = require('node:test');

const root = path.resolve(__dirname, '..');

function extractFunction(source, signature) {
  const start = source.indexOf(signature);
  assert.notEqual(start, -1, `Function not found: ${signature}`);
  const open = source.indexOf('{', start);
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let i = open; i < source.length; i++) {
    const ch = source[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth++;
    if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Unclosed function: ${signature}`);
}

test('P48-F01 runtime: PerformanceMonitor metric reaches predictive health monitoring without opening its page', () => {
  const window = {};
  const context = vm.createContext({
    window,
    console: { log() {}, warn() {}, error() {} },
    setInterval: () => 1,
    clearInterval() {},
    setTimeout: () => 1,
    clearTimeout() {},
    performance: { now: () => 0 },
    requestAnimationFrame() { return 1; },
    Date,
    Math,
    Map,
    Set,
    Number,
    String,
    Object,
    Array,
    JSON
  });

  const loadModule = (relativePath) => {
    context.module = { exports: {} };
    vm.runInContext(fs.readFileSync(path.join(root, relativePath), 'utf8'), context, { filename: relativePath });
    return context.module.exports;
  };

  const { eventBus } = loadModule('core/eventBus.js');
  window.eventBus = eventBus;
  const { predictiveHealthMonitoring } = loadModule('modules/predictiveHealthMonitoring.js');
  context.predictiveHealthMonitoring = predictiveHealthMonitoring;
  const { performanceMonitor } = loadModule('modules/performanceMonitor.js');
  window.performanceMonitor = performanceMonitor;

  const appSource = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
  vm.runInContext(extractFunction(appSource, 'function initializeAdvancedModules()'), context, { filename: 'app.js:initializeAdvancedModules' });
  context.initializeAdvancedModules();

  const metric = performanceMonitor.recordMetric({
    name: 'runtime_bridge_probe',
    type: 'custom',
    value: 37,
    unit: 'ms',
    category: 'localSave'
  });

  const recorded = predictiveHealthMonitoring.healthMetrics.get('localSave');
  assert.ok(metric, 'PerformanceMonitor should return the recorded metric');
  assert.ok(recorded, 'predictive monitoring should receive the emitted metric');
  assert.equal(recorded.values.at(-1).value, 37);
  assert.equal(recorded.values.at(-1).source, 'performanceMonitor');
  assert.equal(recorded.values.at(-1).unit, 'ms');

  predictiveHealthMonitoring.stopMonitoring();
});
