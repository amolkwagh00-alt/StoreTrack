const { createMonitor, DEFAULT_THRESHOLDS } = require('../modules/performanceMonitor');

function makeHost(overrides = {}) {
  const host = {
    performance: { now: jest.fn(() => 10) },
    console: { warn: jest.fn(), info: jest.fn() },
    ...overrides
  };
  return host;
}

test('classifies menu, Stock Status, and filter targets without retaining target text', () => {
  const monitor = createMonitor(makeHost());
  const target = (id, ariaLabel, dataOnclick, className) => ({
    id,
    tagName: 'DIV',
    parentElement: null,
    classList: { contains: name => name === className },
    getAttribute: key => ({ 'aria-label': ariaLabel, 'data-onclick': dataOnclick }[key] || null)
  });
  expect(monitor.classifyTarget(target('n-stock-zero', 'Stock Status', "componentOpen('stock-zero')"))).toBe('stockStatus');
  expect(monitor.classifyTarget(target('n-dashboard', 'Dashboard', "nav('dash')", 'ni'))).toBe('screen');
  expect(monitor.classifyTarget({ tagName: 'INPUT', parentElement: null, getAttribute: () => null })).toBe('filter');
});

test('uses category thresholds, warns only on over-budget samples, and keeps a bounded sample window', () => {
  const host = makeHost();
  const monitor = createMonitor(host, { maxSamples: 2, thresholds: { filter: 50 } });
  expect(monitor.thresholds.filter).toBe(50);
  monitor.record('arbitrary caller label is not retained', 40, { category: 'filter' });
  monitor.record('another label', 51, { category: 'filter' });
  monitor.record('third label', 2, { category: 'localSave' });
  expect(monitor.getSamples()).toHaveLength(2);
  expect(monitor.getSamples().map(item => item.category)).toEqual(['filter', 'localSave']);
  expect(JSON.stringify(monitor.getSamples())).not.toContain('arbitrary caller label');
  expect(host.console.warn).toHaveBeenCalledTimes(1);
  expect(monitor.summary().filter.exceedances).toBe(1);
  expect(DEFAULT_THRESHOLDS.centralCommit).toBe(2000);
});

test('explicit mark/measure works using clock fallback when PerformanceObserver is unavailable', () => {
  const host = makeHost({ performance: { now: jest.fn().mockReturnValueOnce(100).mockReturnValueOnce(225) } });
  const monitor = createMonitor(host);
  const start = monitor.mark('save-start', { category: 'localSave' });
  expect(monitor.measure('save', start)).toBe(125);
  expect(monitor.getSamples()[0]).toMatchObject({ category: 'localSave', duration: 125 });
});

test('Event Timing observer uses Chromium’s valid minimum duration threshold', () => {
  let observed;
  class FakeObserver {
    constructor(callback) { this.callback = callback; }
    observe(options) { observed = options; }
    disconnect() {}
  }
  createMonitor(makeHost({ PerformanceObserver: FakeObserver }));
  expect(observed).toEqual({ type: 'event', buffered: true, durationThreshold: 16 });
});

test('disabled configuration and missing host APIs degrade to safe no-ops', () => {
  const disabled = createMonitor({}, { enabled: false });
  expect(disabled.mark('x')).toBeNull();
  expect(disabled.record('x', 5)).toBeNull();
  expect(disabled.getSamples()).toEqual([]);
  const fallback = createMonitor(null);
  expect(fallback.mark('start')).toBeTruthy();
  expect(fallback.measure('finish', 'missing-mark')).toBeNull();
  expect(fallback.record('bad', NaN)).toBeNull();
});
