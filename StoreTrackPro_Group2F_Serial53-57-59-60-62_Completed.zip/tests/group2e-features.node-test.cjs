'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..');
const widgetSource = fs.readFileSync(path.join(root, 'modules', 'dashboardWidgets.js'), 'utf8');
const accessibilitySource = fs.readFileSync(path.join(root, 'modules', 'accessibility.js'), 'utf8');
const authSource = fs.readFileSync(path.join(root, 'modules', 'auth.js'), 'utf8');
const htmlSource = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

function widgetHarness(records) {
  const context = {
    window: { currentUser: { id: 'user-1' } },
    document: {
      addEventListener() {},
      querySelector() { return null; },
      createElement() { return { className: '', dataset: {}, querySelector() { return null; } }; },
    },
    console,
    Date,
    setInterval,
    clearInterval,
    gAll: async () => records,
    batchPut: async next => { records.splice(0, records.length, ...next); },
    CustomEvent: function CustomEvent(type) { this.type = type; },
  };
  vm.createContext(context);
  vm.runInContext(`${widgetSource}\nglobalThis.WidgetManagerForTest = WidgetManager;`, context);
  return { context, manager: new context.WidgetManagerForTest() };
}

test('Serial 43 restores the signed-in user layout in saved position order and isolates users', async () => {
  const records = [
    { id: 'a', userId: 'user-1', title: 'A', position: 1, visible: true },
    { id: 'b', userId: 'user-1', title: 'B', position: 0, visible: true },
    { id: 'x', userId: 'user-2', title: 'X', position: 0, visible: true },
  ];
  const { manager } = widgetHarness(records);
  await manager._configReady;
  assert.deepEqual(Array.from(manager.widgetOrder), ['b', 'a']);
  await manager.switchUser('user-2');
  assert.deepEqual(Array.from(manager.widgetOrder), ['x']);
  assert.equal(manager.getWidgetConfig('a'), undefined);
  await manager.switchUser('user-1');
  assert.deepEqual(Array.from(manager.widgetOrder), ['b', 'a']);
});

test('Serial 43 exposes an authentication hook before the first dashboard render', () => {
  assert.match(widgetSource, /setUser: \(userId\) => widgetManager\.switchUser\(userId\)/);
  assert.match(authSource, /window\.DashboardWidgets\.setUser\(cu\.id\)/);
  assert.match(authSource, /window\.DashboardWidgets\.setUser\(null\)/);
});

test('Serial 46 provides keyboard activation and focusable semantics for custom controls', () => {
  assert.match(accessibilitySource, /setupInteractiveKeyboardSupport\(\)/);
  assert.match(accessibilitySource, /target\.closest\?\.\('\[data-onclick\]'\)/);
  assert.match(accessibilitySource, /control\.click\(\)/);
  assert.match(accessibilitySource, /setAttribute\('tabindex', '0'\)/);
  assert.match(accessibilitySource, /e\.key !== 'Enter' && e\.key !== ' '/);
  assert.match(htmlSource, /id="n-dash" role="button" tabindex="0"/);
});

test('Serial 47 provides dialog names, modal state, field labels and focus trapping', () => {
  assert.match(accessibilitySource, /setupDialogSemantics\(\)/);
  assert.match(accessibilitySource, /setAttribute\('aria-modal', 'true'\)/);
  assert.match(accessibilitySource, /setAttribute\('aria-labelledby', heading\.id\)/);
  assert.match(accessibilitySource, /setAttribute\('aria-hidden', dialog\.classList\.contains\('on'\) \? 'false' : 'true'\)/);
  assert.match(accessibilitySource, /element\.__a11yOpener/);
  assert.match(accessibilitySource, /input:not\(\[aria-label\]\).*select:not\(\[aria-label\]\).*textarea:not\(\[aria-label\]\)/);
  assert.match(widgetSource, /aria-describedby="widget-settings-help"/);
});

test('Group 2E changes do not add a database store or touch protected inventory domains', () => {
  const dbSource = fs.readFileSync(path.join(root, 'modules', 'database.js'), 'utf8');
  assert.doesNotMatch(dbSource, /widget_layout|dashboard_layout/);
  for (const file of ['modules/database.js', 'modules/binLocationManagement.js', 'modules/componentManagement.js']) {
    assert.ok(fs.existsSync(path.join(root, file)), `${file} remains present`);
  }
});
