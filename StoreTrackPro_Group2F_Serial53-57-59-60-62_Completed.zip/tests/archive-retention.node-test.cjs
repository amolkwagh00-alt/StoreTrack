'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

async function managerHarness({ failDelete = false } = {}) {
  const deleted = [];
  const context = {
    window: {},
    gAll: async () => [],
    dPut: async () => {},
    dDel: async (store, id) => { if (failDelete) throw new Error('disk write failed'); deleted.push([store, id]); },
    setInterval: () => 1,
    clearInterval() {},
    Date,
    Map,
    console,
  };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../modules/dataArchiving.js'), 'utf8'), context);
  await context.window.DataArchiving.manager.initPromise;
  return { manager: context.window.DataArchiving.manager, deleted };
}

test('archive cleanup validates retention and never deletes invalid or not-yet-expired records', async () => {
  const { manager, deleted } = await managerHarness();
  const today = new Date();
  const old = new Date(today.getTime() - 500 * 86400000).toISOString();
  manager.records.set('old', { id: 'old', archivedAt: old });
  manager.records.set('bad-date', { id: 'bad-date', archivedAt: 'not-a-date' });
  manager.records.set('new', { id: 'new', archivedAt: today.toISOString() });
  await assert.rejects(manager.cleanupOldArchiveRecords(0), /between 1 and 36500/);
  assert.equal(await manager.cleanupOldArchiveRecords(365), 1);
  assert.deepEqual(deleted, [['archive_records', 'old']]);
  assert.equal(manager.records.has('bad-date'), true);
  assert.equal(manager.records.has('new'), true);
});

test('archive cleanup leaves in-memory record intact when durable deletion fails', async () => {
  const { manager } = await managerHarness({ failDelete: true });
  manager.records.set('old', { id: 'old', archivedAt: new Date(Date.now() - 500 * 86400000).toISOString() });
  await assert.rejects(manager.cleanupOldArchiveRecords(365), /disk write failed/);
  assert.equal(manager.records.has('old'), true);
});
