'use strict';
// Focused StoreTrack Batch 6 regressions for original findings 121–140.
// Static-only checks are explicitly labeled; runtime-like tests execute production helpers with controlled mocks.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const pm = fs.readFileSync(path.join(root, 'modules/pm.js'), 'utf8');
const main = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
const auth = fs.readFileSync(path.join(root, 'modules/auth.js'), 'utf8');
function extract(source, name) {
  const start = source.indexOf(`function ${name}`); assert.ok(start >= 0, `${name} exists`);
  const open = source.indexOf('{', start); let depth = 0, quote = null, esc = false;
  for (let i = open; i < source.length; i++) { const c = source[i];
    if (quote) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === quote) quote = null; continue; }
    if (c === "'" || c === '"' || c === '`') { quote = c; continue; }
    if (c === '{') depth++; else if (c === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`unterminated ${name}`);
}
function staticCheck(id, fn) { test(`${id} — static source assertion`, fn); }

staticCheck('P37-F03', () => {
  const start = main.indexOf("secureHandle('pm:smartParseSchedule'");
  const end = main.indexOf('// Generate PM Excel template', start);
  const s = main.slice(start, end);
  assert.match(s, /const headers = allRows\[headerRowIndex\]\.map/);
  assert.match(s, /const value = row\[colIndex\]/);
  assert.doesNotMatch(s, /headers\.filter\(Boolean\)/);
});
staticCheck('P37-F04', () => assert.match(pm, /flatMap\(schedule => Array\.from\(\{length: Math\.min\(100, Math\.max\(1, Number\(schedule\.checksheetQty\)/));
staticCheck('P37-F05', () => { assert.match(pm, /emptyState\.style\.display = rows\.length \? 'none' : ''/); assert.match(pm, /pmSchedules\.length \? 'No PM schedules match/); });
staticCheck('P37-F06', () => { assert.match(pm, /sanitizeHTML\(String\(s\.equipment/); assert.match(pm, /sanitizeHTML\(String\(schedule\.equipment/); assert.match(pm, /sanitizeHTML\(String\(value\)\)/); });
staticCheck('P38-F01', () => { assert.match(app, /approveIndent\(\$\{JSON\.stringify\(String\(x\.id\)\)\}\)/); assert.match(app, /rejectIndent\(\$\{JSON\.stringify\(String\(x\.id\)\)\}\)/); assert.match(app, /issueIndent\(\$\{JSON\.stringify\(String\(x\.id\)\)\}\)/); });
staticCheck('P38-F02', () => { const start = app.indexOf('function renderIndents'); const end = app.indexOf('// ── Material Return', start); assert.match(app.slice(start, end), /sanitizeHTML\(String\(x\.materialName/); assert.match(app.slice(start, end), /sanitizeHTML\(String\(x\.deptName/); });
staticCheck('P38-F03', () => { assert.match(html, /<th>Purpose \/ Job No\.<\/th><th>Remarks<\/th>/); assert.match(app, /x\.job\|\|'',x\.remarks\|\|''/); });
staticCheck('P38-F04', () => { assert.match(app, /id === 'indent'.*canRoleAction\('indentRequest'\)/s); assert.match(auth, /indentAllowed/); assert.match(auth, /aria-hidden/); });
staticCheck('P38-F05', () => assert.match(app, /Number\.isInteger\(qty\)/));
staticCheck('P39-F01', () => { const start = app.indexOf('async function saveReturn'); const end = app.indexOf('function clrReturn', start); const s = app.slice(start, end); assert.match(s, /origin.*type==='OUT'/s); assert.match(s, /returnedAlready\+qty>Number\(origin\.qty\)/); assert.match(s, /originTxId:origin\.id/); });
staticCheck('P39-F02', () => { assert.match(app, /decimalUnits=new Set/); assert.match(app, /Number\.isInteger\(qty\)/); assert.match(html, /id="ret-qty"[^>]*step="any"/); });
staticCheck('P40-F01', () => { const start = app.indexOf('function startCycleCount'); assert.ok(app.indexOf("style.display=''", start) < app.indexOf('renderCCItems()', start)); });
staticCheck('P40-F02', () => assert.match(app, /data-oninput="updateCCItem\(\$\{JSON\.stringify\(String\(m\.id\)\)\}/));
staticCheck('P40-F03', () => assert.match(app, /popCCCat\(\).*sanitizeHTML\(String\(c\)\)/s));
staticCheck('P40-F04', () => { assert.match(app, /const stale=counted\.filter/); assert.match(app, /Stock changed while count was in progress/); });
staticCheck('P41-F01', () => { const start = app.indexOf('function renderClosingStock'); const end = app.indexOf('function exportClosingCSV', start); const s = app.slice(start, end); assert.match(s, /pending-central/); });
staticCheck('P41-F02', () => assert.match(app, /const candidates=M\.filter\(m=>m\.active!==false\|\|T\.some/));
staticCheck('P41-F03', () => { assert.match(app, /const monthKeys=new Set/); assert.match(app, /T\.concat\(ADJ\)\.forEach/); assert.doesNotMatch(app, /for\(let i=0;i<12;i\+\+\)/); });
staticCheck('P42-F01', () => assert.match(app, /type==='consume'[\s\S]{0,700}con-cat[\s\S]{0,450}category===cat/));
staticCheck('P42-F02', () => { const ctx = {}; vm.runInNewContext(extract(app, 'consumptionWindow'), ctx); const w = ctx.consumptionWindow(6, new Date('2026-10-09T12:00:00Z')); assert.deepEqual(Array.from(w.labels), ['2026-05','2026-06','2026-07','2026-08','2026-09','2026-10']); assert.equal(w.start.getDate(), 1); });

test('P41-F01/P41-F02 — closing report runtime-like calculation keeps pending-central and inactive history rows', () => {
  const start = app.indexOf('function renderClosingStock'); const end = app.indexOf('function exportClosingCSV', start);
  const elements = { 'cls-month': { value: '2026-01' }, 'cls-summary': { innerHTML: '' }, 'cls-body': { innerHTML: '' } };
  const ctx = { M: [{ id: 'inactive', active: false, stock: 3, lowAlert: 1, barcode: 'I', name: 'Old', category: 'C', unit: 'Pcs' }], T: [{ itemId: 'inactive', type: 'IN', status: 'pending-central', qty: 2, time: '2026-01-10T00:00:00Z' }], ADJ: [], document: { getElementById: id => elements[id] }, sanitizeHTML: x => String(x), window: {} };
  vm.runInNewContext(app.slice(start, end) + '\nthis.renderClosingStock=renderClosingStock;', ctx);
  ctx.renderClosingStock();
  assert.match(elements['cls-body'].innerHTML, /Old/);
  assert.match(elements['cls-body'].innerHTML, />2</);
});
