// Focused dependency-free regressions for audit findings 31–60.
// Run: node --test tests/storetrack-batch2-31-60.node-test.cjs
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

process.env.TZ = 'Asia/Kolkata';
const ROOT = process.env.STORETRACK_ROOT || path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(ROOT, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const printing = fs.readFileSync(path.join(ROOT, 'modules/printing.js'), 'utf8');
const auth = fs.readFileSync(path.join(ROOT, 'modules/auth.js'), 'utf8');
const recommendations = fs.readFileSync(path.join(ROOT, 'modules/smartRecommendations.js'), 'utf8');
const utilities = fs.readFileSync(path.join(ROOT, 'modules/utilities.js'), 'utf8');

function extractFunction(source, name) {
  const re = new RegExp(`(?:async\\s+)?function\\s+${name}\\s*\\(`);
  const match = re.exec(source);
  assert.ok(match, `function ${name} exists`);
  const openParen = source.indexOf('(', match.index);
  let parens = 0, mode = 'code', escaped = false, closeParen = -1;
  for (let i = openParen; i < source.length; i++) {
    const c = source[i], n = source[i + 1];
    if (mode === 'single' || mode === 'double' || mode === 'template') {
      if (escaped) { escaped = false; continue; }
      if (c === '\\') { escaped = true; continue; }
      if ((mode === 'single' && c === "'") || (mode === 'double' && c === '"') || (mode === 'template' && c === '`')) mode = 'code';
      continue;
    }
    if (c === "'") { mode = 'single'; continue; }
    if (c === '"') { mode = 'double'; continue; }
    if (c === '`') { mode = 'template'; continue; }
    if (c === '(') parens++;
    else if (c === ')' && --parens === 0) { closeParen = i; break; }
  }
  assert.ok(closeParen >= 0, `function ${name} signature closes`);
  const bodyOpen = source.indexOf('{', closeParen);
  assert.ok(bodyOpen >= 0, `function ${name} body exists`);
  let depth = 0, state = 'code', escape = false, lineComment = false, blockComment = false;
  const interpolationDepths = [];
  for (let i = bodyOpen; i < source.length; i++) {
    const c = source[i], n = source[i + 1];
    if (lineComment) { if (c === '\n') lineComment = false; continue; }
    if (blockComment) { if (c === '*' && n === '/') { blockComment = false; i++; } continue; }
    if (state === 'single' || state === 'double') {
      if (escape) { escape = false; continue; }
      if (c === '\\') { escape = true; continue; }
      if ((state === 'single' && c === "'") || (state === 'double' && c === '"')) state = 'code';
      continue;
    }
    if (state === 'template') {
      if (escape) { escape = false; continue; }
      if (c === '\\') { escape = true; continue; }
      if (c === '`') { state = 'code'; continue; }
      if (c === '$' && n === '{') { depth++; interpolationDepths.push(depth); state = 'code'; i++; }
      continue;
    }
    if (c === '/' && n === '/') { lineComment = true; i++; continue; }
    if (c === '/' && n === '*') { blockComment = true; i++; continue; }
    if (c === "'") { state = 'single'; continue; }
    if (c === '"') { state = 'double'; continue; }
    if (c === '`') { state = 'template'; continue; }
    if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (interpolationDepths.length && depth === interpolationDepths[interpolationDepths.length - 1] - 1) {
        interpolationDepths.pop(); state = 'template'; continue;
      }
      if (depth === 0) return source.slice(match.index, i + 1);
    }
  }
  throw new Error(`Could not find end of function ${name}`);
}
function appContext(names, extra = {}) {
  const ctx = vm.createContext({ console: { log() {}, warn() {}, error() {} }, ...extra });
  vm.runInContext(names.map(n => extractFunction(app, n)).join('\n'), ctx, { timeout: 1500 });
  return ctx;
}
function appContextWithSanitizer(names, extra = {}) {
  const ctx = vm.createContext({ console: { log() {}, warn() {}, error() {} }, ...extra });
  vm.runInContext([extractFunction(utilities, 'sanitizeHTML'), ...names.map(n => extractFunction(app, n))].join('\n'), ctx, { timeout: 1500 });
  return ctx;
}
function domEscape(value) {
  return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function fakeElement(initial = {}) {
  const el = { value: '', innerHTML: '', textContent: '', style: {}, checked: false, ...initial };
  return el;
}
function fakeDocument(elements = {}) {
  return {
    getElementById(id) { return elements[id] || null; },
    createElement() {
      let text = '';
      return { set textContent(v) { text = String(v); }, get innerHTML() { return domEscape(text); }, toDataURL() { return 'data:image/png;base64,AA=='; } };
    },
    querySelectorAll() { return []; },
    createDocumentFragment() { return { children: [], appendChild(node) { this.children.push(node); } }; }
  };
}
function loadPrinting(extra = {}) {
  const ctx = vm.createContext({
    console, document: fakeDocument(), window: {},
    qrToDataURL: async () => 'data:image/png;base64,AA==',
    safeJsBarcode() {}, applyCssText() {}, ...extra
  });
  vm.runInContext(printing + '\nglobalThis.__test = {normalizeLabelSettings, lblMmToPx, lblPreviewLayoutCss, buildLabelPrintHtml, buildLabelZpl, getLblSettings};', ctx, { timeout: 1500 });
  return ctx;
}

// 31 — exports must consume the currently filtered history, not raw transactions.
test('P08-F01 history CSV/XLS exports use the active history filter result', () => {
  const elements = { 'srch-h': fakeElement({ value: 'bolt' }), 'flt-h-tp': fakeElement({ value: 'OUT' }), 'flt-h-f': fakeElement({ value: '' }), 'flt-h-t': fakeElement({ value: '' }) };
  const ctx = appContext(['historyFilteredTransactions', 'sortTransactionsNewestFirst', 'localDateRangeBounds'], {
    document: fakeDocument(elements), T: [
      { itemName: 'Bolt M8', barcode: 'A', type: 'OUT', time: '2026-01-01T10:00:00Z' },
      { itemName: 'Nut M8', barcode: 'B', type: 'OUT', time: '2026-01-01T11:00:00Z' },
      { itemName: 'Bolt M8', barcode: 'A', type: 'IN', time: '2026-01-01T12:00:00Z' }
    ]
  });
  assert.equal(ctx.historyFilteredTransactions().length, 1);
  assert.match(app, /historyFilteredTransactions\(\)\.forEach\(t=>rows\.push/);
  assert.match(app, /historyFilteredTransactions\(\)\.map\(t=>\[/);
});

// 32 — sort by parsed transaction time, newest first.
test('P08-F02 history rows are sorted newest-first by transaction timestamp', () => {
  const ctx = appContext(['sortTransactionsNewestFirst']);
  const result = ctx.sortTransactionsNewestFirst([
    { id: 'old', time: '2026-01-01T00:00:00Z' },
    { id: 'new', time: '2026-01-03T00:00:00Z' },
    { id: 'mid', time: '2026-01-02T00:00:00Z' }
  ]);
  assert.deepEqual(Array.from(result, r => r.id), ['new', 'mid', 'old']);
  assert.match(app, /function historyFilteredTransactions\(\)[\s\S]*?sortTransactionsNewestFirst/);
});

// 33 — null and invalid-time rows are discarded before the renderer/export touches fields.
test('P08-F03 malformed history rows are excluded before rendering and export', () => {
  const ctx = appContext(['historyFilteredTransactions', 'sortTransactionsNewestFirst', 'localDateRangeBounds'], {
    document: fakeDocument({ 'srch-h': fakeElement(), 'flt-h-tp': fakeElement({ value: 'all' }), 'flt-h-f': fakeElement(), 'flt-h-t': fakeElement() }),
    T: [null, {}, { time: 'not a date' }, { time: '2026-03-01T12:00:00Z', itemName: 'valid', type: 'IN' }]
  });
  assert.equal(ctx.historyFilteredTransactions().length, 1);
});

// 34 — local date window is inclusive of the final local day through its last millisecond.
test('P09-F01 date report uses local-day bounds and includes the entire end date', () => {
  const ctx = appContext(['localDateRangeBounds', 'isWithinLocalDateRange']);
  assert.equal(ctx.isWithinLocalDateRange('2026-03-04T18:29:59.999Z', '2026-03-04', '2026-03-04'), true);
  assert.equal(ctx.isWithinLocalDateRange('2026-03-04T18:30:00.000Z', '2026-03-04', '2026-03-04'), false);
  assert.equal(ctx.isWithinLocalDateRange('bad', '2026-03-04', '2026-03-04'), false);
});

// 35 — defaults derive from the local calendar, not UTC ISO slicing.
test('P09-F02 report date defaults use the local current date', () => {
  const from = fakeElement(), to = fakeElement();
  const ctx = appContext(['initReportDates', 'localDateKey'], { document: fakeDocument({ 'rp-from': from, 'rp-to': to }) });
  ctx.initReportDates();
  assert.equal(from.value, ctx.localDateKey(new Date()));
  assert.equal(to.value, from.value);
  assert.match(app, /function initReportDates\(\)\{const t=localDateKey\(new Date\(\)\)/);
});

// 36 — CSV export mirrors the report-type selection.
test('P09-F03 CSV export rows follow the selected report type', () => {
  const ctx = appContext(['reportExportRows', 'localDateKey']);
  const rows = ctx.reportExportRows('out', [{ type: 'OUT', time: '2026-03-04T10:00:00Z', barcode: 'B1', itemName: 'Bolt', qty: 2, deptName: 'Maintenance' }, { type: 'IN', time: '2026-03-04T11:00:00Z', barcode: 'B2' }]);
  assert.equal(rows[0][0], 'DateTime');
  assert.equal(rows.length, 2);
  assert.equal(rows[1][4], 'Maintenance');
  assert.match(app, /reportExportRows\(document\.getElementById\('rp-type'\)\?\.value\|\|'summary',rpData\)/);
});

// 37 — Date Report HTML encodes user-controlled item/department values.
test('P09-F04 Date Report escapes transaction fields before inserting HTML', () => {
  const now = new Date(), day = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
  const fields = { 'rp-from': fakeElement({ value: day }), 'rp-to': fakeElement({ value: day }), 'rp-type': fakeElement({ value: 'out' }), 'rp-head': fakeElement(), 'rp-body': fakeElement(), 'rp-metrics': fakeElement() };
  const hostile = '<img src=x onerror=alert(1)>';
  const ctx = appContextWithSanitizer(['genReport','isWithinLocalDateRange','localDateRangeBounds','localDateKey'], {
    document: fakeDocument(fields), T: [{ status: 'confirmed', type: 'OUT', time: new Date().toISOString(), barcode: hostile, itemName: hostile, deptName: hostile, person: hostile, job: hostile, userName: hostile, qty: 1 }], rpData: [],
  });
  ctx.genReport();
  assert.equal(ctx.rpData.length, 1);
  assert.doesNotMatch(fields['rp-body'].innerHTML, /<img src=x/);
  assert.match(fields['rp-body'].innerHTML, /&lt;img/);
});

// 38 — numeric-string zero stock behaves as zero in the Low Stock report.
test('P10-F01 string zero is classified as OUT throughout Low Stock helpers', () => {
  const ctx = appContext(['numericStockValue','isZeroStockMaterial','isLowStockMaterial','lowStockForSupplier','materialSupplierId']);
  const item = { id: 1, stock: '0', lowAlert: '4', supplierId: 'S1', active: true };
  assert.equal(ctx.isZeroStockMaterial(item), true);
  assert.equal(ctx.isLowStockMaterial(item), true);
  assert.equal(ctx.lowStockForSupplier([item], 'S1').length, 1);
  assert.match(app, /low\.filter\(isZeroStockMaterial\)/);
  assert.match(app, /isZeroStockMaterial\(m\)\?'OUT':'LOW'/);
});

// 39 — exactly 90 and 180 days qualify.
test('P11-F01 exact 90/180-day inactivity boundaries are included', () => {
  const begin = recommendations.indexOf('const INVENTORY_INACTIVITY_DAY_MS');
  const end = recommendations.indexOf('/**\n * Recommendation class', begin);
  assert.ok(begin >= 0 && end > begin);
  const ctx = vm.createContext({});
  vm.runInContext(recommendations.slice(begin, end) + '\nglobalThis.c = classifyInventoryInactivity;', ctx);
  assert.equal(ctx.c(89.999), 'normal');
  assert.equal(ctx.c(90), 'slow');
  assert.equal(ctx.c(179.999), 'slow');
  assert.equal(ctx.c(180), 'dead');
});

// 40 — categories are exclusive, so dead stock cannot be shown twice.
test('P11-F02 dead-stock classification is exclusive from slow-moving', () => {
  assert.match(recommendations, /if\(classification==='normal'\)continue;[\s\S]*const isDead=classification==='dead'/);
  const start = recommendations.indexOf('async generateOptimizationRecommendations()');
  const end = recommendations.indexOf('\n  /**', start + 10);
  const body = recommendations.slice(start, end);
  assert.match(body, /isDead\?'Dead Stock':'Slow-Moving Item'/);
  assert.equal((body.match(/recommendations\.push\(/g) || []).length, 1);
});

// 41 — only completed, matching IN/OUT movements reset inactivity.
test('P11-F03 non-IN/OUT, pending, invalid, and unrelated transactions do not reset inactivity', () => {
  const begin = recommendations.indexOf('const INVENTORY_INACTIVITY_DAY_MS');
  const end = recommendations.indexOf('/**\n * Recommendation class', begin);
  const ctx = vm.createContext({});
  vm.runInContext(recommendations.slice(begin, end) + '\nglobalThis.x={isQualifyingInventoryMovement,lastInventoryActivityTime};', ctx);
  const material = { id: 'MAT-1', barcode: 'BC-1' };
  const txs = [
    { itemId: 'MAT-1', type: 'ADJUSTMENT', status: 'confirmed', time: '2026-01-01' },
    { itemId: 'MAT-1', type: 'IN', status: 'pending', time: '2026-01-02' },
    { itemId: 'OTHER', barcode: 'OTHER', type: 'OUT', status: 'confirmed', time: '2026-01-03' },
    { itemId: 'MAT-1', type: 'OUT', status: 'confirmed', time: '2026-01-04T00:00:00Z' }
  ];
  assert.equal(ctx.x.lastInventoryActivityTime(material, txs), Date.parse('2026-01-04T00:00:00Z'));
});

// 42 — keyboard route activation on Enter and Space.
test('P11-F04 Slow-Moving sidebar responds to Enter and Space', () => {
  const calls = [], ctx = appContext(['handleSlowMovingNavKey'], { nav: id => calls.push(id) });
  let prevented = 0;
  for (const key of ['Enter', ' ']) ctx.handleSlowMovingNavKey({ key, preventDefault() { prevented++; } });
  ctx.handleSlowMovingNavKey({ key: 'Escape', preventDefault() { prevented++; } });
  assert.deepEqual(calls, ['slowmoving', 'slowmoving']);
  assert.equal(prevented, 2);
  assert.match(html, /id="n-slowmoving"[^>]*role="button"[^>]*tabindex="0"[^>]*data-onkeydown="handleSlowMovingNavKey\(event\)">/);
});

// 43 — Select All acts on every matching material, beyond the 30-row display cap.
test('P12-F01 Select All selects all matching materials, not only the first 30', () => {
  const ctx = appContext(['matchingLabelMaterials','selectAllLabels','identifiersMatch'], {
    M: Array.from({ length: 47 }, (_, i) => ({ id: i + 1, name: `Item ${i + 1}`, barcode: `B${i + 1}`, active: true })),
    lblSel: [], document: fakeDocument({ 'lbl-srch': fakeElement({ value: '' }) }),
    renderLblSearch() {}, renderLblSel() {}, updateLabelCount() {}, renderLblLivePreview() {}
  });
  ctx.selectAllLabels();
  assert.equal(ctx.lblSel.length, 47);
  assert.match(app, /function renderLblSearch\(\)[\s\S]*?matchingLabelMaterials\(M,search\.value\)\.slice\(0,30\)/);
});

// 44 — mm inputs convert to actual CSS pixel dimensions, with correct per-row count.
test('P12-F02 preview gaps and margin convert millimetres to CSS pixels', () => {
  const ctx = loadPrinting();
  const css = ctx.__test.lblPreviewLayoutCss(4, 10, 5, 15);
  assert.match(css, /repeat\(4,auto\)/);
  assert.match(css, /column-gap:37\.795/);
  assert.match(css, /row-gap:18\.897/);
  assert.match(css, /padding:56\.692/);
});

// 45 — no unsupported, inert Custom paper choice is offered.
test('P12-F03 paper-size list only contains implemented options', () => {
  const match = html.match(/<select id="lbl-paper-size"[\s\S]*?<\/select>/);
  assert.ok(match);
  assert.deepEqual(Array.from(match[0].matchAll(/<option value="([^"]+)"/g), m => m[1]), ['a4','a3','letter']);
  assert.doesNotMatch(match[0], /custom/i);
});

// 46 — layout and templates tabs reveal and focus their actual targets.
test('P12-F04 label side tabs navigate to live panels', () => {
  const calls = [];
  const layout = fakeElement({ scrollIntoView() { calls.push('layout-scroll'); }, focus() { calls.push('layout-focus'); } });
  const templates = fakeElement({ style: { display: 'none' }, scrollIntoView() { calls.push('templates-scroll'); }, focus() { calls.push('templates-focus'); } });
  const arrow = fakeElement();
  const btn = fakeElement();
  const other = fakeElement();
  const ctx = appContext(['lblSideNav'], { document: { querySelectorAll: () => [btn, other], getElementById: id => ({ 'layout-sec': layout, 'lbl-label-sec': templates, 'lbl-label-arrow': arrow })[id] || null } });
  ctx.lblSideNav(btn, 'layout');
  ctx.lblSideNav(btn, 'templates');
  assert.ok(calls.includes('layout-scroll'));
  assert.ok(calls.includes('templates-scroll'));
  assert.equal(templates.style.display, 'flex');
  assert.equal(arrow.textContent, '▲');
});

// 47 — printer properties now clearly use the system dialog; no inert button remains.
test('P12-F05 printer properties are delegated to the real system print dialog', () => {
  assert.match(html, /Printer properties are available in the system print dialog/);
  assert.doesNotMatch(html, /<button[^>]*>[^<]*Printer Properties/i);
  assert.match(app, /async function lblDoPrint\(\)[\s\S]*?doPrintLabels\('browser'\)/);
});

// 48 — settings clamp invalid and out-of-range dimensions, font, rows, and copies.
test('P12-F06 label numeric settings are bounded before output generation', () => {
  const ctx = loadPrinting();
  const s = ctx.__test.normalizeLabelSettings({ w: -10, h: 999, fs: 'NaN', per: 0, copies: 500 });
  assert.deepEqual(JSON.parse(JSON.stringify(s)), { w: 20, h: 200, fs: 8, per: 1, copies: 100, showCat: false, showUnit: false });
  assert.match(app, /function _lblGetPvSettings\(\)[\s\S]*clampFiniteInt/);
});

// 49 — user-controlled material data is escaped in generated live/print label HTML.
test('P12-F07 label print HTML escapes material values', async () => {
  const ctx = loadPrinting();
  const attack = '<svg/onload=alert(1)>';
  const output = await ctx.__test.buildLabelPrintHtml({ name: attack, category: attack, barcode: attack, unit: attack }, { w: 50, h: 25, fs: 8, showCat: true, showUnit: true });
  assert.doesNotMatch(output, /<svg\/onload/);
  assert.match(output, /&lt;svg\/onload=alert\(1\)&gt;/);
});

// 50 — preview status uses generated total labels, not a hard-coded 1 / 1.
test('P12-F08 preview counter reflects the actual number of generated labels', async () => {
  const count = fakeElement();
  const grid = fakeElement({ style: {}, appendChild(node) { this.childCount = node.children.length; } });
  const ctx = appContext(['_lblRebuildGrid','clampFiniteInt'], {
    document: { getElementById: id => ({ 'lbl-preview-grid': grid, 'lbl-prev-count': count, 'lbl-per-range': fakeElement({ value: 3 }), 'lbl-hgap-range': fakeElement({ value: 10 }), 'lbl-vgap-range': fakeElement({ value: 5 }), 'lbl-margin-sel': fakeElement({ value: 5 }) })[id] || null,
      createDocumentFragment() { return { children: [], appendChild(node) { this.children.push(node); } }; } },
    lblSel: [{ id: 1 }, { id: 2 }], _lblColorMode: 'color', _lblCutLines: true,
    _lblGetPvSettings: () => ({ w: 50, h: 25, fs: 8, copies: 2 }),
    createLabelElement: async () => ({ style: {} }), applyCssText() {}, _lblApplyZoom() {},
    lblPreviewLayoutCss: () => ''
  });
  await ctx._lblRebuildGrid();
  assert.equal(count.textContent, '4 labels · 50×25 mm');
});

// 51 — successful supplier deletion records an audit event; failed delete has no false event.
test('P13-F01 supplier deletion writes a DELETE audit only after persistence succeeds', async () => {
  const events = [], ctx = appContext(['delSupp','identifiersMatch'], {
    canRoleAction: () => true, SP: [{ id: 'supplier-x', name: 'Supplier X' }], confirm: () => true,
    async dDel(store,id) { events.push(`delete:${store}:${id}`); },
    async addAudit(type,message) { events.push(`audit:${type}:${message}`); },
    renderSupp() {}, popSuppSel() {}, toast() {}
  });
  await ctx.delSupp('supplier-x');
  assert.equal(ctx.SP.length, 0);
  assert.equal(events[0], 'delete:suppliers:supplier-x');
  assert.match(events[1], /^audit:DELETE:Deleted supplier: Supplier X/);
});

// 52 — imported nonnumeric supplier IDs are preserved and passed safely through actions.
test('P13-F02 supplier actions retain string IDs without numeric parsing', () => {
  const ids = ['sup-uuid-α'];
  const fields = Object.fromEntries(['sp-eid','sp-nm','sp-cp','sp-ph','sp-em','sp-gst','sp-addr'].map(id => [id, fakeElement()]));
  const ctx = appContext(['editSupp','identifiersMatch','eventIdArg'], { SP: [{ id: ids[0], name: 'Supplier' }], document: fakeDocument(fields), toast() {} });
  ctx.editSupp(ids[0]);
  assert.equal(fields['sp-eid'].value, ids[0]);
  assert.equal(ctx.eventIdArg(ids[0]), JSON.stringify(ids[0]));
  assert.match(app, /obj\.id=existing\?existing\.id:generateUUID\(\)/);
});

// 53 — malformed supplier emails are rejected by the actual validation helper.
test('P13-F03 malformed supplier emails are rejected', () => {
  const ctx = appContext(['isValidOptionalEmail']);
  assert.equal(ctx.isValidOptionalEmail(''), true);
  assert.equal(ctx.isValidOptionalEmail('ops@example.com'), true);
  assert.equal(ctx.isValidOptionalEmail('wrong-address'), false);
  assert.equal(ctx.isValidOptionalEmail('bad@host'), false);
  assert.match(app, /if\(!isValidOptionalEmail\(email\)\)/);
});

// 54 — non-admin roles do not see the supplier mutation form, with a clear explanation.
test('P13-F04 supplier UI is hidden for non-admin roles and save is fail-closed', () => {
  const ctx = appContext(['canManageSuppliersUI'], { cu: { role: 'store-person' } });
  assert.equal(ctx.canManageSuppliersUI(), false);
  ctx.cu = { role: 'admin' };
  assert.equal(ctx.canManageSuppliersUI(), true);
  assert.match(html, /id="supplier-role-hint"[^>]*>Supplier master changes require an Admin or Developer role\./i);
  assert.match(app, /function renderSupp\(\)[\s\S]*supplier-mutation-card[\s\S]*canManage/);
  assert.match(app, /async function saveSupp\(\)[\s\S]*canRoleAction\('saveSupp'\)/);
});

// 55 — capacities accept blank/zero and positive integers, reject decimals/negative values.
test('P14-F01 location capacity rejects negative and fractional values', () => {
  const ctx = appContext(['parseLocationCapacity']);
  assert.deepEqual(JSON.parse(JSON.stringify(ctx.parseLocationCapacity(''))), { ok: true, value: 0 });
  assert.deepEqual(JSON.parse(JSON.stringify(ctx.parseLocationCapacity('4'))), { ok: true, value: 4 });
  assert.equal(ctx.parseLocationCapacity('-1').ok, false);
  assert.equal(ctx.parseLocationCapacity('1.5').ok, false);
});

// 56 — location report/CSV associations normalize numeric and string IDs.
test('P14-F02 restored/imported mixed-type IDs retain location assignments', () => {
  const ctx = appContext(['identifiersMatch']);
  assert.equal(ctx.identifiersMatch(7, '7'), true);
  assert.equal(ctx.identifiersMatch('loc-uuid', 'loc-uuid'), true);
  assert.equal(ctx.identifiersMatch(7, '8'), false);
  for (const name of ['renderLocs','renderLocStock','exportLocCSV','exportLocXLS']) {
    const fn = extractFunction(app, name);
    assert.match(fn, /identifiersMatch/);
  }
});

// 57 — failed location writes are reported and do not fake success or remove local records.
test('P14-F03 location save/delete persistence failures are surfaced', async () => {
  const toasts = [];
  const fields = { 'loc-zone': fakeElement({ value: 'A' }), 'loc-rack': fakeElement({ value: 'R1' }), 'loc-bin': fakeElement({ value: 'B1' }), 'loc-cap': fakeElement({ value: '10' }), 'loc-desc': fakeElement(), 'loc-eid': fakeElement() };
  const saveCtx = appContext(['saveLoc','parseLocationCapacity','identifiersMatch'], {
    document: fakeDocument(fields), LOCS: [], async dPut() { throw new Error('disk full'); }, toast: (m) => toasts.push(m), console: { log() {}, warn() {}, error() {} }
  });
  await saveCtx.saveLoc();
  assert.equal(saveCtx.LOCS.length, 0);
  assert.match(toasts.at(-1), /save failed/i);

  const deleteCtx = appContext(['delLoc','identifiersMatch'], {
    LOCS: [{ id: 'loc-1', zone: 'A', rack: 'R', bin: '1' }], M: [], canRoleAction: () => true,
    confirm: () => true, async dDel() { throw new Error('disk full'); }, renderLocs() {}, popLocSelects() {}, toast: m => toasts.push(m),
    locCode: loc => `${loc.zone}-${loc.rack}-${loc.bin}`, console: { log() {}, warn() {}, error() {} }
  });
  await deleteCtx.delLoc('loc-1');
  assert.equal(deleteCtx.LOCS.length, 1);
  assert.match(toasts.at(-1), /delete failed/i);
});

// 58 — department deletion is denied before touching persistence when authorization fails.
test('P15-F01 department deletion fails closed for unauthorized roles', async () => {
  let deletes = 0;
  const ctx = appContext(['delDept','identifiersMatch'], { DP: [{ id: 1, name: 'Ops' }], canRoleAction: () => false, confirm: () => true, async dDel() { deletes++; }, toast() {} });
  await ctx.delDept(1);
  assert.equal(deletes, 0);
  assert.equal(ctx.DP.length, 1);
});

// 59 — department names are escaped in generated tables and downstream HTML.
test('P15-F02 hostile department names are escaped in generated HTML', () => {
  const fields = { 'dp-cnt': fakeElement(), 'dp-body': fakeElement() };
  const ctx = appContextWithSanitizer(['renderDept','eventIdArg'], { DP: [{ id: 1, name: '<svg/onload=1>', code: '<b>Ops</b>' }], document: fakeDocument(fields) });
  ctx.renderDept();
  assert.doesNotMatch(fields['dp-body'].innerHTML, /<svg\/onload/);
  assert.match(fields['dp-body'].innerHTML, /&lt;svg\/onload/);
  assert.match(app, /sanitizeHTML\(String\(tx\.deptName/);
});

// 60 — destructive MSP entry points are wrapped with the mapping capability.
test('P16-F01 MSP destructive actions require mapping capability before execution', () => {
  const calls = [], ctx = vm.createContext({ console: { log() {}, warn() {}, error() {} } });
  ctx.window = {
    ACTION_ALIASES: {},
    canRoleAction(action) { calls.push(action); return false; },
    mspDeleteRow() { calls.push('EXEC_DELETE_ROW'); },
    mspClearAll() { calls.push('EXEC_CLEAR_ALL'); },
    mspDupList() { calls.push('EXEC_DUP_LIST'); }
  };
  vm.runInContext(extractFunction(app, 'installPermissionGuards'), ctx);
  ctx.installPermissionGuards();
  ctx.window.mspDeleteRow(); ctx.window.mspClearAll(); ctx.window.mspDupList();
  assert.deepEqual(calls, ['mapping','mapping','mapping']);
  assert.match(app, /'mspDeleteRow','mspClearAll','mspDupList'/);
  assert.match(app, /mspAddRow:'mapping', mspDeleteRow:'mapping', mspClearAll:'mapping', mspDupList:'mapping'/);
  assert.match(auth, /mspDeleteActiveList/);
});
