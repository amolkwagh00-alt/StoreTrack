const { debounce, throttle, DebounceManager } = require('../modules/debounce.js');

describe('Debounce and throttle utilities', () => {
  beforeEach(() => {
    jest.useFakeTimers();
    jest.setSystemTime(1000);
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  test('debounce delays execution and keeps the latest arguments/context', () => {
    const calls = [];
    const receiver = {
      value: 7,
      run(arg) {
        calls.push([this.value, arg]);
      },
    };
    const delayed = debounce(receiver.run, 100);
    delayed.call(receiver, 'first');
    delayed.call(receiver, 'latest');
    expect(calls).toEqual([]);
    jest.advanceTimersByTime(100);
    expect(calls).toEqual([[7, 'latest']]);
  });

  test('immediate debounce executes once, then permits a later call', () => {
    const fn = jest.fn();
    const immediate = debounce(fn, 100, true);
    immediate('first');
    immediate('ignored');
    expect(fn).toHaveBeenCalledTimes(1);
    jest.advanceTimersByTime(100);
    immediate('second window');
    expect(fn).toHaveBeenCalledTimes(2);
  });

  test('throttle executes immediately and schedules the trailing call', () => {
    const fn = jest.fn();
    const limited = throttle(fn, 100);
    limited('first');
    limited('trailing');
    expect(fn).toHaveBeenCalledWith('first');
    expect(fn).toHaveBeenCalledTimes(1);
    jest.advanceTimersByTime(100);
    expect(fn).toHaveBeenCalledTimes(2);
    expect(fn).toHaveBeenLastCalledWith('trailing');
  });

  test('manager caches functions by key and clears selected/all entries', () => {
    const manager = new DebounceManager();
    const fn = jest.fn();
    const one = manager.debounce('one', fn, 10);
    expect(manager.debounce('one', jest.fn(), 10)).toBe(one);
    const two = manager.throttle('two', fn, 10);
    expect(manager.throttle('two', jest.fn(), 10)).toBe(two);
    manager.clearDebounce('one');
    manager.clearThrottle('two');
    expect(manager.debounceMap.has('one')).toBe(false);
    expect(manager.throttleMap.has('two')).toBe(false);
    manager.debounce('three', fn);
    manager.throttle('four', fn);
    manager.clearAll();
    expect(manager.debounceMap.size).toBe(0);
    expect(manager.throttleMap.size).toBe(0);
  });

  test('manager cancel helpers clear scheduled function registries', () => {
    const manager = new DebounceManager();
    const fn = jest.fn();
    manager.debounce('search', fn, 10)('value');
    manager.throttle('scroll', fn, 10);
    manager.clearDebounce('search');
    manager.clearThrottle('scroll');
    expect(manager.debounceMap.size).toBe(0);
    expect(manager.throttleMap.size).toBe(0);
  });

  test('browser event helpers handle missing and present elements', () => {
    const mod = require('../modules/debounce.js');
    expect(mod).toHaveProperty('debounce');
    document.body.innerHTML = '<input id="search"><div></div>';
    const callback = jest.fn();
    const search = window.Debounce.applySearchDebounce('#search', callback, 50);
    document.querySelector('#search').value = 'abc';
    document.querySelector('#search').dispatchEvent(new Event('input', { bubbles: true }));
    jest.advanceTimersByTime(50);
    expect(callback).toHaveBeenCalledWith('abc');
    expect(window.Debounce.applySearchDebounce('#missing', callback)).toBeUndefined();
    const scroll = window.Debounce.applyScrollThrottle(callback, 10);
    const resize = window.Debounce.applyResizeThrottle(callback, 10);
    expect(typeof scroll).toBe('function');
    expect(typeof resize).toBe('function');
    window.Debounce.cancel('scroll');
    window.Debounce.cancelAll();
  });
});
