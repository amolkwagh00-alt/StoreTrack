'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const batch2c = require('../modules/batch2cFeatures.js');

test('Serial 24 generates stable, readable bin barcode labels mapped to location IDs', () => {
  const result = batch2c.validateBinLabels([{ id: 7, zone: 'A', rack: 'R1', bin: 'B2', desc: 'Fasteners' }]);
  assert.equal(result.valid, true);
  assert.deepEqual(result.labels[0], { index: 1, id: '7', code: 'A-R1-B2', barcode: 'BIN-A-R1-B2', zone: 'A', rack: 'R1', bin: 'B2', description: 'Fasteners' });
});

test('Serial 24 blocks duplicate and invalid location label assignments', () => {
  const result = batch2c.validateBinLabels([{ id: 1, zone: 'A', rack: 'R1', bin: 'B1' }, { id: 2, zone: 'A', rack: 'R1', bin: 'B1' }, { id: '', zone: '', rack: '', bin: '' }]);
  assert.equal(result.valid, false);
  assert.ok(result.errors.some(e => /Duplicate location code/.test(e.message)));
  assert.ok(result.errors.some(e => /missing a stable ID/.test(e.message)));
});

test('Serial 27 preview counts valid, invalid, added and duplicate rows without writing', () => {
  const preview = batch2c.previewImportRows([
    ['NEW-1', 'Bolt', 'Hardware', 'Pcs', '4', '2'],
    ['OLD-1', 'Existing', 'Hardware', 'Pcs', '3', '2'],
    ['', 'Missing barcode', 'Hardware', 'Pcs', '1', '1'],
    ['BAD-1', 'Bad qty', 'Hardware', 'Pcs', '-2', '1'],
    ['NEW-1', 'Duplicate', 'Hardware', 'Pcs', '1', '1'],
  ], { partno: 0, name: 1, category: 2, unit: 3, stock: 4, lowalert: 5 }, [{ id: 'old', barcode: 'OLD-1' }]);
  assert.deepEqual(preview.stats, { total: 5, valid: 2, invalid: 3, added: 1, updated: 0, skipped: 1, rejected: 3 });
  assert.equal(preview.safeToImport, false);
  assert.equal(preview.records[0].status, 'added');
  assert.equal(preview.records[1].status, 'skipped');
  assert.ok(preview.errors.every(e => Number.isInteger(e.row) && e.message));
});

test('Serial 27 UI has CSV and Excel preview controls and no live write in preview path', () => {
  const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
  const app = fs.readFileSync(path.join(__dirname, '../app.js'), 'utf8');
  assert.match(html, /accept="\.csv,\.xlsx,\.xls"/);
  assert.match(app, /previewImportRows/);
  assert.match(app, /Import blocked until invalid rows are corrected/);
  assert.match(app, /No live data was changed/);
});
