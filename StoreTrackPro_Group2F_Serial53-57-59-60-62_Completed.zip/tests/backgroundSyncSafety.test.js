const fs = require('fs');
const path = require('path');
const { BackgroundSync } = require('../modules/backgroundSync');

const root = path.join(__dirname, '..');
const worker = fs.readFileSync(path.join(root, 'service-worker.js'), 'utf8');

describe('sync honesty and API cache isolation', () => {
  test('syncBatch rejects instead of claiming records synchronized without a remote adapter', async () => {
    const sync = new BackgroundSync();
    await expect(sync.syncBatch('materials', [{ id: 1 }], 'server')).rejects.toThrow('Remote sync adapter is not configured');
  });

  test('upload and download explicitly fail while no remote adapters are configured', async () => {
    const sync = new BackgroundSync();
    await expect(sync.uploadData({ payload: [{ id: 1 }] })).rejects.toThrow('no data was uploaded');
    await expect(sync.downloadData()).rejects.toThrow('no data was downloaded');
  });

  test('initialization accepts concurrency options without treating them as an event bus', () => {
    const sync = new BackgroundSync();
    sync.startSyncProcessor = () => {};
    sync.registerServiceWorker = () => {};
    sync.initialize({ maxConcurrentTasks: 3, retryAttempts: 4 });
    expect(sync.getConfig()).toMatchObject({ maxConcurrent: 3, retryAttempts: 4 });
    expect(sync.eventBus).toBeNull();
  });

  test('API requests bypass Cache Storage rather than reusing another session response', () => {
    expect(worker).toContain("if (url.pathname.includes('/api/')) {");
    expect(worker).toContain('event.respondWith(fetch(event.request));');
    expect(worker).toContain('Never cache them by URL alone');
  });
});
