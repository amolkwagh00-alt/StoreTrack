const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'dashboardWidgets.js'), 'utf8');

function createHarness() {
  const elements = new Set();
  const document = {
    addEventListener() {},
    querySelector(selector) {
      const match = selector.match(/data-widget-id="([^"]+)"/);
      return match ? (elements.has(match[1]) ? { dataset: { widgetId: match[1] } } : null) : null;
    },
    createElement() { return {}; }
  };
  const context = {
    document,
    window: {},
    console,
    Date,
    setInterval,
    clearInterval,
    gAll: async () => [],
    dClr: async () => {},
    batchPut: async () => {}
  };
  vm.createContext(context);
  vm.runInContext(`${source}\nglobalThis.WidgetManagerForTest = WidgetManager;`, context);
  const manager = new context.WidgetManagerForTest();
  manager.widgetConfigs.clear();
  manager.widgetOrder = [];
  manager.registerWidget('fast', { visible: true, refreshInterval: 60000 });
  manager.registerWidget('slow', { visible: true, refreshInterval: 300000 });
  manager.registerWidget('hidden', { visible: false, refreshInterval: 60000 });
  elements.add('fast');
  elements.add('slow');
  return { manager, elements };
}

beforeEach(() => jest.useFakeTimers());
afterEach(() => jest.useRealTimers());

test('registered intervals default to one minute and are clamped to the supported 1–5 minute range', () => {
  const { manager } = createHarness();
  manager.registerWidget('default', {});
  manager.registerWidget('too-fast', { refreshInterval: 1000 });
  manager.registerWidget('too-slow', { refreshInterval: 600000 });
  expect(manager.getWidgetConfig('default').refreshInterval).toBe(60000);
  expect(manager.getWidgetConfig('too-fast').refreshInterval).toBe(60000);
  expect(manager.getWidgetConfig('too-slow').refreshInterval).toBe(300000);
});

test('timer refreshes only visible, rendered widgets when their individual intervals are due', async () => {
  const { manager } = createHarness();
  const refresh = jest.spyOn(manager, 'refreshWidget').mockResolvedValue();
  manager.startAutoRefresh();
  expect(jest.getTimerCount()).toBe(1);
  await jest.advanceTimersByTimeAsync(60000);
  expect(refresh.mock.calls.map(call => call[0])).toEqual(['fast']);
  await jest.advanceTimersByTimeAsync(240000);
  expect(refresh.mock.calls.map(call => call[0])).toEqual(['fast', 'fast', 'fast', 'fast', 'fast', 'slow']);
  expect(refresh.mock.calls.flat().join(',')).not.toContain('hidden');
});

test('repeated start replaces the timer, stop clears and nulls its handle, and full refresh is single-flight', async () => {
  const { manager } = createHarness();
  manager.startAutoRefresh();
  const firstHandle = manager.refreshInterval;
  manager.startAutoRefresh();
  expect(manager.refreshInterval).not.toBe(firstHandle);
  expect(jest.getTimerCount()).toBe(1);
  manager.stopAutoRefresh();
  expect(manager.refreshInterval).toBeNull();
  expect(jest.getTimerCount()).toBe(0);

  let finish;
  const gate = new Promise(resolve => { finish = resolve; });
  const refresh = jest.spyOn(manager, 'refreshWidget').mockImplementation(() => gate);
  const first = manager.refreshAllWidgets();
  const second = manager.refreshAllWidgets();
  expect(refresh).toHaveBeenCalledTimes(1);
  finish();
  await Promise.all([first, second]);
});
