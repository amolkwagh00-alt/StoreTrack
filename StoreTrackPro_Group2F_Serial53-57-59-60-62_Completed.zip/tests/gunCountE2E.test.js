const { initDB, gAll, dPut, dClr } = require('../modules/database');
const GunCountService = require('../core/gunCountService');

describe('Gun Count data-flow E2E contract', () => {
  beforeAll(async () => {
    await initDB();
  });
  beforeEach(async () => {
    await dClr('component_gun_rows');
    await dClr('component_mappings');
    await dClr('component_gun_counts');
  });

  test('Import → DB → Bin allocation → Label projection → Export projection → Backup data → BI metrics keeps one count per Gun occurrence', async () => {
    const imported = [
      {
        id: 'g1',
        sourceKey: 'matrix:Sheet1:2',
        sourceFile: 'matrix.xlsx',
        sourceSheet: 'Sheet1',
        sourceRow: 2,
        stationNo: 'S10',
        gunReferenceNo: 'G01',
        sourceOnly: false,
      },
      {
        id: 'g2',
        sourceKey: 'matrix:Sheet1:3',
        sourceFile: 'matrix.xlsx',
        sourceSheet: 'Sheet1',
        sourceRow: 3,
        stationNo: 'S10',
        gunReferenceNo: 'G02',
        sourceOnly: false,
      },
      {
        id: 'g3',
        sourceKey: 'matrix:Sheet1:4',
        sourceFile: 'matrix.xlsx',
        sourceSheet: 'Sheet1',
        sourceRow: 4,
        stationNo: 'S20',
        gunReferenceNo: 'G01',
        sourceOnly: false,
      },
    ];
    for (const row of imported) {
      await dPut('component_gun_rows', row);
    }
    const mappings = imported.map((r, i) => ({
      id: `m${i}`,
      sourceKey: r.sourceKey,
      sourceFile: r.sourceFile,
      stationNo: r.stationNo,
      gunReferenceNo: r.gunReferenceNo,
      position: 'Fix Shank',
      partNo: `P-${i}`,
      binId: `${r.stationNo}-BIN01`,
      quantity: 99,
      requiredQty: 1,
    }));
    for (const row of mappings) {
      await dPut('component_mappings', row);
    }

    const sourceRows = await gAll('component_gun_rows');
    const mappingRows = await gAll('component_mappings');
    const metrics = await GunCountService.persistAggregate({
      gAll,
      dPut,
      dClr,
      sourceRows,
      mappingRows,
    });
    expect(metrics.total).toBe(3);
    expect(metrics.allocated).toBe(3);

    // Bin projection, labels, reports, BI and exports all consume the same canonical metrics.
    const binProjection = mappingRows.filter((r) => r.binId);
    expect(GunCountService.calculateGunCount(binProjection, true)).toBe(3);
    const labelRows = sourceRows.map((r) => ({
      sourceKey: r.sourceKey,
      stationNo: r.stationNo,
      gunReferenceNo: r.gunReferenceNo,
      gunCount: 1,
    }));
    expect(GunCountService.calculateGunCount(labelRows)).toBe(3);
    const reportSummary = {
      sourceGunCount: metrics.source,
      mappedGunCount: metrics.mapped,
      allocatedGunCount: metrics.allocated,
      unassignedGunCount: metrics.unassigned,
    };
    const exportRows = [reportSummary, ...mappingRows];
    expect(exportRows[0].sourceGunCount).toBe(3);
    expect(GunCountService.calculateMetrics(sourceRows, mappingRows).total).toBe(3);

    // Physical verification changes quantity only; Gun Count must remain 3.
    for (const row of mappingRows) {
      row.quantity = 0;
      row.physicalQuantity = 4;
      await dPut('component_mappings', row);
    }
    expect(
      GunCountService.calculateMetrics(
        await gAll('component_gun_rows'),
        await gAll('component_mappings'),
      ).total,
    ).toBe(3);
    const backupData = {
      component_gun_rows: await gAll('component_gun_rows'),
      component_mappings: await gAll('component_mappings'),
      component_gun_counts: await gAll('component_gun_counts'),
    };
    expect(backupData.component_gun_counts.find((x) => x.id === 'global').gunCount).toBe(3);
  });

  test('BI source-only count appears with blank component columns and clears after assignment', async () => {
    const source = {
      id: 'g-source-only',
      sourceKey: 'matrix:Sheet1:9',
      sourceFile: 'matrix.xlsx',
      sourceSheet: 'Sheet1',
      sourceRow: 9,
      stationNo: 'S30',
      gunReferenceNo: 'G09',
      sourceOnly: true,
      fixShank: '',
      movingShank: '',
      fixAdaptor: '',
      movingAdaptor: '',
      fixHolder: '',
      movingHolder: '',
    };
    await dPut('component_gun_rows', source);

    const unassigned = await GunCountService.persistAggregate({ gAll, dPut, dClr, sourceRows: await gAll('component_gun_rows'), mappingRows: await gAll('component_mappings') });
    expect(unassigned.source).toBe(1);
    expect(unassigned.mapped).toBe(0);
    expect(unassigned.unassigned).toBe(1);

    source.sourceOnly = false;
    source.fixShank = 'FS-09';
    await dPut('component_gun_rows', source);
    const mapping = { id: 'm-source-only', sourceKey: source.sourceKey, sourceFile: source.sourceFile, stationNo: source.stationNo, gunReferenceNo: source.gunReferenceNo, position: 'Fix Shank', partNo: 'FS-09', binId: 'S30-BIN01' };
    await dPut('component_mappings', mapping);
    const assigned = await GunCountService.persistAggregate({ gAll, dPut, dClr, sourceRows: await gAll('component_gun_rows'), mappingRows: await gAll('component_mappings') });

    expect(assigned.source).toBe(1);
    expect(assigned.mapped).toBe(1);
    expect(assigned.allocated).toBe(1);
    expect(assigned.unassigned).toBe(0);
    expect((await gAll('component_gun_counts')).find(row => row.id === 'global')).toMatchObject({ gunCount: 1, mappedGunCount: 1, allocatedGunCount: 1, unassignedGunCount: 0 });
  });
});
