const fs = require('fs');
const path = require('path');
const vm = require('vm');
const crypto = require('crypto');
const { encryptBackup, decryptBackup, FORMAT, ALGORITHM } = require('../modules/secureBackup');

const root = path.join(__dirname, '..');
const rendererSource = fs.readFileSync(path.join(root, 'modules', 'dataBackup.js'), 'utf8');
const mainSource = fs.readFileSync(path.join(root, 'main.js'), 'utf8');

function functionText(source, name) {
  const asyncStart = source.indexOf(`async function ${name}(`);
  const start = asyncStart >= 0 ? asyncStart : source.indexOf(`function ${name}(`);
  if (start < 0) throw new Error(`missing ${name}`);
  const paramsEnd = source.indexOf(')', start);
  const open = source.indexOf('{', paramsEnd);
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let i = open; i < source.length; i += 1) {
    const ch = source[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth += 1;
    if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`unterminated ${name}`);
}

function makeTargetPC(storeNames, withFieldEncryption = false) {
  const db = Object.fromEntries(storeNames.map(name => [name, []]));
  db.users = [{ id: 'target-admin', username: 'target-admin', passwordHash: 'local-password-hash' }];
  const events = [];
  const preview = { innerHTML: '' };
  const targetWindowsKey = crypto.randomBytes(32);
  const fieldEncryptionManager = withFieldEncryption ? {
    enabled: true,
    encryptionKey: crypto.randomBytes(32).toString('base64'),
    encryptedFields: new Set(['name']),
  } : null;
  if (fieldEncryptionManager) {
    db.encryption_settings = [{ id: 'settings', enabled: true }];
    db.encryption_fields = [{ id: 'config', fields: ['name'] }];
    db.encryption_key = [{ id: 'master', key: fieldEncryptionManager.encryptionKey }];
  }
  const mainPortableFns = [
    functionText(mainSource, 'validateCompleteBackup'),
    functionText(mainSource, 'decryptPortableBackup'),
  ].join('\n');
  const decryptOnTarget = vm.runInNewContext(`${mainPortableFns}; decryptPortableBackup`, {
    Buffer,
    ENCRYPTED_BACKUP_FORMAT: FORMAT,
    ENCRYPTED_BACKUP_ALGORITHM: ALGORITHM,
    decryptBackup,
  });

  const context = {
    console,
    setTimeout: callback => { callback(); return 1; },
    setInterval: () => 1,
    clearInterval() {},
    document: { getElementById: id => id === 'backup-restore-preview' ? preview : null },
    localStorage: { getItem: () => null, setItem() {} },
    confirm: message => { events.push({ type: 'confirm', message }); return true; },
    toast: (message, type) => events.push({ type: 'toast', message, level: type }),
    audit: async (...args) => events.push({ type: 'audit', args }),
    window: { location: { reload() { events.push({ type: 'reload' }); } } },
    DB: 'StoreTrackDB_ShankMapping_Clean_20260825',
    db,
    STORES: storeNames,
    BACKUP_KEY: 'storetrack_last_backup_date',
    SECURITY_ACK_KEY: 'storetrack_plaintext_backup_warning_ack',
    getStoreNames: () => storeNames,
    gAll: async name => (db[name] || []).map(row => ({ ...row })),
    dClr: async name => { events.push({ type: 'clear', name }); db[name] = []; },
    dPut: async (name, row) => {
      events.push({ type: 'put', name, row: { ...row } });
      const stored = { ...row };
      if (fieldEncryptionManager?.enabled && fieldEncryptionManager.encryptedFields.size && !['encryption_settings', 'encryption_fields', 'encryption_key'].includes(name)) {
        stored.fieldEncryptionKeyUsed = fieldEncryptionManager.encryptionKey;
      }
      db[name].push(stored);
    },
  };
  if (fieldEncryptionManager) { context.window.DataEncryption = { manager: fieldEncryptionManager }; }
  context.window.backupBridge = {
    decryptPortable: async serialized => ({ ok: true, portable: true, data: decryptOnTarget(serialized) }),
    // A portable import must not read PC A's local backup or key.
    read: async () => { throw new Error('source PC local backup key is unavailable'); },
    write: async () => { events.push({ type: 'target-safety-backup', keyFingerprint: targetWindowsKey.subarray(0, 4).toString('hex') }); return { ok: true, fileName: 'target-safety.json' }; },
    writeRecoveryJournal: async () => ({ ok: true }),
    clearRecoveryJournal: async () => ({ ok: true }),
  };
  const rendererFns = ['dateKey', 'statusText', 'isUserStore', 'readSnapshot', 'writeRestoreJournal', 'clearRestoreJournal', 'collect', 'valid', 'validGRN', 'stable', 'compare', 'restoreTestRowKey', 'canonicalRestoreData', 'runIsolatedRestoreTest', 'saveRestoreVerification', 'escapeBackupHtml', 'createBackup', 'restoreBackup'];
  const functionSource = rendererFns.map(name => functionText(rendererSource, name)).join('\n');
  vm.runInNewContext(`const BACKUP_KEY='storetrack_last_backup_date'; const RESTORE_TEST_KEY='storetrack_last_restore_verification'; const SECURITY_ACK_KEY='storetrack_plaintext_backup_warning_ack'; ${functionSource}\nreadSnapshot = async names => Object.fromEntries(names.filter(name => name.toLowerCase() !== 'users').map(name => [name, (db[name] || []).map(row => ({...row}))])); this.restoreBackup=restoreBackup;`, context);
  return { context, db, events, preview, targetWindowsKey, fieldEncryptionManager };
}

test('portable backup from one Windows PC restores on a clean PC without the source safeStorage key', async () => {
  const storeNames = ['materials', 'transactions', 'users', 'grn', 'component_parts', 'component_mappings', 'component_stock'];
  const payloadStores = Object.fromEntries(storeNames.filter(name => name !== 'users').map(name => [name, []]));
  payloadStores.materials = [{ id: 'mat-1', name: 'Imported shank', quantity: 8 }];
  payloadStores.grn = [{ id: 'grn-1', grnNo: 'GRN-2026-01', items: [{ partNo: 'FS-101', qty: 8 }] }];
  payloadStores.component_parts = [{ id: 'part-1', partNo: 'FS-101', componentType: 'Fix Shank' }];
  payloadStores.component_mappings = [{ id: 'map-1', stationNo: 'ST-01', gunReferenceNo: 'GUN-1', partNo: 'FS-101' }];
  payloadStores.component_stock = [{ id: 'stock-1', partNo: 'FS-101', binId: 'BIN-01', quantity: 8 }];
  const payload = {
    format: 'StoreTrackProCompleteBackup',
    version: 2,
    createdAt: '2026-10-25T00:00:00.000Z',
    database: 'StoreTrackDB_ShankMapping_Clean_20260825',
    excludedStores: ['users'],
    stores: payloadStores,
  };

  // PC A's portable export: fresh random AES key is carried by the selected JSON file.
  const sourceWindowsKey = crypto.randomBytes(32);
  const portableFile = JSON.stringify({
    ...encryptBackup(JSON.stringify(payload), sourceWindowsKey),
    portableKey: sourceWindowsKey.toString('base64'),
  });

  // PC B has a separately generated protected key and a clean operational database.
  const target = makeTargetPC(storeNames);
  expect(target.targetWindowsKey.equals(sourceWindowsKey)).toBe(false);
  await target.context.restoreBackup(portableFile, 'StoreTrackPro-portable-backup.json');

  expect(target.db.materials).toEqual(payloadStores.materials);
  expect(target.db.grn).toEqual(payloadStores.grn);
  expect(target.db.component_parts).toEqual(payloadStores.component_parts);
  expect(target.db.component_mappings).toEqual(payloadStores.component_mappings);
  expect(target.db.component_stock).toEqual(payloadStores.component_stock);
  expect(target.db.users).toEqual([{ id: 'target-admin', username: 'target-admin', passwordHash: 'local-password-hash' }]);
  expect(target.events.some(event => event.type === 'target-safety-backup')).toBe(true);
  expect(target.events.some(event => event.type === 'confirm' && event.message.includes('This portable JSON includes its own recovery key'))).toBe(true);
  expect(target.events.find(event => event.type === 'toast' && event.message.includes('Backup restored'))).toBeDefined();
  expect(target.events.some(event => event.type === 'reload')).toBe(true);
});

test('portable restore adopts the backup field-encryption key before persisting imported rows', async () => {
  const storeNames = ['materials', 'users', 'encryption_settings', 'encryption_fields', 'encryption_key'];
  const sourceFieldKey = crypto.randomBytes(32).toString('base64');
  const stores = {
    materials: [{ id: 'mat-encrypted', name: 'Confidential source value' }],
    encryption_settings: [{ id: 'settings', enabled: true }],
    encryption_fields: [{ id: 'config', fields: ['name'] }],
    encryption_key: [{ id: 'master', key: sourceFieldKey }],
  };
  const payload = { format: 'StoreTrackProCompleteBackup', version: 2, createdAt: '2026-10-25T00:00:00.000Z', stores };
  const portableKey = crypto.randomBytes(32);
  const portableFile = JSON.stringify({ ...encryptBackup(JSON.stringify(payload), portableKey), portableKey: portableKey.toString('base64') });
  const target = makeTargetPC(storeNames, true);
  const targetFieldKey = target.fieldEncryptionManager.encryptionKey;
  expect(targetFieldKey).not.toBe(sourceFieldKey);

  await target.context.restoreBackup(portableFile, 'encrypted-source.json');

  expect(target.fieldEncryptionManager.enabled).toBe(true);
  expect(target.fieldEncryptionManager.encryptionKey).toBe(sourceFieldKey);
  expect(Array.from(target.fieldEncryptionManager.encryptedFields)).toEqual(['name']);
  expect(target.db.materials).toEqual([{ id: 'mat-encrypted', name: 'Confidential source value', fieldEncryptionKeyUsed: sourceFieldKey }]);
  expect(target.db.encryption_key).toEqual([{ id: 'master', key: sourceFieldKey }]);
  expect(target.db.users).toEqual([{ id: 'target-admin', username: 'target-admin', passwordHash: 'local-password-hash' }]);
});

test('a copied machine-bound backup is rejected with instructions to make a portable export on its source PC', () => {
  const decryptFnSource = `${functionText(mainSource, 'validateCompleteBackup')}\n${functionText(mainSource, 'decryptPortableBackup')}\nthis.decryptPortableBackup=decryptPortableBackup;`;
  const decrypt = vm.runInNewContext(`${decryptFnSource}; decryptPortableBackup`, {
    Buffer,
    ENCRYPTED_BACKUP_FORMAT: FORMAT,
    ENCRYPTED_BACKUP_ALGORITHM: ALGORITHM,
    decryptBackup,
  });
  const localOnlyEnvelope = encryptBackup(JSON.stringify({ format: 'StoreTrackProCompleteBackup', version: 2, stores: { materials: [] } }), crypto.randomBytes(32));
  expect(() => decrypt(JSON.stringify(localOnlyEnvelope))).toThrow(/source PC.*Windows-protected key.*Create.*portable JSON/i);
});
