const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'componentManagement.js'), 'utf8');

function sourceFunction(start, end) {
  const startIndex = source.indexOf(start);
  const endIndex = source.indexOf(end, startIndex);
  if (startIndex < 0 || endIndex < 0) { throw new Error(`Missing source function boundary: ${start}`); }
  return source.slice(startIndex, endIndex).trim();
}

const esc = value => String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');

async function answerDialog(dom, value) {
  for (let attempt = 0; attempt < 10 && !dom.window.document.querySelector('#cm-input-dialog-value'); attempt += 1) {
    await new Promise(resolve => setTimeout(resolve, 0));
  }
  const input = dom.window.document.querySelector('#cm-input-dialog-value');
  if (!input) { throw new Error('Expected mapping dialog did not render'); }
  input.value = value;
  dom.window.document.querySelector('[data-input-action="save"]').click();
}

describe('StoreTrack stock management behavior', () => {
  test('editing Pencil mapping through the rendered UI dialog does not change stock quantities', async () => {
    const dom = new JSDOM('<!doctype html><html><body></body></html>', { url: 'https://storetrack.test/' });
    const mapping = { id: 'pencil-map', stationNo: 'ECA 20 RH', gunReferenceNo: 'Gun 1', position: 'Fix Shank', partNo: '07-526/43', binId: 'PENCIL-BIN-01' };
    const state = { mappings: [mapping], stock: [{ id: 'pencil-stock', partNo: '07-526/43', binId: 'PENCIL-BIN-01', quantity: 7, minimumStock: 2 }], historicalConsumption: [] };
    const stockBefore = structuredClone(state.stock);
    const writes = [];
    const confirmations = [];
    const dialogSource = sourceFunction('function componentInputDialog(', '  const user = () => window.cu || {};');
    const componentInputDialog = new Function('document', 'esc', `${dialogSource}; return componentInputDialog;`)(dom.window.document, esc);
    const editSource = sourceFunction('async function editMapping(id) {', '  async function deleteMapping(id) {');
    const editMapping = new Function('state', 'canComponent', 'componentInputDialog', 'POSITIONS', 'vendorPartNo', 'partByNo', 'mappingIdentity', 'sameStation', 'validMappedPartNo', 'partKey', 'confirm', 'toastMsg', 'user', 'nowIso', 'dPut', 'uid', 'audit', 'load', 'migrateExistingRhLhCommonBins', 'reconcileRhLhCommonBinReferences', 'matrix', 'STORES', `return (${editSource});`)(
      state,
      () => true,
      componentInputDialog,
      ['Fix Shank', 'Moving Shank', 'Fix Adaptor', 'Moving Adaptor', 'Fix Holder', 'Moving Holder', 'Pencil Shank'],
      value => String(value ?? ''),
      partNo => ({ partNo }),
      (station, gun, position) => `${station}|${gun}|${position}`,
      (left, right) => String(left).toLowerCase() === String(right).toLowerCase(),
      value => Boolean(String(value || '').trim()),
      value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, ''),
      message => { confirmations.push(message); return true; },
      () => {},
      () => ({ id: 'test-user', username: 'test-user' }),
      () => '2026-10-27T00:00:00.000Z',
      async (store, row) => { writes.push({ store, row: structuredClone(row) }); },
      prefix => `${prefix}-test`,
      async () => {},
      async () => {},
      async () => {},
      async () => {},
      () => {},
      { mappings: 'component_mappings' },
    );

    const operation = editMapping('pencil-map');
    await answerDialog(dom, 'ECA 20 LH');
    await answerDialog(dom, 'Gun 1');
    await answerDialog(dom, 'Fix Shank');
    await answerDialog(dom, '07-526/43');
    await operation;

    expect(state.mappings[0].stationNo).toBe('ECA 20 LH');
    expect(state.stock).toEqual(stockBefore);
    expect(confirmations[0]).toContain('Current stock changed by this edit: No (quantity is not modified)');
    expect(writes.map(write => write.store)).toEqual(['component_mappings', 'component_mapping_revisions']);
    dom.window.close();
  });

  test('keeps 06-0519/215 in Pencil Common and hides its zero ECA row from Stock Control', async () => {
    const partNo = '06-0519/215';
    const state = {
      parts: [{ id: 'part-adaptor', partNo, componentType: 'Adaptor', minimumStock: 0 }],
      mappings: [{ id: 'pencil-map', partNo, position: 'Pencil Shank', stationNo: 'ECA 20 RH/LH', gunReferenceNo: 'Gun 1', binId: 'ECA 20 RH/LH' }],
      bins: [
        { id: 'common-bin', binId: 'ECA 20 RH/LH', stationNo: 'ECA 20 RH/LH', active: true },
        { id: 'pencil-bin', binId: 'PENCIL-BIN-19', stationNo: '', binKind: 'PENCIL_PAIR', pencilPartNumbers: [partNo], active: true },
      ],
      stock: [
        { id: 'adapter-zero', partNo, binId: 'ECA 20 RH/LH', quantity: 0, minimumStock: 0 },
        { id: 'misrouted-five', partNo, binId: 'PENCIL-BIN-19', quantity: 5, minimumStock: 0 },
      ],
      tx: [],
    };
    const partKeySource = sourceFunction('const pencilPartKey = value => {', 'const isPencilPart = value =>');
    const partKey = new Function('vendorPartNo', `${partKeySource}; return pencilPartKey;`)(value => String(value ?? ''));
    const masterLookup = value => state.parts.find(part => partKey(part.partNo) === partKey(value));
    const classifierSource = sourceFunction('const isPencilPart = value =>', '  function stockRowsForView');
    const isPencilPart = new Function('PENCIL_PART_FORMAT', 'pencilPartKey', 'partByNo', `${classifierSource}; return isPencilPart;`)(
      /^(?:07-\d{2,4}(?:\/l?\d+)?|06-\d{3}\/l?\d+)$/i,
      partKey,
      masterLookup,
    );
    const receiveOptionsSource = sourceFunction('function receiveMappedBinOptions(partNo) {', '  function receiveEntryPartNo');
    const receiveMappedBinOptions = new Function('vendorPartNo', 'receivePartFamily', 'partKey', 'isPencilPart', 'state', `return (${receiveOptionsSource});`)(
      value => String(value ?? ''),
      value => [value],
      partKey,
      isPencilPart,
      state,
    );
    const stockRowsSource = sourceFunction('function stockRowsForView() {', '  function stockRowLocationComment');
    const stockRowsForView = new Function('state', 'isPencilPart', 'partKey', 'activeBinForStation', 'partByNo', `return (${stockRowsSource});`)(
      state,
      isPencilPart,
      partKey,
      station => state.bins.find(bin => bin.stationNo === station),
      masterLookup,
    );
    const locationCommentSource = sourceFunction('function stockRowLocationComment(row) {', '  const pencilSeriesKey');
    const stockRowLocationComment = new Function(`return (${locationCommentSource});`)();
    const ensureSource = sourceFunction('async function ensureStockRecord(partNo, binId) {', '  async function changeStock(partNo, binId, delta');
    const writes = [];
    const ensureStockRecord = new Function('state', 'partKey', 'isPencilPart', 'sameStation', 'partByNo', 'autoSafetyQuantity', 'dPut', 'STORES', 'uid', 'nowIso', `return (${ensureSource});`)(
      state,
      partKey,
      isPencilPart,
      () => false,
      masterLookup,
      () => 0,
      async (...args) => writes.push(args),
      { stock: 'component_stock' },
      () => 'new-stock-id',
      () => '2026-10-29T00:00:00.000Z',
    );
    const planSource = sourceFunction('function allocationPlan(partNo, totalQuantity) {', '  function applyAllocationOverrides');
    const allocationPlan = new Function('partByNo', 'receivePartFamilyRoles', 'receiveMappedBinOptions', 'combinedStockQuantity', 'autoSafetyQuantity', 'allocationRecentConsumption', 'allocationExpectedStockOut', 'compareAllocationPriority', `return (${planSource});`)(
      masterLookup,
      value => ({ family: [value], original: [value], alternatives: [] }),
      receiveMappedBinOptions,
      (parts, binId) => state.stock.filter(row => parts.some(value => partKey(value) === partKey(row.partNo)) && row.binId === binId).reduce((sum, row) => sum + Number(row.quantity || 0), 0),
      () => 0,
      () => 0,
      () => ({ daysUntilZero: null, date: null, expectedStockOutDate: null }),
      (left, right) => String(left.binId).localeCompare(String(right.binId)),
    );

    expect(isPencilPart(partNo)).toBe(true);
    expect(receiveMappedBinOptions(partNo).map(option => option.binId)).toEqual(['PENCIL-BIN-19']);
    expect(allocationPlan(partNo, 5).map(option => [option.binId, option.quantity])).toEqual([['PENCIL-BIN-19', 5]]);
    const displayRows = stockRowsForView();
    const stationRow = displayRows.find(row => row.binId === 'ECA 20 RH/LH');
    expect(displayRows.map(row => row.binId).sort()).toEqual(['ECA 20 RH/LH', 'PENCIL-BIN-19']);
    expect(stationRow.quantity).toBe(5);
    expect(stationRow.pencilStockBinIds).toEqual(['PENCIL-BIN-19']);
    expect(stockRowLocationComment(stationRow)).toBe('Qty 5 is held in PENCIL-BIN-19');
    await ensureStockRecord(partNo, 'ECA 20 RH/LH');
    expect(writes).toHaveLength(0);
  });

  test('Required Quantity UI and consumption analytics reconcile against distinct fixture sources', () => {
    const state = {
      mappings: [
        { stationNo: 'ECA 20 RH', gunReferenceNo: 'Gun 1', position: 'Fix Shank', partNo: '07-526/43' },
        { stationNo: 'ECA 20 LH', gunReferenceNo: 'Gun 1', position: 'Fix Shank', partNo: '07-526/43' },
        { stationNo: 'ECA 20 RH', gunReferenceNo: 'Gun 2', position: 'Moving Shank', partNo: '07-526/43' },
        { stationNo: 'ECA 20 RH', gunReferenceNo: 'Gun 1', position: 'Fix Adaptor', partNo: '07-526/48' },
      ],
      tx: [
        { partNo: '07-526/43', type: 'Receive', direction: 'IN', quantity: 5, date: '2026-10-20T10:00:00Z' },
        { partNo: '07-526/43', type: 'Replacement / Issue', direction: 'OUT', quantity: 2, date: '2026-10-21T10:00:00Z' },
        { partNo: '07-526/43', type: 'Manual Shank Usage', direction: 'OUT', quantity: 1, date: '2026-10-22T10:00:00Z' },
      ],
      replacements: [{ partNo: '07-526/43', quantity: 2, stationNo: 'ECA 20 RH', replacementDate: '2026-10-21' }],
      historicalConsumption: [{ partNo: '07-526/43', quantity: 3, stationNo: 'ECA 20 LH', replacementDate: '2026-10-19' }],
    };
    const validMappedPartNo = value => Boolean(String(value || '').trim()) && !/^n\/?a$/i.test(String(value || '').trim());
    const vendorPartNo = value => value == null ? '' : String(value);
    const requiredRowsSource = sourceFunction('function requiredQuantityRows() {', '  function autoSafetyQuantity');
    const requiredQuantityRows = new Function('state', 'MAPPED_PART_POSITIONS', 'validMappedPartNo', 'vendorPartNo', 'canonicalStation', 'calculateGunCount', `return (${requiredRowsSource});`)(
      state,
      ['fixshank', 'movingshank', 'fixadaptor', 'movingadaptor', 'fixholder', 'movingholder'],
      validMappedPartNo,
      vendorPartNo,
      value => String(value || '').trim().replace(/\s+/g, ' '),
      value => value,
    );
    const dom = new JSDOM('<!doctype html><div id="component-management-content"></div>', { url: 'https://storetrack.test/' });
    const requiredUiSource = sourceFunction('function requiredQuantity() {', '  function forecastDateAdd');
    const table = (headers, rows, empty) => `<table><thead><tr>${headers.map(header => `<th>${header}</th>`).join('')}</tr></thead><tbody>${rows || `<tr><td colspan="${headers.length}">${empty}</td></tr>`}</tbody></table>`;
    const requiredQuantityUi = new Function('requiredQuantityRows', 'canComponent', 'esc', 'partDisplayWithComment', 'btn', 'table', 'shell', `return (${requiredUiSource});`)(
      requiredQuantityRows,
      () => true,
      esc,
      partNo => partNo,
      label => `<button>${esc(label)}</button>`,
      table,
      (title, body) => { dom.window.document.getElementById('component-management-content').innerHTML = `<h1>${title}</h1>${body}`; },
    );
    requiredQuantityUi();
    const pencilRow = [...dom.window.document.querySelectorAll('tr.cm-required-row')].find(row => row.dataset.part === '07-526/43');
    expect(pencilRow).toBeDefined();
    expect([...pencilRow.querySelectorAll('td')].map(cell => cell.textContent.trim()).slice(3, 6)).toEqual(['3', '3', '6']);
    expect(pencilRow.dataset.station).toContain('ECA 20 RH');
    expect(pencilRow.dataset.station).toContain('ECA 20 LH');

    const analyticsRowsSource = sourceFunction('function analyticsRows(start,end){', 'function lowStockRows()');
    const consumptionRowsSource = sourceFunction('function consumptionRows() {', '  function monthBounds');
    const analyticsBreakdownSource = sourceFunction('function analyticsBreakdown(start,end){', 'function openStationFromQr');
    const reporting = new Function('state', 'consumptionRows', `${analyticsRowsSource}; ${analyticsBreakdownSource}; return { analyticsRows, analyticsBreakdown };`)(
      state,
      new Function('state', `return (${consumptionRowsSource});`)(state),
    );
    expect(reporting.analyticsRows('2026-10-01', '2026-10-31')).toEqual([
      { date: '2026-10-20', receive: 5, replacement: 0, repairReturn: 0, scrap: 0, adjustment: 0 },
      { date: '2026-10-21', receive: 0, replacement: 2, repairReturn: 0, scrap: 0, adjustment: 0 },
      { date: '2026-10-22', receive: 0, replacement: 1, repairReturn: 0, scrap: 0, adjustment: 0 },
    ]);
    expect(reporting.analyticsBreakdown('2026-10-01', '2026-10-31').parts).toEqual([['07-526/43', 6]]);
    dom.window.close();
  });

  test('ECA 20 RH/LH merge keeps side identities and exposes a shared ECA 20 RH/LH bin label', async () => {
    const state = {
      gunRows: [
        { stationNo: 'ECA 20 RH', gunReferenceNo: 'Gun 1' },
        { stationNo: 'ECA 20 LH', gunReferenceNo: 'Gun 1' },
      ],
      mappings: [
        { id: 'rh-map', stationNo: 'ECA 20 RH', gunReferenceNo: 'Gun 1', position: 'Fix Shank', partNo: '07-526/43', binId: 'BIN-RH' },
        { id: 'lh-map', stationNo: 'ECA 20 LH', gunReferenceNo: 'Gun 1', position: 'Fix Shank', partNo: '07-526/48', binId: 'BIN-LH' },
      ],
      bins: [
        { id: 'rh-bin', binId: 'BIN-RH', name: 'BIN-RH', stationNo: 'ECA 20 RH', active: true },
        { id: 'lh-bin', binId: 'BIN-LH', name: 'BIN-LH', stationNo: 'ECA 20 LH', active: true },
      ],
      stock: [
        { id: 'rh-stock', partNo: '07-526/43', binId: 'BIN-RH', quantity: 3, minimumStock: 1 },
        { id: 'lh-stock', partNo: '07-526/48', binId: 'BIN-LH', quantity: 4, minimumStock: 1 },
      ],
      tx: [],
    };
    const normalStation = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const canonicalStation = value => String(value || '').trim().replace(/\s+/g, ' ');
    const baseStationName = value => canonicalStation(String(value || '').replace(/(?:[\s_-]+)(?:LH|RH)[/\\.,;:]*$/i, '').replace(/(?:[\s_-]+)(?:LH|RH)[/\\.,;:]*$/i, '').trim());
    const baseStationKey = value => normalStation(baseStationName(value));
    const stationVariantKey = value => normalStation(value);
    const mappingIdentity = (station, gun, position) => `${normalStation(station)}|${String(gun || '').toLowerCase()}|${String(position || '').toLowerCase()}`;
    const sourceFunctionFor = (start, end) => sourceFunction(start, end);
    const countSource = sourceFunctionFor('function mergeStationGunCount(station) {', '  function mergeStationGunCondition');
    const count = new Function('state', 'stationVariantKey', `return (${countSource});`)(state, stationVariantKey);
    const conditionSource = sourceFunctionFor('function mergeStationGunCondition(source, target) {', '  async function mergeStation(source, target)');
    const condition = new Function('mergeStationGunCount', 'baseStationKey', `return (${conditionSource});`)(count, baseStationKey);
    const planSource = sourceFunctionFor('function stationMergePlan(source, target) {', '  function previewStationMerge');
    const plan = new Function('state', 'canonicalStation', 'mappingIdentity', `return (${planSource});`)(state, canonicalStation, mappingIdentity);
    const writes = [];
    let seq = 0;
    const dPut = async (store, row) => { writes.push({ operation: 'put', store, id: row.id }); };
    const dDel = async (store, id) => { writes.push({ operation: 'delete', store, id }); state.stock = state.stock.filter(row => row.id !== id); };
    const mergeSource = sourceFunctionFor('async function mergeStation(source, target) {', '  const COMPONENT_STATION_MERGE_ROLLBACK');
    const merge = new Function('state', 'canComponent', 'canonicalStation', 'mergeStationGunCondition', 'toastMsg', 'stationMergePlan', 'confirm', 'binByStation', 'baseStationName', 'samePartNo', 'uid', 'nowIso', 'user', 'STORES', 'dPut', 'dDel', 'audit', 'load', 'bins', `return (${mergeSource});`)(
      state,
      () => true,
      canonicalStation,
      condition,
      () => {},
      plan,
      () => true,
      station => state.bins.find(bin => bin.active !== false && normalStation(bin.stationNo) === normalStation(station)),
      baseStationName,
      (left, right) => normalStation(left) === normalStation(right),
      prefix => `${prefix}-${++seq}`,
      () => '2026-10-27T00:00:00.000Z',
      () => ({ id: 'test-user' }),
      { bins: 'component_bins', mappings: 'component_mappings', stock: 'component_stock', tx: 'component_stock_transactions' },
      dPut,
      dDel,
      async () => {},
      async () => {},
      () => {},
    );

    await merge('ECA 20 RH', 'ECA 20 LH');
    const sharedBin = state.bins.find(bin => bin.binId === 'ECA 20 RH/LH');
    expect(sharedBin).toEqual(expect.objectContaining({ name: 'ECA 20 RH/LH Common Bin', active: true }));
    expect(state.mappings.map(row => [row.stationNo, row.gunReferenceNo, row.binId])).toEqual([
      ['ECA 20 RH', 'Gun 1', 'ECA 20 RH/LH'],
      ['ECA 20 LH', 'Gun 1', 'ECA 20 RH/LH'],
    ]);
    expect(state.stock.map(row => [row.partNo, row.binId, row.quantity]).sort()).toEqual([
      ['07-526/43', 'ECA 20 RH/LH', 3],
      ['07-526/48', 'ECA 20 RH/LH', 4],
    ]);
    expect(writes.some(write => write.store === 'component_bins' && write.operation === 'put')).toBe(true);
  });
});
