const fs = require('fs');
const vm = require('vm');
const source = fs.readFileSync(
  require('path').join(__dirname, '..', 'modules', 'aiAssistants.js'),
  'utf8',
);
const context = { window: {}, console, Set, Map, Number, String, Date, Intl };
vm.createContext(context);
vm.runInContext(source, context);
const api = context.window.aiAssistantTest;
const data = {
  component_parts: [{ partNo: 'P-101', unit: 'pcs' }],
  component_stock: [{ partNo: 'P-101', quantity: 4, binId: 'B1' }],
  component_mappings: [{ partNo: 'P-101', stationNo: 'S1', gunReferenceNo: 'G1' }],
  component_replacements: [
    {
      partNo: 'P-101',
      quantity: 1,
      replacementDateTime: '2026-09-01T10:00:00Z',
      stationNo: 'S1',
      gunReferenceNo: 'G1',
      shift: 'A',
      maintenanceTeam: 'Team 1',
    },
    {
      partNo: 'P-101',
      quantity: 1,
      replacementDateTime: '2026-09-02T10:00:00Z',
      stationNo: 'S1',
      gunReferenceNo: 'G1',
      shift: 'A',
      maintenanceTeam: 'Team 1',
    },
  ],
  component_repair_scrap: [
    { partNo: 'P-101', status: 'Pending', repairReason: 'wear', stationNo: 'S1' },
  ],
  audit: [
    {
      action: 'ADJUST',
      details: 'manual stock adjustment',
      userName: 'auditor',
      time: '2026-09-02T10:00:00Z',
    },
  ],
  users: [{ username: 'auditor', role: 'admin' }],
  materials: [],
  transactions: [],
};
if (!api.answerChat('P-101 current stock किती?', data).includes('4'))
  throw new Error('stock answer failed');
const mappingAnswer = api.answerChat('P-101 कुठे वापरला आहे?', data);
if (!mappingAnswer.includes('S1')) throw new Error('mapping answer failed');
if (!api.rootCause('P-101', data).possibleReasons.length) throw new Error('root cause failed');
if (!api.auditAnalysis(data).summary.includes('1 events')) throw new Error('audit analysis failed');
console.log('AI assistant smoke test passed');
