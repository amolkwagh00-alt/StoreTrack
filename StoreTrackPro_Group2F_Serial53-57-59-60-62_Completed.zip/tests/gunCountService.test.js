const GunCountService = require('../core/gunCountService');

describe('Canonical Gun Count service', () => {
  test('shared calculateGunCount is canonical and ignores quantity', () => {
    const rows = [
      { sourceKey: 'A:1', stationNo: 'S1', gunReferenceNo: 'G1', quantity: 2 },
      { sourceKey: 'A:2', stationNo: 'S1', gunReferenceNo: 'G1', quantity: 99 },
      { sourceKey: 'A:3', stationNo: 'S1', gunReferenceNo: 'G2', quantity: 1 },
    ];

    expect(GunCountService.calculateGunCount(rows, true)).toBe(2);
  });

  test('counts only rows with an actual component part and keeps common-gun rows separate', () => {
    const rows = [
      { sourceKey: 'A:1', stationNo: 'S1', gunReferenceNo: 'COMMON', fixShank: 'FS-1' },
      { sourceKey: 'A:2', stationNo: 'S1', gunReferenceNo: 'COMMON', movingHolder: 'MH-1' },
      {
        sourceKey: 'A:3',
        stationNo: 'S2',
        gunReferenceNo: 'EMPTY',
        fixShank: '',
        movingShank: 'NA',
        fixedHolder: '',
      },
    ];

    expect(GunCountService.calculateGunCount(rows)).toBe(2);
    expect(GunCountService.calculateMetrics(rows, []).source).toBe(2);
  });

  test('blank component columns do not hide a flagged source-only Gun from BI unassigned counts', () => {
    const metrics = GunCountService.calculateMetrics([
      {
        sourceKey: 'A:9',
        stationNo: 'S9',
        gunReferenceNo: 'G9',
        sourceOnly: true,
        fixShank: '',
        movingShank: '',
        fixAdaptor: '',
        movingAdaptor: '',
        fixHolder: '',
        movingHolder: '',
      },
    ], []);

    expect(metrics.source).toBe(1);
    expect(metrics.unassigned).toBe(1);
    expect(metrics.reconciliation.sourceMinusMapped).toBe(1);
    expect(metrics.reconciliation.balanced).toBe(false);
  });

  test('fingerprint changes when allocation changes but not when quantity changes', () => {
    const source = [{ sourceKey: 'A:1', stationNo: 'S1', gunReferenceNo: 'G1', quantity: 1 }];
    const mapping = [
      { sourceKey: 'M:1', stationNo: 'S1', gunReferenceNo: 'G1', binId: 'B1', quantity: 1 },
    ];

    const first = GunCountService.calculateMetrics(source, mapping);
    mapping[0].quantity = 999;
    const quantityChanged = GunCountService.calculateMetrics(source, mapping);

    expect(quantityChanged.sourceHash).toBe(first.sourceHash);
    expect(quantityChanged.mappingHash).toBe(first.mappingHash);

    mapping[0].binId = 'B2';
    const allocationChanged = GunCountService.calculateMetrics(source, mapping);

    expect(allocationChanged.mappingHash).not.toBe(quantityChanged.mappingHash);
  });

  test('reconciliation identifies source-only and partially allocated states', () => {
    const source = [
      { sourceKey: 'A:1', stationNo: 'S1', gunReferenceNo: 'G1' },
      { sourceKey: 'A:2', stationNo: 'S2', gunReferenceNo: 'G2', sourceOnly: true },
    ];
    const mapping = [{ sourceKey: 'M:1', stationNo: 'S1', gunReferenceNo: 'G1', binId: 'B1' }];

    const metrics = GunCountService.calculateMetrics(source, mapping);

    expect(metrics.reconciliation.balanced).toBe(false);
    expect(metrics.reconciliation.sourceMinusMapped).toBe(1);
    expect(metrics.reconciliation.mappedMinusAllocated).toBe(0);
  });

  test('persistAggregate skips rewriting unchanged aggregate', async () => {
    const store = [];
    const gAll = async () => store.slice();
    const dClr = async () => {
      store.length = 0;
    };
    const dPut = async (_name, row) => {
      store.push(row);
    };

    const source = [{ sourceKey: 'A:1', stationNo: 'S1', gunReferenceNo: 'G1' }];

    const first = await GunCountService.persistAggregate({
      gAll,
      dPut,
      dClr,
      sourceRows: source,
      mappingRows: [],
      existingRows: [],
    });

    const second = await GunCountService.persistAggregate({
      gAll,
      dPut,
      dClr,
      sourceRows: source,
      mappingRows: [],
      existingRows: store.slice(),
    });

    expect(first.persisted).toBe(true);
    expect(second.unchanged).toBe(true);
    expect(store.length).toBeGreaterThan(0);
  });

  test('persistAggregate refreshes unassigned count when a source row is assigned without changing total source count', async () => {
    const store = [];
    const gAll = async () => store.slice();
    const dClr = async () => { store.length = 0; };
    const dPut = async (_name, row) => { store.push(row); };
    const source = [{ sourceKey: 'A:1', stationNo: 'S1', gunReferenceNo: 'G1', sourceOnly: true, fixShank: 'FS-1' }];

    await GunCountService.persistAggregate({ gAll, dPut, dClr, sourceRows: source, mappingRows: [], existingRows: [] });
    source[0].sourceOnly = false;
    const updated = await GunCountService.persistAggregate({ gAll, dPut, dClr, sourceRows: source, mappingRows: [], existingRows: store.slice() });

    expect(updated.persisted).toBe(true);
    expect(updated.source).toBe(1);
    expect(updated.unassigned).toBe(0);
    expect(store.find(row => row.id === 'global').unassignedGunCount).toBe(0);
  });

  test('persists global and station aggregates', async () => {
    const store = [];
    const gAll = async () => store.slice();
    const dClr = async () => {
      store.length = 0;
    };
    const dPut = async (_name, row) => {
      store.push(row);
    };

    const metrics = await GunCountService.persistAggregate({
      gAll,
      dPut,
      dClr,
      sourceRows: [
        { sourceKey: 'A:1', stationNo: 'S1', gunReferenceNo: 'G1' },
        { sourceKey: 'A:2', stationNo: 'S1', gunReferenceNo: 'G2' },
        { sourceKey: 'A:3', stationNo: 'S2', gunReferenceNo: 'G1' },
      ],
      mappingRows: [],
    });

    expect(metrics.total).toBe(3);
    expect(store.find((x) => x.id === 'global').gunCount).toBe(3);
    expect(store.find((x) => x.scope === 'STATION' && x.stationNo === 'S1').gunCount).toBe(2);
  });
});
