'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function extract(source, name) {
  const start = source.indexOf(`function ${name}(`); assert.notEqual(start, -1);
  const open = source.indexOf('{', start); let depth = 0; let quote = null; let escaped = false;
  for (let i = open; i < source.length; i++) {
    const ch = source[i];
    if (quote) { if (escaped) escaped = false; else if (ch === '\\') escaped = true; else if (ch === quote) quote = null; continue; }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth++;
    else if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Unclosed function ${name}`);
}
const app = fs.readFileSync(path.join(__dirname, '../app.js'), 'utf8');

test('stock accuracy uses item-level exact matches and absolute units of variance', () => {
  const context = {};
  vm.runInNewContext(`${extract(app, 'computeStockAccuracy')}; result = computeStockAccuracy([
    { details: [{ diff: 0 }, { diff: 4 }, { diff: -2 }] },
    { details: [{ diff: 0 }, { diff: 'bad' }] },
    { items: [] }
  ]);`, context);
  assert.deepEqual(JSON.parse(JSON.stringify(context.result)), { counts: 3, items: 4, matched: 2, accuracy: 50, absoluteVariance: 6 });
});

test('accuracy report filters counts by period and exports details with preview confirmation', () => {
  const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
  assert.match(html, /id="cc-period" aria-label="Stock accuracy reporting period"/);
  assert.match(html, /Stock Accuracy Report/);
  assert.match(app, /type==='stockaccuracy'/);
  assert.match(app, /Stock accuracy export preview/);
  assert.match(app, /Exact match rate: \$\{stats\.accuracy\.toFixed\(1\)\}%/);
});
