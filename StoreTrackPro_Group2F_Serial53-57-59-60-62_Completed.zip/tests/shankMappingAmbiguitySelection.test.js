const fs = require('fs');
const path = require('path');

const source = fs.readFileSync(
  path.join(__dirname, '..', 'modules', 'componentManagement.js'),
  'utf8',
);

describe('ambiguous Part No. selection workflow', () => {
  test('a multi-part cell with no bold value maps no Part automatically', () => {
    const start = source.indexOf('const selectedValueFor = field => {');
    const end = source.indexOf('; const getPart', start);
    expect(start).toBeGreaterThanOrEqual(0);
    expect(end).toBeGreaterThan(start);
    const expression = source.slice(
      start + 'const selectedValueFor = '.length,
      end,
    );
    const selectValue = new Function(
      'MAPPED_PART_FIELDS',
      'splitBoldPartText',
      'boldValueFor',
      'values',
      'idx',
      'fieldValue',
      `return (${expression});`,
    )(
      ['fixShank'],
      (value) => String(value).split(',').map((part) => part.trim()),
      () => [],
      ['PN-A, PN-B'],
      { fixShank: 0 },
      () => '',
    );

    expect(selectValue('fixShank')).toEqual([]);
    expect(source).not.toContain('pendingImport.boldAware');
  });

  test('bold value is the Original; unbolded candidates do not get a default Original', () => {
    const parserLine = source.split('\n').find((line) => line.includes('const partOptionsFor = field =>'));
    expect(parserLine).toContain('const original = bold[0] ||');
    expect(parserLine).toContain('const alternatives = bold.length ? raw.filter');
    expect(parserLine).not.toContain('raw[0] ||');
  });

  test('BI lists unresolved rows as PENDING and explains user-selected Original semantics', () => {
    expect(source).toContain('Part Selection Pending — Original / Alternative');
    expect(source).toContain('<span class="pill pill-y">PENDING</span>');
    expect(source).toContain('No Part No. is bold. No Original is assumed');
    expect(source).toContain('the user-selected Part becomes Original and all remaining candidates become Alternatives');
  });

  test('bold Original is not pending when stock is zero; no-bold candidates remain pending', () => {
    const start = source.indexOf('function ambiguousPartRows()');
    const end = source.indexOf('function ambiguousPartSection()', start);
    const resolverSource = source.slice(start, end);
    const rows = new Function(
      'state', 'likelyField', 'splitBoldPartText', 'validMappedPartNo', 'samePartNo', 'partStockQuantity',
      `${resolverSource}; return ambiguousPartRows;`,
    )(
      {
        gunRows: [
          { id: 'bold', sourceHeaders: ['Fixed Shank'], sourceValues: ['PN-1/PN-2'], boldParts: { fixShank: ['PN-1'] } },
          { id: 'unbolded', sourceHeaders: ['Fixed Shank'], sourceValues: ['PN-1/PN-2'], boldParts: { fixShank: [] } },
        ],
      },
      (header, field) => header === 'Fixed Shank' && field === 'fixShank',
      value => String(value || '').split('/').map(part => part.trim()).filter(Boolean),
      value => Boolean(value) && !/^NA$/i.test(value),
      (left, right) => String(left).toLowerCase() === String(right).toLowerCase(),
      () => 0,
    )();

    expect(rows.find(item => item.row.id === 'bold')).toBeUndefined();
    expect(rows.find(item => item.row.id === 'unbolded').choices[0]).toMatchObject({
      original: '',
      candidates: ['PN-1', 'PN-2'],
    });
  });

  test('saving requires a selection for every ambiguous field and assigns all remaining candidates as Alternatives', () => {
    expect(source).toContain('Select a Part No. for every pending component field before saving');
    expect(source).toContain('original: selected,');
    expect(source).toContain('alternatives: candidates.filter(part => !samePartNo(part, selected))');
    expect(source).toContain('row.ambiguousResolved = true;');
  });

  test('selected Original and Alternative stock records are created in the row Station Common Bin', () => {
    const backfillStart = source.indexOf('async function backfillMappingsFromGunRows()');
    const backfillEnd = source.indexOf('function rhLhStationSide', backfillStart);
    const backfill = source.slice(backfillStart, backfillEnd);
    expect(backfill).toContain('activeBinForStation(row.stationNo)');
    expect(backfill).toContain('await ensureCandidateStockRecords(row, bin);');
    expect(backfill).toContain('mappingIdentity(row.stationNo, row.gunReferenceNo, position)');
  });
});

describe('station-scoped Common Bin and mapping identity', () => {
  test('the same Part No. at FFA and UB resolves to independent Common Bins', () => {
    const resolver = source.slice(
      source.indexOf('function activeBinForStation'),
      source.indexOf('function displayStationForBin'),
    );
    const getBin = new Function(
      'state',
      'canonicalStation',
      'baseStationKey',
      'sameStation',
      `${resolver}; return activeBinForStation;`,
    )(
      {
        bins: [
          { binId: 'FFA-BIN01', stationNo: 'FFA 10', active: true },
          { binId: 'UB-BIN01', stationNo: 'UB 10', active: true },
        ],
      },
      (value) => String(value || '').trim(),
      (value) => String(value || '').trim().toLowerCase(),
      (left, right) => String(left || '').trim().toLowerCase() === String(right || '').trim().toLowerCase(),
    );

    expect(getBin('FFA 10').binId).toBe('FFA-BIN01');
    expect(getBin('UB 10').binId).toBe('UB-BIN01');
    expect(source).toContain('mappingIdentity(row.stationNo, row.gunReferenceNo, position)');
  });

  test('mapping identity includes Station so repeated Part Numbers do not collapse across Stations', () => {
    const declaration = source.match(/const mappingIdentity = .*?;/)?.[0];
    expect(declaration).toBeTruthy();
    const mappingIdentity = new Function(
      'normalStation',
      `return (${declaration.replace('const mappingIdentity = ', '').slice(0, -1)});`,
    )((value) => String(value || '').trim().toLowerCase());

    expect(mappingIdentity('FFA 10', 'Gun 1', 'Fix Shank')).not.toBe(
      mappingIdentity('UB 10', 'Gun 1', 'Fix Shank'),
    );
  });
});
