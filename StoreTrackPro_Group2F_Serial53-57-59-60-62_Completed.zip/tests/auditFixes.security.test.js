const crypto = require('crypto');
const { DataEncryptionManager } = require('../modules/dataEncryption');
const { TwoFactorAuthManager } = require('../modules/twoFactorAuth');
const { SessionManager } = require('../modules/sessionManager');
const { PasswordPolicy } = require('../modules/passwordPolicy');
const serverAuth = require('../server/auth');

describe('StoreTrack assigned security audit regressions', () => {
  const previousWindowBridge = window.encryptionKeyBridge;
  const previousDataEncryption = window.DataEncryption;
  const previousGOne = global.gOne;
  const previousDDel = global.dDel;
  const previousDPut = global.dPut;
  const previousGAll = global.gAll;

  afterEach(() => {
    window.encryptionKeyBridge = previousWindowBridge;
    window.DataEncryption = previousDataEncryption;
    global.gOne = previousGOne;
    global.dDel = previousDDel;
    global.dPut = previousDPut;
    global.gAll = previousGAll;
    window.localStorage.removeItem('storetrack.login-lockouts.v1');
    jest.restoreAllMocks();
  });

  test('legacy IndexedDB master key migrates to OS-backed storage and is deleted only after verification', async () => {
    const oldKey = crypto.randomBytes(32).toString('base64');
    global.gOne = jest.fn(async () => ({ id: 'master', key: oldKey }));
    global.dDel = jest.fn(async () => {});
    let protectedKey = null;
    window.encryptionKeyBridge = {
      getKey: async () => ({ available: true, key: protectedKey }),
      setKey: async key => { protectedKey = key; }
    };
    const manager = new DataEncryptionManager();

    await manager.loadOrGenerateKey();

    expect(manager.encryptionKey).toBe(oldKey);
    expect(protectedKey).toBe(oldKey);
    expect(global.dDel).toHaveBeenCalledWith('encryption_key', 'master');
  });

  test('configured encryption rejects missing keys and crypto failures instead of returning plaintext', async () => {
    const manager = new DataEncryptionManager();
    manager.enabled = true;
    await expect(manager.encrypt('sensitive-value')).rejects.toThrow(/key is unavailable/);

    manager.encryptionKey = 'not-a-canonical-key';
    await expect(manager.encrypt('sensitive-value')).rejects.toThrow(/refusing to store plaintext/);

    manager.encryptionKey = crypto.randomBytes(32).toString('base64');
    const ciphertext = await manager.encrypt('sensitive-value');
    expect(ciphertext).toMatch(/^st-encrypted:v1:/);
    expect(ciphertext).not.toContain('sensitive-value');
    await expect(manager.decrypt(ciphertext)).resolves.toBe('sensitive-value');
    await expect(manager.decrypt(`st-encrypted:v1:${'A'.repeat(60)}`)).rejects.toThrow(/refusing to return ciphertext/);
  });

  test('unsupported OS key protection preserves access to legacy keys but refuses protected writes', async () => {
    const oldKey = crypto.randomBytes(32).toString('base64');
    global.gOne = jest.fn(async () => ({ id: 'master', key: oldKey }));
    window.encryptionKeyBridge = { getKey: async () => ({ available: false, key: null }), setKey: jest.fn() };
    const manager = new DataEncryptionManager();
    manager.enabled = true;

    await manager.loadOrGenerateKey();
    expect(manager.encryptionKey).toBe(oldKey);
    expect(manager.legacyInsecureKey).toBe(true);
    await expect(manager.encrypt('new secret')).rejects.toThrow(/OS-protected key storage is unavailable/);
    await expect(manager.protectSecret('totp-seed')).rejects.toThrow(/OS-protected key storage is unavailable/);
  });

  test('failure to load encryption settings is propagated instead of defaulting to plaintext mode', async () => {
    global.gOne = jest.fn(async () => { throw new Error('IndexedDB read unavailable'); });
    const manager = new DataEncryptionManager();

    await expect(manager.init()).rejects.toThrow(/IndexedDB read unavailable/);
    expect(manager.enabled).toBe(false);
  });

  test('2FA seeds are persisted as protected envelopes and backup codes only as one-way hashes', async () => {
    const writes = [];
    global.dPut = jest.fn(async (store, record) => {
      writes.push({ store, record: structuredClone(record) });
      return writes.length;
    });
    const manager = new TwoFactorAuthManager();
    window.DataEncryption = {
      manager: {
        protectSecret: jest.fn(async secret => `st-secure:v1:${Buffer.from(secret).toString('base64')}`)
      }
    };

    const setup = await manager.setup2FA('user-1');
    const savedSeed = writes.find(write => write.store === '2fa_secrets').record.secret;
    const savedCodes = writes.filter(write => write.store === '2fa_backup_codes');

    expect(savedSeed).toMatch(/^st-secure:v1:/);
    expect(savedSeed).not.toBe(setup.secret);
    expect(savedCodes).toHaveLength(10);
    expect(savedCodes.every(write => /^pbkdf2-sha256\$120000\$/.test(write.record.code))).toBe(true);
    expect(savedCodes.some(write => write.record.code === btoa(setup.backupCodes[0]))).toBe(false);
    expect(await manager.verifyBackupCode(setup.backupCodes[0], savedCodes[0].record.code)).toBe(true);
  });

  test('legacy reversible backup codes are irreversibly migrated without invalidating them', async () => {
    const legacy = { id: 13, userId: 'user-2', code: btoa('87654321'), used: false };
    global.gAll = jest.fn(async store => store === '2fa_backup_codes' ? [legacy] : []);
    global.dPut = jest.fn(async () => 13);
    const manager = new TwoFactorAuthManager();

    await manager.loadBackupCodes();

    const migrated = manager.backupCodes.get('user-2')[0];
    expect(migrated.code).toMatch(/^pbkdf2-sha256\$120000\$/);
    expect(migrated.code).not.toBe(legacy.code);
    expect(global.dPut).toHaveBeenCalledWith('2fa_backup_codes', expect.objectContaining({ code: migrated.code }));
    expect(await manager.verifyBackupCode('87654321', migrated.code)).toBe(true);
  });

  test('plain IndexedDB session records regain their prototype methods when hydrated', () => {
    const manager = new SessionManager();
    const hydrated = manager.hydrateSession({
      id: 's-1', userId: 'u-1', username: 'alice', active: true,
      startTime: new Date(Date.now() - 60_000).toISOString(),
      lastActivity: new Date().toISOString(), timeoutMinutes: 30
    });

    expect(hydrated.isExpired()).toBe(false);
    expect(hydrated.getDuration()).toBeGreaterThan(0);
    hydrated.invalidate();
    expect(hydrated.active).toBe(false);
    hydrated.updateActivity();
    expect(typeof hydrated.lastActivity).toBe('string');
  });

  test('account lockout survives construction of a new policy instance (app restart simulation)', () => {
    window.localStorage.removeItem('storetrack.login-lockouts.v1');
    const firstRun = new PasswordPolicy();
    firstRun.policy.maxFailedAttempts = 3;
    firstRun.recordFailedAttempt('restart-user');
    firstRun.recordFailedAttempt('restart-user');
    firstRun.recordFailedAttempt('restart-user');
    expect(firstRun.isAccountLocked('restart-user')).toBe(true);

    const afterRestart = new PasswordPolicy({ restorePersistedLockouts: true });
    expect(afterRestart.isAccountLocked('restart-user')).toBe(true);
    expect(afterRestart.getRemainingLockTime('restart-user')).toBeGreaterThan(0);
  });

  test('new bcrypt hashes do not treat suffix-distinct passwords over 72 UTF-8 bytes as equivalent', async () => {
    const prefix = 'A'.repeat(72);
    const original = `${prefix}-original-suffix`;
    const alternate = `${prefix}-different-suffix`;
    const hash = await serverAuth.hashPassword(original);

    expect(hash).toMatch(/^\$bcrypt-sha256\$/);
    await expect(serverAuth.verifyPassword(original, hash)).resolves.toBe(true);
    await expect(serverAuth.verifyPassword(alternate, hash)).resolves.toBe(false);
  });

  test('legacy raw bcrypt hashes remain verifiable for safe password-hash transition', async () => {
    const bcrypt = require('bcryptjs');
    const oldHash = await bcrypt.hash('Existing-Password1!', 4);
    await expect(serverAuth.verifyPassword('Existing-Password1!', oldHash)).resolves.toBe(true);
    await expect(serverAuth.verifyPassword('Wrong-Password1!', oldHash)).resolves.toBe(false);
  });
});
