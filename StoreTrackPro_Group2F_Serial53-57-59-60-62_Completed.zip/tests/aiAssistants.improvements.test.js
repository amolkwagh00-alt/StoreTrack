const assert = require('assert');
const fs = require('fs');
const vm = require('vm');

test('AI assistant improvements support evidence, clarification, roles, and confidence', () => {
  const source = fs.readFileSync(
    require('path').join(__dirname, '..', 'modules', 'aiAssistants.js'),
    'utf8',
  );
  const context = { window: {}, console, Set, Map, Number, String, Date, Intl };
  vm.createContext(context);
  vm.runInContext(source, context);
  const api = context.window.aiAssistantTest;
  const data = {
    component_parts: [{ partNo: 'P-101', unit: 'pcs' }],
    component_stock: [{ partNo: 'P-101', quantity: 4, binId: 'B1' }],
    component_mappings: [],
    component_replacements: [
      { partNo: 'P-101', quantity: 1, replacementDateTime: '2026-09-01T10:00:00Z' },
    ],
    component_repair_scrap: [],
    audit: [],
    users: [],
  };
  assert(api.answerChat('P-101 current stock किती?', data).includes('Source: component_stock'));
  assert(api.answerChat('P-101', data).includes('current stock'));
  assert.strictEqual(api.canUseAudit({ role: 'admin' }), true);
  assert.strictEqual(api.canUseAudit({ role: 'store' }), false);
  assert.strictEqual(api.rootCause('P-101', data).confidence, 'Low');
});
