'use strict';
// Focused StoreTrack Batch 7 regressions for original findings 141–164.
// Static-only checks are explicitly labeled; runtime-like checks exercise production helpers/modules with controlled data.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const ai = fs.readFileSync(path.join(root, 'modules/aiAssistants.js'), 'utf8');
const predictive = fs.readFileSync(path.join(root, 'modules/predictiveHealthMonitoring.js'), 'utf8');
const performance = fs.readFileSync(path.join(root, 'modules/performanceMonitor.js'), 'utf8');
const supplier = fs.readFileSync(path.join(root, 'modules/supplierPerformanceTracking.js'), 'utf8');

function extract(source, name) {
  const start = source.indexOf(`function ${name}`);
  assert.ok(start >= 0, `${name} exists`);
  const open = source.indexOf('{', start);
  let depth = 0; let quote = null; let esc = false;
  for (let i = open; i < source.length; i += 1) {
    const c = source[i];
    if (quote) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === quote) quote = null; continue; }
    if (c === "'" || c === '"' || c === '`') { quote = c; continue; }
    if (c === '{') depth += 1;
    else if (c === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`unterminated ${name}`);
}
function staticCheck(id, fn) { test(`${id} — static source assertion`, fn); }

staticCheck('P42-F03', () => {
  const start = app.indexOf('function renderConsumption');
  const end = app.indexOf('function popConCat', start);
  const section = app.slice(start, end);
  assert.match(section, /items\.map\(/);
  assert.doesNotMatch(section, /items\.slice\(0,30\)/);
});
staticCheck('P42-F04', () => {
  assert.match(app, /function popConCat\(\)[\s\S]*escapeHTML\(String\(c\?\?''\)\)/);
  assert.match(app, /const safe=escapeHTML\(String\(c\?\?''\)\)/);
});
staticCheck('P43-F01', () => assert.match(app, /printGRN\(\$\{JSON\.stringify\(String\(g\.id\)\)\}\)/));
staticCheck('P43-F02', () => {
  const start = app.indexOf('function renderGRN');
  const end = app.indexOf('// ── Monthly Summary', start);
  const section = app.slice(start, end);
  assert.match(section, /sanitizeHTML\(String\(g\.supplierName/);
  assert.match(section, /sanitizeHTML\(String\(it\.materialName/);
  assert.match(section, /sanitizeHTML\(String\(CFG\.addr/);
});
staticCheck('P43-F03', () => { const section=app.slice(app.indexOf('function csvCell'), app.indexOf('function serializeCSVRows')); assert.match(section, /typeof value!==['\"]number/); assert.match(section, /text="'"\+text/); });
staticCheck('P43-F04', () => {
  assert.match(app, /function isValidGRNRecord\(g\)[\s\S]*Array\.isArray\(g\.items\)/);
  assert.match(app, /function validGRNRowsOrWarn\(rows, action\)/);
  assert.match(app, /validGRNRowsOrWarn\(GRN,'export'\)/);
});
staticCheck('P44-F01', () => {
  const start = app.indexOf('function renderMonthlySummary');
  const end = app.indexOf('// ──', start + 40);
  const section = app.slice(start, end);
  assert.match(section, /sanitizeHTML\(String\(CFG\.company/);
  assert.match(section, /sanitizeHTML\(String\(m\.name/);
});
staticCheck('P44-F02', () => assert.match(app, /const from=new Date\(year,month,1\);const to=new Date\(year,month\+1,1\)/));
staticCheck('P44-F03', () => assert.match(app, /inQty=inTxs\.reduce\(\(s,t\)=>s\+Number\(t\.qty\|\|0\),0\)/));
staticCheck('P45-F01', () => assert.match(app, /const itemId=t\.itemId \?\? t\.matId/));
staticCheck('P45-F02', () => {
  assert.match(app, /const low=reorderCandidates\(M,suppFlt\)/);
  assert.match(app, /reorderCandidates\(M,document\.getElementById\('po-supp-flt'\)\?\.value\|\|''\)/);
});
staticCheck('P45-F03', () => {
  const start = app.indexOf('function genPODraft');
  const end = app.indexOf('function printPO', start);
  const section = app.slice(start, end);
  assert.match(section, /po-supp-\$\{m\.id\}/);
  assert.match(section, /unitCost\|\|m\.unitPrice/);
  assert.match(section, /supplier\?\.name/);
});
staticCheck('P45-F04', () => {
  const section = app.slice(app.indexOf('function genPODraft'), app.indexOf('function printPO'));
  assert.match(section, /sanitizeHTML\(String\(co\)/);
  assert.match(section, /sanitizeHTML\(String\(m\.name/);
  assert.match(section, /sanitizeHTML\(String\(CFG\.addr/);
});
staticCheck('P45-F05', () => assert.match(app, /for\(const id of \[\.\.\.poSelected\]\)[\s\S]*poSelected\.delete\(id\)/));
staticCheck('P46-F01', () => {
  const start = app.indexOf('function renderBIDashboard');
  const end = app.indexOf('// ── Health Monitor', start);
  assert.match(app.slice(start, end), /t\.type==='OUT'&&t\.status==='confirmed'/);
  const reject = app.slice(app.indexOf('async function rejectReq'), app.indexOf('// ── Bulk Approval Helpers'));
  assert.match(reject, /linked\.status='rejected'/);
});
staticCheck('P46-F02', () => assert.match(app, /sanitizeHTML\(String\(mat \? mat\.name : itemId\)\)/));
staticCheck('P47-F01', () => {
  assert.match(ai, /const historicalConsumption = data\.component_historical_consumption/);
  assert.match(ai, /\[\.\.\.replacements, \.\.\.repairs, \.\.\.historicalRows\]/);
});
staticCheck('P47-F02', () => {
  const section = ai.slice(ai.indexOf('function auditAnalysis'), ai.indexOf('function renderChatAnswer'));
  assert.doesNotMatch(section, /findings\.slice\(0,\s*80\)/);
});
staticCheck('P48-F01', () => {
  assert.match(app, /window\.eventBus\.on\('PERFORMANCE_METRIC'/);
  assert.match(app, /predictiveHealthMonitoring\.recordMetric\(metricName, metricValue/);
});
staticCheck('P48-F02', () => assert.match(app, /const metricsList = document\.getElementById\('health-metrics-list'\)/));
staticCheck('P48-F03', () => assert.match(app, /healthMonitorRefreshTimer=setInterval/));
staticCheck('P48-F04', () => assert.match(app, /const predictiveAlerts = .*predictiveHealthMonitoring\.getAlerts/));
staticCheck('P49-F01', () => {
  assert.match(supplier, /const supplierReturns = transactions\.filter/);
  assert.match(supplier, /t\.type === 'OUT'/);
  assert.match(supplier, /const promised = t\.promisedDate \|\| t\.expectedDate/);
});
staticCheck('P50-F01', () => {
  const start = app.indexOf('async function approveReq');
  const end = app.indexOf('async function rejectReq', start);
  const section = app.slice(start, end);
  assert.match(section, /if\(a\.status!==\'pending\'\)/);
  assert.ok(section.indexOf("a.status!=='pending'") < section.indexOf('window.atomicReadModifyWrite'));
  assert.match(section, /freshApproval\.status!=='pending'[\s\S]*const updated=\{\.\.\.current,stock:Number\(current\.stock\)-qty/);
  assert.match(section, /validate:record=>record\?\.status==='pending'/);
});

test('P42-F02 — consumption window covers exactly N calendar months', () => {
  const ctx = {};
  vm.runInNewContext(extract(app, 'consumptionWindow'), ctx);
  const result = ctx.consumptionWindow(6, new Date('2026-10-09T12:00:00Z'));
  assert.deepEqual(Array.from(result.labels), ['2026-05','2026-06','2026-07','2026-08','2026-09','2026-10']);
  assert.equal(result.start.getDate(), 1);
});
test('P43-F03 — CSV helper neutralizes formula-leading values at serialization', () => {
  const ctx = {};
  vm.runInNewContext(`${extract(app, 'csvCell')}\n${extract(app, 'serializeCSVRows')}\nthis.out=serializeCSVRows([['x'],['=1+1'],['+cmd'],['-cmd'],['@cmd'],['a,"b']]);`, ctx);
  assert.match(ctx.out, /'=?1\+1/);
  assert.match(ctx.out, /'\+cmd/);
  assert.match(ctx.out, /'\-cmd/);
  assert.match(ctx.out, /'@cmd/);
  assert.match(ctx.out, /a,""b/);
});
test('P43-F04 — GRN validator rejects malformed rows without dereferencing items', () => {
  const ctx = { console: { warn() {} }, toast() {} };
  vm.runInNewContext(`${extract(app, 'isValidGRNRecord')}\n${extract(app, 'validGRNRowsOrWarn')}\nthis.out=validGRNRowsOrWarn([{id:'ok',items:[],grnNo:'G',time:'2026-01-01'}, {id:'bad',items:null}], 'render');`, ctx);
  assert.equal(ctx.out.length, 1);
  assert.equal(ctx.out[0].id, 'ok');
});
test('P45-F02 — supplier filter returns only matching low-stock material', () => {
  const ctx = {};
  vm.runInNewContext(`${extract(app, 'numericStockValue')}\n${extract(app, 'isLowStockMaterial')}\n${extract(app, 'materialSupplierId')}\n${extract(app, 'lowStockForSupplier')}\nthis.out=lowStockForSupplier([{id:'a',stock:0,lowAlert:2,supplierId:'S1'},{id:'b',stock:0,lowAlert:2,supplierId:'S2'}],'S1');`, ctx);
  assert.equal(Array.from(ctx.out, x => x.id).join(','), 'a');
});
test('P47-F01 — root cause includes historical consumption records and quantities', () => {
  const ctx = { window: {} };
  vm.runInNewContext(`${ai}\nthis.out=window.aiAssistantTest.rootCause('P-1',{component_parts:[],component_replacements:[],component_repair_scrap:[],component_historical_consumption:[{partNo:'P-1',quantity:'3',date:'2026-01-02',stationNo:'S1'}]});`, ctx);
  assert.equal(ctx.out.records, 1);
  assert.equal(ctx.out.replacementQty, 3);
});
test('P47-F02 — audit analysis returns all generated findings, not a hidden 80-row slice', () => {
  const ctx = { window: {} };
  vm.runInNewContext(`${ai}\nconst logs=Array.from({length:90},(_,i)=>({action:'approve',details:'x',time:'2026-01-01',userName:'u'+i})); this.out=window.aiAssistantTest.auditAnalysis({audit:logs,component_audit_log:[],users:[]});`, ctx);
  assert.ok(ctx.out.findings.length >= 90);
});
test('P48-F01 — performance metric emitted through EventBus reaches predictive health module', () => {
  const listeners = {};
  const eventBus = { on(name, fn) { listeners[name] = fn; return () => {}; }, emit(name, data) { listeners[name]?.(data); } };
  const ctx = { window: { eventBus }, setInterval: () => 1, clearInterval() {}, requestAnimationFrame: () => {}, performance: { now: () => 0 }, console };
  vm.runInNewContext(`${predictive}\n${performance}\nthis.predictive=new PredictiveHealthMonitoring(); this.monitor=window.performanceMonitor;`, ctx);
  ctx.eventBus = eventBus;
  eventBus.on('PERFORMANCE_METRIC', metric => ctx.predictive.recordMetric(metric.name, metric.value, { source: 'performanceMonitor', unit: metric.unit }));
  ctx.monitor.recordMetric({name:'probe',value:42,unit:'ms',category:'localSave'});
  const recorded = ctx.predictive.healthMetrics.get('localSave');
  assert.equal(recorded.values.at(-1).value, 42);
  assert.equal(recorded.values.at(-1).source, 'performanceMonitor');
  assert.equal(recorded.values.at(-1).unit, 'ms');
});
test('P49-F01 — supplier metric counts OUT returns separately from IN orders', async () => {
  const now = new Date(); const transactionDate = new Date(now.getFullYear(), now.getMonth(), 3).toISOString();
  const ctx = { console, setInterval: () => 1, clearInterval() {}, Date, Math, window: {}, gAll: async store => store === 'supplier_items' ? [{supplierId:'S1',barcode:'B'}] : store === 'transactions' ? [{type:'IN',barcode:'B',time:transactionDate,promisedDate:transactionDate,qty:1},{type:'OUT',barcode:'B',time:transactionDate,returned:true,qty:1}] : [], dPut: async () => {} };
  vm.runInNewContext(`${supplier}\nthis.Manager=SupplierPerformanceTrackingManager;`, ctx);
  const manager = vm.runInContext('Object.create(Manager.prototype)', ctx);
  manager.metrics = new Map();
  const metric = await manager.calculateMetricsForSupplier('S1');
  assert.equal(metric.totalOrders, 1);
  assert.equal(metric.returns, 1);
  assert.equal(metric.qualityRate, 0);
});
test('P50-F01 — approval source guard precedes stock mutation', () => {
  const start = app.indexOf('async function approveReq');
  const end = app.indexOf('async function rejectReq', start);
  const section = app.slice(start, end);
  assert.ok(section.indexOf("a.status!=='pending'") < section.indexOf('window.atomicReadModifyWrite'));
  assert.match(section, /freshApproval\.status!=='pending'[\s\S]*const updated=\{\.\.\.current,stock:Number\(current\.stock\)-qty/);
});
