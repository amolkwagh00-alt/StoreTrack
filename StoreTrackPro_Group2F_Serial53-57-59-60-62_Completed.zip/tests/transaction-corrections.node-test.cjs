'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = process.env.STORETRACK_ROOT || path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const start = app.indexOf('async function correctTransaction(');
const end = app.indexOf('\nfunction renderHist()', start);
assert.ok(start >= 0 && end > start, 'transaction correction operation exists');

async function run(original, material, alreadyCorrected = false) {
  let committed = null;
  const context = {
    T: [original, ...(alreadyCorrected ? [{ id: 'prior-correction', correctionOf: original.id }] : [])],
    M: [material],
    cu: { username: 'auditor', name: 'Auditor' },
    window: {
      prompt: () => 'Recorded correction reason',
      atomicReadModifyWrite: async (store, key, derive, options) => {
        assert.equal(store, 'materials');
        assert.equal(key, material.id);
        assert.equal(options.guards.length, 2);
        const guards = { sourceTransaction: original, existingCorrection: null };
        const outcome = derive(material, guards);
        committed = outcome;
        return outcome.result;
      }
    },
    canRoleAction: () => true,
    sanitizeText: s => String(s),
    toast: (msg, type) => { context.lastToast = { msg, type }; },
    gAll: async store => store === 'materials' ? [committed.record] : [original, committed.writes[0].obj],
    addAudit: (...args) => { context.audit = args; },
    renderHist: () => {},
    generateUUID: () => 'unused'
  };
  vm.runInNewContext(app.slice(start, end), context);
  await context.correctTransaction(original.id);
  return { context, committed };
}

(async () => {
  const originalIn = { id: 'tx-in', itemId: 'mat-1', itemName: 'Bolt', barcode: 'B1', unit: 'ea', type: 'IN', qty: 5, status: 'confirmed' };
  const inResult = await run(originalIn, { id: 'mat-1', stock: 10 });
  assert.equal(inResult.committed.record.stock, 5, 'correcting IN subtracts its quantity');
  assert.equal(inResult.committed.writes[0].obj.type, 'OUT');
  assert.equal(inResult.committed.writes[0].obj.correctionOf, 'tx-in');
  assert.equal(inResult.committed.writes[0].obj.correctionReason, 'Recorded correction reason');
  assert.equal(originalIn.qty, 5, 'original remains unchanged');
  assert.ok(inResult.context.audit, 'correction is audited');

  const originalOut = { id: 'tx-out', itemId: 'mat-1', itemName: 'Bolt', barcode: 'B1', unit: 'ea', type: 'OUT', qty: 3, status: 'confirmed' };
  const outResult = await run(originalOut, { id: 'mat-1', stock: 4 });
  assert.equal(outResult.committed.record.stock, 7, 'correcting OUT restores its quantity');
  assert.equal(outResult.committed.writes[0].obj.type, 'IN');

  const insufficient = await run(originalIn, { id: 'mat-1', stock: 2 });
  assert.equal(insufficient.committed, null, 'negative correction does not commit');
  assert.match(insufficient.context.lastToast.msg, /negative|not saved/i);

  const duplicate = await run(originalIn, { id: 'mat-1', stock: 10 }, true);
  assert.equal(duplicate.committed, null, 'duplicate correction prevented');
  assert.match(duplicate.context.lastToast.msg, /already has a correction/i);
  assert.match(app, /correctTransaction\(\$\{JSON\.stringify\(String\(t\.id\)\)\}\)/, 'history action uses quoted IDs');
  console.log('transaction corrections: all regression checks passed');
})().catch(error => { console.error(error); process.exitCode = 1; });
