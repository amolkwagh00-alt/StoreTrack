#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');
const serviceWorker = read('service-worker.js');
const backgroundSync = read('modules/backgroundSync.js');
const database = read('modules/database.js');

const checks = [
  [
    'service worker avoids unsupported file-scheme cache entries',
    /file:/.test(serviceWorker) && /skip|unsupported|file scheme/i.test(serviceWorker),
  ],
  [
    'background sync tolerates unsupported registration',
    /file:/.test(backgroundSync) && /unsupported|catch|return/i.test(backgroundSync),
  ],
  [
    'IndexedDB index migration is idempotent',
    /indexNames/.test(database) && /contains|includes/.test(database),
  ],
  ['database initialization is present', /function initDB|async function initDB/.test(database)],
];

const failures = checks.filter(([, ok]) => !ok);
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
}
if (failures.length > 0) {
  process.exitCode = 1;
}
