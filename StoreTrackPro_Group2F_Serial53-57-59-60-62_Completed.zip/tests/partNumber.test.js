const {
  normalizePartNo,
  partKey,
  samePartNo,
  hasDuplicatePartNo,
  displayPartNo,
} = require('../core/partNumber');
const analytics = require('../modules/shankConsumptionAnalytics');

describe('leading-zero Part Number variants', () => {
  test('normalizes numeric segments and matches the confirmed variants', () => {
    expect(normalizePartNo('07-526/98')).toBe('7-526/98');
    expect(normalizePartNo('07-0526/98')).toBe('7-526/98');
    expect(samePartNo('07-526/98', '07-0526/98')).toBe(true);
  });

  test('preserves long numeric identifiers without unsafe-integer collisions', () => {
    expect(normalizePartNo('0009007199254740992-0007')).toBe('9007199254740992-7');
    expect(samePartNo('0009007199254740992', '9007199254740992')).toBe(true);
    expect(samePartNo('9007199254740992', '9007199254740993')).toBe(false);
  });

  test('does not merge a genuinely different part', () => {
    expect(samePartNo('07-526/98', '07-526/99')).toBe(false);
    expect(samePartNo('07-526/98', '07-5268/98')).toBe(false);
  });

  test('rejects duplicate Part No. variants but permits the current record during edit', () => {
    const materials = [
      { id: 1, hsn: '07-526/98' },
      { id: 2, hsn: '08-100/01' },
    ];
    expect(hasDuplicatePartNo('07-0526/98', materials, '')).toBe(true);
    expect(hasDuplicatePartNo('07-0526/98', materials, 1)).toBe(false);
    expect(hasDuplicatePartNo('09-999/01', materials, '')).toBe(false);
  });

  test('pools stock and consumption under one logical part', () => {
    const forecast = analytics.calculateForecast({
      today: '2026-09-03',
      periodDays: 90,
      parts: [
        { partNo: '07-526/98', minimumStock: 0 },
        { partNo: '07-0526/98', minimumStock: 0 },
      ],
      stock: [
        { partNo: '07-526/98', quantity: 2 },
        { partNo: '07-0526/98', quantity: 3 },
      ],
      replacements: [],
    });
    expect(forecast).toHaveLength(1);
    expect(forecast[0].currentStock).toBe(5);
    expect(forecast[0].partNo).toContain('07-526/98');
    expect(forecast[0].partNo).toContain('07-0526/98');
  });

  test('combined display preserves both known formats', () => {
    expect(displayPartNo(['07-526/98', '07-0526/98'])).toBe('07-526/98 / 07-0526/98');
    expect(partKey('07-526/98')).toBe(partKey('07-0526/98'));
  });
});
