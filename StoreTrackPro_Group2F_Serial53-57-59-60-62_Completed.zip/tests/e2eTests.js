/**
 * Enterprise E2E Testing Framework
 * End-to-end testing for StoreTrack Pro using Playwright
 */

class E2ETestSuite {
  constructor(name) {
    this.name = name;
    this.tests = [];
    this.beforeAll = null;
    this.afterAll = null;
    this.beforeEach = null;
    this.afterEach = null;
  }

  /**
   * Add E2E test
   * @param {string} name - Test name
   * @param {Function} fn - Test function
   */
  test(name, fn) {
    this.tests.push({ name, fn, status: 'pending' });
  }

  /**
   * Setup before all tests
   * @param {Function} fn - Setup function
   */
  beforeAll(fn) {
    this.beforeAll = fn;
  }

  /**
   * Teardown after all tests
   * @param {Function} fn - Teardown function
   */
  afterAll(fn) {
    this.afterAll = fn;
  }

  /**
   * Setup before each test
   * @param {Function} fn - Setup function
   */
  beforeEach(fn) {
    this.beforeEach = fn;
  }

  /**
   * Teardown after each test
   * @param {Function} fn - Teardown function
   */
  afterEach(fn) {
    this.afterEach = fn;
  }

  /**
   * Run E2E tests
   * @param {object} browser - Browser instance
   * @returns {Promise<object>} Test results
   */
  async run(browser) {
    const results = {
      suite: this.name,
      total: this.tests.length,
      passed: 0,
      failed: 0,
      skipped: 0,
      duration: 0,
      tests: []
    };

    const startTime = Date.now();

    try {
      if (this.beforeAll) {
        await this.beforeAll(browser);
      }

      for (const test of this.tests) {
        const testResult = {
          name: test.name,
          status: 'pending',
          duration: 0,
          error: null,
          screenshot: null
        };

        const testStartTime = Date.now();

        try {
          if (this.beforeEach) {
            await this.beforeEach(browser);
          }

          await test.fn(browser);

          testResult.status = 'passed';
          results.passed++;
          test.status = 'passed';
        } catch (err) {
          testResult.status = 'failed';
          testResult.error = err.message;
          results.failed++;
          test.status = 'failed';

          // Take screenshot on failure
          try {
            const page = await browser.newPage();
            testResult.screenshot = await page.screenshot({ encoding: 'base64' });
            await page.close();
          } catch (screenshotErr) {
            console.error('Failed to take screenshot:', screenshotErr);
          }
        } finally {
          const testDuration = Date.now() - testStartTime;
          testResult.duration = testDuration;

          if (this.afterEach) {
            try {
              await this.afterEach(browser);
            } catch (err) {
              console.error('Error in afterEach:', err);
            }
          }
        }

        results.tests.push(testResult);
      }

      if (this.afterAll) {
        await this.afterAll(browser);
      }
    } catch (err) {
      console.error('Error running E2E test suite:', err);
    }

    results.duration = Date.now() - startTime;
    return results;
  }
}

class E2ETestRunner {
  constructor() {
    this.suites = new Map();
    this.results = null;
    this.browser = null;
  }

  /**
   * Create E2E test suite
   * @param {string} name - Suite name
   * @returns {E2ETestSuite} Test suite
   */
  createSuite(name) {
    const suite = new E2ETestSuite(name);
    this.suites.set(name, suite);
    return suite;
  }

  /**
   * Get suite
   * @param {string} name - Suite name
   * @returns {E2ETestSuite} Test suite
   */
  getSuite(name) {
    return this.suites.get(name);
  }

  /**
   * Initialize browser
   * @param {object} options - Browser options
   */
  async initBrowser(options = {}) {
    try {
      const { chromium } = require('playwright');
      this.browser = await chromium.launch({
        headless: options.headless !== false,
        slowMo: options.slowMo || 0
      });
    } catch (err) {
      console.error('Failed to initialize browser:', err);
      console.log('Playwright not available, using mock browser');
      this.browser = this.createMockBrowser();
    }
  }

  /**
   * Create mock browser for testing without Playwright
   * @returns {object} Mock browser
   */
  createMockBrowser() {
    return {
      newPage: async () => ({
        goto: async (url) => console.log(`Navigating to: ${url}`),
        click: async (selector) => console.log(`Clicking: ${selector}`),
        fill: async (selector, value) => console.log(`Filling ${selector} with: ${value}`),
        waitForSelector: async (selector) => console.log(`Waiting for: ${selector}`),
        screenshot: async (options) => 'mock-screenshot',
        close: async () => console.log('Closing page')
      }),
      close: async () => console.log('Closing browser')
    };
  }

  /**
   * Close browser
   */
  async closeBrowser() {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
    }
  }

  /**
   * Run all E2E suites
   * @returns {Promise<object>} Combined results
   */
  async runAll() {
    if (!this.browser) {
      await this.initBrowser();
    }

    const combinedResults = {
      totalSuites: this.suites.size,
      totalTests: 0,
      totalPassed: 0,
      totalFailed: 0,
      totalSkipped: 0,
      totalDuration: 0,
      suites: []
    };

    for (const [name, suite] of this.suites) {
      const results = await suite.run(this.browser);
      combinedResults.suites.push(results);
      combinedResults.totalTests += results.total;
      combinedResults.totalPassed += results.passed;
      combinedResults.totalFailed += results.failed;
      combinedResults.totalSkipped += results.skipped;
      combinedResults.totalDuration += results.duration;
    }

    this.results = combinedResults;
    await this.closeBrowser();
    return combinedResults;
  }

  /**
   * Run specific suite
   * @param {string} name - Suite name
   * @returns {Promise<object>} Suite results
   */
  async runSuite(name) {
    if (!this.browser) {
      await this.initBrowser();
    }

    const suite = this.suites.get(name);
    if (!suite) {
      throw new Error(`Suite ${name} not found`);
    }

    const results = await suite.run(this.browser);
    await this.closeBrowser();
    return results;
  }

  /**
   * Get results
   * @returns {object} Test results
   */
  getResults() {
    return this.results;
  }

  /**
   * Print results to console
   */
  printResults() {
    if (!this.results) {
      console.log('No E2E test results available');
      return;
    }

    console.log('\n=== E2E Test Results ===');
    console.log(`Total Suites: ${this.results.totalSuites}`);
    console.log(`Total Tests: ${this.results.totalTests}`);
    console.log(`Passed: ${this.results.totalPassed}`);
    console.log(`Failed: ${this.results.totalFailed}`);
    console.log(`Skipped: ${this.results.totalSkipped}`);
    console.log(`Duration: ${this.results.totalDuration}ms`);
    console.log(`Success Rate: ${((this.results.totalPassed / this.results.totalTests) * 100).toFixed(2)}%`);

    if (this.results.totalFailed > 0) {
      console.log('\n=== Failed Tests ===');
      for (const suite of this.results.suites) {
        for (const test of suite.tests) {
          if (test.status === 'failed') {
            console.log(`[${suite.suite}] ${test.name}: ${test.error}`);
            if (test.screenshot) {
              console.log(`  Screenshot available`);
            }
          }
        }
      }
    }

    console.log('=====================\n');
  }
}

// Global E2E test runner instance
const e2eTestRunner = new E2ETestRunner();

// Create default E2E test suites
const createDefaultE2ESuites = () => {
  // Login Flow Tests
  const loginSuite = e2eTestRunner.createSuite('Login Flow');

  loginSuite.beforeAll(async (browser) => {
    console.log('Setting up login flow test...');
  });

  loginSuite.afterAll(async (browser) => {
    console.log('Tearing down login flow test...');
  });

  loginSuite.test('Navigate to login page', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/login');
    await page.waitForSelector('#login-form');
    await page.close();
  });

  loginSuite.test('Enter credentials', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/login');
    await page.fill('#username', 'admin');
    await page.fill('#password', 'password');
    await page.close();
  });

  loginSuite.test('Submit login form', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/login');
    await page.fill('#username', 'admin');
    await page.fill('#password', 'password');
    await page.click('#login-button');
    await page.waitForSelector('#dashboard');
    await page.close();
  });

  // Dashboard Flow Tests
  const dashboardSuite = e2eTestRunner.createSuite('Dashboard Flow');

  dashboardSuite.beforeAll(async (browser) => {
    console.log('Setting up dashboard flow test...');
  });

  dashboardSuite.afterAll(async (browser) => {
    console.log('Tearing down dashboard flow test...');
  });

  dashboardSuite.test('Navigate to dashboard', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/dashboard');
    await page.waitForSelector('#dashboard-container');
    await page.close();
  });

  dashboardSuite.test('View KPI widgets', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/dashboard');
    await page.waitForSelector('.kpi-widget');
    const widgets = await page.$$('.kpi-widget');
    console.log(`Found ${widgets.length} KPI widgets`);
    await page.close();
  });

  dashboardSuite.test('Refresh dashboard data', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/dashboard');
    await page.click('#refresh-button');
    await page.waitForSelector('.loading-spinner', { state: 'hidden' });
    await page.close();
  });

  // Inventory Flow Tests
  const inventorySuite = e2eTestRunner.createSuite('Inventory Flow');

  inventorySuite.beforeAll(async (browser) => {
    console.log('Setting up inventory flow test...');
  });

  inventorySuite.afterAll(async (browser) => {
    console.log('Tearing down inventory flow test...');
  });

  inventorySuite.test('Navigate to inventory list', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/inventory');
    await page.waitForSelector('#inventory-table');
    await page.close();
  });

  inventorySuite.test('Search inventory item', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/inventory');
    await page.fill('#search-input', 'Test Item');
    await page.click('#search-button');
    await page.waitForSelector('.inventory-row');
    await page.close();
  });

  inventorySuite.test('Add new inventory item', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/inventory');
    await page.click('#add-item-button');
    await page.waitForSelector('#item-form');
    await page.fill('#item-name', 'New Item');
    await page.fill('#item-barcode', '1234567890');
    await page.click('#save-button');
    await page.waitForSelector('.success-message');
    await page.close();
  });

  // Scanner Flow Tests
  const scannerSuite = e2eTestRunner.createSuite('Scanner Flow');

  scannerSuite.beforeAll(async (browser) => {
    console.log('Setting up scanner flow test...');
  });

  scannerSuite.afterAll(async (browser) => {
    console.log('Tearing down scanner flow test...');
  });

  scannerSuite.test('Navigate to scanner page', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/scanner');
    await page.waitForSelector('#scanner-container');
    await page.close();
  });

  scannerSuite.test('Enable scanner', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/scanner');
    await page.click('#enable-scanner-button');
    await page.waitForSelector('.scanner-active');
    await page.close();
  });

  scannerSuite.test('Simulate barcode scan', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/scanner');
    await page.click('#enable-scanner-button');
    // Simulate barcode input
    await page.evaluate(() => {
      const event = new KeyboardEvent('keydown', { key: 'Enter' });
      document.dispatchEvent(event);
    });
    await page.close();
  });

  // Report Flow Tests
  const reportSuite = e2eTestRunner.createSuite('Report Flow');

  reportSuite.beforeAll(async (browser) => {
    console.log('Setting up report flow test...');
  });

  reportSuite.afterAll(async (browser) => {
    console.log('Tearing down report flow test...');
  });

  reportSuite.test('Navigate to reports page', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/reports');
    await page.waitForSelector('#reports-container');
    await page.close();
  });

  reportSuite.test('Select report template', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/reports');
    await page.click('#report-template-dropdown');
    await page.click('#inventory-summary-template');
    await page.waitForSelector('#report-preview');
    await page.close();
  });

  reportSuite.test('Generate and export report', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/reports');
    await page.click('#generate-report-button');
    await page.waitForSelector('.report-generated');
    await page.click('#export-pdf-button');
    await page.close();
  });

  // Settings Flow Tests
  const settingsSuite = e2eTestRunner.createSuite('Settings Flow');

  settingsSuite.beforeAll(async (browser) => {
    console.log('Setting up settings flow test...');
  });

  settingsSuite.afterAll(async (browser) => {
    console.log('Tearing down settings flow test...');
  });

  settingsSuite.test('Navigate to settings page', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/settings');
    await page.waitForSelector('#settings-container');
    await page.close();
  });

  settingsSuite.test('Change theme', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/settings');
    await page.click('#theme-dropdown');
    await page.click('#dark-theme-option');
    await page.waitForSelector('.dark-mode');
    await page.close();
  });

  settingsSuite.test('Update user profile', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/settings');
    await page.click('#profile-tab');
    await page.fill('#user-name', 'Updated Name');
    await page.click('#save-profile-button');
    await page.waitForSelector('.success-message');
    await page.close();
  });

  // Logout Flow Tests
  const logoutSuite = e2eTestRunner.createSuite('Logout Flow');

  logoutSuite.beforeAll(async (browser) => {
    console.log('Setting up logout flow test...');
  });

  logoutSuite.afterAll(async (browser) => {
    console.log('Tearing down logout flow test...');
  });

  logoutSuite.test('Click logout button', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/dashboard');
    await page.click('#logout-button');
    await page.waitForSelector('#login-form');
    await page.close();
  });

  logoutSuite.test('Verify session cleared', async (browser) => {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000/dashboard');
    await page.click('#logout-button');
    await page.goto('http://localhost:3000/dashboard');
    await page.waitForSelector('#login-form');
    await page.close();
  });
};

// Export for use
if (typeof window !== 'undefined') {
  window.E2ETestRunner = E2ETestRunner;
  window.e2eTestRunner = e2eTestRunner;
  window.E2ETestSuite = E2ETestSuite;
  window.createDefaultE2ESuites = createDefaultE2ESuites;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { 
    E2ETestRunner, 
    e2eTestRunner, 
    E2ETestSuite,
    createDefaultE2ESuites 
  };
}
