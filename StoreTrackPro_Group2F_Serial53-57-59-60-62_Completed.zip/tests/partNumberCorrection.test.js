const fs = require('fs');
const path = require('path');
const vm = require('vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'componentManagement.js'), 'utf8');
const helperStart = source.indexOf('function replacePartNumberList(');
const helperEnd = source.indexOf('async function correctPartNumberEverywhere(', helperStart);
const helperSource = source.slice(helperStart, helperEnd);

function createPlan(oldPartNo, newPartNo, overrides = {}) {
  let id = 0;
  const context = {
    STORES: {
      parts: 'component_parts', mappings: 'component_mappings', stock: 'component_stock',
      tx: 'component_stock_transactions', audit: 'component_audit_log', bins: 'component_bins',
      partConfigs: 'component_part_forecast_configs', orders: 'component_procurement_orders',
    },
    vendorPartNo: value => value == null ? '' : String(value),
    validMappedPartNo: value => Boolean(String(value || '').trim()) && !/^n\/?a$/i.test(String(value || '').trim()),
    partKey: value => String(value || '').trim().replace(/\s+/g, '').toLowerCase(),
    samePartNo: (a, b) => Boolean(String(a || '').trim()) && String(a || '').trim().replace(/\s+/g, '').toLowerCase() === String(b || '').trim().replace(/\s+/g, '').toLowerCase(),
    mappingIdentity: (station, gun, position) => `${String(station || '').toLowerCase()}\u001f${String(gun || '')}\u001f${String(position || '')}`,
    statusFor: (quantity, minimum) => Number(quantity) <= 0 ? 'ZERO STOCK' : Number(quantity) < Number(minimum || 0) ? 'LOW STOCK' : 'OK STOCK',
    nowIso: () => '2026-11-06T13:00:00.000Z',
    uid: prefix => `${prefix}-${++id}`,
    user: () => ({ id: 'test-user', username: 'tester' }),
    state: {
      parts: [], mappings: [], stock: [], gunRows: [], bins: [], partConfigs: [], orders: [],
      ...overrides,
    },
  };
  const script = `${helperSource}\nJSON.stringify(buildPartNumberCorrectionPlan(${JSON.stringify(oldPartNo)}, ${JSON.stringify(newPartNo)}, ${JSON.stringify(overrides)}));`;
  return JSON.parse(vm.runInNewContext(script, context));
}

describe('Part Number correction migration', () => {
  test('updates live mappings, retires the old Part Master entry, and preserves/merges stock per bin', () => {
    const mapping = {
      id: 'map-1', stationNo: 'UB 40', gunReferenceNo: 'UB40-R6', position: 'Moving Holder', partNo: '5367',
      boldParts: { movingHolder: ['5367'] },
      partOptions: { movingHolder: { original: '5367', alternatives: ['05-4836'], candidates: ['5367', '05-4836'] } },
      sourceValues: ['05-4836/5367'],
    };
    const result = createPlan('5367', '05-5367', {
      parts: [
        { id: 'part-old', partNo: '5367', componentType: 'Holder', description: 'Holder 5367', active: true, candidateOnly: true, minimumStock: 0 },
        { id: 'part-new', partNo: '05-5367', componentType: 'Holder', description: 'Correct Holder', active: true, minimumStock: 3 },
      ],
      mappings: [mapping],
      stock: [
        { id: 'old-bin-1', partNo: '5367', binId: 'UB40-BIN01', quantity: 3, minimumStock: 2 },
        { id: 'new-bin-1', partNo: '05-5367', binId: 'UB40-BIN01', quantity: 4, minimumStock: 5 },
        { id: 'old-bin-2', partNo: '5367', binId: 'UB40-BIN02', quantity: 1, minimumStock: 1 },
      ],
      gunRows: [{ id: 'gun-row-1', partOptions: { movingHolder: { original: '5367', alternatives: [], candidates: ['5367'] } }, boldParts: { movingHolder: ['5367'] }, sourceValues: ['05-4836/5367'] }],
      bins: [], partConfigs: [], orders: [],
    });

    const writes = result.writes;
    const liveMapping = writes.find(write => write.store === 'component_mappings')?.obj;
    expect(liveMapping.partNo).toBe('05-5367');
    expect(liveMapping.partOptions.movingHolder).toEqual({ original: '05-5367', alternatives: ['05-4836'], candidates: ['05-5367', '05-4836'] });
    expect(liveMapping.boldParts.movingHolder).toEqual(['05-5367']);
    expect(liveMapping.sourceValues).toEqual(['05-4836/5367']); // Raw imported source is preserved for provenance.

    const parts = writes.filter(write => write.store === 'component_parts').map(write => write.obj);
    expect(parts.find(part => part.id === 'part-old')).toMatchObject({ partNo: '5367', active: false, supersededBy: '05-5367' });
    expect(parts.find(part => part.id === 'part-new').minimumStock).toBe(3);

    const stockPuts = writes.filter(write => write.store === 'component_stock').map(write => write.obj);
    expect(stockPuts.find(row => row.id === 'new-bin-1')).toMatchObject({ partNo: '05-5367', binId: 'UB40-BIN01', quantity: 7, minimumStock: 5 });
    expect(stockPuts.find(row => row.id === 'old-bin-2')).toMatchObject({ partNo: '05-5367', binId: 'UB40-BIN02', quantity: 1 });
    expect(writes).toContainEqual({ store: 'component_stock', operation: 'delete', key: 'old-bin-1' });

    const tx = writes.filter(write => write.store === 'component_stock_transactions').map(write => write.obj);
    expect(tx).toHaveLength(4);
    expect(tx.filter(row => row.direction === 'OUT').reduce((sum, row) => sum + row.quantity, 0)).toBe(4);
    expect(tx.filter(row => row.direction === 'IN').reduce((sum, row) => sum + row.quantity, 0)).toBe(4);
    expect(tx.every(row => row.type === 'Part Number Correction Transfer')).toBe(true);
    expect(result.summary).toMatchObject({ affectedMappings: 1, stockQuantityMoved: 4, oldPartNo: '5367', newPartNo: '05-5367' });
    expect(writes.find(write => write.store === 'component_mapping_revisions')?.obj.oldValue.partNo).toBe('5367');
    expect(writes.find(write => write.store === 'component_mapping_revisions')?.obj.newValue.partNo).toBe('05-5367');
    expect(writes.find(write => write.store === 'component_audit_log')?.obj.action).toBe('PART_NUMBER_CORRECTION');
  });

  test('rejects a migration that would create duplicate Station/Gun/Position mappings', () => {
    expect(() => createPlan('5367', '05-5367', {
      parts: [{ id: 'old', partNo: '5367', componentType: 'Holder' }, { id: 'new', partNo: '05-5367', componentType: 'Holder' }],
      mappings: [
        { id: 'old-map', stationNo: 'UB 40', gunReferenceNo: 'R6', position: 'Moving Holder', partNo: '5367' },
        { id: 'new-map', stationNo: 'UB 40', gunReferenceNo: 'R6', position: 'Moving Holder', partNo: '05-5367' },
      ], stock: [], gunRows: [], bins: [], partConfigs: [], orders: [],
    })).toThrow('Part No. correction would create duplicate mapping');
  });

  test('rejects different Component Types instead of merging them', () => {
    expect(() => createPlan('5367', '05-5367', {
      parts: [{ id: 'old', partNo: '5367', componentType: 'Holder' }, { id: 'new', partNo: '05-5367', componentType: 'Adaptor' }],
      mappings: [], stock: [], gunRows: [], bins: [], partConfigs: [], orders: [],
    })).toThrow('Cannot merge Part Numbers with different Component Types');
  });

  test('active Parts and Types of Shank exclude a superseded Part No. while inactive details remain filterable', () => {
    expect(source).toContain("state.parts.filter(p => p.active !== false && validMappedPartNo(p.partNo)).sort");
    expect(source).toContain("if (activity && !activity.value) { activity.value = 'active'; }");
    expect(source).toContain("['cm-part-type-filter', 'cm-part-active-filter', 'cm-part-stock-filter', 'cm-part-critical-filter', 'cm-part-sort']");
    expect(source).toContain("id === 'cm-part-active-filter' ? 'active' : ''");
    expect(source).toContain("state.parts.filter(p => p.active !== false).map(p => p.partNo)");
    expect(source).toContain('correctPartNumberEverywhere(old.partNo, proposed.partNo');
  });
});
