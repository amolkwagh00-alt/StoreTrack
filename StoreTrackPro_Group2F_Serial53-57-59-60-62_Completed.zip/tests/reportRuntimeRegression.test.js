const fs = require('fs');
const path = require('path');

describe('Component Reports runtime regression', () => {
  test('defines Gun reconciliation markup before using it in the report shell', () => {
    const source = fs.readFileSync(
      path.join(__dirname, '..', 'modules', 'componentManagement.js'),
      'utf8',
    );
    const reportsStart = source.indexOf('function reports()');
    const reportsSource = source.slice(
      reportsStart,
      source.indexOf('\n  function exportReport()', reportsStart),
    );
    const declaration = reportsSource.indexOf('const gunReconHtml =');
    const use = reportsSource.indexOf('${gunReconHtml}');
    expect(reportsStart).toBeGreaterThanOrEqual(0);
    expect(declaration).toBeGreaterThanOrEqual(0);
    expect(use).toBeGreaterThan(declaration);
  });
});
