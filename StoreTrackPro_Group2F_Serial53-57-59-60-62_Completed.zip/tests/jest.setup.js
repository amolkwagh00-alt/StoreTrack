// Polyfills real IndexedDB behaviour inside Jest's jsdom environment
// (jsdom itself does not implement IndexedDB — see modules/database.js tests).
require('fake-indexeddb/auto');

// jsdom's `crypto` global has no `.subtle` (SubtleCrypto) — modules/encryption.js
// needs real WebCrypto (PBKDF2 + AES-GCM). Node's built-in webcrypto is a full,
// real implementation, so this isn't a mock — it's the same algorithm the app
// uses in the browser/Electron renderer.
const { TextEncoder, TextDecoder } = require('util');
if (typeof globalThis.TextEncoder === 'undefined') {
  globalThis.TextEncoder = TextEncoder;
}
if (typeof globalThis.TextDecoder === 'undefined') {
  globalThis.TextDecoder = TextDecoder;
}

const nodeCrypto = require('crypto');
if (typeof globalThis.crypto === 'undefined' || typeof globalThis.crypto.subtle === 'undefined') {
  Object.defineProperty(globalThis, 'crypto', { value: nodeCrypto.webcrypto, configurable: true });
}

// jsdom doesn't expose the global structuredClone() that fake-indexeddb relies on
// internally to store/retrieve records (Node has it natively since v17).
if (typeof globalThis.structuredClone === 'undefined') {
  globalThis.structuredClone = (val) => JSON.parse(JSON.stringify(val));
}
