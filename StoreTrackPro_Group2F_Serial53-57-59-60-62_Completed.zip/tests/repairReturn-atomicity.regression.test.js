const fs = require('fs');
const path = require('path');

describe('Repair Return concurrent-window regression', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'modules', 'componentManagement.js'), 'utf8');
  const start = source.indexOf('async function repairReturn(id)');
  const end = source.indexOf('  function repair()', start);
  const posting = source.slice(start, end);

  test('persisted lifecycle status is atomically transitioned with stock, transaction, and audit writes', () => {
    expect(start).toBeGreaterThanOrEqual(0);
    expect(posting).toContain('window.atomicReadModifyWrite(STORES.repair, id');
    expect(posting).toContain("current.status !== 'REPAIR COMPLETED'");
    expect(posting).toContain("status: 'RETURNED TO STOCK'");
    expect(posting).toContain("{ store: STORES.stock, obj: freshStockRow }");
    expect(posting).toContain("{ store: STORES.tx, obj: freshTx }");
    expect(posting).toContain("{ store: STORES.audit, obj: freshAudit }");
  });

  test('existing persisted stock row is included as an atomic freshness guard', () => {
    expect(posting).toContain("{ store: STORES.stock, key: existingStock.id, name: 'stock' }");
    expect(posting).toContain('const freshStock = guards.stock || stockRow;');
  });
});
