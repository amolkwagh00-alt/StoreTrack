'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const app = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
function extract(source, name) {
  const start = source.indexOf(`function ${name}(`); assert.notEqual(start, -1, `missing ${name}`);
  const open = source.indexOf('{', start); let depth = 0; let quote = null; let escaped = false;
  for (let i = open; i < source.length; i += 1) {
    const ch = source[i];
    if (quote) { if (escaped) escaped = false; else if (ch === '\\') escaped = true; else if (ch === quote) quote = null; continue; }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth += 1; else if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`unterminated ${name}`);
}

test('Serial 53 retains exact counted-versus-system accuracy math and empty-safe reporting', () => {
  const context = {};
  vm.runInNewContext(`${extract(app, 'computeStockAccuracy')}; result=computeStockAccuracy([{details:[{diff:0},{diff:-3}]},{details:[]}]);`, context);
  assert.deepEqual(JSON.parse(JSON.stringify(context.result)), { counts: 2, items: 2, matched: 1, accuracy: 50, absoluteVariance: 3 });
  assert.match(html, /Stock Accuracy Report/);
  assert.match(app, /Stock accuracy export preview/);
});

test('Serial 57 wires site, part and supplier filters into date reports', () => {
  for (const id of ['rp-site', 'rp-part', 'rp-supp']) assert.match(html, new RegExp(`id="${id}"`));
  assert.match(app, /const site=document\.getElementById\('rp-site'\)/);
  assert.match(app, /const part=document\.getElementById\('rp-part'\)/);
  assert.match(app, /const supplier=document\.getElementById\('rp-supp'\)/);
  assert.match(app, /populateReportFilters\(\)/);
  const context = { Date, isWithinLocalDateRange: (value, from, to) => value >= `${from}T00:00:00Z` && value <= `${to}T23:59:59Z` };
  vm.runInNewContext(`${extract(app, 'filterReportTransactions')}; result=filterReportTransactions([
    {time:'2026-01-15T12:00:00Z',status:'confirmed',type:'IN',itemId:'m1',supplierName:'Acme',location:'Plant A',barcode:'P-1'},
    {time:'2026-01-15T12:00:00Z',status:'confirmed',type:'IN',itemId:'m2',supplierName:'Other',location:'Plant B',barcode:'P-2'},
    {time:'2026-01-15T12:00:00Z',status:'pending',itemId:'m1',supplierName:'Acme',location:'Plant A',barcode:'P-1'}
  ],'2026-01-01','2026-01-31','Plant A','P-1','Acme',[{id:'m1',barcode:'P-1'}]);`, context);
  assert.equal(context.result.length, 1);
});

test('Serial 59 previews the selected report projection before downloading', () => {
  assert.match(app, /Report export preview/);
  assert.match(app, /The CSV will contain the generated report projection/);
  assert.match(app, /if\(!confirm\(preview\)\)\{return;\}/);
  assert.match(app, /reportExportRows\(reportType,rpData\)/);
});

test('Serial 60 exposes validated retention policy save and cleanup using existing archive stores', () => {
  assert.match(html, /archive-retention-days/);
  assert.match(html, /saveArchivePolicy\(\)/);
  assert.match(html, /cleanupArchivedRecords\(\)/);
  assert.match(app, /Retention must be a whole number from 1 to 36500 days/);
  assert.match(app, /cleanupOldArchiveRecords\(days\)/);
  assert.match(app, /Invalid timestamps were preserved/);
  assert.doesNotMatch(app, /createObjectStore\(['"]archive/);
});

test('Serial 62 provides admin-only diagnostics with severity and error-type filters', () => {
  assert.match(html, /id="s-diag"/);
  assert.match(html, /diag-error-severity/);
  assert.match(html, /diag-error-type/);
  assert.match(app, /if\(!cu\|\|cu\.role!==['"]admin['"]\)/);
  assert.match(app, /e\.context\?\.type===errorType/);
  assert.match(app, /window\.performanceMonitor/);
});
