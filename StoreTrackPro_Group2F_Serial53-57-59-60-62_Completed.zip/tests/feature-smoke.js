#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');

const root = path.resolve(__dirname, '..');
const printing = fs.readFileSync(path.join(root, 'modules/printing.js'), 'utf8');
const scanner = require(path.join(root, 'Scanner/scanner-manager.js'));

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
  console.log(`PASS ${message}`);
}

(async () => {
  assert(typeof scanner === 'function', 'scanner manager exports a constructable API');
  for (const method of ['start', 'stop', 'listHIDDevices', 'listSerialPorts', 'enrollHID']) {
    assert(
      new RegExp(`\\b${method}\\s*\\(`).test(scanner.prototype[method]?.toString() || ''),
      `scanner exposes ${method}`,
    );
  }
  const qr = await QRCode.toDataURL('STORETRACK-TEST-123');
  assert(qr.startsWith('data:image/png;base64,'), 'QR code generation returns a PNG data URL');
  for (const api of [
    'getLblSettings',
    'buildLabelZpl',
    'createLabelElement',
    'buildLabelPrintHtml',
  ]) {
    assert(new RegExp(`function\\s+${api}\\s*\\(`).test(printing), `printing exposes ${api}`);
  }
  console.log('FEATURE SMOKE PASSED');
})().catch((error) => {
  console.error(error.stack || error.message);
  process.exitCode = 1;
});
