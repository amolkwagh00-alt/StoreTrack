// Focused dependency-free StoreTrack regressions for original findings 81–100.
// Run: node --test tests/storetrack-batch4-81-100.node-test.cjs
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ROOT = process.env.STORETRACK_ROOT || path.resolve(__dirname, '..');
const cm = fs.readFileSync(path.join(ROOT, 'modules/componentManagement.js'), 'utf8');
const partNumberUtils = require(path.join(ROOT, 'core/partNumber.js'));

function extractFunction(source, name) {
  const match = new RegExp(`(?:async\\s+)?function\\s+${name}\\s*\\(`).exec(source);
  assert.ok(match, `function ${name} exists`);
  const open = source.indexOf('(', match.index); let parens = 0, quote = '', escape = false, close = -1;
  for (let i = open; i < source.length; i += 1) {
    const c = source[i];
    if (quote) { if (escape) escape = false; else if (c === '\\') escape = true; else if (c === quote) quote = ''; continue; }
    if (c === "'" || c === '"' || c === '`') { quote = c; continue; }
    if (c === '(') parens += 1; else if (c === ')' && --parens === 0) { close = i; break; }
  }
  assert.ok(close >= 0, `${name} signature closes`);
  const bodyOpen = source.indexOf('{', close); let depth = 0, state = 'code', escaped = false, lineComment = false, blockComment = false; const interpolations = [];
  for (let i = bodyOpen; i < source.length; i += 1) {
    const c = source[i], n = source[i + 1];
    if (lineComment) { if (c === '\n') lineComment = false; continue; }
    if (blockComment) { if (c === '*' && n === '/') { blockComment = false; i += 1; } continue; }
    if (state === 'single' || state === 'double') { if (escaped) escaped = false; else if (c === '\\') escaped = true; else if ((state === 'single' && c === "'") || (state === 'double' && c === '"')) state = 'code'; continue; }
    if (state === 'template') { if (escaped) escaped = false; else if (c === '\\') escaped = true; else if (c === '`') state = 'code'; else if (c === '$' && n === '{') { depth += 1; interpolations.push(depth); state = 'code'; i += 1; } continue; }
    if (c === '/' && n === '/') { lineComment = true; i += 1; continue; }
    if (c === '/' && n === '*') { blockComment = true; i += 1; continue; }
    if (c === "'") { state = 'single'; continue; } if (c === '"') { state = 'double'; continue; } if (c === '`') { state = 'template'; continue; }
    if (c === '{') depth += 1; else if (c === '}') { depth -= 1; if (interpolations.length && depth === interpolations[interpolations.length - 1] - 1) { interpolations.pop(); state = 'template'; continue; } if (depth === 0) return source.slice(match.index, i + 1); }
  }
  throw new Error(`Could not find end of ${name}`);
}
function makeContext(names, globals = {}) { const ctx = vm.createContext(globals); vm.runInContext(names.map(name => extractFunction(cm, name)).join('\n'), ctx, { timeout: 3000 }); return ctx; }
const normPart = value => String(value || '').trim().replace(/\s+/g, '').split(/([/-])/).map(x => /^\d+$/.test(x) ? String(Number(x)) : x.toUpperCase()).join('').toLowerCase();
const normStation = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');

// 81 — both Types of Shank export formats must apply the visible search query.
test('P23-F02 Types of Shank Excel and PDF exports honor active search', () => {
  const output = {};
  const ctx = makeContext(['exportTypesShankExcel', 'exportTypesShankPdf'], {
    val: id => id === 'cm-types-shank-search' ? 'abc' : '', uniqueShankPartNumbers: () => ['ABC-1', 'XYZ-2', 'XABC-3'], today: () => '2026-10-10',
    partUsageComment: () => '',
    exportExcel: (...args) => { output.excel = args; }, exportPdfTable: (...args) => { output.pdf = args; }
  });
  ctx.exportTypesShankExcel(); ctx.exportTypesShankPdf();
  assert.deepEqual(JSON.parse(JSON.stringify(output.excel[3])), [['ABC-1', ''], ['XABC-3', '']]);
  assert.deepEqual(JSON.parse(JSON.stringify(output.pdf[2])), [['ABC-1', ''], ['XABC-3', '']]);
});

// 82 — Save Part must use the canonical Part Master role capability.
test('P24-F01 Save Part uses partMaster capability and persists for an authorized role', async () => {
  const calls = [], writes = [];
  const fields = { 'cp-no': { value: 'FS-101' }, 'cp-desc': { value: 'Fixed Shank' }, 'cp-type': { value: 'Shank' }, 'cp-min': { value: '2' } };
  const ctx = makeContext(['savePart'], {
    canComponent: key => { calls.push(key); return key === 'partMaster'; }, document: { getElementById: id => fields[id] || null }, val: id => (fields[id]?.value || '').trim(), sel: id => fields[id]?.value || '',
    validMappedPartNo: value => Boolean(String(value).trim()) && !/^N\/?A$/i.test(String(value).trim()), TYPES: ['Shank'], partByNo: () => null,
    dPut: async (store, row) => writes.push([store, row]), state: { parts: [] }, STORES: { parts: 'component_parts' }, uid: () => 'new-part', nowIso: () => '2026-10-10T00:00:00Z',
    audit: async () => {}, toastMsg: () => {}, parts() {}
  });
  await ctx.savePart();
  assert.deepEqual(calls, ['partMaster']);
  assert.equal(writes.length, 1);
  assert.equal(writes[0][1].partNo, 'FS-101');
});

// 83 — Edit Part rejects normalized placeholders and trimmed blank descriptions before mutation.
test('P24-F02 Edit Part rejects invalid Part No. and blank trimmed description', async () => {
  const original = { id: 'p1', partNo: 'FS-101', description: 'Fixed Shank' }; const errors = []; let writes = 0;
  const ctx = makeContext(['editPart'], {
    canComponent: key => key === 'partMaster', state: { parts: [original] }, componentInputDialog: async title => title === 'Part No.' ? ' N/A ' : '   ',
    vendorPartNo: value => String(value || ''), validMappedPartNo: value => Boolean(String(value).trim()) && !/^(?:n\/?a|na|not\s*applicable|not\s*available|-+)$/i.test(String(value).trim()),
    samePartNo: (a, b) => normPart(a) === normPart(b), toastMsg: (...args) => errors.push(args), awaitPutPart: async () => { writes += 1; }
  });
  await ctx.editPart('p1');
  assert.equal(original.partNo, 'FS-101'); assert.equal(original.description, 'Fixed Shank');
  assert.equal(writes, 0); assert.equal(errors.length, 1);
});

// 84 — Stock aggregation and Part Master lookup must share canonical partKey normalization.
test('P24-F03 Parts Master uses the same partKey for stock aggregation and lookup', () => {
  const body = extractFunction(cm, 'parts');
  assert.match(body, /const key = partKey\(stock\.partNo\)/);
  assert.match(body, /const normalizedPartKey = partKey\(p\.partNo\)/);
  assert.equal(partNumberUtils.partKey('FS-0101'), partNumberUtils.partKey('FS-101'));
});

// 85 — Enter-to-highlight must switch to the page containing a later matching row.
test('P24-F04 Enter-to-highlight reveals matching Part Master row on its page', () => {
  const rows = Array.from({ length: 65 }, (_, i) => ({ dataset: { partNo: `P-${i + 1}` }, style: {}, scrollIntoView() { this.scrolled = true; } }));
  const target = rows[60], pager = { page: 1, pageSize: 30, filteredRows: [] }; const search = { value: 'P-61' };
  const ctx = makeContext(['searchPartMaster'], {
    document: { getElementById: id => id === 'cm-part-master-search' ? search : null, querySelectorAll: selector => selector === '.cm-part-master-row' ? rows : [] },
    componentPagerState: new Map([['parts', pager]]), filterPartMasterRows() { pager.filteredRows = rows; }, componentRefreshPager(key) { assert.equal(key, 'parts'); }, toastMsg() {}
  });
  ctx.searchPartMaster();
  assert.equal(pager.page, 3); assert.equal(target.style.outline, '2px solid #e0a800'); assert.equal(target.scrolled, true);
});

// 86 — Edit Mapping uses separate visible labels and existing values in all four dialogs.
test('P25-F01 Edit Mapping dialogs show current field values as prefilled inputs', async () => {
  const row = { id: 'm1', stationNo: 'Press 1', gunReferenceNo: 'Gun 2', position: 'Fix Shank', partNo: 'FS-101', binId: 'B1' }; const prompts = [];
  const ctx = makeContext(['editMapping'], {
    canComponent: () => true, state: { mappings: [row], stock: [], historicalConsumption: [] }, POSITIONS: ['Fix Shank'],
    validMappedPartNo: value => Boolean(String(value || '').trim()), partKey: partNumberUtils.partKey,
    componentInputDialog: async (...args) => { prompts.push(args); return args[2]; }, vendorPartNo: value => String(value || ''), partByNo: () => row,
    mappingIdentity: (station, gun, position) => `${station}|${gun}|${position}`, sameStation: (a, b) => a === b, confirm: () => true,
    dPut: async () => {}, STORES: { mappings: 'mappings' }, uid: () => 'rev1', nowIso: () => '2026-10-10T00:00:00Z', user: () => ({ id: 'u1' }), audit: async () => {},
    load: async () => {}, migrateExistingRhLhCommonBins: async () => {}, reconcileRhLhCommonBinReferences: async () => {}, matrix() {}
  });
  await ctx.editMapping('m1');
  assert.deepEqual(JSON.parse(JSON.stringify(prompts)), [
    ['Edit Mapping — Station No.', 'Station No. (blank is allowed)', 'Press 1'],
    ['Edit Mapping — Gun Reference No.', 'Gun Reference No. (blank is allowed)', 'Gun 2'],
    ['Edit Mapping — Component Position', 'Component position (Fix Shank)', 'Fix Shank'],
    ['Edit Mapping — Vendor Part No.', 'Vendor Part No. (must exist in Part Master; N/A remains N/A; blank remains blank)', 'FS-101']
  ]);
});

// 87 — Mapping exports retain source-only imported Station/Gun rows.
test('P25-F02 Mapping Excel and PDF exports include source-only Gun rows', () => {
  const captured = {}; const sourceOnly = { stationNo: 'Press 5', gunReferenceNo: 'Gun 9', sourceOnly: true, sourceSheet: 'Matrix', sourceRow: 22 };
  const ctx = makeContext(['exportMappingExcel', 'exportMappingPdf'], {
    canComponent: () => true, gunCountMetrics: () => ({ source: 1, mapped: 0, allocated: 0, unassigned: 1 }),
    state: { mappings: [], gunRows: [sourceOnly] }, today: () => '2026-10-10', exportExcel: (...args) => { captured.excel = args; }, exportPdfTable: (...args) => { captured.pdf = args; }
  });
  ctx.exportMappingExcel(); ctx.exportMappingPdf();
  assert.ok(captured.excel[3].some(row => row[0] === 'Press 5' && row[1] === 'Gun 9'));
  assert.ok(captured.pdf[2].some(row => row[0] === 'Press 5' && row[1] === 'Gun 9'));
});

// 88 — Source-only Gun deletion removes the underlying source register row and audits it.
test('P25-F03 Delete Gun removes source-only Gun Register row', async () => {
  const source = { id: 'g1', sourceSheet: 'Matrix', sourceSrNo: 22, stationNo: 'Press 5', gunReferenceNo: 'Gun 9' }; const deletes = [], audits = [];
  const group = { sourceOnly: true, ids: [], sources: new Set(['Matrix']), srNos: new Set([22]), stationNo: 'Press 5', gunReferenceNo: 'Gun 9' };
  const ctx = makeContext(['deleteGunGroup'], {
    canComponent: () => true, state: { matrixGroups: new Map([['g0', group]]), gunRows: [source], mappings: [] }, confirm: () => true,
    dDel: async (...args) => deletes.push(args), audit: async (...args) => audits.push(args), rebuildGunCountAggregate: async () => {}, matrix() {}
  });
  await ctx.deleteGunGroup('g0');
  assert.deepEqual(deletes, [['component_gun_rows', 'g1']]); assert.equal(ctx.state.gunRows.length, 0);
  assert.ok(audits.some(args => args[0] === 'COMPONENT_SOURCE_GUN_DELETE'));
});

// 89 — manual merge preview/mutation eligibility requires matching nonempty base Station.
test('P26-F01 Manual RH/LH merge rejects different base Stations', () => {
  const ctx = makeContext(['mergeStationGunCondition'], {
    baseStationKey: value => String(value).replace(/\s+(RH|LH)$/i, '').replace(/[^a-z0-9]/gi, '').toLowerCase(),
    mergeStationGunCount: () => 1
  });
  const result = ctx.mergeStationGunCondition('Press 1 RH', 'Press 2 LH');
  assert.equal(result.ok, false); assert.match(result.message, /same base Station/i);
  assert.match(extractFunction(cm, 'mergeStation'), /mergeStationGunCondition\(source, target\)[\s\S]*?if \(!gunCondition\.ok\)/);
});

// 90 — Rollback restores target mapping and transaction snapshots by record ID.
test('P26-F02 Rollback restores target mapping and transaction bin IDs', async () => {
  const db = {
    histories: [{ id: 'h1', createdAt: '2026-10-01', source: 'Press LH', target: 'Press RH', mode: 'COMMON_BIN',
      mappings: [{ id: 'm-target', stationNo: 'Press RH', binId: 'OLD-BIN' }],
      transactions: [{ id: 'tx-target', stationNo: 'Press RH', binId: 'OLD-BIN' }], stock: [], targetBin: { id: 'b1', binId: 'OLD-BIN' } }],
    mappings: [{ id: 'm-target', stationNo: 'Press RH', binId: 'MERGED-BIN' }], transactions: [{ id: 'tx-target', stationNo: 'Press RH', binId: 'MERGED-BIN' }], stock: [], bins: []
  };
  const ctx = makeContext(['rollbackStationMerge'], {
    canComponent: () => true, gAll: async store => db[store === 'component_station_merge_history' ? 'histories' : store],
    dDel: async (store, id) => { db[store] = db[store].filter(row => row.id !== id); }, dPut: async (store, row) => { const i = db[store].findIndex(x => x.id === row.id); if (i < 0) db[store].push({ ...row }); else db[store][i] = { ...row }; },
    STORES: { mappings: 'mappings', tx: 'transactions', stock: 'stock', bins: 'bins' }, COMPONENT_STATION_MERGE_ROLLBACK: 'COMPONENT_COMMON_BIN_MERGE_ROLLBACK',
    confirm: () => true, audit: async () => {}, load: async () => {}, toastMsg() {}, bins() {}
  });
  await ctx.rollbackStationMerge();
  assert.equal(db.mappings.find(row => row.id === 'm-target').binId, 'OLD-BIN');
  assert.equal(db.transactions.find(row => row.id === 'tx-target').binId, 'OLD-BIN');
});

// 91 — Unauthorized users must be rejected before Edit Station Alias opens prompts.
test('P27-F01 Edit Station Alias fails closed before opening dialogs', async () => {
  let dialogs = 0;
  const ctx = makeContext(['editStationAlias'], { canComponent: () => false, componentInputDialog: async () => { dialogs += 1; }, state: { aliases: [{ id: 'a1' }] } });
  await ctx.editStationAlias('a1'); assert.equal(dialogs, 0);
});

// 92 — Alias edit must reject a normalized collision before deleting or overwriting either alias.
test('P27-F02 Alias edit rejects duplicate normalized alias without writes', async () => {
  const aliases = [{ id: 'alias-old', canonicalStation: 'Press 1', alias: 'Press-1' }, { id: 'alias-press2', canonicalStation: 'Press 2', alias: 'Press-2' }]; const deletes = [], writes = [], errors = [];
  const values = ['Press 2', 'Press 2'], prompts = [];
  const ctx = makeContext(['stationAliasConflict', 'editStationAlias'], {
    canComponent: () => true, state: { aliases }, componentInputDialog: async (...args) => { prompts.push(args); return values.shift(); }, canonicalStation: value => String(value).trim().replace(/\s+/g, ' '),
    sameStation: (a, b) => normStation(a) === normStation(b), normalStation: normStation, user: () => ({}), nowIso: () => '2026-10-10',
    dDel: async (...args) => deletes.push(args), dPut: async (...args) => writes.push(args), audit: async () => {}, load: async () => {}, stationAliases() {},
    toastMsg: (...args) => errors.push(args), STORES: { aliases: 'aliases' }
  });
  await ctx.editStationAlias('alias-old');
  assert.deepEqual(JSON.parse(JSON.stringify(prompts)), [['Edit Canonical Station Alias', 'Canonical Station', 'Press 1'], ['Edit Station Alias', 'Alias', 'Press-1']]);
  assert.equal(deletes.length, 0); assert.equal(writes.length, 0); assert.match(errors[0][0], /conflicts with an existing alias/i);
});

// 93 — The same active-alias resolver must serve import, mapping, bin, and station identity/search.
test('P27-F03 shared station resolver canonicalizes active aliases and stops after deactivation', () => {
  const state = { aliases: [] }; let variationLookups = 0;
  const ctx = makeContext(['activeStationAlias', 'resolveStationAlias', 'sameStation', 'stationMatchesSearch', 'resolveImportStation', 'stationAliasConflict', 'saveStationAlias'], {
    state, normalStation: normStation, canonicalStation: value => String(value || '').trim().replace(/\s+/g, ' '), cmMatch: (value, query) => !query || String(value || '').toLowerCase().includes(String(query).toLowerCase()),
    val: id => id === 'csa-canonical' ? 'Press 10' : 'Press Ten', canComponent: () => true, STORES: { aliases: 'aliases' },
    dPut: async (_store, row) => state.aliases.push(row), audit: async () => {}, load: async () => {}, stationAliases() {}, toastMsg() {},
    user: () => ({ username: 'Admin' }), nowIso: () => '2026-10-10', stationVariationFor: () => { variationLookups += 1; return []; }, pendingImport: { stationDecisions: {} }, confirm: () => false
  });
  return ctx.saveStationAlias().then(() => {
  assert.equal(state.aliases[0].alias, 'Press Ten');
  assert.equal(ctx.resolveImportStation('Press Ten'), 'Press 10');
  assert.equal(ctx.sameStation('Press Ten', 'Press 10'), true);
  assert.equal(ctx.stationMatchesSearch('Press 10', 'Press Ten'), true);
  assert.equal(ctx.stationMatchesSearch('Press RH', 'Press Ten'), false);
  assert.match(extractFunction(cm, 'filterMappingRows'), /stationMatchesSearch\(row\.dataset\.station, station\)/);
  assert.match(extractFunction(cm, 'filterBinRows'), /stationMatchesSearch\(row\.dataset\.station, station\)/);
  assert.match(cm, /let text = resolveStationAlias\(String\(value \|\| ''\)\)/);
  assert.match(cm, /const stationVariantKey = value => normalStation\(resolveStationAlias\(value\)\)/);
  state.aliases[0].status = 'INACTIVE';
  assert.equal(ctx.resolveImportStation('Press Ten'), 'Press Ten');
  assert.equal(ctx.sameStation('Press Ten', 'Press 10'), false);
  assert.equal(ctx.stationMatchesSearch('Press 10', 'Press Ten'), false);
  assert.equal(variationLookups, 1);
  });
});

// 94 — Edit Bin must pass a separate visible label and current location as initial value.
test('P28-F01 Edit Bin dialog receives the persisted physical location as initial value', async () => {
  const bin = { id: 'b1', binId: 'BIN-1', stationNo: 'Press 1', location: 'Rack 4' }; let prompt;
  const ctx = makeContext(['editBin'], {
    canComponent: () => true, state: { bins: [bin] }, componentInputDialog: async (...args) => { prompt = args; return args[2]; },
    nowIso: () => '2026-10-10', dPut: async () => {}, STORES: { bins: 'bins' }, audit: async () => {}, toastMsg() {}, load: async () => {}, bins() {}
  });
  await ctx.editBin('b1');
  assert.deepEqual(JSON.parse(JSON.stringify(prompt)), ['Edit Bin Location', 'Physical location', 'Rack 4']); assert.equal(bin.location, 'Rack 4');
});

// 95 — Pencil Bin exports must be denied before Excel/PDF side effects.
test('P28-F02 Pencil Bin Excel/PDF exports enforce Reports permission', () => {
  let effects = 0;
  const ctx = makeContext(['exportPencilBinsExcel', 'exportPencilBinsPdf'], {
    canComponent: action => action === 'reports' ? false : true, exportExcel() { effects += 1; }, exportPdfTable() { effects += 1; }, pencilBinRowsForExport() { effects += 1; return []; }, today: () => '2026-10-10'
  });
  ctx.exportPencilBinsExcel(); ctx.exportPencilBinsPdf(); assert.equal(effects, 0);
});

// 96 — Bin location persistence precedes a before/after audit record.
test('P28-F03 Edit Bin writes old/new location audit after persistence', async () => {
  const bin = { id: 'b1', binId: 'BIN-1', stationNo: 'Press 1', location: 'Rack 4' }; const sequence = [];
  const ctx = makeContext(['editBin'], {
    canComponent: () => true, state: { bins: [bin] }, componentInputDialog: async () => 'Rack 5', nowIso: () => '2026-10-10',
    dPut: async (_store, row) => sequence.push(['put', row.location]), STORES: { bins: 'bins' }, audit: async (action, entity, id, details) => sequence.push(['audit', action, details.previousLocation, details.location]),
    toastMsg() {}, load: async () => {}, bins() {}
  });
  await ctx.editBin('b1');
  assert.deepEqual(JSON.parse(JSON.stringify(sequence)), [['put', 'Rack 5'], ['audit', 'COMPONENT_BIN_LOCATION_UPDATE', 'Rack 4', 'Rack 5']]);
});

// 97 — Common-bin Excel/PDF exports exclude Pencil and inactive bins.
test('P29-F01 Common-bin Excel/PDF exports exclude Pencil bins', () => {
  const captured = {}; const bins = [
    { binId: 'COMMON-1', stationNo: 'Press 1', location: 'A', active: true },
    { binId: 'PENCIL-1', binKind: 'PENCIL_PAIR', location: 'B', active: true },
    { binId: 'OLD-1', stationNo: 'Press 2', active: false }
  ];
  const ctx = makeContext(['exportBinsExcel', 'exportBinsPdf'], { canComponent: () => true, state: { bins }, binGunAllocations: () => '', today: () => '2026-10-10', exportExcel: (...args) => { captured.excel = args; }, exportPdfTable: (...args) => { captured.pdf = args; } });
  ctx.exportBinsExcel(); ctx.exportBinsPdf();
  assert.deepEqual(JSON.parse(JSON.stringify(captured.excel[3].map(row => row[0]))), ['COMMON-1']);
  assert.deepEqual(JSON.parse(JSON.stringify(captured.pdf[2].map(row => row[0]))), ['COMMON-1']);
});

// 98 — Missing-bin page back action must route to common Shank bins (`bins-copy`).
test('P29-F02 Missing-bin back button targets common Shank Bin route', () => {
  let rendered = '';
  const ctx = makeContext(['openMissingBinAllocations'], {
    missingBinRecords: () => [], shell: (_title, body) => { rendered = body; },
    btn: (label, action) => `<button>${label}|${action}</button>`, table: () => '<table></table>'
  });
  ctx.openMissingBinAllocations(); assert.match(rendered, /Back to Bin Allocation\|componentOpen\('bins-copy'\)/);
});

// 99 — Allocation includes mappings for every station in a merged bin.
test('P29-F03 Gun-wise allocation includes merged source-station mappings', () => {
  const ctx = makeContext(['binGunAllocations'], {
    POSITIONS: ['Fix Shank', 'Moving Shank', 'Fix Adaptor', 'Moving Adaptor', 'Fix Holder', 'Moving Holder', 'Pencil Shank'],
    state: {
      gunRows: [{ stationNo: 'Press LH', gunReferenceNo: 'Gun 1', sourceKey: 'Matrix:12', srNo: 1 }],
      mappings: [{ stationNo: 'Press LH', gunReferenceNo: 'Gun 1', sourceKey: 'Matrix:12', position: 'Fix Shank', partNo: 'FS-LEFT' }]
    },
    stationVariantKey: value => normStation(value), normalStation: normStation, vendorPartNo: value => String(value || ''), validMappedPartNo: value => Boolean(value), partDisplayWithComment: value => String(value || ''), esc: value => String(value)
  });
  const rendered = ctx.binGunAllocations({ stationNo: 'Press RH', mergedStations: ['Press LH'] }); assert.match(rendered, /FS-LEFT/);
});

// 100 — Reconciliation uses a merged bin when the source gun remains under its original Station.
test('P29-F04 Reconciliation export includes merged Bin ID for source-side Station', () => {
  let serialized = '';
  const ctx = makeContext(['exportBinReconciliation'], {
    canComponent: () => true,
    state: { gunRows: [{ sourceRow: 12, sourceKey: 'Matrix:12', stationNo: 'Press LH', gunReferenceNo: 'Gun 1', sourceOnly: true }], mappings: [], bins: [{ binId: 'PRESS-RH-LH', stationNo: 'Press RH', mergedStations: ['Press LH'], active: true }] },
    sameStation: (a, b) => normStation(a) !== '' && normStation(a) === normStation(b), POSITIONS: ['Fix Shank'], validMappedPartNo: value => Boolean(value), calculateGunCount: () => 1,
    csv: rows => JSON.stringify(rows), download: (_name, content) => { serialized = content; }, today: () => '2026-10-10'
  });
  ctx.exportBinReconciliation(); const rows = JSON.parse(serialized); assert.equal(rows[1][4], 'PRESS-RH-LH');
});
