// Unit tests for session security module
const { SessionSecurity } = require('../modules/sessionSecurity.js');

describe('Session Security Module', () => {
  let sessionSecurity;

  beforeEach(() => {
    sessionSecurity = new SessionSecurity();
    // jest-environment-jsdom already provides a real `window`/`document`
    // (global === window here), so mock by adding properties onto them
    // rather than replacing `global.window` wholesale -- that reassignment
    // doesn't actually change what the bare `window` identifier resolves to
    // inside sessionSecurity.js, since `window` is a non-configurable
    // self-reference in jsdom, not a plain writable global.
    window.eventBus = { emit: jest.fn() };
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('initialize', () => {
    test('should initialize with default values', () => {
      sessionSecurity.initialize();
      expect(sessionSecurity.sessionTimeout).toBe(30 * 60 * 1000);
      expect(sessionSecurity.warningTime).toBe(60 * 1000);
    });

    test('should initialize with custom values', () => {
      sessionSecurity.initialize({
        sessionTimeout: 60 * 60 * 1000,
        warningTime: 5 * 60 * 1000,
      });
      expect(sessionSecurity.sessionTimeout).toBe(60 * 60 * 1000);
      expect(sessionSecurity.warningTime).toBe(5 * 60 * 1000);
    });
  });

  describe('startSession', () => {
    test('should start session with provided data', () => {
      const sessionData = { username: 'testuser', role: 'admin' };
      sessionSecurity.startSession(sessionData);

      expect(sessionSecurity.sessionData).toBeDefined();
      expect(sessionSecurity.sessionData.username).toBe('testuser');
      expect(sessionSecurity.sessionData.active).toBe(true);
    });

    test('should set remember me expiry when enabled', () => {
      const sessionData = { username: 'testuser' };
      sessionSecurity.startSession(sessionData, true);

      expect(sessionSecurity.sessionData.rememberMe).toBe(true);
      expect(sessionSecurity.sessionData.expiry).toBeGreaterThan(Date.now());
    });

    test('should not set expiry when remember me disabled', () => {
      const sessionData = { username: 'testuser' };
      sessionSecurity.startSession(sessionData, false);

      expect(sessionSecurity.sessionData.rememberMe).toBe(false);
      expect(sessionSecurity.sessionData.expiry).toBeNull();
    });

    test('should emit session started event', () => {
      const sessionData = { username: 'testuser' };
      sessionSecurity.startSession(sessionData);

      expect(window.eventBus.emit).toHaveBeenCalledWith(
        'SESSION_STARTED',
        expect.objectContaining({ username: 'testuser' }),
      );
    });
  });

  describe('stopSession', () => {
    test('should stop active session', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      sessionSecurity.stopSession();

      expect(sessionSecurity.sessionData.active).toBe(false);
    });

    test('should clear timers', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      sessionSecurity.stopSession();

      expect(sessionSecurity.sessionTimer).toBeNull();
      expect(sessionSecurity.warningTimer).toBeNull();
    });
  });

  describe('recordActivity', () => {
    test('should update last activity timestamp', () => {
      const before = Date.now();
      sessionSecurity.recordActivity();
      const after = Date.now();

      expect(sessionSecurity.lastActivity).toBeGreaterThanOrEqual(before);
      expect(sessionSecurity.lastActivity).toBeLessThanOrEqual(after);
    });

    test('should reset warning flag', () => {
      sessionSecurity.warningShown = true;
      sessionSecurity.recordActivity();

      expect(sessionSecurity.warningShown).toBe(false);
    });

    test('should reset timers when session is active', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      sessionSecurity.recordActivity();

      // Should call resetTimers (implementation detail)
      expect(sessionSecurity.lastActivity).toBeGreaterThan(0);
    });
  });

  describe('isSessionActive', () => {
    test('should return false when no session exists', () => {
      expect(sessionSecurity.isSessionActive()).toBeFalsy();
    });

    test('should return false when session is inactive', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      sessionSecurity.sessionData.active = false;

      expect(sessionSecurity.isSessionActive()).toBeFalsy();
    });

    test('should return true for active session', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      expect(sessionSecurity.isSessionActive()).toBe(true);
    });
  });

  describe('getSessionData', () => {
    test('should return session information', () => {
      sessionSecurity.startSession({ username: 'testuser', role: 'admin' });
      const info = sessionSecurity.getSessionData();

      expect(info).toBeDefined();
      expect(info.username).toBe('testuser');
      expect(info.role).toBe('admin');
      expect(info.active).toBe(true);
    });

    test('should return null when no session exists', () => {
      const info = sessionSecurity.getSessionData();
      expect(info).toBeNull();
    });
  });

  describe('getSessionStats (session duration)', () => {
    // There's no standalone getSessionDuration() -- duration is one field
    // of getSessionStats(), which app.js/auth.js rely on for the same data.
    test('should calculate session duration', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      const stats = sessionSecurity.getSessionStats();

      expect(stats.duration).toBeGreaterThanOrEqual(0);
    });

    test('should return null when no session exists', () => {
      expect(sessionSecurity.getSessionStats()).toBeNull();
    });
  });

  describe('getRemainingTime (used to decide "expiring soon")', () => {
    // There's no isSessionExpiringSoon() method -- showWarning() (driven by
    // the internal setTimeout in resetTimers()) is what actually decides
    // this in the running app, by comparing getRemainingTime() to
    // warningTime. We test that same comparison directly here rather than
    // a method that doesn't exist.
    test('remaining time drops below warningTime as the session ages', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      sessionSecurity.lastActivity =
        Date.now() - (sessionSecurity.sessionTimeout - sessionSecurity.warningTime + 1000);

      expect(sessionSecurity.getRemainingTime()).toBeLessThan(sessionSecurity.warningTime);
    });

    test('remaining time stays above warningTime right after activity', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      sessionSecurity.lastActivity = Date.now();

      expect(sessionSecurity.getRemainingTime()).toBeGreaterThan(sessionSecurity.warningTime);
    });
  });

  describe('extendSession', () => {
    test('should extend session duration', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      const beforeLastActivity = sessionSecurity.lastActivity;

      // Date.now() has millisecond granularity, so two calls in the same
      // tick can be genuinely equal -- advance the clock a tick for real
      // rather than asserting >= (which would silently pass a no-op too).
      jest.spyOn(Date, 'now').mockReturnValue(beforeLastActivity + 5);

      sessionSecurity.extendSession();

      expect(sessionSecurity.lastActivity).toBeGreaterThan(beforeLastActivity);
      Date.now.mockRestore();
    });

    test('should reset warning flag', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      sessionSecurity.warningShown = true;

      sessionSecurity.extendSession();

      expect(sessionSecurity.warningShown).toBe(false);
    });
  });

  describe('clearSessionData', () => {
    test('should clear session data', () => {
      sessionSecurity.startSession({ username: 'testuser' });
      sessionSecurity.clearSessionData();

      // clearSessionData() only clears sessionData (and localStorage) -- it
      // deliberately leaves lastActivity alone (a new session sets it again
      // via startSession()/recordActivity()), so there's nothing to assert
      // about lastActivity here.
      expect(sessionSecurity.sessionData).toBeNull();
    });
  });
});
