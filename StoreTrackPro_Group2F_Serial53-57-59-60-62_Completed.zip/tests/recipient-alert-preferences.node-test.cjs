'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = process.env.STORETRACK_ROOT || path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'modules', 'automatedAlerts.js'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const start = source.indexOf('function alertRecipientId(');
const end = source.indexOf('/**\n * Global automated alerts manager instance', start);
assert.ok(start >= 0 && end > start);
const context = {};
vm.runInNewContext(source.slice(start, end), context);
const prefs = [
  { userId: 'alice', channel: 'email', eventType: 'stock_low', enabled: false },
  { userId: 'alice', channel: 'push', eventType: 'stock_low', enabled: true },
  { userId: 'bob', channel: 'email', eventType: 'stock_low', enabled: true },
  { userId: 'alice', channel: 'email', eventType: 'stock_out', enabled: true }
];
const manager = { getPreferencesForUser: id => prefs.filter(p => p.userId === id) };
const recipients = ['alice', 'bob'].map(userId => ({ userId }));
assert.deepEqual(Array.from(context.resolveAlertRecipients({ eventType: 'stock_low', category: 'inventory', recipients }, 'email', manager).map(r => r.userId)), ['bob']);
assert.deepEqual(Array.from(context.resolveAlertRecipients({ eventType: 'stock_low', recipients }, 'push', manager).map(r => r.userId)), ['alice', 'bob']);
assert.deepEqual(Array.from(context.resolveAlertRecipients({ eventType: 'stock_out', recipients }, 'email', manager).map(r => r.userId)), ['alice', 'bob']);
assert.deepEqual(Array.from(context.resolveAlertRecipients({ eventType: 'battery_low', recipients }, 'email', manager).map(r => r.userId)), ['alice', 'bob'], 'no matching preference preserves legacy allow behavior');
assert.match(source, /sendEmailNotification\(deliveryAlert\)/, 'filtered recipient payload is used for channel delivery');
assert.match(source, /userId, isGlobal: false/, 'in-app alerts are persisted per user, not globally');
assert.match(html, /id="alert-pref-event"/);
assert.match(html, /id="alert-pref-channel"/);
assert.match(app, /setUserNotificationPreference\(userId,channel,eventType,enabled/);
assert.match(app, /renderAlertRecipientPreferences\(\)/);
console.log('recipient alert preferences: all regression checks passed');
