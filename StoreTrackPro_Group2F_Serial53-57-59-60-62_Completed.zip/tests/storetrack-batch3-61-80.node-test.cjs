// Focused dependency-free regressions for StoreTrack audit findings 61–80.
// Run: node --test tests/storetrack-batch3-61-80.node-test.cjs
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ROOT = process.env.STORETRACK_ROOT || path.resolve(__dirname, '..');
const msp = fs.readFileSync(path.join(ROOT, 'modules/msp.js'), 'utf8');
const cm = fs.readFileSync(path.join(ROOT, 'modules/componentManagement.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');

function extractFunction(source, name) {
  const re = new RegExp(`(?:async\\s+)?function\\s+${name}\\s*\\(`);
  const match = re.exec(source);
  assert.ok(match, `function ${name} exists`);
  const openParen = source.indexOf('(', match.index);
  let parens = 0, mode = 'code', escaped = false, closeParen = -1;
  for (let i = openParen; i < source.length; i += 1) {
    const c = source[i];
    if (mode !== 'code') {
      if (escaped) { escaped = false; continue; }
      if (c === '\\') { escaped = true; continue; }
      if ((mode === 'single' && c === "'") || (mode === 'double' && c === '"') || (mode === 'template' && c === '`')) mode = 'code';
      continue;
    }
    if (c === "'") { mode = 'single'; continue; }
    if (c === '"') { mode = 'double'; continue; }
    if (c === '`') { mode = 'template'; continue; }
    if (c === '(') parens += 1;
    else if (c === ')' && --parens === 0) { closeParen = i; break; }
  }
  assert.ok(closeParen >= 0, `${name} signature closes`);
  const bodyOpen = source.indexOf('{', closeParen);
  assert.ok(bodyOpen >= 0, `${name} body exists`);
  let depth = 0, state = 'code', escape = false, lineComment = false, blockComment = false;
  const interpolationDepths = [];
  for (let i = bodyOpen; i < source.length; i += 1) {
    const c = source[i], n = source[i + 1];
    if (lineComment) { if (c === '\n') lineComment = false; continue; }
    if (blockComment) { if (c === '*' && n === '/') { blockComment = false; i += 1; } continue; }
    if (state === 'single' || state === 'double') {
      if (escape) { escape = false; continue; }
      if (c === '\\') { escape = true; continue; }
      if ((state === 'single' && c === "'") || (state === 'double' && c === '"')) state = 'code';
      continue;
    }
    if (state === 'template') {
      if (escape) { escape = false; continue; }
      if (c === '\\') { escape = true; continue; }
      if (c === '`') { state = 'code'; continue; }
      if (c === '$' && n === '{') { depth += 1; interpolationDepths.push(depth); state = 'code'; i += 1; }
      continue;
    }
    if (c === '/' && n === '/') { lineComment = true; i += 1; continue; }
    if (c === '/' && n === '*') { blockComment = true; i += 1; continue; }
    if (c === "'") { state = 'single'; continue; }
    if (c === '"') { state = 'double'; continue; }
    if (c === '`') { state = 'template'; continue; }
    if (c === '{') depth += 1;
    else if (c === '}') {
      depth -= 1;
      if (interpolationDepths.length && depth === interpolationDepths[interpolationDepths.length - 1] - 1) {
        interpolationDepths.pop(); state = 'template'; continue;
      }
      if (depth === 0) return source.slice(match.index, i + 1);
    }
  }
  throw new Error(`Could not find end of function ${name}`);
}
function context(source, names, globals = {}) {
  const ctx = vm.createContext(globals);
  vm.runInContext(names.map(name => extractFunction(source, name)).join('\n'), ctx, { timeout: 2500 });
  return ctx;
}
function fakeElement(value = '') { return { value, textContent: '', innerHTML: '', style: {}, dataset: {} }; }
function fakeDocument(elements = {}) { return { getElementById: id => elements[id] || null, querySelectorAll: () => [] }; }

// 61 — MSP sort controls must actually sort rows by the selected mode.
test('P16-F02 MSP sort controls sort by selected mode', () => {
  const rows = [
    { Machine: 'Press B', Status: 'Available', Qty: 8, createdAt: '2026-02-02T00:00:00Z' },
    { Machine: 'Press A', Status: 'Low Stock', Qty: 1, createdAt: '2026-02-01T00:00:00Z' }
  ];
  let rendered;
  const elements = { 'msp-global-search': fakeElement(), 'msp-machine-filter': fakeElement(), 'msp-status-filter': fakeElement(), 'msp-sort-sel': fakeElement('az'), 'msp-filtered-count': fakeElement() };
  const ctx = context(msp, ['mspRowIsLow', 'mspRenderTable'], {
    MSP_STATUS_COL: 'Status', document: fakeDocument(elements), mspActiveList: () => ({ headers: ['Machine', 'Status', 'Qty'], rows }),
    mspRenderTableRows: (_list, result) => { rendered = result; }
  });
  ctx.mspRenderTable();
  assert.deepEqual(Array.from(rendered, row => row.Machine), ['Press A', 'Press B']);
});

// 62 — the filtered-count element must reflect the filtered result, not total source rows.
test('P16-F03 MSP filtered-count indicator updates to the visible result count', () => {
  const rows = [{ Machine: 'Press A', Status: 'Available' }, { Machine: 'Press B', Status: 'Low Stock' }, { Machine: 'Press C', Status: 'Available' }];
  const count = fakeElement();
  const elements = { 'msp-global-search': fakeElement(), 'msp-machine-filter': fakeElement(), 'msp-status-filter': fakeElement('Low Stock'), 'msp-sort-sel': fakeElement('newest'), 'msp-filtered-count': count };
  const ctx = context(msp, ['mspRowIsLow', 'mspRenderTable'], {
    MSP_STATUS_COL: 'Status', document: fakeDocument(elements), mspActiveList: () => ({ headers: ['Machine', 'Status'], rows }), mspRenderTableRows() {}
  });
  ctx.mspRenderTable();
  assert.equal(count.textContent, '1 of 3 parts');
});

// 63 — CSV parsing must retain empty columns so values never shift left.
test('P16-F04 MSP CSV parser preserves leading, middle, and trailing empty cells', () => {
  const ctx = context(msp, ['mspParseCsv']);
  const parsed = ctx.mspParseCsv('Part,Station,Gun,Note\r\nP-1,,G-1,\r\n,PRESS 2,,memo');
  assert.deepEqual(JSON.parse(JSON.stringify(parsed)), [
    ['Part', 'Station', 'Gun', 'Note'],
    ['P-1', '', 'G-1', ''],
    ['', 'PRESS 2', '', 'memo']
  ]);
});

// 64 — CSV header cells receive the same quote escaping as data cells.
test('P16-F05 MSP CSV export quotes and escapes special header cells', () => {
  const ctx = vm.createContext({});
  const listToCsv = msp.slice(msp.indexOf('function mspListToCSV'), msp.indexOf('\nfunction mspExportList'));
  vm.runInContext(listToCsv + '\n' + extractFunction(msp, 'mspParseCsv'), ctx, { timeout: 2500 });
  const csv = ctx.mspListToCSV({ headers: ['Part, "No."', 'Header\nName'], rows: [{ 'Part, "No."': 'P-1', 'Header\nName': 'x' }] });
  const parsed = ctx.mspParseCsv(csv);
  assert.deepEqual(JSON.parse(JSON.stringify(parsed[0])), ['Part, "No."', 'Header\nName']);
  assert.deepEqual(JSON.parse(JSON.stringify(parsed[1])), ['P-1', 'x']);
});

// 65 — untrusted list/part values must be encoded in table and print HTML.
test('P16-F06 MSP table and print rendering escape user-controlled text', () => {
  const hostile = '<img src=x onerror="alert(1)">';
  const thead = fakeElement(), tbody = fakeElement();
  const ctx = vm.createContext({ document: fakeDocument({ 'msp-part-thead': thead, 'msp-part-tbody': tbody }) });
  const escapeHtml = msp.slice(msp.indexOf('function mspEscapeHtml'), msp.indexOf('\nfunction mspJsArg'));
  const renderRows = msp.slice(msp.indexOf('function mspRenderTableRows'), msp.indexOf('\n// ── mspInit'));
  const printHtml = msp.slice(msp.indexOf('function mspBuildPrintHtml'), msp.indexOf('\nfunction mspPrintList'));
  vm.runInContext(escapeHtml + '\n' + renderRows + '\n' + printHtml, ctx, { timeout: 2500 });
  const list = { title: hostile, machineName: hostile, headers: [hostile], rows: [{ [hostile]: hostile }] };
  ctx.mspRenderTableRows(list, list.rows);
  const printable = ctx.mspBuildPrintHtml(list);
  for (const output of [thead.innerHTML, tbody.innerHTML, printable]) {
    assert.doesNotMatch(output, /<img src=x/);
    assert.match(output, /&lt;img/);
  }
});

// 66 — numeric Qty/Min Qty fields must drive MSP low-stock classification.
test('P16-F07 MSP low-stock predicate uses numeric Qty and Min Qty values', () => {
  const ctx = context(msp, ['mspRowIsLow'], { MSP_STATUS_COL: 'Status' });
  assert.equal(ctx.mspRowIsLow({ Status: 'Available', Qty: '2', 'Min Qty': '3' }, ['Status', 'Qty', 'Min Qty']), true);
  assert.equal(ctx.mspRowIsLow({ Status: 'Available', Qty: '4', 'Min Qty': '3' }, ['Status', 'Qty', 'Min Qty']), false);
});

// 67 — Guide Line route is denied when its explicit capability is false.
test('P17-F01 Guide Line route checks the guide capability before opening', () => {
  const calls = [];
  const ctx = context(cm, ['open'], {
    state: { tab: 'dashboard' }, window: {},
    canComponent(action) { calls.push(action); return action !== 'guide'; }
  });
  ctx.open('guide');
  assert.deepEqual(Array.from(calls), ['view', 'guide']);
  assert.equal(ctx.state.tab, 'dashboard');
});

// 68 — native button semantics make the Guide Line navigation keyboard-operable.
test('P17-F02 Guide Line navigation uses a native button', () => {
  assert.match(html, /<button type="button" class="ni" data-onclick="componentOpen\('guide'\)"[^>]*>[^<]*Guide Line<\/button>/);
  assert.doesNotMatch(html, /<div[^>]*data-onclick="componentOpen\('guide'\)"/);
});

// 69 — explicit shankMapping.view denial must stop Dashboard and component routes.
test('P18-F01 Shank Mapping view capability blocks Dashboard opening', () => {
  const ctx = context(cm, ['open'], { state: { tab: 'old' }, window: {}, canComponent: () => false });
  ctx.open('dashboard');
  assert.equal(ctx.state.tab, 'old');
});

// 70 — all five dashboard report/export/email handlers must stop before side effects.
test('P18-F02 Dashboard report/export/email actions all enforce Reports capability', () => {
  let effects = 0;
  const ctx = context(cm, ['exportAnalytics', 'exportLowStock', 'exportLowStockExcel', 'exportLowStockPdf', 'emailLowStock'], {
    canComponent(action) { assert.equal(action, 'reports'); return false; },
    download() { effects += 1; }, exportExcel() { effects += 1; }, exportPdfTable() { effects += 1; }, audit() { effects += 1; },
    lowStockRows() { effects += 1; return [{ partNo: 'P-1' }]; }, groupedAlertExportRows() { effects += 1; return []; },
    state: {}, monthBounds() { effects += 1; return { start: '', end: '' }; }, analyticsRows() { effects += 1; return []; }, toastMsg() { effects += 1; },
    today: () => '2026-01-01', csv: () => '', window: { CFG: {}, location: {} }, encodeURIComponent
  });
  for (const name of ['exportAnalytics', 'exportLowStock', 'exportLowStockExcel', 'exportLowStockPdf', 'emailLowStock']) ctx[name]();
  assert.equal(effects, 0);
});

// 71 — the BI Dashboard should render one card-wrapped anomaly table only.
test('P19-F01 BI dashboard renders one Shank Usage Anomalies table inside one card', () => {
  const body = extractFunction(cm, 'biDashboard');
  assert.equal((body.match(/Shank Usage Anomalies — Explanation/g) || []).length, 1);
  assert.equal((body.match(/anomalyRows, 'No usage anomalies detected in the selected period\.'/g) || []).length, 1);
  assert.match(body, /<div class="card"><div class="card-hd">Shank Usage Anomalies — Explanation<\/div>[\s\S]*?anomalyRows[\s\S]*?<\/div><div class="card cm-critical-awareness">/);
});

// 72 — historical usage uses the same active Part No. and Station filters.
test('P19-F02 historical usage in period honors the active BI part and station filters', () => {
  const body = extractFunction(cm, 'biDashboard');
  const historical = body.match(/consumptionRows\(\)\.filter\(r => r\.historical[\s\S]*?\),'Historical Usage in Period'\)/)?.[0];
  assert.ok(historical, 'historical usage metric is computed from a filtered source');
  assert.match(historical, /partQuery/);
  assert.match(historical, /stationQuery/);
  assert.match(historical, /r\.historical/);
});

// 73 — pooled available quantity must be derived from filtered BI partRows.
test('P19-F03 pooled available quantity is summed from the active filtered BI rows', () => {
  const body = extractFunction(cm, 'biDashboard');
  assert.match(body, /\.filter\(x => \(!partQuery[\s\S]*?!stationQuery[\s\S]*?\)\.sort/);
  assert.match(body, /cardMetric\(partRows\.reduce\(\(sum, x\) => sum \+ x\.quantity, 0\),'Pooled Available Qty'\)/);
});

// 74 — BI Usage Period controls procurement/risk/forecast calculations.
test('P19-F04 BI period is passed through procurement and forecast calculations', () => {
  const body = extractFunction(cm, 'biDashboard');
  const procurement = extractFunction(cm, 'procurementRows');
  assert.match(body, /const period = Number\(sel\('cm-bi-period'\) \|\| 90\)/);
  assert.match(body, /procurementRows\(period\)/);
  assert.match(body, /shankBIForecastRows\(proc, partRows, period\)/);
  assert.match(procurement, /function procurementRows\(periodOverride\)/);
  assert.match(procurement, /Number\(periodOverride \|\| document\.getElementById\('cm-p-period'\)/);
});

// 75 — both history export formats preserve old and new part identities.
test('P20-F01 History Excel and PDF exports include Old Part No. and New Part No.', () => {
  const captured = {};
  const ctx = context(cm, ['exportHistoryExcel', 'exportHistoryPdf'], {
    historyExportRows: () => [{ date: '2026-01-01', oldPartNo: 'OLD-1', newPartNo: 'NEW-2', quantity: 1 }],
    exportExcel: (...args) => { captured.excel = args; }, exportPdfTable: (...args) => { captured.pdf = args; }, today: () => '2026-01-01'
  });
  ctx.exportHistoryExcel(); ctx.exportHistoryPdf();
  for (const [format, headerIndex, rowsIndex] of [['excel', 2, 3], ['pdf', 1, 2]]) {
    const args = captured[format];
    assert.ok(args[headerIndex].includes('Old Part No.'));
    assert.ok(args[headerIndex].includes('New Part No.'));
    assert.equal(args[rowsIndex][0][args[headerIndex].indexOf('Old Part No.')], 'OLD-1');
    assert.equal(args[rowsIndex][0][args[headerIndex].indexOf('New Part No.')], 'NEW-2');
  }
});

// 76 — ambiguous Part/Station/Gun matches must not be labeled MATCHED.
test('P20-F02 ambiguous historical Part–Station–Gun mapping is classified AMBIGUOUS', () => {
  const ctx = context(cm, ['replacementMappingStatus'], {
    replacementImportNormalize: value => String(value || ''), normalGunReference: value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, ''),
    partKey: value => String(value || '').toLowerCase(), sameStation: (a, b) => String(a).toLowerCase() === String(b).toLowerCase(),
    state: { mappings: [
      { partNo: 'P-1', stationNo: 'Press 1', gunReferenceNo: 'G-1', position: 'Fix Shank' },
      { partNo: 'P-1', stationNo: 'Press 1', gunReferenceNo: 'G-1', position: 'Moving Shank' }
    ] }
  });
  assert.equal(ctx.replacementMappingStatus({ partNo: 'P-1', stationNo: 'Press 1', gunReferenceNo: 'G-1', componentType: '' }), 'AMBIGUOUS');
});

// 77 — Add Maintenance Person modal fields must provide visible accessible labels.
test('P20-F03 Add Maintenance Person passes visible labels to both input dialogs', async () => {
  const prompts = [];
  const ctx = context(cm, ['addPerson'], {
    canComponent: () => true,
    componentInputDialog: async (...args) => { prompts.push(args); return null; }
  });
  await ctx.addPerson();
  assert.deepEqual(JSON.parse(JSON.stringify(prompts)), [
    ['Maintenance Person name', 'Maintenance Person name'],
    ['Maintenance Team / Department', 'Maintenance Team / Department']
  ]);
});

// 78 — nested Low/Zero Stock exports must use the displayed mode and current filters.
test('P21-F01 stock exports are scoped to active alert mode and filters', () => {
  const candidates = [
    { partNo: 'ABC-1', binId: 'BIN-A', stationNo: 'Press 1', quantity: 0, status: 'OUT OF STOCK', grouped: true },
    { partNo: 'XYZ-2', binId: 'BIN-B', stationNo: 'Press 2', quantity: 2, status: 'LOW STOCK', grouped: true }
  ];
  const ctx = context(cm, ['stockRowsForExport'], {
    window: { componentStockViewMode: 'status' }, state: { stock: [], bins: [] },
    stockRowsForView: () => [], stockStatusRows: () => candidates, sortStockStatusRows: rows => rows,
    cmSearchValue: id => id === 'cm-stock-part-search' ? 'XYZ' : '', partByNo: () => ({ componentType: 'Shank' }),
    cmMatch: (value, query) => !query || String(value || '').toLowerCase().includes(query.toLowerCase()), sameStation: () => false,
    autoSafetyQuantity: () => 0, statusFor: () => 'NORMAL'
  });
  assert.deepEqual(JSON.parse(JSON.stringify(ctx.stockRowsForExport().map(row => row.partNo))), ['XYZ-2']);
});

// 79 — blank Remaining Qty must be rejected before any stock decrement is recorded.
test('P22-F01 blank required Remaining Qty is rejected without changing stock', async () => {
  const errors = []; let writes = 0;
  const values = { 'cm-manual-part': 'P-1', 'cm-manual-bin': 'BIN-1', 'cm-manual-remaining': '' };
  const ctx = context(cm, ['saveManualStockAdjustment'], {
    canComponent: () => true, vendorPartNo: value => String(value || ''), val: id => values[id],
    stockFor: () => ({ quantity: 9 }), partByNo: () => ({ partNo: 'P-1' }), toastMsg: (message, kind) => errors.push([message, kind]),
    changeStock: async () => { writes += 1; }, state: { bins: [] }, isPencilPart: () => false,
    receiveMappedBinOptions: () => [], load: async () => {}, stock() {},
  });
  await ctx.saveManualStockAdjustment();
  assert.equal(writes, 0);
  assert.equal(errors.length, 1);
  assert.equal(errors[0][1], 'er');
});

// 80 — the visible Search Part No. label must be associated with its control.
test('P23-F01 Types of Shank Search Part No. label is programmatically associated', () => {
  let rendered = '';
  const ctx = context(cm, ['typesOfShank'], {
    uniqueShankPartNumbers: () => ['P-1'], partUsageComment: () => '', esc: value => String(value),
    shell: (_title, body) => { rendered = body; }, btn: () => ''
  });
  ctx.typesOfShank();
  assert.match(rendered, /<label class="fl" for="cm-types-shank-search">Search Part No\.<\/label>/);
  assert.match(rendered, /<input class="fi" id="cm-types-shank-search"/);
});
