const fs = require('fs');
const html = fs.readFileSync(require('path').join(__dirname, '..', 'index.html'), 'utf8');
for (const token of [
  's-ai-assistants',
  'ai-chat-question',
  'ai-run-audit',
  'ai-rc-part',
  'modules/aiAssistants.js',
]) {
  if (!html.includes(token)) throw new Error(`missing ${token}`);
}
console.log('AI HTML wiring check passed');
