const ExcelJS = require('exceljs');
const { BulkImportManager } = require('../modules/bulkImport');

describe('BulkImportManager production import paths', () => {
  test('parses the first Excel worksheet through ExcelJS fallback', async () => {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Materials');
    sheet.addRow(['barcode', 'name', 'category']);
    sheet.addRow(['B-001', 'Bolt', 'Hardware']);
    const rows = await new BulkImportManager().parseExcel(await workbook.xlsx.writeBuffer(), { sheetName: 'Materials' });
    expect(rows).toEqual([{ barcode: 'B-001', name: 'Bolt', category: 'Hardware' }]);
  });

  test('applies schema defaults and skips repeated unique values in one batch', async () => {
    const manager = new BulkImportManager();
    const written = [];
    global.gAll = jest.fn(async () => []);
    global.dPut = jest.fn(async (_store, item) => written.push(item));
    const result = await manager.importData('materials', [
      { barcode: 'B-001', name: 'Bolt', category: 'Hardware', unit: 'pcs', currentStock: 1 },
      { barcode: 'B-001', name: 'Bolt duplicate', category: 'Hardware', unit: 'pcs', currentStock: 2 },
    ]);
    expect(result.success).toBe(1);
    expect(result.skipped).toHaveLength(1);
    expect(written[0].active).toBe(true);
  });
});
