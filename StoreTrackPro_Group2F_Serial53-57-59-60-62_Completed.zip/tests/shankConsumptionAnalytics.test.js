const analytics = require('../modules/shankConsumptionAnalytics.js');

describe('Shank Consumption Analytics', () => {
  const replacements = [
    {
      partNo: 'SH-5299',
      quantity: 4,
      replacementDate: '2026-08-20',
      stationNo: 'FFA-10',
      gunReferenceNo: 'G1',
      shift: '1st Shift',
      type: 'Replacement / Issue',
    },
    {
      partNo: 'SH-5299',
      quantity: 7,
      replacementDate: '2026-08-19',
      stationNo: 'RFA-20',
      gunReferenceNo: 'G2',
      shift: '2nd Shift',
      type: 'Replacement / Issue',
    },
    {
      partNo: 'SH-5299',
      quantity: 5,
      replacementDate: '2026-08-18',
      stationNo: 'RFA-30',
      gunReferenceNo: 'G3',
      shift: '3rd Shift',
      type: 'Replacement / Issue',
    },
    {
      partNo: 'SH-5299',
      quantity: 100,
      replacementDate: '2026-08-20',
      stationNo: 'FFA-10',
      type: 'Receive',
    },
    {
      partNo: 'SH-5299',
      quantity: 20,
      replacementDate: '2026-08-20',
      stationNo: 'FFA-10',
      type: 'Repair Return',
    },
    {
      partNo: 'SH-5299',
      quantity: 2,
      replacementDate: '2026-08-20',
      stationNo: 'FFA-10',
      type: 'Scrap',
    },
    {
      partNo: 'SH-5299',
      quantity: 3,
      replacementDate: '2026-08-20',
      stationNo: 'FFA-10',
      type: 'Adjustment',
    },
  ];

  test('counts only replacement transactions in rolling consumption windows', () => {
    const row = analytics.calculateConsumption(replacements, {
      end: '2026-08-20',
      periodDays: 90,
    })[0];
    expect(row.totalConsumption).toBe(16);
    expect(row.last7Days).toBe(16);
    expect(row.last30Days).toBe(16);
    expect(row.last60Days).toBe(16);
    expect(row.last90Days).toBe(16);
    expect(row.averageDailyUsage).toBeCloseTo(16 / 90);
    expect(row.averageMonthlyUsage).toBeCloseTo(16 / 3);
  });

  test('calculates actual shift and station quantities', () => {
    const row = analytics.calculateConsumption(replacements, {
      end: '2026-08-20',
      periodDays: 90,
    })[0];
    expect(row.shifts).toEqual({ '1st Shift': 4, '2nd Shift': 7, '3rd Shift': 5 });
    expect(row.stations).toEqual({ 'FFA-10': 4, 'RFA-20': 7, 'RFA-30': 5 });
  });

  test('calculates reorder point and stock-out risk with configurable lead time and safety stock', () => {
    const rows = analytics.calculateForecast({
      today: '2026-08-20',
      parts: [
        { partNo: 'SH-5299', minimumStock: 2, analytics: { leadTimeDays: 60, safetyStockQty: 5 } },
      ],
      occurrenceByPart: { 'SH-5299': 5 },
      stock: [{ partNo: 'SH-5299', quantity: 8 }],
      replacements,
      periodDays: 90,
    });
    expect(rows[0].reorderPoint).toBeCloseTo((16 / 90) * 90 + 5);
    expect(rows[0].expectedDaysUntilZero).toBeCloseTo(8 / (16 / 90));
    expect(rows[0].status).toBe('STOCK-OUT RISK');
  });

  test('uses critical risk priority and does not project zero date for zero usage', () => {
    const rows = analytics.calculateForecast({
      today: '2026-08-20',
      parts: [{ partNo: 'ZERO' }, { partNo: 'EMPTY' }],
      stock: [
        { partNo: 'ZERO', quantity: 0 },
        { partNo: 'EMPTY', quantity: 10 },
      ],
      replacements: [],
    });
    expect(rows.find((row) => row.partNo === 'ZERO')).toMatchObject({
      status: 'ZERO STOCK',
      expectedZeroDate: null,
      insufficientData: true,
    });
    expect(rows.find((row) => row.partNo === 'EMPTY')).toMatchObject({
      status: 'OK STOCK',
      stockStatus: 'OK STOCK',
      forecastStatus: 'NO DATA',
      expectedZeroDate: null,
    });
  });

  test('builds running transaction balances for the why-is-stock-low drill-down', () => {
    const rows = analytics.transactionDrillDown(
      [
        { partNo: 'A', type: 'Receive', quantity: 10, date: '2026-08-01' },
        { partNo: 'A', type: 'Replacement / Issue', quantity: 3, date: '2026-08-02' },
        { partNo: 'A', type: 'Repair Return', quantity: 1, date: '2026-08-03' },
        { partNo: 'A', type: 'Scrap', quantity: 2, date: '2026-08-04' },
      ],
      'A',
    );
    expect(rows.map((row) => row.runningBalance)).toEqual([10, 7, 8, 6]);
  });

  test('ORDER NOW contains only actionable risk statuses in severity order', () => {
    const rows = analytics.orderNowRows({
      today: '2026-08-20',
      parts: [{ partNo: 'A' }, { partNo: 'B' }],
      stock: [
        { partNo: 'A', quantity: 0 },
        { partNo: 'B', quantity: 10 },
      ],
      replacements: [],
    });
    expect(rows.map((row) => row.status)).toEqual(['ZERO STOCK']);
  });
});

describe('Shank Consumption Analytics enhancement regressions', () => {
  test('applies default configuration and preserves explicit per-part overrides', () => {
    const rows = analytics.calculateForecast({
      today: '2026-08-20',
      config: { leadTimeDays: 30, safetyStockDays: 2, usagePeriodDays: 30 },
      parts: [
        { partNo: 'DEFAULT' },
        { partNo: 'OVERRIDE', analytics: { leadTimeDays: 5, safetyStockQty: 4 } },
      ],
      stock: [
        { partNo: 'DEFAULT', quantity: 10 },
        { partNo: 'OVERRIDE', quantity: 10 },
      ],
      replacements: [],
    });
    expect(rows.find((row) => row.partNo === 'DEFAULT')).toMatchObject({
      leadTimeDays: 60,
      safetyStockQty: 0,
      internalProcurementDays: 30,
    });
    expect(rows.find((row) => row.partNo === 'OVERRIDE')).toMatchObject({
      leadTimeDays: 35,
      safetyStockQty: 0,
      internalProcurementDays: 30,
    });
  });

  test('marks missing consumption history as insufficient data instead of inventing usage', () => {
    const rows = analytics.calculateConsumption(
      [
        {
          partNo: 'OTHER',
          quantity: 9,
          replacementDate: '2026-08-20',
          type: 'Replacement / Issue',
        },
      ],
      { end: '2026-08-20', periodDays: 30 },
    );
    expect(rows.find((row) => row.partNo === 'OTHER')).toMatchObject({
      totalConsumption: 9,
      insufficientData: false,
    });
    expect(analytics.calculateConsumption([], { end: '2026-08-20', periodDays: 30 })).toEqual([]);
  });

  test('keeps shift and station quantities attributable to the replacement source rows', () => {
    const rows = analytics.calculateConsumption(
      [
        {
          partNo: 'A',
          quantity: 2,
          replacementDate: '2026-08-20',
          stationNo: 'FFA 10',
          shift: '1st Shift',
          type: 'Replacement / Issue',
        },
        {
          partNo: 'A',
          quantity: 3,
          replacementDate: '2026-08-20',
          stationNo: 'FFA-10',
          shift: '2nd Shift',
          type: 'Replacement / Issue',
        },
      ],
      { end: '2026-08-20', periodDays: 30 },
    );
    expect(rows[0].shifts).toEqual({ '1st Shift': 2, '2nd Shift': 3, '3rd Shift': 0 });
    expect(rows[0].stations).toEqual({ 'FFA 10': 2, 'FFA-10': 3 });
  });
});

describe('Shank Consumption Analytics production hardening', () => {
  test('returns per-Part Critical Flag and preserves override values', () => {
    const rows = analytics.calculateForecast({
      today: '2026-08-20',
      parts: [
        {
          partNo: 'CRIT-1',
          analytics: { leadTimeDays: 12, safetyStockQty: 7, criticalFlag: true },
        },
      ],
      occurrenceByPart: { 'CRIT-1': 7 },
      stock: [{ partNo: 'CRIT-1', quantity: 4 }],
      replacements: [
        {
          partNo: 'CRIT-1',
          quantity: 2,
          replacementDate: '2026-08-20',
          type: 'Replacement / Issue',
        },
      ],
    });
    expect(rows[0]).toMatchObject({
      leadTimeDays: 42,
      safetyStockQty: 7,
      occurrenceQty: 7,
      criticalFlag: true,
    });
  });

  test('uses occurrence count as safety qty and classifies confidence by unique usage days', () => {
    const rows = analytics.calculateForecast({
      today: '2026-08-20',
      parts: [{ partNo: 'OCC-1' }],
      occurrenceByPart: { 'OCC-1': 5 },
      stock: [{ partNo: 'OCC-1', quantity: 5 }],
      replacements: [
        {
          partNo: 'OCC-1',
          quantity: 1,
          replacementDate: '2026-08-20',
          type: 'Replacement / Issue',
        },
        {
          partNo: 'OCC-1',
          quantity: 2,
          replacementDate: '2026-08-20',
          type: 'Replacement / Issue',
        },
      ],
    });
    expect(rows[0]).toMatchObject({
      occurrenceQty: 5,
      safetyStockQty: 5,
      usageDays: 1,
      usageConfidence: 'LOW',
      status: 'LOW STOCK',
    });
  });

  test('pools occurrence and safety-stock counts across Part Number variants', () => {
    const rows = analytics.calculateForecast({
      today: '2026-09-03',
      parts: [{ partNo: '07-526/98' }, { partNo: '07-0526/98' }],
      occurrenceByPart: { '07-526/98': 2, '07-0526/98': 3 },
      stock: [{ partNo: '07-526/98', quantity: 10 }],
      replacements: [],
    });
    expect(rows).toHaveLength(1);
    expect(rows[0].occurrenceQty).toBe(5);
    expect(rows[0].safetyStockQty).toBe(5);
  });

  test('marks low-history forecasts LOW confidence and detects abnormal recent usage', () => {
    const rows = analytics.calculateForecast({
      today: '2026-08-20',
      parts: [{ partNo: 'SPIKE' }],
      stock: [{ partNo: 'SPIKE', quantity: 10 }],
      replacements: [
        {
          partNo: 'SPIKE',
          quantity: 100,
          replacementDate: '2026-08-20',
          type: 'Replacement / Issue',
        },
      ],
      periodDays: 90,
    });
    expect(rows[0].usageConfidence).toBe('LOW');
    expect(rows[0].abnormalConsumption).toBe(true);
  });
});

module.exports = {};

/* global analytics */

describe('Shank Consumption Analytics UI runtime contract', () => {
  const fs = require('fs');
  const path = require('path');
  test('analytics UI defines a local esc helper for all HTML renderers', () => {
    const source = fs.readFileSync(
      path.join(__dirname, '..', 'modules', 'shankConsumptionAnalyticsUI.js'),
      'utf8',
    );
    expect(source).toContain('const esc = value =>');
    expect(source).toContain('${esc(row.partNo)}');
    expect(source).toContain('${esc(status.stationNo)}');
  });
});
