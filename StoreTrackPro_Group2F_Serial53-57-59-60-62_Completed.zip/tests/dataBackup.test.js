const fs = require('fs');
const path = require('path');

describe('complete StoreTrack Pro backup', () => {
  const root = path.join(__dirname, '..');
  const backup = fs.readFileSync(path.join(root, 'modules', 'dataBackup.js'), 'utf8');
  const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
  const main = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
  const preload = fs.readFileSync(path.join(root, 'preload.js'), 'utf8');
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

  test('exports every IndexedDB store and validates before writing', () => {
    expect(backup).toContain('getStoreNames');
    expect(backup).toContain('StoreTrackProCompleteBackup');
    expect(backup).toContain('Object.keys(payload.stores).length > 0');
    expect(main).toContain("secureHandle('backup:write'");
    expect(main).toContain('fs.renameSync(temp, target)');
  });

  test('rotates only after successful atomic verification', () => {
    expect(main).toContain('validateCompleteBackup(decryptCompleteBackup(fs.readFileSync(temp');
    expect(main).toContain('Backup verification failed');
    expect(main).toContain('name !== fileName');
  });

  test('isolated restore testing and automated backup verification are wired', () => {
    expect(backup).toContain('async function runIsolatedRestoreTest(payload)');
    expect(backup).toContain('indexedDB.deleteDatabase(testDbName)');
    expect(backup).toContain('await runIsolatedRestoreTest(payload)');
    expect(backup).toContain('automatic-after-backup');
    expect(backup).toContain('automatic-before-portable-export');
    expect(backup).toContain('Retained backup integrity');
    expect(backup).toContain('Preserve current store (not in backup)');
  });

  test('backup discovery matches date-stamped filenames', () => {
    expect(main).toContain('/^StoreTrackPro-backup-\\d{4}-\\d{2}-\\d{2}\\.json$/');
    expect(main.match(/\^StoreTrackPro-backup-/g)).toHaveLength(3);
  });

  test('portable backups embed a recovery key and can be imported without the local key', () => {
    expect(main).toContain("secureHandle('backup:exportPortable'");
    expect(main).toContain("secureHandle('backup:decryptPortable'");
    expect(main).toContain('portableKey: key.toString');
    expect(main).toContain('decryptBackup(envelope, key)');
    expect(preload).toContain("ipcRenderer.invoke('backup:exportPortable', serialized)");
    expect(preload).toContain("ipcRenderer.invoke('backup:decryptPortable', serialized)");
    expect(backup).toContain('Create Backup for Any Windows PC (portable JSON)');
    expect(backup).toContain('Import Backup from Another PC');
    expect(backup).toContain('restoreBackup(reader.result, file.name)');
    expect(backup).toContain('anyone with this file can decrypt and restore its data');
    expect(backup).toContain('Daily backups use authenticated AES-256-GCM encryption');
    expect(backup).toContain('are for this PC only');
    expect(main).toContain('cannot be restored on this PC');
    expect(main).toContain('choose “Create Backup for Any Windows PC (portable JSON)”');
  });

  test('restore and status bridges are wired', () => {
    expect(preload).toContain("exposeInMainWorld('backupBridge'");
    expect(preload).toContain("ipcRenderer.invoke('backup:read')");
    expect(preload).toContain("ipcRenderer.invoke('backup:status')");
    expect(preload).toContain("ipcRenderer.invoke('backup:openFolder')");
    expect(backup).toContain('Backup file created');
    expect(backup).toContain('Open Backup Folder');
    expect(backup).toContain('Copy Backup Path');
    expect(backup).toContain('Restore Latest Backup');
    expect(backup).toContain('component-management-content');
    expect(backup).toContain('await dClr(name)');
  });

  test('legacy Restore JSON accepts complete backup files with format and stores', () => {
    expect(app).toContain("data.format === 'StoreTrackProCompleteBackup'");
    expect(app).toContain('Object.entries(data.stores)');
    expect(app).toContain('await window.componentRestoreBackupData(data.stores)');
    expect(app).toContain("toast('Complete StoreTrack Pro backup restored!')");
  });

  test('Settings JSON Backup does not depend on unsupported prompt()', () => {
    const exportFn = app.slice(
      app.indexOf('async function exportBackup()'),
      app.indexOf('async function importBackup('),
    );
    expect(exportFn).not.toContain("prompt('Do you want to password-protect");
    expect(exportFn).toContain('const fileBody=plainText');
  });

  test('daily backup starts after database readiness and Windows setup exists', () => {
    expect(html).toContain('modules/dataBackup.js');
    expect(fs.readFileSync(path.join(root, 'app.js'), 'utf8')).toContain(
      'startStoreTrackDailyBackup',
    );
    expect(fs.existsSync(path.join(root, 'setup-daily-backup.bat'))).toBe(true);
    expect(fs.existsSync(path.join(root, 'run-daily-backup.bat'))).toBe(true);
  });
});
