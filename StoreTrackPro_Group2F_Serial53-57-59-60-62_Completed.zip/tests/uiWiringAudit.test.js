const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const uiSource = [
  'index.html',
  'app.js',
  ...fs
    .readdirSync(path.join(root, 'modules'))
    .filter((file) => file.endsWith('.js'))
    .map((file) => path.join('modules', file)),
]
  .map((file) => fs.readFileSync(path.join(root, file), 'utf8'))
  .join('\n');
const componentSource = [
  fs.readFileSync(path.join(root, 'app.js'), 'utf8'),
  ...fs
    .readdirSync(path.join(root, 'modules'))
    .filter((file) => file.endsWith('.js'))
    .map((file) => fs.readFileSync(path.join(root, 'modules', file), 'utf8')),
].join('\n');

function namesFrom(pattern, source) {
  return [...source.matchAll(pattern)].map((match) => match[1]).filter(Boolean);
}

test('all component-prefixed UI handlers resolve to a declaration or window export', () => {
  const used = new Set(namesFrom(/\b(component[A-Z][A-Za-z0-9_]*)\s*\(/g, uiSource));
  const declared = new Set([
    ...namesFrom(/\bfunction\s+(component[A-Z][A-Za-z0-9_]*)\s*\(/g, componentSource),
    ...namesFrom(/\bwindow\.(component[A-Z][A-Za-z0-9_]*)\s*=\s*/g, componentSource),
  ]);
  const missing = [...used].filter((name) => !declared.has(name));
  expect(missing).toEqual([]);
});

test('Parts Master Save Part action is reachable from the Parts Master renderer', () => {
  const partsBlock = componentSource.match(/function parts\(\)[\s\S]*?async function savePart/)[0];
  expect(partsBlock).toContain("btn('Save Part', 'componentSavePart()', true)");
  expect(componentSource).toContain('window.componentSavePart = savePart');
});
