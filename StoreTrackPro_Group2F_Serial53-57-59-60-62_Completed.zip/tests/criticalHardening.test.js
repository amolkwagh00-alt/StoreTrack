const { signToken, verifyToken, revokeToken } = require('../server/auth');
const { eventVisibleToUser } = require('../server/index');

describe('critical hardening', () => {
  test('revoked JWT is rejected', () => {
    const token = signToken({ sub: 'user-1', role: 'viewer' }, 60);
    expect(verifyToken(token).sub).toBe('user-1');
    revokeToken(token);
    expect(() => verifyToken(token)).toThrow('Token revoked');
  });

  test('scoped event is hidden from another site and visible to matching site', () => {
    const event = { payload: { siteId: 'SITE-A' } };
    expect(eventVisibleToUser(event, { siteId: 'SITE-A' })).toBe(true);
    expect(eventVisibleToUser(event, { siteId: 'SITE-B' })).toBe(false);
  });

  test('legacy single-site events remain visible when no scope exists', () => {
    expect(
      eventVisibleToUser({ payload: { transaction: { id: 'tx-1' } } }, { siteId: 'SITE-A' }),
    ).toBe(true);
  });

  test('scoped event is hidden when authenticated user has no matching scope', () => {
    expect(eventVisibleToUser({ payload: { siteId: 'SITE-A' } }, { role: 'viewer' })).toBe(false);
  });

  test('all supplied scopes must match', () => {
    const event = { payload: { tenantId: 'T1', siteId: 'SITE-A' } };
    expect(eventVisibleToUser(event, { tenantId: 'T1', siteId: 'SITE-A' })).toBe(true);
    expect(eventVisibleToUser(event, { tenantId: 'T1', siteId: 'SITE-B' })).toBe(false);
    expect(eventVisibleToUser(event, { tenantId: 'T2', siteId: 'SITE-A' })).toBe(false);
  });
});
