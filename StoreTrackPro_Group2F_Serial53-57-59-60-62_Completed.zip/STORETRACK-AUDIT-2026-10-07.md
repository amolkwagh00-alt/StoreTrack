# StoreTrack Full Project Audit — 2026-10-07

## Nikal
Ha code-level audit ani targeted hardening zala aahe; **“100% bug-free” asa guarantee deta yet nahi**. Production PostgreSQL/JWT configuration ya sandbox madhye navhati, mhanun central server, real multi-user requests, restore drill, ani Windows/Electron hardware paths runtime madhye verify kele nahit. Project tree madhye `.git` history pan nahi, tyamule bug kadhicha introduce zala he tharavta ale nahi.

## Ya audit madhye keleli fixes

- **Replacement mapping/bin:** RH/LH merged Common Bin mapping canonical bin shi resolve hote; mapping madhye bin ID missing asel tar validation ata fail hote.
- **Replacement imports:** Old Part No. preview/edit field ani import header mapping add kele. Gun references normalize karun Old Part inference hote; ambiguity asel tar inference fail hote. Live import New Part No. la chupchap Old Part mhanun vaprat nahi. Repair/Scrap sathi Old Part component catalogue kiwa mapping madhye asane avashyak.
- **Replacement atomicity:** Stock, stock transaction, replacement entry, lifecycle row, ani internal audit ekach DB transaction madhye commit hotat. Failure zalyas in-memory stock/state mutate hot nahi.
- **Historical consumption:** File ani manual historical entry + audit atomic; historical mode stock deduct karat nahi. Unique mapping sapadlyas imported component type mapping madhun canonicalize hoto, ani invalid calendar dates reject hotat.
- **Physical stock verification:** Saglya rows/quantity/reasons pahile validate hotat; nantar stock, transaction, audit ekach transaction madhye save hotat.
- **Repair lifecycle:** Repair completion status + audit atomic; Repair Return cha atomic stock/lifecycle/audit flow ani Old/New Part identity checks rahatat.
- **RH/LH reconciliation:** Fakt source/canonical known Bin IDs aslele transactions relocate hotat; station same aahe evadhyavarun dusrya bin che transaction badalat nahit.
- **Bin Location movement:** Invalid quantity la blank/all-stock samajle jat nahi; partial movement reject hote (current data model item la ekach bin store karto). Material location + movement history atomic save; assigned bin delete block; location suggestions startup la populate hotat.
- **Output safety:** Location, movement ani print-report madhil user-controlled text escape kele.
- **Background Sync:** Fake upload/download/sync success ata report hot nahi; remote adapter nasel tar explicit failure. App che concurrency config yogya pane initialize hote.
- **Service worker:** `/api/` GET responses Cache Storage madhye cache hot nahit, mhanun offline/account switch nantar URL-var adharit dusrya user cha cached response deny hot nahi.
- **Plaintext backup warning:** Settings madhun full JSON export ajun encrypted nahi; export aadhi sensitive-data warning/confirmation, JSON note, toast ani audit text add kele.

## Chachnya

- `npm test -- --runInBand`: **37 suites, 383 tests pass**.
- `npm run test:smoke`: pass — 80 HTML module references, 96 JS parse checks.
- `npm run release:check`: pass.
- JavaScript syntax checks: pass.
- `npm run lint`: **0 errors, 115 warnings** (style warnings; repository madhye adhipasun aslelya compact-code warnings suddha samavisht).
- `npm audit --omit=dev --audit-level=high`: production tree madhye **3 moderate advisories** (`mammoth → argparse → sprintf-js`). StoreTrack Mammoth cha document-conversion API vaparto, CLI nahi; audit nusar vulnerable argparse CLI path vaparla jat nahi. Npm-cha suggested fix breaking `mammoth@0.3.29` downgrade aahe, mhanun dependency na badalta ha advisory open thevla.
- `npm run production:validate`: 5 pass; 2 environment-config blockers — `STORETRACK_JWT_SECRET` ani `DATABASE_URL`/`PGHOST` set nahi.

## Ajun open / separate remediation pahije

1. **Central idempotency user-scoped nahi (Medium, security/data correctness):** `idempotency_keys.key` ekta primary key aahe; lookup authenticated `user_id` ne scope hot nahi. Cross-user key reuse mule cached response dusrya user la parat milu shakto kiwa operation suppress hou shakto. Schema migration + server tests + PostgreSQL verification avashyak; ithe production DB naslyane change apply/test kele nahi.
2. **Central sync migration partial hoऊ shakte (Medium):** client materials ek-ek request ne sync karto; madhye error zala tar aadhi save zalele remote rows rollback/checkpoint hot nahit. API-level batch/transaction/idempotency design avashyak.
3. **Background Sync feature ajun real remote adapter shivay unavailable aahe:** fake success band kele; `backgroundSync` operations ata explicit error detat. `centralSync` ha vegla path aahe, pan tyachi migration partial-write limitation varil pramane open aahe.
4. **Full JSON backup plaintext aahe:** warning/confirmation add keli, pan encryption implement keleli nahi. Password-protected backup format/restore compatibility sathi product decision ani migration tests pahijet.
5. **Backup restore/reconciliation sampurna atomic nahi:** component backup restore ani RH/LH bin/stock/mapping reconciliation anek writes madhye hotat; process madhye crash/DB error zala tar partial state rahu shakto. Ya audit madhye unrelated transaction rewrites rokale, pan sarva reconciliation operations transaction madhye migrate kele nahit.
6. **PWA offline behavior:** privacy sathi API caching band aahe. `/api/` calls offline astana cached response deny honar nahi; offline API experience pahije asel tar user-scoped cache/auth invalidation design lagel.
7. **Dependency advisory open aahe:** Mammoth transitive moderate finding la breaking dependency change vina fix karta ali nahi.

## Production readiness

Code-level Jest/smoke/release checks pass zalyat. Pan central-server production verification **blocked** aahe karan sandbox madhye `STORETRACK_JWT_SECRET` ani PostgreSQL `DATABASE_URL`/`PGHOST` configure navhate. Mhanun he deliverable hardening + audit aahe; live production certification nahi.
