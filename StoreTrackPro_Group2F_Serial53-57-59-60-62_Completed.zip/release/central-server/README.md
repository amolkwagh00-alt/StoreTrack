# StoreTrack Pro Central Server Bundle

Deploy this bundle separately from the Electron installer. Copy server/.env.example to server/.env, set strong secrets, run migrations, and start the Node service or Docker Compose. Never commit .env or production data backups.
