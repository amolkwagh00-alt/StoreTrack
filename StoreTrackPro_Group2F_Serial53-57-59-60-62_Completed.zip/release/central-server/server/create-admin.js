require('dotenv').config({ path: require('path').join(__dirname, '.env') });
const crypto = require('crypto');
const { pool, migrate } = require('./db');
const { hashPassword } = require('./auth');

(async () => {
  const username = String(process.env.ADMIN_USERNAME || process.argv[2] || '')
    .trim()
    .toLowerCase();
  const password = process.env.ADMIN_PASSWORD || process.argv[3];
  const name = process.env.ADMIN_NAME || 'Administrator';
  if (!username || !password || password.length < 8)
    throw new Error('Provide username and an administrator password of at least 8 characters');
  await migrate();
  await pool.query(
    "INSERT INTO app_users(id, username, display_name, password_hash, role) VALUES($1,$2,$3,$4,'admin') ON CONFLICT (username) DO UPDATE SET display_name=EXCLUDED.display_name, password_hash=EXCLUDED.password_hash, role='admin', active=TRUE, session_version=app_users.session_version+1, updated_at=NOW()",
    [crypto.randomUUID(), username, name, await hashPassword(password)],
  );
  console.log(`Central administrator '${username}' is ready.`);
  await pool.end();
})().catch(async (error) => {
  console.error(error.message);
  await pool.end();
  process.exitCode = 1;
});
