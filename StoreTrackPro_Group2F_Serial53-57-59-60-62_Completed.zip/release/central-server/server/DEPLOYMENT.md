# StoreTrack Pro V8 Central Deployment
> **Repository alignment (2026-09-19):** This documentation is aligned with the security-fixed and performance-tuned StoreTrack Central Server build. Target Windows certificate, firewall, ACL, backup-restore, and hardware validation remain deployment-site checks.


## Recommended production topology

Run one PostgreSQL instance and one StoreTrack API on a Windows Server or protected Linux host in the LAN. Install the Electron client on each workstation. Every client keeps an IndexedDB cache for fast UI access and offline queueing, but confirmed stock changes are committed to PostgreSQL through the API. Production client traffic should use HTTPS through a trusted reverse proxy. PostgreSQL is the source of truth.

```text
PC-1 Electron ─┐
PC-2 Electron ─┼── HTTPS/WebSocket ── StoreTrack API ── PostgreSQL
PC-3 Electron ─┘                         │
                                         └── audit + sync event log
```

## Windows Server / LAN deployment

Install Node.js 22 LTS and PostgreSQL 16 on the server. Copy the project or a server-only release bundle to `C:\StoreTrackPro`. Create `server\.env` from `server\.env.example` and set a unique database password and a random JWT secret of at least 32 characters. Allow inbound TCP `8787` only from the store LAN, and allow PostgreSQL TCP `5432` only from the local server unless a separate database host is intentionally used.

Run the following in an elevated Command Prompt from the project directory:

```bat
npm ci --omit=dev
npm run central:migrate
set ADMIN_USERNAME=admin
set ADMIN_PASSWORD=replace-with-a-strong-password
npm run central:create-admin
npm run central:server
```

For a persistent Windows service, use NSSM or Windows Task Scheduler configured to restart `node server/index.js` on failure. Do not expose PostgreSQL directly to the workstations; expose only the API. If HTTPS is required, terminate TLS at IIS or a reverse proxy and set the Electron API URL to the HTTPS address. The installer defaults its API firewall rule to `LocalSubnet`; pass an explicit approved CIDR through `-FirewallRemoteAddress` when the LAN is narrower.

The Windows installer stores database backups as DPAPI LocalMachine-protected `.dump.dpapi` files. The unencrypted temporary dump is deleted after encryption. Use the generated `Restore-Database.ps1` helper on the same Windows host to decrypt and restore a backup. Perform a restore drill before production sign-off.

## Electron client configuration

Open **Settings → Central Server Synchronization**, enter the HTTPS reverse-proxy address, and select **Save & Test**. Do not configure a production client with a plaintext HTTP URL. On the next local login, the same username and password are used to obtain a central JWT. The JWT remains in the Electron main process and is never exposed to the renderer JavaScript. If the server is unavailable, local login continues and confirmed IN/OUT transactions are persisted in the `central_queue` IndexedDB store for retry.

## Optional Docker deployment

Docker is optional. It is useful when the operator already manages Docker and wants PostgreSQL and the API lifecycle isolated together. It is not required for the Electron desktop application or for a normal Windows Server/LAN deployment.

```bat
set POSTGRES_PASSWORD=replace-with-a-long-password
set STORETRACK_JWT_SECRET=replace-with-a-long-random-secret
set TRUST_PROXY_TLS=true
set CORS_ORIGIN=https://your-storetrack-client.example
set API_BIND_ADDRESS=127.0.0.1
set API_PORT=8787
docker compose -f server\docker-compose.yml up -d
docker compose -f server\docker-compose.yml exec api node server/migrate.js
docker compose -f server\docker-compose.yml exec -e ADMIN_USERNAME=admin -e ADMIN_PASSWORD=replace-with-a-strong-password api node server/create-admin.js
```

Replace `CORS_ORIGIN` with the exact HTTPS origin used by the client. `TRUST_PROXY_TLS=true` is appropriate only when the API is reached through an HTTPS reverse proxy. Compose publishes the API to `127.0.0.1:8787` by default so a reverse proxy on the Docker host can reach it without exposing plaintext API traffic to the LAN. If the reverse proxy runs on another machine, set `API_BIND_ADDRESS` to the Docker host's specific LAN address and firewall the port so only that proxy can connect; do not use `0.0.0.0` on an untrusted network.

## IndexedDB migration

From the existing Electron application, use **Settings → Backup / Restore → Export Backup** and copy the resulting JSON file to the server. Run:

```bat
npm run central:import-backup -- C:\path\to\backup.json
```

The importer upserts material master records and inserts historical IN/OUT records idempotently. It does not blindly overwrite central stock with a later local cache. After import, validate material counts and selected stock balances before allowing live transactions.

## Operational checks

Use `GET /health` from a workstation to confirm API and database reachability. Confirm that a Material IN on PC-1 changes the material on PC-2 through the WebSocket event or the 15-second incremental pull fallback. Test a simultaneous OUT against the same material; PostgreSQL row locking must allow only transactions that leave non-negative stock. Test disconnecting the server, creating an IN/OUT, restoring connectivity, and verifying the queued transaction is committed exactly once.
