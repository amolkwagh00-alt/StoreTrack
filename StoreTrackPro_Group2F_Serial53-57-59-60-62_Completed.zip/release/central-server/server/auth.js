const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const secret = process.env.STORETRACK_JWT_SECRET || '';
if (secret.length < 32 && process.env.NODE_ENV !== 'test') {
  throw new Error('STORETRACK_JWT_SECRET must be at least 32 characters outside tests');
}
const revokedTokens = new Map();

function base64url(value) {
  return Buffer.from(value)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}
function signToken(payload, ttlSeconds = 28800) {
  const now = Math.floor(Date.now() / 1000);
  const body = base64url(
    JSON.stringify({
      ...payload,
      jti: payload.jti || crypto.randomUUID(),
      iat: now,
      exp: now + ttlSeconds,
    }),
  );
  const header = base64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const signature = base64url(
    crypto.createHmac('sha256', secret).update(`${header}.${body}`).digest(),
  );
  return `${header}.${body}.${signature}`;
}
function verifyToken(token) {
  const [header, body, signature] = String(token || '').split('.');
  if (!header || !body || !signature)
    throw Object.assign(new Error('Invalid token'), { statusCode: 401 });
  const expected = base64url(
    crypto.createHmac('sha256', secret).update(`${header}.${body}`).digest(),
  );
  const provided = Buffer.from(signature);
  const expectedBuffer = Buffer.from(expected);
  if (
    provided.length !== expectedBuffer.length ||
    !crypto.timingSafeEqual(provided, expectedBuffer)
  )
    throw Object.assign(new Error('Invalid token'), { statusCode: 401 });
  let payload;
  try {
    payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
  } catch {
    throw Object.assign(new Error('Invalid token'), { statusCode: 401 });
  }
  const now = Math.floor(Date.now() / 1000);
  if (!payload.exp || payload.exp <= now)
    throw Object.assign(new Error('Token expired'), { statusCode: 401 });
  const revokedUntil = payload.jti ? revokedTokens.get(payload.jti) : null;
  if (revokedUntil && revokedUntil > now)
    throw Object.assign(new Error('Token revoked'), { statusCode: 401 });
  return payload;
}
function revokeToken(tokenOrPayload) {
  const payload =
    typeof tokenOrPayload === 'string'
      ? (() => {
          try {
            return verifyToken(tokenOrPayload);
          } catch {
            return null;
          }
        })()
      : tokenOrPayload;
  if (payload?.jti && payload.exp) revokedTokens.set(payload.jti, payload.exp);
  if (revokedTokens.size > 10000) {
    const now = Math.floor(Date.now() / 1000);
    for (const [jti, exp] of revokedTokens) if (exp <= now) revokedTokens.delete(jti);
  }
}
async function hashPassword(password) {
  if (typeof password !== 'string') throw new TypeError('Password must be a string');
  // bcrypt considers only the first 72 input bytes. Hashing to fixed-length
  // ASCII first prevents distinct long passwords from becoming equivalent.
  const prehash = `storetrack-bcrypt-sha256-v1:${crypto
    .createHash('sha256')
    .update('StoreTrack password prehash v1\0', 'utf8')
    .update(password, 'utf8')
    .digest('base64url')}`;
  return `$bcrypt-sha256$${await bcrypt.hash(prehash, 12)}`;
}
function validatePassword(password) {
  return typeof password === 'string' && password.length >= 8 && password.length <= 256;
}
async function verifyPassword(password, hash) {
  if (typeof password !== 'string' || typeof hash !== 'string') return false;
  if (hash.startsWith('$bcrypt-sha256$')) {
    const prehash = `storetrack-bcrypt-sha256-v1:${crypto
      .createHash('sha256')
      .update('StoreTrack password prehash v1\0', 'utf8')
      .update(password, 'utf8')
      .digest('base64url')}`;
    return bcrypt.compare(prehash, hash.slice('$bcrypt-sha256$'.length));
  }
  if (typeof hash === 'string' && hash.startsWith('$pbkdf2$')) {
    const [, , salt, expected] = hash.split('$');
    if (!salt || !expected) return false;
    const actual = await new Promise((resolve, reject) =>
      crypto.pbkdf2(String(password), salt, 100000, 64, 'sha512', (error, key) =>
        error ? reject(error) : resolve(key.toString('hex')),
      ),
    );
    return (
      actual.length === expected.length &&
      crypto.timingSafeEqual(Buffer.from(actual), Buffer.from(expected))
    );
  }
  return bcrypt.compare(password, hash);
}
function requireAuth(req) {
  const value = req.headers.authorization || '';
  if (!value.startsWith('Bearer '))
    throw Object.assign(new Error('Authentication required'), { statusCode: 401 });
  return verifyToken(value.slice(7));
}
function requireRole(user, roles) {
  if (!roles.includes(user.role))
    throw Object.assign(new Error('Insufficient permissions'), { statusCode: 403 });
}
module.exports = {
  signToken,
  verifyToken,
  revokeToken,
  hashPassword,
  validatePassword,
  verifyPassword,
  requireAuth,
  requireRole,
};
