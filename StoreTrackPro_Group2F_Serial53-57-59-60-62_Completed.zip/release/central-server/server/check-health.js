require('dotenv').config({ path: require('path').join(__dirname, '.env') });

const baseUrl = (process.env.CENTRAL_URL || `http://127.0.0.1:${process.env.PORT || 8787}`).replace(
  /\/$/,
  '',
);
const startedAt = process.hrtime.bigint();

fetch(`${baseUrl}/health`)
  .then(async (response) => {
    const latencyMs = Number(process.hrtime.bigint() - startedAt) / 1e6;
    const body = await response.json().catch(() => ({}));
    const result = {
      ok: response.ok,
      status: response.status,
      latencyMs: Math.round(latencyMs * 100) / 100,
      ...body,
    };
    console.log(JSON.stringify(result, null, 2));
    process.exitCode = response.ok ? 0 : 1;
  })
  .catch((error) => {
    console.error(JSON.stringify({ ok: false, error: error.message }, null, 2));
    process.exitCode = 1;
  });
