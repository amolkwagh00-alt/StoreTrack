require('dotenv').config({ path: require('path').join(__dirname, '.env') });
const http = require('http');
const https = require('https');
const fs = require('fs');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
const {
  migrate,
  pool,
  getMaterials,
  getChanges,
  toMaterial,
  commitStock,
  purgeIdempotencyKeys,
  health,
  getMigrationStatus,
  getUserSessionState,
  revokeToken: persistRevocation,
  isTokenRevoked,
} = require('./db');
const {
  signToken,
  hashPassword,
  verifyPassword,
  validatePassword,
  revokeToken,
  requireAuth,
  requireRole,
} = require('./auth');
const GunCountService = require('../core/gunCountService');

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '127.0.0.1';
const CORS_ORIGIN = process.env.CORS_ORIGIN || `http://127.0.0.1:${PORT}`;
const MAX_GUN_ROWS = Math.min(2000, Math.max(100, Number(process.env.MAX_GUN_ROWS || 2000)));
const WS_HEARTBEAT_MS = Math.max(5000, Number(process.env.WS_HEARTBEAT_MS || 30000));
const WS_MAX_BUFFERED_BYTES = Math.min(
  16 * 1024 * 1024,
  Math.max(64 * 1024, Number(process.env.WS_MAX_BUFFERED_BYTES || 1024 * 1024)),
);
const HTTP_KEEPALIVE_TIMEOUT_MS = Math.min(
  300000,
  Math.max(5000, Number(process.env.HTTP_KEEPALIVE_TIMEOUT_MS || 65000)),
);
const HTTP_HEADERS_TIMEOUT_MS = Math.min(
  310000,
  Math.max(10000, Number(process.env.HTTP_HEADERS_TIMEOUT_MS || HTTP_KEEPALIVE_TIMEOUT_MS + 1000)),
);
const HTTP_REQUEST_TIMEOUT_MS = Math.min(
  300000,
  Math.max(5000, Number(process.env.HTTP_REQUEST_TIMEOUT_MS || 30000)),
);
const IDEMPOTENCY_RETENTION_DAYS = Math.max(1, Number(process.env.IDEMPOTENCY_RETENTION_DAYS || 30));
const IDEMPOTENCY_PURGE_INTERVAL_MS = Math.max(
  60000,
  Number(process.env.IDEMPOTENCY_PURGE_INTERVAL_MS || 6 * 60 * 60 * 1000),
);
const loginAttempts = new Map();
const gunAttempts = new Map();
function pruneGunAttempts(now = Date.now()) {
  const cutoff = now - 60 * 60 * 1000;
  for (const [ip, entry] of gunAttempts) if (!entry || entry.since < cutoff) gunAttempts.delete(ip);
  if (gunAttempts.size > 10000)
    for (const ip of [...gunAttempts.keys()].slice(0, gunAttempts.size - 10000))
      gunAttempts.delete(ip);
}
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_MAX_ATTEMPTS = Math.min(Math.max(1, Number(process.env.LOGIN_MAX_ATTEMPTS || 5)), 5);
const DUMMY_PASSWORD_HASH = '$2b$12$C6UzMDM.H6dfI/f/IKcEe.V0B0QfM7fGvQq0vJmQx5qjQmQf2eN6u';
if (
  process.env.NODE_ENV === 'production' &&
  HOST !== '127.0.0.1' &&
  HOST !== 'localhost' &&
  process.env.TRUST_PROXY_TLS !== 'true' &&
  !(process.env.TLS_KEY_FILE && process.env.TLS_CERT_FILE)
) {
  throw new Error(
    'Public central-server binding requires HTTPS through a trusted TLS proxy (set TRUST_PROXY_TLS=true after configuring it).',
  );
}
if (process.env.NODE_ENV === 'production' && HOST !== '127.0.0.1' && CORS_ORIGIN === '*') {
  throw new Error('CORS_ORIGIN=* is not allowed for public production binding.');
}

function send(res, status, body, headers = {}) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'access-control-allow-origin': CORS_ORIGIN,
    'access-control-allow-headers': 'authorization, content-type, idempotency-key',
    'access-control-allow-methods': 'GET, POST, OPTIONS',
    ...headers,
  });
  res.end(data);
}

async function readJson(req) {
  let raw = '';
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 2_000_000)
      throw Object.assign(new Error('Request too large'), { statusCode: 413 });
  }
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch (_) {
    throw Object.assign(new Error('Malformed JSON body'), { statusCode: 400 });
  }
}

function loginAllowed(ip, username) {
  const key = `${ip}|${String(username || '')
    .trim()
    .toLowerCase()}`;
  const now = Date.now();
  const previous = loginAttempts.get(key) || { count: 0, since: now };
  if (now - previous.since >= LOGIN_WINDOW_MS) {
    previous.count = 0;
    previous.since = now;
  }
  previous.count += 1;
  loginAttempts.set(key, previous);
  if (loginAttempts.size > 10000) {
    for (const [storedKey, value] of loginAttempts)
      if (now - value.since >= LOGIN_WINDOW_MS) loginAttempts.delete(storedKey);
  }
  return previous.count <= LOGIN_MAX_ATTEMPTS;
}
function clearLoginAttempts(ip, username) {
  loginAttempts.delete(
    `${ip}|${String(username || '')
      .trim()
      .toLowerCase()}`,
  );
}
function eventVisibleToUser(event, user) {
  const payload = event?.payload || {};
  const scopeKeys = ['tenantId', 'siteId', 'locationId', 'deviceId'];
  // Legacy/unscoped events remain visible. Once an event carries a scope,
  // every supplied scope must be present on the authenticated user and match.
  // Never treat a missing user scope as authorization to receive scoped data.
  return scopeKeys.every((key) => {
    if (payload[key] == null || payload[key] === '') return true;
    if (user?.[key] == null || user[key] === '') return false;
    return String(payload[key]) === String(user[key]);
  });
}

function route(req) {
  return new URL(req.url, `http://${req.headers.host || 'localhost'}`);
}

async function authenticate(req) {
  const user = requireAuth(req);
  if (await isTokenRevoked(user.jti))
    throw Object.assign(new Error('Token revoked'), { statusCode: 401 });
  const current = await getUserSessionState(user.sub);
  if (
    !current?.active ||
    String(current.role) !== String(user.role) ||
    Number(current.session_version) !== Number(user.sessionVersion)
  )
    throw Object.assign(new Error('Session is no longer valid'), { statusCode: 401 });
  return user;
}

async function handle(req, res) {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  const url = route(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health') {
      const payload = await health();
      return send(res, 200, {
        ...payload,
        serverTime: new Date().toISOString(),
        uptimeSeconds: Math.floor(process.uptime()),
        version: process.env.npm_package_version || '5.0.0',
      });
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/login') {
      const { username, password } = await readJson(req);
      if (!username || !password)
        return send(res, 400, { error: 'Username and password are required' });
      const ip = req.socket.remoteAddress || 'unknown';
      if (!loginAllowed(ip, username))
        return send(res, 429, { error: 'Too many login attempts. Try again later.' });
      const result = await pool.query(
        'SELECT id, username, display_name, password_hash, role, active, session_version FROM app_users WHERE lower(username)=lower($1)',
        [String(username).trim()],
      );
      const account = result.rows[0];
      const validPassword = await verifyPassword(
        password,
        account?.password_hash || DUMMY_PASSWORD_HASH,
      );
      if (!account?.active || !validPassword)
        return send(res, 401, { error: 'Invalid credentials' });
      const user = result.rows[0];
      clearLoginAttempts(ip, username);
      return send(res, 200, {
        token: signToken({
          sub: user.id,
          username: user.username,
          name: user.display_name,
          role: user.role,
          sessionVersion: user.session_version,
        }),
        user: { id: user.id, username: user.username, name: user.display_name, role: user.role },
      });
    }
    const user = await authenticate(req);
    if (req.method === 'GET' && url.pathname === '/api/admin/migrations') {
      requireRole(user, ['developer', 'admin']);
      return send(res, 200, await getMigrationStatus());
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/logout') {
      const rawToken = req.headers.authorization.slice(7);
      const tokenPayload = requireAuth(req);
      revokeToken(rawToken);
      await persistRevocation(tokenPayload.jti, tokenPayload.exp);
      return send(res, 200, { ok: true });
    }
    if (req.method === 'POST' && url.pathname === '/api/ai/events') {
      const payload = await readJson(req);
      const allowedActions = ['chat_query', 'audit_run', 'root_cause_run', 'export_guidance'];
      if (!allowedActions.includes(payload.action))
        return send(res, 400, { error: 'Invalid AI action' });
      if (payload.action === 'audit_run') requireRole(user, ['developer', 'admin']);
      const eventId = crypto.randomUUID();
      const safePayload = {
        action: payload.action,
        partNo: typeof payload.partNo === 'string' ? payload.partNo.slice(0, 120) : null,
        queryType: typeof payload.queryType === 'string' ? payload.queryType.slice(0, 80) : null,
        recordCount: Number.isFinite(Number(payload.recordCount))
          ? Number(payload.recordCount)
          : null,
        clientTimestamp:
          typeof payload.clientTimestamp === 'string' ? payload.clientTimestamp.slice(0, 60) : null,
      };
      await pool.query(
        `INSERT INTO audit_events(event_id, entity_type, entity_id, action, payload, user_id) VALUES($1,'ai_assistant',$2,$3,$4,$5)`,
        [eventId, safePayload.partNo || 'assistant', safePayload.action, safePayload, user.sub],
      );
      return send(res, 201, { ok: true, eventId });
    }
    if (req.method === 'GET' && url.pathname === '/api/materials')
      return send(res, 200, { materials: await getMaterials() });
    if (req.method === 'POST' && url.pathname === '/api/materials') {
      requireRole(user, ['developer', 'admin']);
      const payload = await readJson(req);
      if (!payload.id || !payload.barcode || !payload.name)
        return send(res, 400, { error: 'id, barcode, and name are required' });
      const client = await pool.connect();
      let material;
      let materialRow;
      let sequence;
      try {
        await client.query('BEGIN');
        const result = await client.query(
        `INSERT INTO materials(id, barcode, name, category, unit, stock, low_alert, reorder_qty, unit_cost, hsn, location, bin_location_id, photo, specs, active, source_updated_at, version, updated_at)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,NOW(),0,NOW())
         ON CONFLICT (id) DO UPDATE SET barcode=EXCLUDED.barcode,name=EXCLUDED.name,category=EXCLUDED.category,unit=EXCLUDED.unit,low_alert=EXCLUDED.low_alert,reorder_qty=EXCLUDED.reorder_qty,unit_cost=EXCLUDED.unit_cost,hsn=EXCLUDED.hsn,location=EXCLUDED.location,bin_location_id=EXCLUDED.bin_location_id,photo=EXCLUDED.photo,specs=EXCLUDED.specs,active=EXCLUDED.active,source_updated_at=NOW(),version=materials.version+1,updated_at=NOW()
         RETURNING *`,
        [
          String(payload.id),
          String(payload.barcode),
          String(payload.name),
          payload.category || 'General',
          payload.unit || 'pcs',
          Math.max(0, Number(payload.stock) || 0),
          Number(payload.lowAlert) || 10,
          Number(payload.reorderQty) || 50,
          Number(payload.unitCost) || 0,
          payload.hsn || null,
          payload.location || null,
          payload.binLocationId || null,
          payload.photo || null,
          JSON.stringify(payload.specs || []),
          payload.active !== false,
        ],
        );
        materialRow = result.rows[0];
        material = toMaterial(materialRow);
        const event = await client.query(
          `INSERT INTO sync_events(event_id, entity_type, entity_id, action, payload) VALUES($1,'material',$2,'material.upserted',$3) RETURNING sequence`,
          [crypto.randomUUID(), String(material.id), { material }],
        );
        sequence = Number(event.rows[0].sequence);
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
      return send(res, 200, { material: materialRow, sequence });
    }
    if (req.method === 'POST' && url.pathname === '/api/gun-count') {
      pruneGunAttempts();
      const ip = req.socket.remoteAddress || 'unknown';
      const now = Date.now();
      const previous = gunAttempts.get(ip) || { count: 0, since: now };
      if (now - previous.since > 60000) {
        previous.count = 0;
        previous.since = now;
      }
      previous.count += 1;
      gunAttempts.set(ip, previous);
      if (previous.count > 30)
        return send(res, 429, { error: 'Too many gun-count requests. Try again later.' });
      const payload = await readJson(req);
      if (!Array.isArray(payload.sourceRows) || !Array.isArray(payload.mappingRows))
        return send(res, 400, { error: 'sourceRows and mappingRows arrays are required' });
      if (payload.sourceRows.length > MAX_GUN_ROWS || payload.mappingRows.length > MAX_GUN_ROWS)
        return send(res, 413, { error: `Too many rows. Maximum is ${MAX_GUN_ROWS} per array.` });
      const metrics = GunCountService.calculateMetrics(payload.sourceRows, payload.mappingRows);
      return send(res, 200, { ok: true, contract: 'occurrence-v1', metrics });
    }
    if (req.method === 'GET' && url.pathname === '/api/sync/changes') {
      const requestedLimit = Math.min(Number(url.searchParams.get('limit')) || 500, 2000);
      // Scan pages until we have a full visible page or reach the end. The
      // cursor covers every scanned event, including events hidden by scope.
      let cursor = Number(url.searchParams.get('after') || 0);
      const visible = [];
      const scanLimit = 2000;
      while (visible.length < requestedLimit) {
        const fetched = await getChanges(cursor, Math.min(scanLimit, requestedLimit));
        if (!fetched.length) break;
        for (const event of fetched) {
          cursor = event.sequence;
          if (eventVisibleToUser(event, user)) visible.push(event);
          if (visible.length >= requestedLimit) break;
        }
        if (fetched.length < Math.min(scanLimit, requestedLimit)) break;
      }
      return send(res, 200, { changes: visible, cursor });
    }
    if (req.method === 'POST' && url.pathname === '/api/transactions/stock') {
      requireRole(user, ['developer', 'admin', 'store']);
      const transaction = await readJson(req);
      const key = req.headers['idempotency-key'] || transaction.id;
      if (
        !key ||
        !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
          String(key),
        )
      )
        return send(res, 400, { error: 'A UUID transaction id or Idempotency-Key is required' });
      transaction.id = String(key);
      return send(res, 200, await commitStock({ transaction, userId: user.sub }));
    }
    if (req.method === 'POST' && url.pathname === '/api/users') {
      requireRole(user, ['developer', 'admin']);
      const { username, name, password, role = 'viewer' } = await readJson(req);
      const normalizedUsername = String(username || '')
        .trim()
        .toLowerCase();
      if (
        !/^[a-z0-9._-]{2,80}$/.test(normalizedUsername) ||
        !name ||
        !validatePassword(password) ||
        !['developer', 'admin', 'store', 'maintenance', 'auditor', 'viewer'].includes(role)
      )
        return send(res, 400, { error: 'Invalid user payload' });
      if (role === 'developer' && user.role !== 'developer')
        return send(res, 403, { error: 'Only a developer can create a developer account' });
      const id = crypto.randomUUID();
      await pool.query(
        'INSERT INTO app_users(id, username, display_name, password_hash, role) VALUES($1,$2,$3,$4,$5)',
        [id, normalizedUsername, name, await hashPassword(password), role],
      );
      return send(res, 201, { id, username: normalizedUsername, name, role });
    }
    if (req.method === 'POST' && url.pathname === '/api/users/sync') {
      requireRole(user, ['developer', 'admin']);
      const payload = await readJson(req);
      if (!Array.isArray(payload.users) || payload.users.length > 500)
        return send(res, 400, { error: 'users must be an array with at most 500 entries' });
      const allowedRoles = new Set([
        'developer',
        'admin',
        'store',
        'maintenance',
        'auditor',
        'viewer',
      ]);
      const client = await pool.connect();
      let created = 0;
      let updated = 0;
      let skipped = 0;
      try {
        await client.query('BEGIN');
        for (const candidate of payload.users) {
          const username = String(candidate?.username || '')
            .trim()
            .toLowerCase();
          const name = String(candidate?.name || candidate?.displayName || username)
            .trim()
            .slice(0, 160);
          const role = String(candidate?.role || 'viewer').toLowerCase();
          const hash = typeof candidate?.passwordHash === 'string' ? candidate.passwordHash : '';
          if (
            !/^[a-z0-9._-]{2,80}$/.test(username) ||
            !name ||
            !allowedRoles.has(role) ||
            !/^\$(?:2[aby]|pbkdf2)\$/.test(hash)
          ) {
            skipped += 1;
            continue;
          }
          const existing = await client.query(
            'SELECT id, role FROM app_users WHERE lower(username)=lower($1) FOR UPDATE',
            [username],
          );
          if (role === 'developer' && user.role !== 'developer') {
            skipped += 1;
            continue;
          }
          if (
            existing.rowCount &&
            existing.rows[0].role === 'developer' &&
            user.role !== 'developer'
          ) {
            skipped += 1;
            continue;
          }
          if (existing.rowCount) {
            await client.query(
              'UPDATE app_users SET username=$1, display_name=$2, role=$3, active=$4, password_hash=$5, session_version=session_version+1, updated_at=NOW() WHERE id=$6',
              [username, name, role, candidate.active !== false, hash, existing.rows[0].id],
            );
            updated += 1;
          } else {
            await client.query(
              'INSERT INTO app_users(id, username, display_name, password_hash, role, active) VALUES($1,$2,$3,$4,$5,$6)',
              [crypto.randomUUID(), username, name, hash, role, candidate.active !== false],
            );
            created += 1;
          }
        }
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
      return send(res, 200, { ok: true, created, updated, skipped });
    }
    return send(res, 404, { error: 'Not found' });
  } catch (error) {
    const status = error.statusCode || 500;
    if (status >= 500) console.error('[storetrack-api]', error);
    return send(res, status, { error: status >= 500 ? 'Internal server error' : error.message });
  }
}

async function start() {
  let lastError;
  const retries = Math.max(1, Number(process.env.DB_START_RETRIES || 10));
  for (let attempt = 1; attempt <= retries; attempt += 1) {
    try {
      await migrate();
      lastError = null;
      break;
    } catch (error) {
      lastError = error;
      if (attempt === retries) break;
      const delay = Math.min(30000, 500 * 2 ** (attempt - 1));
      console.error(
        `[storetrack-api] database unavailable; retry ${attempt}/${retries} in ${delay}ms`,
      );
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  if (lastError) throw lastError;
  const tlsKey = process.env.TLS_KEY_FILE;
  const tlsCert = process.env.TLS_CERT_FILE;
  if ((tlsKey && !tlsCert) || (!tlsKey && tlsCert))
    throw new Error('TLS_KEY_FILE and TLS_CERT_FILE must be configured together');
  const server = tlsKey
    ? https.createServer({ key: fs.readFileSync(tlsKey), cert: fs.readFileSync(tlsCert) }, handle)
    : http.createServer(handle);
  server.keepAliveTimeout = HTTP_KEEPALIVE_TIMEOUT_MS;
  server.headersTimeout = HTTP_HEADERS_TIMEOUT_MS;
  server.requestTimeout = HTTP_REQUEST_TIMEOUT_MS;
  const wss = new WebSocketServer({ noServer: true });
  const clients = new Set();
  wss.on('connection', (ws, user) => {
    clients.add(ws);
    ws.storeTrackUser = user;
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });
    const expiryTimer = setTimeout(
      () => ws.close(4001, 'Token expired'),
      Math.max(1, Number(user?.exp || 0) * 1000 - Date.now()),
    );
    ws.on('close', () => {
      clearTimeout(expiryTimer);
      clients.delete(ws);
    });
    ws.on('error', () => clients.delete(ws));
  });
  const heartbeatTimer = setInterval(async () => {
    for (const ws of clients) {
      if (ws.isAlive === false) {
        ws.terminate();
        clients.delete(ws);
        continue;
      }
      if (await isTokenRevoked(ws.storeTrackUser?.jti)) {
        ws.close(4001, 'Token revoked');
        clients.delete(ws);
        continue;
      }
      const current = await getUserSessionState(ws.storeTrackUser?.sub);
      if (
        !current?.active ||
        String(current.role) !== String(ws.storeTrackUser?.role) ||
        Number(current.session_version) !== Number(ws.storeTrackUser?.sessionVersion)
      ) {
        ws.close(4001, 'Session invalidated');
        clients.delete(ws);
        continue;
      }
      ws.isAlive = false;
      ws.ping();
    }
  }, WS_HEARTBEAT_MS);
  heartbeatTimer.unref?.();
  const purgeIdempotency = () => purgeIdempotencyKeys(IDEMPOTENCY_RETENTION_DAYS)
    .catch((error) => console.error('[storetrack-idempotency-purge]', error));
  await purgeIdempotency();
  const purgeTimer = setInterval(purgeIdempotency, IDEMPOTENCY_PURGE_INTERVAL_MS);
  purgeTimer.unref?.();
  server.on('upgrade', async (req, socket, head) => {
    if (req.url !== '/api/sync/stream') return socket.destroy();
    try {
      req.storeTrackUser = await authenticate(req);
    } catch {
      return socket.destroy();
    }
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req.storeTrackUser));
  });
  const dbClient = await pool.connect();
  await dbClient.query('LISTEN storetrack_sync');
  dbClient.on('notification', async (msg) => {
    try {
      const note = JSON.parse(msg.payload || '{}');
      const sequence = Number(note.sequence);
      if (!Number.isFinite(sequence) || sequence <= 0) return;
      // Fetch the event that generated this notification rather than the latest
      // event in the table. This prevents intermediate events being skipped when
      // multiple PostgreSQL notifications arrive close together.
      const changes = await getChanges(sequence - 1, 1);
      const event = changes[0];
      if (!event || event.sequence !== sequence) return;
      for (const ws of clients) {
        if (ws.readyState !== 1 || !eventVisibleToUser(event, ws.storeTrackUser)) continue;
        if (ws.bufferedAmount > WS_MAX_BUFFERED_BYTES) {
          ws.close(1013, 'Client backpressure');
          continue;
        }
        if (await isTokenRevoked(ws.storeTrackUser?.jti)) {
          ws.close(4001, 'Token revoked');
          continue;
        }
        ws.send(JSON.stringify({ type: 'sync.event', event }));
      }
    } catch (error) {
      console.error('[storetrack-sync]', error);
    }
  });
  server.listen(PORT, HOST, () => console.log(`StoreTrack API listening on ${HOST}:${PORT}`));
  const shutdown = async () => {
    clearInterval(heartbeatTimer);
    clearInterval(purgeTimer);
    for (const ws of clients) ws.close();
    await dbClient.release();
    await pool.end();
    server.close(() => process.exit(0));
  };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
  return server;
}

if (require.main === module)
  start().catch((error) => {
    console.error(error);
    process.exit(1);
  });
module.exports = { handle, start, eventVisibleToUser };
