-- Prevent ambiguous accounts that differ only by username casing.
CREATE UNIQUE INDEX IF NOT EXISTS idx_app_users_username_lower ON app_users (lower(username));
INSERT INTO schema_migrations(version) VALUES ('003_case_insensitive_usernames') ON CONFLICT DO NOTHING;
