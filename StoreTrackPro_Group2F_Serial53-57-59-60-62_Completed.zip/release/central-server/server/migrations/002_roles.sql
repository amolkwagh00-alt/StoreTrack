CREATE TABLE IF NOT EXISTS app_roles (
  role TEXT PRIMARY KEY CHECK (role IN ('developer','admin','store','maintenance','auditor','viewer')),
  display_name TEXT NOT NULL,
  capabilities JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO app_roles(role, display_name, capabilities) VALUES
  ('developer', 'Developer', '["*"]'::jsonb),
  ('admin', 'Admin', '["admin","users","approvals","partRegister","stockReceive","physicalStock","consumption","indentRequest","materialReturn","replacement","repairScrap","consumptionImport","reports","monthEndReports","monthEndClose","zeroStockReports","transactionHistory","auditTrail","pdfExcelExport","settings","imports","mapping","lifecycle"]'::jsonb),
  ('store', 'Store Person', '["partRegister","stockReceive","physicalStock","consumption","indentRequest","materialReturn","reports","pdfExcelExport"]'::jsonb),
  ('maintenance', 'Maintenance Officer', '["consumption","replacement","repairScrap","consumptionImport","indentRequest","materialReturn","reports","transactionHistory","pdfExcelExport","lifecycle"]'::jsonb),
  ('auditor', 'Auditor', '["reports","monthEndReports","zeroStockReports","transactionHistory","auditTrail","pdfExcelExport"]'::jsonb),
  ('viewer', 'Viewer', '[]'::jsonb)
ON CONFLICT (role) DO UPDATE SET display_name=EXCLUDED.display_name, capabilities=EXCLUDED.capabilities, updated_at=NOW();

INSERT INTO schema_migrations(version) VALUES ('002_roles') ON CONFLICT DO NOTHING;
