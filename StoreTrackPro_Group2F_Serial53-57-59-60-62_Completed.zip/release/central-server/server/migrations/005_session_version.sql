ALTER TABLE app_users
  ADD COLUMN IF NOT EXISTS session_version BIGINT NOT NULL DEFAULT 1;

INSERT INTO schema_migrations(version) VALUES ('005_session_version') ON CONFLICT DO NOTHING;
