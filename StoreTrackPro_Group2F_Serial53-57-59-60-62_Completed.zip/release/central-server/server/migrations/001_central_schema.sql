CREATE TABLE IF NOT EXISTS app_users (
  id UUID PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('developer','admin','store','maintenance','auditor','viewer')),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS materials (
  id TEXT PRIMARY KEY,
  barcode TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'General',
  unit TEXT NOT NULL DEFAULT 'pcs',
  stock NUMERIC NOT NULL DEFAULT 0 CHECK (stock >= 0),
  low_alert NUMERIC NOT NULL DEFAULT 10,
  reorder_qty NUMERIC NOT NULL DEFAULT 50,
  unit_cost NUMERIC NOT NULL DEFAULT 0,
  hsn TEXT,
  location TEXT,
  bin_location_id TEXT,
  photo TEXT,
  specs JSONB NOT NULL DEFAULT '[]'::jsonb,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  source_updated_at TIMESTAMPTZ,
  version BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS stock_transactions (
  id UUID PRIMARY KEY,
  material_id TEXT NOT NULL REFERENCES materials(id),
  type TEXT NOT NULL CHECK (type IN ('MATERIAL_IN','MATERIAL_OUT','ADJUSTMENT')),
  quantity NUMERIC NOT NULL CHECK (quantity > 0),
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('pending','confirmed','rejected')),
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  user_id UUID REFERENCES app_users(id),
  device_id TEXT,
  occurred_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  key TEXT PRIMARY KEY,
  user_id UUID REFERENCES app_users(id),
  response JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS revoked_tokens (
  jti TEXT PRIMARY KEY,
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_revoked_tokens_expires ON revoked_tokens(expires_at);

CREATE TABLE IF NOT EXISTS audit_events (
  id BIGSERIAL PRIMARY KEY,
  event_id UUID NOT NULL UNIQUE,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  action TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  user_id UUID REFERENCES app_users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sync_events (
  sequence BIGSERIAL PRIMARY KEY,
  event_id UUID NOT NULL UNIQUE,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  action TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_stock_transactions_material_time ON stock_transactions(material_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_sync_events_sequence ON sync_events(sequence);
CREATE INDEX IF NOT EXISTS idx_audit_events_entity ON audit_events(entity_type, entity_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_ai_audit_events_user_time ON audit_events(user_id, created_at DESC) WHERE entity_type = 'ai_assistant';
CREATE INDEX IF NOT EXISTS idx_materials_updated ON materials(updated_at DESC);

CREATE OR REPLACE FUNCTION publish_sync_event() RETURNS trigger AS $$
BEGIN
  PERFORM pg_notify('storetrack_sync', json_build_object('sequence', NEW.sequence, 'eventId', NEW.event_id)::text);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_event_notify ON sync_events;
CREATE TRIGGER trg_sync_event_notify AFTER INSERT ON sync_events FOR EACH ROW EXECUTE FUNCTION publish_sync_event();

CREATE TABLE IF NOT EXISTS schema_migrations (
  version TEXT PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO schema_migrations(version) VALUES ('001_central_schema') ON CONFLICT DO NOTHING;

-- Gun Count contract is occurrence-based; central API validates/calculates it without persisting a duplicate source of truth.
