require('dotenv').config({ path: require('path').join(__dirname, '.env') });
const fs = require('fs');
const path = require('path');
const { pool, migrate, toMaterial } = require('./db');
const crypto = require('crypto');

const input = process.argv[2];
const recomputeStock = process.argv.includes('--recompute-stock');
if (!input || input.startsWith('--'))
  throw new Error('Usage: node server/import-backup.js <backup.json> [--recompute-stock]');

(async () => {
  const backup = JSON.parse(fs.readFileSync(path.resolve(input), 'utf8'));
  if (!Array.isArray(backup.M) || !Array.isArray(backup.T))
    throw new Error('Backup must contain M (materials) and T (transactions) arrays');
  await migrate();
  const client = await pool.connect();
  const report = {
    materialsImported: 0,
    transactionsImported: 0,
    skippedMaterials: 0,
    skippedTransactions: 0,
    recomputedMaterials: 0,
    errors: [],
  };
  const importedMaterialIds = new Set();
  try {
    await client.query('BEGIN');
    for (const material of backup.M) {
      if (!material?.id || !material?.barcode || !material?.name) {
        report.skippedMaterials += 1;
        continue;
      }
      await client.query(
        `INSERT INTO materials(id, barcode, name, category, unit, stock, low_alert, reorder_qty, unit_cost, hsn, location, bin_location_id, photo, specs, active, version)
           VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,0)
           ON CONFLICT(id) DO UPDATE SET barcode=EXCLUDED.barcode, name=EXCLUDED.name, category=EXCLUDED.category, unit=EXCLUDED.unit, low_alert=EXCLUDED.low_alert, reorder_qty=EXCLUDED.reorder_qty, unit_cost=EXCLUDED.unit_cost, hsn=EXCLUDED.hsn, location=EXCLUDED.location, bin_location_id=EXCLUDED.bin_location_id, photo=EXCLUDED.photo, specs=EXCLUDED.specs, active=EXCLUDED.active, updated_at=NOW()`,
        [
          String(material.id),
          String(material.barcode),
          String(material.name),
          material.category || 'General',
          material.unit || 'pcs',
          Math.max(0, Number(material.stock) || 0),
          Number(material.lowAlert) || 10,
          Number(material.reorderQty) || 50,
          Number(material.unitCost) || 0,
          material.hsn || null,
          material.location || null,
          material.binLocationId || null,
          material.photo || null,
          JSON.stringify(material.specs || []),
          material.active !== false,
        ],
      );
      report.materialsImported += 1;
      importedMaterialIds.add(String(material.id));
    }
    for (const tx of backup.T) {
      const quantity = Number(tx?.qty);
      if (
        !tx?.id ||
        !tx?.itemId ||
        !Number.isFinite(quantity) ||
        quantity <= 0 ||
        !['IN', 'OUT', 'MATERIAL_IN', 'MATERIAL_OUT'].includes(tx.type)
      ) {
        report.skippedTransactions += 1;
        continue;
      }
      const exists = await client.query('SELECT 1 FROM materials WHERE id=$1', [
        String(tx.itemId),
      ]);
      if (!exists.rowCount) {
        report.skippedTransactions += 1;
        report.errors.push({ type: 'transaction', id: tx.id, error: 'material does not exist' });
        continue;
      }
      const type =
        tx.type === 'OUT' || tx.type === 'MATERIAL_OUT' ? 'MATERIAL_OUT' : 'MATERIAL_IN';
      await client.query(
        `INSERT INTO stock_transactions(id, material_id, type, quantity, status, payload, device_id, occurred_at)
           VALUES($1,$2,$3,$4,'confirmed',$5,$6,$7) ON CONFLICT(id) DO NOTHING`,
        [
          String(tx.id),
          String(tx.itemId),
          type,
          quantity,
          tx,
          tx.deviceId || 'indexeddb-import',
          tx.time || new Date().toISOString(),
        ],
      );
      report.transactionsImported += 1;
    }
    if (recomputeStock && importedMaterialIds.size) {
      const ids = [...importedMaterialIds];
      const computed = await client.query(
        `
        WITH ordered AS (
          SELECT t.material_id, t.type, t.quantity, t.payload, t.occurred_at,
                 MAX(CASE WHEN t.type='ADJUSTMENT' THEN t.occurred_at END)
                   OVER (PARTITION BY t.material_id) AS last_adjustment_at
          FROM stock_transactions t
          WHERE t.material_id = ANY($1::text[]) AND t.status='confirmed'
        ), totals AS (
          SELECT material_id,
            COALESCE(MAX(CASE WHEN type='ADJUSTMENT' AND occurred_at=last_adjustment_at
                              THEN (payload->>'newStock')::numeric END), 0)
            + COALESCE(SUM(CASE WHEN type='MATERIAL_IN' AND (last_adjustment_at IS NULL OR occurred_at > last_adjustment_at) THEN quantity
                                WHEN type='MATERIAL_OUT' AND (last_adjustment_at IS NULL OR occurred_at > last_adjustment_at) THEN -quantity ELSE 0 END), 0) AS stock
          FROM ordered GROUP BY material_id
        ) SELECT material_id, stock FROM totals`,
        [ids],
      );
      const negatives = computed.rows.filter((row) => Number(row.stock) < 0);
      if (negatives.length)
        throw new Error(
          `Recompute would make stock negative for: ${negatives.map((r) => r.material_id).join(', ')}`,
        );
      for (const row of computed.rows) {
        const current = await client.query('SELECT * FROM materials WHERE id=$1 FOR UPDATE', [
          row.material_id,
        ]);
        if (!current.rowCount) continue;
        const next = Number(row.stock);
        if (Number(current.rows[0].stock) !== next) {
          await client.query(
            'UPDATE materials SET stock=$1, version=version+1, updated_at=NOW() WHERE id=$2',
            [next, row.material_id],
          );
          await client.query(
            `INSERT INTO sync_events(event_id, entity_type, entity_id, action, payload) VALUES($1,'stock',$2,'stock.updated',$3)`,
            [
              crypto.randomUUID(),
              row.material_id,
              {
                material: toMaterial({
                  ...current.rows[0],
                  stock: next,
                  version: Number(current.rows[0].version) + 1,
                }),
                source: 'backup-recompute',
              },
            ],
          );
        }
        report.recomputedMaterials += 1;
      }
    }
    await client.query('COMMIT');
    console.log(JSON.stringify(report, null, 2));
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
})().catch(async (error) => {
  console.error('Backup import failed:', error.message);
  await pool.end();
  process.exitCode = 1;
});
