const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const { migrate, pool } = require('./db');

migrate()
  .then(async () => {
    console.log('StoreTrack central schema is up to date.');
    await pool.end();
  })
  .catch(async (error) => {
    console.error('StoreTrack central migration failed:', error);
    await pool.end();
    process.exitCode = 1;
  });
