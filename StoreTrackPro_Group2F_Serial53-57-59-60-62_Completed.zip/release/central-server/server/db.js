const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const crypto = require('crypto');

const poolSize = Math.min(50, Math.max(5, Number(process.env.DB_POOL_SIZE || 10)));
const poolIdleTimeoutMillis = Math.min(300000, Math.max(5000, Number(process.env.DB_POOL_IDLE_TIMEOUT_MS || 30000)));
const poolConnectionTimeoutMillis = Math.min(30000, Math.max(1000, Number(process.env.DB_POOL_CONNECTION_TIMEOUT_MS || 5000)));
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: poolSize,
  idleTimeoutMillis: poolIdleTimeoutMillis,
  connectionTimeoutMillis: poolConnectionTimeoutMillis,
  ssl:
    process.env.DATABASE_SSL === 'true'
      ? { rejectUnauthorized: process.env.DATABASE_SSL_VERIFY !== 'false' }
      : undefined,
});

const EXPECTED_MIGRATIONS = [
  '001_central_schema',
  '002_roles',
  '003_case_insensitive_usernames',
  '004_idempotency_retention',
  '005_session_version',
];

async function migrate() {
  const client = await pool.connect();
  try {
    await client.query('SELECT pg_advisory_lock(hashtext($1))', ['storetrack_migrate']);
    await client.query(
      'CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW())',
    );
    for (const file of [
      '001_central_schema.sql',
      '002_roles.sql',
      '003_case_insensitive_usernames.sql',
      '004_idempotency_retention.sql',
      '005_session_version.sql',
    ]) {
      const version = file.replace(/\.sql$/, '');
      const applied = await client.query('SELECT 1 FROM schema_migrations WHERE version=$1', [
        version,
      ]);
      if (applied.rowCount) continue;
      if (version === '003_case_insensitive_usernames') {
        const duplicates = await client.query(
          'SELECT lower(username) AS username, COUNT(*)::int AS count FROM app_users GROUP BY lower(username) HAVING COUNT(*) > 1',
        );
        if (duplicates.rowCount)
          throw new Error(
            `Cannot apply username uniqueness migration; duplicate usernames: ${duplicates.rows.map((row) => `${row.username} (${row.count})`).join(', ')}`,
          );
      }
      const sql = fs.readFileSync(path.join(__dirname, 'migrations', file), 'utf8');
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query(
          'INSERT INTO schema_migrations(version) VALUES($1) ON CONFLICT DO NOTHING',
          [version],
        );
        await client.query('COMMIT');
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      }
    }
  } finally {
    await client
      .query('SELECT pg_advisory_unlock(hashtext($1))', ['storetrack_migrate'])
      .catch(() => {});
    client.release();
  }
}

function toMaterial(row) {
  if (!row) return null;
  return {
    id: row.id,
    barcode: row.barcode,
    name: row.name,
    category: row.category,
    unit: row.unit,
    stock: Number(row.stock),
    lowAlert: Number(row.low_alert),
    reorderQty: Number(row.reorder_qty),
    unitCost: Number(row.unit_cost),
    hsn: row.hsn,
    location: row.location,
    binLocationId: row.bin_location_id,
    photo: row.photo,
    specs: row.specs || [],
    active: row.active,
    version: Number(row.version),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

async function getMaterials() {
  const { rows } = await pool.query('SELECT * FROM materials ORDER BY name');
  return rows.map(toMaterial);
}

async function getChanges(afterSequence, limit = 500) {
  const { rows } = await pool.query(
    `SELECT sequence, event_id, entity_type, entity_id, action, payload, created_at
     FROM sync_events WHERE sequence > $1 ORDER BY sequence ASC LIMIT $2`,
    [Number(afterSequence || 0), Math.min(Number(limit) || 500, 2000)],
  );
  return rows.map((r) => ({
    sequence: Number(r.sequence),
    eventId: r.event_id,
    entityType: r.entity_type,
    entityId: r.entity_id,
    action: r.action,
    payload: r.payload,
    createdAt: r.created_at,
  }));
}

async function commitStock({ transaction, userId }) {
  const client = await pool.connect();
  const key = transaction.id;
  const idempotencyKey = `${userId || 'system'}:${key}`;
  try {
    await client.query('BEGIN');
    // Scope idempotency to the authenticated user so one user's key cannot
    // replay another user's transaction response.
    const previous = await client.query('SELECT response FROM idempotency_keys WHERE key = $1', [
      idempotencyKey,
    ]);
    if (previous.rowCount) {
      await client.query('COMMIT');
      return previous.rows[0].response;
    }
    const material = await client.query('SELECT * FROM materials WHERE id = $1 FOR UPDATE', [
      String(transaction.itemId),
    ]);
    if (!material.rowCount)
      throw Object.assign(new Error('Material not found'), { statusCode: 404 });
    const existingTransaction = await client.query('SELECT id FROM stock_transactions WHERE id = $1', [key]);
    if (existingTransaction.rowCount)
      throw Object.assign(new Error('Transaction ID has already been used; create a new transaction ID'), {
        statusCode: 409,
      });
    const current = material.rows[0];
    const quantity = Number(transaction.qty);
    if (!Number.isFinite(quantity) || quantity <= 0)
      throw Object.assign(new Error('Quantity must be positive'), { statusCode: 400 });
    const isIn = transaction.type === 'MATERIAL_IN' || transaction.type === 'IN';
    const isOut = transaction.type === 'MATERIAL_OUT' || transaction.type === 'OUT';
    const isAdjustment = transaction.type === 'ADJUSTMENT';
    if (!isIn && !isOut && !isAdjustment)
      throw Object.assign(new Error('Unsupported transaction type'), { statusCode: 400 });
    const oldStock = Number(current.stock);
    const newStock = isAdjustment
      ? Number(transaction.newStock)
      : isIn
        ? oldStock + quantity
        : oldStock - quantity;
    if (isAdjustment && (!Number.isFinite(newStock) || newStock < 0))
      throw Object.assign(new Error('Adjustment newStock must be a non-negative number'), {
        statusCode: 400,
      });
    if (newStock < 0)
      throw Object.assign(new Error(`Insufficient stock. Available: ${oldStock}`), {
        statusCode: 409,
      });

    const occurredAt = transaction.time || new Date().toISOString();
    await client.query(
      `UPDATE materials SET stock=$1, version=version+1, updated_at=NOW(), source_updated_at=$2 WHERE id=$3`,
      [newStock, occurredAt, String(transaction.itemId)],
    );
    const inserted = await client.query(
      `INSERT INTO stock_transactions(id, material_id, type, quantity, status, payload, user_id, device_id, occurred_at)
       VALUES($1,$2,$3,$4,'confirmed',$5,$6,$7,$8) RETURNING created_at`,
      [
        key,
        String(transaction.itemId),
        isAdjustment ? 'ADJUSTMENT' : isIn ? 'MATERIAL_IN' : 'MATERIAL_OUT',
        isAdjustment ? Math.abs(newStock - oldStock) : quantity,
        transaction,
        userId || null,
        transaction.deviceId || null,
        occurredAt,
      ],
    );
    const eventId = crypto.randomUUID();
    const eventPayload = {
      material: toMaterial({
        ...current,
        stock: newStock,
        version: Number(current.version) + 1,
        updated_at: inserted.rows[0].created_at,
      }),
      transaction: { ...transaction, status: 'confirmed' },
      oldStock,
      newStock,
    };
    const event = await client.query(
      `INSERT INTO sync_events(event_id, entity_type, entity_id, action, payload) VALUES($1,'stock',$2,'stock.updated',$3) RETURNING sequence, created_at`,
      [eventId, String(transaction.itemId), eventPayload],
    );
    await client.query(
      `INSERT INTO audit_events(event_id, entity_type, entity_id, action, payload, user_id) VALUES($1,'stock',$2,$3,$4,$5)`,
      [
        crypto.randomUUID(),
        String(transaction.itemId),
        isAdjustment ? 'ADJUSTMENT' : isIn ? 'MATERIAL_IN' : 'MATERIAL_OUT',
        eventPayload,
        userId || null,
      ],
    );
    const response = {
      ok: true,
      transaction: { ...transaction, status: 'confirmed' },
      material: eventPayload.material,
      oldStock,
      newStock,
      sequence: Number(event.rows[0].sequence),
      committedAt: event.rows[0].created_at,
    };
    await client.query('INSERT INTO idempotency_keys(key, user_id, response) VALUES($1,$2,$3)', [
      idempotencyKey,
      userId || null,
      response,
    ]);
    await client.query('COMMIT');
    return response;
  } catch (error) {
    await client.query('ROLLBACK');
    if (error?.code === '23505') {
      const retry = await pool.query('SELECT response FROM idempotency_keys WHERE key=$1', [
        idempotencyKey,
      ]);
      if (retry.rowCount) return retry.rows[0].response;
    }
    throw error;
  } finally {
    client.release();
  }
}

async function purgeIdempotencyKeys(retentionDays = 30) {
  const days = Number.isFinite(Number(retentionDays)) ? Math.max(1, Number(retentionDays)) : 30;
  const result = await pool.query(
    'DELETE FROM idempotency_keys WHERE created_at < NOW() - ($1 * INTERVAL \'1 day\')',
    [days],
  );
  return result.rowCount || 0;
}

async function health() {
  const result = await pool.query('SELECT NOW() AS now');
  return { ok: true, databaseTime: result.rows[0].now };
}

async function getMigrationStatus() {
  const result = await pool.query('SELECT version, applied_at FROM schema_migrations ORDER BY version');
  const known = new Set(EXPECTED_MIGRATIONS);
  const appliedVersions = result.rows.map((row) => String(row.version));
  const appliedSet = new Set(appliedVersions);
  const pendingVersions = EXPECTED_MIGRATIONS.filter((version) => !appliedSet.has(version));
  const unexpectedVersions = appliedVersions.filter((version) => !known.has(version));
  return {
    source: 'central-postgresql',
    migrationTablePresent: true,
    expectedVersions: [...EXPECTED_MIGRATIONS],
    appliedVersions,
    pendingVersions,
    unexpectedVersions,
    currentVersion: EXPECTED_MIGRATIONS.filter((version) => appliedSet.has(version)).at(-1) || null,
    expectedVersion: EXPECTED_MIGRATIONS.at(-1),
    migrationPending: pendingVersions.length > 0 || unexpectedVersions.length > 0,
    checkedAt: new Date().toISOString(),
  };
}

async function getUserSessionState(userId) {
  const result = await pool.query('SELECT active, role, session_version FROM app_users WHERE id=$1', [
    String(userId),
  ]);
  if (!result.rowCount) return null;
  return result.rows[0];
}

async function revokeToken(jti, expiresAt) {
  if (!jti || !expiresAt) return;
  await pool.query(
    'INSERT INTO revoked_tokens(jti, expires_at) VALUES($1,$2) ON CONFLICT (jti) DO UPDATE SET expires_at=EXCLUDED.expires_at',
    [String(jti), new Date(Number(expiresAt) * 1000)],
  );
  await pool.query('DELETE FROM revoked_tokens WHERE expires_at <= NOW()');
}

async function isTokenRevoked(jti) {
  if (!jti) return false;
  const result = await pool.query(
    'SELECT 1 FROM revoked_tokens WHERE jti=$1 AND expires_at > NOW()',
    [String(jti)],
  );
  return result.rowCount > 0;
}

module.exports = {
  pool,
  toMaterial,
  migrate,
  getMaterials,
  getChanges,
  commitStock,
  purgeIdempotencyKeys,
  health,
  getMigrationStatus,
  getUserSessionState,
  revokeToken,
  isTokenRevoked,
};
