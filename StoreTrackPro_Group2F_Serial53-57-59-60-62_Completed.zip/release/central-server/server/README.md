# StoreTrack Central API
> **Repository alignment (2026-09-19):** This documentation is aligned with the security-fixed and performance-tuned StoreTrack Central Server build. Target Windows certificate, firewall, ACL, backup-restore, and hardware validation remain deployment-site checks.


This directory contains the optional central server required for multi-PC synchronization. The Electron client remains a Windows desktop application; this service is the server-side source of truth.

## Required environment

Copy `.env.example` to `.env` and set a strong `STORETRACK_JWT_SECRET`.

```text
DATABASE_URL=postgres://storetrack:change-me@localhost:5432/storetrack
STORETRACK_JWT_SECRET=replace-with-at-least-32-random-characters
PORT=8787
HOST=127.0.0.1
CORS_ORIGIN=https://your-client-origin.example
```

## Run directly

```bash
npm run central:migrate
npm run central:server
```

## Run with Docker Compose

```bash
docker compose -f server/docker-compose.yml up -d
npm run central:migrate
```

## API

- `GET /health`
- `POST /api/auth/login`
- `GET /api/materials` with `Authorization: Bearer <token>`
- `POST /api/transactions/stock` with an idempotent transaction ID and `developer`/`admin`/`store` role
- `GET /api/sync/changes?after=<sequence>`
- `POST /api/users` with `developer`/`admin` role
- `POST /api/users/sync` with `developer`/`admin` role
- WebSocket `wss://server.example/api/sync/stream` through the HTTPS reverse proxy

Authenticated requests and WebSocket upgrades validate token revocation, active account state, current role, and database-backed `session_version`. Stock writes are serialized with a row lock, validated against non-negative stock, protected by user-scoped idempotency, recorded in an immutable transaction table, audited, and published through PostgreSQL notifications. The Windows installer creates DPAPI-encrypted backups and a same-host restore helper.
