@echo off
setlocal
set SERVICE_NAME=StoreTrackProCentral
set PROJECT_DIR=%~dp0..
set NODE_EXE=node

echo Installing %SERVICE_NAME% as a Windows service requires NSSM or an equivalent service wrapper.
echo Recommended command with NSSM:
echo nssm install %SERVICE_NAME% "%NODE_EXE%" "%PROJECT_DIR%server\index.js"
echo nssm set %SERVICE_NAME% AppDirectory "%PROJECT_DIR%"
echo nssm set %SERVICE_NAME% Start SERVICE_AUTO_START
echo nssm start %SERVICE_NAME%
echo.
echo Configure server\.env before starting the service.
endlocal
