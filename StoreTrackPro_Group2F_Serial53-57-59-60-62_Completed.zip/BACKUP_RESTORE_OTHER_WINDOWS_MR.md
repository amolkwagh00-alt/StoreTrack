# दुसऱ्या Windows PC वर StoreTrack backup restore

दुसऱ्या PC वर backup restore करण्यासाठी **portable JSON** वापरा. रोज तयार होणारा backup आणि **Create This-PC Encrypted Backup** हा पर्याय फक्त मूळ Windows installation वर restore होऊ शकतो; त्याची key त्या PC च्या Windows account शी सुरक्षितरीत्या जोडलेली असते.

## नवीन portable backup तयार करा

1. StoreTrack उघडा आणि **Backup & Restore** पेजवर जा.
2. ज्या PC मधून data हलवायचा आहे, तिथे **Create Backup for Any Windows PC (portable JSON)** निवडा.
3. Security confirmation स्वीकारा आणि Save dialog मध्ये `.json` file जतन करा.
4. ती file target PC पर्यंत सुरक्षित पद्धतीने पोहोचवा.

## Target PC वर restore करा

1. Target PC वर StoreTrack उघडा आणि **Backup & Restore** पेजवर जा.
2. **Import Backup from Another PC** निवडा आणि portable JSON file उघडा.
3. Restore preview तपासा आणि योग्य असल्यास confirm करा. Restore आधी target PC चा safety backup तयार होतो; पूर्ण झाल्यावर app reload होईल.

Backup मध्ये StoreTrack आणि Shank Mapping operational data असतो. User accounts/password hashes backup मधून वगळले जातात; target PC वरील user accounts तसेच राहतात.

## महत्त्वाची सुरक्षा आणि जुन्या file बद्दल

Portable JSON मध्ये decrypt करण्यासाठीची recovery key त्याच file मध्ये असते. त्यामुळे file ज्याच्याकडे असेल तो backup वाचू शकतो—फक्त विश्वासू ठिकाणी साठवा.

जर तुमच्याकडे आधीचा `StoreTrackPro-backup-YYYY-MM-DD.json` file असेल, तर तो local encrypted backup असण्याची शक्यता आहे. तो दुसऱ्या PC वर थेट import होत नाही. मूळ PC वर StoreTrack अजून सुरू होत असेल, तर तिथे जाऊन portable JSON तयार करा. फक्त जुनी machine-bound encrypted file उपलब्ध असेल आणि मूळ PC/key उपलब्ध नसेल, तर target PC ती decrypt करू शकणार नाही.
