@echo off
setlocal EnableExtensions
set "INSTALLER=%~dp0Install-Central-Server.ps1"

echo ==============================================
echo StoreTrack Pro - Central Server Setup
echo ==============================================
echo.
echo Requesting Administrator permission...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$script = [IO.Path]::GetFullPath('%INSTALLER%'); $args = @('-NoProfile','-ExecutionPolicy','Bypass','-NoExit','-File',$script); $p = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $args -PassThru -Wait; exit $p.ExitCode"
set "RESULT=%errorlevel%"
echo.
if "%RESULT%"=="0" (
  echo Central Server setup window finished.
) else (
  echo Central Server setup returned exit code %RESULT%.
)
echo.
pause
exit /b %RESULT%
