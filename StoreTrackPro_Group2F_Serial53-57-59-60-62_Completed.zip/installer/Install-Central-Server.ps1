#requires -Version 5.1
[CmdletBinding()]
param(
  [string]$InstallRoot = 'C:\StoreTrack\CentralServer',
  [int]$ApiPort = 8787,
  [string]$DatabaseName = 'storetrack',
  [string]$DatabaseUser = 'storetrack',
  [string]$PostgresBin = '',
  [int]$PostgresPort = 5432,
  [string]$AdminUsername = 'admin',
  [string]$TlsKeyFile = '',
  [string]$TlsCertFile = '',
  [string]$FirewallRemoteAddress = 'LocalSubnet',
  [switch]$SkipFirewall,
  [switch]$SkipBackupTask
)
$ErrorActionPreference = 'Stop'

function Require-Admin {
  $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
  if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Run PowerShell as Administrator.' }
}
function New-RandomSecret([int]$Length = 48) {
  $bytes = New-Object byte[] $Length
  [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
  ([Convert]::ToBase64String($bytes) -replace '[^A-Za-z0-9]', '').Substring(0, $Length)
}
function Find-Executable([string]$Name, [string[]]$Candidates) {
  foreach ($candidate in $Candidates) { if ($candidate -and (Test-Path $candidate)) { return (Resolve-Path $candidate).Path } }
  $command = Get-Command $Name -ErrorAction SilentlyContinue
  if ($command) { return $command.Source }
  return $null
}
function Invoke-Psql([string]$Psql, [string]$Database, [string]$Sql, [string]$Password, [int]$Port = 5432) {
  $env:PGPASSWORD = $Password
  try { & $Psql -h 127.0.0.1 -p $Port -U postgres -d $Database -v ON_ERROR_STOP=1 -c $Sql | Out-Host; if ($LASTEXITCODE -ne 0) { throw "psql failed with exit code $LASTEXITCODE" } }
  finally { Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue }
}
function Test-PsqlScalar([string]$Psql, [string]$Database, [string]$Sql, [string]$Password, [int]$Port = 5432) {
  if (-not (Test-Path $Psql)) { return '' }
  $env:PGPASSWORD = $Password
  $tempRoot = [System.IO.Path]::GetTempPath()
  New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
  $outFile = Join-Path $tempRoot ("storetrack-psql-out-" + [guid]::NewGuid().ToString() + '.txt')
  $errFile = Join-Path $tempRoot ("storetrack-psql-err-" + [guid]::NewGuid().ToString() + '.txt')
  try {
    $argumentList = "-h 127.0.0.1 -p $Port -U postgres -d $Database -tA -c `"$Sql`""
    $process = Start-Process -FilePath $Psql -ArgumentList $argumentList -Wait -PassThru -WindowStyle Hidden -RedirectStandardOutput $outFile -RedirectStandardError $errFile
    if ($process.ExitCode -ne 0) { return '' }
    return ((Get-Content $outFile -Raw -ErrorAction SilentlyContinue) -replace '\s+', '').Trim()
  } catch { return '' }
  finally {
    Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
    foreach ($tempFile in @($outFile, $errFile)) {
      if ($tempFile -and (Test-Path -LiteralPath $tempFile -ErrorAction SilentlyContinue)) {
        Remove-Item -LiteralPath $tempFile -Force -ErrorAction SilentlyContinue
      }
    }
  }
}
function Install-PostgresAutomatically([string]$Password, [int]$Port) {
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  Write-Host 'PostgreSQL access was not available. Installing an isolated StoreTrack PostgreSQL instance automatically...' -ForegroundColor Yellow
  if ($winget) {
    $override = "/mode unattended --unattendedmodeui none --superpassword `"$Password`" --serverport $Port"
    & $winget.Source install --id PostgreSQL.PostgreSQL.18 --exact --silent --accept-source-agreements --accept-package-agreements --override $override | Out-Host
    if ($LASTEXITCODE -ne 0) { throw 'Automatic PostgreSQL installation failed. Company software policy may require IT approval.' }
  } else {
    $installer = Join-Path ([System.IO.Path]::GetTempPath()) 'postgresql-18.6-1-windows-x64.exe'
    $url = 'https://get.enterprisedb.com/postgresql/postgresql-18.6-1-windows-x64.exe'
    Write-Host 'winget is unavailable; downloading the official PostgreSQL installer from EDB...' -ForegroundColor Yellow
    Invoke-WebRequest -Uri $url -OutFile $installer -UseBasicParsing
    if (-not (Test-Path $installer)) { throw 'PostgreSQL installer download failed.' }
    $arguments = @('--mode','unattended','--unattendedmodeui','none','--superpassword',$Password,'--serverport',"$Port",'--disable-components','pgAdmin,stackbuilder')
    $process = Start-Process -FilePath $installer -ArgumentList $arguments -Wait -PassThru
    if ($process.ExitCode -ne 0) { throw "Automatic PostgreSQL installation failed with exit code $($process.ExitCode)." }
  }
  Start-Sleep -Seconds 8
}

Require-Admin
New-Item -ItemType Directory -Force -Path $InstallRoot, (Join-Path $InstallRoot 'server'), (Join-Path $InstallRoot 'backups') | Out-Null
$sourceRoot = Split-Path -Parent $PSScriptRoot
Copy-Item (Join-Path $sourceRoot 'server\*') (Join-Path $InstallRoot 'server') -Recurse -Force
$centralPackage = Join-Path $sourceRoot 'release\central-server\package.json'
if (-not (Test-Path $centralPackage)) { $centralPackage = Join-Path $sourceRoot 'package.json' }
Copy-Item $centralPackage (Join-Path $InstallRoot 'package.json') -Force

$pgCandidates = @()
if ($PostgresBin) { $pgCandidates += (Join-Path $PostgresBin 'psql.exe') }
$pgCandidates += @('C:\Program Files\PostgreSQL\18\bin\psql.exe','C:\Program Files\PostgreSQL\17\bin\psql.exe','C:\Program Files\PostgreSQL\16\bin\psql.exe')
$psql = Find-Executable 'psql.exe' $pgCandidates
if (-not $psql) {
  $psql = Join-Path $env:TEMP 'storetrack-psql-placeholder.exe'
  $pgBin = 'C:\Program Files\PostgreSQL\18\bin'
} else { $pgBin = Split-Path $psql }
$pgDump = Join-Path $pgBin 'pg_dump.exe'
$node = Find-Executable 'node.exe' @('C:\Program Files\nodejs\node.exe')
if (-not $node) { throw 'Node.js LTS is required on the central PC.' }

$postgresPlain = New-RandomSecret 40
$dbPassword = New-RandomSecret 40
$jwtSecret = New-RandomSecret 48
$adminPlain = New-RandomSecret 18

$connected = (Test-PsqlScalar $psql 'postgres' 'SELECT 1' $postgresPlain $PostgresPort) -eq '1'
if (-not $connected) {
  $PostgresPort = 5433
  Install-PostgresAutomatically $postgresPlain $PostgresPort
  $psql = Find-Executable 'psql.exe' @('C:\Program Files\PostgreSQL\18\bin\psql.exe','C:\Program Files\PostgreSQL\17\bin\psql.exe','C:\Program Files\PostgreSQL\16\bin\psql.exe')
  if (-not $psql) { throw 'Automatic PostgreSQL installation completed but psql.exe was not found.' }
  $pgBin = Split-Path $psql
  $pgDump = Join-Path $pgBin 'pg_dump.exe'
  $connected = (Test-PsqlScalar $psql 'postgres' 'SELECT 1' $postgresPlain $PostgresPort) -eq '1'
}
if (-not $connected) { throw 'PostgreSQL was installed but the generated administrator credentials could not be verified.' }
Invoke-Psql $psql 'postgres' "DO `$`$BEGIN IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '$DatabaseUser') THEN CREATE ROLE $DatabaseUser LOGIN PASSWORD '$dbPassword'; ELSE ALTER ROLE $DatabaseUser WITH LOGIN PASSWORD '$dbPassword'; END IF; END`$`$;" $postgresPlain $PostgresPort
$databaseExists = Test-PsqlScalar $psql 'postgres' "SELECT 1 FROM pg_database WHERE datname='$DatabaseName'" $postgresPlain $PostgresPort
if ($databaseExists -ne '1') { Invoke-Psql $psql 'postgres' "CREATE DATABASE $DatabaseName OWNER $DatabaseUser" $postgresPlain $PostgresPort }
$env:DATABASE_URL = "postgres://${DatabaseUser}:$dbPassword@127.0.0.1:$PostgresPort/$DatabaseName"
$env:STORETRACK_JWT_SECRET = $jwtSecret
$env:PORT = "$ApiPort"
$env:HOST = '0.0.0.0'
$env:NODE_ENV = 'production'
if ($TlsKeyFile -and $TlsCertFile) { $env:TLS_KEY_FILE = $TlsKeyFile; $env:TLS_CERT_FILE = $TlsCertFile }
else { throw 'Provide -TlsKeyFile and -TlsCertFile for LAN HTTPS.' }
$env:ADMIN_USERNAME = $AdminUsername
$env:ADMIN_PASSWORD = $adminPlain
$env:ADMIN_NAME = 'Central Administrator'
Push-Location $InstallRoot
try {
  & (Join-Path (Split-Path $node) 'npm.cmd') 'install' '--omit=dev' '--no-audit' '--no-fund'
  if ($LASTEXITCODE -ne 0) { throw 'Central server dependency installation failed.' }
  & $node 'server\migrate.js'
  if ($LASTEXITCODE -ne 0) { throw 'Central migration failed.' }
  & $node 'server\create-admin.js'
  if ($LASTEXITCODE -ne 0) { throw 'Central administrator creation failed.' }
} finally { Pop-Location }

$envFile = @("DATABASE_URL=$($env:DATABASE_URL)","STORETRACK_JWT_SECRET=$jwtSecret","PORT=$ApiPort","HOST=0.0.0.0","NODE_ENV=production","CORS_ORIGIN=https://your-client-origin.example","TLS_KEY_FILE=$TlsKeyFile","TLS_CERT_FILE=$TlsCertFile")
Set-Content -Path (Join-Path $InstallRoot 'server\.env') -Value $envFile -Encoding UTF8
$credentialFile = Join-Path $InstallRoot 'credentials.txt'
Set-Content -Path $credentialFile -Value @("StoreTrack Central Server credentials", "Created: $(Get-Date -Format o)", "API URL: https://$env:COMPUTERNAME`:$ApiPort", "Admin username: $AdminUsername", "Admin password: $adminPlain", "Database user: $DatabaseUser", "Database password: $dbPassword", "Database port: $PostgresPort", "Keep this file restricted to authorized administrators.") -Encoding UTF8
$acl = Get-Acl $credentialFile
$acl.SetAccessRuleProtection($true, $false)
$acl.Access | ForEach-Object { $acl.RemoveAccessRule($_) | Out-Null }
$adminRule = New-Object System.Security.AccessControl.FileSystemAccessRule('Administrators','FullControl','Allow')
$systemRule = New-Object System.Security.AccessControl.FileSystemAccessRule('SYSTEM','FullControl','Allow')
$acl.AddAccessRule($adminRule); $acl.AddAccessRule($systemRule); Set-Acl $credentialFile $acl
$envPath = Join-Path $InstallRoot 'server\.env'
$envAcl = Get-Acl $envPath
$envAcl.SetAccessRuleProtection($true, $false)
$envAcl.Access | ForEach-Object { $envAcl.RemoveAccessRule($_) | Out-Null }
$envAcl.AddAccessRule($adminRule); $envAcl.AddAccessRule($systemRule); Set-Acl $envPath $envAcl
Remove-Item Env:DATABASE_URL,Env:STORETRACK_JWT_SECRET,Env:ADMIN_USERNAME,Env:ADMIN_PASSWORD,Env:ADMIN_NAME -ErrorAction SilentlyContinue

$startScript = Join-Path $InstallRoot 'Start-CentralServer.cmd'
Set-Content $startScript "@echo off`r`ncd /d `"$InstallRoot`"`r`n`"$node`" server\index.js >> logs\central-server.log 2>&1`r`n" -Encoding ASCII
New-Item -ItemType Directory -Force -Path (Join-Path $InstallRoot 'logs') | Out-Null
$taskName = 'StoreTrack Central Server'
schtasks.exe /Delete /TN $taskName /F 2>$null | Out-Null
schtasks.exe /Create /TN $taskName /SC ONSTART /RU SYSTEM /RL HIGHEST /TR "cmd.exe /c `"$startScript`"" /F | Out-Host

if (-not $SkipFirewall) {
  Remove-NetFirewallRule -DisplayName 'StoreTrack Central API' -ErrorAction SilentlyContinue
  New-NetFirewallRule -DisplayName 'StoreTrack Central API' -Direction Inbound -Protocol TCP -LocalPort $ApiPort -RemoteAddress $FirewallRemoteAddress -Action Allow -Profile Domain,Private | Out-Null
}
if (-not $SkipBackupTask) {
  $backupScript = Join-Path $InstallRoot 'Backup-Database.ps1'
  $backupCode = @"
`$ErrorActionPreference = 'Stop'
`$envFile = Get-Content '$InstallRoot\server\.env'
`$databaseUrl = (`$envFile | Where-Object { `$_ -like 'DATABASE_URL=*' }) -replace '^DATABASE_URL=', ''
`$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
New-Item -ItemType Directory -Force -Path '$InstallRoot\backups' | Out-Null
`$plainFile = Join-Path '$InstallRoot\backups' ("storetrack-`$stamp.dump")
`$encryptedFile = Join-Path '$InstallRoot\backups' ("storetrack-`$stamp.dump.dpapi")
& '$pgDump' --dbname=`$databaseUrl --format=custom --file=`$plainFile
if (`$LASTEXITCODE -ne 0 -or -not (Test-Path `$plainFile) -or (Get-Item `$plainFile).Length -le 0) { throw 'pg_dump failed or produced an empty dump' }
`$bytes = [IO.File]::ReadAllBytes(`$plainFile)
`$protected = [Security.Cryptography.ProtectedData]::Protect(`$bytes, $null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
[IO.File]::WriteAllBytes(`$encryptedFile, `$protected)
Remove-Item `$plainFile -Force
if (-not (Test-Path `$encryptedFile) -or (Get-Item `$encryptedFile).Length -le 0) { throw 'Encrypted backup was not created' }
Get-ChildItem '$InstallRoot\backups\*.dump.dpapi' | Sort-Object LastWriteTime -Descending | Select-Object -Skip 30 | Remove-Item -Force
"@
  Set-Content $backupScript $backupCode -Encoding UTF8
  $restoreScript = Join-Path $InstallRoot 'Restore-Database.ps1'
  $restoreCode = @"
param([Parameter(Mandatory=`$true)][string]`$EncryptedBackup)
`$ErrorActionPreference = 'Stop'
`$envFile = Get-Content '$InstallRoot\server\.env'
`$databaseUrl = (`$envFile | Where-Object { `$_ -like 'DATABASE_URL=*' }) -replace '^DATABASE_URL=', ''
`$bytes = [IO.File]::ReadAllBytes(`$EncryptedBackup)
`$dump = [Security.Cryptography.ProtectedData]::Unprotect(`$bytes, `$null, [Security.Cryptography.DataProtectionScope]::LocalMachine)
`$plainFile = Join-Path `$env:TEMP ('storetrack-restore-' + [guid]::NewGuid().ToString() + '.dump')
try {
  [IO.File]::WriteAllBytes(`$plainFile, `$dump)
  & '$pgBin\pg_restore.exe' --clean --if-exists --dbname=`$databaseUrl `$plainFile
  if (`$LASTEXITCODE -ne 0) { throw 'pg_restore failed' }
} finally { Remove-Item `$plainFile -Force -ErrorAction SilentlyContinue }
"@
  Set-Content $restoreScript $restoreCode -Encoding UTF8
  $backupAcl = Get-Acl (Join-Path $InstallRoot 'backups')
  $backupAcl.SetAccessRuleProtection($true, $false)
  $backupAcl.Access | ForEach-Object { $backupAcl.RemoveAccessRule($_) | Out-Null }
  $backupAcl.AddAccessRule($adminRule); $backupAcl.AddAccessRule($systemRule); Set-Acl (Join-Path $InstallRoot 'backups') $backupAcl
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $backupScript
  if ($LASTEXITCODE -ne 0) { throw 'Initial database backup failed.' }
  schtasks.exe /Delete /TN 'StoreTrack Daily Database Backup' /F 2>$null | Out-Null
  schtasks.exe /Create /TN 'StoreTrack Daily Database Backup' /SC DAILY /ST 23:30 /RU SYSTEM /TR "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$backupScript`"" /F | Out-Host
}
Write-Host "Central server installed at $InstallRoot" -ForegroundColor Green
Write-Host "API URL: $(if ($TlsKeyFile) { 'https' } else { 'http' })://$env:COMPUTERNAME`:$ApiPort" -ForegroundColor Green
Write-Host "StoreTrack admin username: $AdminUsername" -ForegroundColor Green
Write-Host "Credentials saved to the ACL-restricted file: $credentialFile" -ForegroundColor Yellow
Write-Host 'Next: configure each client with the central PC LAN IP, not 127.0.0.1.' -ForegroundColor Yellow
