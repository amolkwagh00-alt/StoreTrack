# StoreTrack Pro — Deployment Guide
> **Repository snapshot:** 2026-11-12 · root package version 5.0.0. This is a deployment procedure based on repository source, not evidence that a build or customer deployment has passed. Record site-specific results before production use.

## Package contents and build
`npm run build` runs the Windows NSIS desktop build and then `scripts/create-deployment-guide.js`. The latter creates `dist/StoreTrack-Deployment-Guide` containing this guide, the PowerShell installer, setup command, central deployment documentation, security setup, and a README. The build script does not itself provision a central server. Confirm actual files in `dist` after a successful build; source configuration is not proof of a built artifact.

The desktop installer is per-user, allows an install-directory choice, and defines desktop and Start Menu shortcuts. `Build-StoreTrack.cmd` runs tests/validation before invoking `npm run build`; it is a build workflow, not a customer installation wizard.

## Select the central-server deployment route
Choose exactly the route your operations team will maintain:

1. **Windows installer route:** follow the next sections and the detailed [Central Installer Guide](CENTRAL_INSTALLER_GUIDE.md). It requires an elevated Windows host, Node.js, and TLS key and certificate. The script may attempt to install PostgreSQL 18 on port 5433 if its configured PostgreSQL probe fails. It configures a Windows startup task, a scoped API firewall rule, generated credentials and—unless skipped—DPAPI LocalMachine backups/tasks.
2. **Manual or Compose route:** follow [`server/DEPLOYMENT.md`](../server/DEPLOYMENT.md) and `server/docker-compose.yml` instead. This route has separate database, TLS reverse-proxy, environment, task/service, firewall, and backup steps. It does not run or inherit the PowerShell installer's credentials, firewall/task rules, or DPAPI backup behavior. Compose defaults API and PostgreSQL port publishing to loopback and requires explicit secrets, TLS-proxy configuration, and exact CORS origin.

Do not mix instructions from the two paths without explicitly reconciling configuration and operational ownership.

## Windows installer route: prepare host and TLS
Use a protected Windows Server or PC that remains online as required by the site. The installer requires `node.exe` to be discoverable; PostgreSQL may already be available, or automatic installation can be attempted. Confirm your organization permits the installer/package source and verify the actual database port (normally 5432; fallback attempts 5433). Reserve a stable server DNS name and address.

Obtain a TLS certificate from a trusted issuer with the DNS name in its SAN. Store its private key in a protected location, record expiry, and plan renewal. The installer requires both certificate and private-key paths and configures the API to use them directly; a self-signed certificate is not a trusted production chain unless explicitly trusted under organizational policy.

Example paths (substitute site-approved paths):

```text
C:\Certificates\storetrack-server.crt
C:\Certificates\storetrack-server.key
```

## Run the Windows installer
From the deployment bundle, run `Setup-Central-Server.cmd` to request elevation, or run `Install-Central-Server.ps1` from elevated PowerShell with the actual TLS paths and approved firewall scope:

```powershell
.\Install-Central-Server.ps1 `
  -InstallRoot 'C:\StoreTrack\CentralServer' `
  -ApiPort 8787 `
  -TlsKeyFile 'C:\Certificates\storetrack-server.key' `
  -TlsCertFile 'C:\Certificates\storetrack-server.crt' `
  -FirewallRemoteAddress '192.168.1.0/24' `
  -AdminUsername 'admin'
```

Replace the sample CIDR with the approved source range. The script default is `LocalSubnet`; it creates an inbound API-port rule on Domain/Private profiles unless firewall creation is skipped. Do not assume this protects PostgreSQL or proves the rule is effective: inspect rules and test connectivity from both approved and unapproved networks.

The script generates database, JWT, and initial admin secrets. It writes `server\.env` and `credentials.txt`, restricting their ACLs to Administrators and SYSTEM. The environment file initially contains a placeholder CORS origin (`https://your-client-origin.example`): replace it with the exact actual client origin. Verify effective ACLs and secure credential handoff on the host; the installer does not prove that protection or handoff succeeded. Change the bootstrap admin password after first login.

## Verify TLS, API, and desktop clients
The installer configures a server startup task at boot as SYSTEM/highest. Confirm the task runs after reboot and inspect logs. Test `/health` locally and from an approved workstation using the trusted DNS name, without certificate-bypass options. A passing deployment requires a valid trusted chain and matching name, not merely an HTTP response.

Install the StoreTrack Pro NSIS `.exe` on each approved workstation. Configure **Settings → Central Server Synchronization** with the server's HTTPS URL, never the workstation's loopback address or a production plaintext HTTP URL. Record successful login, role-denied access, and synchronization results on actual client and server builds.

Configured clients receive authenticated WebSocket events, pull changes immediately at startup and every 15 seconds as a safety fallback, and scan the central transaction queue every 5 seconds. Failed queued work retries with jittered backoff from 5 seconds up to a 5-minute cap and becomes operator-retryable after 10 attempts; WebSocket reconnect uses jittered backoff from about 3 seconds up to a 60-second cap and stops on terminal authentication errors. These implementation schedules are not latency guarantees: client hardware, local data volume, network conditions, and server/database latency affect results. Treat responsiveness objectives as code budgets for validation, not guarantees. On ordinary local first-run, random admin/store setup credentials are generated and shown once in the login hint; secure and rotate them. Local renderer roles are not a security boundary, while main-process IPC is restricted to the canonical app main frame and unexpected top-level navigation is blocked.

## Backups and recovery checks
Unless `-SkipBackupTask` is used, installer code creates an initial PostgreSQL custom dump and a daily 23:30 SYSTEM/highest task; it retains the newest 30 files. The script protects dumps with DPAPI LocalMachine and removes the temporary unencrypted dump. Check task history and confirm a non-empty `.dump.dpapi` file exists. Record the dump identity, modified time, byte size, SHA-256, task identity/schedule/last-run evidence, and operator/date; a hash identifies bytes but does not show that a restore will succeed.

The generated `Restore-Database.ps1` reads `DATABASE_URL` from its installation's `server\\.env` and runs `pg_restore --clean --if-exists`; it can replace objects in that configured database and has no target override or production-safety check. Never run it for a drill against the production configuration. The dated same-host drill checklist in [Central Installer Guide](CENTRAL_INSTALLER_GUIDE.md#same-host-disaster-recovery-drill-record-dated-2026-11-12) requires a separately identified disposable isolated database and isolated helper/configuration copy, target double-check, representative record and application-health checks, stop/rollback actions, and signed evidence. Do not mark a drill passed unless that record is completed from an actual approved isolated-host exercise. LocalMachine protection ties default decryption to that machine; define and test a separate host-replacement recovery process.

Desktop IndexedDB backups are separate from central PostgreSQL backups. Test each recovery process independently and keep approved off-host copies according to the organization's recovery plan.

## Site acceptance record
Do not mark these complete without recorded evidence. For each item record actual value/result, evidence reference, operator and date/time; use “not run” or “blocked” with owner/reason rather than inferring a pass from configuration:

- [ ] Installer/build version and artifact SHA-256; install, upgrade, and uninstall results.
- [ ] TLS chain, SAN/hostname, expiry, and private-key permissions.
- [ ] API `/health` and trusted client connection; firewall scope and PostgreSQL reachability from workstation networks.
- [ ] Effective ACLs on `.env`, credentials, certificate key, and backup directory.
- [ ] Actual PostgreSQL instance/port, health, migration state, and service/task identity, startup, and logs.
- [ ] Backup task identity/schedule/last run; dump identity, nonzero size and SHA-256.
- [ ] Approved same-host restore drill record, including isolated target identity, representative record checks, application health, stop/rollback disposition, and operator/reviewer sign-off—or explicitly “not run”.
- [ ] Separately accepted off-host/server-replacement recovery and desktop backup/restore.
- [ ] Two-workstation HTTPS/WSS synchronization, role-denial, and controlled stock concurrency tests.
- [ ] Scanner/printer, customer retention, and operational ownership checks.

## Handover
Provide the customer only approved installer/documentation materials, final HTTPS address, firewall scope, and recorded backup/recovery procedure. Do not place `.env`, private keys, plaintext credentials, or unencrypted database dumps in the release folder or email. Record deployment date, server name, certificate expiry, backup and restore-test dates, and support contact.
