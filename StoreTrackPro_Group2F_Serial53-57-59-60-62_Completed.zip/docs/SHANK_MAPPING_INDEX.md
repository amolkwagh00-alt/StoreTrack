# SHANK MAPPING — DOCUMENTATION INDEX
> **Repository review:** 2026-11-05. Source and tests are authoritative; packaged/runtime validation is still environment-specific. See [Current Logic Reference](CURRENT_BEHAVIOR.md).



This documentation package describes the **implemented Shank Mapping / Component Management module** in StoreTrack Pro. It supplements, and does not replace, the integrated **Dashboard → Guide Line** inside the application.

> Use the Dashboard → Guide Line for in-application, searchable instructions. Use this `docs` package for onboarding, process reference, role guidance, troubleshooting, and workflow diagrams.

## Latest Production Documentation

| Document | Purpose |
|---|---|
| [Production Workflow](SHANK_MAPPING_PRODUCTION_WORKFLOW.md) | Current occurrence, stock, forecast, procurement, adjustment, alert, export, and backup rules. |
| [Pooled Stock / Forecast / Procurement diagram](diagrams/09_pooled_stock_forecast_procurement.mmd) | Part-level pooled stock, 90-day effective lead time, order quantity, and order lifecycle. |
| [Adjustment / Alert / Backup diagram](diagrams/10_adjustment_alert_backup_workflow.mmd) | Manual adjustment, physical verification, grouped alerts, and Backup & Restore flow. |
| [RH/LH Common Bin merge diagram](diagrams/11_lh_rh_common_bin_merge.mmd) · [PNG](diagrams/11_lh_rh_common_bin_merge.png) | Eligibility, shared-bin naming, inactive source-bin history, and rollback. |
| [Manual Historical Entry and Search diagram](diagrams/12_manual_historical_entry_and_search.mmd) · [PNG](diagrams/12_manual_historical_entry_and_search.png) | Typed Part No. with suggestions, analytics-only save, and full-dataset table filters. |

## Documents

| Document | Purpose |
|---|---|
| [User Guide](SHANK_MAPPING_USER_GUIDE.md) | Complete practical guide for Store Person, Maintenance Team, Officer/Supervisor, and Administrator. |
| [Quick Start](SHANK_MAPPING_QUICK_START.md) | One-page first-day operating checklist. |
| [How-To Guide](SHANK_MAPPING_HOW_TO.md) | Task-focused instructions for import, typed manual historical entries, stock, replacement, lifecycle, labels, table search, reports, and month-end. |
| [Process](SHANK_MAPPING_PROCESS.md) | Explains the Station → Gun → Shank → common-bin data model and operating process. |
| [Flowchart](SHANK_MAPPING_FLOWCHART.md) | ASCII and Mermaid diagrams for the complete workflow and decision points. |
| [Feature update — 2026-10-07](FEATURE_UPDATE_2026-10-07.md) | Verified behavior changes, refreshed diagram/image list, screenshot status, and validation. |
| [Role Guide](SHANK_MAPPING_ROLE_GUIDE.md) | Role-based operating boundaries and quick guides. |
| [Troubleshooting](SHANK_MAPPING_TROUBLESHOOTING.md) | Problem, likely cause, and corrective action reference. |

## Verified Scope

The module currently covers dynamic Gun Matrix workbook sheet detection, sheet selection, suggested or manual column mapping, editable and full-dataset-searchable dry-run preview, import summaries, confirmed updates, duplicate protection, import snapshots and rollback, Station/Gun mappings, automatic one-common-bin-per-Station creation, eligible RH/LH Common Bin merging with inactive source-history bins, vendor Part Number preservation, stock receiving, physical verification, replacement accountability, stock deduction, Repair/Scrap lifecycle, actual-quantity Repair Return, labels, field-specific table search, Station and Part Number searches, manual analytics-only historical consumption entry with typed Part No. plus suggestions, zero-stock transaction drill-down, historical month-end calculation, accountability export, audit records, and role/capability checks.

Live stock changes use encryption-aware optimistic compare-and-swap (CAS) persistence: the stock record and ledger transaction are committed together; conflicts are retried up to five attempts, then `ATOMIC_MUTATION_CONFLICT` is returned for reload/retry. Historical consumption remains separate and does not affect live balances.

The primary implementation is in `modules/componentManagement.js`. Persistence, indexes, and the current database version are defined in `modules/database.js`. Automated coverage is in `tests/componentManagement.test.js` and the wider test suite under `tests/`.

## Core Rules

| Rule | Implemented behavior |
|---|---|
| Vendor Part Numbers | Shank Mapping preserves supplied Part Number text for storage/display; comparison keys normalize whitespace, case, and leading zeroes in numeric segments separated by `/` or `-`. This matching normalization does not rewrite stored vendor text. A value containing `/` remains one Part Number; blank and `NA` values are excluded. |
| Occurrence and quantities | Auto Safety/Minimum equals valid Gun Mapping occurrence; Maximum Qty equals occurrence × 2. |
| Station bin | Standard Shank parts use a Station Common Bin. Pencil parts instead use station-independent Pencil Pair bins; a Station Common Bin display may only project Pencil quantity. Eligible RH/LH sides merge to an active `<Base> RH/LH Common Bin`; the non-target source bin becomes inactive and pre-merge snapshots support rollback. Unassigned rows do not create a bin. |
| Pooled stock | Procurement and grouped alerts use pooled Part-level quantity across bins; Stock screens remain Bin-wise. |
| Mapping identity | Station, Gun Reference, Position, and Part Number remain distinct; repeated Part Numbers are not globally deduplicated in mapping or labels. |
| Replacement accountability | Maintenance Person must be selected from the searchable directory; Maintenance Team/Department, date/time, shift, old/new Part Numbers, quantity, condition, action, bin, remarks, and logged-in user are retained. |
| Consumption scope | Only Replacement / Issue counts as usage. Receive, Repair Return, Scrap, and Adjustment remain separate; manual remaining quantity and physical verification are adjustments. |
| Procurement | Effective lead time is 30 internal days + 60 supplier days = 90 days. Open/pending orders prevent duplicate ORDER NOW alerts. |
| Month-end | Historical reporting uses the selected `YYYY-MM` month and the formula `Opening + Receive + Repair Return − Replacement − Scrap ± Adjustment = Closing`. |
| Label content | Station/Bin labels show SR No., Fix Shank Part No., and Moving Shank Part No. per mapping row. Inactive merged source bins are excluded from normal label selection. |
| Backup and Restore | Side Menu → Backup & Restore opens the Shank Mapping component section before rendering the backup screen. |

## Current logic clarifications (2026-11-05)

- Status: ZERO STOCK at 0; LOW STOCK only for positive stock below the minimum applied by that view; equality or above is OK STOCK. The row-level stock record compares against `minimumStock`; pooled analytics may compute a part-level requirement from auto-safety/Required Qty and existing minima. Forecast risk labels are separate.
- Standard receiving previews auto-allocation; the Stock Control Excel import instead resolves Station/Gun and checks its row location against the active Common Bin.
- Manual historical entry can save unlisted typed Part Numbers and mapping-review context; historical file import requires a Part Master Part Number. Both are stock-neutral analytics.
- Ambiguous unbolded source candidates require user resolution in import preview; do not assume an automatic Original selection.

## Source References

1. [`modules/componentManagement.js`](../modules/componentManagement.js) — Shank Mapping UI, workflow, validation, reporting, labels, import, lifecycle, and audit behavior.
2. [`modules/database.js`](../modules/database.js) — IndexedDB clean-release identity, current version, Component Management stores, and indexes.
3. [`tests/componentManagement.test.js`](../tests/componentManagement.test.js) — feature-specific regression coverage.
4. [`index.html`](../index.html) — application shell and Dashboard navigation.

## Reading Order

New users should begin with the [Quick Start](SHANK_MAPPING_QUICK_START.md), then read the [User Guide](SHANK_MAPPING_USER_GUIDE.md). Supervisors should also review the [Process](SHANK_MAPPING_PROCESS.md), [Flowchart](SHANK_MAPPING_FLOWCHART.md), and [Role Guide](SHANK_MAPPING_ROLE_GUIDE.md). When a result is unexpected, use the [Troubleshooting](SHANK_MAPPING_TROUBLESHOOTING.md) guide before repeating an import or transaction.
