# SHANK MAPPING — FLOWCHART
> **Repository review:** 2026-11-05. Verify against current source and target build; this documentation is not deployment certification.
> **Repository review (2026-11-05):** This flowchart reflects the RH/LH Common Bin, manual historical consumption, full-dataset import-preview search, and searchable Shank Mapping tables. Target Windows certificate, firewall, ACL, backup-restore, and hardware validation remain deployment-site checks.



This document describes the implemented workflow in both readable text and Mermaid syntax. The diagrams are documentation aids; the application remains the operational source of truth.

## A. Complete System Flow

```mermaid
flowchart TD
    A[Gun Matrix Excel] --> B[Sheet Detection]
    B --> C[Sheet Selection]
    C --> D[Column Mapping]
    D --> E[Searchable, paginated Import Preview]
    E --> F{Import valid?}
    F -- No --> G[Warning / Correct source or mapping]
    G --> D
    F -- Yes --> H[Confirm Import]
    H --> I[Station Mapping]
    I --> J[Gun Reference Mapping]
    J --> K[Fix / Moving Shank Mapping]
    K --> L[Automatic Common Station Bin]
    L --> M[Part Master]
    M --> N[Stock Receiving]
    N --> O[Stock Availability]
    O --> P[Maintenance Replacement]
    P --> Q{Stock available?}
    Q -- No --> R[Block transaction]
    Q -- Yes --> S[Issue and Deduct Stock]
    S --> S1[Atomically compare current stock and write stock + ledger]
    S1 --> T{Removed component repairable?}
    T -- Yes --> U[Repair]
    U --> V[Repair Return]
    T -- No --> W[Scrap]
    V --> X[Labels / Daily Monitoring]
    W --> X
    X --> Y[Historical Month-End]
    Y --> Z[Zero Stock Drill-down]
    Z --> AA[Accountability Export]
```

## B. Excel Import Flow

```mermaid
flowchart TD
    A[Choose workbook] --> B[Detect all worksheets]
    B --> C[Select worksheets]
    C --> D[Suggest or manually map columns]
    D --> E[Build dry-run preview]
    E --> F{Warnings or missing values?}
    F -- Yes --> G[Review warning / skipped rows]
    G --> H{Station variation?}
    H -- Yes --> I[Explicitly use existing Station or create new Station]
    H -- No --> J[Correct source or mapping if required]
    I --> K[Review summary]
    J --> K
    F -- No --> K[Review summary]
    K --> L[Confirm import]
    L --> M[Snapshot, commit, history, audit]
```

The preview reports Rows Scanned, New, Updated, Duplicate, Skipped, and Warnings. Its field filters search the complete imported row set across pages, including Station, Part No. across component columns, Gun Reference, and individual component fields. Exact duplicates are not inserted. Existing mapping updates require confirmation.

## C. Station → Gun → Shank Mapping

```mermaid
flowchart LR
    A[Station No.] --> B[Gun Reference No.]
    B --> C[Fix Shank]
    B --> D[Moving Shank]
    B --> E[Adaptor / Holder / Pencil Shank]
    C --> F[Vendor Part Number]
    D --> G[Vendor Part Number]
    E --> H[Vendor Part Number]
```

Each Station/Gun/Position mapping remains separate even when the same vendor Part Number appears in several rows.

## D. Station → Common Bin

```mermaid
flowchart TD
    A[Assigned Station] --> B{Common Station Bin exists?}
    B -- Yes --> C[Use existing common bin]
    B -- No --> D[Create one Station Bin]
    C --> E[Fix and Moving Shanks use same bin]
    D --> E
    F[Station Not Assigned] --> G[Keep row without creating a bin]
```

## E. Replacement Flow

```mermaid
flowchart TD
    A[Identify Station] --> B[Select Gun]
    B --> C[Review mapped component]
    C --> D[Select Maintenance Person and Team]
    D --> E[Enter old/new Part No. and quantity]
    E --> F[Check available stock]
    F --> G{Stock available?}
    G -- No --> H[Show INSUFFICIENT STOCK and block save]
    G -- Yes --> I[Issue component]
    I --> J[Deduct new Part Number from common-bin stock]
    J --> J1[Encryption-aware optimistic CAS; stock + ledger atomic]
    J1 --> J2{Snapshot conflict or repeated conflicts?}
    J2 -- Retry up to 5 --> J1
    J2 -- Repeated --> J3[ATOMIC_MUTATION_CONFLICT; reload and retry]
    J2 -- No conflict --> K[Write replacement and audit history]
    K --> L[Choose Repair or Scrap for removed component]
```

## F. Repair/Scrap Flow

```mermaid
flowchart TD
    A[Removed Component] --> B[Condition Check]
    B --> C{Repairable?}
    C -- Yes --> D[UNDER REPAIR]
    D --> E[REPAIR COMPLETED]
    E --> F[Repair Return using actual lifecycle quantity]
    F --> G[Stock IN transaction]
    C -- No --> H[SCRAP]
    H --> I[Scrap transaction]
```

## G. Month-End Flow

```mermaid
flowchart TD
    A[Select Month / Year] --> B[Read transactions before month]
    B --> C[Calculate Opening]
    C --> D[Read Receive, Repair Return, Replacement, Scrap, Adjustment through month end]
    D --> E[Calculate Closing]
    E --> F[Review historical report]
    F --> G[Export accountability for same selected month]
```

```text
Opening + Receive + Repair Return − Replacement − Scrap ± Adjustment = Closing
```

## H. Zero Stock Investigation Flow

```mermaid
flowchart TD
    A[Zero Stock Part] --> B[Open transaction drill-down]
    B --> C[Opening balance]
    C --> D[Receive]
    D --> E[Replacement]
    E --> F[Repair Return]
    F --> G[Scrap]
    G --> H[Adjustment]
    H --> I[Running Balance]
    I --> J[Closing Balance / reason stock reached zero]
```

## I. Eligible RH/LH Common Bin Merge

```mermaid
flowchart TD
    A[Same base Station has RH and LH sides] --> B{Each side has 1 or 2 Guns and a valid Common Bin?}
    B -- No --> C[Keep sides separate; review eligibility]
    B -- Yes --> D[Select/confirm opposite RH and LH Stations]
    D --> E[Create active <Base> RH/LH Common Bin]
    E --> F[Move source mappings and consolidate stock]
    F --> G[Mark non-target source bin inactive]
    G --> H[Save source/target snapshots and audit event]
    H --> I[Show only active shared bin in operational lists/labels]
    H --> J[Keep rollback path in merge history]
```

The active bin name explicitly contains `RH/LH`. The non-target source-bin record is inactive; pre-merge source/target snapshots and affected state are retained in history for rollback. Inactive bins are not presented as active bin choices.

## J. Manual Historical Consumption and Table Search

```mermaid
flowchart TD
    A[Manual Historical Consumption] --> B[Choose Part No. suggestion or type a Part No.]
    B --> C[Enter valid date and positive whole-number quantity]
    C --> D{If Station/Gun supplied, is context resolved?}
    D -- No / incomplete / ambiguous --> E[Save with Mapping Review status]
    D -- Yes or not supplied --> F[Save historical row and audit event]
    E --> F
    F --> G[Use for historical analytics/forecasting only]
    G --> H[Do not create live issue or mutate current stock]
    I[Open a large Shank Mapping table] --> J[Search fields shown in that table]
    J --> K[Filter all applicable rows, across Import Preview pages]
    K --> L[Clear Search to restore the full result set]
```

Rendered supporting diagrams: [RH/LH Common Bin merge](diagrams/11_lh_rh_common_bin_merge.png) and [Manual Historical Entry / Search](diagrams/12_manual_historical_entry_and_search.png).

## Decision Rules

| Decision | Yes path | No path |
|---|---|---|
| Import valid? | Continue to confirmation. | Review warnings, skipped rows, or column mapping and correct the source. |
| Station assigned? | Use or create the Station’s one common bin. | Preserve as Station Not Assigned and do not create a bin. |
| RH/LH merge eligible? | Merge only same-base opposite sides with 1–2 Guns per side and valid bins. | Keep sides separate; do not force the merge. |
| Manual historical entry valid? | Save a historical analytics row; current stock is unchanged. | Correct the date/quantity or remove a mismatched supplied Station/Gun. |
| Possible Station variation? | The user explicitly chooses existing Station or new Station. | Continue with the supplied Station. |
| Stock available? | Issue through encryption-aware optimistic CAS; stock and ledger commit together. | Block the replacement; stock cannot become negative. |
| CAS conflict? | Retry the compare-and-swap, up to five attempts. | After repeated conflicts, show `ATOMIC_MUTATION_CONFLICT`; reload and retry. |
| Removed component repairable? | Repair, complete, and return actual quantity. | Record Scrap separately. |

[Back to Documentation Index](SHANK_MAPPING_INDEX.md)
