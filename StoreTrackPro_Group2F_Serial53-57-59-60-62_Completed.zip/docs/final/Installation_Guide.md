# Installation Guide
> **Repository snapshot:** 2026-11-05 · root package version **5.0.0** (`package.json`; central bundle metadata also says 5.0.0). This describes repository code, not a successful build or site certification. Re-run checks for each release. See [Documentation Index](../README.md) and [current-behavior notes](../CURRENT_BEHAVIOR.md).

## Requirements and desktop build
The Electron application declares Electron `^44.5.1`; `postinstall` rebuilds `node-hid` and `serialport`. The root package build target is Windows NSIS:

```bash
npm ci
npm start
# On a supported Windows build host
npm run build
```

`npm run build` runs `build:app` (`electron-builder --win nsis`) and then `build:deployment-guide` (copies a handover guide and central-server scripts into `dist/StoreTrack-Deployment-Guide`). NSIS is per-user (`perMachine: false`), permits choosing the install directory, and defines desktop and Start Menu shortcuts. This describes configuration only; it does not prove that a build, clean install, upgrade, uninstall, or customer deployment succeeded. `Build-StoreTrack.cmd` adds a test/validation sequence before invoking the same build; it is not the installer itself.

## First local launch
On ordinary clean startup with no local users, `loadAll()` generates random setup passwords for local `admin` and `store` accounts, marks both `mustChangePassword`, and displays the one-time credentials in the login hint. Save them securely and change them after first sign-in; the setup flow is local renderer behavior, not a tamper-resistant authorization boundary. A separate destructive **Clear All Data** fallback invokes `seedData()` and generates random `admin`, `store`, and `developer` credentials that it logs to the console; protect that output and do not confuse it with normal first-run setup. Central-server administrator provisioning is separate and uses the `npm run central:create-admin` flow and configured credentials.

## Optional central server — choose one deployment route
The central API is separate from desktop installation and local IndexedDB:

- **Windows installer:** follow [Central Installer Guide](../CENTRAL_INSTALLER_GUIDE.md). The PowerShell script requires Administrator rights and both TLS key and certificate; it configures its own database, secrets, tasks, and firewall behavior.
- **Manual/Compose:** use [server deployment documentation](../../server/DEPLOYMENT.md) and `server/docker-compose.yml`. This route has separate environment, database, TLS-proxy, and startup steps; it does not run the Windows PowerShell installer or inherit its generated credentials, scheduled backup, firewall rule, or DPAPI recovery behavior.

Keep central PostgreSQL and desktop-local data/backup procedures distinct. Do not treat source-level setup instructions as evidence of TLS, firewall, credential ACL, or backup success on a target host.

### Sync timing and security boundaries
When central sync is configured, the client listens for authenticated WebSocket events, pulls changes immediately at startup and then every 15 seconds as a safety fallback, and scans the queued transaction store every 5 seconds. Failed queued items use jittered retry delays beginning at 5 seconds, increasing to a 5-minute cap, and become operator-retryable after 10 attempts. WebSocket reconnect uses jittered exponential delay from about 3 seconds to a 60-second cap; terminal authentication failures stop reconnect. These are code schedules, not delivery-time guarantees: client hardware, local data volume, network/server latency, and outages affect observed results. Treat any responsiveness target as a code budget for validation, not a guarantee. The Electron bridge accepts privileged calls only from the canonical main-frame app document and blocks unexpected top-level navigation; renderer-side local role checks remain distinct from central server authorization.

## Offline and packaging boundaries
Local IndexedDB features may operate without central connectivity. Central sync queue/retry is separate from service-worker caching. The Windows package file allowlist omits `service-worker.js` and `manifest.json`; service-worker API cache/sync paths do not establish complete offline operation. Validate the built artifact before making PWA/offline claims.

## Sources
`package.json`, `Build-StoreTrack.cmd`, `scripts/create-deployment-guide.js`, `modules/database.js`, `app.js`, `main.js`, `server/`, and `installer/`.
