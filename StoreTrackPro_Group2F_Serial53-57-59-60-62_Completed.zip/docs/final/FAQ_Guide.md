# Frequently Asked Questions
> **Repository snapshot:** 2026-11-05 · StoreTrack Pro 5.0.0. Source and tests are authoritative; this is not production certification. See [documentation index](../README.md) and [current behavior](../CURRENT_BEHAVIOR.md).

## Is StoreTrack a web app or desktop app?
The packaged product is an Electron desktop app; a separate central HTTP/WebSocket service is optional. The central service is not the local database.

## Which database/schema is current?
Local IndexedDB: `StoreTrackDB_ShankMapping_Clean_20260825`, version 23. Central PostgreSQL applies migrations 001–005.

## What are the default passwords?
There are no fixed default passwords. Ordinary clean local startup generates one-time random passwords for admin and store, marks those accounts `mustChangePassword`, and displays the credentials in the setup hint. Clear All Data is a separate destructive reset that erases local data and calls the fallback `seedData()` seeder, which creates fresh random admin/store/developer credentials and displays them in the setup hint. Save the appropriate setup credentials securely and change them after signing in; do not conflate normal startup with the reset path.

## Does central login use 2FA?
No central 2FA flow is evidenced. Client-side TOTP functionality is separate.

## Does the central API provide full materials CRUD or reporting?
No. The inspected API has materials GET and POST; no central report-export or material update/delete contract is listed.

## Does offline mode guarantee all operations?
No. Local IndexedDB availability, centralSync queue/retry, shared-folder synchronization and service-worker caching are separate. Validate the specific build and workflow.

## What is Shank Mapping status logic?
Status depends on the Shank Mapping view: the stock-status classification is ZERO STOCK at zero, LOW STOCK for positive stock below that view's applicable minimum, and otherwise OK STOCK. Do not assume Required Qty is the threshold in every view; consumption/forecast screens use their own occurrence/safety-stock and forecast calculations. Forecast risk labels are separate from basic stock status.

## Are Pencil parts held in station Common Bins?
No; physical balances use station-independent Pencil Pair bins. Some station rows may project that balance for display.

## Do historical entries change current stock?
No. Historical consumption is analytics-only. Manual historical entry allows a typed unlisted part; spreadsheet import requires a known Part Master number.

## How does stock commit prevent stale or duplicate writes?
The central API locks the material row, validates the resulting balance (including rejecting negative stock), and persists the stock, transaction, audit/sync events and idempotency response in one database transaction. A repeat using the same authenticated user and transaction UUID/key replays the saved response; a reused transaction ID without an idempotent replay is rejected. In supported local approval-backed stock paths, approval status is guarded as still pending within an atomic read-modify-write, so concurrent duplicate approval cannot apply the stock deduction twice. This is path-specific protection, not a guarantee for every workflow.

## Are response-time budgets measured guarantees?
No. The local monitor defines targets including 100 ms input acknowledgement, 1,000 ms screen usability/local save, 2,000 ms central commit/push, 2,000/5,000 ms stock status for normal/large data, 300/1,000 ms filtering and 3,000 ms small export. These are configurable instrumentation thresholds, not an SLA or measured result. Some categories depend on explicit instrumentation or optional browser event timing, and no user-PC performance follows from the source defaults. Measure on the actual target environment.

## Is XLSX export guaranteed?
No. Current export code describes Excel-compatible HTML workbook/CSV output; parsing Excel is a distinct feature.

## Where are central backups stored and can they move to another machine?
There are distinct backup types. Windows central PostgreSQL installer dumps use DPAPI LocalMachine protection and the generated restore helper is for the same host. The desktop app also supports this-PC encrypted backups protected by that Windows installation's key, plus an explicitly created portable JSON backup that includes its recovery key and can be restored on another PC. Anyone obtaining a portable file can decrypt its data; keep it securely. Do not treat these desktop backups as central database dumps.

## Have all current tests passed?
This documentation refresh did not run the test suite. Use commands in [Testing Documentation](Testing_Documentation.md) and attach date, revision and output to any pass claim.

## Why doesn't the documentation call every module production-ready?
Presence of a module or test name does not prove UI wiring, provider configuration, target-site availability or end-to-end validation.
