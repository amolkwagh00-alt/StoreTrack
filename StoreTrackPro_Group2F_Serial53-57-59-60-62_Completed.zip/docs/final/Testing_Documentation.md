# Testing Documentation
> **Repository snapshot:** 2026-11-16 · StoreTrack Pro 5.0.0. This documentation describes repository code and tests, not a production certification. Re-run relevant checks for every release. See [Documentation Index](../README.md) and [current-behavior notes](../CURRENT_BEHAVIOR.md).
>
> **Execution status:** After the supplied Windows log was reviewed and code fixes applied, `npm test -- --runInBand` passed **53 suites / 488 tests** in the provided sandbox. This is Jest evidence for this workspace snapshot only—not a packaged Windows installer, live PostgreSQL, hardware, or production certification.

## Windows test-log review and follow-up — 2026-11-05

The supplied Windows run log records dependency installation/native rebuild completing (with deprecation notices and Husky skipped because Git was unavailable), 53 Jest suites / 486 tests passing, Playwright 3/3 passing, and smoke/offline checks passing. It then stopped at lint with one error: `app.js:2055` reassigned a `const` in `bulkApproveSelected`; therefore that run did **not** reach `release:check` or the Windows build. Review also found undefined `suppFlt` in Low Stock rendering and undefined `period` in the Shank BI query. All three code issues were corrected and regression assertions added; the central-server release bundle was regenerated because five copied server files were stale.

Post-fix checks in the provided sandbox: Jest **53/488 passed**; Playwright **3/3 passed**; smoke passed (80 module script references and 97 JavaScript files parsed); offline smoke passed (4 checks); `npm run central:bundle` followed by `npm run release:check` passed. `npm run lint` exits 0 with **0 errors / 401 warnings**. The remaining 17 `no-undef` warnings are cross-script references to `canRoleAction` (declared in `modules/auth.js`) and `lblPreviewLayoutCss` (declared in `modules/printing.js`); both scripts load before `app.js`. Other style/unused warnings remain. A Windows installer/build was not rerun after these fixes and remains a handover gate.

## Declared npm checks
The following commands are declared in the root `package.json`. Their declaration does not establish that they were executed or passed.

| Command | Declared scope |
|---|---|
| `npm test` | Jest using root configuration (`tests/**/*.test.js` discovery pattern). |
| `npm run test:unit` | Jest excluding `tests/integration.test.js` through `--testPathIgnorePatterns`. |
| `npm run test:integration` | Jest targeting `tests/integration.test.js`. |
| `npm run test:database` | Jest targeting `tests/database.test.js`, serially (`--runInBand`). |
| `npm run test:gun-count` | Jest targeting `tests/gunCountService.test.js` and `tests/gunCountE2E.test.js`, serially. |
| `npm run test:smoke` / `npm run smoke` | Both run `node tests/smoke.js`. |
| `npm run test:offline` | Runs `node tests/offline-smoke.js`. |
| `npm run test:e2e` | Runs `playwright test`; Playwright is configured to discover `e2e/**/*.spec.js`, currently `e2e/project-shell.spec.js` and `e2e/release-workflows.spec.js`. |
| `npm run test:e2e:ui` | Runs Playwright in UI mode. |
| `npm run test:e2e:report` | Opens the Playwright report; not itself a test run. |
| `npm run test:audit-regressions` | Runs `node tests/storetrack-audit-regressions.js`. |
| `npm run lint` | ESLint configured source/test patterns; it does not include every file under `tests/`. |
| `npm run release:check` | Runs `scripts/release-hygiene.js`. |
| `npm run production:validate` | Runs `scripts/production-validation.js`. |
| `npm run central:bundle` | Runs `scripts/build-central-server-bundle.js`. |

At this snapshot, `tests/` contains 53 files named `*.test.js`, matching the configured Jest filename pattern. Additional test-related scripts/files, including `.node-test.cjs`, are not discovered by the default Jest pattern. `e2e/` contains the two Playwright specs named above. File counts and names are inventory, not execution evidence. For any pass statement, save command, date, branch/commit, environment, and full result.

## Focused regression assertions
The current regression tests include the following targeted checks (assertion coverage is not a statement about whether those tests have been run):

| Area | Test paths and assertion intent |
|---|---|
| Compare-and-swap (CAS) concurrency and duplicate approval | `tests/auditFixes.stock.test.js` verifies concurrent deductions reconcile with the ledger, failed derivation does not write, configured encryption transforms are retained, and concurrent approval is committed once. These are fake-IndexedDB/Jest regressions, not multi-machine production tests. |
| Encrypted persistence | `tests/database.test.js` verifies configured encryption hooks are used for writes/reads and batch writes; `tests/encryption.test.js` covers encryption/decryption, wrong-key and tamper rejection; `tests/dataBackup.portable.test.js` checks restoring encrypted fields adopts the backup key before imported rows are persisted. |
| Central polling/single-flight | `tests/auditFixes.centralSync.test.js` asserts overlapping pulls share one request, an empty pull causes no render or health check, overlapping health checks share one request, retry backoff is bounded/jittered, and terminal failures remain visible/retryable. |
| Material change feed/cursor | `tests/central-material-feed.test.js` asserts a material upsert writes a `material.upserted` event, the filtered poll scans past hidden scoped events and returns the scanned cursor, and the client advances `lastSequence` monotonically. |
| Dashboard widget accessibility/lifecycle | `tests/dashboardWidgets.accessibility.test.js` asserts native Move up/Move down buttons expose accessible names, settings have dialog semantics and labelled fields, re-render destroys existing chart instances first, and mouse controls continue to move widgets. |
| Release assets | `e2e/release-workflows.spec.js` and source/workflow checks cover the configured release path. Workflow configuration is not proof of a successful Windows build or a published GitHub Release; verify the uploaded `.exe` and `.sha256` in the actual draft before publishing. |
| Electron logout and trust boundary | `tests/auditFixes.electron.test.js` asserts privileged IPC accepts only the canonical app document/exact main frame, blocks untrusted navigation, distinguishes terminal authentication close from transient errors, verifies logout clears credentials, and checks retry reset invalidates stale socket callbacks. `tests/auth.test.js` covers renderer logout behavior. |
| Performance monitor | `tests/performanceMonitor.test.js` checks target classification without retaining target text, category thresholds and over-budget warnings, bounded sample storage, clock-fallback mark/measure, Chromium Event Timing's minimum duration threshold, and safe no-op behavior when disabled/APIs are unavailable. |
| Backup verification/restore safety | `tests/dataBackup-features.node-test.cjs` and `tests/dataBackup-consistency.node-test.cjs` cover read-only integrity checking, test-only restore with no writes, malformed-input rejection, per-store preview, and recovery journaling. |
| Central conflict handling | `tests/centralSync-conflicts.node-test.cjs` verifies 409 persistence, no automatic retries, correction constraints, fresh transaction IDs and explicit discard. `tests/auditFixes.centralSync.test.js` contains additional Jest coverage (not run in the current workspace). |
| Archive retention / local schema | `tests/archive-retention.node-test.cjs` checks invalid timestamps/ranges and durable-delete failure behavior; `tests/database-status.node-test.cjs` checks local schema-version/missing-store diagnostics and the central-server caveat. |
| Audit search and recovery messages | `tests/error-audit-guidance.node-test.cjs` checks user/module search, malformed legacy values, result-cap notice, and operation-specific recovery text. |
| Import/export progress and central schema diagnostics | `tests/feature-batch-90-100.node-test.cjs` checks chunked CSV progress/cancel/retry, import commit progress/cancel-state UI, shared Shank XLSX/PDF progress/cancel/retry wiring, central migration status comparisons and admin-only route wiring. |

## Performance budgets and interpretation
`modules/performanceMonitor.js` defines local budgets (milliseconds): acknowledgement 100; ordinary screen usable 1000; Stock Status normal data 2000; Stock Status large data (>5,000 rows) 5000; filter 300; filter on >5,000 rows 1000; local save 1000; central LAN commit 2000; central push-to-render 2000; small export (<=1,000 rows) 3000. The monitor supports configurable category thresholds.

These are budgets for **sample-based monitoring**, not continuous profiling or a guarantee of application latency. Chromium Event Timing collection uses a 16 ms minimum `durationThreshold`; explicit mark/measure/record calls are available for other operations. The default in-memory ring retains at most 200 samples (configurable up to 1,000); only fixed categories, numeric durations and timestamps are kept, not caller labels or user data, and samples are not transmitted. `summary()` reports sample count, mean (`averageMs`), p95, threshold, and exceedance count by category; absent categories have no summary entry. A passing summary applies only to observed samples and workload.

## Runtime/site verification still requires actual environments
Record separate evidence for Electron/IndexedDB, Windows NSIS installation/upgrade/uninstall, central PostgreSQL migration/concurrency, TLS/firewall/ACL/reboot, backup restore, HID/serial scanners, printers and multi-workstation operation. `tests/STORETRACK_RUNTIME_PENDING_11_TEST_CASES.md` is a test plan, not a run report. In particular, automated unit/regression assertions do not establish deployed central-server or real hardware behavior.

For the 2026-11-11 maintenance package, the complete standalone Node regression set passed **215/215**, including the focused P21/P23/P25/P29/P31/P37/P45/P48/P49/P50 cases after correcting stale source assertions and incomplete VM test fixtures. The separate audit-regression script passed **36/36 assertions**, release hygiene passed, focused backup/recovery tests passed **12/12**, and modified JavaScript syntax checks passed. Jest suites were not run because Jest dependencies are not installed in this workspace. No Windows installer build, live PostgreSQL synchronization, or GitHub release upload was executed; keep those as pending acceptance checks rather than claiming release/runtime completion.

## Historic records
`docs/closure-matrix-updated.csv` preserves its historical rows and now has additive 2026-11-05 code-status entries. Those entries remain `FIXED_CODE_RUNTIME_PENDING`: the Jest result above does not replace Electron packaged-build, real multi-window, host, live service, hardware, or restore validation. Historical validation totals in older reports remain historical only.

## Maintenance implementation verification — 2026-11-13
The current full standalone Node run passed **231/231**. The source audit passed **36 assertions**, release hygiene passed, and modified-JavaScript syntax checks passed. Focused tests cover backup integrity and non-mutating test restore, central HTTP 409 conflict handling, archive retention, local schema status, audit search and recovery guidance. Jest dependencies are not installed in this workspace, so Jest was not run. No Windows installer build, live central database synchronization, actual host restore drill, or GitHub Release upload was executed; those remain acceptance gates, not completed work.

Continuation result on 2026-11-13: full standalone Node suite passed **242/242**. New focused coverage exercises CSV quoted-field parsing and cancellation-before-write, filtered audit exports, item-level stock accuracy math, unmapped transaction detection, expanded global-search coverage, terminal Central Sync failure notifications, and per-device/version sync health metadata. The source audit again passed **36 assertions**, release hygiene passed, and syntax checks passed. The added tests are source/runtime unit regressions, not GUI/Electron end-to-end tests; Jest, Windows packaging, live central service, and production restore remain unrun.

Final implementation checks on 2026-11-14: the suite contains 25 standalone Node test scripts; all **242 TAP cases passed (0 failed)**. Three additional assertion-based test scripts passed for local transaction attachments (type/size/signature validation, IN/OUT persistence hooks, history access), linked correction entries (IN/OUT compensation, immutable original, reason, duplicate and negative-stock protection), and per-alert recipient preferences (per-user/channel isolation, enabled/disabled and allow-by-default behavior). Audit regression passed **36 assertions**, release hygiene passed, and changed JavaScript syntax checks passed. These checks do not replace Jest, actual Electron UI/E2E, Windows packaging, a live central server, or a production restore drill; none of those were run in this environment.


## Selected-feature batch 1 verification — 2026-11-16

The first five selected serials (100, 97, 95, 93, 90) were reviewed as a batch. Search/recovery guidance/disaster-recovery content for 100, 93 and 90 already had corresponding implementation and focused regression coverage, so those were retained rather than duplicated. Serial 97 now exposes a read-only, developer/admin-only `GET /api/admin/migrations` endpoint through the Electron bridge and System Diagnostics. Serial 95 adds live Shank Matrix commit progress and cancel-state clarity, plus chunked progress/cancel/retry for app CSV report exports and shared Shank Mapping XLSX/PDF export routes. Serial 95 remains partially complete because other standalone legacy XLSX/PDF paths do not all use the shared progress panel.

The complete standalone Node suite passed **248/248**, including new focused cases for CSV export progress/cancellation/retry, Shank import progress UI, and central migration status/role wiring. Audit regression passed **36 assertions**, release hygiene passed, modified JavaScript syntax passed, and the central-server ZIP was regenerated and checked for the admin migration route. This is not a Jest, packaged Electron, Windows installer, live PostgreSQL/API, or end-user GUI run. Serial 95 stays in the backlog; the next five to address are **95, 78, 77, 75, 71**. See [Current Behavior](../CURRENT_BEHAVIOR.md) for the complete remaining serial list.
