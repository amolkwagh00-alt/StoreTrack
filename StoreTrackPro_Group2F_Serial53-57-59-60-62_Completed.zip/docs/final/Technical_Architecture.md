# Technical Architecture
> **Repository snapshot:** 2026-11-05 · StoreTrack Pro 5.0.0. This documentation describes repository code and tests, not a production certification. Re-run relevant checks for every release. See [Documentation Index](../README.md) and [current-behavior notes](../CURRENT_BEHAVIOR.md).

## Product boundary
StoreTrack Pro is an Electron desktop application with a renderer (`index.html`, `app.js`, `modules/`), a privileged Electron main process (`main.js`), and a preload bridge (`preload.js`). The renderer owns local IndexedDB access through `modules/database.js`; the main process provides privileged OS, filesystem, encryption, printing and central-credential operations through exposed bridges. Central API authorization is enforced by the server for its own routes; local renderer role checks are not a remote, server-enforced security boundary.

A separate optional central service lives in `server/` and uses PostgreSQL. Desktop local data and central PostgreSQL data are distinct stores with distinct deployment, authentication, backup and recovery paths. `release/central-server/` is generated output and must be checked against `server/` before release (`npm run central:bundle`, then `npm run release:check`).

## Data and communication paths
- Desktop domain modules read/write local IndexedDB database `StoreTrackDB_ShankMapping_Clean_20260825`, schema version 23.
- Renderer privileged calls travel through APIs exposed by `preload.js`; central API handlers in `main.js` are registered through `secureHandle`, which checks for a `file://` sender and the primary window when it exists. This is an IPC boundary, not a claim that every local operation has server-side authorization.
- Shared-folder/master-file sync is a local file workflow; it is not the same as central API sync.
- Central mode uses HTTP(S) requests and an authenticated WebSocket stream, according to the configured base URL and server TLS/deployment configuration. `main.js` accepts either `http://` or `https://`; the server can create HTTP or HTTPS depending on key/certificate settings. Production LAN exposure should use correctly configured trusted TLS termination/direct TLS and network controls; the source alone does not establish that a deployed proxy is trusted or functioning.
- Central stock commits, materials, account synchronization and event records operate against PostgreSQL through server routes. `modules/centralSync.js` maintains a local queue for selected stock-commit failures and polls changes in addition to receiving stream events; this does not make every local transaction a central transaction.
- `modules/centralSync.js` queue/retry logic is distinct from `service-worker.js`; the latter is not proof of working offline central synchronization.

## Authentication and trust boundaries
Local account/session and capability checks are implemented in client code. Central service authentication uses signed JWTs plus database-backed user active/role/session-version and revocation checks on protected HTTP requests; WebSocket connections are authenticated on upgrade and rechecked for revocation/session changes. Central role controls apply only to routes that enforce them (for example, materials/user administration and stock commits have distinct role rules). The server also applies scoped-event filtering to sync polling and the WebSocket stream; legacy/unscoped events remain visible. Client TOTP is local feature code; it is not a central-server second factor. See [Security](Security_Documentation.md), [API](API_Documentation.md), and [Database](Database_Documentation.md).

## Local atomic stock persistence and performance instrumentation

The local `atomicReadModifyWrite` helper in `modules/database.js` provides encryption-aware optimistic compare-and-swap (CAS). It reads raw IndexedDB snapshot(s), decrypts/restores them and derives the update, then prepares/encrypts writes before opening the write transaction. Inside that transaction it re-reads and compares every raw snapshot; on a match it atomically writes the primary record and related records (for example, approval, transaction, or ledger records). Conflicts retry up to five attempts, then return `ATOMIC_MUTATION_CONFLICT`. This is a local IndexedDB guarantee for callers using this helper, not a universal guarantee for every persistence path. Approval-backed stock posting also guards that the approval remains `pending` in the atomic read-modify-write to prevent duplicate posting.

`modules/performanceMonitor.js` keeps numeric durations and allow-listed categories in bounded in-memory samples only, excludes labels/URLs/input values and other user data, and never sends these local metrics. Its budget thresholds are configurable targets used for local warnings/summaries, not measured guarantees or service-level commitments.

## Packaging caveat
`package.json` defines a Windows NSIS package and a file allowlist. The allowlist does not include `manifest.json` or `service-worker.js`; therefore do not claim packaged PWA/service-worker behavior without checking the actual artifact. The build command does not establish target-site TLS, hardware, install, restore, or multi-workstation success.

## Architecture sources
`main.js`, `preload.js`, `app.js`, `modules/database.js`, `modules/centralSync.js`, `server/index.js`, `server/auth.js`, `server/db.js`, `package.json`, and `installer/Install-Central-Server.ps1`.
