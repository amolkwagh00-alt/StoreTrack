# End User Manual
> **Repository snapshot:** 2026-11-06 · StoreTrack Pro 5.0.0. This documentation describes repository code and tests, not a production certification. Re-run relevant checks for every release. See [Documentation Index](../README.md) and [current-behavior notes](../CURRENT_BEHAVIOR.md).

## Scope
This repository includes two distinct domains: general materials inventory and Shank Mapping/component workflows. Screens and permissions vary by role; ask an administrator if an action is unavailable. `docs/SHANK_MAPPING_INDEX.md` links the focused workflow guides.

## Sign in
On ordinary clean local startup, the app creates local admin/store accounts with one-time random setup passwords displayed in the login hint; both accounts require a password change. Save those credentials securely and change them promptly. Clear All Data is a separate destructive reset path: it erases local records and its fallback seeder creates fresh random admin/store/developer credentials and displays them in the setup hint. Do not confuse this with normal startup or assume old passwords remain valid. Central login, if configured, is separate from local sign-in. Log out when finished and report account lockout to the administrator; no central reset endpoint is documented.

## General material stock
Use the matching Material In/Out screen, confirm the material/barcode, quantity and transaction details before commit. Central material operations are available only when configured; the central stock commit locks the material row, validates non-negative resulting stock, and atomically records stock, transaction, audit/sync events and a user-scoped idempotency response. Retrying the same transaction ID/key replays its saved response; a reused ID without a saved replay is rejected. Local IndexedDB stock paths use atomic read-modify-write for supported workflows, but do not automatically inherit the central API's guarantees.

## Shank Mapping essentials
- **Shank Receiving keyboard flow:** In the Part No. box, use Arrow Down to highlight a datalist option and press Enter; focus moves to **Total Received Quantity**. After entering a positive whole-number quantity, StoreTrack shows a confirmation notice when auto-bin allocation is ready. Press Enter again while the quantity field is focused to activate **Receive Stock by Kit Allocation** and post the receipt. Enter is the explicit commit—check the Part No., quantity, source and allocation first. After a successful receipt, the same Part No. is restored in the field with focus and its text selected; quantity remains blank for the next entry. Invalid quantity or the absence of an active mapped Common Bin prevents receipt.
- Mapping rows retain Station + Gun Reference + Position + Part identity; a part may map at multiple stations.
- Match uses normalized Part Number comparisons (whitespace/case and numeric-segment leading zeroes); this is comparison-only, and saved/displayed vendor text remains as entered.
- Import ambiguity must be resolved in preview; the app must not silently choose among unbolded alternatives.
- Eligible LH/RH pairs can share a Common Bin when each side has one or two guns and both have valid bins; this is conditional, not universal.
- Pencil pairs use station-independent `PENCIL-BIN-##` physical stock. A station Common Bin display can be a read-only projection, not another physical balance.
- Status: ZERO STOCK at 0; LOW STOCK for positive stock below the applicable stock minimum (including Required Qty where set); OK STOCK at/above that minimum. Forecast risk labels are separate.
- Standard Fix/Moving Shank stock uses Station Common Bins; Pencil parts instead hold physical stock in station-independent Pencil Pair bins, and a Station display may only project that quantity. Stock Control Excel import is its own Station/Gun-based Fix/Moving receipt flow, not the standard receiving allocation flow.
- When there is no authoritative Part Master type, the supported Pencil identifier fallback includes `07-0526/43`, `07-0526/48`, `06-417/L30` and legacy `06-417/L35`; `05-0589` does not match that fallback. Verify the actual Part Master type and import preview rather than relying on a code example alone. Different base series never pair; a single leftover part receives its own single-item Pencil Bin.
- Manual historical consumption accepts a typed unlisted Part Number; historical file import requires an existing Part Master Part Number. Both historical modes are analytics-only and do not change live stock. Historical mode must not be confused with Live Replacement import, which deducts stock.
See `SHANK_MAPPING_USER_GUIDE.md`, `SHANK_MAPPING_HOW_TO.md`, `STOCK_ENTRY_EXCEL_IMPORT.md`.

## Search, reports and exports
Use only the search/report controls present in your current screen. Excel-compatible HTML/CSV export is not proof of a native XLSX writer. PDF/print functions use local bridges; the central API does not expose report export. Verify preview, printer, paper and destination before printing.

## Scanner and accessibility
Scanner configuration supports HID or serial paths; serial port/baud and separate IN/OUT assignment depend on the attached device. Discover/test the actual unit; compatibility is not guaranteed by source code alone. Keyboard and focus aids exist, but are not WCAG certification.

## Response-time targets
The local performance monitor defines default target thresholds: input acknowledgement 100 ms; ordinary screen 1,000 ms; stock status 2,000 ms (large dataset 5,000 ms); filter 300 ms (large dataset 1,000 ms); local save 1,000 ms; central LAN commit/push 2,000 ms; small export 3,000 ms. These are instrumentation budgets, not measured performance promises. Measurement is bounded and local, and some categories require explicit instrumentation or optional browser event-timing support. They do not establish performance on your PC, network, or production data; collect measurements on the target environment.

## Offline and recovery
Local IndexedDB availability and central queue/retry are distinct; neither proves every screen or PWA capability works offline. For desktop recovery, ask which backup type applies: this-PC encrypted backups use the originating Windows installation's protected key; the optional portable JSON includes its own recovery key and can be restored on another PC. Anyone with that portable file can decrypt its data, so protect it accordingly. These are separate from central PostgreSQL installer dumps and their same-host restore process. Follow the administrator's approved process and verify the restore target before proceeding.
