# Executive Summary

> **Repository snapshot:** 2026-11-05 · StoreTrack Pro 5.0.0. This summarizes repository code/configuration/tests and is not production certification. See the [documentation index](../README.md) and maintained [current behavior hub](../CURRENT_BEHAVIOR.md).

StoreTrack Pro has two related but distinct application domains: an Electron desktop application using local IndexedDB and an optional separately deployed Node/PostgreSQL central service. Renderer/local permissions, central roles, local storage, shared-folder sync and central HTTPS/WebSocket synchronization do not share one implicit authority or transaction boundary.

## Current repository facts

The desktop database is `StoreTrackDB_ShankMapping_Clean_20260825`, IndexedDB schema v23. Central SQL migrations are 001–005. Windows desktop packaging is configured as NSIS; the Electron dependency is `^44.5.1`. Shank Mapping includes Part Master, station/gun mappings, Common/Pencil bins, stock/lifecycle/history and analytics. The central API is narrower than full product CRUD; see [API Documentation](API_Documentation.md).

Local atomic read-modify-write uses encryption-aware optimistic compare-and-swap: decrypted snapshots are derived outside the write transaction, encrypted payloads are prepared, raw snapshots are rechecked inside a single IndexedDB read-write transaction, and conflicts retry up to five times before an explicit conflict error. This is local-database atomicity, not distributed atomicity. BI approvals are auditable workflow records, not a universal guard on every stock write. Recommendations are not automatically applied; approval requirements must be evaluated per operational route/call site.

Configured performance budgets include acknowledgement 100 ms, ordinary screen 1,000 ms, Stock Status 2,000/5,000 ms (normal/large data), filter 300/1,000 ms, local save 1,000 ms, central commit/push 2,000 ms each and small export 3,000 ms. These are code targets, not achieved results. Central health/queue/pull timers run at 30/5/15-second intervals when central sync is configured and active; these do not guarantee freshness.

## Readiness and evidence

After reviewing the supplied Windows run log and applying code fixes, the 2026-11-05 sandbox follow-up passed **53 suites / 488 Jest tests**, Playwright 3/3, smoke/offline checks, and release hygiene; lint exited 0 with 401 warnings and no errors. This is repository-level evidence only. The Windows installer/build was not rerun after the fixes; live TLS/site, hardware and restore-drill certification also remain pending. Dated closure/audit records remain snapshots, not proof every item is runtime-verified. See [Testing Documentation](Testing_Documentation.md), [Maintenance Guide](Maintenance_Guide.md), and the [current behavior hub](../CURRENT_BEHAVIOR.md).
