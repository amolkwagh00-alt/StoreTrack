# Troubleshooting Guide
> **Repository snapshot:** 2026-11-05 · StoreTrack Pro 5.0.0. This documentation describes repository code and tests, not a production certification. Re-run relevant checks for every release. See [Documentation Index](../README.md) and [current-behavior notes](../CURRENT_BEHAVIOR.md).

| Symptom | Safe first checks |
|---|---|
| IndexedDB upgrade waits/blocked | Close every StoreTrack window/instance using the profile; restart the intended version and inspect console diagnostics. Do not delete the DB without a verified backup. |
| Local login/seed credential issue | For a normal clean startup, use the one-time credentials shown in the login hint and change them immediately. Do not confuse this with Clear All Data, whose fallback seeder generates random credentials and logs them to console; protect that output. |
| Central login/API unavailable | Confirm HTTPS URL, certificate chain, server health, DNS/firewall, account active status and server logs. `/health` and login are public; protected routes require valid current token/session. |
| Changes not appearing centrally | Check centralSync configuration/queue and network/service health separately from service worker and shared-folder sync. Capture queued item/error before retrying. |
| Stock commit conflict | Refresh material/stock, check quantity and idempotency transaction identity; do not repeat blindly. |
| Shank mapping ambiguity | Resolve every ambiguous candidate in import preview; verify station, gun, position, part and bin before commit. |
| Pencil inventory mismatch | Check station-independent `PENCIL-BIN-##` as physical stock source; common-bin station rows may only project quantity. |
| Scanner unavailable | Check selected HID/serial mode, connected device, serial COM/baud, separate IN/OUT assignment, permissions and test event. Device/model support is environment-specific. |
| Backup restore issue | Identify the exact backup format first. DPAPI LocalMachine central dumps require same host; portable client export contains recovery material and must be protected. Preserve original and follow approved restore procedure. |

Do not follow old guidance that a missing crypto/fs import currently blocks central server startup: current root server files import them. Escalate with app version, OS, exact steps, redacted logs and backup status. Never share tokens, passwords, private keys, database dumps or portable backup files in support logs.
