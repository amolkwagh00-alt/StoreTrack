# Database Documentation

> **Repository snapshot:** 2026-11-05 · StoreTrack Pro 5.0.0. This describes repository implementation, not a production certification. Re-run checks for each release. See [Documentation Index](../README.md) and [current-behavior notes](../CURRENT_BEHAVIOR.md).

## Desktop IndexedDB

The desktop renderer opens the IndexedDB database **`StoreTrackDB_ShankMapping_Clean_20260825` at schema version 23** (`modules/database.js`, constants `DB` and `VER`). It is deliberately a distinct identity from the older `StoreTrackDB` database; it is not version 7 or 9 of that old identity. The version 23 source comment identifies atomic Shank allocation-batch history and undo snapshots. The `STORES` declaration and upgrade/index code in `modules/database.js` are authoritative for the current store and index set. The schema includes local materials, transactions, users, audit/configuration and operational records, Shank Mapping stores, and local central-sync queue/metadata stores.

IndexedDB upgrades create missing stores and indexes; the source cleanup comment notes that removing a name from `STORES` does not delete an existing store. An upgrade can be blocked by another open connection/window, so close other app instances and retry if the upgrade reports a block. The local database is not the central PostgreSQL database, and the central migrations do not migrate or define this IndexedDB schema.

## Local atomic stock mutations

`modules/database.js` exposes `atomicReadModifyWrite` for encryption-aware optimistic CAS on local IndexedDB. The helper reads raw snapshots, decrypts/restores records, derives the mutation, and prepares/encrypts the resulting writes before starting the write transaction. The transaction rechecks each raw snapshot and queues no writes unless all still match; when they do, primary and related records are committed atomically. A changed snapshot retries, up to five attempts, after which the helper throws an error with code `ATOMIC_MUTATION_CONFLICT`. The mechanism applies only to operations routed through the helper. Approval workflows additionally validate the approval status is still `pending` within the same guarded atomic mutation before posting stock, transaction, and approval changes.

## Central PostgreSQL

Central PostgreSQL is an independent service and schema, not a remote mirror of all local IndexedDB stores. `server/db.js` applies migrations `001` through `005`, tracking applied migration identifiers in `schema_migrations`; startup invokes migration and `npm run central:migrate` is also provided (`server/migrate.js`). These migrations establish the central tables and role definitions, a case-insensitive username uniqueness index, an idempotency-key retention index, and `app_users.session_version`. Migration 004 itself creates the index; the migration runner records its version after successful execution.

Central tables include `app_users`, `app_roles`, `materials`, `stock_transactions`, `idempotency_keys`, `revoked_tokens`, `audit_events`, `sync_events`, and `schema_migrations`. The migration SQL is the source of truth for columns, constraints, and indexes. Local IndexedDB `users` and central PostgreSQL `app_users` are separate account stores; do not assume a local account, password, or 2FA enrollment automatically exists centrally.

Central stock commit in `server/db.js` uses a transaction, locks the material row, checks user-scoped idempotency, updates stock and writes transaction, sync/audit events, and persists the response. This does not mean every local IndexedDB or Shank Mapping operation is a PostgreSQL transaction. Part Number normalization/display behavior is implemented elsewhere and is not a database guarantee.

## Authentication-related data

The local account records live in IndexedDB `users`; central identities live in PostgreSQL `app_users`. Local login can remain usable offline, with central login/sync optional when configured. Local user records are excluded from the desktop complete operational backup and preserved on restore. Central accounts are not part of that desktop backup. See [Security Documentation](Security_Documentation.md) for the different authentication and 2FA behaviors.

## Backups, portability, and recovery limits

These are distinct formats and recovery mechanisms:

1. **Desktop complete operational backup:** `modules/dataBackup.js` exports the stores except `users`. The Electron main-process boundary in `main.js` encrypts/authenticates the backup using AES-256-GCM with a key protected through Electron `safeStorage` on the originating computer. A machine-bound complete backup generally cannot be decrypted on another computer; use the app's portable JSON export on the source machine when transferring operational data. Legacy plaintext backup files can still be detected for compatibility and should be treated as untrusted/plaintext.
2. **Portable desktop JSON:** The export is encrypted/authenticated, but its recovery key is embedded in the JSON file itself. Anyone who obtains that file can decrypt its contents, so it is portable rather than confidential against its holder; protect it accordingly. Restore preserves target `users` accounts and does not import source local account records. The payload can include 2FA store rows, but 2FA seeds are protected using OS-backed key storage (`modules/dataEncryption.js`); cross-machine recovery of those protected seeds is not established by the portability test and should not be relied on. Re-enrol 2FA on the destination if needed. Central users/data are not represented by this local export.
3. **Central Windows PostgreSQL dump:** `installer/Install-Central-Server.ps1` runs `pg_dump` custom-format and protects dump bytes with DPAPI `LocalMachine`; its helper restores on that Windows machine. These dumps are machine-bound and are not portable cross-machine recovery artifacts. The installer retains a rolling set of dumps, not an off-host copy.
4. **Other/legacy JSON exports and rolling master JSON copies:** These are not interchangeable with the above complete encrypted backup or PostgreSQL dump. Some legacy/settings export paths are plaintext; inspect the specific format before relying on it for recovery.

Test restores on the actual target platform, keep an authorized off-host recovery copy, and retain separately the credentials/keys required for each recovery path. No successful production-site restore is asserted here. Sources include `modules/database.js`, `modules/dataBackup.js`, `modules/dataEncryption.js`, `modules/secureBackup.js`, `main.js`, `server/db.js`, `server/migrations/`, and `installer/Install-Central-Server.ps1`.
