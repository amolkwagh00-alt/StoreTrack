# Source Code Documentation
> **Repository snapshot:** 2026-11-05 · StoreTrack Pro 5.0.0. This documentation describes repository code and tests, not a production certification. Re-run relevant checks for every release. See [Documentation Index](../README.md) and [current-behavior notes](../CURRENT_BEHAVIOR.md).

## Main areas
| Path | Responsibility (source tree) |
|---|---|
| `app.js`, `index.html`, `styles.css` | Renderer UI, workflows and startup. |
| `main.js`, `preload.js` | Electron process boundary, narrow bridges and OS integration. |
| `core/` | Shared domain utilities/contracts (including Part Number normalization). |
| `modules/` | Feature modules: database, auth, Shank Mapping/component management, backup, sync, import/export, reporting, analytics and more. Presence does not mean production enabled. |
| `Scanner/` | HID/serial scanner integration. |
| `server/` | Optional central Node API, auth, PostgreSQL DB and migrations. |
| `installer/`, `release/central-server/` | Windows central installer and generated release bundle. |
| `tests/`, `e2e/`, `.github/workflows/` | Automated checks and CI definitions; inspect package scripts for invocation. |
| `docs/` | Guides, diagrams, generated exports, inventories and historical audit records. |

## Release copy synchronization
`release/central-server/` is generated from root `server/` by `npm run central:bundle`; then run `npm run release:check`. A successful source check is not an installer/site/runtime pass.

## Historic defect correction
Older documentation said central startup lacked `crypto`/`fs` imports. Current root `server/auth.js` and `server/db.js` include those imports; remove that claim as a current blocker.

## Sources
`package.json`, `scripts/build-central-server-bundle.js`, `scripts/release-hygiene.js`, source directories and test directories.
