# Administrator Guide
> **Repository snapshot:** 2026-11-05 · StoreTrack Pro 5.0.0. This documentation describes repository code and tests, not a production certification. Re-run relevant checks for every release. See [Documentation Index](../README.md) and [current-behavior notes](../CURRENT_BEHAVIOR.md).

## Separate local and central roles
Local UI capability roles are developer, admin, store, maintenance, auditor and viewer (`modules/auth.js`). Central API roles are independently defined/enforced (`server/migrations/002_roles.sql`, `server/index.js`). Route guards are specific: stock commit permits developer/admin/store; user creation permits developer/admin, with developer creation restricted to developer. Do not infer central control over all local screens.

## Account operations
Ordinary clean local startup creates admin/store accounts with newly generated one-time random setup passwords, marks them for password change, and displays them in the login hint. Securely deliver/save these credentials and change them promptly. Clear All Data is a distinct destructive local reset: it erases records and invokes a fallback seeder that creates fresh random admin/store/developer credentials displayed in the setup hint. Do not treat it as standard installation or rely on prior credentials. Central bootstrap uses the separate `npm run central:create-admin` path or installer handoff. No central password-reset route is listed.

## Inventory administration
Review Part Master and Station/Gun mappings separately. Preserve source-row identity; resolve ambiguous candidate fields before import. Common-bin LH/RH merging is conditional. Pencil Pair physical stock belongs to station-independent Pencil bins, not a station bin projection. See Shank Mapping index and user guides.

For central stock writes, the service row-locks a material, validates the resulting quantity, and commits the balance, transaction, audit event, sync event and user-scoped idempotency response in one database transaction. Retries with the same user and transaction UUID/key return the saved response; IDs already used without that replay are rejected. Local stock-changing workflows use IndexedDB atomic read-modify-write in supported paths. Approval-backed local stock deductions guard that the approval is still pending inside the atomic operation, preventing a concurrent repeat approval from deducting stock twice. These guarantees are path-specific, not a promise that every workflow is transactional.

## Backups and security
Keep backup types distinct. Windows central installer PostgreSQL dumps use DPAPI LocalMachine protection and the generated restore helper is for the same host. The desktop app offers this-PC encrypted backups protected by the originating Windows installation's key, and a separate portable JSON export that includes its recovery key and can be restored on another PC. Anyone holding that portable file can decrypt its data; store and transfer it accordingly. Desktop backups are not central PostgreSQL dumps. Follow the maintenance guide for the applicable restore workflow, then verify access controls, firewall, CORS, TLS, PostgreSQL exposure and scheduled task on the target host.

## Capability availability
A module or menu claim is not proof a capability is enabled, correctly provisioned, or production-supported. Validate role-specific workflows on the exact build and document outcome.

`modules/performanceMonitor.js` defines default response-time budgets (for example, 1,000 ms ordinary screen, 2,000 ms central commit, and 2,000/5,000 ms stock-status normal/large-data). The monitor records bounded local measurements, optionally uses browser event-timing support, and permits explicit instrumentation; categories can therefore have no samples. Budgets are targets, not test results, SLAs or user-PC performance claims. Gather and document measurements on the actual target configuration.
