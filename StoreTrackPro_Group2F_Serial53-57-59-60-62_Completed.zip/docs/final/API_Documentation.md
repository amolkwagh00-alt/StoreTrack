# API Documentation
> **Repository snapshot:** 2026-11-16 · StoreTrack Pro 5.0.0. This documentation describes repository code and tests, not a production certification. Re-run relevant checks for every release. See [Documentation Index](../README.md) and [current-behavior notes](../CURRENT_BEHAVIOR.md).

## Central service routes (source inventory)
| Method/path | Authentication / role | Purpose and notes |
|---|---|---|
| `GET /health` | None | Queries PostgreSQL and returns database time, server time, uptime and version. |
| `POST /api/auth/login` | None | Authenticates an active user; in-memory IP+normalized-username throttling; returns JWT and a user summary. |
| `POST /api/auth/logout` | Bearer | Revokes the current token in process memory and persisted revocation data. |
| `GET /api/admin/migrations` | Bearer; developer/admin | Read-only applied/pending central PostgreSQL migration versions; does not execute migrations. |
| `POST /api/ai/events` | Bearer; `audit_run` also requires developer/admin | Accepts only `chat_query`, `audit_run`, `root_cause_run`, or `export_guidance`; stores a sanitized subset of event fields. |
| `GET /api/materials` | Bearer | Returns central materials. |
| `POST /api/materials` | Bearer; developer/admin | Upserts by material ID (not a full CRUD API); requires ID, barcode and name. |
| `POST /api/gun-count` | Bearer | Calculates and returns `occurrence-v1` metrics from source and mapping arrays; it does not persist a gun-count record. Rate/row limited. |
| `GET /api/sync/changes` | Bearer | Incremental event polling; page size capped at 2,000 and scoped events filtered against the user's tenant/site/location/device claims. |
| `POST /api/transactions/stock` | Bearer; developer/admin/store | Idempotent stock commit with material-row locking, audit and sync writes. |
| `POST /api/users` | Bearer; developer/admin; creating a developer restricted to developer | Creates a central user. |
| `POST /api/users/sync` | Bearer; developer/admin | Synchronizes up to 500 account records; existing account updates increment `session_version`. |
| `GET /api/sync/stream` (WebSocket upgrade) | Bearer on upgrade | Authenticated scoped event stream; session/revocation state is rechecked during the connection. |

The route table is the central server's surface, not a promise that every desktop feature has a central API capability. The Electron central bridge in `preload.js` exposes configure, login, a local central-session logout/reset, materials, read-only migration status, user sync, AI event, stock commit, change polling, status and stream-event listening. `central:logout` clears the client-held credentials and stream state; it does not call `POST /api/auth/logout`, so it does not itself revoke the token server-side. No central report-export, password-reset, user edit/delete, full role-administration or material update/delete route is implemented.

The migration diagnostic compares the `schema_migrations` table with migrations `001_central_schema` through `005_session_version`. It reports applied, pending and unexpected versions to System Diagnostics after the signed-in central account passes the developer/admin role check. It is strictly read-only; deployment/migration commands remain an operator-controlled action.

## Request and error behavior
`readJson` accumulates request chunks and rejects once the JavaScript string exceeds 2,000,000 characters (reported as 413); malformed JSON returns 400. This applies to handlers that read JSON bodies, not a universal byte-level or GET-body limit. Login is limited by an in-memory IP+normalized-username counter: default five attempts per 15-minute window, with the configured maximum capped at five. Protected HTTP routes check JWT signature/expiry, persisted or in-memory revocation, active account, current role and `session_version`. The change polling route filters returned events by supplied scope claims; legacy/unscoped events remain visible. The WebSocket path applies the same event-scope rule. Error responses generally contain an `error` string; endpoint-specific validations and statuses are defined in `server/index.js`.

The server's CORS response header reflects the configured `CORS_ORIGIN`; the handler does not validate request `Origin` as an authorization check. The API can be created as HTTP or HTTPS depending on TLS key/certificate configuration, while public production binding is guarded by environment checks that expect direct TLS or an operator-configured trusted TLS proxy. Actual proxy/TLS behavior must be verified in the target deployment; do not infer it from this route inventory.

## Stock transaction semantics
`POST /api/transactions/stock` accepts central material transaction data; the endpoint locks the material row and scopes idempotency to the authenticated user. It rejects invalid/insufficient stock and commits transaction, audit event, sync event and idempotency result atomically in PostgreSQL. Do not apply this guarantee to local Shank Mapping operations. The desktop sync module queues selected central stock failures for retry in local IndexedDB; this is a client behavior, separate from the server's transaction guarantee.

## Material change feed semantics
`POST /api/materials` upserts the material and inserts a `sync_events` row with entity type `material`, action `material.upserted`, and the updated material payload inside the same PostgreSQL transaction. A successful material change therefore receives a sequence for incremental polling and the event is not committed separately from its material update.

`GET /api/sync/changes?after=<sequence>&limit=<n>` returns visible events and a scan cursor. The server advances the cursor for every scanned event, including events omitted because the caller's tenant/site/location/device scope does not match. This is necessary to avoid rescanning filtered events forever. When a visible page fills before a scan batch is exhausted, the cursor stops at the last scanned event; later polling continues after that sequence. The client persists a finite cursor only when it is greater than its current `lastSequence`, and incoming stream events trigger a pull when a sequence gap is detected. Scope filtering and cursor advancement are separate: a filtered event is not exposed, but it is still passed by the cursor.

## Sources and tests
`server/index.js`, `server/auth.js`, `server/db.js`, `main.js`, `preload.js`, `modules/centralSync.js`, `server/migrations/001_central_schema.sql`–`005_session_version.sql`, `tests/central-contract.test.js`, `tests/central-material-feed.test.js`, and `tests/auth.test.js`.
