# Maintenance Guide
> **Repository snapshot:** 2026-11-05 · StoreTrack Pro 5.0.0. This documentation describes repository code and tests, not a production certification. Re-run relevant checks for every release. See [Documentation Index](../README.md) and [current-behavior notes](../CURRENT_BEHAVIOR.md).

## Routine controls
- Review local and central health separately; monitor queue/error logs without assuming eventual-delivery guarantees.
- Keep Electron client version, central server version, root `server/` and generated `release/central-server/` aligned. Run `npm run central:bundle` then `npm run release:check` before shipping.
- Apply migrations using controlled release procedure; central migration files are 001–005. Back up before schema changes.
- Review local user access and central role assignments independently. Rotate secrets/certificates and protect logs.

## Backup inventory
| Backup | Scope / limitation |
|---|---|
| Desktop complete backup | Local app data; protected using machine/OS facilities where supported; verify origin machine and restore behavior. |
| Desktop portable JSON | Transfer workflow; recovery key is included in the file, so possession may expose data. |
| Legacy/settings JSON | May not have the same encryption as complete backup; inspect path and protect it. |
| Rolling master JSON copy | Periodic master-file snapshot; not a full encrypted backup or PostgreSQL dump. |
| Central PostgreSQL installer dump | Custom dump protected with DPAPI LocalMachine; same-host helper; not portable to another host by default. |

Maintain encrypted off-host recovery copies using an approved export/migration path. Run periodic restore drills and record host, version, backup hash, date and outcome.

## Housekeeping and evidence
Do not infer retention, successful schedules, alert delivery or restore success from task/module existence. Attach current task history, logs and test evidence. Preserve dated closure/audit CSVs as historical snapshots; regenerate source inventory from code with documented exclusions.
