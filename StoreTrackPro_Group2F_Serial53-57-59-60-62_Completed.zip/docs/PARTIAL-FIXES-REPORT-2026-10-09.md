# StoreTrack — 5 Partial Findings Fix Report

Date: 2026-10-09

## Status

The five previously PARTIAL findings now have targeted code mitigations and are recorded as `FIXED_CODE_RUNTIME_PENDING` in the closure matrix. This means the source-level fixes and static checks are complete, but full Electron/IndexedDB runtime verification remains outstanding. Do not interpret this as a completed full application acceptance test.

## Fixes

1. **P02-F03 — Older backup missing stores:** restore preview lists stores absent from the backup and requires confirmation; absent stores are preserved, not silently cleared.
2. **P02-F04 — Plaintext backup and user credentials:** complete operational backups exclude the `users` store. The UI and manual backup flow explicitly warn that the file is unencrypted. Automatic plaintext backups are paused until the user acknowledges the warning. Existing users are preserved during restore.
3. **P38-F04 — Indent Request role access:** navigation enforces `indentRequest` capability and hides matching sidebar/dashboard controls for roles without permission, while honoring explicit grants.
4. **P42-F04 — Category filter XSS:** both consumption category filter population paths escape category labels and attribute values before HTML interpolation.
5. **P43-F04 — Malformed GRN rows:** GRN records are shape-validated. Complete and legacy imports abort before writes if malformed GRNs are present; dedicated restore validates too; render/export skip malformed rows with a warning; print is guarded.

## Checks run

- `node --check app.js`
- `node --check modules/auth.js`
- `node --check modules/dataBackup.js`
- `node tests/smoke.js` — PASS
- `node tests/offline-smoke.js` — PASS
- `node scripts/release-hygiene.js` — PASS
- `node tests/storetrack-audit-regressions.js` — PASS (24 assertions)

Full Jest and Electron/Playwright runtime tests were not run because dependencies are not installed in this working copy. The remaining verification is role-by-role UI testing, real IndexedDB backup/restore with old snapshots, and malformed GRN restore/export in Electron.

## Documentation review — 2026-11-05
The findings, check outcomes, and runtime-pending status above remain this report's 2026-10-09 record; they have not been re-run or updated as current release results. The later 2026-11-05 sandbox Jest result is recorded separately in [Testing Documentation](final/Testing_Documentation.md) and does not alter this report's original evidence. Consult [Current Logic Reference](CURRENT_BEHAVIOR.md) for current code behavior.

## Separate current source-status addendum — 2026-11-05
The checks and pending states above remain the 2026-10-09 record. Current source review additionally finds implementation for IPC canonical-document/exact-main-frame checks; concurrency-safe stock CAS with encryption-aware transforms and guarded approval; Material IN retry identity/state; fractional Material OUT rejection; per-install bootstrap generation; health/sync retry changes; widget timer/config lifecycle; central logout bridge; and performance budgets/telemetry. After fixes prompted by a supplied Windows log, the current checkout passed `npm test -- --runInBand` with 53 suites / 488 tests in the sandbox on 2026-11-05. This does not close packaged Windows build, host, integration or production verification. See [the current closure snapshot note](audit-snapshot-status.md); do not reinterpret historical check outcomes as current.
