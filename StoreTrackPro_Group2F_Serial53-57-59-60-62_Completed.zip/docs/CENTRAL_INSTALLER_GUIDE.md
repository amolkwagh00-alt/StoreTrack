# StoreTrack Central Server Installer
> Reviewed 2026-11-12 against `installer/Install-Central-Server.ps1`, `installer/Setup-Central-Server.cmd`, and current server code. This documents configured/scripted behavior only; it does not mean the installer or target host was tested in this refresh.

## Scope and prerequisites
This is the Windows central Node/PostgreSQL deployment, separate from the Electron desktop client and its local IndexedDB. Run the PowerShell installer elevated. It requires Node.js discoverable as `node.exe`, plus both a TLS private key and certificate (`-TlsKeyFile` and `-TlsCertFile`); without both it throws. By default the listener binds `0.0.0.0` on API port 8787 and uses the supplied key/certificate for HTTPS. Prepare a trusted certificate whose SAN matches the DNS name clients will use.

## Install outline
Run `installer\Setup-Central-Server.cmd` (prompts for elevation) or use elevated PowerShell with the parameters in `Install-Central-Server.ps1`. The script copies server files, initializes configuration/database and migrations, creates the bootstrap administrator, writes startup configuration, and normally creates Windows tasks. It probes PostgreSQL at the configured port (default 5432) using generated credentials. If that probe fails, it attempts an isolated PostgreSQL 18 installation and changes to port 5433; package availability, policy, privileges, and successful installation/connection are environment-dependent. Confirm the actual database instance and port rather than assuming that fallback succeeded.

The default API firewall rule is inbound TCP on the API port, scoped to `LocalSubnet`, and applies to Domain/Private profiles; `-FirewallRemoteAddress` sets the allowed source scope and `-SkipFirewall` bypasses rule creation. It does not verify network reachability or create a PostgreSQL-isolation guarantee. Check firewall state, network paths, and database exposure on the target host.

The server startup task is configured for ONSTART as SYSTEM/highest. Unless `-SkipBackupTask` is supplied, the script makes an initial dump and creates a daily 23:30 SYSTEM/highest task. The generated backup script encrypts PostgreSQL custom dumps with DPAPI LocalMachine, deletes the temporary plaintext dump, and retains the newest 30 encrypted dumps. These actions can fail at runtime and must be checked in Task Scheduler and on disk.

## Credentials and configuration
Random database, JWT, and bootstrap admin credentials are written in `server\.env` and `credentials.txt`. The installer configures ACLs on those files for Administrators and SYSTEM; verify effective ACLs on the actual host. Transfer bootstrap credentials only through an approved secure channel and change the admin password after first login. The generated `.env` uses the placeholder `CORS_ORIGIN=https://your-client-origin.example`; set this to the exact approved client origin before production use. No claim that access was restricted or secrets successfully delivered follows from the script alone.

## Backup and recovery
The generated restore helper decrypts the DPAPI LocalMachine-protected dump and restores it through `pg_restore` using the `DATABASE_URL` from that helper's installation `.env`. It invokes `pg_restore --clean --if-exists`, so it can drop/replace objects in the database named by that URL; it has no target-database override or built-in production-safety check. Default recovery is tied to the same host protection context. Never point the helper at the live/production `.env` for a drill. Verify that an encrypted dump was produced, conduct a same-host restore drill only into a separately identified, disposable isolated database using an isolated helper/configuration copy, and separately approve off-host recovery and host-replacement procedures. A backup task definition is not proof of a successful backup or restore.

### Same-host disaster-recovery drill record (dated 2026-11-12)
This is an operator checklist/template, not evidence that a host drill has been performed. Schedule under an approved change window, obtain database-owner approval, and keep production service/data untouched. The helper's destructive `--clean --if-exists` behavior means the isolated target must be established and verified before invocation.

**Stop conditions:** Do not run the helper if any item below is unknown, the helper's `.env` resolves to production, the target is not disposable/isolated, the backup identity/hash cannot be recorded, or production-impact risk is detected. Stop immediately on unexpected service, database, or data impact; do not retry against another target. Preserve logs and escalate to the database/incident owner. Rollback means stop the drill, leave production unchanged, and discard/recreate only the disposable drill database/clone under the approved procedure; do not attempt an improvised restore over production to recover from a drill error.

- [ ] Approval/change ticket: __________  Scope/rollback owner: __________
- [ ] Operator: __________  Witness/reviewer: __________  Drill date/time + timezone: __________
- [ ] Source host/install root (record identifier only): __________  Host identity matches DPAPI LocalMachine context: __________
- [ ] Select encrypted dump path: __________  File modified time: __________  Size (bytes): __________  SHA-256: __________
- [ ] Record dump identity from backup log/metadata (timestamp/run/task): __________  Confirm file is non-empty and hash is recorded before use: __________
- [ ] Isolated target host/instance/port: __________  Disposable database name: __________  Owner confirmation: __________
- [ ] Confirm target is distinct from production by inspecting the isolated helper copy's `server\\.env` `DATABASE_URL` and independently verifying host, port, and database name; record evidence (redact secrets): __________
- [ ] Confirm production service/configuration is not modified, and no production client or scheduled task points at the isolated target: __________
- [ ] Confirm the isolated helper copy uses the intended dump path and only the disposable target; operator + reviewer re-check immediately before execution: __________
- [ ] Restore outcome/exit code and timestamp (or “not run”): __________  Captured log path/evidence reference: __________
- [ ] Verify expected representative records by stable IDs and expected key fields/counts (record criteria and redacted results): __________
- [ ] Verify restored schema/migrations as applicable and application/API health against the isolated target only; endpoint/build/result: __________
- [ ] Confirm production API/service and production database remained healthy and unchanged: __________
- [ ] Cleanup/disposition of disposable database and any plaintext temporary files; evidence: __________
- [ ] Failure/rollback/stop actions taken or “none”; incident/ticket reference: __________
- [ ] Operator sign-off/date: __________  Reviewer sign-off/date: __________

Never record passwords, full connection strings, private keys, or plaintext dumps in this checklist. Hashes and metadata identify a dump but do not prove it is restorable. A completed record proves only the documented drill scope; it does not establish off-host recovery capability.

## Client connection and acceptance
Use the central PC's trusted HTTPS DNS address (for example `https://storetrack-server.company.local:8787`) in clients. `127.0.0.1` on a workstation points to that workstation, not the server. Do not configure production clients for plaintext HTTP. Verify `/health`, trusted TLS without bypass flags, login, denied-role cases, and synchronization using actual built client/server versions. The configured client pushes via authenticated WebSocket, performs an immediate startup pull and a 15-second incremental safety pull, and scans its transaction queue every 5 seconds. Failed queue items use jittered backoff (5-second starting delay, capped at 5 minutes) and move to operator retry after 10 attempts; WebSocket reconnects back off with jitter from about 3 seconds to a 60-second cap and stop on terminal authentication failures. These are code schedules, not latency guarantees: workstation hardware, data volume, network conditions, and server/database latency affect actual results. Treat responsiveness objectives as code budgets to validate, not guarantees.

## Deployment checklist verification record
For each acceptance item, record actual value, evidence location, operator, date/time, and pass/fail; do not infer a pass from configuration or this guide. Check build/package version and artifact hash; TLS trust/name/expiry; API health; effective secret/key/backup ACLs; actual database instance/port and migration state; service/task identity, startup and logs; firewall scope and PostgreSQL reachability; and authorized-client login, denied-role and sync results. Verify non-empty encrypted dump identity, size and SHA-256, plus backup task identity/schedule/last run. Record the isolated same-host drill above separately. Mark items “not run” or “blocked” with owner/reason rather than passing them.

Source: `installer/Install-Central-Server.ps1`, `installer/Setup-Central-Server.cmd`, `server/index.js`, and `server/db.js`.
