> **Documentation review:** 2026-11-05. Source code/configuration and tests are the behavioral authority; historical audit results are not current release certification.

# AI Assistants Production Hardening


## Scope

StoreTrack Pro AI Assistants remain offline-first and retrieval-based. Chat, audit analysis, and root-cause analysis read the current application's authorized local IndexedDB records. No user question or inventory record is sent to a general-purpose external AI service.

## Authorization

AI Audit is available only to users with the `admin` or `developer` role. The renderer disables the control for other roles, and the central server independently enforces the same policy on `POST /api/ai/events` when the action is `audit_run`. This server-side check prevents a central-session client from treating the UI restriction as the only security boundary.

## Auditability

The application records AI actions locally in the `audit` store using an append-only event shape. The recorded fields include action type, user identifier, username, role, timestamp, part number when applicable, query category, and record count. Full free-form questions are not persisted by the AI event logger. When a central session is configured and online, the same metadata is submitted to the authenticated `/api/ai/events` endpoint and stored in the central `audit_events` table under `entity_type = 'ai_assistant'`. Offline operation remains available; central logging failure does not expose local records or block local analysis.

Supported action types are `chat_query`, `audit_run`, `root_cause_run`, and `export_guidance`. The central endpoint accepts only these actions and rejects unauthorized audit requests.

## Local performance telemetry boundary

The separate local performance-budget monitor (`modules/performanceMonitor.js`) keeps only numeric durations and allow-listed categories in bounded in-memory samples. It excludes labels, URLs, input values, and other user data, and never sends these metrics. Budget thresholds are configurable warning targets, not measured guarantees or production SLAs. This does not change the separate AI-event metadata behavior described under Auditability.

## Evidence and data quality

Chat answers identify the source IndexedDB store and the number of records used. Audit findings include evidence counts to help an auditor trace the scale of an indicator. Root-cause analysis reports confidence as Low, Medium, or High based on the available related records and displays a data-quality message. These outputs remain indicators or hypotheses and do not establish misconduct or causality.

## Language and usability

Chat recognizes common English, Marathi, and Hinglish variants for stock, replacement, repair, location, and usage questions. A bare part number produces a clarification prompt rather than an arbitrary answer. Quick-action buttons are provided for current stock, part usage, last replacement, and pending repair.

## Verification

The following checks are included in the repository:

- `tests/aiAssistants.smoke.js`
- `tests/aiAssistants.improvements.test.js`
- `tests/aiAssistants.hardening.test.js`
- `tests/aiAssistants.htmlcheck.js`

The hardening test verifies the central endpoint contract and the authenticated preload bridge. The complete Jest suite should be run after dependencies are installed with `npm test -- --runInBand`.

## Deployment requirements

Production deployment must use a strong JWT secret, a non-wildcard trusted CORS origin, changed database credentials, and HTTPS/TLS for any public central-server binding. The example environment file is not a production credential set.
