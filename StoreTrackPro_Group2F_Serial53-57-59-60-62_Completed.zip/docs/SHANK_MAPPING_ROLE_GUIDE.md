> **Repository review:** 2026-11-05. Verify against current source and target build; this documentation is not deployment certification.
> **Documentation review:** 2026-11-05. Source code/configuration and tests are the behavioral authority; historical audit results are not current release certification.

# SHANK MAPPING — ROLE GUIDE



Access is governed by the logged-in user, the StoreTrack Pro role system, and Shank Mapping capability checks. The following guide describes the intended operating responsibilities without overriding application permissions.

## Store Person

The Store Person operates the stock side of the process. The normal workflow is to review the dashboard, receive valid vendor Part Numbers into existing common Station Bins, verify physical quantities, inspect Low Stock and Zero Stock states, search Station or Part Number information, and print current labels. The Store Person should review replacement entries and confirm that stock deductions agree with the transaction history.

The Store Person should not bypass an insufficient-stock warning, create an unassigned Station Bin, alter a vendor Part Number, or save a physical adjustment without a reason. When a replacement is missing Maintenance accountability, return it for completion rather than entering a substitute person.

### Store Person Quick Guide

| Sequence | Action |
|---:|---|
| 1 | Check Dashboard Low/Zero Stock alerts. |
| 2 | Receive stock into the correct existing bin. |
| 3 | Verify physical stock and record a reason for any difference. |
| 4 | Search Station or Part Number when issuing stock. |
| 5 | Review replacement history and transaction drill-down. |
| 6 | Print selected or all labels after mapping changes. |
| 7 | Support historical month-end review and accountability export when permitted. |

## Maintenance Team

The Maintenance Team identifies the Station and Gun, checks the current Fix/Moving mapping, and communicates the required component to Store. When the component is replaced, the team records the old Part No., new Part No., quantity, condition, action, Maintenance Person, Team/Department, date, time, shift, common bin, and remarks.

The Maintenance Person must be selected from the searchable directory. The removed component must be classified as Repair or Scrap. The Maintenance Team should not treat a replacement as complete until the entry is saved successfully and the old/new Part Numbers are visible in history.

### Maintenance Team Quick Guide

| Sequence | Action |
|---:|---|
| 1 | Identify Station and select Gun Reference. |
| 2 | Review the mapped component and common bin. |
| 3 | Confirm the new vendor Part Number and available quantity. |
| 4 | Enter old Part No., new Part No., quantity, condition, and action. |
| 5 | Select Maintenance Person and enter Team/Department. |
| 6 | Save the replacement and verify the audit/history result. |
| 7 | Send the removed component through Repair or Scrap lifecycle. |

## Officer / Supervisor

The Officer or Supervisor reviews report results, station-wise and part-wise usage, maintenance-person accountability, physical adjustments, import warnings, mapping revisions, transaction history, zero-stock explanations, and the selected historical month-end. The supervisor should confirm that the accountability export uses the same Month/Year shown in the report.

When reviewing a Station-name variation warning, the supervisor should require a deliberate choice before a new Station/Bin is created. When reviewing a mapping update, use the revision and audit history to confirm the previous and new Part Numbers.

### Officer / Supervisor Quick Guide

| Review area | Control question |
|---|---|
| Import | Were warnings, duplicate counts, skipped rows, and update prompts reviewed? |
| Station | Is there one common bin per assigned Station? |
| Stock | Are Low Stock, Zero Stock, and physical differences explained? |
| Replacement | Are Maintenance Person, Team, old/new Part Numbers, and quantity present? |
| Lifecycle | Does Repair Return use the actual lifecycle quantity? |
| Month-end | Does the selected month satisfy the historical formula? |
| Export | Does the filename/header contain the selected `YYYY-MM`? |

## Administrator

The Administrator manages controlled setup and governance actions when the role has the required capability. These actions include importing Gun Matrix data, reviewing and confirming mapping updates, using import rollback, maintaining Part Master records, adding searchable Maintenance People and Teams, reviewing audit history, and managing role or feature permissions through the existing application security model.

The Administrator must preserve existing data. A Part Number supplied for Shank Mapping must not be regenerated or renumbered. Before committing a large import, the Administrator should review the dry-run and confirm that the protected snapshot is available.

### Administrator Quick Guide

| Sequence | Action |
|---:|---|
| 1 | Confirm the logged-in account has the needed Shank Mapping capability. |
| 2 | Prepare or validate the workbook and import mappings. |
| 3 | Review Station variation warnings and update prompts. |
| 4 | Commit only after the preview is correct. |
| 5 | Confirm import history and snapshot/rollback availability. |
| 6 | Maintain Part Master and Maintenance directory records without changing vendor identifiers. |
| 7 | Review audit, revisions, lifecycle, and month-end records. |

## Capability Areas

The module checks capability names for viewing, importing, Part Master, mapping, bins, stock receiving, stock adjustment, replacement, lifecycle, labels, reports, and the Guide Line. Administrative actions use the administrator guard in addition to the capability check. A denied capability displays a permission-denied message and stops the action. If an authorized stock action reports `ATOMIC_MUTATION_CONFLICT`, reload the current view and retry only after confirming the prior action did not succeed; stock and ledger are committed together. Historical consumption imports/entries are analytics-only and do not change current balances.

[Back to Documentation Index](SHANK_MAPPING_INDEX.md)
