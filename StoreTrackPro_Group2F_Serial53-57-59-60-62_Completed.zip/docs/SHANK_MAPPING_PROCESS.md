# SHANK MAPPING — PROCESS
> **Repository review:** 2026-11-05. Verify against current source and target build; this documentation is not deployment certification.
> **Repository review (2026-11-05):** This process reflects the RH/LH Common Bin, manual historical consumption, full-dataset import-preview search, and Shank Mapping table-search updates. Target Windows certificate, firewall, ACL, backup-restore, and hardware validation remain deployment-site checks.



## Process Model

```text
Station
   ↓
Gun Reference
   ↓
Fix Shank       Moving Shank
       \         /
        Common Station Bin
                ↓
        Component Stock
```

A mapping is represented as a Station, Gun Reference, component position, and vendor Part Number. The module also preserves source worksheet and source row information for imported mappings. Adaptor, Holder, and Pencil Shank positions are retained in mapping and stock data, while the bin label is intentionally limited to Fix and Moving Shank columns.

## One Station, One Common Station Bin

> **One Station = One common Station Bin.**

The system creates one active common bin for each assigned Station. Fix and Moving Shanks share that bin. Do not create separate Fix and Moving bins for the same Station. A row without Station No. is retained as `Station Not Assigned` and does not automatically create a bin.

A bin identifier is generated from the Station name, using a normalized form such as `FFA10-BIN01`. The bin record also stores the Station, name, physical location, active status, and timestamps. The physical location can be edited from the Common Station Bins screen.

### Eligible RH/LH Common Bin merge

When the same base Station has one RH and one LH side, the automatic merge is permitted only if each side has one or two Guns and both sides have valid Common Bins. The shared active identifier and name include `RH/LH` (for example, `<Base> RH/LH Common Bin`). Mappings and stock are consolidated into the active target. The non-target source bin becomes inactive; pre-merge source/target bins, mappings, and affected stock are recorded in merge history for rollback. Inactive bins are omitted from operational active-bin and label selection.

## A Station Can Have Any Number of Guns

A Station is not limited to one Gun. Each Gun Reference remains a separate mapping context. The component choices shown during Replacement Entry are populated from the selected Station and Gun.

## Common Part Numbers Do Not Merge Mappings

Part Master stores a Part Number once, but mapping rows remain separate. For example:

| Station | Gun | Fix Shank | Moving Shank |
|---|---|---|---|
| FFA 10 | Gun A | FS-101 | MS-201 |
| FFA 10 | Gun B | FS-101 | MS-202 |
| FFA 10 | Gun C | FS-105 | MS-205 |

The Part Number `FS-101` is shared in Part Master and stock references, but the Gun A and Gun B mappings remain distinct. Label generation groups by Station and Gun so the two rows are not collapsed merely because their Fix Part Number is the same.

## Vendor Part Number Rule

For Shank Mapping, Part Numbers come from Manufacturing or the Vendor. The module preserves the original value exactly as imported or entered. It does not auto-generate, renumber, or substitute Part Numbers for Fix Shank, Moving Shank, Adaptor, Holder, or Pencil Shank. This is a module-specific exception; other StoreTrack Pro modules keep their existing Part Number rules.

## Import-to-Bin Process

The import process detects worksheets, permits selection, maps headers, and builds a dry-run. During commit, each assigned Station is resolved against existing Station/Bin names. Possible matches are normalized by lowercasing and removing non-alphanumeric characters. Therefore `FFA 10`, `FFA-10`, and `FFA10` can be identified as possible variations. The user must explicitly decide whether to use the existing Station or create a new Station/Bin.

After Station resolution, the system creates the common bin if required, creates missing Part Master records using the supplied vendor Part Number, and creates or updates position-specific mappings. Exact duplicates are counted and skipped. Confirmed updates write mapping revisions and audit entries.

## Stock and Replacement Process

Stock is held by Part Number and Bin. Receiving creates an `IN` transaction. Replacement issues create an `OUT` transaction for the new Part Number. Repair Return creates an `IN` transaction using the actual lifecycle quantity. Scrap creates an `OUT` Scrap transaction. Physical verification can create a signed Adjustment transaction when a reason is provided.

The replacement record links Station, Gun, old Part Number, new Part Number, quantity, maintenance accountability, common bin, and lifecycle action. Negative stock is not permitted. Live stock updates use encryption-aware optimistic compare-and-swap: the stock balance and ledger transaction are committed atomically. A changed snapshot is retried (up to five attempts); repeated conflicts return `ATOMIC_MUTATION_CONFLICT` and require reload/retry. Historical consumption is analytics-only and never alters this live balance.

## Historical Accounting Process

The selected month controls both the displayed report and accountability export. Opening is the signed balance from transactions before the first day of the selected month. Period movements are read through the last day of the selected month. The closing calculation is:

> **Opening + Receive + Repair Return − Replacement − Scrap ± Adjustment = Closing**

This process is transaction-backed and does not require a separate manual Excel month-end calculation.

## Manual historical consumption entry

Users may choose an existing Part No. suggestion or type a vendor/historical Part No. directly in the manual historical-entry text field. A valid date and positive integer quantity are required. Station/Gun context is optional; incomplete, unmatched, or ambiguous supplied context can be saved with Mapping Review status. The saved historical row is used for analytics/forecasting and audit only—no live replacement, stock/ledger mutation, or bin creation occurs. Exact duplicate rows are rejected.

## Table search

Large Shank Mapping tables expose field-specific search controls for the columns they display. Import Preview searches the complete imported row set across pages, including Station, Part No. (across component fields), Gun Reference, and individual component fields. Existing dedicated Station/Part searches remain the primary filters on screens that already provide them.

[Back to Documentation Index](SHANK_MAPPING_INDEX.md)
