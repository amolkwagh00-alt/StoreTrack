# Part No. Correction — वापर सूचना

## काय बदलले आहे

Gun Matrix मधील Part No. बदलल्यावर आता तो फक्त निवडलेल्या mappingमध्ये बदलत नाही. Confirm केल्यावर exact जुना Part No. वापरणाऱ्या active mappings, Part Master references, candidate selections आणि bin-wise stock recordsचे corrected Part No.कडे migration होते. Part Masterमधील जुना record inactive/superseded म्हणून जतन होतो; default active list आणि Types of Shankमध्ये तो दिसत नाही.

जर नवीन Part No.ची त्याच binमध्ये stock row आधीपासून असेल, तर जुन्या Part No.ची quantity त्या rowमध्ये add होते; अन्यथा जुनी row नवीन Part No.सह त्याच binमध्ये re-key होते. जुन्या quantityमुळे stock कमी होत नाही. Non-zero quantity migrate करताना stock transactionमध्ये OUT/IN correction pair नोंदतो. Mapping revision आणि auditमध्ये जुना व नवीन Part No. जतन होतो.

Raw imported source values, जुने stock transactions आणि audit/revision history मुद्दाम बदलले जात नाहीत; ते मूळ import/changeचा पुरावा म्हणून राहतात. Ongoing procurement/order references आणि component forecast referencesमध्येही active Part No. update होतो.

## सध्याच्या backupमधील `5367` साठी एकदाच करायची दुरुस्ती

1. आधी StoreTrackचा नवीन backup घ्या.
2. या fixed projectमधून तयार केलेली app आवृत्ती वापरून app उघडा.
3. **Shank Mapping → Parts Master** मध्ये जुना `5367` record उघडा. Activity filterमध्ये `Inactive` निवडून archive झालेला recordही शोधता येईल.
4. Editमध्ये Part No. `05-5367` टाका आणि description योग्य असल्याची खात्री करा.
5. Global correction confirmationमध्ये Part No. pair योग्य असल्याची खात्री करून confirm करा.

या post-edit backupमध्ये R4 आणि R6 mapping आधीच `05-5367` आहेत. Dry-runनुसार `5367`ची UB40-BIN01 stock row quantity `0` तशीच ठेवून त्याच binमध्ये `05-5367` म्हणून नोंदली जाईल. त्यामुळे corrected Gun Matrix Excel पुन्हा import करण्याची गरज नाही.

> ही ZIP source code आहे. ती backup फाइल किंवा चालू live database आपोआप बदलत नाही.
