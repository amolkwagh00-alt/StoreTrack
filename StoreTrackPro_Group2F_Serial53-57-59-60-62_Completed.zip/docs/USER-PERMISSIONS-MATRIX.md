# StoreTrack Pro — Permissions and Trust Boundaries
> Reviewed 2026-11-05 against `modules/auth.js`, `server/migrations/002_roles.sql` and `server/index.js`. This is a source snapshot; target-build UAT is required.

## Local renderer roles
| Local role | Capability scope in `modules/auth.js` | Important limit |
|---|---|---|
| developer | Broad/unrestricted local capability helper | Does not bypass OS, database, deployment or central API controls. |
| admin | Administrative local capabilities, with possible explicit per-user restrictions | Not automatically a central superuser; central endpoint guards still apply. |
| store | Register/receive/physical stock/consumption/returns/reports/export scopes as defined by local capability constants | Not local user administration or Shank mapping administration by default. |
| maintenance | Consumption/replacement/repair-scrap/import/lifecycle/report scopes as defined in local constants | Does not imply central stock API access. |
| auditor | Reporting, month-end/zero-stock reports, transaction history, audit and export scopes | Read/audit capability set; validate exact screen wiring. |
| viewer | Empty default capability set; common read/search behavior can be screen-specific | Do not infer every report/export is available. |

This local table describes renderer capability checks, not a server-side authorization guarantee. See `modules/auth.js` and `tests/rolePermissions.test.js`.

## Central API role guards
| Central operation | Guard observed in `server/index.js` |
|---|---|
| Health and login | Public endpoints. |
| Stock transaction commit | Authenticated developer, admin or store. |
| Central user creation | Authenticated developer or admin; creating a developer requires developer. |
| User synchronization | Authenticated developer or admin. |
| Other protected routes | Route-specific authentication/guards; consult API guide/source. |

Central role schema has its own role list and must not be substituted for local roles. Local screens may implement capabilities the central server does not expose.

## Stock and approval safety boundaries
Central stock commit is authenticated and role-guarded as above. The service locks the material row, rejects invalid/insufficient balances, and atomically persists the stock update, transaction, audit/sync records and user-scoped idempotency response. A retry with the same user and UUID transaction ID/Idempotency-Key returns the prior response; a reused transaction ID without a matching replay is rejected. In supported local approval-backed stock mutation paths, atomic read-modify-write checks the approval remains pending, so simultaneous decisions cannot deduct stock twice. This is not a claim that every local or central workflow shares these semantics; validate the concrete path and deployment.

## Required validation
For each release, execute allowed/denied actions on the packaged target build and record role, endpoint/screen, build identifier and result. Source-level role constants are not a complete UI authorization audit or site certification.
