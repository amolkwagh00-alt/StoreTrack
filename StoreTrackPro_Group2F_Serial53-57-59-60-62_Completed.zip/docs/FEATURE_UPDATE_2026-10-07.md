# StoreTrack Shank Mapping — Feature and Documentation Update

**Date:** 2026-10-07  
**Validated package:** `StoreTrack-V5-LH-RH-inactive-common-fixed-v5-docs-updated.zip`

## User-visible behavior recorded

- **Manual Historical Consumption:** Part No. is a text field with existing Part Master suggestions. A user may also type an unlisted historical/vendor Part No. A valid date and positive whole-number quantity are required. Station/Gun context is optional; if provided, the mapping must match. The saved row is historical/analytics-only, audited, rejects exact duplicates, and does not create a current-stock movement or bin.
- **Searchable tables:** large Shank Mapping tables expose field-appropriate filters. Import Preview searches the complete imported row set across pages by Station, any mapped Part No., Gun Reference, or a particular component field (Fix/Moving Adaptor, Holder, Shank, and Pencil Shank). Existing dedicated search controls are retained rather than duplicated.
- **RH/LH Common Bin:** eligible opposite RH/LH sides for the same base Station can merge only when each side has one or two Guns and both Common Bins are valid. The active bin name contains `RH/LH`; mappings and stock are consolidated. The non-target source bin is inactive; pre-merge source/target snapshots are retained for rollback and inactive bins are omitted from active-bin/label selection.
- **Labels:** current Station/Bin labels remain scoped to active bins and the documented SR No. / Fix Shank / Moving Shank fields; preview sizing was updated to reduce clipped table content.

## Documentation and visual assets updated

- `docs/SHANK_MAPPING_INDEX.md`
- `docs/SHANK_MAPPING_QUICK_START.md`
- `docs/SHANK_MAPPING_HOW_TO.md`
- `docs/SHANK_MAPPING_USER_GUIDE.md`
- `docs/SHANK_MAPPING_PROCESS.md`
- `docs/SHANK_MAPPING_FLOWCHART.md`
- `docs/final/Release_Notes.md`
- `docs/diagrams/02_excel_import_flow.mmd` and matching `.png`
- New `docs/diagrams/11_lh_rh_common_bin_merge.mmd` and `.png`
- New `docs/diagrams/12_manual_historical_entry_and_search.mmd` and `.png`

The `assets/` logo and application-icon files are product branding, not workflow illustrations, so they were not changed. The repository's generic `docs/final/End_User_Manual.md` previously had screenshot placeholders but no actual Shank Mapping UI screenshots; the placeholders are now explicitly labelled as such. The new PNGs are rendered workflow diagrams, not screenshots of the application.

## Validation

- 34 Jest suites passed; 357 tests passed on the validated ZIP.
- `node --check modules/componentManagement.js` passed.
- ESLint: 0 errors, 116 warnings (existing repository warnings remain).
- Mermaid source and matching PNG previews were rendered and checked for presence in the package.

## Documentation review — 2026-11-05
The behavior summarized above is retained as the 2026-10-07 package snapshot. The 34-suite / 357-test result and other checks above are historical evidence for the named validated ZIP, not results for the 2026-11-05 repository snapshot. Separately, after a same-day Windows log review and code fixes, the current checkout passed `npm test -- --runInBand` with 53 suites / 488 tests in the sandbox; this later result does not change the named 2026-10-07 evidence or certify deployment/runtime behavior. See [Current Logic Reference](CURRENT_BEHAVIOR.md) and [Testing Documentation](final/Testing_Documentation.md).

## Current repository status note — 2026-11-05
The behavior and package validation above remain the original 2026-10-07 historical record. Separately, a source review of the current checkout finds the later IPC, stock concurrency/approval, Material IN retry, integer Material OUT, per-install bootstrap, health/sync retry, widget lifecycle/configuration, logout bridge, and performance budget/telemetry implementations present. After follow-up fixes, the current checkout's sandbox Jest suite passed 53 suites / 488 tests on 2026-11-05; Windows packaged-build and relevant integration/runtime verification remain pending. Refer to [the current closure snapshot note](audit-snapshot-status.md) and its appended dated matrix rows.
