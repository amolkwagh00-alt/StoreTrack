> **Repository review:** 2026-11-05. Verify against current source and target build; this documentation is not deployment certification.
> **Documentation review:** 2026-11-05. Source code/configuration and tests are the behavioral authority; historical audit results are not current release certification.

# SHANK MAPPING — TROUBLESHOOTING



Use the table below to diagnose the most common Shank Mapping problems. When a corrective action changes data, confirm the result in history or audit before continuing.

| Problem | Possible cause | What the user should do |
|---|---|---|
| Station Not Assigned | The source row has no Station No. or the Station column was not mapped. | Review the workbook and column mapping. Re-import through the controlled preview after supplying a valid Station. Do not expect a bin for the unassigned row. |
| Assigned RH/LH merge shown as Station Not Assigned | An active RH/LH merged bin exists, but a dashboard/label view resolved the station from a stale stock row or inactive source bin. | Do not delete the inactive source bins or re-import. Refresh/restart after applying the active merged-bin fix; the active merged bin station (for example `ECS 65 RH/LH`) is now the canonical display value. |
| Wrong Station | The source value is wrong, or a variation such as `FFA 10` and `FFA10` was treated as a possible match. | Stop before commit. Review the warning and explicitly choose the existing Station or confirm creation of a new Station. For a committed mapping change, use the controlled update and review mapping history. |
| Wrong Part No. | The wrong source column was selected, or the workbook contains a wrong vendor identifier. | Rebuild the preview with the correct column mapping. Preserve the vendor Part Number exactly; do not substitute an internally generated number. If updating an existing mapping, accept the explicit update prompt only after review. |
| Duplicate Mapping | The same Station/Gun/Position/Part Number was imported again. | Review the import summary. Exact duplicates are counted and skipped; they are not inserted again. |
| Import Warning | Missing primary fields, skipped component-less row, Station variation, or an existing mapping candidate. | Read the dry-run warning and skipped-row information. Correct the source or make the required explicit Station/update decision before committing. |
| Stock update conflict (`ATOMIC_MUTATION_CONFLICT`) | Another update changed the stock snapshot during the optimistic compare-and-swap; the helper retries up to five attempts, then stops. | Reload the view, inspect the current balance and transaction history, and retry once only if the action did not succeed. The stock/ledger mutation is atomic; do not manually add a balancing row. |
| Approval already processed | A material OUT request is no longer pending; the guarded approval action rejects duplicate/stale approval before applying it again. | Refresh the approvals list and inspect its status and transaction. Do not approve or deduct again. |
| Insufficient Stock | The replacement quantity exceeds available quantity in the selected Part/Bin. | Receive or locate stock first. Do not bypass `INSUFFICIENT STOCK`; the negative-stock block is intentional. |
| Zero Stock | Stock has been consumed, scrapped, adjusted out, or has not yet been received. | Open the Zero Stock Report and select the Part Number to view the actual transaction drill-down and running balance. |
| Physical Stock Difference | Physical quantity differs from system quantity. | Enter the physical count and a reason. Save the verification to create a signed Adjustment transaction. |
| Label Mismatch | Mapping changed, the wrong rows were selected, or labels were generated from stale expectations. | Review Station/Gun mapping, confirm the common bin, then reopen labels and use Preview before Print Selected or Print All. |
| Label contains prohibited data | A user is viewing an old or unrelated label template. | Use the Shank Mapping label screen. The current printable HTML shows Station, Bin, and the three required shank columns only; Gun Number, Quantity, Holder, Adaptor, and Pencil Shank are excluded. |
| Repair Issue | The lifecycle quantity is missing or the entry is not in `UNDER REPAIR`. | Review the Repair/Scrap record. Repair Return requires a positive actual lifecycle quantity and posts that quantity, not a default `+1`. |
| Scrap Issue | The removed component was classified inconsistently or the user expected it to return to stock. | Confirm the Action is Scrap. Scrap is a separate outbound transaction and is not a Repair Return. |
| Month-End Difference | The wrong month was selected, a transaction date is outside the period, or a movement was not recorded. | Load the intended Month/Year, review transactions through that month’s final day, and verify `Opening + Receive + Repair Return − Replacement − Scrap ± Adjustment = Closing`. |
| Accountability export uses wrong month | The report selection was not loaded or the report month was cleared. | Load the selected month before exporting. The export uses the selected `YYYY-MM`, includes it in the filename/header, and defaults to the current month only when no valid selection exists. |
| Part Number appears changed | A user expected the general StoreTrack numbering rule to apply. | For Shank Mapping, the vendor/manufacturing Part Number is authoritative and preserved exactly. Other modules retain their own numbering behavior. |
| Common bin missing | The Station is unassigned, or the import was not committed. | Check Station No., review import history, and inspect Common Station Bins. Unassigned rows intentionally do not create bins. |
| Permission denied | The user role or explicit feature capability does not allow the action. | Ask an Administrator to review the existing role and Shank Mapping capability settings. Do not attempt to bypass the application guard. |
| Import rollback unavailable | No protected snapshot is linked to the import, or the user lacks administrator access. | Check Import History and the import record. Use rollback only when a snapshot is present and the role permits the action. |

## Safe Recovery Sequence

When the result is uncertain, stop the transaction or import, capture the visible warning, review Import History or Replacement History, and inspect the relevant audit or mapping revision. Correct the source or form, then repeat only the controlled operation that failed. Do not delete unrelated data to force a result.

## Source References

1. [`modules/componentManagement.js`](../modules/componentManagement.js)
2. [`modules/database.js`](../modules/database.js)
3. [`tests/componentManagement.test.js`](../tests/componentManagement.test.js)

[Back to Documentation Index](SHANK_MAPPING_INDEX.md)
