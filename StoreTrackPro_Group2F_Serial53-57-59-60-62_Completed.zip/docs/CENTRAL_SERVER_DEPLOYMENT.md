# Central Server Deployment
> Reviewed 2026-11-05. The central service is optional and separate from Electron/local IndexedDB. Commands below are configuration examples, not evidence that a host deployment passed.

## Choose deployment path
The Windows installer (`installer/Install-Central-Server.ps1`) requires TLS key/certificate and configures its own HTTPS service, firewall and tasks. Manual/container deployments (`server/DEPLOYMENT.md`, `server/docker-compose.yml`) have distinct defaults. For LAN/public use, configure direct TLS or a trusted TLS-terminating reverse proxy and restrict network access; deployment configuration and trust must be validated on the target host. The Node service itself creates HTTPS when both TLS key/certificate file variables are configured and otherwise creates HTTP. Production non-loopback startup has environment guards, but those checks do not verify a proxy's identity, TLS settings or end-to-end behavior.

## Manual setup outline
1. Install supported Node.js and PostgreSQL versions matching current deployment policy and dependencies.
2. Configure `DATABASE_URL`, `STORETRACK_JWT_SECRET` (at least 32 characters outside tests), `HOST`, `PORT`, and narrowly scoped `CORS_ORIGIN` from `server/.env.example`.
3. Install central dependencies as documented for that deployment path.
4. Run `npm run central:migrate` and `npm run central:create-admin`.
5. Start with `npm run central:server` or the reviewed Compose path; configure and validate appropriate TLS termination/direct TLS and restrict network/firewall access.
6. Validate `/health`, central login and route-specific authorization with actual clients.

## Central routes and semantics
Current source route inventory includes `GET /health`, login/logout, AI event logging, GET/POST `/api/materials`, `/api/gun-count`, `/api/sync/changes`, `/api/transactions/stock`, `/api/users`, `/api/users/sync`, and authenticated WebSocket `/api/sync/stream`. Most routes other than health and login require a bearer token; authorization varies by route and action. `/api/gun-count` calculates and returns metrics and does not persist a record. The API is not full material/user/report CRUD. Request JSON parsing rejects bodies over 2,000,000 JavaScript string characters (not an asserted byte-level limit). CORS configuration is not an authorization mechanism. Stock commits use row locking and user-scoped idempotency; do not generalize that central database guarantee to local workflows. The Electron bridge exposes selected central operations but does not expose the server logout route.

## Client synchronization cadence and security
Configured clients subscribe to authenticated WebSocket events, pull changes immediately on startup and then every 15 seconds as a fallback, and scan the local central-transaction queue every 5 seconds. Queue failures use jittered delays starting at 5 seconds and capped at 5 minutes; an item moves to failed/operator-retryable after 10 attempts. WebSocket reconnect delay grows with jitter from about 3 seconds to a 60-second cap, resets after a stable connection, and stops for terminal authentication errors. Health checks have a 30-second scheduled cadence and are also triggered in relevant failure paths; concurrent health and pull operations are coalesced. These are implementation schedules, not guarantees of event or commit latency. Client hardware, local data volume, connectivity, and server/database latency affect observed outcomes. Any stated responsiveness target is a code budget for testing, not a service guarantee.

The Electron main process accepts privileged IPC only from the canonical app document in the primary main frame and cancels unexpected top-level navigation/redirects. Local renderer role checks are not an authorization boundary; enforce sensitive access through server-side authorization and treat workstation OS access as part of the trust model.

## Backups
Manual deployment backup policy is an operator/infrastructure responsibility unless configured separately. The Windows installer backup is a separate PostgreSQL custom dump encrypted by DPAPI LocalMachine, with same-host restore semantics. Desktop local backups are not central DB backups. Record backup location, protection, retention and a passed restore drill on the target system before production use.

## References
`server/DEPLOYMENT.md`, `server/.env.example`, `server/index.js`, `server/auth.js`, `server/db.js`, `main.js`, `preload.js`, `modules/centralSync.js`, `server/migrations/`, `installer/Install-Central-Server.ps1`.
