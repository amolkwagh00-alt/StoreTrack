# StoreTrack Pro AI Assistants
> Reviewed 2026-11-05. The implementation is local retrieval/rules-based and should not be confused with a hosted generative LLM.

## Scope
The workspace provides AI Chat, AI Audit and AI Root Cause Analysis over current application records. The reviewed implementation reads local IndexedDB and does not send those queried records to an external LLM.

## Chat
Recognized topics include part usage, current stock, last replacement, pending repair and reporting/export guidance in English/Marathi. It uses retrieved records/rules, asks for clarification for underspecified questions, and directs users to existing CSV/Excel controls rather than generating an untracked export.

## Audit and root-cause review
Audit is limited to Admin/Developer in the feature logic. Results are indicators for human review, not proof of misconduct. Root-cause output describes recorded associations/patterns as possible reasons; it does not establish causation or mutate stock/maintenance records.

## Local performance telemetry boundary
Performance-budget instrumentation is separate from AI assistant behavior. `modules/performanceMonitor.js` retains numeric durations and allow-listed categories in bounded in-memory samples, excludes user data such as labels, URLs, and input values, and never sends those samples. Its budget thresholds are targets for local warnings, not measured guarantees.

## Sources and verification
UI: `index.html`, startup/navigation: `app.js`, logic: `modules/aiAssistants.js`; tests: `tests/aiAssistants.smoke.js`, `tests/aiAssistants.htmlcheck.js`, `tests/aiAssistants.improvements.test.js`, `tests/aiAssistants.hardening.test.js`. No checks were run during the 2026-11-05 documentation refresh. Old dated test pass statements are historical only.
