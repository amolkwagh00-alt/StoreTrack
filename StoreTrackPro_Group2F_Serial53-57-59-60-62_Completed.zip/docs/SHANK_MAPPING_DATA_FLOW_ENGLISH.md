> **Repository review:** 2026-11-05. Verify against current source and target build; this documentation is not deployment certification.
> **Documentation review:** 2026-11-05. Source code/configuration and tests are the behavioral authority; historical audit results are not current release certification.

# Shank Mapping: Complete Data Flow



## Purpose

This document explains how the Shank Mapping module moves data from import and dashboard actions through mapping, bins, stock, replacement, repair, scrap, reporting, forecasting, labels, and backup operations. The application source remains the operational source of truth.

## Core stores

| Store | Purpose | Main screens |
|---|---|---|
| `component_parts` | One Part Master record per unique Vendor Part No. | Types of Shank, Parts, Stock, Reports, Forecast |
| `component_gun_rows` | Preserved source-row identity from the imported workbook | Gun Register, import recovery, audit |
| `component_mappings` | Station/Gun/component-position mapping | Shank Mapping, labels, bins |
| `component_bins` | One Common Bin per assigned Station | Bin Management, Stock, labels |
| `component_stock` | Current quantity by Part No. and Bin | Stock, dashboard, replacement |
| `component_stock_transactions` | Receive, issue, repair return, scrap, and adjustment movements | History, running balance, reports |
| `component_replacements` | Replacement accountability records | Replacement, history, reports |
| `component_repair_scrap` | Repair and scrap lifecycle records | Repair/Scrap, history |
| `component_import_snapshots` | Trial-import rollback snapshots | Import and rollback |
| `component_import_configs` | Workbook and column-mapping configuration | Import |
| `component_station_aliases` | Canonical Station identity and variation matching | Import, aliases, bins |
| `component_label_versions` | Label version and print status | Labels |
| `maintenance_people` | Maintenance Person and Team directory | Replacement, history |
| `component_audit_log` | Significant action audit records | Audit and history |

## Import and mapping flow

```text
Workbook
  → Detect worksheets
  → Select worksheets
  → Map columns
  → Build dry-run preview
  → Review warnings, skipped rows, source-only rows, duplicates, and Station variations
  → Choose existing Station or create a new Station when warned
  → Confirm import
  → Preserve source-row identity
  → Create or reuse Parts, mappings, aliases, and Station Common Bins
  → Save import history and audit record
```

Blank and `NA` component values are excluded. For Gun Count, a source row is eligible when at least one of Fixed Shank, Moving Shank, Fixed Adaptor, Moving Adaptor, Fixed Holder, or Moving Holder contains an actual Part No.; Pencil Shank alone does not make a row eligible. When a cell contains more than one Part No. and none is Bold, no Part No. is selected automatically; the row is shown in the BI Dashboard ambiguous-Part section for an explicit Original/Latest choice. A Vendor Part No. containing `/` remains one complete Part No. The same Part No. can appear at multiple Stations while remaining one Part Master item; Station and Bin visibility remains separate in mapping and stock screens.

## Occurrence and quantity rules

Valid Gun Mapping occurrence is the count of every valid Gun Mapping row containing an actual Part No. in a counted component position. Blank/`NA`-only rows are excluded, and the count is not deduplicated by Station, Gun Reference, or Position; common/repeated Gun References remain separate occurrences. Therefore, if a Part No. appears 15 times in Gun Mapping, Minimum Qty is 15 and Maximum Qty is 30. The BI Dashboard's Unassigned / Source-only count is the number of excluded source rows and opens a drill-down list.

| Value | Rule |
|---|---:|
| Gun Mapping occurrence | `n` |
| Auto Safety / Minimum Qty | `n` |
| Maximum Qty | `n × 2` |

For example, occurrence `3` produces Auto Safety/Minimum `3` and Maximum Qty `6`. These are planning and status values; they do not increase physical stock.

## Station and Common Bin flow

Each assigned Station uses one Station Common Bin for standard mapped components. Pencil parts are an exception: physical stock uses station-independent Pencil Pair bins; some Station views only project those quantities. Unassigned or blank rows do not create a component bin. Stock Receiving uses one combined Part No. control that supports existing selection or manual typing, then displays only bins containing the entered Part No.; a new Part No. with no bin is rejected until it is mapped to a bin.

## Stock and consumption flow

```text
Receive Stock
  → Validate and derive the next Part + Bin balance
  → Atomically commit stock row + Receive ledger transaction
  → Recalculate pooled Part quantity
  → Refresh Stock, Dashboard, and alerts

Replacement / Issue
  → Validate Station, Gun, component, person, team, bin, and quantity
  → Check available pooled/current stock
  → Encryption-aware optimistic CAS on current stock
  → Retry snapshot conflict up to five attempts
  → Atomically commit stock row + Replacement / Issue ledger transaction
  → On repeated conflict return `ATOMIC_MUTATION_CONFLICT`; reload and retry
  → Save replacement and audit history
```

Historical consumption entries/imports are stored separately for analytics and audit; they never change live stock or create a live issue. Only `Replacement / Issue` transactions count as live consumption usage. Receive, Repair Return, Scrap, and Adjustment remain separate transaction types.

```text
Available Stock = Receive + Repair Return − Replacement/Issue − Scrap ± Adjustment
```

Manual Shank Usage — Remaining Qty and Physical Stock Verification create Adjustment transactions. They update stock but do not count as consumption usage or usage days.

## Pooled stock and alert flow

Procurement and grouped Dashboard/Low Stock alerts use pooled Part-level stock across all bins. Stock screens continue to show Bin-wise records. A Part No. appears once in grouped alerts, with all related Stations, Locations, and Bins combined.

Alert priority is:

```text
ZERO STOCK → STOCK-OUT RISK → REORDER → LOW STOCK
```

The priority is followed by Critical Flag, Expected Zero Date, and Vendor Part No. Zero average daily usage does not produce a fake Expected Zero Date.

## Forecast and procurement flow

Usage days are unique calendar days containing a Replacement/Issue transaction in the selected inclusive period. Confidence levels are `NO DATA` for zero days, `LOW` for 1–29 days, `MEDIUM` for 30–89 days, and `HIGH` for 90 or more days.

The default effective lead time is 90 days: 30 internal PR/PO days plus 60 supplier lead-time days. Fixed Part-specific Safety Stock Qty has priority; when blank or zero, Safety Stock Days are used. Suggested Order Qty is never negative and subtracts pooled stock and open/pending order quantity from target stock. An existing open or pending order prevents a duplicate `ORDER NOW` alert.

Order lifecycle statuses are `ORDER NOW`, `ORDER CREATED`, `ORDER PENDING`, `PARTIALLY RECEIVED`, `RECEIVED`, and `CANCELLED`. Procurement records retain Order Status, PO No., Order Date, Expected Arrival Date, Ordered Qty, Received Qty, and Pending Qty.

## Repair, Scrap, labels, and reports

A removed component follows either the Repair or Scrap path. Repair Return increases stock through its own transaction. Scrap decreases stock through its own transaction. Labels are Station-wise and include the complete mapped Gun and Part details assigned to the Bin. Preview and printing do not change stock or mapping.

Exports are available for Types of Shank, Stock, Mapping, Bins, History, Low/Zero Stock, Analytics, and Procurement lists in Excel and PDF where provided by the screen.

## Backup and restore

Side Menu → Backup & Restore first activates the Shank Mapping component section and then renders the backup screen. For another Windows PC, create “Backup for Any Windows PC (portable JSON)” on the source PC, copy that JSON file to the target, then choose “Import Backup from Another PC” on the target and confirm the preview. Portable JSON embeds its recovery key, so protect the file from unauthorized access. Daily backups and “This-PC Encrypted Backup” use the source Windows installation’s protected key and cannot be restored on another PC by copying the file alone. “Restore Latest Backup” restores only the latest local backup. User accounts/password hashes are excluded; destination accounts are preserved. Confirm only a verified backup and restart StoreTrack after restoration so every module reloads its data.

## End-to-end production sequence

```text
Complete Backup
  → Import Preview
  → Review and confirm mapping
  → Commit production import
  → Verify occurrence, Auto Safety, and Maximum Qty
  → Receive stock into mapped Common Bin
  → Verify pooled Part quantity
  → Record Replacement/Issue or Physical Adjustment
  → Review Dashboard and Procurement alerts
  → Verify order lifecycle and exports
  → Perform Windows UAT and sign-off
```

## Source references

- `modules/componentManagement.js`
- `modules/shankConsumptionAnalytics.js`
- `modules/dataBackup.js`
- `modules/database.js`
- `index.html`
- `tests/`
