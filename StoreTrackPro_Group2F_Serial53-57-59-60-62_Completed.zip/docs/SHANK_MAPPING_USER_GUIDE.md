# SHANK MAPPING — USER GUIDE
> **Repository review:** 2026-11-05. This guide reflects the supplied source snapshot; verify the shipped build before operational use. See [current logic notes](CURRENT_BEHAVIOR.md).



## What the System Does

Shank Mapping connects the Gun Matrix to Station numbers, Gun Reference numbers, Fix and Moving Shanks, component Part Master records, one common Station Bin, stock quantities, maintenance replacements, Repair/Scrap history, labels, reports, and month-end accountability. It provides a controlled alternative to searching disconnected spreadsheets and manually calculating stock movements.

The module is accessed from the StoreTrack Pro application through the Shank Mapping area. The in-application **Dashboard → Guide Line** remains available as a searchable, printable guide; this document is the companion reference in the project `docs` folder.

## Why It Exists

The workflow preserves the relationship between a Station, its Guns, and the components assigned to each Gun. It also ensures that a stock issue is recorded with the responsible Maintenance Person and Team, that the removed component receives a Repair or Scrap outcome, and that historical month-end balances can be reconstructed from transactions.

## Who Uses It

| User | Main supported activities |
|---|---|
| Store Person | Receive stock, verify physical quantities, review availability and low/zero stock, search mappings, print labels, and review or export reports when permitted. |
| Maintenance Team | Search Station and Gun mappings, identify the mapped component, record replacements, identify old and new Part Numbers, and classify removed components for Repair or Scrap. |
| Officer / Supervisor | Review station-wise, part-wise, and maintenance-person reports; inspect history and audit trail; review physical adjustments; run historical month-end and accountability exports when permitted. |
| Administrator | Manage imports, confirmed mapping updates, rollback, Part Master and maintenance directory entries, and role/capability access when permitted by the application security model. |

Actual access is controlled by the logged-in user, the existing role system, and Shank Mapping capability checks. A role description in this document does not grant access by itself.

## Complete Workflow

```text
Gun Matrix Excel
        ↓
Sheet Detection
        ↓
Sheet Selection
        ↓
Column Mapping
        ↓
Import Preview
        ↓
Confirm Import
        ↓
Station / Gun Mapping
        ↓
Automatic Common Station Bin
        ↓
Part Master
        ↓
Stock Receiving
        ↓
Stock Availability
        ↓
Maintenance Replacement
        ↓
Stock Deduction
        ↓
Repair / Scrap
        ↓
Repair Return
        ↓
Label Printing
        ↓
Daily Monitoring
        ↓
Month-End
        ↓
Zero Stock
        ↓
Transaction Drill-down
        ↓
Accountability Report
```

### 1. Gun Matrix Excel

Prepare a workbook containing the Station No., Gun Reference No., and any component columns used by the source data. The supplied template contains the supported headers for Fix Shank, Moving Shank, Fix/Moving Adaptor, Fix/Moving Holder, and Pencil Shank. Part Numbers are vendor or manufacturing identifiers and must be entered exactly as supplied.

### 2. Sheet Detection and Selection

Upload the workbook in the import screen. The system detects all worksheet names and displays their row counts. Select the sheets to process. Worksheet names are not hard-coded; the user decides which detected sheets participate in the import.

### 3. Column Mapping

The system suggests columns using header aliases, but the user can select a different header or leave an optional component column unmapped. Station No., Gun Reference No., Fix Shank, and Moving Shank are the primary fields. Review the selections before building the preview.

### 4. Import Preview and Confirmation

Build the dry-run preview. Review the rows, missing-field counts, duplicate or existing candidates, skipped rows, and warnings. A possible Station-name variation such as `FFA 10`, `FFA-10`, or `FFA10` is warned about. The import cannot silently create a second Station/Bin: an explicit decision is required to use the existing Station or create a new one.

Existing mapping changes require a separate confirmation. Exact duplicate mappings are counted as duplicates and are not inserted again. Rows with no Station No. remain as **Station Not Assigned** and do not create a bin.

The editable preview has filters for Station, Part No. across all mapped component fields, Gun Reference, and each Fix/Moving Adaptor, Holder, and Shank field plus Pencil Shank. Filters apply to the full imported row set, not just the currently displayed page; pagination remains available for review.

### 5. Station/Gun Mapping and Common Bin

Each component position is stored as a separate mapping under Station and Gun Reference. A Station can contain any number of Guns. A repeated Part Number is stored once in Part Master but remains present in every applicable Station/Gun/Position mapping.

For each eligible assigned Station, the system uses a Common Bin for standard Shank parts. Fix and Moving Shanks use the mapped station bin. Pencil parts are an exception: their physical stock is held in station-independent Pencil Pair bins; some station stock views may only project those quantities. A missing Station does not create a bin.

For an eligible opposite-side RH/LH pair with the same base Station, automatic merge is allowed only when each side has one or two Guns and valid Common Bins. The active target is named `<Base> RH/LH Common Bin`; the non-target source bin is marked inactive. Pre-merge source/target bin and stock snapshots are saved in merge history for rollback. Inactive bins are hidden from normal active-bin lists and label selection.

### 6. Part Master

Part Master records are unique by Part Number. The Shank Mapping exception is strict: the source vendor/manufacturing Part Number is preserved exactly, without auto-generation, renumbering, or replacement by an internal identifier. This exception applies only to Shank Mapping; other StoreTrack Pro modules retain their existing Part Number behavior.

### 7. Stock Receiving and Availability

Standard receiving takes a Part Number and total quantity, then previews automatic allocation across eligible mapped bins. The separate Stock Control Excel import resolves the Station/Gun and requires its row Bin Location to match the active Common Bin. The dashboard and stock view show available quantity, minimum quantity, and status. Status thresholds are ZERO STOCK at quantity 0, LOW STOCK when quantity is positive but below the minimum applied by that view, and OK STOCK at or above it. Row-level records use `minimumStock`; pooled analytics may calculate a part-level requirement from auto-safety/Required Qty and existing minima. Forecast-risk labels are separate.

Negative stock is blocked. A replacement or adjustment that would make quantity negative cannot be saved.

### 8. Maintenance Replacement

Maintenance identifies the Station and selects a Gun Reference. The system shows the mapped component choices and common bin. Before saving, the user records the old Part No., new mapped Part No., quantity, condition, action, Maintenance Person, Team/Department, date, time, shift, and remarks. Maintenance Person is mandatory and must be selected from the searchable directory.

When the replacement is saved, the new Part Number is deducted from common-bin stock and its ledger transaction is committed atomically with the stock row. The live write is encryption-aware optimistic CAS: changed snapshots are retried up to five times; repeated conflicts return `ATOMIC_MUTATION_CONFLICT` and require a reload/retry. The replacement record and audit trail are also recorded by the workflow. If the required quantity is not available, the system displays `INSUFFICIENT STOCK` and blocks the transaction.

### 9. Repair and Scrap Lifecycle

A removed component is classified as Repair or Scrap. Repair follows `UNDER REPAIR` to `REPAIR COMPLETED`, then posts a Repair Return using the actual lifecycle quantity. Scrap remains a separate Scrap transaction. Both the lifecycle record and audit record preserve the transaction context.

### 10. Labels

Labels are generated from current mapping rows. They show:

```text
STATION: <Station No.>
BIN: <Common Station Bin>

SR NO. | FIX SHANK PART NO. | MOVING SHANK PART NO.
```

Gun Number, Actual Quantity, Holder, Adaptor, and Pencil Shank are not printed. Separate Station/Gun rows remain separate even when Part Numbers repeat. The label screen provides Preview, Print Selected, and Print All. Small, Medium, Large, and Custom width and height affect the printable page; content-aware sizing and wrapping are used to reduce table clipping, so review the preview before printing. A QR code encodes the Station and Bin payload used by the application to open the corresponding mapping context.

### 11. Search, Monitoring, and Reports

Station Search shows the common bin, Gun References, Fix Shanks, Moving Shanks, all mappings, and stock availability. Part Number Search shows component type, available quantity, bins, stations, Gun References, mapping status, and a transaction-history drill-down. Large tables also provide field-specific search controls for the fields actually shown; Part No. search in the import preview searches all mapped component columns. Clear the filters to restore the full result set. Screens that already had dedicated Station/Part filters keep those controls rather than showing duplicates.

Zero-stock entries can be opened to view the transaction trail and running balance. Reports include station-wise, part-wise, maintenance-person summaries, the zero-stock report, historical month-end accounting, and accountability export.

### 12. Historical Month-End

Select the target Month/Year in the Reports screen. The system calculates the month using transactions through that month’s last day. The formula is:

> **Opening + Receive + Repair Return − Replacement − Scrap ± Adjustment = Closing**

The accountability export uses the same selected month. Its filename and header contain the selected `YYYY-MM` value. If no month is selected, the existing current-month default is used.

## 13. Manual Historical Consumption Entry

Open **Replacement Entry → Manual Historical Consumption**. The Part No. field is a text input with suggestions from existing Part Master values: choose a suggestion or type a historical/vendor Part No. that is not in the list. Enter a valid date and a positive whole-number quantity. Station and Gun context may be supplied when known; incomplete, mismatched, or ambiguous context can be saved with mapping-review status rather than rejected. Duplicate and invalid date/quantity checks still apply.

The saved row is stored as historical consumption and audited. It contributes to historical consumption analytics/forecasting, but it does not create a live Replacement/Issue, change current stock or its ledger, or create a bin. Exact duplicate manual entries are rejected. Use the live Replacement workflow for current stock issues.

## Daily Operating Principles

Record work when it occurs. Do not postpone replacement, Repair/Scrap, physical verification, or adjustments until month-end. Review warnings before confirming an import, and use the transaction drill-down whenever a balance is unexpectedly low or zero.

## Source References

1. [`modules/componentManagement.js`](../modules/componentManagement.js)
2. [`modules/database.js`](../modules/database.js)
3. [`tests/componentManagement.test.js`](../tests/componentManagement.test.js)
