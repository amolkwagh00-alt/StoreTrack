# StoreTrack Documentation Index
> Documentation refresh: 2026-11-06; maintenance addendum: 2026-11-11. Current behavior hub: [CURRENT_BEHAVIOR.md](CURRENT_BEHAVIOR.md). Source/configuration/schema and executed tests are authoritative; rendered documents and historical audit tables are not behavioral authority.

## Maintained guides
- [Current behavior reference](CURRENT_BEHAVIOR.md) — application domains, authority boundaries, integrity, cadence, performance budgets and verification caveats.
- [End-user manual](final/End_User_Manual.md), [Admin guide](final/Admin_Guide.md), [FAQ](final/FAQ_Guide.md)
- [Architecture](final/Technical_Architecture.md), [Database](final/Database_Documentation.md), [Security](final/Security_Documentation.md), [API](final/API_Documentation.md)
- [Install](final/Installation_Guide.md), [Deployment](final/Deployment_Guide.md), [Maintenance](final/Maintenance_Guide.md), [Troubleshooting](final/Troubleshooting_Guide.md)
- [Testing](final/Testing_Documentation.md), [Source code](final/Source_Code_Documentation.md), [Release notes](final/Release_Notes.md), [Executive summary](final/Executive_Summary.md)
- [2026-11-11 maintenance fixes](final/Release_Notes.md#maintenance-fixes--2026-11-11) — central material sync/cursor, dashboard widget accessibility/chart cleanup, and Windows installer/checksum release workflow; includes verification limits.
- [Shank Mapping index](SHANK_MAPPING_INDEX.md), [Shank Mapping user guide](SHANK_MAPPING_USER_GUIDE.md), [Stock Entry Excel Import](STOCK_ENTRY_EXCEL_IMPORT.md)
- [2026-11-05 bug-audit follow-up](BUG_AUDIT_2026-11-05.md) — post-fix dispositions, supplied Windows test-log review, updated Jest/release-check evidence and remaining runtime verification.
- [Production handover test manual — Marathi](PRODUCTION_HANDOVER_TEST_MANUAL_MR.md) — prioritized UAT/acceptance steps, expected outcomes, evidence and sign-off.
- [UAT test register — Marathi (Excel)](StoreTrack_UAT_Test_Register_MR.xlsx) — 51 fillable cases, status dropdowns, test-data sheet, defect log and sign-off summary.

## Historical audit evidence
- [Closure snapshot status](audit-snapshot-status.md) and [closure matrix CSV](closure-matrix-updated.csv) — original rows preserved, with additive dated current-code status rows.
- [2026-10-07 feature validation](FEATURE_UPDATE_2026-10-07.md) and [2026-10-09 partial-fix report](PARTIAL-FIXES-REPORT-2026-10-09.md) — historical findings/results; read their dated addenda for later context.

## File types and source-of-truth policy
`docs/` contains maintained Markdown guides and Mermaid `.mmd` sources, rendered PNGs, export artifacts, inventory/audit JSON and historical evidence. Markdown and `.mmd` are maintained source; PNG/DOCX/PDF are derived outputs. `file_inventory.json` is generated inventory, not an audit. `audit_summary.json` records documentation scope/dispositions, the separately executed Jest result and inventory metadata; it is not a source/security audit or deployment certification. Dated audit/fix reports, closure matrices/CSVs and restore records are historical snapshots; preserve their original dates/findings and do not present them as current runtime verification. These classifications describe repository artifacts, not deployment evidence.

## Regeneration and verification
- `docs/final/file_inventory.json` was regenerated on 2026-11-05 with `python3 scripts/refresh-documentation.py`; rerun after repository changes. Inventory generation is not QA.
- Render edited diagrams using `manus-render-diagram docs/diagrams/name.mmd docs/diagrams/name.png` and inspect output.
- Re-export DOCX/PDF from maintained Shank Mapping Markdown after review; record generator/version and source date.
- `npm run release:check` is release hygiene only. Test commands in root README are available commands, not evidence they passed.

## Evidence rules
Record command, exact result, date, commit/worktree, environment and tester for executed tests. A pending case list is a plan, not a test. Do not copy old totals or claimed performance into current docs as verified facts; code-level budgets are targets until measured under representative workloads.
