# Stock Control Excel Import
> **Repository review:** 2026-11-05. Verify against current source and target build; this documentation is not deployment certification.

## Workbook columns

The first worksheet must use these headers (the order may vary if the names are unchanged):

| Sr No. | Station No. | Gun Reference No. | Fix Qty | Moving Qty | Required Qty | Bin Location |
|---|---|---|---:|---:|---:|---|

`Sr No.` is optional; blank values are numbered automatically in the preview. `Station No.` and `Gun Reference No.` must match an existing Station/Gun mapping. Fix and Moving Part Numbers are looked up from that mapping, so a separate Part No. column is not needed. `Fix Qty` and `Moving Qty` are quantities being received; leave a quantity blank or enter `0` when there is no receipt for that component. At least one of those two quantities must be greater than zero. `Required Qty` is a non-negative whole number that contributes to the stock minimum for both mapped components on that row. The import preserves any higher existing minimum or automatically calculated safety quantity; it will not silently lower a stock minimum. `Bin Location` must match the active common Shank Bin's configured physical location or its Bin ID.

This workbook flow is for Fix/Moving components resolved from the selected Station and Gun. It is distinct from standard receiving's mapped-bin allocation. Pencil parts use station-independent Pencil Pair bins; use the Pencil-aware stock receiving workflow rather than treating a Station Common Bin display as physical Pencil stock.

## How to import

In **Stock Control**, choose **Download Excel Template**, fill in the rows, then choose **Import Excel / CSV**. The app previews every populated row and resolves the Fix/Moving Part Numbers. Correct any errors in the workbook and re-import it; the app does not allow a partial import if one or more rows are invalid. Choose **Receive** only after reviewing a clean preview.

A committed import adds the received quantities to the selected bin's stock, updates the minimum quantity, and writes stock rows, ledger transactions, and audit records in one atomic batch. If the database cannot commit the complete batch, no rows are applied. This batch uses the Stock Control import commit path; live Shank stock mutations made through the operational stock-change path use encryption-aware optimistic CAS and atomically write the stock record with its ledger entry. CAS conflicts retry up to five attempts; repeated conflicts return `ATOMIC_MUTATION_CONFLICT` and require reload/retry. Historical consumption is separate and never changes live balances. The import preview/commit action is not an approval workflow; do not treat a repeated click as deduplicated. Excel `.xlsx`, `.xls`, `.xlsm`, and `.csv` files are accepted; only the first worksheet is read.
