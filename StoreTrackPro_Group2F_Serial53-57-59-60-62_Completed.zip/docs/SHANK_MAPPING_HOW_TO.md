# SHANK MAPPING — HOW-TO GUIDE
> **Repository review:** 2026-11-05. Verify against current source and target build; this documentation is not deployment certification.
> **Repository review (2026-11-05):** This guide reflects the RH/LH Common Bin, manual historical consumption, full-dataset import-preview search, and Shank Mapping table-search updates. Target Windows certificate, firewall, ACL, backup-restore, and hardware validation remain deployment-site checks.



## Import a Gun Matrix Workbook

Open the import screen and choose an `.xlsx`, `.xls`, `.xlsm`, or `.csv` file. The system reads every worksheet and shows its name and row count. Select the worksheets to process. For each supported field, review the suggested header or choose a header manually. The primary fields are Station No., Gun Reference No., Fix Shank, and Moving Shank; the remaining supported fields are Fix Adaptor, Moving Adaptor, Fix Holder, Moving Holder, and Pencil Shank.

Select **Build Import Preview**. Review the dry-run rows and the counts for Rows Scanned, New, Updated, Duplicate, Skipped, and Warnings. Correct the workbook or mapping if a required value is missing. If the preview warns that a new Station may match an existing Station after punctuation and spacing normalization, explicitly choose whether to reuse the existing Station or create the new Station. Do not proceed based on an unresolved warning.

Use the preview filters to find rows by Station, Part No. across all mapped component fields, Gun Reference, or a specific Fix/Moving Adaptor, Holder, or Shank field and Pencil Shank. Search covers the full imported row set while display remains paginated; clear filters to review every row again.

Select **Commit Confirmed Import** and accept the commit prompt. Exact duplicates are not reinserted. An existing mapping at the same Station, Gun, and Position prompts before its Part Number is updated. A protected snapshot is taken before commit, and the import history records the summary and backup reference.

## Roll Back an Import

Open Import History and locate the import with a rollback action. Confirm the rollback prompt. The protected snapshot restores the Component Management domain stores for Part Master, mappings, bins, stock, stock transactions, and Repair/Scrap lifecycle data. The rollback action is written to audit history.

## Review Station and Gun Mapping

Open the Gun Matrix view. Each row displays Station, Gun Reference, Position, vendor Part Number, and source sheet. A Station may contain multiple Guns. A repeated Part Number is not a reason to merge rows: each Station/Gun/Position relationship remains independently visible.

If one source cell contains more than one Part No. and none of those values is Bold, the application selects no Part No. automatically. Open the BI Dashboard and use the **Multiple Part No. — Bold Part No. Missing** section. Choose the intended **Original** or **Latest** Part No. for the affected field and select **Save selected Part No.** The source row is then mapped and the Gun Count is recalculated.

## Check the Common Station Bin

Open Common Station Bins. Each assigned Station should have one active common bin, typically using the normalized Station identifier with `-BIN01`. Fix and Moving Shanks use the same bin. Rows with `Station Not Assigned` never create a bin. A bin’s physical location can be edited from the bin screen.

An eligible opposite-side RH/LH pair for the same base Station merges only when each side has one or two Guns and valid Common Bins. The active shared bin is named `<Base> RH/LH Common Bin`. The non-target source bin becomes inactive; source/target snapshots remain in merge history for rollback. Inactive bins are hidden from active-bin lists and label selection.

## Add or Review a Part Master Record

Open Parts Master and enter the vendor Part No., description, component type, and minimum stock. The Part No. must be unique in Part Master. For Shank Mapping, preserve the vendor/manufacturing identifier exactly. Do not replace it with an internal number and do not invoke the general application Part Number generator.

## Receive Stock

Open Component Stock. Use the single **Part No.** control to select an existing Part Master number or type a Part No. manually, then enter a positive integer quantity. After the Part No. is entered, the Bin dropdown shows only bins containing that Part No.; select one of those bins. Optionally enter a reference and remarks, then select **Receive Stock**. The quantity increases and its stock transaction is written in the same atomic database commit. Live stock updates use encryption-aware optimistic compare-and-swap (CAS): conflicts are retried up to five attempts; a repeated conflict returns `ATOMIC_MUTATION_CONFLICT`, so reload and retry rather than assuming the operation succeeded. If the Part No. is not present in any eligible bin, or the selected Bin does not contain the Part No., the receive action is rejected.

## Verify Physical Stock

Open Physical Stock Verification. Review each system quantity and enter the physical quantity. When the physical quantity differs from the system quantity, enter a reason. Save the verification to create a signed `Adjustment` transaction. The system quantity is not silently overwritten, and a non-zero difference without a reason is rejected.

## Import Historical Shank Consumption

For a previous 2–3 month consumption list, open **Replacement Entry → Import Replacement List** and choose **Historical Consumption — analytics only** as the Import Mode. Select the Excel/CSV file and review the preview before confirming. Each row requires an existing Part Master Part No., a valid date, and a positive integer quantity. Historical rows are stored separately, are included in Consumption Analytics, Forecast, and Procurement calculations, and never deduct from current stock. Do not use Live Replacement mode for old records because Live Replacement performs current stock validation and deduction.

The Historical Consumption import is intended for baseline history only. After import, open **Consumption Analytics** and compare the 7/30/60/90-day totals with the source Excel list before changing safety-stock or lead-time settings.

Use **Download Historical Template** to obtain the supported CSV column layout. The preview reports valid, invalid, and duplicate rows before commit. Invalid or duplicate rows can be exported with **Export Rejected Rows** for correction. A confirmed import receives a batch ID; from **Transactions / Replacement History**, use **Delete Batch** to undo the complete historical import. This deletes historical analytics rows only and never changes current stock.

Historical rows are local Shank Mapping analytics data and are explicitly excluded from Central Sync. They are included in Complete Backup/Restore and the Shank Mapping reset/rollback lifecycle.

## Record One Manual Historical Consumption Entry

Open **Replacement Entry → Manual Historical Consumption**. **Part No.** is a text input with suggestions: choose a listed Part or type a historical/vendor Part No. that is not listed. Enter a valid date and positive whole-number quantity. Station and Gun are optional; incomplete, mismatched, or ambiguous supplied context can be saved with mapping-review status. Exact duplicates are rejected. The saved record is analytics-only; it does not create a live stock transaction, change current stock, or create a bin.

## Record a Maintenance Replacement

Open Replacement Entry. Select a Maintenance Person from the searchable directory and enter the Maintenance Team/Department. Enter Date, Time, Shift, Station, Gun Reference, component, Old Part No., mapped New Part No., quantity, Old Part Condition, Action, and any remarks.

When Station and Gun are selected, the mapped component choices and common bin are populated. Review the available/minimum quantity. If stock is insufficient, the system displays `INSUFFICIENT STOCK` and blocks saving. Otherwise, save the replacement. The new Part Number is deducted from stock, the replacement history is written, and the event is audited. The record includes the logged-in user.

## Complete Repair or Record Scrap

Open Repair / Scrap Lifecycle. A Repair entry is initially `UNDER REPAIR`. Select **Complete Repair** when the component is returned. The application uses the recorded lifecycle quantity, not a hard-coded quantity, to post the `Repair Return` transaction. A Scrap entry remains `SCRAP` and is counted separately in month-end accounting.

## Print a Label

Open Component Bin Label Printing. Review the generated rows, select the rows to print, and choose Preview, Print Selected, or Print All. Choose Small, Medium, Large, or Custom and set Custom Width and Custom Height when required. The label preview uses content-aware sizing and wrapping to reduce clipped table rows; review it before printing.

The printed HTML contains Station and Bin headers followed by exactly:

```text
SR NO. | FIX SHANK PART NO. | MOVING SHANK PART NO.
```

It does not contain Gun Number, Quantity, Holder, Adaptor, or Pencil Shank. Repeated Part Numbers remain repeated when they belong to different Station/Gun mapping rows. The QR code encodes a StoreTrack Station/Bin payload.

## Search by Station

Open Station Search and enter part or all of a Station number. The result shows the common Station Bin, Gun References, Fix Shanks, Moving Shanks, all mappings, and stock availability.

## Search by Part Number

Open Part Number Search and enter part or all of the vendor Part Number. The result shows component type, total available quantity, bins, stations, Gun References, mapping status, and a Transactions action for drill-down.

For large tables, use the per-column search fields above the table. Search applies to the fields shown—such as Station, Gun Reference, Part No., Fix/Moving Adaptor, Holder, Shank, and Pencil Shank. Multiple filters narrow the same data together. Use **Clear Search** to restore all rows; existing dedicated filters are retained rather than duplicated.

## Investigate Zero Stock

Open Component Reports and review the Zero Stock Report. Select a Part Number to open the actual transaction drill-down. The drill-down orders transactions by date and shows transaction type, signed quantity, reference or remarks, user, Station, Gun Reference, and running balance.

## Run Historical Month-End

In Component Reports, select a Month/Year and choose **Load Selected Month**. The report calculates opening from transactions before the selected month and movement through that month’s final day. Review the values using:

> `Opening + Receive + Repair Return − Replacement − Scrap ± Adjustment = Closing`

Use **Export Month-end CSV** for the selected report month. Use **Export Stock Accountability** to export the same selected month. The exported filename and report header contain `YYYY-MM`.

## Review Import and Audit History

Import History shows source file, import timestamp, status, row counts, warnings, and rollback action. Replacement History and Transactions show maintenance accountability fields, old/new Part Numbers, quantity, condition, action, bin, and logged-in user. Audit records are created for significant imports, mapping changes, stock transactions, lifecycle events, labels, exports, and rollback.

[Back to Documentation Index](SHANK_MAPPING_INDEX.md)
