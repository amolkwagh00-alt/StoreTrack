> **Repository review:** 2026-11-05. Verify against current source and target build; this documentation is not deployment certification.
> **Documentation review:** 2026-11-05. Source code/configuration and tests are the behavioral authority; historical audit results are not current release certification.

# StoreTrack Pro — Production Workflow



## 1. Import and mapping workflow

The production source is the Gun Mapping workbook. Select the workbook and worksheets, map or confirm the columns, and build the dry-run preview. Review skipped rows, duplicate source rows, invalid rows, station-variation warnings, and vendor Part No. values before committing. A trial import may be reset according to the trial-data rule; a production import must be treated as permanent and must be preceded by a complete backup.

During commit, source-row identity is preserved. Valid Station, Gun Reference, component position, and Vendor Part No. values create or reuse Parts, Mapping rows, Gun Rows, Station aliases, and applicable bins. A value containing `/` remains one Vendor Part No.; blank and `NA` values are excluded from component allocation. Stored/displayed vendor text is preserved; normalized keys are used for comparison and do not rewrite that text. If the same component is mapped at multiple stations, the Part Master lists it once, while Mapping and Bin Management retain station-wise visibility.

## 2. Occurrence, safety, and maximum rules

Gun Mapping occurrence is the count of valid source mapping rows for a Vendor Part No. It is not deduplicated by Gun Reference No. Auto Safety/Minimum Qty equals the occurrence count. Maximum Qty equals occurrence count multiplied by two.

| Value | Rule for occurrence `n` |
|---|---:|
| Gun Mapping occurrence | `n` |
| Auto Safety / Minimum Qty | `n` |
| Maximum Qty | `n × 2` |

For example, if `05-7265` occurs three times, Auto Safety/Minimum is `3` and Maximum Qty is `6`. Required/target planning values must not be mistaken for current physical stock.

## 3. Station Common Bin and stock workflow

Standard Shank parts use Station-wise Common Bins; blank and `NA` mappings do not create component allocation. Pencil parts are the exception: physical stock is held in station-independent Pencil Pair bins, while some Station stock views may project that quantity. Stock Receiving previews eligible mapped-bin allocation, and Stock screens retain Bin-wise visibility. The Stock Control Excel import is a separate Station/Gun-based Fix/Moving receipt workflow that validates the row's Bin Location against the active Common Bin; it is not the general mapped-bin allocation workflow.

The pooled Part-level available quantity used for procurement and grouped alerts is the sum of the Part No. across all bins. Therefore, stock received into one bin does not create a false order merely because another bin for the same Part No. is empty. Dashboard and Low Stock alerts show one row per Part No. and combine Station/Bin details. Operational stock status is ZERO STOCK at quantity 0, LOW STOCK only when positive quantity is below the applicable minimum, and OK STOCK at or above that minimum; forecast-risk labels are separate.

## 4. Consumption and stock transaction workflow

Only `Replacement / Issue` transactions count as consumption usage. Receive, Repair Return, Scrap, and Adjustment are separate transaction types. Replacement validates the mapped Station/Gun/component, maintenance person/team, selected bin, quantity, and pooled/current stock rule before deducting stock. A failed stock check does not save a replacement. The live stock mutation uses encryption-aware optimistic compare-and-swap (CAS), retrying changed snapshots up to five attempts; on repeated conflict it returns `ATOMIC_MUTATION_CONFLICT` for reload/retry. The stock record and its ledger transaction are committed together.

Manual Shank Usage — Remaining Qty and Physical Stock Verification are adjustments. They update the stock balance and create an Adjustment transaction but do not inflate consumption history or usage days. Physical Verification requires a reason for every non-zero difference.

```text
Available = Receive + Repair Return − Replacement/Issue − Scrap ± Adjustment
```

## 5. Forecast and procurement workflow

The forecast uses inclusive date ranges. Usage days are unique calendar days containing a Replacement/Issue transaction. Confidence is `NO DATA` for zero usage days, `LOW` for 1–29, `MEDIUM` for 30–89, and `HIGH` for 90 or more.

The effective default lead time is 90 days: 30 internal PR/PO days plus 60 supplier lead-time days. The forecast target is based on usage, effective lead time, review period, and safety stock. A fixed Part-specific safety quantity has priority; if it is blank or zero, safety-stock days are used. When average daily usage is zero, no fake Expected Zero Date is shown. Zero current stock is always `ZERO STOCK` and `ORDER NOW`.

Suggested Order Qty is calculated from target stock minus current pooled stock and open/pending order quantity, never below zero. Existing open orders prevent duplicate `ORDER NOW` alerts. Procurement lifecycle statuses are `ORDER NOW`, `ORDER CREATED`, `ORDER PENDING`, `PARTIALLY RECEIVED`, `RECEIVED`, and `CANCELLED`, with PO No., order date, expected arrival date, ordered, received, and pending quantities.

## 6. Dashboard and alert workflow

Dashboard alert rows are grouped by Vendor Part No. in the priority order `ZERO STOCK → STOCK-OUT RISK → REORDER → LOW STOCK`, followed by critical flag, expected zero date, and Vendor Part No. Available quantity is pooled; Stations, Locations, and Bins are combined in the same row. Alert Acknowledge and Resolve actions pass the Alert ID as an HTML-safe string through the CSP bridge.

## 7. Repair, Scrap, Labels, and exports

Removed components follow the Repair or Scrap lifecycle. Repair Return adds stock through a separate transaction; Scrap reduces stock through a separate transaction. Labels are Station-wise and include the complete Gun and Part details assigned to the bin. Preview and print do not alter stock or mapping. Excel and PDF exports are available for Types of Shank, Stock, Mapping, Bins, History, Low/Zero Stock, Analytics, and Procurement lists.

## 8. Backup and restore workflow

Use Side Menu → Backup & Restore. The screen is opened inside the Shank Mapping component section. For another Windows PC, create “Backup for Any Windows PC (portable JSON)” on the source PC, move that file to the target, then use “Import Backup from Another PC” and confirm the preview. Its recovery key is embedded in the file, so store it securely. Daily backups and “This-PC Encrypted Backup” use the source Windows installation’s protected key and cannot be restored by copying the file alone. Restore Latest Backup is local to this PC. User accounts/password hashes are excluded and target accounts are preserved. Restore only a verified backup and restart the application so every module reloads its state.

## 9. Production handoff sequence

```text
Complete Backup
  → Import Preview
  → Review rows, Parts, Stations, Bins and warnings
  → Commit production import
  → Verify occurrence / safety / maximum
  → Receive stock into mapped Common Bin
  → Verify pooled Part stock
  → Record Replacement/Issue or Physical Adjustment
  → Check Dashboard and Procurement grouping
  → Review order lifecycle and exports
  → Perform Windows UAT and sign-off
```

**Production rule:** do not reset or delete production mapping data as part of a normal import. Trial cleanup is for explicitly marked test data only.
