# StoreTrack Pro — Production Handover Test Manual

**भाषा:** मराठी  
**Software snapshot:** StoreTrack Pro 5.0.0; नोंद तारीख 2026-11-06  
**उद्देश:** Production/operations team ने ग्राहकाला देण्यापूर्वी योग्य build, Windows install, data integrity, roles, sync, backup/restore, performance आणि hardware वापर प्रत्यक्ष तपासण्यासाठी हा manual वापरावा.

> **महत्त्वाचे:** या manual मधील acceptance tests आधी staging किंवा production-सारख्या isolated environment मध्ये करा. Live production database वर destructive, duplicate, offline, migration किंवा restore tests चालवू नका. 2026-11-06 च्या Shank Receiving UI follow-up नंतर sandbox मधील Jest suite 53 suites / 491 tests पास झाली; `npm run lint` exit code 0 (0 errors / 401 warnings). हे निकाल Windows/package/live-server acceptance ची जागा घेत नाहीत. आधीचा supplied Windows run lint error मुळे Windows build पर्यंत पोहोचला नव्हता; package test अजून आवश्यक आहे.

## 1. Scope आणि system boundaries

StoreTrack Pro चे दोन वेगळे भाग आहेत: (1) Electron desktop application व त्याचा local IndexedDB, आणि (2) वापरत असल्यास स्वतंत्र Node/PostgreSQL central service. Local roles/permissions, central API roles, local backup आणि central PostgreSQL backup यांना एकच system समजू नका. Central server नसेल तर local-only deployment साठी central-service tests `N/A` म्हणून कारण नोंदवा.

या checklist मध्ये desktop installation/upgrade, login व permissions, Shank Mapping, stock workflows, imports/exports, backup/restore, optional central service, security, scanner/printer, performance, rollback आणि production sign-off समाविष्ट आहेत.

## 2. Priority आणि pass/fail नियम

- **P0 / Go-live blocker:** login/role bypass, stock/data loss किंवा duplicate posting, चुकीचा balance, backup restore अपयशी, install/upgrade crash, central auth/ACL/TLS failure, critical hardware workflow failure.
- **P1 / Go-live साठी निर्णय आवश्यक:** प्रमुख वापर-अडथळा, response target चा वारंवार भंग, import/report चूक, reconnect किंवा retry मधील अडचण. Owner, workaround आणि due date नोंदवा.
- **P2 / follow-up:** कमी परिणामाचा visual/text defect; ग्राहकावर परिणाम व workaround स्पष्ट करून नोंदवा.
- प्रत्येक test ला `Pass`, `Fail`, `Blocked` किंवा `N/A` द्या. पुरावा नसलेला test `Pass` मानू नका. Fail ला ticket/defect ID द्या.
- P0 defect असताना **Go-live नाही**. P1 फक्त business owner च्या लेखी acceptance, स्पष्ट workaround आणि ठरलेल्या due date नंतरच defer करा.

## 3. Test सुरू करण्यापूर्वी — handover pre-flight

खालील माहिती भरल्याशिवाय test सुरू करू नका:

| आवश्यक माहिती | नोंद |
|---|---|
| Build / app version / build date | |
| Installer file name व SHA-256 | |
| Windows edition/build, RAM, CPU, storage | |
| Tester, भूमिका, test सुरू/समाप्त वेळ | |
| Environment: staging / production-like / production smoke | |
| Local-only की central sync enabled | |
| Central API build/version, URL, DB migration versions | |
| Test account IDs/roles (passwords या report मध्ये लिहू नका) | |
| Test dataset आकार; वास्तविक customer data वापरले आहे का | |
| Scanner model/driver/mode; printer model/driver/paper | |
| Backup location, restore plan, rollback owner/contact | |

### Go-live पूर्वी सोडवायचे release checks

1. **First-run credentials स्पष्ट करा:** current source मधील `loadAll()` normal clean-startup path मध्ये `generateSetupSecret()` वापरते; मात्र security guide मध्ये fixed bootstrap values चे वर्णन आहे. Handover आधी actual packaged installer मध्ये हा path पडताळा आणि documentation mismatch सोडवा. दोन स्वतंत्र clean test installs मध्ये credentials सुरक्षितपणे तयार होतात का, first-login password बदलणे बंधनकारक आहे का, आणि कोणतेही fixed/default credential वापरात राहत नाही ना हे तपासा. अस्पष्टता, credential leakage किंवा fixed credential आढळल्यास P0 security blocker नोंदवा.
2. **Central bundle ताजे आहे याची खात्री:** 2026-11-05 च्या read-only release audit मध्ये staged `release/central-server` हे source पेक्षा stale दिसले आणि release-hygiene check ने stale `.env.example` दाखवले. Central service देणार असल्यास bundle source मधून पुन्हा तयार करून `npm run release:check` पास करणे, ZIP contents तपासणे आणि तयार bundle मधून प्रत्यक्ष install/start/health test करणे आवश्यक. Bundle मधील `core/gunCountService.js` योग्य install path मध्ये येतो का हे विशेष तपासा.
3. **Secrets आणि TLS:** test/staging मध्ये स्वतंत्र secrets; production JWT secret किमान 32 characters; TLS certificate/key, hostname trust, firewall scope, DB ACL आणि service account यांचे पुरावे तयार ठेवा. Secret/password या manual किंवा screenshots मध्ये लिहू नका.
4. **Test data/rollback:** synthetic test accounts आणि unique test Part/Station/Gun IDs वापरा. Backup घ्या, restore कुठे करणार ते आधी ठरवा. Clear All Data, migration downgrade, queue fault injection किंवा DB restore हे फक्त disposable/staging environment मध्ये करा.

## 4. Automated आणि build verification

हे developer/QA test environment मध्ये करा; production host वर test dependencies install करू नका.

| ID | Command/check | अपेक्षित निकाल | Priority |
|---|---|---|---|
| AUTO-01 | `npm ci` | Lockfile प्रमाणे dependencies install; native Electron modules rebuild errors नसावेत. | P0 |
| AUTO-02 | `npm test -- --runInBand` | सर्व Jest tests पास; command, commit/build, environment व पूर्ण output जतन करा. 2026-11-06 चा sandbox निकाल 53/490 हा फक्त code-test evidence आहे; प्रत्येक packaged build साठी पुन्हा नोंदवा. | P0 |
| AUTO-03 | `npm run test:e2e` | उपलब्ध Playwright specs clean environment वर पास; browser/build version व report जतन करा. | P1 |
| AUTO-04 | `npm run lint` | exit code 0; warnings/failures स्पष्टपणे नोंदवा. | P1 |
| AUTO-05 | Central enabled असल्यास `npm run central:bundle` नंतर `npm run release:check` | exit code 0; staged bundle source शी current; stale/generated release artifacts नसावेत. | Central enabled असल्यास P0 |
| AUTO-06 | `npm run build` (समर्थित Windows build host) | NSIS installer व expected deployment guide तयार; artifact SHA-256 व build log जतन. | P0 |

Automated tests पास झाले तरी installed build, host configuration, TLS, hardware, restore आणि user workflows चे manual acceptance tests आवश्यक आहेत.

## 5. Installation, first launch आणि database

प्रत्येक OS/install test clean Windows VM किंवा disposable machine वर करा. Developer च्या आधीच्या `StoreTrackData` folder वर अवलंबून राहू नका.

| ID | कृती | अपेक्षित निकाल / पुरावा | Priority |
|---|---|---|---|
| INST-01 | Installer hash/version verify करा; per-user install करा; Start Menu आणि desktop shortcut ने launch करा. | योग्य version उघडते; unsigned/बदललेला artifact नाही; install log व screenshots. | P0 |
| INST-02 | Protected install directory किंवा writable AppData fallback ची QA मध्ये चाचणी करा. | app data योग्य user-writable location मध्ये तयार; permission error नाही. | P1 |
| INST-03 | पहिल्या login/setup मध्ये admin व store test accounts तयार करा; password change flow पूर्ण करा; logout/relogin करा. | setup credentials unique/secure; first login नंतर password बदलणे बंधनकारक; login hint/console/log मध्ये secret राहू नये. | P0 |
| INST-04 | Wrong password, disabled account, expired/locked session आणि role-boundary checks करा. | अनधिकृत login/action नाकारले; audit/log मध्ये secret नाही; योग्य वापरकर्त्याचे session सुरक्षितपणे बंद. | P0 |
| INST-2FA | Local 2FA enabled असेल तर TOTP enrollment, valid/invalid code, one-time backup code, used backup-code reuse, logout/relogin व app restart तपासा. | योग्य code शिवाय session उघडत नाही; backup code एकदाच वापरता येतो; protected-secret recovery/reenrolment site policy प्रमाणे; enabled नसेल तर `N/A` व कारण नोंदवा. | P1 |
| INST-05 | DB नवीन तयार करा; schema v23 stores/indexes तयार आहेत का ते तपासा; app दोन windows उघडून upgrade/migration contention तपासा. | startup व migration पूर्ण; `object store not found` नाही; दुसऱ्या connection मुळे block झाल्यास user ला recoverable message. | P0 |
| INST-06 | Previous supported test version वर upgrade करा; local sample data verify; uninstall/reinstall/repair path तपासा. | upgrade दरम्यान data टिकते; uninstall ने अपेक्षित user data अनवधानाने हटत नाही; rollback प्रक्रिया लिहिलेली. | P0 |

## 6. User roles आणि core Shank Mapping workflows

प्रत्येक role साठी स्वतंत्र test account वापरा. Admin ने पाहू शकणाऱ्या screens, Store role, Supervisor/Officer किंवा इतर configured roles यांना गृहीत धरू नका—target deployment मधील प्रत्यक्ष role/capability matrix नुसार तपासा.

| ID | कृती | अपेक्षित निकाल / पुरावा | Priority |
|---|---|---|---|
| ROLE-01 | Store, Admin आणि target site मधील इतर भूमिका घेऊन login करा; menu व permitted actions पाहा. | भूमिका-नुसार फक्त मंजूर screens/actions; UI hide असले तरी थेट unauthorized mutation नाकारले जाते. | P0 |
| MAP-01 | Synthetic Gun Matrix workbook import करा: worksheet निवडा, columns map करा, preview तपासा, मग confirm करा. | Station/Gun/Part संबंध योग्य; duplicate mapping पुन्हा insert नाही; missing Station `Station Not Assigned`; bin silent duplicate नाही. | P0 |
| MAP-02 | Station-name variations, duplicate row, blank required field, existing mapping change अशा negative cases preview मध्ये द्या. | Warnings स्पष्ट; existing mapping overwrite करण्यासाठी explicit confirm; user च्या संमतीशिवाय duplicate Station/Common Bin तयार नाही. | P1 |
| MAP-03 | Common Bin, Fix/Moving Shank आणि Pencil Pair bins तपासा; RH/LH merge शक्य असल्यास staging dataset वर करा. | Pencil physical stock station-independent bin मध्ये; inactive merge source normal active list मध्ये दिसत नाही; merge history/rollback snapshots उपलब्ध. | P0 |
| MAP-04 | Part Master, Station Search आणि Part Search वापरा; repeated Part Number अनेक Guns/positions मध्ये असल्यास तपासा. | Source Part Number जसा आहे तसाच; प्रत्येक mapping योग्य; mapping आणि stock availability वेगळे/स्पष्ट दिसतात. | P1 |
| STOCK-01 | Standard Stock Receive आणि Stock Control Excel Receive दोन्ही वेगळे वापरून test quantities टाका. | Preview allocation योग्य; ledger, stock row आणि audit entries मध्ये समान quantity; invalid batch मध्ये partial commit नाही. | P0 |
| STOCK-11 | Part No. dropdown उघडा; Arrow Down ने Part No. निवडा आणि Enter दाबा. Focus Total Received Quantity मध्ये गेल्यावर positive whole-number Qty टाका; auto-bin preview/confirmation दिसल्यावर Enter दाबा. Receipt नंतर Part No. field तपासा; invalid quantity/no mapping आणि rapid repeated Enter staging मध्ये तपासा. | Dropdown मधील Part No. native पद्धतीने निवडला जातो व Enter नंतर Qty field ला focus मिळतो; confirmation Part No./Qty/source/bin count दाखवते; पुढचा Enter एकच atomic receipt करतो; यशानंतर तोच Part No. field मध्ये भरलेला, focused व selected राहतो आणि Qty रिकामी असते; invalid form receive होत नाही; duplicate posting नाही. | P0 |
| STOCK-02 | Fix/Moving import मध्ये wrong Station/Gun, Bin Location mismatch, invalid quantity, blank rows व invalid workbook तपासा. | चुकीच्या row साठी preview error; सर्व row valid नसल्यास partial import होत नाही; योग्य `.xlsx/.xls/.xlsm/.csv` व first worksheet behavior नोंदवा. | P0 |
| STOCK-03 | Valid Replacement/Issue/OUT करा आणि त्याच item वर उपलब्ध stock पेक्षा जास्त issue प्रयत्न करा. | Stock फक्त एकदाच योग्य प्रमाणात कमी; ledger/audit/user/time जोडलेले; insufficient stock नाकारले. | P0 |
| STOCK-04 | Store role ने approval लागू असलेली request करा; दोन admin windows मधून एकाच pending request ला एकाच वेळी approve करण्याचा staging concurrency test करा. | एकच valid transition/stock deduction; दुसरी action stale/conflict म्हणून नाकारली; duplicate transaction नाही. | P0 |
| STOCK-05 | Receive/OUT/Adjustment मध्ये zero, negative, decimal, अतिमोठी व text quantity तपासा. | फक्त नियमानुसार positive whole number; negative balance नाही; invalid value save होत नाही. | P0 |
| STOCK-06 | Repair → Repair Completed → Repair Return आणि स्वतंत्र Scrap workflow करा. | योग्य quantity/Part/transaction type; Repair Return stock मध्येच जोडले; Scrap चुकीने stock वाढवत नाही. | P0 |
| STOCK-07 | Minimum quantity, zero stock, low stock आणि adequate stock तयार करा; stock status screen तपासा. | ZERO/LOW/OK labels configured rule नुसार; row-level व pooled analytics threshold फरक चुकीने एकत्रित नाही. | P1 |
| STOCK-08 | Staging मध्ये Stock Control Excel Receive preview/commit वर rapid double-click, repeated submit किंवा delayed response मध्ये retry करा. | UI duplicate submit रोखते किंवा duplicate receipt चे स्पष्ट नियंत्रण आहे; stock व ledger duplicate होत नाहीत. सध्याची import documentation repeated click deduplicated असल्याची हमी देत नाही—duplicate झाल्यास P0 data-integrity issue नोंदवा; live production वर हा प्रयोग करू नका. | P0 |
| HIST-01 | Manual Historical Consumption entry करा; duplicate date/Part/quantity row पुन्हा द्या. | ऐतिहासिक analytics/audit मध्ये नोंद; duplicate rule लागू; current stock किंवा live ledger balance बदलत नाही. | P0 |
| HIST-02 | Month-end report ला transactions month-end पर्यंत समाविष्ट आहेत का ते तपासा. | Formula `Opening + Receive + Repair Return − Replacement − Scrap ± Adjustment = Closing`; selected month/year header आणि export filename जुळते. | P1 |

### Stock/data integrity concurrency

Staging मध्ये दोन windows किंवा दोन local sessions मधून एकाच stock item वर simultaneous receive/issue करा. **Local IndexedDB CAS हे local transaction boundary आहे; cross-PC transaction नाही.** Central enabled असल्यास दोन clients कडून एकाच central material वर concurrent stock commits करा. शेवटचा stock = प्रारंभिक stock + सर्व स्वीकारलेल्या movements; rejected/conflict action ledger मध्ये यशस्वी म्हणून दिसू नये; प्रत्येक stock mutation ला एक audit/transaction record असावा. Repeated CAS conflict आल्यास reload/retry स्पष्टपणे द्यावा—silent overwrite स्वीकारू नका.

## 7. Central service आणि offline/retry (फक्त central-enabled site)

हे tests staging API/DB वर करा; failure injection live production वर करू नका.

| ID | कृती | अपेक्षित निकाल / पुरावा | Priority |
|---|---|---|---|
| CENT-00 | प्रत्यक्ष handover bundle मधून निवडलेला deployment route (Windows installer किंवा Compose/manual) clean staging host वर install/start करा; service path मध्ये `core/gunCountService.js` उपलब्ध आहे का verify करा. | Service error शिवाय सुरू; restart नंतर recover; `/health` योग्य; installer log, service status व deployed file manifest जतन. Missing module/config असल्यास central go-live block. | P0 |
| CENT-01 | Migrations `001–005` लागू करा; upgrade आधी/नंतर schema/version तपासा; central server reboot करा. | Migration प्रत्येकवेळी safe; schema version योग्य; service पुन्हा start/health देतो. | P0 |
| CENT-02 | TLS hostname/certificate verify; allowed network मधून health/login; disallowed subnet मधून firewall denial. | Valid certificate; secret/JWT logs मध्ये नाही; ACL/firewall प्रत्यक्ष लागू. | P0 |
| CENT-03 | Central admin/store configured roles ने login करा; unauthorized API actions आणि revoked/disabled account session वापरून पाहा. | server-side authorization लागू; local renderer permission एकटीवर केंद्रीय access अवलंबून नाही; token/session invalidation अपेक्षेप्रमाणे. | P0 |
| CENT-04 | Stock transaction एकदा commit करा; staging test harness मध्ये तोच transaction ID पुन्हा पाठवा. | Idempotency contract नुसार duplicate balance change/ledger row नाही. Request ID व DB record IDs जतन. | P0 |
| CENT-05 | API connectivity बंद असताना test transaction करा; service परत आणा; queue status/retry तपासा. | Offline transaction visible queued/pending; online झाल्यावर एकदाच लागू; user ला queued/success/failure state दिसते. | P0 |
| CENT-06 | Controlled staging मध्ये network failure/5xx आणि client 4xx वेगळे निर्माण करा. | Transient errors queue/retry; स्पष्ट 4xx permanent error म्हणून दाखवला जातो, अनंत transient retry होत नाही; failed item operator कडून निरीक्षण/retry योग्य. | P0 |
| CENT-07 | Repeated server outage staging मध्ये retry limit पर्यंत चालवा; queue failed entry तपासा; operator retry करा. | Retry schedule observable; 10 failed attempts नंतर terminal failed state व error; manual retry counter/state reset नियमानुसार. | P1 |
| CENT-08 | दोन clients कडून conflicting updates; duplicate/competing approval; overlapping pull/health checks. | Central transaction locking/idempotency मुळे accepted balances अचूक; duplicate transition नाही; duplicate polling/request अनावश्यकरीत्या वाढत नाही. | P0 |
| CENT-09 | Central URL रिकामा/local-only mode, नंतर configured mode; login/logout, WebSocket reconnect, terminal auth error test करा. | Local-only मध्ये poll error नाही; central enabled असताना reconnect bounded; logout नंतर local credentials/socket/retry थांबतात. Server token revoke वेगळे server-side test करा—client logout bridge स्वतः revoke करत नाही. | P1 |

## 8. Backup, restore आणि disaster recovery

प्रत्येक backup type वेगळा test करा; ते परस्पर interchangeable नाहीत. आधी backup manifest, file hash, record counts आणि test dataset IDs लिहा.

| ID | कृती | अपेक्षित निकाल / पुरावा | Priority |
|---|---|---|---|
| BAK-01 | Same-machine complete desktop operational backup घ्या; disposable test DB मध्ये restore करा. | Parts, mappings, bins, stock, transactions, historical consumption व audit data योग्य; local users restore नियमाप्रमाणे टिकतात; counts/hash तुलना. | P0 |
| BAK-02 | Portable desktop JSON दुसऱ्या test machine वर import/restore करा. | Target users जतन; operational data योग्य; imported rows readable; 2FA OS-protected secret portability गृहीत धरू नका—आवश्यक असल्यास re-enrol. | P0 |
| BAK-03 | Portable JSON च्या embedded recovery key/confidentiality बाबत receiver हाताळणी तपासा. | File मिळवणारी व्यक्ती contents decrypt करू शकते हे मान्य; authorized secure transfer/storage; test file production data नाही. | P0 |
| BAK-04 | Central PostgreSQL backup घेऊन documented target host/restore method ने restore करा. | Restore नंतर migration/schema, roles, stock/transactions/audit/sync events तपासलेले; app पुन्हा health/login/commit करतो. DPAPI LocalMachine dump दुसऱ्या PC वर portable आहे असे गृहीत धरू नका. | P0 |
| BAK-05 | Restore आधी व नंतर balance reconciliation करा; एक item वर ledger sum विरुद्ध current stock तपासा. | कोणतेही silent loss/duplicate; mismatch असल्यास go-live stop, incident owner ने sign-off. | P0 |

## 9. Hardware आणि user-facing operations

| ID | कृती | अपेक्षित निकाल / पुरावा | Priority |
|---|---|---|---|
| HW-01 | HID scanner; मग Serial scanner (configured असल्यास); scan, malformed input, disconnect/reconnect करा. | योग्य barcode एका field/transaction मध्ये; scan duplicate नाही; reconnect नंतर app recover; model/driver/mode नोंद. | P1 |
| HW-02 | Label preview/print, PDF report export; printer selection, paper size आणि QR scan तपासा. | QR योग्य Station/Bin context उघडतो; Part Number wrapping/clipping नाही; print व PDF मध्ये data पूर्ण; printer/driver नोंद. | P1 |
| HW-03 | Daily-use user ने menu, search, transaction drill-down, report/export, session lock/unlock चालवावे. | प्रत्येक critical screen स्पष्ट; wrong click ने duplicate save/unauthorized change नाही; feedback/errors समजण्यासारखे. | P1 |

## 10. Response-time आणि load test

पहिले target PC ची CPU/RAM, Windows build, app version, local/central network latency व test data volume नोंदवा. Synthetic dataset ने दोन runs करा: **सामान्य** (5,000 rows पर्यंत) आणि **large** (5,000 पेक्षा जास्त rows). प्रत्येक action किमान 30 वेळा; cold-start आणि warm-run वेगळे मोजा. Average एकटाच पुरेसा नाही—p95 आणि budget exceedance count नोंदवा.

| कृती / monitor category | लक्ष्य | कसे मोजायचे |
|---|---:|---|
| Click/input acknowledgement / next paint | 100 ms | approved performance instrumentation किंवा screen recording/trace; Event Timing automatic sample 16 ms पेक्षा कमी duration पकडत नाही. |
| सामान्य screen usable / side-menu navigation | 1,000 ms | click पासून screen usable होईपर्यंत; opening animation नव्हे तर content ready. |
| Stock Status, ≤5,000 rows | 2,000 ms | test rows count नोंदून screen render complete मोजा. |
| Stock Status, >5,000 rows | 5,000 ms | मोठा synthetic dataset; filter आणि table usability वेगळी नोंदवा. |
| Search/filter, ≤5,000 rows | 300 ms | query input पासून visible result update पर्यंत. |
| Search/filter, >5,000 rows | 1,000 ms | large synthetic data वर repeat. |
| Local stock save | 1,000 ms | confirm action ते local confirmation/ledger write success. |
| Central LAN commit | 2,000 ms | stable staging LAN वर request ते commit acknowledgement. |
| Central push-to-render | 2,000 ms | दुसऱ्या client वर change येण्यापासून UI refresh पर्यंत. |
| Small export, ≤1,000 rows | 3,000 ms | file तयार होईपर्यंत; output integrity तपासा. |

Approved diagnostics console उपलब्ध असल्यास `window.performanceMonitor.summary()` ने per-category `count`, `averageMs`, `p95Ms`, `thresholdMs`, `exceedances` जतन करा; `window.performanceMonitor.getSamples()` फक्त authorized test data असताना वापरा. DevTools production build मध्ये उपलब्ध/approved नसेल तर screen recording/OS trace/stopwatch वापरा व measurement method नोंदवा. Monitor targets **हमी किंवा benchmark नाहीत**. Recommended acceptance: प्रत्येक मुख्य category मध्ये किमान 30 valid samples, p95 target मध्ये, वारंवार/सतत exceedance नाही; एकच slow sample असेल तरी कारण नोंदवा. Network/DB/hardware slow असल्यास app आणि infrastructure timings वेगळे करा.

## 11. Failure recovery, rollback आणि regression

1. Staging मध्ये app बंद/पुन्हा सुरू करून pending transaction, login state, local DB आणि logs तपासा.
2. Central outage नंतर queued items एकदाच replay होतात का; same transaction IDs व balances reconcile करा.
3. Migration/upgrade fail झाल्यास vendor runbook वापरून rollback किंवा forward-fix verify करा; production DB वर manual table deletion करू नका.
4. Backup restore नंतर role login, permissions, stock, audit trail, report/export, scanner/print पुन्हा चालवा.
5. Installer rollback/uninstall नंतर data ठेवणे/काढणे याची site policy प्रमाणे स्पष्टता मिळवा.
6. प्रत्येक fix नंतर प्रभावित test cases आणि automated regression पुन्हा चालवा; फक्त जुना pass report copy करू नका.

## 12. Defect report आणि evidence form

प्रत्येक failure साठी खालील template वापरा; वास्तविक password/JWT/secret, personal data किंवा production backup attach करू नका.

```text
Test ID:
Result: Pass / Fail / Blocked / N/A
Build/version + installer SHA-256:
Windows / hardware / network / environment:
Test account role (username redact/alias):
Dataset ID + row count:
Exact steps + timestamp/time zone:
Expected result:
Actual result:
Impact/severity: P0 / P1 / P2
Evidence paths (redacted screenshots, logs, trace, DB counts):
Defect/ticket ID + owner + due date:
Retest build and result:
```

## 13. Final go/no-go sign-off

**Go** зөв तेव्हाच द्या जेव्हा: (a) build/version/hash नोंदलेले; (b) सर्व P0 install/auth/stock/data/backup/restore tests पास; (c) central service लागू असल्यास release bundle fresh व `release:check` पास, TLS/ACL/migrations/duplicate protection चालतात; (d) target hardware वापरलेले; (e) performance evidence व thresholds नोंदलेले; (f) सर्व Fail/Blocked items चे signed disposition आहे; (g) rollback/contact/backup owner उपलब्ध आहे.

```text
Site / environment:
Build/version/hash:
P0 tests: __ passed / __ failed / __ blocked
P1 tests: __ passed / __ failed / __ accepted with workaround
Backup/restore: Pass / Fail
Performance p95 summary attached: Yes / No
Open P0/P1 tickets:
Rollback verified: Yes / No
Operations lead — name/date/sign:
Business owner — name/date/sign:
Vendor/release owner — name/date/sign:
Final decision: GO / NO-GO
```
