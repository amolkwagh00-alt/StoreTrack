# SHANK MAPPING — QUICK START
> **Repository review:** 2026-11-05. Verify against current source and target build; this documentation is not deployment certification.
> **Repository review (2026-11-05):** This guide reflects the RH/LH Common Bin, manual historical consumption, full-dataset import-preview search, and Shank Mapping table-search updates. Target Windows certificate, firewall, ACL, backup-restore, and hardware validation remain deployment-site checks.



## FIRST DAY

1. Open **Shank Mapping** from the StoreTrack Pro application.
2. Download or prepare the Gun Matrix workbook using the supported headers.
3. Upload the Excel workbook and wait for all worksheets to be detected.
4. Select the worksheets and review or correct the suggested column mappings.
5. Build the Import Preview and review New, Updated, Duplicate, Skipped, and Warning counts.
6. Resolve any Station-name variation warning explicitly; choose the existing Station or confirm creation of a new Station.
7. Confirm the import only after reviewing the dry-run and any update prompts.
8. Review the Station/Gun mappings and confirm that each assigned Station has one common Station Bin.
9. Review Part Master and confirm that vendor Part Numbers are preserved exactly.
10. Receive components into the correct common Station Bin before issuing them.
11. Use **Search Station** or **Part Number Search** to locate mappings, bins, stock, and transaction history.
12. Record every Maintenance Replacement with the old Part No., new Part No., quantity, Maintenance Person, Team/Department, condition, action, date/time, shift, bin, and remarks.
13. Classify the removed component as **Repair** or **Scrap**; complete Repair to return its actual lifecycle quantity to stock.
14. Print labels using Preview, Print Selected, or Print All, and choose the required size.
15. Monitor dashboard Low Stock and Zero Stock alerts and use transaction drill-down to investigate a zero balance.
16. At month-end, select the required Month/Year, review the historical calculation, and export accountability for that same month.

## Optional historical and search workflows

- **Manual Historical Consumption:** In Replacement Entry, choose a Part No. suggestion or type one directly, then enter a valid date and positive whole-number quantity. A typed Part No. need not already exist in the suggestions. This records analytics history only and does not change current stock.
- **Large tables:** Use the field-specific search boxes above the table. The Gun Matrix preview filters across all imported rows, including rows on other pages. Use **Clear Search** to return to the full list.
- **Eligible RH/LH pair:** Confirm that the shared active bin name ends in `RH/LH Common Bin`; the non-target source bin is inactive, and the pre-merge source/target snapshots are available through merge history for rollback.

> **Stock concurrency:** Live stock changes compare the encrypted current record optimistically; stock and ledger are committed together. On repeated conflicts (after up to five attempts), reload and retry when `ATOMIC_MUTATION_CONFLICT` is shown. Historical consumption never changes live stock.
>
> **Remember:** One Station has one common bin. Shank Mapping vendor Part Numbers are not auto-generated. A replacement cannot be saved without a Maintenance Person. Historical month-end uses the selected month, not automatically the current month.

[Back to Documentation Index](SHANK_MAPPING_INDEX.md)
