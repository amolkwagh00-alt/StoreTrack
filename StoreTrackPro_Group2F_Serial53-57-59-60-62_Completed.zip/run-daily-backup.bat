@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0node_modules\.bin\electron.cmd" (
  start "StoreTrack Pro Daily Backup" /min "%~dp0node_modules\.bin\electron.cmd" "%~dp0" --hidden
) else if exist "%~dp0StoreTrack Pro.exe" (
  start "StoreTrack Pro Daily Backup" /min "%~dp0StoreTrack Pro.exe" --hidden
) else (
  echo StoreTrack Pro is not installed. Run npm install first or use the packaged EXE.
  exit /b 1
)
