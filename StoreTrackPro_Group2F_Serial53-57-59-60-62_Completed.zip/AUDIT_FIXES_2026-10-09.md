# StoreTrack audit fixes — 2026-10-09 (continued)

## 22 source-level findings addressed in this patch
- P01-F04: Dashboard recent/top/shift metrics and dashboard widgets now use confirmed movement transactions only.
- P03-F04: Quantity-modal supplier option values and labels are escaped.
- P04-F04: Batch OUT invalidates a stale single-item Issue Slip.
- P05-F02: Editing an imported material preserves its existing UUID key.
- P06-F01: Current Stock rows open the Material Detail panel.
- P06-F02: Current Stock Location is escaped before HTML insertion.
- P06-F03: Current Stock empty-state colspan matches its 9 columns.
- P06-F04: Current Stock filtering safely handles malformed name/barcode fields.
- P07-F01: Stock Adjustment checks the physicalStock capability.
- P07-F02: Decimal quantities are rejected, not truncated; input has min=1/step=1.
- P07-F03: Material stock and adjustment history are committed atomically in one IndexedDB multi-store transaction.
- P08-F01: History view, CSV, and Excel share search/type/date filters.
- P08-F02: History is sorted newest-first by transaction timestamp.
- P08-F03: History filtering tolerates malformed/legacy text fields.
- P38-F02: Indent free-text fields are escaped.
- P38-F03: Indent Purpose/Job No. and Remarks are shown and exported.
- P42-F01: Consumption CSV respects category filter.
- P42-F02: Consumption date cutoff matches its N calendar-month buckets.
- P43-F02: GRN table and print HTML escape stored metadata and item fields.
- P43-F03: CSV serialization neutralizes formula-leading text; GRN export uses it.
- P45-F02: Reorder table and CSV share the supplier filter.
- P48-F03: Health Monitor refreshes while visible and cleans up its timer on navigation.
- P48-F01: PerformanceMonitor `PERFORMANCE_METRIC` events now feed valid named numeric samples into predictive health monitoring continuously, without requiring the Health Monitor page to be open. Dedicated Node VM runtime bridge test passes using the actual EventBus, PerformanceMonitor, PredictiveHealthMonitoring modules and `initializeAdvancedModules()` from `app.js`; Electron UI/production runtime remains pending.

## Regression tests and checks
- `node --test tests/storetrack-22-source-fix-regressions.test.js` — PASS, 28 tests (23 finding-specific source assertions + 5 behavior tests).
- `node --test tests/predictive-metrics-runtime.test.js` — PASS, 1 Node VM runtime bridge test for P48-F01; actual emitted probe metric was received by predictive monitoring.
- `node tests/storetrack-audit-regressions.js` — PASS, 35 source/behavior assertions.
- `node tests/smoke.js` — PASS, 80 module references and 96 JavaScript files checked.
- `node tests/offline-smoke.js` — PASS, 4 offline/database initialization checks.
- `node scripts/release-hygiene.js` — PASS.
- `node scripts/production-validation.js` — 5 PASS, 2 BLOCKED because `STORETRACK_JWT_SECRET` and PostgreSQL configuration (`DATABASE_URL`/`PGHOST`) are not set.

## Runtime test cases prepared
`tests/STORETRACK_RUNTIME_PENDING_11_TEST_CASES.md` contains 11 step-by-step runtime test cases for P02-F03, P02-F04, P16-F01, P16-F04, P16-F05, P16-F06, P26-F01, P26-F02, P38-F04, P42-F04, and P43-F04. They require a configured Electron app and disposable test database.

## Important limitations
- The 22 findings in this patch have source fixes and automated regression coverage, but their full Electron UI/database runtime behavior has not yet been verified. P48-F01 additionally passes a focused Node VM runtime bridge test; Electron UI/production behavior is still pending.
- The 11 runtime test cases are prepared, not executed. Do not mark them PASS until evidence is recorded.
- Production validation remains blocked by missing JWT/PostgreSQL configuration. Full Jest/Electron end-to-end execution was not available in this environment.
- This patch does not claim all 164 audit findings are closed; keep `Open = 0` unclaimed until all applicable runtime cases pass and the remaining findings are independently evidenced.


## Batch 1 — first 30 master findings (2026-10-09)

The first 30 unique findings were reviewed in original master order in a recoverable working copy. No edits were made to the uploaded original archive or original source tree. Existing correct code was verified rather than re-applied.

### Source changes made or hardened
- P02-F01: `nav` now accepts a scoped `bypassFeatureGate` option used only by Backup Center to enter the component host when Shank Mapping is disabled.
- P02-F04: complete backup restore, safety snapshot, and rollback skip the `users` store; account-preservation notice remains explicit.
- P03-F02: added a today's Material IN transaction filter/renderer and wired it on page entry and after manual receipt.
- P03-F03: scanner IDB receipt updates the selected Material IN stock display and refreshes the IN log.
- P04-F01/F03/F04/F05: Batch OUT now checks `procOut` capability and fails closed; submits central sync and records `pending-central` failure; invalidates stale slip only after authorization/cart checks; requires atomic `dPutMany` writes without sequential fallback.
- P05-F01: import label/accept list now advertises only supported Excel formats.
- P05-F03/F04/F05/F06: clear stale zero-result bulk-selection controls and enforce the matching direct capability checks on delete/toggle/import/export handlers.
- P07-F01: Stock Adjustment now fails closed when the role-action checker is missing or `physicalStock` is denied.
- Updated the existing source-fix assertions for Batch OUT guard ordering and Stock Adjustment's fail-closed guard.
- Added `tests/storetrack-first-30-batch-regressions.node-test.cjs`, one focused case per finding.

### Partial mitigation
- P02-F03 remains `PARTIAL_CODE_RUNTIME_PENDING`: restore explicitly warns and confirms while preserving omitted operational stores; it does not automatically clear/restore missing stores.

### First-30 regression and affordable checks
- `node --test tests/storetrack-first-30-batch-regressions.node-test.cjs` — PASS, 30/30.
- `node --test tests/storetrack-22-source-fix-regressions.test.js` — PASS, 28/28.
- `node tests/storetrack-audit-regressions.js` — PASS, 35 assertions.
- `node tests/smoke.js` — PASS, 80 script references and 96 app JS files.
- `node tests/offline-smoke.js` — PASS, 4 checks.
- `node scripts/release-hygiene.js` — PASS.
- `node --check app.js`, `modules/dataBackup.js`, `main.js`, and `preload.js` — PASS.

These are source-level and helper-level checks, not Electron UI/IndexedDB or production runtime verification. All 11 prepared Electron runtime cases remain unexecuted. Full Jest/Playwright execution remains blocked by unavailable project dependencies/runner; no dependencies were installed. See `FIRST30_FINDINGS_REPORT.md`, `TEST_RUN_REPORT.md`, and `REMAINING_BLOCKERS.md` in the audit deliverables.