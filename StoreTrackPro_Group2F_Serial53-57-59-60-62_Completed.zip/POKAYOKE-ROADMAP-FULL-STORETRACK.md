# StoreTrack — Sampurna Software Poka‑Yoke Roadmap

**Scope:** Dashboard, Materials/Stock, IN/OUT, suppliers, PO/GRN, indent/approvals, returns, cycle count, bins, component/shank mapping and lifecycle, preventive maintenance, analytics/reports, users/security, imports/exports, sync, backup/restore, scanner/printer and settings.

## Mool niyam

Poka‑Yoke mhanje chuk zalyavar message dakhavne evadhe nahi. **Invalid/ambiguous operation save hou naye; valid operation ekdach, yogya record/bin/user var, audit trail sahit commit vhava.** Confirmation popup ha shevatcha safety layer; mapping, quantity, permission, state ani database constraints ha pahila layer asava.

## Sampurna app la lagu honare safety controls

| Control | App madhye lagu karnyachi paddhat | Priority |
|---|---|---|
| Ekach validation service | UI validation var avalambun rahu naka. Save, import, scanner, offline queue ani API sarvanni ekach service/domain rule vaprava. | P0 |
| Stable IDs | Dropdown/datalist madhun disnara label navhe; internal material ID, bin ID, user ID ani mapping ID save kara. Label badalal tari sambandh tutnar nahi. | P0 |
| Atomic save | Stock badal, transaction, lifecycle, approvals ani audit record sambandhit astil tar ekach DB/server transaction. Error zala tar sagla rollback. | P0 |
| Duplicate-action rok | OUT, GRN, PO receive, return, approval, import, sync ya pratyek command la user-scoped idempotency key. Double-click/retry ne operation duplicate hou naye. | P0 |
| Stale form protection | Record open kelyanantar dusrya user ne update kela asel tar version/`updatedAt` mismatch check kara; overwrite na karta latest data reload karayla sanga. | P0 |
| Explicit impact preview | Save purvi item, qty, before/after stock, source/destination, Old/New Part, approver ani related records dakhva. | P0 |
| No silent fallback | Unknown ID, blank/invalid quantity, missing mapping, offline state, low permissions kiwa failed printer/sync la default/guess karu naka. | P0 |
| Reason + trace | Manual override, negative/exception action, scrap, stock adjustment, delete/restore la mandatory reason; actor, timestamp, before/after value record kara. | P1 |
| Safe undo | Ledger entry delete/edit na karta reversing transaction ne undo kara; undo la original event ID link kara. | P1 |
| Role + separation | Create/approve/receive/adjust/delete permissions vegle; high-impact action sathi dusra approver; self-approval block. | P1 |

## Module/workflow pramane Poka‑Yoke

| Module / workflow | Rokayche pramukh failure modes | Poka‑Yoke design |
|---|---|---|
| **Login, Users, 2FA, Sessions, Permissions** | Chukicha role, disabled user, stale session, self-approval, unauthorized export | Default-deny role matrix; pratyek API/DB action la server-side authorization; sensitive action aadhi re-auth/2FA; logout/password reset nantar session revoke; self-approval block; permission-denied audit. |
| **Material Master** | Duplicate barcode/part, wrong unit/category, used item delete, wrong min/max | Unique normalized SKU/barcode; unit allowlist; duplicate detection before save/import; item used in history asel tar delete nahi—archive; min/max consistency check; required supplier/category fields. |
| **Material IN / GRN / Purchase Order** | Wrong PO/supplier/item, over-receipt, duplicate GRN, wrong cost/quantity | PO → supplier → material pre-fill ani immutable link; received qty PO balance peksha jast asel tar explicit over-receipt approval; invoice/GRN duplicate number check; line-level preview; Save+stock+GRN+audit atomic; scan item and compare expected PO line. |
| **Material OUT / Batch OUT** | Wrong material/person/department, excess qty, repeated scan, accidental submit | User/department/job reference required; available stock live recheck at commit; quantity >0 and <= available; scan-first with visible item name/photo; duplicate barcode in same batch highlight; batch all-or-none kiwa explicit partial policy; per-line confirmation for high-value item. |
| **Stock Adjust** | Wrong sign/reason, stock below zero, silent count correction | Adjustment type determines sign; user cannot freely invert it; reason required; before/after preview; threshold-based second approval; commit rechecks latest quantity and logs the physical-count evidence. |
| **Material Return** | Return wrong item, return more than issued, return same issue twice | Original OUT transaction select/scan karne mandatory; remaining returnable qty calculate; returned quantity <= outstanding issued qty; each return linked to original transaction; duplicate return key block; condition (usable/repair/scrap) required. |
| **Cycle Count / Physical Verification** | Duplicate count, stale snapshot, variance hidden, one row partially committed | Freeze/version count snapshot; one active count per zone; each barcode/bin once; unknown item goes to exception queue; variance preview with reason; all rows validate before atomic commit; recount/approval for threshold variances. |
| **Bins / Location / Stock Movement** | Wrong source/destination, deleting assigned bin, partial move unsupported, same-bin move | Scan source bin + item, verify item is actually there; source != destination; qty available and model permits; full-item move only if per-bin quantity model nahi; destination capacity check; bin with references archive-only; stock and movement history atomic. |
| **Suppliers / Reorder / PO** | Wrong supplier, duplicate PO, unit-price error, reorder over/under, PO sent twice | Supplier active/status check; currency/UOM normalization; last-price variance alert; PO number unique; min order/lead-time/MOQ rule; order quantity preview based on available + pending + demand; supplier submission idempotent; approval threshold on amount. |
| **Indent Request / Approvals** | Duplicate request, unauthorized approval, requester approves own request, stale approval | Request token prevents duplicate; available stock and substitute suggestions; approval matrix by amount/category; requester cannot approve own request; approval bound to exact request version/amount; any edit invalidates approval and restarts chain. |
| **Preventive Maintenance / Machine Spares** | Wrong machine/part, missed due service, duplicate work order, unsafe spare usage | Machine ID scan; maintenance schedule blocks completion without checklist; required readings/photo for critical work; spare part availability verify; one open work order per machine/task; completion linked to technician and machine hour; overdue escalation. |
| **Component/Shank Mapping, Replacement, Repair/Scrap, History** | Wrong Part→Station→Gun→Component→Bin; wrong Old/New Part; ambiguous RH/LH; duplicate repair return | Exact unique mapping gate; merged bin resolve to canonical bin; no silent Old Part fallback; unique Old Part inference only; explicit Old/New scan; lifecycle state machine; repair return limited to originating lifecycle; replacement stock/lifecycle/audit atomic; historical mode cannot mutate stock. *(Audit madhye kahi controls aadhich implement/test kele aahet.)* |
| **Imports (CSV/Excel/PDF/Word/Component)** | Column shift, invalid date/decimal, duplicate rows, partial import, guessed component | File hash/name + import ID dedupe; schema/template version check; preview every normalized row; invalid/ambiguous row blocks batch; duplicate key and date/locale warnings; dry-run stock impact; all-or-none transaction; store original file checksum and import audit. |
| **Barcode Labels / Scanner / Printing** | Wrong printer/template, duplicate/incorrect label, scanner prefix error | Print preview with item ID + human-readable code; test-label mode; verify scanner prefix/suffix/config before enabling; scan printed label back and compare; one label per canonical ID; printer failure must not mark task done. |
| **Dashboards, Reports, BI, Consumption, Forecasting, AI** | Stale/incomplete data, mixed historical/live values, forecast mistaken as fact | Show data-as-of time, filters and source; Historical Consumption explicitly analytics-only; forecast/AI output labelled estimate with confidence and evidence; detect missing/duplicate periods; no AI-generated stock action auto-commit; CSV/PDF export inherits current filter and permission. |
| **Notifications / Low-stock / Supplier Performance** | Duplicate or stale alerts, wrong recipients, alert says done when unsent | Alert event ID dedupe; delivery state queued/sent/failed; recipient preview; retry idempotent; resolve alert only after underlying stock/order condition is rechecked. |
| **Central Sync / Offline / Background Sync** | Fake success, partial migration, duplicate retry, wrong-user cached response | Network state visible; local queue state shown per record; server ACK before Synced; user-scoped idempotency; transaction/batch API for migrations; conflict screen, never last-write-wins silently; API cache user-scoped or disabled; failed sync remains retryable and visible. *(Fake Background Sync success audit madhye band kele; actual adapter/configuration ajun pahije.)* |
| **Backup / Restore / Data Archiving** | Plaintext sensitive file, wrong backup, partial restore, accidental overwrite | Password-protected authenticated encryption; backup schema/version + checksum; restore dry-run counts/conflicts; choose merge/replace explicitly; export and restore permissions; restore to staging then verify; atomic swap/rollback; keep immutable pre-restore snapshot. |
| **Audit Trail / System Diagnostics / Settings** | Audit tampering, unsafe config, hidden environment failures | Append-only audit at server side; no edit/delete UI; show user/time/source/record ID; settings schema validation + test connection before apply; config changes require admin re-auth; health indicator shows blocked/missing JWT/DB/sync/printer status. |
| **Accessibility / General UI** | Keyboard-only user misses disabled/error state; buttons trigger twice | Required-field labels; focus first invalid field; error beside field; keyboard-operable menus/dialogs; disabled reason visible; loading lock on submit; responsive/accessible confirmation; clear Cancel vs Save distinction. |

## Amalbajavni kram

### Phase 1 — Stock correctness (sarvat aadhi)
Material Master uniqueness; IN/OUT/GRN/Return/Cycle Count rules; bin and component mapping; atomic writes; duplicate-action protection; audit reason; final stock impact preview. Acceptance: parallel/double-submit test madhye stock ekdach badalto; negative stock hot nahi; ek row invalid asel tar all-or-none policy enforce hote.

### Phase 2 — Approval and lifecycle
Indent→approval→PO→GRN trace; separation of duties; amount/variance approvals; component repair/return state machine; reversible ledger actions. Acceptance: unauthorized/self-approval block; invalid state transition block; pratyek stock change la source document/audit reference.

### Phase 3 — Data safety and integration
User-scoped idempotency migration; central sync batch transactions; backup encryption and staged atomic restore; RH/LH reconciliation atomicity; API authorization/CSRF/rate-limit checks. Acceptance: simulated network interruption/retry mule duplicate/partial server data hot nahi; restore failure nantar original dataset exact parat milto.

### Phase 4 — Usability and analytics guardrails
Scanner/printing verification; stale-data banners; AI/forecast labels; reliable notification delivery; keyboard/error-state accessibility. Acceptance: user la data stale, unsynced, estimated kiwa printer/scanner unavailable aahe he action purvi spashta diste.

## Release gate / Poka‑Yoke test checklist

Pratyek high-impact workflow sathi tests madhye he cases compulsory kara: valid save; blank/malformed input; unknown/ambiguous mapping; wrong user/role; stale record; double-click; retry after simulated timeout; DB failure mid-transaction; concurrent users; offline mode; duplicate import; rollback; audit completeness. Production release aadhi real PostgreSQL migration test, backup→restore drill, ani scanner/printer hardware test kara.

## Aajchya audit madhye dislele open points

Central idempotency user-scoped migration, central sync partial-write prevention, Background Sync remote adapter, plaintext JSON backup encryption, backup restore ani RH/LH reconciliation full atomicity he ajun implement/production-verify karayche aahet. PWA API offline cache privacy karanane disabled aahe. He sagle **P0/P1 backlog** madhye ghya; existing [Full Project Audit] madhye exact blockers/tests aahet.
