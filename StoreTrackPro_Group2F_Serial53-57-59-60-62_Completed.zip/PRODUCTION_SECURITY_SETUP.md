# StoreTrack Pro Production Security Setup
> **Repository alignment (2026-09-19):** This documentation is aligned with the security-fixed and performance-tuned StoreTrack Central Server build. Target Windows certificate, firewall, ACL, backup-restore, and hardware validation remain deployment-site checks.


## HTTPS

The central API now binds to `127.0.0.1` by default. For a public or LAN deployment, use one of these supported modes:

### Trusted HTTPS reverse proxy

Run the API behind Nginx, Caddy, or another TLS terminator. Set:

```env
NODE_ENV=production
HOST=0.0.0.0
TRUST_PROXY_TLS=true
CORS_ORIGIN=https://inventory.example.com
STORETRACK_JWT_SECRET=<random secret of at least 32 characters>
```

The reverse proxy must terminate HTTPS, forward requests to the API, and restrict access to the API port. `TRUST_PROXY_TLS=true` is an explicit operator assertion; it must not be set unless the proxy really enforces HTTPS.

### Direct Node TLS

For a direct TLS listener, provide both certificate files:

```env
NODE_ENV=production
HOST=0.0.0.0
TLS_KEY_FILE=/etc/storetrack/tls/privkey.pem
TLS_CERT_FILE=/etc/storetrack/tls/fullchain.pem
CORS_ORIGIN=https://inventory.example.com
STORETRACK_JWT_SECRET=<random secret of at least 32 characters>
```

`TLS_KEY_FILE` and `TLS_CERT_FILE` must be provided together. The API refuses a production public binding when neither direct TLS nor an explicitly trusted TLS proxy is configured.

## Persistent JWT revocation

On startup, the central migration creates the `revoked_tokens` table and the `session_version` column on `app_users`. Logout writes the token ID and expiry to PostgreSQL. HTTP/WebSocket authentication checks revocation, active status, current role, and session version before accepting the token. Role changes, account deactivation, password replacement, and synchronized account updates invalidate older sessions. Expired revocation rows are cleaned during new revocation writes.

Run the normal migration before accepting traffic:

```bash
npm run central:migrate
```

The database must be persistent. Do not use an ephemeral PostgreSQL volume in production. The `server/docker-compose.yml` configuration requires an explicit `CORS_ORIGIN` and `TRUST_PROXY_TLS` value for its public API binding.

The Windows installer defaults the API firewall to `LocalSubnet`; pass `-FirewallRemoteAddress` with the approved LAN CIDR for a narrower scope. PostgreSQL must not be reachable from workstations. The installer creates DPAPI LocalMachine-encrypted `.dump.dpapi` backups, deletes the temporary plaintext dump, and creates `Restore-Database.ps1` for same-host restore drills.

## Required operational validation

After deployment, verify that:

1. `https://<domain>/health` is reachable and the HTTP endpoint is not publicly exposed.
2. Logout makes the same token return HTTP 401 on a second protected request.
3. Restarting the API does not make a revoked token valid again.
4. A second site cannot receive events scoped to the first site.
5. A role change or account deactivation makes the old token return HTTP 401.
6. PostgreSQL backups include the `revoked_tokens` table and `app_users.session_version` values.
7. The encrypted backup restore helper successfully restores a test copy on the same Windows host.
