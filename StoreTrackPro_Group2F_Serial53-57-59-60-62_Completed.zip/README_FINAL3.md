# StoreTrack Pro V8 — Final Feature Status
> **Repository alignment (2026-09-19):** This documentation is aligned with the security-fixed and performance-tuned StoreTrack Central Server build. Target Windows certificate, firewall, ACL, backup-restore, and hardware validation remain deployment-site checks.


Use the current project package rather than older archives. The final source includes the production Shank Mapping, pooled stock, forecast, procurement, backup, CSP, and UI fixes described in the documentation suite.

## Performance testing

`performanceTesting.js` is not wired as a fake REST load test. The application uses the System Diagnostics page to run a real Database Benchmark against the local IndexedDB database. The benchmark measures average write time across repeated operations and bulk-read time for the actual local data set. Results are recorded through the existing performance monitoring path.

## Final feature status

| Category | Status |
|---|---|
| Implemented and operational features | 20 |
| Intentionally not wired by design, with reasons shown in System Diagnostics | 6 |
| Replaced fake implementations with real Stock-Out Forecast and Database Benchmark features | 2 |
| Existing notification features with collision fixes | 2 |

No item is silently presented as complete when it is not supported. Features that are not appropriate for this offline Electron application are explicitly identified in System Diagnostics.

## Verification steps

1. Open **System Diagnostics**.
2. Select **Database Benchmark** and choose **Run Benchmark** to view real local database measurements.
3. Review the **Not Wired — By Design** card for features that require external services or are intentionally excluded.
4. Run the complete Jest and smoke-test commands described in the Testing Documentation.

## Documentation

The `docs` folder contains the English production workflow, user guides, role guide, troubleshooting guide, FAQ, technical architecture, security, deployment, testing, centralization documentation, and rendered Mermaid diagrams. The current production rules are:

- Auto Safety / Minimum Qty equals Gun Mapping occurrence.
- Maximum Qty equals Gun Mapping occurrence multiplied by two.
- Procurement uses pooled Part-level stock across all bins.
- Effective default lead time is 90 days: 30 internal PR/PO days plus 60 supplier days.
- Manual Remaining Qty and Physical Verification are adjustments and do not count as consumption usage.
- Open or pending orders prevent duplicate ORDER NOW alerts.
- Backup & Restore opens through the Shank Mapping component section.
