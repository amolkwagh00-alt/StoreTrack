/* exported _removeAllEventListeners, ackAlertUI, addUser, adjChg, approveIndent, approveReq, batchScan, bulkApproveSelected, bulkRejectSelected, changePassword, checkArStrength, clearApprovalSelection, clearHistFilter, closeDbLock, closeInQtyPopup, closeLblPreview, closeOutQtyPopup, closeShiftEnd, confirmBatchOut, confirmInQtyPopup, confirmMove, confirmOutQtyPopup, copyLowAlert, delDept, delLoc, delMat, delSupp, delUser, deleteSelectedMaterials, diagClearErrors, diagClearLogs, diagExportLogs, doAdjust, doAdminResetPw, doCopyAlert, doGSearch, doPrintSlip, doSendBoth, downloadSampleCSV, editDept, editLoc, editMatFromDetail, editSupp, exportAllMaterialsExcel, exportBackup, exportCSV, exportClosingCSV, exportClosingXLSX, exportLocCSV, exportLocXLS, exportPDFReport, exportSelectedCSV, genLowFile, genPODraft, genReport, getShiftEnd, getShiftStart, handlePhoto, importBackup, importCSV, initTheme, issueIndent, lanExport, lanImport, lblCopiesChange, lblDoPrint, lblRangeSync, lblSetColor, lblSetDest, lblSetOrient, lblSideNav, lblToggleCutLines, lblToggleGrid, lblToggleRuler, lblToggleSection, lblUpdatePreview, lblZoomActual, lblZoomChange, lblZoomFit, loadMovItem, markAllNotifsRead, markNotifRead, mdGoEdit, mdGoIn, mdGoOut, openAdminReset, openAlertPreview, openBatchOut, openDbLock, openDbPasswordReset, openLblPreview, openMatDetail, openMaterialDetail, openSmartImport, pinClear, pinKey, previewLowAlert, printClosingReport, printGRN, printIssueSlip, printLabels, printLocReport, printMatCard, printMaterialCard, printMonthlySummary, printPO, printSelectedLabels, printShiftReport, quickInFromDetail, quickOutFromDetail, refreshLanHealth, rejectIndent, rejectReq, removeBatchItem, removeSpecRow, reqForgotPw, requestDesktopNotificationPermission, resetDbPassword, resetUserPassword, resolveAlertUI, restoreArchiveRecord, restoreLocalSnapshot, runArchiveNow, runDbBenchmark, saveAlertCfg, saveAnalyticsConfig, saveBarcodeCfg, saveCoCfg, saveCycleCount, saveDept, saveIndent, saveLoc, saveMat, saveNotifPrefs, saveReturn, saveSupp, saveWidgets, scCancelEnroll, scClearLog, scEnrollHID, scRefreshHID, scRefreshPorts, scResetConfig, scSaveSerial, scSetMode, scTest, scToggleAutoStart, scrollNav, selectAllApprovals, selectAllLabels, setLabelSize, showCCDetail, showForgotPw, siConfirmImport, siNext, snapshotLocalData, startCycleCount, swTab, switchSummary, toggleAllPO, toggleLbl, toggleMat, toggleNotifDropdown, togglePO, toggleSelectAllMaterials, toggleSelectedMaterials, toggleSidebar, toggleTheme, toggleUser, updateCCItem, updateTopLowBadge, verifyDbLock */

function completedTransaction(t) { return t && t.status === 'confirmed' && Number.isFinite(Number(t.qty)) && Number(t.qty) >= 0; }
/* global applyCssText, sentryIntegration, apmMonitoring, userBehaviorAnalytics, dashboardIntegrations, predictiveHealthMonitoring, automatedIssueDetection, selfHealing, performanceBaseline, queryCache, backgroundSync, businessIntelligence, anomalyDetection */
// Register service worker for PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(err => console.warn('[Service Worker]', err.message))
      .then(registration => {
        console.log('ServiceWorker registration successful:', registration.scope);
      })
      .catch(error => {
        console.log('ServiceWorker registration failed:', error);
      });
  });
}

// ── IndexedDB ──
// Database functions are now in modules/database.js to avoid conflicts

// ── Security Utilities (XSS Protection) ──
// These functions are now in modules/utilities.js to avoid duplication

// ── UUID Helper (with fallback for older browsers) ──
// This function is now in modules/utilities.js to avoid duplication

// ── Debounce Utility ──
// This function is now in modules/debounce.js to avoid duplication

// ── Loading States ──
let loadingOverlay=null;
function showLoading(message='Loading...',cancellable=false){
  if(!loadingOverlay){
    loadingOverlay=document.createElement('div');
    loadingOverlay.id='loading-overlay';
    applyCssText(loadingOverlay,'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:9999;color:white;font-size:18px;');
    document.body.appendChild(loadingOverlay);
  }
  loadingOverlay.innerHTML=`<div class="loading-spinner"></div><p id="loading-message">${message}</p>${cancellable?'<button data-onclick="hideLoading()" data-style="margin-top:20px;padding:10px 20px;background:var(--bl);color:white;border:none;border-radius:4px;cursor:pointer;">Cancel</button>':''}`;
  loadingOverlay.style.display='flex';
  return {
    hide:hideLoading,
    update: function(newMessage){
      const msgEl = document.getElementById('loading-message');
      if(msgEl) {msgEl.textContent = newMessage;}
    }
  };
}
function hideLoading(){
  if(loadingOverlay) {loadingOverlay.style.display='none';}
}

// ── Keyboard Shortcuts ──
const SHORTCUTS={
  'Ctrl+K':()=>{const search=document.querySelector('.topbar-search input');if(search){search.focus();}},
  'Ctrl+1':()=>nav('dash'),
  'Ctrl+2':()=>nav('master'),
  'Ctrl+3':()=>nav('in'),
  'Ctrl+4':()=>nav('out'),
  'Ctrl+5':()=>nav('stock'),
  'Ctrl+6':()=>nav('reports'),
  'Ctrl+7':()=>nav('labels'),
  'Ctrl+8':()=>nav('cfg'),
  'Ctrl+L':()=>{if(confirm('Are you sure you want to logout?')){doLogout();}},
  'Escape':()=>{const overlays=document.querySelectorAll('.ov.on');overlays.forEach(o=>o.classList.remove('on'));},
  'F1':()=>{nav('cfg');toast('Keyboard shortcuts shown in Settings section','inf');}
};
const shortcutKeys={};
function initShortcuts(){
  document.addEventListener('keydown',e=>{
    // Ignore shortcuts when user is typing in input fields, textareas, or contenteditable elements
    const target = e.target;
    const isInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable;
    
    // Allow Ctrl+K to focus search, and Escape to close overlays, even from inputs
    if (isInput && !(e.ctrlKey && e.key.toLowerCase() === 'k') && e.key !== 'Escape') {
      return;
    }
    
    // Normalize single-character keys to uppercase so e.g. 'k' and 'K' both
    // match the 'Ctrl+K' entry in SHORTCUTS (was case-sensitive before, so
    // every letter-based shortcut silently failed to match).
    let key = e.key.length === 1 ? e.key.toUpperCase() : e.key;
    if(e.ctrlKey) {key = 'Ctrl+' + key;}
    else if(e.altKey) {key = 'Alt+' + key;}
    else if(e.shiftKey) {key = 'Shift+' + key;}
    
    if(SHORTCUTS[key]){
      e.preventDefault();
      e.stopPropagation();
      SHORTCUTS[key]();
    }
  });
}
// Activate keyboard shortcuts. This was previously defined but never called,
// so none of the shortcuts (Ctrl+1..8, Ctrl+L, Escape, F1) worked at all.
initShortcuts();

// ── Enter-key submit ──
// Generic Enter-to-submit support: previously each form/modal had to wire its
// own onkeydown handler individually, and most didn't, so pressing Enter did
// nothing almost everywhere in the app (including the Login screen).
document.addEventListener('keydown', e => {
  if (e.key !== 'Enter') {return;}
  const target = e.target;
  // Only act on single-line text inputs — never hijack Enter in a <textarea>
  // (needs newlines) or on checkboxes/radios/file pickers.
  if (target.tagName !== 'INPUT') {return;}
  if (['checkbox', 'radio', 'file', 'button', 'submit'].includes(target.type)) {return;}

  // Login screen: Enter in username/password submits login
  const loginWrap = document.getElementById('login-wrap');
  if (loginWrap && getComputedStyle(loginWrap).display !== 'none' && loginWrap.contains(target)) {
    e.preventDefault();
    doLogin();
    return;
  }

  // Any open overlay/modal (".ov.on"): Enter clicks its primary action button
  const openOv = target.closest('.ov.on');
  if (openOv) {
    const primaryBtn = openOv.querySelector('.modal .btn-p, .modal .btn-s');
    if (primaryBtn && !primaryBtn.disabled) {
      e.preventDefault();
      primaryBtn.click();
    }
  }
});

// ── Error Handling ──
function handleError(error, context = {}) {
  console.error('Error:', error, context);
  
  // Build context-aware error message
  let msg = error.message || 'An error occurred';
  
  // Add context-specific guidance
  if (context.operation) {
    const operationGuidance = {
      'login': 'Please check your credentials and try again.',
      'save': 'Your changes were not saved. Please try again.',
      'delete': 'The item could not be deleted. It may be in use.',
      'import': 'The file could not be imported. Please check the file format.',
      'export': 'The data could not be exported. Please try again.',
      'sync': 'Data synchronization failed. Please check your connection.',
      'print': 'The document could not be printed. Please check your printer.',
      'scan': 'Scanner error. Please check the scanner connection.'
    };
    
    if (operationGuidance[context.operation]) {
      msg += '. ' + operationGuidance[context.operation];
    }
  }
  
  // Add actionable suggestions for common errors
  if (msg.includes('network') || msg.includes('connection')) {
    msg += ' Please check your internet connection.';
  } else if (msg.includes('permission') || msg.includes('access')) {
    msg += ' You may not have sufficient permissions.';
  } else if (msg.includes('not found')) {
    msg += ' The requested resource was not found.';
  }
  
  toast(msg, 'er');
  
  // Log detailed error for debugging
  if (context.details) {
    console.error('Error details:', context.details);
  }
}

// ── State ──
let M=[],T=[],U=[],A=[],AP=[],ADJ=[],SP=[],DP=[],CFG={},IN_REQ=[],RET=[],CC=[],GRN=[],LOCS=[],MOVS=[];
let cu=null,inI=null,outI=null,lblSel=[],lastTx=null,rpData=[];
if (typeof window !== 'undefined') {
  Object.defineProperty(window, 'currentUser', { configurable: true, get: () => cu, set: value => { cu = value; } });
}
function generateSetupSecret(){
  const bytes=new Uint8Array(18);
  if(window.crypto?.getRandomValues){window.crypto.getRandomValues(bytes);return Array.from(bytes,b=>b.toString(36).padStart(2,'0')).join('');}
  throw new Error('Secure random setup credentials are unavailable');
}

// The stock forecast consumes both material stock and confirmed transactions.
// Invalidate at the shared persistence boundary so every app workflow (including
// approvals, imports, returns, and batch writes) cannot leave a stale forecast.
function invalidateStockForecast(){
  try{window.cacheManager?.delete('stock-forecast');}catch(e){/* cache is optional */}
}
if(window.dPut&&!window.dPut.__stockForecastInvalidation){
  const basePut=window.dPut;
  const wrappedPut=async function(store,obj){
    const result=await basePut(store,obj);
    if(store==='materials'||store==='transactions'){invalidateStockForecast();}
    return result;
  };
  wrappedPut.__stockForecastInvalidation=true;
  window.dPut=wrappedPut;
}
if(window.dPutMany&&!window.dPutMany.__stockForecastInvalidation){
  const basePutMany=window.dPutMany;
  const wrappedPutMany=async function(writes){
    const result=await basePutMany(writes);
    if((writes||[]).some(write=>write?.store==='materials'||write?.store==='transactions')){invalidateStockForecast();}
    return result;
  };
  wrappedPutMany.__stockForecastInvalidation=true;
  window.dPutMany=wrappedPutMany;
}
if(window.batchPut&&!window.batchPut.__stockForecastInvalidation){
  const baseBatchPut=window.batchPut;
  const wrappedBatchPut=async function(store,rows){
    const result=await baseBatchPut(store,rows);
    if(store==='materials'||store==='transactions'){invalidateStockForecast();}
    return result;
  };
  wrappedBatchPut.__stockForecastInvalidation=true;
  window.batchPut=wrappedBatchPut;
}
if(window.dDel&&!window.dDel.__stockForecastInvalidation){
  const baseDelete=window.dDel;
  const wrappedDelete=async function(store,id){
    const result=await baseDelete(store,id);
    if(store==='materials'||store==='transactions'){invalidateStockForecast();}
    return result;
  };
  wrappedDelete.__stockForecastInvalidation=true;
  window.dDel=wrappedDelete;
}
if(window.dClr&&!window.dClr.__stockForecastInvalidation){
  const baseClear=window.dClr;
  const wrappedClear=async function(store){
    const result=await baseClear(store);
    if(store==='materials'||store==='transactions'){invalidateStockForecast();}
    return result;
  };
  wrappedClear.__stockForecastInvalidation=true;
  window.dClr=wrappedClear;
}

async function loadAll(){
  [M,T,U,A,AP,ADJ,SP,DP,IN_REQ,RET,CC,GRN,LOCS,MOVS]=await Promise.all(['materials','transactions','users','audit','approvals','adjustments','suppliers','departments','indents','cyclecount','returns','grn','locations','movements'].map(gAll));
  const c=await gAll('config');if(c.length){CFG=c[0];}
  // Cross-Windows backups created before the Shank Mapping/Gun UI was added
  // do not contain this flag. Treat only a missing value as enabled so the
  // new UI is available after restore, while preserving an explicit developer
  // choice to disable the feature.
  if (typeof CFG.featureShankMapping !== 'boolean') {
    CFG = { ...(CFG || {}), id: CFG?.id || 1, featureShankMapping: true };
    await dPut('config', CFG);
  }
  applyFeatureMenuVisibility();
  ['cfg-em','cfg-wa','cfg-bcp','cfg-co','cfg-addr','cfg-loc','cfg-gst','cfg-central-url'].forEach(id=>{
    const map={'cfg-em':'email','cfg-wa':'wa','cfg-bcp':'barcodePrefix','cfg-co':'company','cfg-addr':'addr','cfg-loc':'location','cfg-gst':'gst','cfg-central-url':'centralServerUrl'};
    const el=document.getElementById(id);if(el&&CFG[map[id]]){el.value=CFG[map[id]];}
  });
  
  // Create default users if none exist
  if (U.length === 0) {
    const adminSetupPassword = generateSetupSecret();
    const storeSetupPassword = generateSetupSecret();
    const defaultUsers = [
      { id: 1, username: 'admin', passwordHash: await hashPassword(adminSetupPassword), name: 'Administrator', role: 'admin', active: true, mustChangePassword: true },
      { id: 2, username: 'store', passwordHash: await hashPassword(storeSetupPassword), name: 'Store User', role: 'store', active: true, mustChangePassword: true }
    ];
    for (const user of defaultUsers) {
      await dPut('users', user);
    }
    U = defaultUsers;
    const hint = document.getElementById('bootstrap-hint');
    if (hint) {
      hint.textContent = `One-time setup credentials — admin: ${adminSetupPassword} · store: ${storeSetupPassword}. Save these now and change each password after signing in.`;
      hint.style.display = 'block';
    }
  }
  
  // Initialize advanced feature modules
  initializeAdvancedModules();
}

// ── Initialize Advanced Feature Modules ──
function initializeAdvancedModules() {
  try {
    // Initialize Sentry (disabled by default until DSN is configured)
    if (typeof sentryIntegration !== 'undefined') {
      sentryIntegration.initialize({
        enabled: false,
        environment: 'development'
      });
      console.log('[Advanced] Sentry integration initialized');
    }
    
    // Initialize APM monitoring
    if (typeof apmMonitoring !== 'undefined') {
      apmMonitoring.initialize({
        sampleRate: 0.1,
        slowThreshold: 1000
      });
      console.log('[Advanced] APM monitoring initialized');
    }
    
    // Initialize user behavior analytics
    if (typeof userBehaviorAnalytics !== 'undefined') {
      userBehaviorAnalytics.initialize({
        anonymizeData: true,
        sessionTimeout: 30 * 60 * 1000
      });
      console.log('[Advanced] User behavior analytics initialized');
    }
    
    // Initialize dashboard integrations
    if (typeof dashboardIntegrations !== 'undefined') {
      dashboardIntegrations.initialize({
        bufferSize: 1000,
        flushInterval: 30000
      });
      console.log('[Advanced] Dashboard integrations initialized');
    }
    
    // Initialize predictive health monitoring
    if (typeof predictiveHealthMonitoring !== 'undefined') {
      predictiveHealthMonitoring.initialize({
        baselineWindow: 100,
        checkInterval: 60000
      });
      // Feed actual PerformanceMonitor measurements into predictive monitoring
      // continuously; do not rely on the Health Monitor page being open.
      if (typeof window !== 'undefined' && window.eventBus && !window.__storeTrackPredictiveMetricListener) {
        window.__storeTrackPredictiveMetricListener = window.eventBus.on('PERFORMANCE_METRIC', metric => {
          const metricName = String(metric?.name || '').trim();
          const metricValue = Number(metric?.value);
          if (!metricName || !Number.isFinite(metricValue) || typeof predictiveHealthMonitoring.recordMetric !== 'function') return;
          predictiveHealthMonitoring.recordMetric(metricName, metricValue, {
            source: 'performanceMonitor',
            type: String(metric?.type || 'custom'),
            unit: String(metric?.unit || '')
          });
        });
      }
      console.log('[Advanced] Predictive health monitoring initialized');
    }
    
    // Initialize automated issue detection
    if (typeof automatedIssueDetection !== 'undefined') {
      automatedIssueDetection.initialize({
        checkInterval: 30000
      });
      console.log('[Advanced] Automated issue detection initialized');
    }
    
    // Initialize self-healing
    if (typeof selfHealing !== 'undefined') {
      selfHealing.initialize({
        autoHealEnabled: true,
        maxRetries: 3
      });
      console.log('[Advanced] Self-healing mechanisms initialized');
    }
    
    // Initialize performance baseline tracking
    if (typeof performanceBaseline !== 'undefined') {
      performanceBaseline.initialize({
        sampleSize: 100,
        warmupPeriod: 5 * 60 * 1000
      });
      console.log('[Advanced] Performance baseline tracking initialized');
    }
    
    // Initialize query cache
    if (typeof queryCache !== 'undefined') {
      queryCache.initialize({
        maxSize: 1000,
        defaultTTL: 5 * 60 * 1000
      });
      console.log('[Advanced] Query cache initialized');
    }
    
    // Initialize background sync
    if (typeof backgroundSync !== 'undefined') {
      backgroundSync.initialize({
        maxConcurrentTasks: 3,
        retryAttempts: 3
      });
      console.log('[Advanced] Background sync initialized');
    }

    // Initialize the dashboard/widget feature modules after IndexedDB is ready.
    // Their constructors are intentionally safe to call more than once, while
    // this explicit startup hook guarantees the UI is rendered after loadAll().
    if (window.DashboardWidgets) {
      window.DashboardWidgets.init();
      console.log('[Advanced] Dashboard widgets initialized');
    }
    if (window.SupplierPerformanceTracking?.init) {
      window.SupplierPerformanceTracking.init().catch(error => console.error('[Advanced] Supplier tracking initialization failed:', error));
    }
    console.log('[Advanced] All modules initialized successfully');
  } catch (error) {
    console.error('[Advanced] Module initialization failed:', error);
  }
}

// ── Explicit BI consumption data contract ──
function biIsoDate(value) { return String(value || '').slice(0, 10); }
function biAddDays(date, days) { const d = new Date(`${biIsoDate(date)}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + Number(days || 0)); return d.toISOString().slice(0, 10); }
function biNumber(value) { const n = Number(value); return Number.isFinite(n) ? n : 0; }
function biNormalizeConsumption(row, source) {
  const partNo = String(row?.newPartNo || row?.partNo || '').trim();
  const date = biIsoDate(row?.replacementDate || row?.replacementDateTime || row?.date || row?.createdAt);
  const quantity = Math.max(0, biNumber(row?.quantity));
  return partNo && date ? { ...row, partNo, date, quantity, source, type: 'Replacement / Issue' } : null;
}
async function getBIConsumptionMetrics() {
  const today = biIsoDate(new Date().toISOString());
  const historical = typeof gAll === 'function' ? await gAll('component_historical_consumption') : [];
  const live = typeof gAll === 'function' ? await gAll('component_replacements') : [];
  const rows = [...(historical || []).map(row => biNormalizeConsumption(row, 'historical')), ...(live || []).map(row => biNormalizeConsumption(row, 'live'))].filter(Boolean);
  const windows = { 30: biAddDays(today, -29), 60: biAddDays(today, -59), 90: biAddDays(today, -89) };
  const inWindow = (row, start) => row.date >= start && row.date <= today;
  const byPart = new Map(), byStation = new Map(), byShift = new Map(), byDay = new Map();
  rows.forEach(row => {
    const part = byPart.get(row.partNo) || { partNo: row.partNo, total: 0, live: 0, historical: 0, last30: 0, last60: 0, last90: 0 };
    part.total += row.quantity; part[row.source] += row.quantity;
    if (inWindow(row, windows[30])) { part.last30 += row.quantity; }
    if (inWindow(row, windows[60])) { part.last60 += row.quantity; }
    if (inWindow(row, windows[90])) { part.last90 += row.quantity; }
    byPart.set(row.partNo, part);
    const station = String(row.stationNo || 'Unknown').trim() || 'Unknown'; byStation.set(station, biNumber(byStation.get(station)) + row.quantity);
    const shift = String(row.shift || 'Unknown').trim() || 'Unknown'; byShift.set(shift, biNumber(byShift.get(shift)) + row.quantity);
    byDay.set(row.date, biNumber(byDay.get(row.date)) + row.quantity);
  });
  const stockRows = typeof gAll === 'function' ? await gAll('component_stock') : [];
  const currentStock = new Map();
  (stockRows || []).forEach(row => { const part = String(row.partNo || '').trim(); if (part) { currentStock.set(part, biNumber(currentStock.get(part)) + biNumber(row.quantity)); } });
  const parts = typeof gAll === 'function' ? await gAll('component_parts') : [];
  const configs = typeof gAll === 'function' ? await gAll('component_part_forecast_configs') : [];
  const configByPart = new Map((configs || []).map(row => [String(row.partNo || '').trim(), row]));
  const critical = (parts || []).filter(part => part.active !== false && (part.criticalFlag || part.analytics?.criticalFlag || configByPart.get(String(part.partNo || '').trim())?.criticalFlag)).map(part => {
    const partNo = String(part.partNo || '').trim(), usage = byPart.get(partNo) || { total: 0, live: 0, historical: 0, last30: 0, last60: 0, last90: 0 };
    return { partNo, description: part.description || '', consumption: usage.total, liveConsumption: usage.live || 0, historicalConsumption: usage.historical || 0, currentStock: biNumber(currentStock.get(partNo)), minimumStock: biNumber(part.minimumStock), status: biNumber(currentStock.get(partNo)) <= biNumber(part.minimumStock) ? 'CRITICAL' : 'AWARENESS' };
  });
  const last90Total = [...byPart.values()].reduce((sum, row) => sum + row.last90, 0);
  return { today, total: rows.reduce((sum, row) => sum + row.quantity, 0), liveTotal: rows.filter(row => row.source === 'live').reduce((sum, row) => sum + row.quantity, 0), historicalTotal: rows.filter(row => row.source === 'historical').reduce((sum, row) => sum + row.quantity, 0), forecastUsageRate: last90Total / 90, byPart: [...byPart.values()].sort((a, b) => b.total - a.total), byStation: [...byStation.entries()].sort((a, b) => b[1] - a[1]), byShift: [...byShift.entries()].sort((a, b) => b[1] - a[1]), trend: Object.entries(byDay).sort(([a], [b]) => a.localeCompare(b)).map(([date, quantity]) => ({ date, quantity })), windows, critical, currentStockSource: 'component_stock', stockCalculation: 'current stock is independent from consumption history' };
}

// ── BI Dashboard Renderer ──
// Uses modules/businessIntelligence.js for value-based KPIs (needs
// materials[].unitCost, added to the material form) and
// modules/anomalyDetection.js for anomaly detection. Two KPIs still have no
// real data source in this app and stay honestly "—": supplier on-time rate
// isn't tracked on GRN records, and there's no persisted forecast-vs-actual
// history, so "Demand Prediction Accuracy" was replaced with "Inventory
// Turnover Ratio" and "Equipment Health Score" with "Total Inventory Value" --
// both genuinely computable from real data (see calculateInventoryTurnover/
// calculateCarryingCost in businessIntelligence.js).
async function renderBIDashboard() {
  if(window.truthfulAnalytics){
    const a=await window.truthfulAnalytics.calculate();
    const inv=document.getElementById('bi-inventory-analysis');
    if(inv){const shown=a.inventory.filter(x=>x.value>0||x.consumption>0).slice(0,8);inv.innerHTML=`<div data-style="display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin-bottom:8px"><b>Valuation: ${a.summary.valuationTracked?'₹'+a.summary.stockValue.toLocaleString('en-IN'):'Not tracked'}</b><b>Aged 90+ days: ${a.summary.staleItems}</b></div>${shown.length?`<div class="tw"><table><thead><tr><th>Item</th><th>ABC</th><th>XYZ</th><th>Age</th><th>Value</th></tr></thead><tbody>${shown.map(x=>`<tr><td>${sanitizeHTML(x.name||x.barcode||x.id)}</td><td>${x.class}</td><td>${x.variability}</td><td>${x.ageDays==null?'Not tracked':x.ageDays+'d'}</td><td>${x.value?'₹'+x.value.toLocaleString('en-IN'):'Not tracked'}</td></tr>`).join('')}</tbody></table></div>`:'<div data-style="color:var(--tx3)">No consumption or valuation records available.</div>'}`;}
    const ctl=document.getElementById('bi-control-analysis');
    if(ctl){const aging=a.pendingApprovals.slice(0,8);ctl.innerHTML=`<div data-style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:8px"><b>Pending: ${a.summary.pendingApprovals}</b><b>Quality issues: ${a.summary.qualityIssues}</b><b>Low stock: ${a.summary.lowStock}</b></div>${aging.length?`<div>Oldest pending approvals: ${aging.map(x=>`${sanitizeHTML(x.itemName||x.partNo||x.id)} (${x.ageDays==null?'age not tracked':x.ageDays+'d'})`).join(', ')}</div>`:'<div data-style="color:var(--tx3)">No pending approvals in recorded data.</div>'}${a.quality.length?`<div data-style="margin-top:8px;color:var(--warning)">Data quality examples: ${a.quality.slice(0,5).map(x=>sanitizeHTML(x.type+': '+x.record)).join(' · ')}</div>`:''}`;}
  }
  const nowMs=Date.now();
  const outRows=T.filter(t=>t.type==='OUT'&&t.status==='confirmed'&&Number.isFinite(Number(t.qty)));
  const recentOut=outRows.filter(t=>{const d=new Date(t.time||t.timestamp||0).getTime();return Number.isFinite(d)&&nowMs-d<=30*86400000;});
  const demandEl=document.getElementById('bi-demand-chart');
  if(demandEl){
    const total=recentOut.reduce((sum,t)=>sum+Number(t.qty),0);
    const daily=total/30;
    demandEl.innerHTML=recentOut.length
      ? `<div><b>${total.toLocaleString('en-IN')} units</b> recorded OUT in the last 30 days<br><span data-style="color:var(--tx3)">${recentOut.length} confirmed OUT transactions; average ${daily.toFixed(2)} units/day. Forecast-vs-actual accuracy is not tracked because forecast snapshots are not persisted.</span></div>`
      : '<div>No dated confirmed OUT transactions in the last 30 days. Forecast is not calculated from insufficient current data.</div>';
  }
  // KPI-1 + KPI-3: real value-based KPIs, now that materials can carry a
  // Unit Cost. costOfGoodsSold/totalValue both come from real OUT
  // transactions and real stock*unitCost -- no fabricated data.
  if (typeof businessIntelligence !== 'undefined') {
    await businessIntelligence.initialize({
      materials: M.map(m => ({ ...m, value: (m.stock || 0) * (m.unitCost || 0) })),
      transactions: T.map(t => {
        const mat = M.find(x => x.id === t.itemId);
        return { ...t, value: (Number(t.qty) || 0) * (mat?.unitCost || 0) };
      }),
      suppliers: SP,
      grn: GRN
    });
    const kpis = await businessIntelligence.calculateKPIs();

    document.getElementById('bi-kpi-1').textContent =
      kpis.inventoryTurnover && kpis.inventoryTurnover.ratio !== undefined ? kpis.inventoryTurnover.ratio : '—';
    document.getElementById('bi-kpi-3').textContent =
      kpis.carryingCost ? '₹' + Number(kpis.carryingCost.totalValue).toLocaleString('en-IN') : '—';
  } else {
    document.getElementById('bi-kpi-1').textContent = 'N/A';
    document.getElementById('bi-kpi-3').textContent = 'N/A';
  }

  // KPI-2 + anomaly list: real anomaly detection over each material's
  // recent OUT-transaction quantities (z-score / IQR / sudden-drop /
  // percent-change methods -- see modules/anomalyDetection.js).
  if (typeof anomalyDetection !== 'undefined') {
    anomalyDetection.clearAllAnomalies();

    const qtyByMaterial = {};
    T.filter(t => t.type === 'OUT' && t.status === 'confirmed' && t.itemId != null).forEach(t => {
      (qtyByMaterial[t.itemId] = qtyByMaterial[t.itemId] || []).push(Number(t.qty) || 0);
    });
    Object.entries(qtyByMaterial).forEach(([itemId, qtys]) => {
      if (qtys.length >= 3) {anomalyDetection.detectAnomalies(qtys, itemId);}
    });

    const anomalies = anomalyDetection.getAnomalySummary();
    document.getElementById('bi-kpi-2').textContent = anomalies.totalAnomalies;

    const list = document.getElementById('bi-anomaly-list');
    if (anomalies.totalAnomalies > 0) {
      const rows = Object.entries(anomalies.byMaterial)
        .filter(([, count]) => count > 0)
        .map(([itemId, count]) => {
          const mat = M.find(m => String(m.id) === String(itemId));
          return `<div data-style="padding:8px 4px;border-bottom:1px solid var(--bd)">${sanitizeHTML(String(mat ? mat.name : itemId))} — ${count} unusual issue-quantity event(s)</div>`;
        }).join('');
      list.innerHTML = rows || `<div data-style="padding:20px;text-align:center;color:var(--tx3)">No anomalies detected</div>`;
    } else {
      list.innerHTML = outRows.length < 3 ? '<div data-style="padding:20px;text-align:center;color:var(--tx3)">Not enough OUT history for anomaly analysis.</div>' : '<div data-style="padding:20px;text-align:center;color:var(--tx3)">No qualifying anomalies detected in the recorded OUT quantities.</div>';
    }
  } else {
    document.getElementById('bi-kpi-2').textContent = 'N/A';
  }

  const kpis = typeof businessIntelligence !== 'undefined' ? businessIntelligence.getKPIs() : {};
  const insights = [
    { label: 'Inventory turnover', value: kpis.inventoryTurnover?.ratio != null ? `${kpis.inventoryTurnover.ratio}x` : 'Not tracked', tone: 'var(--primary)' },
    { label: 'Carrying cost', value: kpis.carryingCost?.monthlyCost != null ? `₹${Number(kpis.carryingCost.monthlyCost).toLocaleString('en-IN')} / month` : 'Not tracked', tone: 'var(--warning)' },
    { label: 'Supplier on-time rate', value: kpis.supplierPerformance?.average != null ? `${kpis.supplierPerformance.average}%` : 'Not tracked', tone: 'var(--success)' }
  ];
  const insightList = document.getElementById('bi-insights-list');
  if (insightList) {
    insightList.innerHTML = insights.map(item => `<div data-style="display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-bottom:1px solid var(--bd)"><span>${item.label}</span><b data-style="color:${item.tone}">${item.value}</b></div>`).join('');
  }
  const trendList = document.getElementById('bi-trends-list');
  if (trendList) {
    const trendRows = Object.entries(kpis).filter(([, value]) => value && value.trend).map(([key, value]) => `<div data-style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--bd)"><span>${key.replace(/[A-Z]/g, m => ' '+m).replace(/^./, m => m.toUpperCase())}</span><span>${value.trend}</span></div>`);
    trendList.innerHTML = trendRows.length ? trendRows.join('') : '<div data-style="padding:12px;color:var(--tx3)">Trend history will appear after additional refreshes.</div>';
  }
  const optimizationList = document.getElementById('bi-optimization-list');
  if (optimizationList) {
    const low = lowItems().slice(0, 8);
    optimizationList.innerHTML = low.length ? low.map(m => `<div data-style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--bd)"><span>${sanitizeHTML(m.name)}</span><span data-style="color:var(--warning)">Reorder ${suggestedOrderQty(m)}</span></div>`).join('') : '<div data-style="padding:12px;color:var(--tx3)">No optimization actions required.</div>';
  }

  // KPI-4: reuse the same low-stock definition the reorder/alert flow
  // uses the target rule (stock < Low Alert), rather than
  // inventing a separate "critical issues" concept with its own data source.
  document.getElementById('bi-kpi-4').textContent = lowItems().length;


  // Maintenance list: no real equipment data source exists (see note above).
  const maintList = document.getElementById('bi-maintenance-list');
  if (maintList) {
    maintList.innerHTML = '<div data-style="padding:20px;text-align:center;color:var(--tx3)">Not available — no equipment sensor data source is configured</div>';
  }
}

// ── Health Monitor Renderer ──
let healthMonitorRefreshTimer=null;
function renderHealthMonitor() {
  if (typeof predictiveHealthMonitoring === 'undefined') {
    document.getElementById('health-status').textContent = 'N/A';
    return;
  }
  
  const healthStatus = predictiveHealthMonitoring.getHealthStatus();
  document.getElementById('health-status').textContent = healthStatus.overallStatus || 'Healthy';
  document.getElementById('health-status').style.color = 
    healthStatus.overallStatus === 'healthy' ? 'var(--success)' :
    healthStatus.overallStatus === 'warning' ? 'var(--warning)' : 'var(--danger)';
  
  // Get system health from APM if available
  if (typeof apmMonitoring !== 'undefined') {
    const sysHealth = apmMonitoring.getSystemHealth();
    document.getElementById('health-uptime').textContent = sysHealth.uptimeFormatted || '—';
    if (sysHealth.memory) {
      document.getElementById('health-memory').textContent = sysHealth.memory.usagePercent?.toFixed(1) + '%' || '—';
      if (typeof predictiveHealthMonitoring.recordMetric === 'function' && Number.isFinite(Number(sysHealth.memory.usagePercent))) predictiveHealthMonitoring.recordMetric('memory_usage_percent', Number(sysHealth.memory.usagePercent), { source: 'apm' });
    }
    if (typeof predictiveHealthMonitoring.recordMetric === 'function' && Number.isFinite(Number(sysHealth.uptime))) predictiveHealthMonitoring.recordMetric('uptime_seconds', Number(sysHealth.uptime), { source: 'apm' });
  }
  
  const metricsList = document.getElementById('health-metrics-list');
  if (metricsList) { const metrics = typeof apmMonitoring !== 'undefined' && apmMonitoring.getMetrics ? apmMonitoring.getMetrics() : (healthStatus.metrics || {}); const entries = Object.entries(metrics || {}); metricsList.innerHTML = entries.length ? entries.slice(0, 12).map(([key,value]) => `<div data-style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border)"><span>${sanitizeHTML(String(key))}</span><b>${sanitizeHTML(String(value))}</b></div>`).join('') : '<div data-style="padding:20px;text-align:center;color:var(--tx3)">No production metrics available yet.</div>'; }
  // Get active issues
  if (typeof automatedIssueDetection !== 'undefined') {
    const stats = automatedIssueDetection.getStatistics();
    document.getElementById('health-issues').textContent = stats.byStatus?.open || '0';
    
    const alertsList = document.getElementById('health-alerts-list');
    const alerts = automatedIssueDetection.getIssues({ status: 'open' }); const predictiveAlerts = typeof predictiveHealthMonitoring !== 'undefined' && predictiveHealthMonitoring.getAlerts ? predictiveHealthMonitoring.getAlerts() : []; const combinedAlerts = [...alerts, ...predictiveAlerts.map(a => ({...a, message: a.message || `${a.metricName || 'Metric'} exceeded predictive threshold`, detectedAt: a.createdAt || a.detectedAt}))];
    if (combinedAlerts.length > 0) {
      alertsList.innerHTML = combinedAlerts.slice(0, 5).map(a => 
        `<div data-style="padding:8px;border-bottom:1px solid var(--border)">
          <div data-style="font-weight:600;color:${a.severity === 'critical' ? 'var(--danger)' : 'var(--warning)'}">${a.message}</div>
          <div data-style="font-size:10px;color:var(--tx3)">${new Date(a.detectedAt).toLocaleString()}</div>
        </div>`
      ).join('');
    } else {
      alertsList.innerHTML = '<div data-style="padding:20px;text-align:center;color:var(--tx3)">No recent alerts</div>';
    }
  }
  
  // Render predictions
  if (typeof predictiveHealthMonitoring !== 'undefined') {
    const predictionsList = document.getElementById('health-predictions-list');
    const predictions = predictiveHealthMonitoring.getAllPredictions();
    if (predictions.length > 0) {
      predictionsList.innerHTML = predictions.slice(0, 5).map(p => 
        `<div data-style="padding:8px;border-bottom:1px solid var(--border)">
          <div data-style="font-weight:600">${p.metricName}</div>
          <div data-style="font-size:10px;color:var(--tx3)">Trend: ${p.slope > 0 ? 'Increasing' : 'Decreasing'}</div>
        </div>`
      ).join('');
    } else {
      predictionsList.innerHTML = '<div data-style="padding:20px;text-align:center;color:var(--tx3)">No predictive metrics collected yet.</div>';
    }
  }
}

// ── Save Analytics Configuration ──
function saveAnalyticsConfig() {
  const sentryEnabled = document.getElementById('cfg-sentry').value === 'enabled';
  const apmSampleRate = parseFloat(document.getElementById('cfg-apm-sample').value);
  const userAnalytics = document.getElementById('cfg-user-analytics').value;
  const selfHealEnabled = document.getElementById('cfg-self-heal').value === 'enabled';
  
  // Update Sentry
  if (typeof sentryIntegration !== 'undefined') {
    sentryIntegration.setEnabled(sentryEnabled);
  }
  
  // Update APM
  if (typeof apmMonitoring !== 'undefined') {
    apmMonitoring.setConfig({ sampleRate: apmSampleRate });
  }
  
  // Update user analytics
  if (typeof userBehaviorAnalytics !== 'undefined') {
    userBehaviorAnalytics.setConfig({ 
      anonymizeData: userAnalytics !== 'full' 
    });
  }
  
  // Update self-healing
  if (typeof selfHealing !== 'undefined') {
    selfHealing.setAutoHealEnabled(selfHealEnabled);
  }
  
  // Save to config
  const analyticsConfig = {
    sentry: sentryEnabled,
    apmSampleRate,
    userAnalytics,
    selfHeal: selfHealEnabled
  };
  
  CFG.analytics = analyticsConfig;
  dPut('config', CFG);
  
  showToast('Analytics settings saved successfully');
}

// ── QR Code helper ──
// Calls the main-process bridge (qrBridge exposed by preload.js).
// Returns a data-URL string, or an empty string if generation fails.
async function qrToDataURL(text, opts) {
  try {
    if (window.qrBridge) {
      const r = await window.qrBridge.toDataURL(text, opts || { margin: 1 });
      if (r && r.ok) {return r.dataURL;}
    }
  } catch (_) {}
  return '';
}

// ── JsBarcode safe wrapper ──
function safeJsBarcode(el, value, opts) {
  try {
    if (typeof JsBarcode === 'function') {
      JsBarcode(el, value, opts);
    }
  } catch (_) {}
}

// NOTE: getLblSettings, lblMmToPx, lblCodeHeightMm, escapeZpl, buildLabelZpl,
// createLabelElement, buildLabelPrintHtml now live only in modules/printing.js
// (loaded before this file) — removed the identical duplicate copies that
// used to be here.

// ── Toast ──
let _tt;
function toast(msg,type='ok'){
  const t=document.getElementById('toast');
  t.textContent=msg;
  // Normalize type strings: 'err' -> 'er', 'suc' -> 'ok'
  const normalizedType = type === 'err' ? 'er' : (type === 'suc' ? 'ok' : type);
  t.className='on '+(normalizedType==='ok'?'ok':normalizedType==='er'?'er':'inf');
  clearTimeout(_tt);
  _tt=setTimeout(()=>t.className='',3000);
}

// ── Authentication functions moved to modules/auth.js ──
// Variables: passwordChangeRequired, DEFAULT_CREDENTIALS
// Functions: isViewer, canMutate, canAdmin, markDefaultCredentialIfNeeded, applyRolePermissions
// Session timeout: sessionTimeoutTimer, SESSION_TIMEOUT_MS, resetSessionTimeout, initSessionTimeout
// Login/Logout: doLogin, doLogout

// ── Core Infrastructure Bootstrap (core/*.js) ──
// core/errorHandler.js calls window.showToast(msg, type) with type in
// {'critical','error','warning','info'} — bridge it to the app's real
// toast(msg, type) which expects {'ok','er','inf'}. Without this bridge,
// errorHandler silently does nothing when it tries to notify the user,
// because `if (window.showToast)` is false and it just skips.
window.showToast = function(msg, type) {
  const t = (type === 'error' || type === 'critical') ? 'er'
          : (type === 'warning' || type === 'info') ? 'inf'
          : 'ok';
  toast(msg, t);
};

if (window.errorHandler) {
  // Turns on window.onerror / unhandledrejection capture (setupGlobalErrorHandlers()),
  // which was defined but never activated because .initialize() was never called
  // anywhere in the app. This is the first time uncaught errors in this app get
  // logged anywhere instead of silently vanishing in the console.
  window.errorHandler.initialize({ userFeedback: true });
}

if (window.configManager) {
  // IMPORTANT: configManager.js already self-initializes with its own solid
  // built-in defaults (app, database, scanner, rfid, printing, backup, sync,
  // ui, performance) the moment core/configManager.js loads — see the bottom
  // of that file. Calling .initialize() again here would call
  // `this.defaults = JSON.parse(JSON.stringify(defaultConfig))`, which is a
  // full REPLACE, not a merge, and would silently wipe every one of those
  // built-in defaults out. So instead of re-initializing, we layer our two
  // extra values on top with .set(), which only touches the paths given and
  // leaves everything else configManager already set up alone.
  window.configManager.set('security.sessionTimeoutMs', 30 * 60 * 1000, false);
  window.configManager.set('security.passwordMinLength', 6, false);
}

if (window.stateManager) {
  window.stateManager.initialize({
    app: { bootedAt: new Date().toISOString() },
    dashboard: { materials: 0, transactions: 0, users: 0, lowStock: 0 }
  });
}

if (window.passwordPolicy) {
  // IMPORTANT: passwordPolicy.js's built-in defaults (min 8 chars, uppercase,
  // lowercase, number, AND special char required) are stricter than what this
  // app has ever enforced (passStrong(): 6+ chars, one letter, one number —
  // see below). Existing passwords could FAIL the stricter policy.
  // We do NOT flip enforcement to the stricter policy here — that would lock
  // people out with no warning. Instead we configure it to match what
  // passStrong() already requires, and use passwordPolicy only for the
  // things passStrong() doesn't do at all: common-password blocklist,
  // password history, and failed-login lockout (see doLogin()/saveMat-style
  // wiring in modules/auth.js). If you want to move to the stricter policy
  // later, change these four flags to `true` and roll out a forced
  // password-reset for existing users first.
  window.passwordPolicy.updatePolicy({
    minLength: 6,
    requireUppercase: false,
    requireLowercase: false,
    requireNumber: true,
    requireSpecial: false,
    maxFailedAttempts: 5,
    lockoutDuration: 15 * 60 * 1000
  });
}

if (window.sessionSecurity) {
  const timeoutMs = (window.configManager && window.configManager.get('security.sessionTimeoutMs')) || (30 * 60 * 1000);
  window.sessionSecurity.initialize({
    sessionTimeout: timeoutMs,
    warningTime: Math.min(60 * 1000, Math.floor(timeoutMs / 4)) // warn in the last 60s (or 1/4 of timeout if that's shorter)
  });
  // Real usage: when sessionSecurity's own warning timer fires (it runs
  // alongside the existing session-timeout timer in modules/auth.js, sharing
  // the same duration from configManager), show an actual toast the user can
  // act on. sessionSecurity never calls the real doLogout() itself — the
  // existing timer in modules/auth.js remains the single source of truth for
  // actually ending the session, so there's no risk of a double-logout race.
  if (window.eventBus) {
    window.eventBus.on('SESSION_WARNING', (data) => {
      toast('⚠ ' + (data && data.message ? data.message : 'Your session will expire soon') + ' — click anywhere to stay logged in', 'inf');
    });
  }
}

/**
 * Push the current in-memory counts (M, T, U, etc.) into stateManager so the
 * Diagnostics panel has a real, live snapshot rather than static placeholder
 * numbers. Called from updateDash() (real dashboard refresh path) and from
 * diagInit() itself.
 */
function syncAppStateSnapshot() {
  if (!window.stateManager) {return;}
  try {
    window.stateManager.set('dashboard', {
      materials: Array.isArray(M) ? M.length : 0,
      transactions: Array.isArray(T) ? T.length : 0,
      users: Array.isArray(U) ? U.length : 0,
      lowStock: Array.isArray(M) ? M.filter(m => m.active !== false && (Number(m.stock) === 0 || Number(m.stock) < Number(m.lowAlert || 0))).length : 0
    }, { silent: true });
  } catch (e) { /* non-fatal — diagnostics is best-effort */ }
}

// ── Theme Toggle ──
function toggleTheme() {
  const html = document.documentElement;
  const currentTheme = html.getAttribute('data-theme');
  const newTheme = currentTheme === 'light' ? 'dark' : 'light';
  html.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
  toast(`Switched to ${newTheme} theme`, 'ok');
}

function initTheme() {
  const savedTheme = localStorage.getItem('theme') || 'dark';
  document.documentElement.setAttribute('data-theme', savedTheme);
}

// ── Authentication functions moved to modules/auth.js ──
// Functions: isViewer, canMutate, canAdmin, markDefaultCredentialIfNeeded, applyRolePermissions, doLogin, doLogout

// ── Event Listener Helpers ──
const _eventListeners = [];
function _addEventListener(target, event, handler, options) {
  target.addEventListener(event, handler, options);
  _eventListeners.push({ target, event, handler });
}
function _removeAllEventListeners() {
  _eventListeners.forEach(({ target, event, handler }) => {
    target.removeEventListener(event, handler);
  });
  _eventListeners.length = 0;
}

// ── Audit ──
async function addAudit(action,details,module){
  const e={id:generateUUID(),time:new Date().toISOString(),user:cu?cu.username:'system',userName:cu?cu.name:'System',action,details,module:module||'SYSTEM'};
  A.push(e);
  await dPut('audit',e);
  if (window.AuditTrail?.log) {
    await window.AuditTrail.log({
      id: `enhanced-${e.id}`, userId: cu?.id || null, username: e.userName,
      action, resource: module || 'SYSTEM', resourceId: null,
      description: String(details || ''), category: 'application', severity: 'info',
      metadata: { legacyAuditId: e.id }
    });
  }
}

// ── Developer feature controls ──
const SIDE_MENU_GROUPS={main:'Main',stock:'Stock',reports:'Reports',masters:'Masters',shankMapping:'Shank Mapping',workflow:'Workflow',analytics:'Analytics',admin:'Admin'};
function isDeveloper(){return !!(cu&&cu.role==='developer');}
function getSidebarMenuItems(){
  return Array.from(document.querySelectorAll('.sb-nav .ng[data-menu-group] .ni')).map((item,index)=>{
    const group=item.closest('.ng')?.dataset.menuGroup||'main';
    if(!item.dataset.menuKey) item.dataset.menuKey=`${group}:${index}`;
    const copy=item.cloneNode(true);copy.querySelectorAll('svg,.ni-badge').forEach(el=>el.remove());
    return {element:item,key:item.dataset.menuKey,group,label:copy.textContent.replace(/\s+/g,' ').trim()||item.getAttribute('aria-label')||item.dataset.menuKey};
  });
}
function getEnabledSideMenuItems(){
  const items=getSidebarMenuItems();
  const saved=CFG?.enabledSideMenuItems;
  if(saved&&typeof saved==='object') return Object.fromEntries(items.map(item=>[item.key,saved[item.key]!==false]));
  const groups=CFG?.enabledSideMenuGroups&&typeof CFG.enabledSideMenuGroups==='object'?CFG.enabledSideMenuGroups:{};
  return Object.fromEntries(items.map(item=>[item.key,groups[item.group]!==false && (item.group!=='shankMapping'?true:CFG?.featureShankMapping===true)]));
}
function getAdminAllowedSideMenuItems(){
  const items=getSidebarMenuItems();
  const saved=CFG?.adminAllowedSideMenuItems;
  return Object.fromEntries(items.map(item=>[item.key,saved&&typeof saved==='object'?saved[item.key]!==false:true]));
}
function isSideMenuItemAllowed(key){
  if(isDeveloper()) return true;
  const items=getSidebarMenuItems();
  const visible=getEnabledSideMenuItems()[key]===true;
  return visible && (cu?.role!=='admin' || getAdminAllowedSideMenuItems()[key]===true);
}
function isShankMappingEnabled(){return getSidebarMenuItems().some(item=>item.group==='shankMapping'&&isSideMenuItemAllowed(item.key));}
function applyFeatureMenuVisibility(){
  const items=getSidebarMenuItems();
  const enabledItems=getEnabledSideMenuItems();
  const adminAllowedItems=getAdminAllowedSideMenuItems();
  const card=document.getElementById('developer-feature-card');
  items.forEach(item=>{item.element.style.display=(isSideMenuItemAllowed(item.key))?'':'none';});
  document.querySelectorAll('.ng[data-menu-group]').forEach(menu=>{const hasEnabled=items.some(item=>item.group===menu.dataset.menuGroup&&isSideMenuItemAllowed(item.key));menu.style.display=(hasEnabled||isDeveloper())?'':'none';});
  if(card){card.style.display=isDeveloper()?'':'none';}
  const controls=document.getElementById('developer-menu-items');
  if(controls){controls.className='developer-menu-permissions';controls.removeAttribute('data-style');controls.innerHTML=items.map(item=>`<div class="developer-menu-row"><span>${sanitizeHTML(item.label)}</span><label><input type="checkbox" data-menu-toggle="${item.key}" data-onchange="saveDeveloperMenuSelection()" ${enabledItems[item.key]===true?'checked':''} ${isDeveloper()?'':'disabled'} aria-label="Visible ${sanitizeHTML(item.label)}"></label><label><input type="checkbox" data-admin-menu-toggle="${item.key}" data-onchange="saveDeveloperMenuSelection()" ${adminAllowedItems[item.key]===true?'checked':''} ${isDeveloper()?'':'disabled'} aria-label="Admin Allow ${sanitizeHTML(item.label)}"></label></div>`).join('');}
  const active=document.querySelector('.ni.active')?.dataset.menuKey;
  if(active&&!isSideMenuItemAllowed(active)) nav('dash');
}
async function saveDeveloperMenuSelection(){
  if(!isDeveloper()){toast('Developer access required','er');applyFeatureMenuVisibility();return;}
  const enabledSideMenuItems=getEnabledSideMenuItems();
  const adminAllowedSideMenuItems=getAdminAllowedSideMenuItems();
  document.querySelectorAll('[data-menu-toggle]').forEach(checkbox=>{enabledSideMenuItems[checkbox.dataset.menuToggle]=checkbox.checked;});
  document.querySelectorAll('[data-admin-menu-toggle]').forEach(checkbox=>{adminAllowedSideMenuItems[checkbox.dataset.adminMenuToggle]=checkbox.checked;});
  CFG={...(CFG||{}),id:1,enabledSideMenuItems,adminAllowedSideMenuItems,featureShankMapping:isShankMappingEnabled()};
  await dPut('config',CFG);
  applyFeatureMenuVisibility();
  addAudit('FEATURE','Updated individual side-menu access','SYSTEM');
  toast('Individual side-menu selections saved for all users','ok');
}

function helpProfileForRole(role){
  const profiles={
    developer:{label:'Developer',summary:'Set the approved menu and role capabilities first; verify backups and diagnostics without bypassing application guards.'},
    admin:{label:'Administrator',summary:'Start with approvals and stock exceptions, then review reports, users, and backups. Available actions still follow the configured permissions.'},
    store:{label:'Store Person',summary:'Receive and issue stock with the right references, attach supporting documents when useful, and check approval status before treating a request as a completed movement.'},
    maintenance:{label:'Maintenance Officer',summary:'Search the required part, submit issue requests, and record replacement, repair, or return details against the correct work.'},
    auditor:{label:'Auditor',summary:'Use reports, transaction history, and audit evidence for review. Corrections are linked entries; never erase or rewrite the original ledger record.'},
    viewer:{label:'Viewer',summary:'Use only the screens available to your account. If a task or action is unavailable, ask an Administrator to review your access.'}
  };
  const key=String(role||'viewer').toLowerCase();
  return {...(profiles[key]||profiles.viewer),role:profiles[key]?key:'viewer'};
}
function renderRoleHelp(){
  const profile=helpProfileForRole(cu?.role);
  const title=document.getElementById('help-role-title');
  const summary=document.getElementById('help-role-summary');
  if(title)title.textContent=`${profile.label} quick start`;
  if(summary)summary.textContent=profile.summary;
  document.querySelectorAll('[data-help-roles]').forEach(card=>{
    const roles=String(card.dataset.helpRoles||'').split(',').map(role=>role.trim().toLowerCase()).filter(Boolean);
    card.hidden=!roles.includes(profile.role);
  });
}

// ── Nav ──
function nav(id, options = {}){
  // The permissions matrix restricts Indent Request to Developer/Admin/Store/Maintenance.
  if (id === 'indent' && typeof canRoleAction === 'function' && !canRoleAction('indentRequest')) { return; }
  const targetMenu=getSidebarMenuItems().find(item=>id==='cfg'?item.element.dataset.menuItem==='settings':item.element.getAttribute('data-onclick')?.includes(`nav('${id}')`));
  if(targetMenu&&!isSideMenuItemAllowed(targetMenu.key)){toast(`${targetMenu.label} is not allowed for this user`,'inf');return;}
  if(['component','bi-dashboard'].includes(id)&&!isShankMappingEnabled()&&!(id==='component'&&options?.bypassFeatureGate===true)){toast('This feature is disabled by the developer','inf');return;}
  document.querySelectorAll('.sec').forEach(s=>s.classList.remove('active'));
  document.querySelectorAll('.ni').forEach(n=>n.classList.remove('active'));
  document.getElementById('s-'+id)?.classList.add('active');
  document.getElementById('n-'+id)?.classList.add('active');
  const T2={dash:'Dashboard',in:'Material IN',out:'Material OUT',master:'Material Master',stock:'Current Stock',adjust:'Stock Adjustment',hist:'IN/OUT History',reports:'Date-wise Reports',low:'Low Stock Report',labels:'Barcode Labels',supp:'Supplier Master',dept:'Department Master','machine-spare':'Machine Spare Parts',approv:'Approvals',users:'User Management',audit:'Audit Trail',diag:'System Diagnostics',cfg:'Settings',scanner:'Scanner Configuration',closing:'Month-End Closing Stock',indent:'Indent Request',returns:'Material Returns',cyclecount:'Cycle Count',consume:'Consumption Report',reorder:'Reorder / PO',grn:'Goods Receipt Note',monthly:'Monthly Summary',locations:'Bin Locations',help:'Help & Training',pm:'Preventive Maintenance','archive-browse':'Archived Records','slowmoving':'Slow-Moving / Dead Stock','bi-dashboard':'BI Dashboard','ai-assistants':'AI Assistants','supplier-performance':'Supplier Performance','health-monitor':'Health Monitor'};
  document.getElementById('pg-title').textContent=T2[id]||id;
  const fns={dash:updateDash,in:renderInLog,master:()=>{popCat('flt-m-cat');renderMaster();},stock:()=>{popCat('flt-stk-cat');renderStock();},hist:renderHist,low:renderLow,adjust:loadAdjSel,approv:renderApprov,users:renderUsers,audit:()=>{popAudUsr();renderAudit();},diag:diagInit,cfg:()=>{refreshStats();refreshCentralSyncPanel();},labels:renderLblSearch,supp:renderSupp,dept:renderDept,locations:()=>{renderLocs();renderLocStock();renderMovHist();popLocSelects();},reports:initReportDates,indent:()=>{popIndentSelects();renderIndents();},returns:()=>{popReturnSelects();renderReturns();},cyclecount:()=>{popCCCat();renderCCItems();renderCCHist();},'machine-spare':mspInit,consume:()=>{popConCat();renderConsumption();},reorder:()=>{renderStockForecast();renderReorder();},grn:()=>{popGRNFilters();renderGRN();},monthly:initMonthlySummary,closing:populateClosingMonths,scanner:scInit,pm:pmRenderList,'archive-browse':renderArchiveBrowse,'slowmoving':renderSlowMoving,'bi-dashboard':()=>{renderBIDashboard();refreshIntegratedIntelligence();},'ai-assistants':()=>{window.aiAssistantInit?.();},'supplier-performance':renderSupplierPerformanceDashboard,'health-monitor':renderHealthMonitor,help:renderRoleHelp};
  if(id==='health-monitor'){if(healthMonitorRefreshTimer)clearInterval(healthMonitorRefreshTimer);healthMonitorRefreshTimer=setInterval(()=>{if(document.getElementById('s-health-monitor')?.classList.contains('active'))renderHealthMonitor();else{clearInterval(healthMonitorRefreshTimer);healthMonitorRefreshTimer=null;}},15000);}else if(healthMonitorRefreshTimer){clearInterval(healthMonitorRefreshTimer);healthMonitorRefreshTimer=null;}
  fns[id]&&fns[id]();
  popSuppSel();popDeptSel();
  if(id==='in'){setTimeout(()=>document.getElementById('in-bc').focus(),100);updateMatScannerStatusUI('in');}
  if(id==='out'){setTimeout(()=>document.getElementById('out-bc').focus(),100);renderLiveFeed();updateMatScannerStatusUI('out');}
}

function handleSlowMovingNavKey(event){if(!event||!['Enter',' '].includes(event.key))return;event.preventDefault?.();nav('slowmoving');}

// ── Sidebar Toggle ──
function toggleSidebar(){
  const sb=document.querySelector('.sb');
  const toggleBtn=document.querySelector('.sb-toggle');
  sb.classList.toggle('collapsed');
  if(sb.classList.contains('collapsed')){
    toggleBtn.textContent='▶';
  }else{
    toggleBtn.textContent='◀';
  }
}

// ── Navigation Scroll ──
function scrollNav(btn, direction){
  const ng = btn.parentElement;
  const scrollAmount = 100;
  if(direction === -1){
    ng.scrollTop -= scrollAmount;
  }else{
    ng.scrollTop += scrollAmount;
  }
}
function localDateKey(value=new Date()) {
  const d=value instanceof Date?new Date(value.getTime()):new Date(value);
  if(!Number.isFinite(d.getTime())) return '';
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function localDateRangeBounds(from,to) {
  let fromMs=null, untilMs=null;
  if(from){const start=new Date(`${from}T00:00:00`);if(!Number.isFinite(start.getTime()))return null;fromMs=start.getTime();}
  if(to){const end=new Date(`${to}T00:00:00`);if(!Number.isFinite(end.getTime()))return null;end.setDate(end.getDate()+1);untilMs=end.getTime();}
  if(fromMs!==null&&untilMs!==null&&fromMs>=untilMs)return null;
  return {fromMs,untilMs};
}
function isWithinLocalDateRange(value,from,to) {
  const ms=Date.parse(value||'');if(!Number.isFinite(ms))return false;
  const bounds=localDateRangeBounds(from,to);if(!bounds)return false;
  return (bounds.fromMs===null||ms>=bounds.fromMs)&&(bounds.untilMs===null||ms<bounds.untilMs);
}
function reportExportRows(type,transactions) {
  const tx=(Array.isArray(transactions)?transactions:[]).filter(t=>t&&typeof t==='object'&&Number.isFinite(Date.parse(t.time||'')));
  const qty=t=>Number(t.qty)||0;
  if(type==='in')return [['DateTime','Barcode','Item','Qty','Supplier','PO','Invoice','By'],...tx.filter(t=>t.type==='IN').map(t=>[new Date(t.time).toLocaleString(),t.barcode||'',t.itemName||'',qty(t),t.supplierName||'',t.po||'',t.invoice||'',t.userName||''])];
  if(type==='out')return [['DateTime','Barcode','Item','Qty','Department','Person','Job No.','By'],...tx.filter(t=>t.type==='OUT').map(t=>[new Date(t.time).toLocaleString(),t.barcode||'',t.itemName||'',qty(t),t.deptName||'',t.person||'',t.job||'',t.userName||''])];
  if(type==='item'){
    const by=new Map();tx.forEach(t=>{if(!['IN','OUT'].includes(t.type))return;const key=String(t.barcode||'');if(!by.has(key))by.set(key,{name:t.itemName||'',unit:t.unit||'',inQ:0,outQ:0,count:0});const v=by.get(key);v[t.type==='IN'?'inQ':'outQ']+=qty(t);v.count++;});
    return [['Barcode','Item','Unit','Total IN','Total OUT','Net','Txns'],...Array.from(by,([barcode,v])=>[barcode,v.name,v.unit,v.inQ,v.outQ,v.inQ-v.outQ,v.count])];
  }
  if(type==='dept'||type==='supp'){
    const kind=type==='dept'?'OUT':'IN',key=type==='dept'?'deptName':'supplierName',label=type==='dept'?'Department':'Supplier';
    const by=new Map();tx.filter(t=>t.type===kind).forEach(t=>{const name=String(t[key]||'Unknown');const v=by.get(name)||{qty:0,count:0};v.qty+=qty(t);v.count++;by.set(name,v);});
    return [[label,`Total ${kind} Qty`,'Transactions'],...Array.from(by,([name,v])=>[name,v.qty,v.count])];
  }
  const by=new Map();tx.forEach(t=>{if(!['IN','OUT'].includes(t.type))return;const date=localDateKey(new Date(t.time));if(!date)return;const v=by.get(date)||{inN:0,inQ:0,outN:0,outQ:0};if(t.type==='IN'){v.inN++;v.inQ+=qty(t);}else{v.outN++;v.outQ+=qty(t);}by.set(date,v);});
  return [['Date','IN Txns','IN Qty','OUT Txns','OUT Qty'],...Array.from(by,([date,v])=>[date,v.inN,v.inQ,v.outN,v.outQ]).sort((a,b)=>String(b[0]).localeCompare(String(a[0])))];
}
function populateReportFilters(){
  const fill=(id,placeholder,values,current='')=>{const el=document.getElementById(id);if(!el)return;const unique=[...new Set(values.map(v=>String(v||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b));el.innerHTML=`<option value="">${placeholder}</option>`+unique.map(v=>`<option value="${sanitizeHTML(v)}">${sanitizeHTML(v)}</option>`).join('');el.value=current&&unique.includes(current)?current:'';};
  const sites=T.map(t=>t.site||t.location||t.binLocation||t.bin||M.find(m=>String(m.id)===String(t.itemId||''))?.site||M.find(m=>String(m.id)===String(t.itemId||''))?.location);
  fill('rp-site','All sites / locations',sites,document.getElementById('rp-site')?.value||'');
  fill('rp-part','All parts',M.map(m=>m.partNo||m.barcode||m.name),document.getElementById('rp-part')?.value||'');
  fill('rp-supp','All suppliers',SP.map(s=>s.name),document.getElementById('rp-supp')?.value||'');
}
function filterReportTransactions(transactions,from,to,site='',part='',supplier='',materials=[]){
  return (Array.isArray(transactions)?transactions:[]).filter(t=>{
    if(!t||typeof t!=='object'||t.status==='pending'||!isWithinLocalDateRange(t.time,from,to))return false;
    const material=(Array.isArray(materials)?materials:[]).find(m=>String(m.id)===String(t.itemId||t.materialId||''))||{};
    const txSite=String(t.site||t.location||t.binLocation||t.bin||material.site||material.location||'');
    const partValues=[t.barcode,t.partNo,material.barcode,material.partNo,material.name].map(v=>String(v||''));
    const txSupplier=String(t.supplierName||material.supplierName||'');
    return (!site||txSite===site)&&(!part||partValues.includes(String(part)))&&(!supplier||txSupplier===supplier);
  });
}
function initReportDates(){const t=localDateKey(new Date());document.getElementById('rp-from').value=t;document.getElementById('rp-to').value=t;populateReportFilters();}
function swTab(el,target){
  el.parentElement.querySelectorAll('.tab').forEach(t=>t.classList.remove('on'));el.classList.add('on');
  ['appr-pend','appr-appr','appr-rej'].forEach(id=>{const d=document.getElementById(id);if(d){d.style.display='none';}});
  document.getElementById(target).style.display='block';
}

// ── Dropdowns ──
function popSuppSel(){const s=document.getElementById('in-supp');const cur=s.value;s.innerHTML='<option value="">— Select Supplier —</option>';SP.forEach(x=>s.innerHTML+=`<option value="${sanitizeHTML(String(x.id))}">${sanitizeHTML(String(x.name||""))}</option>`);s.value=cur;}
function popDeptSel(){const s=document.getElementById('out-dept');const cur=s.value;s.innerHTML='<option value="">— Select Dept —</option>';DP.forEach(d=>s.innerHTML+=`<option value="${sanitizeHTML(String(d.id))}">${sanitizeHTML(String(d.name||''))}</option>`);s.value=cur;}
function popCat(id){const cats=[...new Set(M.map(m=>m.category))].sort();const s=document.getElementById(id);const cur=s.value;s.innerHTML='<option value="">All Categories</option>';cats.forEach(c=>s.innerHTML+=`<option value="${c}">${c}</option>`);s.value=cur;}
function popAudUsr(){const s=document.getElementById('flt-aud-us');const cur=s.value;s.innerHTML='<option value="all">All Users</option>';[...new Set(A.map(a=>a.user))].sort().forEach(u=>s.innerHTML+=`<option value="${u}">${u}</option>`);s.value=cur;}

// ── Photo ──
let photoD=null;
function handlePhoto(e){const f=e.target.files[0];if(!f){return;}const r=new FileReader();r.onload=ev=>{photoD=ev.target.result;const p=document.getElementById('m-ph-prev');p.innerHTML='';const img=document.createElement('img');img.src=photoD;img.className='ph-thumb';img.onclick=()=>showPh(photoD);p.appendChild(img);document.getElementById('m-ph-clr').style.display='';};r.readAsDataURL(f);}
function clrPhoto(){photoD=null;document.getElementById('m-ph-prev').innerHTML='📷';document.getElementById('m-ph-prev').className='ph-ph';document.getElementById('m-ph-clr').style.display='none';document.getElementById('m-ph-inp').value='';}
function showPh(src){document.getElementById('ph-ov-img').src=src;document.getElementById('ph-ov').classList.add('on');}

// ── DB Lock / Password Protect ──
let dbUnlocked=false;
let dbLockTimer=null;
let dbPendingAction=null;

function dbLockedAction(action){
  if(dbUnlocked){runDbAction(action);return;}
  dbPendingAction=action;
  const titles={refreshStats:'↺ Refresh Stats',restoreJson:'⬆ Restore JSON Backup',clearAllData:'🗑 Clear All Data'};
  document.getElementById('dblock-title').textContent='🔒 '+(titles[action]||'Verify Password');
  document.getElementById('dblock-pw').value='';
  document.getElementById('dblock-err').style.display='none';
  document.getElementById('dblock-ov').classList.add('on');
  setTimeout(()=>document.getElementById('dblock-pw').focus(),120);
}
function openDbLock(){
  if(dbUnlocked){
    dbUnlocked=false;clearTimeout(dbLockTimer);
    document.getElementById('db-lock-badge').textContent='🔒 Locked';
    document.getElementById('db-lock-badge').style.background='var(--rdb)';
    document.getElementById('db-lock-badge').style.color='var(--rd)';
    toast('Database actions locked','inf');return;
  }
  dbLockedAction('refreshStats');
}
function closeDbLock(){document.getElementById('dblock-ov').classList.remove('on');dbPendingAction=null;}
async function verifyDbLock(){
  const pw=document.getElementById('dblock-pw').value;
  let valid=false;
  if(cu){
    if(cu.passwordHash) {valid=await verifyPassword(pw,cu.passwordHash);}
    else if(cu.password) {valid=_safeCompare(pw,cu.password);}
  }
  // Admin override: any admin user's password also accepted
  if(!valid&&cu?.role==='admin'){
    for(const u of U.filter(x=>x.role==='admin')){
      if(u.passwordHash){if(await verifyPassword(pw,u.passwordHash)){valid=true;break;}}
      else if(u.password&&_safeCompare(pw,u.password)){valid=true;break;}
    }
  }
  if(!valid){document.getElementById('dblock-err').style.display='';document.getElementById('dblock-pw').value='';document.getElementById('dblock-pw').focus();return;}
  document.getElementById('dblock-err').style.display='none';
  document.getElementById('dblock-ov').classList.remove('on');
  dbUnlocked=true;
  document.getElementById('db-lock-badge').textContent='🔓 Unlocked';
  document.getElementById('db-lock-badge').style.background='var(--gnb)';
  document.getElementById('db-lock-badge').style.color='var(--gn)';
  clearTimeout(dbLockTimer);
  dbLockTimer=setTimeout(()=>{
    dbUnlocked=false;
    const b=document.getElementById('db-lock-badge');
    if(b){b.textContent='🔒 Locked';b.style.background='var(--rdb)';b.style.color='var(--rd)';}
    toast('Database lock auto-locked after 2 minutes','inf');
  },120000);
  if(dbPendingAction){const a=dbPendingAction;dbPendingAction=null;runDbAction(a);}
}
function runDbAction(action){
  if(action==='refreshStats'){refreshStats();toast('Stats refreshed');}
  else if(action==='restoreJson'){document.getElementById('restore-json-inp').click();}
  else if(action==='clearAllData'){clearAllData();}
}

// ── Extra Specifications ──
let specRowCount=0;
function addSpecRow(title='',value=''){
  const c=document.getElementById('specs-container');
  const em=document.getElementById('specs-empty');
  if(em){em.style.display='none';}
  const id='spec-row-'+(++specRowCount);
  const div=document.createElement('div');
  div.id=id;
  applyCssText(div,'display:flex;gap:6px;align-items:center');
  div.innerHTML=`<input class="fi" placeholder="Title (e.g. Material Grade, Thread Size...)" data-style="flex:1.2" value="${title.replace(/"/g,'&quot;')}" data-spec-title>
<input class="fi" placeholder="Value (e.g. IS 2062, M12 x 1.75)" data-style="flex:2" value="${value.replace(/"/g,'&quot;')}" data-spec-value>
<button class="btn btn-d" data-style="padding:3px 7px;flex-shrink:0" data-onclick="removeSpecRow('${id}')">✕</button>`;
  c.appendChild(div);
}
function removeSpecRow(id){
  const el=document.getElementById(id);
  if(el){el.remove();}
  const c=document.getElementById('specs-container');
  if(!c.children.length){const em=document.getElementById('specs-empty');if(em){em.style.display='';}}
}
function getSpecsData(){
  const rows=document.querySelectorAll('#specs-container [data-spec-title]');
  const result=[];
  rows.forEach(ti=>{
    const val=ti.parentElement.querySelector('[data-spec-value]');
    const t=(ti.value||'').trim();const v=(val?val.value:'').trim();
    if(t||v){result.push({title:t,value:v});}
  });
  return result;
}
function loadSpecsData(specs){
  const c=document.getElementById('specs-container');
  c.innerHTML='';specRowCount=0;
  const em=document.getElementById('specs-empty');
  if(!specs||!specs.length){if(em){em.style.display='';}return;}
  if(em){em.style.display='none';}
  specs.forEach(s=>addSpecRow(s.title||'',s.value||''));
}

// ── Material Master ──
function cleanBarcodePrefix(v){return String(v||'MAT').trim().toUpperCase().replace(/[^A-Z0-9]/g,'')||'MAT';}
function passStrong(p){
  const s=String(p||'');
  const basic=s.length>=6&&/[A-Za-z]/.test(s)&&/\d/.test(s);
  if(!basic){return false;}
  // Additive check via modules/passwordPolicy.js: block obviously common
  // passwords (e.g. 'password1', 'welcome123') even though they'd pass the
  // basic length/letter/number rule. Does NOT add new length/case/special
  // requirements — see the passwordPolicy.updatePolicy() call in app.js's
  // bootstrap for why those stay off.
  if(window.passwordPolicy&&window.passwordPolicy.isCommonPassword&&window.passwordPolicy.isCommonPassword(s)){return false;}
  return true;
}
// Some password dialogs are dispatched through window-level handlers. Expose
// the validator explicitly so forced changes and admin resets never resolve an
// undefined global even when their caller is not in this script's lexical scope.
window.passStrong=passStrong;
function nextMatBarcode(){
  const prefix=cleanBarcodePrefix(CFG.barcodePrefix||'MAT');
  const re=new RegExp('^'+prefix.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'0*(\\d+)$','i');
  let max=0;
  M.forEach(m=>{const n=parseInt(String(m.barcode||'').match(re)?.[1]||'0', 10);if(n>max){max=n;}});
  return prefix+String(max+1).padStart(4,'0');
}
function previewMatBarcode(){
  const eid=document.getElementById('m-eid').value;
  const bc=document.getElementById('m-bc');
  if(!eid&&document.getElementById('m-nm').value.trim()){bc.value=nextMatBarcode();}
}
async function saveMat(){
  const nm=document.getElementById('m-nm').value.trim();
  const lowAlertText=document.getElementById('m-low').value.trim();
  const lowAlertValue=lowAlertText===''?10:Number(lowAlertText);
  if(!Number.isFinite(lowAlertValue)||lowAlertValue<0){toast('Low Stock Alert must be zero or greater','er');return;}
  const eid=document.getElementById('m-eid').value;
  const bc=eid?document.getElementById('m-bc').value.trim():nextMatBarcode();
  if(!nm){toast('Name is required!','er');return;}
  // modules/validation.js — real field-level validation (barcode format + numeric fields)
  if(window.Validation){
    const bcCheck=window.Validation.validateField(bc,'barcode');
    if(!bcCheck.valid){toast(bcCheck.message,'er');return;}
    for(const [fid,rule,label] of [['m-stk','positiveNumber','Opening Stock'],['m-low','positiveNumber','Low Stock Alert'],['m-cost','positiveNumber','Unit Cost']]){
      const val=document.getElementById(fid).value;
      if(val!==''){
        const chk=window.Validation.validateField(val,rule);
        if(!chk.valid){toast(label+': '+chk.message,'er');return;}
      }
    }
  }
  const old=eid?M.find(m=>m.id==eid):null;
  const duplicateName=M.find(m=>m.name.toLowerCase()===nm.toLowerCase()&&(!eid||m.id!=eid));
  if(duplicateName&&!confirm('A material with this name already exists. Save anyway?')){return;}
  if(M.find(m=>m.barcode===bc&&(!eid||m.id!=eid))){toast('Barcode already exists!','er');return;}
  const partNo=document.getElementById('m-hsn').value.trim();
  const hasDuplicatePartNo=window.PartNumberUtils?.hasDuplicatePartNo
    ? window.PartNumberUtils.hasDuplicatePartNo(partNo,M,eid)
    : Boolean(partNo&&M.some(m=>String(m.hsn||'').trim().toLowerCase()===partNo.toLowerCase()&&(!eid||m.id!=eid)));
  if(hasDuplicatePartNo){toast('Part No. already exists! Duplicate Part No. is not allowed.','er');return;}
  const binLocationText=(document.getElementById('m-binloc')?.value||'').trim();
  const binLoc=LOCS.find(l=>String(l.id)===binLocationText||String(locCode(l)).trim().toLowerCase()===binLocationText.toLowerCase());
  if(binLocationText&&!binLoc){toast('Select or enter an existing Bin Location. Create the location first if it is not listed.','er');return;}
  const binLocationId=binLoc?binLoc.id:0;
  const location=(document.getElementById('m-loc')?.value||'').trim()||(binLoc?locCode(binLoc):'');
  const obj={barcode:bc,name:nm,category:document.getElementById('m-cat').value||'General',unit:document.getElementById('m-unit').value,stock:parseInt(document.getElementById('m-stk').value, 10)||0,lowAlert:lowAlertValue,reorderQty:old?.reorderQty??0,unitCost:parseFloat(document.getElementById('m-cost').value)||0,hsn:partNo,location,binLocationId,photo:photoD||old?.photo||null,specs:getSpecsData(),active:old?.active!==false,createdAt:old?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};
  document.getElementById('m-bc').value=bc;
  if(eid){obj.id=old?old.id:eid;}
  await dPut('materials',obj);M=await gAll('materials');
  if(eid&&old){
    const fields=['barcode','name','category','unit','stock','lowAlert','unitCost','hsn','location','binLocationId','active'];
    const changes=fields.filter(f=>String(old[f]??'')!==String(obj[f]??'')).map(f=>`${f}: ${old[f]??'-'} -> ${obj[f]??'-'}`);
    addAudit('EDIT',`Edited material: ${nm} [${bc}]${changes.length?' | '+changes.join('; '):' | no field changes'}`,'MATERIAL');
  }else {addAudit('CREATE','Created material: '+nm+' ['+bc+']','MATERIAL');}
  if(window.appLogger){window.appLogger.info(eid?'Material updated':'Material created',{barcode:bc,name:nm});}
  if(window.eventBus){window.eventBus.emit('material:changed',{action:eid?'update':'create',barcode:bc,name:nm});}
  syncAppStateSnapshot();
  clrMatForm();renderMaster();updateBadges();
  toast(eid?'Material updated!':'"'+nm+'" added!');
}
function _editMatCore(id){
  const m=M.find(x=>x.id===id);if(!m){return;}
  document.getElementById('m-eid').value=id;document.getElementById('m-bc').value=m.barcode;document.getElementById('m-nm').value=m.name;document.getElementById('m-cat').value=m.category;document.getElementById('m-unit').value=m.unit;document.getElementById('m-stk').value=m.stock;document.getElementById('m-low').value=m.lowAlert;document.getElementById('m-cost').value=m.unitCost||'';document.getElementById('m-hsn').value=m.hsn||'';document.getElementById('m-loc').value=m.location||'';
  if(m.photo){photoD=m.photo;const p=document.getElementById('m-ph-prev');p.innerHTML='';const img=document.createElement('img');img.src=m.photo;img.className='ph-thumb';img.onclick=()=>showPh(m.photo);p.appendChild(img);document.getElementById('m-ph-clr').style.display='';}
  loadSpecsData(m.specs||[]);nav('master');toast('Editing: '+m.name,'inf');
}
async function toggleMat(id){const m=M.find(x=>x.id===id);if(!m){return;}m.active=!m.active;await dPut('materials',m);M=await gAll('materials');addAudit(m.active?'ACTIVATE':'DEACTIVATE',(m.active?'Activated':'Deactivated')+': '+m.name,'MATERIAL');renderMaster();toast('Status updated');}
async function delMat(id){if(!confirm('Delete?')){return;}const m=M.find(x=>x.id===id);await dDel('materials',id);M=M.filter(x=>x.id!==id);addAudit('DELETE','Deleted: '+(m?m.name:''),'MATERIAL');if(window.appLogger){window.appLogger.warn('Material deleted',{name:m?m.name:'',id});}if(window.eventBus){window.eventBus.emit('material:changed',{action:'delete',name:m?m.name:''});}syncAppStateSnapshot();renderMaster();updateBadges();toast('Deleted');}
function clrMatForm(){document.getElementById('m-eid').value='';loadSpecsData([]);['m-bc','m-nm','m-cat','m-stk','m-low','m-cost','m-hsn','m-loc'].forEach(id=>document.getElementById(id).value='');document.getElementById('m-unit').selectedIndex=0;const bin=document.getElementById('m-binloc');if(bin){bin.value='';}clrPhoto();}
function renderMaster(){
  const q=sanitizeText(document.getElementById('srch-m').value||'').toLowerCase();
  const cat=document.getElementById('flt-m-cat').value;
  const stat=document.getElementById('flt-m-stat').value;
  const f=M.filter(m=>{let ok=(m.name.toLowerCase().includes(q)||m.barcode.toLowerCase().includes(q));if(cat){ok=ok&&m.category===cat;}if(stat==='active'){ok=ok&&m.active!==false;}if(stat==='inactive'){ok=ok&&m.active===false;}return ok;});
  document.getElementById('m-cnt').textContent=f.length+' items';
  const tb=document.getElementById('m-body');
  if(!f.length){const selectAll=document.getElementById('m-select-all');if(selectAll){selectAll.checked=false;}tb.innerHTML='<tr><td colspan="11" data-style="text-align:center;color:var(--tx3);padding:16px">No materials</td></tr>';updateSelectedMaterials();return;}
  tb.innerHTML=f.map(m=>{
    const pct=Math.min(100,Math.round((m.stock/Math.max(m.lowAlert*3,1))*100));
    const col=m.stock<=0?'var(--rd)':m.stock<m.lowAlert?'var(--am)':'var(--gn)';
    const ph=m.photo?`<img data-src="${m.photo}" class="lazy-load ph-thumb" data-style="background:var(--bg3)" data-onclick="showPh(this.src||this.dataset.src)">`:'<div class="ph-ph" data-style="width:30px;height:30px;font-size:12px">📦</div>';
    const createdDate = m.createdAt ? new Date(m.createdAt).toLocaleDateString() : '—';
    // SECURITY FIX: material name/category/unit/location are free-text user
    // input; escape them with sanitizeHTML() before dropping into innerHTML.
    return `<tr><td><input type="checkbox" class="m-sel-cb" data-id="${m.id}" data-onchange="updateSelectedMaterials()"></td><td>${ph}</td><td class="mono">${sanitizeHTML(m.barcode)}</td><td data-style="font-weight:500">${sanitizeHTML(m.name)}</td><td>${sanitizeHTML(m.category)}</td><td>${sanitizeHTML(m.unit)}</td><td>${m.stock}<div class="sbar"><div class="sfill" data-style="width:${pct}%;background:${col}"></div></div></td><td>${m.lowAlert}</td><td class="mono" data-style="font-size:10px;color:var(--tx2)">${sanitizeHTML(m.location||'—')}</td><td><span class="bdg ${m.active!==false?'bg':'br'}">${m.active!==false?'Active':'Inactive'}</span></td><td data-style="font-size:10px;color:var(--tx3)">${createdDate}</td><td><div data-style="display:flex;gap:3px"><button class="btn" data-style="padding:3px 6px" data-onclick="editMat(${m.id})">✏</button><button class="btn" data-style="padding:3px 6px" data-onclick="toggleMat(${m.id})" title="${m.active!==false?'Deactivate':'Activate'}">${m.active!==false?'⏸':'▶'}</button><button class="btn btn-d" data-style="padding:3px 6px" data-onclick="delMat(${m.id})">🗑</button></div></td></tr>`;
  }).join('');
  updateSelectedMaterials();
  // modules/lazyLoader.js — real usage: only decode/load photo data URLs for
  // rows actually scrolled into view, instead of all of them at once.
  if(window.lazyLoader){window.lazyLoader.addElements('.lazy-load');}
}
const renderMasterDebounced=debounce(renderMaster,300);

// ── Material Selection & Bulk Delete ──
function toggleSelectAllMaterials(){
  const selectAll = document.getElementById('m-select-all').checked;
  document.querySelectorAll('.m-sel-cb').forEach(cb => cb.checked = selectAll);
  updateSelectedMaterials();
}

function updateSelectedMaterials(){
  const selected = document.querySelectorAll('.m-sel-cb:checked');
  const count = selected.length;
  const show = count > 0;
  ['m-del-sel-btn','m-exp-sel-btn','m-lbl-sel-btn','m-tog-sel-btn'].forEach(id=>{
    const el=document.getElementById(id);if(el){el.style.display=show?'':'none';}
  });
  const cnt=document.getElementById('m-sel-cnt');
  if(cnt) {cnt.textContent=show?count+' selected':'';}
}

async function deleteSelectedMaterials(){
  if(typeof canRoleAction!=='function'||!canRoleAction('partRegister')){return;}
  const selected = document.querySelectorAll('.m-sel-cb:checked');
  if(!selected.length) {return;}
  if(!confirm(`Delete ${selected.length} selected material(s)?`)) {return;}
  
  const ids = Array.from(selected).map(cb => cb.dataset.id);
  let deletedCount = 0;
  
  for(const id of ids){
    try {
      await dDel('materials', id);
      M = M.filter(m => String(m.id) !== String(id));
      deletedCount++;
    } catch(err) {
      console.error('Error deleting material:', id, err);
    }
  }
  
  if(deletedCount > 0){
    addAudit('DELETE', `Bulk deleted: ${deletedCount} materials`, 'MATERIAL');
    renderMaster();
    updateBadges();
    toast(`Deleted ${deletedCount} materials`);
  } else {
    toast('No materials were deleted', 'er');
  }
  
  document.getElementById('m-select-all').checked = false;
  updateSelectedMaterials();
}

// ── Bulk Export CSV (selected materials) ──────────────────────────────────────
function exportSelectedCSV(){
  if(typeof canRoleAction!=='function'||!canRoleAction('pdfExcelExport')){return;}
  // modules/rateLimiter.js — real usage: cap accidental rapid-fire export
  // clicks (max 10/min), not login (that's already handled by passwordPolicy.js).
  if(window.RateLimiter){
    const rl=window.RateLimiter.checkExportLimit('local-user');
    if(!rl.allowed){window.RateLimiter.showRateLimitError(rl,'export');return;}
  }
  const selected=document.querySelectorAll('.m-sel-cb:checked');
  if(!selected.length){toast('Select items first','er');return;}
  const ids=new Set(Array.from(selected).map(cb=>String(cb.dataset.id)));
  const items=M.filter(m=>ids.includes(String(m.id)));
  const d=new Date().toISOString().slice(0,10);
  const rows=[['Barcode','Name','Category','Unit','Stock','Low Alert','Suggested Order Qty','HSN','Location','Bin Location ID','Status']];
  items.forEach(m=>rows.push([m.barcode,m.name,m.category,m.unit,m.stock,m.lowAlert,suggestedOrderQty(m),m.hsn||'',m.location||'',m.binLocationId||'',m.active!==false?'Active':'Inactive']));
  const csv=rows.map(r=>r.map(c=>{const v=String(c==null?'':c);const safe=/^[=+\-@]/.test(v)?"'"+v:v;return '"'+safe.replace(/"/g,'""')+'"';}).join(',')).join('\n');
  const fn=`materials_selected_${items.length}_${d}.csv`;
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download=fn;a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
  addAudit('EXPORT',`Bulk exported ${items.length} materials to CSV`,'MATERIAL');
  toast(`Exported ${items.length} items → ${fn}`);
}

// ── Export ALL (filtered) materials via modules/excelExport.js ────────────────
// The export module provides a real Excel-compatible export path and a CSV fallback.
function exportAllMaterialsExcel(){
  if(typeof canRoleAction!=='function'||!canRoleAction('pdfExcelExport')){return;}
  if(!window.ExcelExport){toast('Export module not loaded','er');return;}
  if(window.RateLimiter){
    const rl=window.RateLimiter.checkExportLimit('local-user');
    if(!rl.allowed){window.RateLimiter.showRateLimitError(rl,'export');return;}
  }
  const q=sanitizeText(document.getElementById('srch-m').value||'').toLowerCase();
  const cat=document.getElementById('flt-m-cat').value;
  const stat=document.getElementById('flt-m-stat').value;
  const items=M.filter(m=>{
    let ok=(m.name.toLowerCase().includes(q)||m.barcode.toLowerCase().includes(q));
    if(cat){ok=ok&&m.category===cat;}
    if(stat==='active'){ok=ok&&m.active!==false;}
    if(stat==='inactive'){ok=ok&&m.active===false;}
    return ok;
  });
  if(!items.length){toast('No materials to export (check filters)','er');return;}
  const rows=items.map(m=>({
    barcode:m.barcode, name:m.name, category:m.category, unit:m.unit,
    stock:m.stock, lowAlert:m.lowAlert, reorderQty:suggestedOrderQty(m),
    hsn:m.hsn||'', location:m.location||'', status:m.active!==false?'Active':'Inactive',
    created:m.createdAt?new Date(m.createdAt).toLocaleDateString():''
  }));
  const csv=window.ExcelExport.exportToCSV(rows,{});
  const d=new Date().toISOString().slice(0,10);
  window.ExcelExport.downloadCSV(csv,`materials_all_${items.length}_${d}.csv`);
  addAudit('EXPORT',`Exported all ${items.length} materials (Excel format)`,'MATERIAL');
  toast(`Exported ${items.length} items`);
}

// ── Bulk Print Labels (selected materials) ────────────────────────────────────
async function printSelectedLabels(){
  const selected=document.querySelectorAll('.m-sel-cb:checked');
  if(!selected.length){toast('Select items first','er');return;}
  const ids=new Set(Array.from(selected).map(cb=>String(cb.dataset.id)));
  const items=M.filter(m=>ids.has(String(m.id)));
  const s=getLblSettings();
  const {w,h,fs,per,copies}=s;
  showLoading('Generating labels for '+items.length+' items…');
  try{
    let labelsHtml='';
    for(const m of items){
      for(let i=0;i<copies;i++) {labelsHtml+=await buildLabelPrintHtml(m,s);}
    }
    const sheetW=per*w+(per-1)*2+8;
    const doc=`<!DOCTYPE html><html><head><title>Labels</title>
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      html,body{background:#fff;font-family:Arial,sans-serif}
      .grid{display:grid;grid-template-columns:repeat(${per},${w}mm);gap:2mm;padding:4mm;width:${sheetW}mm;background:#fff}
      .lbl{width:${w}mm;height:${h}mm;border:1px solid #000;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden;padding:1mm;page-break-inside:avoid;background:#fff}
      .lbl-name,.lbl-sub,.lbl-bc{text-align:center;white-space:nowrap;width:92%;overflow:hidden;text-overflow:ellipsis;line-height:1.1}
      .lbl-name{font-weight:bold}
      .lbl-codes{display:flex;align-items:center;justify-content:center;gap:1mm;margin:0.5mm 0;flex:1;min-height:0;width:100%}
      .lbl-codes img{object-fit:contain}
      @media print{@page{size:${sheetW}mm auto;margin:0}body{margin:0}.grid{padding:0;gap:0}.lbl{border:1px solid #000!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}}
    </style></head><body><div class="grid">${labelsHtml}</div></body></html>`;
    hideLoading();
    window.printPopupHtml(doc);
    addAudit('PRINT',`Bulk printed labels for ${items.length} materials`,'MATERIAL');
    toast('Print window opened');
  }catch(err){
    hideLoading();
    console.error('[BulkPrint]',err);
    toast('Label print failed: '+err.message,'er');
  }
}

// ── Bulk Toggle Active/Inactive (selected materials) ──────────────────────────
async function toggleSelectedMaterials(){
  if(typeof canRoleAction!=='function'||!canRoleAction('partRegister')){return;}
  const selected=document.querySelectorAll('.m-sel-cb:checked');
  if(!selected.length){toast('Select items first','er');return;}
  const ids=Array.from(selected).map(cb=>String(cb.dataset.id));
  const items=M.filter(m=>ids.has(String(m.id)));
  // Determine action: if ALL selected are active → deactivate; otherwise activate
  const allActive=items.every(m=>m.active!==false);
  const newState=!allActive;
  const actionLabel=newState?'Activated':'Deactivated';
  if(!confirm(`${actionLabel} ${items.length} selected material(s)?`)) {return;}
  let count=0;
  for(const m of items){
    try{
      m.active=newState;
      m.updatedAt=new Date().toISOString();
      await dPut('materials',m);
      count++;
    }catch(err){ console.error('Toggle error:',m.id,err); }
  }
  M=await gAll('materials');
  addAudit(newState?'ACTIVATE':'DEACTIVATE',`Bulk ${actionLabel.toLowerCase()}: ${count} materials`,'MATERIAL');
  renderMaster();
  updateBadges();
  toast(`${actionLabel} ${count} material(s)`);
  document.getElementById('m-select-all').checked=false;
  updateSelectedMaterials();
}

// ── Scan ──
function handleScan(dir,e){
  if(e.key!=='Enter'){return;}
  const code=document.getElementById(dir+'-bc').value.trim();if(!code){return;}
  const item=M.find(m=>m.barcode===code&&m.active!==false);
  const box=document.getElementById(dir+'-sb');
  if(item){
    if(dir==='in'){inI=item;document.getElementById('in-nm').textContent=item.name;document.getElementById('in-dt').textContent=item.barcode+' · '+item.category+' · '+item.unit;document.getElementById('in-cs').textContent=item.stock+' '+item.unit;openInQtyPopup(item);}
    else{outI=item;document.getElementById('out-nm').textContent=item.name;document.getElementById('out-dt').textContent=item.barcode+' · '+item.category+' · '+item.unit;document.getElementById('out-cs').textContent=item.stock+' '+item.unit;openOutQtyPopup(item);}
    box.className='scan-box ok';document.getElementById(dir+'-fb').classList.add('on');document.getElementById(dir+'-st').textContent='✓ '+item.name;
  }else{
    if(dir==='in'){inI=null;}else {outI=null;}
    box.className='scan-box err';document.getElementById(dir+'-fb').classList.remove('on');document.getElementById(dir+'-st').textContent='✕ "'+code+'" not found';
    toast('"'+code+'" barcode not found!','er');
  }
}
function resetScan(dir){
  document.getElementById(dir+'-bc').value='';document.getElementById(dir+'-qty').value='';
  document.getElementById(dir+'-sb').className='scan-box rdy';document.getElementById(dir+'-fb').classList.remove('on');document.getElementById(dir+'-st').textContent='Scanner ready — scan barcode';
  if(dir==='in'){inI=null;['in-supp','in-po','in-inv','in-rem','in-batch'].forEach(id=>document.getElementById(id).value='');}
  else{outI=null;['out-dept','out-person','out-job','out-rem'].forEach(id=>document.getElementById(id).value='');}
  document.getElementById(dir+'-bc').focus();
}

// Rebuild the Material IN log from persisted transactions whenever the page is opened or a receipt is saved.
function todaysInTransactions(transactions, now = new Date()) {
  const today = now.toDateString();
  return (Array.isArray(transactions) ? transactions : [])
    .filter(tx => tx && ['IN', 'MATERIAL_IN'].includes(tx.type) && Number.isFinite(Date.parse(tx.time)) && new Date(tx.time).toDateString() === today)
    .slice()
    .sort((a, b) => Date.parse(b.time) - Date.parse(a.time));
}
function renderInLog(transactions = T) {
  const host = document.getElementById('in-log');
  if (!host) { return; }
  host.innerHTML = todaysInTransactions(transactions).map(tx => {
    const time = new Date(tx.time).toLocaleTimeString();
    const name = sanitizeHTML(String(tx.itemName || tx.materialName || ''));
    const qty = sanitizeHTML(String(tx.qty ?? ''));
    const supplier = sanitizeHTML(String(tx.supplierName || '-'));
    const po = sanitizeHTML(String(tx.po || '-'));
    const batch = sanitizeHTML(String(tx.batch || ''));
    return `<tr><td>${time}</td><td>${name}</td><td data-style="color:var(--gn)">+${qty}</td><td>${supplier}</td><td class="mono">${po}</td><td class="mono">${batch}</td></tr>`;
  }).join('');
}

// Transaction attachments are embedded as base64 data in transaction records (and therefore in JSON backups).
// Strict limits keep IndexedDB/local backup sizes predictable; this feature never performs network I/O.
const TX_ATTACHMENT_MAX_COUNT = 3;
const TX_ATTACHMENT_MAX_BYTES = 5 * 1024 * 1024;
const TX_ATTACHMENT_TYPES = new Set(['application/pdf', 'image/jpeg', 'image/png']);
function showTransactionAttachmentSelection(direction) {
  const input = document.getElementById(`${direction}-attachments`);
  const status = document.getElementById(`${direction}-attachments-status`);
  if (!input || !status) return;
  const files = Array.from(input.files || []);
  const issue = files.length > TX_ATTACHMENT_MAX_COUNT ? `Select no more than ${TX_ATTACHMENT_MAX_COUNT} files.` : files.find(f => !TX_ATTACHMENT_TYPES.has(f.type) || f.size > TX_ATTACHMENT_MAX_BYTES);
  status.textContent = typeof issue === 'string' ? issue : issue ? `${issue.name}: unsupported file type or larger than 5 MB.` : `${files.length} file(s) selected; files are saved locally with the transaction.`;
}
async function readTransactionAttachments(direction) {
  const input = document.getElementById(`${direction}-attachments`);
  const files = Array.from(input?.files || []);
  if (files.length > TX_ATTACHMENT_MAX_COUNT) throw new Error(`Choose at most ${TX_ATTACHMENT_MAX_COUNT} transaction attachments.`);
  const result = [];
  for (const file of files) {
    if (!TX_ATTACHMENT_TYPES.has(file.type)) throw new Error(`${file.name}: only PDF, JPEG, or PNG files are allowed.`);
    if (!Number.isFinite(file.size) || file.size <= 0 || file.size > TX_ATTACHMENT_MAX_BYTES) throw new Error(`${file.name}: file must be non-empty and no larger than 5 MB.`);
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (bytes.length !== file.size) throw new Error(`${file.name}: file data is incomplete.`);
    const validSignature = file.type === 'application/pdf' ? bytes.length >= 5 && String.fromCharCode(...bytes.subarray(0, 5)) === '%PDF-' : file.type === 'image/png' ? bytes.length >= 8 && [137,80,78,71,13,10,26,10].every((n, i) => bytes[i] === n) : bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
    if (!validSignature) throw new Error(`${file.name}: file contents do not match the selected PDF/JPEG/PNG type.`);
    let binary = ''; for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    result.push({ name: String(file.name || 'attachment').slice(0, 255), type: file.type, size: bytes.length, data: btoa(binary) });
  }
  return result;
}
function clearTransactionAttachments(direction) {
  const input = document.getElementById(`${direction}-attachments`); if (input) input.value = '';
  const status = document.getElementById(`${direction}-attachments-status`); if (status) status.textContent = '';
}
function openTransactionAttachment(transactionId,index){
  const tx=T.find(t=>String(t.id)===String(transactionId));
  const file=tx?.attachments?.[Number(index)];
  if(!file||!TX_ATTACHMENT_TYPES.has(file.type)||typeof file.data!=='string'||file.data.length>22*1024*1024){toast('Attachment is missing or invalid.','er');return;}
  try{
    const binary=atob(file.data);if(binary.length!==Number(file.size)||binary.length>TX_ATTACHMENT_MAX_BYTES)throw new Error('Attachment size validation failed');
    const bytes=Uint8Array.from(binary,ch=>ch.charCodeAt(0));
    const url=URL.createObjectURL(new Blob([bytes],{type:file.type}));
    const link=document.createElement('a');link.href=url;link.target='_blank';link.rel='noopener noreferrer';link.download=String(file.name||'transaction-attachment').replace(/[\\/]/g,'_');
    document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
  }catch(error){toast(`Attachment could not be opened. ${error.message||''}`,'er');}
}
// ── Material IN ──
async function procIn(){
  if(!inI){toast('Scan barcode first','er');return;}
  const qty=sanitizeInteger(document.getElementById('in-qty').value, 1);if(!qty||qty<=0){toast('Enter a valid quantity','er');return;}
  let attachments;try{attachments=await readTransactionAttachments('in');}catch(error){toast(error.message,'er');return;}
  const loading=showLoading('Processing Material IN...');
  try{
    const itemSnapshot=inI;
    const sId=document.getElementById('in-supp').value;const sObj=SP.find(s=>s.id==sId);
    // FIX #6: Include id (UUID), timestamp, deviceId, and type for multi-PC conflict detection
    const tx={
      id: generateUUID(),
      timestamp: Date.now(),
      deviceId: navigator.userAgent, // renderer-side device hint; main process overlays actual DEVICE_ID
      time:new Date().toISOString(),barcode:itemSnapshot.barcode,itemId:itemSnapshot.id,itemName:itemSnapshot.name,unit:itemSnapshot.unit,
      type:'IN',...getCurrentShiftLabel(),qty,supplierId:sId,supplierName:sObj?sObj.name:'',
      po:sanitizeText(document.getElementById('in-po').value),invoice:sanitizeText(document.getElementById('in-inv').value),
      batch:sanitizeText(document.getElementById('in-batch').value),remarks:sanitizeText(document.getElementById('in-rem').value),attachments,
      user:cu.username,userName:cu.name,status:'confirmed'
    };
    const pending=window.__pendingMaterialIn;
    const attempt=pending&&pending.itemId===itemSnapshot.id&&pending.qty===qty?pending:{tx,grn:{id:generateUUID(),grnNo:'GRN-'+Date.now().toString().slice(-8),time:tx.time,supplierId:sId,supplierName:tx.supplierName||'',po:tx.po||'',invoice:tx.invoice||'',items:[{barcode:itemSnapshot.barcode,materialName:itemSnapshot.name,unit:itemSnapshot.unit,qty,batch:tx.batch||''}],totalQty:qty,receivedBy:cu.name,user:cu.username},itemId:itemSnapshot.id,qty};
    window.__pendingMaterialIn=attempt;
    if(window.centralSync){try{const centralResult=await window.centralSync.submit(attempt.tx);if(centralResult?.transaction){attempt.tx.status=centralResult.transaction.status||attempt.tx.status;}}catch(syncError){attempt.tx.status='pending-central';attempt.tx.centralSyncError=syncError.message||'Central sync failed';}}
    const grn=attempt.grn;
    if(typeof window.atomicReadModifyWrite!=='function')throw new Error('Atomic stock persistence is unavailable');
    const committed=await window.atomicReadModifyWrite('materials',itemSnapshot.id,(current,guards)=>{
      if(!current)throw new Error('Material no longer exists');
      // The transaction ID is the idempotency key. The database CAS helper
      // rechecks it in the same commit transaction as the stock mutation.
      if(guards.receiptTransaction){return {record:current,writes:[]};}
      const updated={...current,stock:Number(current.stock||0)+qty,updatedAt:new Date().toISOString()};
      return {record:updated,writes:[{store:'transactions',obj:attempt.tx},{store:'grn',obj:grn}]};
    },{guards:[{store:'transactions',key:attempt.tx.id,name:'receiptTransaction'}]});
    inI=committed;window.__pendingMaterialIn=null;
    if(!T.some(saved=>String(saved.id)===String(attempt.tx.id)))T.push(attempt.tx);
    if(!GRN.some(saved=>String(saved.id)===String(grn.id)))GRN.push(grn);M=await gAll('materials');
    addAudit('IN',`IN: ${inI.name} | Qty: ${qty} | Supplier: ${tx.supplierName||'-'} | PO: ${tx.po||'-'}`,'IN');
  renderInLog();
  document.getElementById('in-cs').textContent=inI.stock+' '+inI.unit;
  toast(`✓ ${inI.name} — ${qty} IN! Stock: ${inI.stock}`);clearTransactionAttachments('in');updateBadges();resetScan('in');renderLiveFeed();renderConsumptionChart();renderSummary();updateShiftWidget();
  }catch(e){
    handleError(e,{action:'procIn'});
  }finally{
    loading.hide();
  }
}

// ── OUT Qty Popup ──
function openOutQtyPopup(item){
  document.getElementById('oqp-name').textContent=item.name;
  document.getElementById('oqp-detail').textContent=item.barcode+' · '+item.category+' · '+item.unit;
  const stockEl=document.getElementById('oqp-stock');
  stockEl.textContent=item.stock+' '+item.unit;
  stockEl.style.color=item.stock<item.lowAlert?'var(--am)':'var(--gn)';
  // Show bin location
  const locCode=item.binLocation||item.location||'';
  const locRow=document.getElementById('oqp-loc-row');
  const locEl=document.getElementById('oqp-loc');
  if(locCode&&locRow&&locEl){locRow.style.display='';locEl.textContent=locCode;}else if(locRow){locRow.style.display='none';}
  document.getElementById('oqp-qty').value='';
  document.getElementById('out-qty-ov').classList.add('on');
  setTimeout(()=>document.getElementById('oqp-qty').focus(),100);
}
function closeOutQtyPopup(){
  document.getElementById('out-qty-ov').classList.remove('on');
  document.getElementById('oqp-qty').value='';
  // Reset OUT scan state if user cancels
  resetScan('out');
}
async function confirmOutQtyPopup(){
  const raw=document.getElementById('oqp-qty').value;
  const qty=Number(raw);
  if(!Number.isFinite(qty)||!Number.isInteger(qty)||qty<=0){toast('Enter a positive whole-number quantity','er');document.getElementById('oqp-qty').focus();return;}
  if(qty>outI.stock){toast(`Insufficient stock! Available: ${outI.stock} ${outI.unit}`,'er');document.getElementById('oqp-qty').focus();return;}
  document.getElementById('out-qty-ov').classList.remove('on');
  // Set qty in the OUT form and trigger procOut
  document.getElementById('out-qty').value=qty;
  await procOut();
}

// ── Material OUT ──
async function procOut(){
  if(!outI){toast('Scan barcode first','er');return;}
  const qty=sanitizeInteger(document.getElementById('out-qty').value, 1);if(!qty||qty<=0){toast('Enter a valid quantity','er');return;}
  if(qty>outI.stock){toast(`Insufficient stock! Available: ${outI.stock} ${outI.unit}`,'er');return;}
  let attachments;try{attachments=await readTransactionAttachments('out');}catch(error){toast(error.message,'er');return;}
  const loading=showLoading('Processing Material OUT...');
  try{
    const dId=document.getElementById('out-dept').value;const dObj=DP.find(d=>d.id==dId);
    // FIX #6: Include id (UUID), timestamp, deviceId, and type for multi-PC conflict detection
    const tx={
      id: generateUUID(),
      timestamp: Date.now(),
      deviceId: navigator.userAgent,
      time:new Date().toISOString(),barcode:outI.barcode,itemId:outI.id,itemName:outI.name,unit:outI.unit,
      type:'OUT',...getCurrentShiftLabel(),qty,deptId:dId,deptName:dObj?dObj.name:'',
      person:sanitizeText(document.getElementById('out-person').value),job:sanitizeText(document.getElementById('out-job').value),
      remarks:sanitizeText(document.getElementById('out-rem').value),attachments,user:cu.username,userName:cu.name
    };
    if(cu.role==='store'){
      tx.status='pending';
      const ap={id:generateUUID(),txId:tx.id,time:tx.time,itemName:outI.name,barcode:outI.barcode,qty,unit:outI.unit,deptName:tx.deptName,person:tx.person,job:tx.job,remarks:tx.remarks,reqBy:cu.username,reqByName:cu.name,status:'pending'};
      if(typeof window.dPutMany==='function'){await window.dPutMany([{store:'approvals',obj:ap},{store:'transactions',obj:tx}]);}else{await dPut('approvals',ap);await dPut('transactions',tx);} AP.push(ap);T.push(tx);
      addAudit('OUT',`OUT request (pending): ${outI.name} | Qty: ${qty}`,'OUT');
      toast('OUT request submitted — pending Admin approval','inf');
    }else{
      tx.status='confirmed';
      if(window.centralSync){try{const centralResult=await window.centralSync.submit(tx);if(centralResult?.transaction){tx.status=centralResult.transaction.status||tx.status;}}catch(syncError){tx.status='pending-central';tx.centralSyncError=syncError.message||'Central sync failed';}}
      if(typeof window.atomicReadModifyWrite!=='function')throw new Error('Atomic stock persistence is unavailable');
      outI=await window.atomicReadModifyWrite('materials',outI.id,current=>{
        if(!current||Number(current.stock)<qty)throw new Error(`Insufficient stock: ${Number(current?.stock||0)} available`);
        const updated={...current,stock:Number(current.stock)-qty,updatedAt:new Date().toISOString()};
        return {record:updated,writes:[{store:'transactions',obj:tx}]};
      });
      M=await gAll('materials');T.push(tx);
      addAudit('OUT',`OUT: ${outI.name} | Qty: ${qty} | Dept: ${tx.deptName||'-'}`,'OUT');
      if(isLowStockMaterial(outI)){toast(`⚠ LOW STOCK! ${outI.name}: ${outI.stock} ${outI.unit}`,'er');}
      else {toast(`✓ ${outI.name} — ${qty} OUT! Stock: ${outI.stock}`);}
      document.getElementById('out-cs').textContent=outI.stock+' '+outI.unit;
      lastTx={...tx,_item:outI};
    }
    // SECURITY FIX: escape material/department text before innerHTML.
    document.getElementById('out-log').innerHTML=`<tr><td>${new Date().toLocaleTimeString()}</td><td>${sanitizeHTML(tx.itemName)}</td><td data-style="color:var(--rd)">-${qty}</td><td>${sanitizeHTML(tx.deptName||'-')}</td><td><span class="bdg ${tx.status==='pending'?'ba':'br'}">${sanitizeHTML(tx.status)}</span></td></tr>`+document.getElementById('out-log').innerHTML;
    clearTransactionAttachments('out');updateBadges();resetScan('out');renderLiveFeed();renderConsumptionChart();renderSummary();updateShiftWidget();
  }catch(e){
    handleError(e,{action:'procOut'});
  }finally{
    loading.hide();
  }
}

// ── Issue Slip ──
function printIssueSlip(){
  if(!lastTx){toast('Create an OUT transaction first','er');return;}
  const tx=lastTx;const co=CFG.company||'Your Company';const loc=CFG.location||'Main Store';
  document.getElementById('slip-content').innerHTML=`<div data-style="background:#fff;color:#000;padding:8mm;font-family:Arial,sans-serif;font-size:10pt">
    <h2 data-style="text-align:center;font-size:14pt;margin-bottom:2mm">${co}</h2>
    <p data-style="text-align:center;margin-bottom:4mm">${loc} &nbsp;|&nbsp; MATERIAL ISSUE SLIP</p>
    <table data-style="width:100%;border-collapse:collapse;margin-bottom:3mm">
      <tr><td data-style="border:1px solid #000;padding:2mm"><b>Issue No:</b> ISS-${Date.now().toString().slice(-6)}</td><td data-style="border:1px solid #000;padding:2mm"><b>Date:</b> ${new Date(tx.time).toLocaleDateString()}</td></tr>
      <tr><td data-style="border:1px solid #000;padding:2mm"><b>Issued To:</b> ${sanitizeHTML(String(tx.person||'-'))}</td><td data-style="border:1px solid #000;padding:2mm"><b>Department:</b> ${sanitizeHTML(String(tx.deptName||'-'))}</td></tr>
      <tr><td data-style="border:1px solid #000;padding:2mm"><b>Job/WO No:</b> ${tx.job||'-'}</td><td data-style="border:1px solid #000;padding:2mm"><b>Time:</b> ${new Date(tx.time).toLocaleTimeString()}</td></tr>
    </table>
    <table data-style="width:100%;border-collapse:collapse">
      <thead><tr><th data-style="border:1px solid #000;padding:2mm;background:#eee">Sr.</th><th data-style="border:1px solid #000;padding:2mm;background:#eee">Item</th><th data-style="border:1px solid #000;padding:2mm;background:#eee">Barcode</th><th data-style="border:1px solid #000;padding:2mm;background:#eee">Unit</th><th data-style="border:1px solid #000;padding:2mm;background:#eee">Qty Issued</th><th data-style="border:1px solid #000;padding:2mm;background:#eee">Remarks</th></tr></thead>
      <tbody><tr><td data-style="border:1px solid #000;padding:2mm">1</td><td data-style="border:1px solid #000;padding:2mm">${tx.itemName}</td><td data-style="border:1px solid #000;padding:2mm;font-family:monospace">${tx.barcode}</td><td data-style="border:1px solid #000;padding:2mm">${tx.unit}</td><td data-style="border:1px solid #000;padding:2mm;font-weight:bold">${tx.qty}</td><td data-style="border:1px solid #000;padding:2mm">${tx.remarks||'-'}</td></tr></tbody>
    </table>
    <div data-style="display:flex;justify-content:space-between;margin-top:12mm">
      <div data-style="text-align:center;width:30%"><div data-style="border-top:1px solid #000;margin-top:10mm;padding-top:2mm;font-size:9pt">Issued By: ${tx.userName}</div></div>
      <div data-style="text-align:center;width:30%"><div data-style="border-top:1px solid #000;margin-top:10mm;padding-top:2mm;font-size:9pt">Received By</div></div>
      <div data-style="text-align:center;width:30%"><div data-style="border-top:1px solid #000;margin-top:10mm;padding-top:2mm;font-size:9pt">Store Incharge</div></div>
    </div></div>`;
  document.getElementById('slip-ov').classList.add('on');
}
function doPrintSlip(){
  const c=document.getElementById('slip-content').innerHTML;
  const html=`<!DOCTYPE html><html><head><style>body{margin:0;padding:0}</style></head><body>${c}</body></html>`;
  window.printPopupHtml(html);
  addAudit('PRINT','Printed issue slip for: '+lastTx.itemName,'OUT');
}

// Shared source-safe argument and numeric helpers.
function identifiersMatch(a,b){return a!==null&&a!==undefined&&b!==null&&b!==undefined&&String(a)===String(b);}
function eventIdArg(value){return typeof value==='number'&&Number.isSafeInteger(value)?String(value):JSON.stringify(String(value));}
function clampFiniteInt(value,fallback,min,max){const text=String(value??'').trim();if(!text)return fallback;const n=Number(text);if(!Number.isFinite(n))return fallback;return Math.max(min,Math.min(max,Math.trunc(n)));}
function parseLocationCapacity(value){const text=String(value??'').trim();if(!text)return {ok:true,value:0};const n=Number(text);return {ok:Number.isSafeInteger(n)&&n>=0,value:n};}
function isValidOptionalEmail(value){const email=String(value??'').trim();return !email||/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);}
// Audit regression helpers shared by renderers and exports.
function isCompletedMovement(t){ return Boolean(t && t.status === 'confirmed' && ['IN','OUT'].includes(t.type)); }
function sortTransactionsNewestFirst(rows){ return (Array.isArray(rows)?rows:[]).slice().sort((a,b)=>{const at=Date.parse(a?.time||'');const bt=Date.parse(b?.time||'');return (Number.isFinite(bt)?bt:-Infinity)-(Number.isFinite(at)?at:-Infinity);}); }
function csvCell(value){
  let text=String(value==null?'':value);
  if(typeof value!=='number'){
    let index=0;
    while(index<text.length && (/\s/.test(text[index]) || text.charCodeAt(index)<=0x1f)) index++;
    if(/^[=+\-@]/.test(text.slice(index))) text="'"+text;
  }
  return '"'+text.replace(/"/g,'""')+'"';
}
function serializeCSVRows(rows){ return rows.map(row=>row.map(csvCell).join(',')).join('\n'); }
let currentCsvExportJob=null;
let lastCsvExportRetry=null;
function renderCsvExportStatus(message,percent,options={}){
  const panel=document.getElementById('csv-export-progress');
  const bar=document.getElementById('csv-export-progress-bar');
  const text=document.getElementById('csv-export-progress-text');
  const cancel=document.getElementById('csv-export-cancel');
  const retry=document.getElementById('csv-export-retry');
  if(panel)panel.style.display='block';
  if(bar)bar.value=Math.max(0,Math.min(100,Number(percent)||0));
  if(text)text.textContent=String(message||'');
  if(cancel)cancel.style.display=options.cancel?'':'none';
  if(retry)retry.style.display=options.retry?'':'none';
}
if(typeof window!=='undefined')window.storeTrackExportStatus=renderCsvExportStatus;
async function startCSVExport(rows,filename){
  if(currentCsvExportJob?.running){toast('An export is already being prepared','inf');return false;}
  const exportRows=Array.isArray(rows)?rows:[];
  const job={running:true,cancelled:false};
  currentCsvExportJob=job;
  lastCsvExportRetry={rows:exportRows,filename:String(filename||'export.csv')};
  const chunkSize=250;
  const total=Math.max(exportRows.length,1);
  const output=[];
  try{
    renderCsvExportStatus(`Preparing ${filename} · 0 of ${exportRows.length} rows`,0,{cancel:true});
    if(!exportRows.length)output.push(serializeCSVRows([]));
    for(let offset=0;offset<exportRows.length;offset+=chunkSize){
      if(job.cancelled){renderCsvExportStatus('Export cancelled · no file was downloaded',0,{retry:true});return false;}
      const batch=exportRows.slice(offset,offset+chunkSize);
      output.push(serializeCSVRows(batch));
      const completed=Math.min(offset+batch.length,exportRows.length);
      renderCsvExportStatus(`Preparing ${filename} · ${completed} of ${exportRows.length} rows`,Math.round(completed/total*100),{cancel:true});
      await new Promise(resolve=>setTimeout(resolve,0));
    }
    if(job.cancelled){renderCsvExportStatus('Export cancelled · no file was downloaded',0,{retry:true});return false;}
    _dlCSV(output.join('\n'),filename);
    lastCsvExportRetry=null;
    renderCsvExportStatus(`Export ready · ${filename} (${exportRows.length} rows)`,100,{});
    return true;
  }catch(error){
    renderCsvExportStatus(`Export failed: ${error?.message||'unknown error'} · select Retry Export to try again`,0,{retry:true});
    toast(`CSV export failed: ${error?.message||'unknown error'}`,'er');
    return false;
  }finally{
    job.running=false;
    if(currentCsvExportJob===job)currentCsvExportJob=null;
  }
}
function cancelCsvExport(){if(currentCsvExportJob?.running){currentCsvExportJob.cancelled=true;renderCsvExportStatus('Cancelling export…',0,{cancel:false});return;}window.componentCancelExport?.();}
async function retryCsvExport(){if(lastCsvExportRetry){const retry=lastCsvExportRetry;await startCSVExport(retry.rows,retry.filename);return;}await window.componentRetryExport?.();}
function historyFilteredTransactions(){
  const q=String(document.getElementById('srch-h')?.value||'').trim().toLowerCase();
  const type=document.getElementById('flt-h-tp')?.value||'all';
  const from=document.getElementById('flt-h-f')?.value||''; const to=document.getElementById('flt-h-t')?.value||'';
  return sortTransactionsNewestFirst(T.filter(t=>{
    if(!t||typeof t!=='object') return false;
    const time=Date.parse(t.time||'');if(!Number.isFinite(time))return false;
    const name=String(t.itemName||'').toLowerCase(), barcode=String(t.barcode||'').toLowerCase();
    if(q&&!name.includes(q)&&!barcode.includes(q)) return false;
    if(type!=='all'&&t?.type!==type) return false;
    const bounds=localDateRangeBounds(from,to);if(!bounds)return false;
    if(bounds.fromMs!==null&&time<bounds.fromMs)return false;
    if(bounds.untilMs!==null&&time>=bounds.untilMs)return false;
    return true;
  }));
}
function consumptionWindow(months, now=new Date()){
  const count=Math.max(1,Math.min(36,Number.parseInt(months,10)||6));
  const start=new Date(now.getFullYear(),now.getMonth()-count+1,1);
  const labels=[]; for(let i=count-1;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth()-i,1);labels.push(d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0'));}
  return {start,labels,count};
}
function materialSupplierId(m){ return String(m?.preferredSupplierId||m?.supplierId||''); }
function numericStockValue(value){const n=Number(value);return Number.isFinite(n)?n:null;}
function isZeroStockMaterial(m){return numericStockValue(m?.stock)===0;}
function suggestedOrderQty(m){const stock=numericStockValue(m?.stock),target=numericStockValue(m?.lowAlert);return stock===null||target===null?0:Math.max(0,target-stock);}
function isLowStockMaterial(m){const stock=numericStockValue(m?.stock),target=numericStockValue(m?.lowAlert);return m?.active!==false&&stock!==null&&target!==null&&(stock===0||stock<target);}
function reorderCandidates(materials,supplierId){return (materials||[]).filter(m=>m?.active!==false&&suggestedOrderQty(m)>0&&(!supplierId||materialSupplierId(m)===String(supplierId)));}
function lowStockForSupplier(materials, supplierId){ return (materials||[]).filter(m=>isLowStockMaterial(m)&&(!supplierId||materialSupplierId(m)===String(supplierId))); }

// ── Stock ──
function renderStock(){
  // Each row opens the material detail panel; keep display fields normalized.

  const q=(document.getElementById('srch-stk').value||'').toLowerCase();
  const cat=document.getElementById('flt-stk-cat').value;const st=document.getElementById('flt-stk-st').value;
  const f=M.filter(m=>{if(!m||m.active===false){return false;}const name=String(m.name||'').toLowerCase(),barcode=String(m.barcode||'').toLowerCase();let ok=(name.includes(q)||barcode.includes(q));if(cat){ok=ok&&m.category===cat;}if(st==='low'){ok=ok&&Number(m.stock)<Number(m.lowAlert)&&Number(m.stock)>0;}if(st==='ok'){ok=ok&&Number(m.stock)>=Number(m.lowAlert)&&Number(m.stock)>0;}if(st==='zero'){ok=ok&&Number(m.stock)===0;}return ok;});
  const tb=document.getElementById('stk-body');
  if(!f.length){tb.innerHTML='<tr><td colspan="9" data-style="text-align:center;color:var(--tx3);padding:16px">No items</td></tr>';return;}
  tb.innerHTML=f.map(m=>{
    const isL=m.stock<m.lowAlert,isZ=m.stock===0;const pct=Math.min(100,Math.round((m.stock/Math.max(m.lowAlert*3,1))*100));const col=isZ?'var(--rd)':isL?'var(--am)':'var(--gn)';
    const ph=m.photo?`<img src="${m.photo}" class="ph-thumb">`:'<div class="ph-ph" data-style="width:30px;height:30px;font-size:12px">📦</div>';
    return `<tr data-onclick="openMaterialDetail(${JSON.stringify(String(m.id))})" tabindex="0" role="button" aria-label="View ${sanitizeHTML(String(m.name||'material'))} details"><td>${ph}</td><td class="mono">${sanitizeHTML(String(m.barcode||""))}</td><td data-style="font-weight:500">${sanitizeHTML(String(m.name||""))}</td><td>${sanitizeHTML(String(m.category||""))}</td><td>${sanitizeHTML(String(m.unit||''))}</td><td>${Number(m.stock)||0}<div class="sbar"><div class="sfill" data-style="width:${pct}%;background:${col}"></div></div></td><td>${Number(m.lowAlert)||0}</td><td class="mono" data-style="font-size:10px;color:var(--tx2)">${sanitizeHTML(String(m.location||'—'))}</td><td><span class="bdg ${isZ?'br':isL?'ba':'bg'}">${isZ?'OUT':isL?'LOW':'OK'}</span></td></tr>`;
  }).join('');
}

// ── Adjust ──
function loadAdjSel(){const s=document.getElementById('adj-item');s.innerHTML='<option value="">— Select —</option>';M.filter(m=>m.active!==false).forEach(m=>s.innerHTML+=`<option value="${sanitizeHTML(String(m.id))}">${sanitizeHTML(String(m.name||""))} [${sanitizeHTML(String(m.barcode||""))}]</option>`);renderAdjLog();}
function adjChg(){const m=M.find(x=>x.id==document.getElementById('adj-item').value);document.getElementById('adj-cur').value=m?m.stock+' '+m.unit:'';calcAdj();}
function calcAdj(){
  const m=M.find(x=>x.id==document.getElementById('adj-item').value);if(!m){return;}
  const tp=document.getElementById('adj-type').value;const qty=Number(document.getElementById('adj-qty').value);
  if(!Number.isSafeInteger(qty)||qty<=0){document.getElementById('adj-res').value='Invalid quantity';return;}
  const res=tp==='set'?qty:tp==='add'?m.stock+qty:m.stock-qty;
  document.getElementById('adj-res').value=res+' '+m.unit+(res<0?' ⚠ INVALID':'');
}
async function doAdjust(){
  if(typeof canRoleAction!=='function'||!canRoleAction('physicalStock')){return;}
  const m=M.find(x=>x.id==document.getElementById('adj-item').value);if(!m){toast('Select an item','er');return;}
  const tp=document.getElementById('adj-type').value;const qty=Number(document.getElementById('adj-qty').value);
  if(!Number.isSafeInteger(qty)||qty<=0){toast('Enter a positive whole quantity','er');return;}
  const rsn=document.getElementById('adj-rsn').value.trim();if(!rsn){toast('Enter reason','er');return;}
  const old=m.stock;const nw=tp==='set'?qty:tp==='add'?m.stock+qty:m.stock-qty;
  if(nw<0){toast('Stock cannot be negative!','er');return;}
  const updatedMaterial={...m,stock:nw,updatedAt:new Date().toISOString()};
  const adj={id:generateUUID(),time:new Date().toISOString(),itemId:m.id,itemName:m.name,barcode:m.barcode,type:tp,qty,oldStock:old,newStock:nw,diff:nw-old,reason:rsn,user:cu.username,userName:cu.name};
  try{
    if(typeof window.dPutMany!=='function') throw new Error('Atomic database writes are unavailable');
    await window.dPutMany([{store:'materials',obj:updatedMaterial},{store:'adjustments',obj:adj}]);
  }catch(writeError){toast('Adjustment was not saved. No stock change was committed. '+(writeError.message||''),'er');return;}
  Object.assign(m,updatedMaterial);M=await gAll('materials');ADJ.push(adj);
  if (window.centralSync?.submit && nw !== old) {
    try { await window.centralSync.submit({ id: adj.id, itemId: m.id, type: 'ADJUSTMENT', qty: Math.abs(nw-old), newStock: nw, time: adj.time, reason: rsn, userName: cu.name }); }
    catch (error) { adj.status = 'pending-central'; await dPut('adjustments', adj); toast('Adjustment saved locally; central sync is pending.', 'inf'); }
  }
  addAudit('ADJUST',`Adjustment: ${m.name} | ${old} → ${nw} | Reason: ${rsn}`,'ADJUST');
  ['adj-item','adj-cur','adj-qty','adj-res','adj-rsn'].forEach(id=>document.getElementById(id).value='');
  renderAdjLog();updateBadges();toast(`✓ Stock adjusted: ${m.name} → ${nw} ${m.unit}`);
}
function renderAdjLog(){
  const tb=document.getElementById('adj-log');const s=ADJ.slice().reverse();
  if(!s.length){tb.innerHTML='<tr><td colspan="8" data-style="text-align:center;color:var(--tx3);padding:16px">No adjustments</td></tr>';return;}
  // SECURITY FIX: escape item name, adjustment reason, and user name.
  tb.innerHTML=s.map(a=>`<tr><td data-style="font-size:10px">${new Date(a.time||a.timestamp||a.createdAt).toLocaleString()}</td><td>${sanitizeHTML(a.itemName)}</td><td>${sanitizeHTML(a.type)}</td><td class="mono">${a.oldStock}</td><td class="mono" data-style="color:${a.diff>=0?'var(--gn)':'var(--rd)'}">${a.diff>=0?'+':''}${a.diff}</td><td class="mono" data-style="font-weight:600">${a.newStock}</td><td>${sanitizeHTML(a.reason)}</td><td>${sanitizeHTML(a.userName)}</td></tr>`).join('');
}

// ── History ──
async function correctTransaction(originalId){
  if(typeof canRoleAction!=='function'||!canRoleAction('physicalStock')){return;}
  const original=T.find(t=>String(t.id)===String(originalId));
  if(!original||!['IN','OUT'].includes(original.type)||original.status==='pending'||original.status==='rejected'||original.correctionOf){toast('Only confirmed IN/OUT transactions can be corrected.','er');return;}
  if(T.some(t=>String(t.correctionOf||'')===String(original.id))){toast('This transaction already has a correction entry.','er');return;}
  const reason=String(window.prompt('Reason for correcting transaction '+String(original.id)+':')||'').trim();
  if(!reason){toast('Correction cancelled: a reason is required.','inf');return;}
  const material=M.find(m=>String(m.id)===String(original.itemId));
  if(!material){toast('Correction not saved: the linked material no longer exists.','er');return;}
  const qty=Number(original.qty);
  if(!Number.isSafeInteger(qty)||qty<=0){toast('Correction not saved: original quantity is invalid.','er');return;}
  const correctionId=`correction:${String(original.id)}`;
  const correctedType=original.type==='IN'?'OUT':'IN';
  const correction={id:correctionId,time:new Date().toISOString(),timestamp:Date.now(),deviceId:original.deviceId||'',barcode:original.barcode,itemId:original.itemId,itemName:original.itemName,unit:original.unit,type:correctedType,qty,correction:true,correctionOf:original.id,correctionReason:sanitizeText(reason),user:cu.username,userName:cu.name,status:'confirmed',remarks:`Correction of ${original.id}: ${sanitizeText(reason)}`};
  try{
    if(typeof window.atomicReadModifyWrite!=='function')throw new Error('Atomic stock persistence is unavailable');
    const updated=await window.atomicReadModifyWrite('materials',material.id,(current,guards)=>{
      if(!current||String(current.id)!==String(original.itemId))throw new Error('Linked material is missing or changed');
      if(guards.sourceTransaction?.status==='pending'||guards.sourceTransaction?.status==='rejected')throw new Error('Original transaction is not confirmed');
      if(guards.existingCorrection)throw new Error('This transaction already has a correction entry');
      const delta=correctedType==='IN'?qty:-qty;
      const stock=Number(current.stock||0)+delta;
      if(!Number.isSafeInteger(stock)||stock<0)throw new Error('Correction would make stock negative; no changes were saved');
      return {record:{...current,stock,updatedAt:new Date().toISOString()},writes:[{store:'transactions',obj:correction}],result:{...current,stock,updatedAt:new Date().toISOString()}};
    },{guards:[{store:'transactions',key:original.id,name:'sourceTransaction',validate:r=>Boolean(r&&['IN','OUT'].includes(r.type)&&r.status!=='pending'&&r.status!=='rejected'),errorMessage:'Original transaction is not correctable'},{store:'transactions',key:correctionId,name:'existingCorrection',validate:r=>!r,errorMessage:'This transaction already has a correction entry'}]});
    Object.assign(material,updated);M=await gAll('materials');T=await gAll('transactions');
    addAudit('TRANSACTION_CORRECTION',`Correction ${correction.id} reverses ${original.id} (${original.type} ${qty}): ${reason}`,'IN/OUT');
    if(window.centralSync?.submit){try{const result=await window.centralSync.submit(correction);if(result?.transaction)correction.status=result.transaction.status||correction.status;}catch(syncError){correction.status='pending-central';correction.centralSyncError=syncError.message||'Central sync failed';await dPut('transactions',correction);}}
    T=await gAll('transactions');M=await gAll('materials');updateBadges();renderHist();renderSummary();toast(`Correction entry saved and linked to ${original.id}.`,'ok');
  }catch(error){toast(`Correction not saved. Original transaction is unchanged. ${error.message||''}`,'er');}
}
function renderHist(){
  const f=historyFilteredTransactions();
  const tb=document.getElementById('hist-body');
  if(!f.length){tb.innerHTML='<tr><td colspan="11" data-style="text-align:center;color:var(--tx3);padding:16px">No records</td></tr>';return;}
  // SECURITY FIX: escape item/supplier/dept/PO/job/user text before innerHTML.
  tb.innerHTML=f.map(t=>`<tr><td data-style="font-size:10px;white-space:nowrap">${new Date(t.time).toLocaleString()}</td><td class="mono">${sanitizeHTML(t.barcode)}</td><td>${sanitizeHTML(t.itemName)}</td><td><span class="bdg ${t.type==='IN'?'bg':'br'}">${sanitizeHTML(t.type)}</span>${t.correction?'<span class="bdg ba">Correction</span>':''}</td><td class="mono">${t.type==='IN'?'+':'-'}${t.qty} ${sanitizeHTML(t.unit)}</td><td>${sanitizeHTML(t.supplierName||t.deptName||'-')}</td><td class="mono">${sanitizeHTML(t.po||t.job||'-')}</td><td>${sanitizeHTML(t.userName||'-')}</td><td><span class="bdg ${t.status==='pending'?'ba':t.status==='confirmed'?'bg':'br'}">${sanitizeHTML(t.status||'ok')}</span>${t.correctionOf?`<div class="muted">For ${sanitizeHTML(t.correctionOf)}</div>`:''}</td><td>${(Array.isArray(t.attachments)?t.attachments:[]).map((a,i)=>`<button class="btn btn-sm" type="button" data-onclick="openTransactionAttachment(${JSON.stringify(String(t.id))},${i})" aria-label="Open attachment ${sanitizeHTML(String(a.name||'file'))}">${sanitizeHTML(String(a.name||'Attachment'))}</button>`).join(' ')||'—'}</td><td>${!t.correction&&!T.some(c=>String(c.correctionOf||'')===String(t.id))&&['IN','OUT'].includes(t.type)&&t.status!=='pending'&&t.status!=='rejected'?`<button class="btn btn-sm" type="button" data-onclick="correctTransaction(${JSON.stringify(String(t.id))})" aria-label="Correct transaction ${sanitizeHTML(String(t.id))}">Correct</button>`:''}</td></tr>`).join('');
}
function clearHistFilter(){['flt-h-f','flt-h-t'].forEach(id=>document.getElementById(id).value='');document.getElementById('srch-h').value='';document.getElementById('flt-h-tp').value='all';renderHist();}

// ── Low Stock ──
function renderLow(){
  const low=lowStockForSupplier(M,'');
  const numeric=m=>numericStockValue(m)||0;
  document.getElementById('low-sum').innerHTML=`<div class="g3" data-style="margin-bottom:10px"><div class="met"><div class="met-v" data-style="color:var(--rd)">${low.length}</div><div class="met-l">Low Stock Items</div></div><div class="met"><div class="met-v" data-style="color:var(--rd)">${low.filter(isZeroStockMaterial).length}</div><div class="met-l">Out of Stock</div></div><div class="met"><div class="met-v" data-style="color:var(--am)">${low.filter(m=>numeric(m)>0).length}</div><div class="met-l">Running Low</div></div></div>`;
  const tb=document.getElementById('low-body');
  if(!low.length){tb.innerHTML='<tr><td colspan="8" data-style="text-align:center;color:var(--gn);padding:16px">✓ All stock normal</td></tr>';return;}
  tb.innerHTML=low.map(m=>{const stock=numeric(m),alert=numericStockValue(m.lowAlert)||0,zero=isZeroStockMaterial(m);const ph=m.photo?`<img src="${m.photo}" class="ph-thumb">`:'<div class="ph-ph" data-style="width:30px;height:30px;font-size:12px">📦</div>';return `<tr><td>${ph}</td><td class="mono">${sanitizeHTML(String(m.barcode||""))}</td><td data-style="font-weight:500">${sanitizeHTML(String(m.name||""))}</td><td>${sanitizeHTML(String(m.category||""))}</td><td data-style="color:var(--rd);font-family:var(--mn);font-weight:600">${stock}</td><td>${alert}</td><td>${suggestedOrderQty(m)}</td><td><span class="bdg ${zero?'br':'ba'}">${zero?'OUT':'LOW'}</span></td></tr>`;}).join('');
}
function lowItems(){return lowStockForSupplier(M,'');}
function lowStockMessage(format='text'){
  const low=lowItems();
  let txt=`LOW STOCK REPORT
Company: ${CFG.company||'-'}
Location: ${CFG.location||'-'}
Generated: ${new Date().toLocaleString()}
By: ${cu?.name||'System'}
${'='.repeat(50)}

`;
  low.forEach((m,i)=>{const stock=numericStockValue(m.stock)||0,alert=numericStockValue(m.lowAlert)||0;txt+=`${i+1}. ${m.name}
   Barcode: ${m.barcode}
   Category: ${m.category}
   Stock: ${stock} ${m.unit}
   Required Qty: ${alert} | Suggested Order Qty: ${suggestedOrderQty(m)} ${m.unit}
   Suggested Order Qty: ${suggestedOrderQty(m)}
   Status: ${isZeroStockMaterial(m)?'OUT OF STOCK':'LOW STOCK'}

`;});
  return format==='wa'?txt.replace('LOW STOCK REPORT','LOW STOCK'):txt;
}

function previewLowAlert(){const low=lowItems();if(!low.length){toast('No low stock items','inf');return;}const box=document.getElementById('low-preview');box.value=lowStockMessage('text');box.style.display='block';toast('Low stock alert preview ready','inf');}
async function copyLowAlert(){const low=lowItems();if(!low.length){toast('No low stock items','inf');return;}const msg=lowStockMessage('text');try{await navigator.clipboard.writeText(msg);toast('Low stock alert copied!');}catch(e){const box=document.getElementById('low-preview');box.value=msg;box.style.display='block';box.select();toast('Preview selected. Press Ctrl+C to copy.','inf');}}
function emailAlert(){const low=lowItems();if(!low.length){toast('No low stock items','inf');return;}const sub=`Low Stock Alert - ${CFG.company||'Store'} - ${new Date().toLocaleDateString()}`;window.location.href=`mailto:${CFG.email||'store@company.com'}?subject=${encodeURIComponent(sub)}&body=${encodeURIComponent(lowStockMessage('text'))}`;addAudit('ALERT','Email alert prepared for '+low.length+' items','SYSTEM');}
function waAlert(){const low=lowItems();if(!low.length){toast('No low stock items','inf');return;}const wa=CFG.wa?`https://wa.me/${CFG.wa.replace(/\D/g,'')}?text=`:'https://wa.me/?text=';window.open(wa+encodeURIComponent(lowStockMessage('wa')),'_blank');addAudit('ALERT','WhatsApp alert prepared for '+low.length+' items','SYSTEM');}
function genLowFile(){const low=lowItems();if(!low.length){toast('No low stock items','inf');return;}const txt=lowStockMessage('text');const a=document.createElement('a');const _lowUrl=URL.createObjectURL(new Blob([txt],{type:'text/plain'}));a.href=_lowUrl;a.download=`low_stock_${new Date().toISOString().slice(0,10)}.txt`;a.click();setTimeout(()=>URL.revokeObjectURL(_lowUrl),1000);/* FIX #4 */}
// ── Alert Preview Modal ──
let _alertMode='email';
function openAlertPreview(mode){
  const low=lowItems();if(!low.length){toast('No low stock items','inf');return;}
  _alertMode=mode;
  const msg=lowStockMessage(mode==='wa'?'wa':'text');
  document.getElementById('lowalert-msg').value=msg;
  const lbl=mode==='email'?'📧 Will open Email client':mode==='wa'?'💬 Will open WhatsApp':'📧+💬 Will send Email & WhatsApp';
  document.getElementById('lowalert-type-lbl').textContent=lbl;
  const btn=document.getElementById('lowalert-send-btn');
  btn.textContent=mode==='both'?'✈ Send Both':mode==='email'?'📧 Open Email':'💬 Open WhatsApp';
  document.getElementById('lowalert-ov').classList.add('on');
}
function doSendAlert(){
  if(_alertMode==='email'||_alertMode==='both'){emailAlert();}
  if(_alertMode==='wa'||_alertMode==='both'){waAlert();}
  document.getElementById('lowalert-ov').classList.remove('on');
}
function doSendBoth(){_alertMode='both';doSendAlert();}
async function doCopyAlert(){
  const msg=document.getElementById('lowalert-msg').value;
  try{await navigator.clipboard.writeText(msg);toast('Message copied to clipboard!');}
  catch(e){document.getElementById('lowalert-msg').select();toast('Select all and Ctrl+C to copy','inf');}
}
// ── Forgot Password ──
function showForgotPw(){document.getElementById('forgotpw-ov').classList.add('on');}
function reqForgotPw(){
  const un=document.getElementById('fp-un').value.trim();
  if(!un){toast('Enter your username','er');return;}
  const msg=document.getElementById('fp-msg');
  msg.style.display='block';
  msg.textContent='✓ Request noted for "'+un+'". Please contact your Admin to reset the password. Admin can reset it from Users → 🔑 button.';
  addAudit('USER','Forgot password request for username: '+un,'USER');
}
function checkArStrength(){
  const p=document.getElementById('ar-pw').value;
  const s=document.getElementById('ar-strength');
  if(!p){s.textContent='';return;}
  if(p.length<6){s.style.color='var(--rd)';s.textContent='Too short (min 6 chars)';return;}
  if(!/[A-Za-z]/.test(p)||!/\d/.test(p)){s.style.color='var(--am)';s.textContent='Add both a letter and a number';return;}
  if(window.passwordPolicy&&window.passwordPolicy.isCommonPassword(p)){s.style.color='var(--rd)';s.textContent='⚠ This is a commonly-used password — please choose another';return;}
  // Meets the app's minimum requirements — also show the richer strength
  // score from passwordPolicy.js (weak/fair/good/strong/excellent) as a
  // helpful hint, without blocking submission on it.
  if(window.passwordPolicy){
    const {level}=window.passwordPolicy.calculateStrength(p);
    const colors={weak:'var(--am)',fair:'var(--am)',good:'var(--gn)',strong:'var(--gn)',excellent:'var(--gn)'};
    s.style.color=colors[level]||'var(--gn)';
    s.textContent='✓ Meets requirements — strength: '+level;
  }else{
    s.style.color='var(--gn)';s.textContent='✓ Strong enough';
  }
}
// ── Date Reports ──
function genReport(){
  const from=document.getElementById('rp-from').value,to=document.getElementById('rp-to').value;
  if(!from||!to){toast('Select a date range','er');return;}
  if(from>to){toast('Start date must be on or before end date','er');return;}
  const type=document.getElementById('rp-type').value;
  const site=document.getElementById('rp-site')?.value||'';
  const part=document.getElementById('rp-part')?.value||'';
  const supplier=document.getElementById('rp-supp')?.value||'';
  const filtered=filterReportTransactions(T,from,to,site,part,supplier,M);
  rpData=filtered;
  const head=document.getElementById('rp-head'),body=document.getElementById('rp-body');
  const safe=value=>sanitizeHTML(String(value==null?'':value));
  if(type==='summary'){
    const byD=Object.create(null);filtered.forEach(t=>{const d=localDateKey(new Date(t.time));if(!d||!['IN','OUT'].includes(t.type))return;if(!byD[d])byD[d]={IN:0,OUT:0,inQ:0,outQ:0};byD[d][t.type]++;byD[d][t.type==='IN'?'inQ':'outQ']+=Number(t.qty)||0;});
    head.innerHTML='<th>Date</th><th>IN Txns</th><th>IN Qty</th><th>OUT Txns</th><th>OUT Qty</th>';
    body.innerHTML=Object.entries(byD).sort((a,b)=>b[0].localeCompare(a[0])).map(([d,v])=>`<tr><td>${safe(d)}</td><td data-style="color:var(--gn)">${v.IN}</td><td data-style="color:var(--gn);font-family:var(--mn)">${v.inQ}</td><td data-style="color:var(--rd)">${v.OUT}</td><td data-style="color:var(--rd);font-family:var(--mn)">${v.outQ}</td></tr>`).join('');
  }else if(type==='in'){
    const ins=filtered.filter(t=>t.type==='IN');
    head.innerHTML='<th>Date/Time</th><th>Barcode</th><th>Item</th><th>Qty</th><th>Supplier</th><th>PO</th><th>Invoice</th><th>By</th>';
    body.innerHTML=ins.map(t=>`<tr><td data-style="font-size:10px">${safe(new Date(t.time).toLocaleString())}</td><td class="mono">${safe(t.barcode)}</td><td>${safe(t.itemName)}</td><td data-style="color:var(--gn);font-family:var(--mn)">+${Number(t.qty)||0}</td><td>${safe(t.supplierName||'-')}</td><td class="mono">${safe(t.po||'-')}</td><td class="mono">${safe(t.invoice||'-')}</td><td>${safe(t.userName||'')}</td></tr>`).join('');
  }else if(type==='out'){
    const outs=filtered.filter(t=>t.type==='OUT');
    head.innerHTML='<th>Date/Time</th><th>Barcode</th><th>Item</th><th>Qty</th><th>Dept</th><th>Person</th><th>Job No.</th><th>By</th>';
    body.innerHTML=outs.map(t=>`<tr><td data-style="font-size:10px">${safe(new Date(t.time).toLocaleString())}</td><td class="mono">${safe(t.barcode)}</td><td>${safe(t.itemName)}</td><td data-style="color:var(--rd);font-family:var(--mn)">-${Number(t.qty)||0}</td><td>${safe(t.deptName||'-')}</td><td>${safe(t.person||'-')}</td><td class="mono">${safe(t.job||'-')}</td><td>${safe(t.userName||'')}</td></tr>`).join('');
  }else if(type==='item'){
    const byI=new Map();filtered.forEach(t=>{if(!['IN','OUT'].includes(t.type))return;const bc=String(t.barcode||'');if(!byI.has(bc))byI.set(bc,{name:t.itemName||'',unit:t.unit||'',inQ:0,outQ:0,cnt:0});const v=byI.get(bc);v[t.type==='IN'?'inQ':'outQ']+=Number(t.qty)||0;v.cnt++;});
    head.innerHTML='<th>Barcode</th><th>Item</th><th>Unit</th><th>Total IN</th><th>Total OUT</th><th>Net</th><th>Txns</th>';
    body.innerHTML=Array.from(byI).sort((a,b)=>b[1].cnt-a[1].cnt).map(([bc,v])=>`<tr><td class="mono">${safe(bc)}</td><td>${safe(v.name)}</td><td>${safe(v.unit)}</td><td data-style="color:var(--gn);font-family:var(--mn)">+${v.inQ}</td><td data-style="color:var(--rd);font-family:var(--mn)">-${v.outQ}</td><td class="mono" data-style="font-weight:600">${v.inQ-v.outQ>=0?'+':''}${v.inQ-v.outQ}</td><td>${v.cnt}</td></tr>`).join('');
  }else if(type==='dept'){
    const byD=new Map();filtered.filter(t=>t.type==='OUT').forEach(t=>{const k=String(t.deptName||'Unknown');const v=byD.get(k)||{qty:0,cnt:0};v.qty+=Number(t.qty)||0;v.cnt++;byD.set(k,v);});
    head.innerHTML='<th>Department</th><th>Total OUT Qty</th><th>Transactions</th>';
    body.innerHTML=Array.from(byD).sort((a,b)=>b[1].qty-a[1].qty).map(([d,v])=>`<tr><td data-style="font-weight:500">${safe(d)}</td><td data-style="color:var(--rd);font-family:var(--mn)">${v.qty}</td><td>${v.cnt}</td></tr>`).join('');
  }else if(type==='supp'){
    const byS=new Map();filtered.filter(t=>t.type==='IN').forEach(t=>{const k=String(t.supplierName||'Unknown');const v=byS.get(k)||{qty:0,cnt:0};v.qty+=Number(t.qty)||0;v.cnt++;byS.set(k,v);});
    head.innerHTML='<th>Supplier</th><th>Total IN Qty</th><th>Transactions</th>';
    body.innerHTML=Array.from(byS).sort((a,b)=>b[1].qty-a[1].qty).map(([name,v])=>`<tr><td data-style="font-weight:500">${safe(name)}</td><td data-style="color:var(--gn);font-family:var(--mn)">${v.qty}</td><td>${v.cnt}</td></tr>`).join('');
  }
  const inT=filtered.filter(t=>t.type==='IN').reduce((sum,t)=>sum+(Number(t.qty)||0),0);
  const outT=filtered.filter(t=>t.type==='OUT').reduce((sum,t)=>sum+(Number(t.qty)||0),0);
  const rm=document.getElementById('rp-metrics');rm.style.display='grid';
  rm.innerHTML=`<div class="met"><div class="met-v">${filtered.length}</div><div class="met-l">Total Txns</div></div><div class="met"><div class="met-v" data-style="color:var(--gn)">${inT}</div><div class="met-l">IN Units</div></div><div class="met"><div class="met-v" data-style="color:var(--rd)">${outT}</div><div class="met-l">OUT Units</div></div><div class="met"><div class="met-v">${new Set(filtered.map(t=>String(t.barcode||''))).size}</div><div class="met-l">Unique Items</div></div>`;
}


async function printLabels(){
  if(!lblSel.length){toast('Select items','er');return;}
  const s=getLblSettings(),{w,h,fs,per,copies,showCat,showUnit}=s;
  let labelsHtml='';
  for(const m of lblSel)for(let i=0;i<copies;i++)labelsHtml+=await buildLabelPrintHtml(m,s);
  const sheetW=per*w+(per-1)*2+8;
  const html=`<!DOCTYPE html><html><head><style>*{box-sizing:border-box;margin:0;padding:0}body{background:#fff;font-family:Arial,sans-serif}.grid{display:grid;grid-template-columns:repeat(${per},${w}mm);gap:2mm;padding:4mm;width:${sheetW}mm;background:#fff;justify-content:start}.lbl{width:${w}mm;height:${h}mm;border:1px solid #000;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden;padding:1mm;page-break-inside:avoid;background:#fff}.lbl-name,.lbl-sub,.lbl-bc{text-align:center;white-space:nowrap;width:92%;overflow:hidden;text-overflow:ellipsis;line-height:1.1}.lbl-name{font-weight:bold}.lbl-codes{display:flex;align-items:center;justify-content:center;gap:2mm;margin:0.5mm 0;flex:1;min-height:0;width:100%}.lbl-codes img{object-fit:contain}@media print{@page{size:${sheetW}mm auto;margin:0}body{margin:0}.no-print{display:none!important}.grid{padding:0;gap:0}.lbl{border:1px solid #000 !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}}</style></head><body><div class="grid">${labelsHtml}</div></body></html>`;
  window.printPopupHtml(html);addAudit('PRINT',`Printed ${lblSel.length} label types`,'SYSTEM');
}

// ── Suppliers ──
function canManageSuppliersUI(){return !!cu&&['developer','admin'].includes(cu.role);}
async function saveSupp(){
  if(typeof canRoleAction!=='function'||!canRoleAction('saveSupp'))return;
  const nm=document.getElementById('sp-nm').value.trim();if(!nm){toast('Name is required','er');return;}
  const eid=String(document.getElementById('sp-eid').value||'').trim();
  const email=String(document.getElementById('sp-em').value||'').trim();
  if(!isValidOptionalEmail(email)){toast('Enter a valid supplier email address','er');return;}
  const existing=eid?SP.find(x=>identifiersMatch(x.id,eid)):null;
  if(eid&&!existing){toast('Supplier record not found; reload the list before editing','er');return;}
  const obj={name:nm,contact:document.getElementById('sp-cp').value,phone:document.getElementById('sp-ph').value,email,gst:document.getElementById('sp-gst').value,address:document.getElementById('sp-addr').value,createdAt:existing?.createdAt||new Date().toISOString()};
  obj.id=existing?existing.id:generateUUID();
  try{await dPut('suppliers',obj);SP=await gAll('suppliers');}
  catch(error){console.error('[supplier] save failed',error);toast('Supplier save failed; no success was reported. '+(error.message||''),'er');return;}
  try{await addAudit(eid?'EDIT':'CREATE',(eid?'Edited':'Added')+' supplier: '+nm,'MATERIAL');}
  catch(error){console.error('[supplier] audit write failed',error);toast('Supplier saved, but its audit record could not be written.','er');}
  clrSupp();renderSupp();popSuppSel();toast(eid?'Supplier updated!':'"'+nm+'" added!');
}
function editSupp(id){const s=SP.find(x=>identifiersMatch(x.id,id));if(!s){return;}document.getElementById('sp-eid').value=String(s.id);document.getElementById('sp-nm').value=s.name||'';document.getElementById('sp-cp').value=s.contact||'';document.getElementById('sp-ph').value=s.phone||'';document.getElementById('sp-em').value=s.email||'';document.getElementById('sp-gst').value=s.gst||'';document.getElementById('sp-addr').value=s.address||'';toast('Editing: '+s.name,'inf');}
async function delSupp(id){
  if(typeof canRoleAction!=='function'||!canRoleAction('admin'))return;
  const supplier=SP.find(x=>identifiersMatch(x.id,id));if(!supplier)return;
  if(!confirm('Delete supplier '+String(supplier.name||'')+'?'))return;
  try{await dDel('suppliers',supplier.id);}
  catch(error){console.error('[supplier] delete failed',error);toast('Supplier delete failed; the supplier remains in the list. '+(error.message||''),'er');return;}
  SP=SP.filter(x=>!identifiersMatch(x.id,supplier.id));
  let auditFailed=false;
  try{await addAudit('DELETE','Deleted supplier: '+String(supplier.name||supplier.id),'MATERIAL');}
  catch(error){auditFailed=true;console.error('[supplier] delete audit failed',error);}
  renderSupp();popSuppSel();toast(auditFailed?'Supplier deleted, but the audit record could not be written.':'Supplier deleted');
}
function clrSupp(){document.getElementById('sp-eid').value='';['sp-nm','sp-cp','sp-ph','sp-em','sp-gst','sp-addr'].forEach(id=>document.getElementById(id).value='');}
function renderSupp(){
  const canManage=canManageSuppliersUI();
  const form=document.getElementById('supplier-mutation-card');if(form)form.style.display=canManage?'':'none';
  const hint=document.getElementById('supplier-role-hint');if(hint)hint.style.display=canManage?'none':'block';
  const count=document.getElementById('sp-cnt');if(count)count.textContent=SP.length+' suppliers';
  const tb=document.getElementById('sp-body');if(!tb)return;
  if(!SP.length){tb.innerHTML='<tr><td colspan="6" data-style="text-align:center;color:var(--tx3);padding:16px">No suppliers</td></tr>';return;}
  tb.innerHTML=SP.map(s=>{
    const actions=canManage?`<button class="btn" data-style="padding:3px 6px" data-onclick="editSupp(${eventIdArg(s.id)})">✏</button><button class="btn btn-d" data-style="padding:3px 6px" data-onclick="delSupp(${eventIdArg(s.id)})">🗑</button>`:'—';
    return `<tr><td data-style="font-weight:500">${sanitizeHTML(String(s.name||''))}</td><td>${sanitizeHTML(String(s.contact||'-'))}</td><td class="mono">${sanitizeHTML(String(s.phone||'-'))}</td><td data-style="font-size:10px">${sanitizeHTML(String(s.email||'-'))}</td><td class="mono">${sanitizeHTML(String(s.gst||'-'))}</td><td><div data-style="display:flex;gap:3px">${actions}</div></td></tr>`;
  }).join('');
}

// ── Departments ──
async function saveDept(){
  const nm=document.getElementById('dp-nm').value.trim();if(!nm){toast('Name is required','er');return;}
  const eid=document.getElementById('dp-eid').value;
  const obj={name:nm,code:document.getElementById('dp-cd').value,head:document.getElementById('dp-hd').value,costCenter:document.getElementById('dp-cc').value,email:document.getElementById('dp-em').value,notes:document.getElementById('dp-nt').value,createdAt:new Date().toISOString()};
  if(eid){obj.id=parseInt(eid, 10);}else {obj.id=Date.now();}
  await dPut('departments',obj);DP=await gAll('departments');
  clrDept();renderDept();popDeptSel();toast(eid?'Dept updated!':'"'+nm+'" added!');
}
function editDept(id){const d=DP.find(x=>identifiersMatch(x.id,id));if(!d){return;}document.getElementById('dp-eid').value=id;document.getElementById('dp-nm').value=d.name;document.getElementById('dp-cd').value=d.code||'';document.getElementById('dp-hd').value=d.head||'';document.getElementById('dp-cc').value=d.costCenter||'';document.getElementById('dp-em').value=d.email||'';document.getElementById('dp-nt').value=d.notes||'';toast('Editing: '+d.name,'inf');}
async function delDept(id){if(typeof canRoleAction!=='function'||!canRoleAction('admin'))return;const d=DP.find(x=>identifiersMatch(x.id,id));if(!d||!confirm('Delete?'))return;try{await dDel('departments',d.id);}catch(error){toast('Department delete failed: '+(error.message||''),'er');return;}DP=DP.filter(x=>!identifiersMatch(x.id,d.id));renderDept();popDeptSel();toast('Deleted');}
function clrDept(){document.getElementById('dp-eid').value='';['dp-nm','dp-cd','dp-hd','dp-cc','dp-em','dp-nt'].forEach(id=>document.getElementById(id).value='');}
function renderDept(){
  document.getElementById('dp-cnt').textContent=DP.length+' departments';
  const tb=document.getElementById('dp-body');
  if(!DP.length){tb.innerHTML='<tr><td colspan="6" data-style="text-align:center;color:var(--tx3);padding:16px">No departments</td></tr>';return;}
  // SECURITY FIX: escape free-text department fields before innerHTML.
  tb.innerHTML=DP.map(d=>`<tr><td data-style="font-weight:500">${sanitizeHTML(d.name)}</td><td class="mono">${sanitizeHTML(d.code||'-')}</td><td>${sanitizeHTML(d.head||'-')}</td><td class="mono">${sanitizeHTML(d.costCenter||'-')}</td><td data-style="font-size:10px">${sanitizeHTML(d.email||'-')}</td><td><div data-style="display:flex;gap:3px"><button class="btn" data-style="padding:3px 6px" data-onclick="editDept(${eventIdArg(d.id)})">✏</button><button class="btn btn-d" data-style="padding:3px 6px" data-onclick="delDept(${eventIdArg(d.id)})">🗑</button></div></td></tr>`).join('');
}

// ── Approvals ──
async function renderApprov(){
  const pend=AP.filter(a=>a.status==='pending');const appr=AP.filter(a=>a.status==='approved');const rej=AP.filter(a=>a.status==='rejected');
  document.getElementById('ab').textContent=pend.length;document.getElementById('ab').style.display=pend.length?'':'none';

  // ── Pending tab: checkbox per card + bulk action bar ──
  if(pend.length){
    const cards=pend.map(a=>`
      <div class="appr-c" id="appr-card-${a.id}" data-style="position:relative">
        <label data-style="position:absolute;top:10px;right:10px;display:flex;align-items:center;gap:5px;cursor:pointer;font-size:11px;color:var(--tx2)">
          <input type="checkbox" class="appr-sel-cb" data-id="${a.id}" data-onchange="updateApprovalSelection()">
          Select
        </label>
        <h4>OUT: ${a.itemName}</h4>
        <p>Barcode: ${a.barcode} | Qty: ${a.qty} ${a.unit} | By: ${a.reqByName} | ${new Date(a.time).toLocaleString()}</p>
        <p>Dept: ${sanitizeHTML(String(a.deptName||'-'))} | Person: ${a.person||'-'} | Job: ${a.job||'-'}</p>
        ${a.remarks?`<p>Remarks: ${a.remarks}</p>`:''}
        <div data-style="display:flex;gap:6px;margin-top:8px">
          <button class="btn btn-s" data-onclick="approveReq(${a.id})">✓ Approve</button>
          <button class="btn btn-d" data-onclick="rejectReq(${a.id})">✕ Reject</button>
        </div>
      </div>`).join('');

    const bulkBar=`<div id="appr-bulk-bar" data-style="display:none;margin-bottom:10px;padding:8px 12px;background:var(--bg3);border:1px solid var(--b1);border-radius:var(--r);align-items:center;gap:8px;flex-wrap:wrap">
      <span id="appr-sel-cnt" data-style="font-size:11px;color:var(--tx2);margin-right:4px"></span>
      <button class="btn btn-s" data-onclick="bulkApproveSelected()" data-style="padding:4px 12px;font-size:11px">✓ Approve Selected</button>
      <button class="btn btn-d" data-onclick="bulkRejectSelected()" data-style="padding:4px 12px;font-size:11px">✕ Reject Selected</button>
      <button class="btn" data-onclick="selectAllApprovals()" data-style="padding:4px 12px;font-size:11px">☑ Select All</button>
      <button class="btn" data-onclick="clearApprovalSelection()" data-style="padding:4px 12px;font-size:11px">✕ Clear</button>
    </div>`;
    document.getElementById('pend-list').innerHTML=bulkBar+cards;
  } else {
    document.getElementById('pend-list').innerHTML='<div data-style="color:var(--tx3);padding:20px;text-align:center;font-size:12px">No pending approvals</div>';
  }

  document.getElementById('apprv-list').innerHTML=appr.length?appr.slice().reverse().map(a=>`<div class="card"><p data-style="font-size:11px"><span class="bdg bg">APPROVED</span> <b>${a.itemName}</b> | ${a.qty} ${a.unit} | By: ${a.reqByName} | Approved: ${a.approvedBy||'-'}</p></div>`).join(''):'<div data-style="color:var(--tx3);padding:20px;text-align:center;font-size:12px">No approved</div>';
  document.getElementById('rej-list').innerHTML=rej.length?rej.slice().reverse().map(a=>`<div class="card"><p data-style="font-size:11px"><span class="bdg br">REJECTED</span> <b>${a.itemName}</b> | ${a.qty} ${a.unit} | By: ${a.reqByName}</p></div>`).join(''):'<div data-style="color:var(--tx3);padding:20px;text-align:center;font-size:12px">No rejected</div>';
}
async function approveReq(id){
  const a=AP.find(x=>String(x.id)===String(id));if(!a){return;}
  if(a.status!=='pending'){toast('This request has already been processed','inf');return;}
  const tx=T.find(t=>String(t.id)===String(a.txId));
  let m=M.find(x=>String(x.id)===String(tx?.itemId)) || M.find(x=>x.barcode===a.barcode);if(!m){toast('Material not found','er');return;}
  const qty=Number(a.qty);if(!Number.isFinite(qty)||qty<=0){toast('Invalid approval quantity','er');return;}
  if(qty>Number(m.stock)){toast(`Insufficient stock: ${m.stock} available`,'er');return;}
  const approvedAt=new Date().toISOString();
  if(typeof window.atomicReadModifyWrite!=='function')throw new Error('Atomic stock persistence is unavailable');
  try {
    m=await window.atomicReadModifyWrite('materials',m.id,(current,guards)=>{
      const freshApproval=guards.approval;
      if(!current||Number(current.stock)<qty)throw new Error('Insufficient stock at approval time');
      if(!freshApproval||freshApproval.status!=='pending')throw new Error('This request has already been processed');
      const updated={...current,stock:Number(current.stock)-qty,updatedAt:approvedAt};
      const updatedApproval={...freshApproval,status:'approved',approvedBy:cu.username,approvedAt};
      const freshTx=tx?guards.transaction:null;
      const updatedTx=freshTx?{...freshTx,status:'confirmed'}:null;
      return {record:updated,writes:[{store:'approvals',obj:updatedApproval},...(updatedTx?[{store:'transactions',obj:updatedTx}]:[])]};
    },{guards:[{store:'approvals',key:a.id,name:'approval',validate:record=>record?.status==='pending',errorMessage:'This request has already been processed'},...(tx?[{store:'transactions',key:tx.id,name:'transaction'}]:[])]});
  } catch(error) { toast(error.message||'Approval failed','er'); return; }
  if(tx){
    if (window.centralSync?.submit) {
      try { await window.centralSync.submit({ ...tx, type: 'OUT', status: 'confirmed', itemId: m.id }); }
      catch (error) { tx.status='pending-central'; await dPut('transactions',tx); toast('Approval saved locally; central sync is pending.', 'inf'); }
    }
  }
  [M,AP,T]=await Promise.all([gAll('materials'),gAll('approvals'),gAll('transactions')]);
  addAudit('APPROVAL',`Approved OUT: ${a.itemName} | Qty: ${a.qty}`,'APPROVAL');
  toast(isLowStockMaterial(m)?`⚠ Approved! LOW STOCK: ${m.stock}`:`✓ Approved`,isLowStockMaterial(m)?'er':'ok');
  renderApprov();updateBadges();
}
async function rejectReq(id){
  const a=AP.find(x=>String(x.id)===String(id));if(!a){return;}
  if(a.status!=='pending'){toast('This request has already been processed','inf');return;}
  a.status='rejected';a.rejectedBy=cu.username;a.rejectedAt=new Date().toISOString();await dPut('approvals',a);
  const linked=T.find(t=>String(t.id)===String(a.txId));
  if(linked){linked.status='rejected';linked.rejectedAt=a.rejectedAt;await dPut('transactions',linked);}
  AP=await gAll('approvals');T=await gAll('transactions');
  addAudit('APPROVAL',`Rejected OUT: ${a.itemName}`,'APPROVAL');
  toast('Request rejected','inf');renderApprov();updateBadges();
}

// ── Bulk Approval Helpers ─────────────────────────────────────────────────────
function updateApprovalSelection(){
  const cbs=document.querySelectorAll('.appr-sel-cb:checked');
  const count=cbs.length;
  const bar=document.getElementById('appr-bulk-bar');
  const cnt=document.getElementById('appr-sel-cnt');
  if(bar) {bar.style.display=count>0?'flex':'none';}
  if(cnt) {cnt.textContent=count>0?count+' selected':'';}
}

function selectAllApprovals(){
  document.querySelectorAll('.appr-sel-cb').forEach(cb=>cb.checked=true);
  updateApprovalSelection();
}

function clearApprovalSelection(){
  document.querySelectorAll('.appr-sel-cb').forEach(cb=>cb.checked=false);
  updateApprovalSelection();
}

function _getSelectedApprovalIds(){
  return Array.from(document.querySelectorAll('.appr-sel-cb:checked')).map(cb=>Number(cb.dataset.id));
}

async function bulkApproveSelected(){
  const ids=_getSelectedApprovalIds();
  if(!ids.length){toast('Select at least one request','er');return;}
  if(!confirm(`Approve ${ids.length} selected request(s)?`)) {return;}
  let approved=0,failed=0,lowStockWarns=[];
  for(const id of ids){
    const a=AP.find(x=>x.id===id);
    if(!a||a.status!=='pending'){failed++;continue;}
    const material=M.find(x=>x.barcode===a.barcode);
    if(!material){toast(`Material not found for: ${a.itemName}`,'er');failed++;continue;}
    const qty=Number(a.qty);
    if(!Number.isInteger(qty)||qty<=0){failed++;continue;}
    const tx=T.find(t=>t.id===a.txId);
    const approvedAt=new Date().toISOString();
    let updatedMaterial;
    try{
      if(typeof window.atomicReadModifyWrite!=='function')throw new Error('Atomic stock persistence is unavailable');
      updatedMaterial=await window.atomicReadModifyWrite('materials',material.id,(current,guards)=>{
        const freshApproval=guards.approval;
        if(!current||Number(current.stock)<qty)throw new Error('Insufficient stock');
        if(!freshApproval||freshApproval.status!=='pending')throw new Error('Approval already processed');
        const updated={...current,stock:Number(current.stock)-qty,updatedAt:approvedAt};
        const updatedApproval={...freshApproval,status:'approved',approvedBy:cu.username,approvedAt};
        const freshTx=tx?guards.transaction:null;
        const updatedTx=freshTx?{...freshTx,status:'confirmed'}:null;
        return {record:updated,writes:[{store:'approvals',obj:updatedApproval},...(updatedTx?[{store:'transactions',obj:updatedTx}]:[])]};
      },{guards:[{store:'approvals',key:a.id,name:'approval',validate:record=>record?.status==='pending',errorMessage:'Approval already processed'},...(tx?[{store:'transactions',key:tx.id,name:'transaction'}]:[])]});
    }catch(error){failed++;continue;}
    if(isLowStockMaterial(updatedMaterial)) {lowStockWarns.push(updatedMaterial.name);}
    addAudit('APPROVAL',`Bulk approved OUT: ${a.itemName} | Qty: ${a.qty}`,'APPROVAL');
    approved++;
  }
  [M,AP,T]=await Promise.all([gAll('materials'),gAll('approvals'),gAll('transactions')]);
  renderApprov();updateBadges();
  if(lowStockWarns.length) {toast(`✓ Approved ${approved}. ⚠ Low stock: ${lowStockWarns.join(', ')}`,'er');}
  else if(failed) {toast(`Approved ${approved}, failed ${failed}`,'inf');}
  else {toast(`✓ Approved ${approved} request(s)`);}
}

async function bulkRejectSelected(){
  const ids=_getSelectedApprovalIds();
  if(!ids.length){toast('Select at least one request','er');return;}
  if(!confirm(`Reject ${ids.length} selected request(s)?`)) {return;}
  let rejected=0;
  for(const id of ids){
    const a=AP.find(x=>x.id===id);
    if(!a||a.status!=='pending') {continue;}
    a.status='rejected';a.rejectedBy=cu.username;a.rejectedAt=new Date().toISOString();
    await dPut('approvals',a);
    addAudit('APPROVAL',`Bulk rejected OUT: ${a.itemName}`,'APPROVAL');
    rejected++;
  }
  AP=await gAll('approvals');
  renderApprov();updateBadges();
  toast(`✕ Rejected ${rejected} request(s)`,'inf');
}

// ── Users ──
async function addUser(){
  const nm=document.getElementById('u-nm').value.trim(),un=document.getElementById('u-un').value.trim(),pw=document.getElementById('u-pw').value;
  if(!nm||!un||!pw){toast('Name, Username, and Password are required','er');return;}
  if(!passStrong(pw)){toast('Password must be at least 6 characters and include a letter and a number','er');return;}
  if(U.find(x=>x.username===un)){toast('Username already exists','er');return;}
  const obj={id:Date.now(),name:nm,username:un,passwordHash:await hashPassword(pw),role:document.getElementById('u-rl').value,dept:document.getElementById('u-dp').value,email:document.getElementById('u-em').value,active:true,createdAt:new Date().toISOString(),createdBy:cu.username};
  await dPut('users',obj);U=await gAll('users');
  addAudit('USER',`Created user: ${un} (${obj.role})`,'USER');
  ['u-nm','u-un','u-pw','u-dp','u-em'].forEach(id=>document.getElementById(id).value='');
  renderUsers();toast(`User "${nm}" created!`);
}
async function resetUserPassword(id){const u=U.find(x=>x.id===id);if(!u){toast('User not found','er');return;}const pw=prompt('Enter a new password for '+u.username+' (minimum 6 characters, include a letter and a number):');if(pw===null){return;}if(!passStrong(pw)){toast('Password must be at least 6 characters and include a letter and a number','er');return;}u.passwordHash=await hashPassword(pw);delete u.password;u.updatedAt=new Date().toISOString();await dPut('users',u);U=await gAll('users');addAudit('USER','Reset password for user: '+u.username,'USER');toast('Password reset successfully');}
async function toggleUser(id){const u=U.find(x=>x.id===id);if(!u||u.username===cu.username){toast('Cannot change yourself','er');return;}u.active=!u.active;await dPut('users',u);U=await gAll('users');addAudit('USER',(u.active?'Activated':'Deactivated')+' user: '+u.username,'USER');renderUsers();toast('Updated');}
async function delUser(id){const u=U.find(x=>x.id===id);if(u?.username===cu.username){toast('Cannot delete yourself','er');return;}if(!confirm('Delete?')){return;}await dDel('users',id);U=U.filter(x=>x.id!==id);addAudit('USER','Deleted: '+(u?.username||''),'USER');renderUsers();toast('Deleted');}
function renderUsers(){
  const tb=document.getElementById('u-body');
  if(!U.length){tb.innerHTML='<tr><td colspan="7" data-style="text-align:center;color:var(--tx3);padding:16px">No users</td></tr>';return;}
  const rc={admin:'<span class="bdg bb">Admin</span>',developer:'<span class="bdg ba">Developer</span>',store:'<span class="bdg bg">Store Person</span>',maintenance:'<span class="bdg bt">Maintenance Officer</span>',auditor:'<span class="bdg bp">Auditor</span>',viewer:'<span class="bdg bp">Viewer</span>'};
  // SECURITY FIX: escape user-editable name/username/dept fields.
  tb.innerHTML=U.map(u=>`<tr><td data-style="font-weight:500">${sanitizeHTML(u.name)}</td><td class="mono">${sanitizeHTML(u.username)}</td><td>${rc[u.role]||sanitizeHTML(u.role)}</td><td>${sanitizeHTML(u.dept||'-')}</td><td data-style="font-size:10px">${u.lastLogin?new Date(u.lastLogin).toLocaleString():'-'}</td><td><span class="bdg ${u.active!==false?'bg':'br'}">${u.active!==false?'Active':'Inactive'}</span></td><td><div data-style="display:flex;gap:3px;flex-wrap:wrap"><button class="btn" data-style="padding:3px 6px" data-onclick="openAdminReset(${u.id})" title="Reset Password">🔑 Reset Pw</button><button class="btn" data-style="padding:3px 6px" data-onclick="toggleUser(${u.id})">${u.active!==false?'⏸':'▶'}</button><button class="btn btn-d" data-style="padding:3px 6px" data-onclick="delUser(${u.id})">🗑</button></div></td></tr>`).join('');
}

// ── Audit ──
function filteredAuditRows(){
  const q=String(document.getElementById('srch-aud')?.value||'').trim().toLowerCase();
  const act=String(document.getElementById('flt-aud-act')?.value||'').trim().toLowerCase();
  const ent=String(document.getElementById('flt-aud-ent')?.value||'').trim().toLowerCase();
  const tp=document.getElementById('flt-aud-tp')?.value||'all';const us=document.getElementById('flt-aud-us')?.value||'all';
  const from=document.getElementById('flt-aud-from')?.value||''; const to=document.getElementById('flt-aud-to')?.value||'';
  const fromMs=from?new Date(`${from}T00:00:00`).getTime():null; const toMs=to?new Date(`${to}T23:59:59.999`).getTime():null;
  return (Array.isArray(A)?A:[]).filter(a=>{
    const searchable=[a?.details,a?.action,a?.userName,a?.user,a?.module,a?.entity,a?.entityId,a?.resource,a?.resourceId,a?.itemId,a?.barcode].map(value=>String(value??'').toLowerCase());
    const entityText=[a?.entity,a?.entityId,a?.resource,a?.resourceId,a?.itemId,a?.barcode,a?.details].map(value=>String(value??'').toLowerCase()).join(' ');
    const rawTime=a?.time||a?.timestamp||a?.createdAt; const time=Date.parse(rawTime||'');
    let ok=!q||searchable.some(value=>value.includes(q));
    if(act)ok=ok&&String(a?.action??'').toLowerCase().includes(act);
    if(ent)ok=ok&&entityText.includes(ent);
    if(tp!=='all')ok=ok&&String(a?.module??a?.category??'')===tp;
    if(us!=='all')ok=ok&&String(a?.user??a?.userName??a?.username??'')===us;
    if(fromMs!==null)ok=ok&&Number.isFinite(time)&&time>=fromMs;
    if(toMs!==null)ok=ok&&Number.isFinite(time)&&time<=toMs;
    return ok;
  }).slice().sort((a,b)=>Date.parse(b?.time||b?.timestamp||b?.createdAt||0)-Date.parse(a?.time||a?.timestamp||a?.createdAt||0));
}
function clearAuditFilters(){['srch-aud','flt-aud-act','flt-aud-ent','flt-aud-from','flt-aud-to'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});['flt-aud-tp','flt-aud-us'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='all';});renderAudit();}

function renderAudit(){
  const matching=filteredAuditRows();
  const f=matching.slice(0,300);
  const tb=document.getElementById('aud-body');
  const mc={LOGIN:'bb',MATERIAL:'bp',IN:'bg',OUT:'br',ADJUST:'ba',APPROVAL:'ba',USER:'bb',SYSTEM:'bt'};
  const capNotice=document.getElementById('aud-limit-notice');
  if(capNotice){capNotice.textContent=matching.length>f.length?`Showing newest ${f.length} of ${matching.length} matching entries.`:'';}
  if(!f.length){tb.innerHTML='<tr><td colspan="5" data-style="text-align:center;color:var(--tx3);padding:16px">No entries</td></tr>';return;}
  // SECURITY FIX: audit "details" strings frequently embed user-entered names
  // (materials, suppliers, departments, usernames, etc.) verbatim — escape
  // everything user-controlled before it goes into innerHTML.
  tb.innerHTML=f.map(a=>`<tr><td data-style="font-size:10px;white-space:nowrap">${new Date(a.time||a.timestamp||a.createdAt).toLocaleString()}</td><td data-style="font-weight:500">${sanitizeHTML(a.userName)}</td><td>${sanitizeHTML(a.action)}</td><td data-style="font-size:11px;color:var(--tx2)">${sanitizeHTML(a.details)}</td><td><span class="bdg ${mc[a.module]||'bb'}">${sanitizeHTML(a.module)}</span></td></tr>`).join('');
}

// ── Dashboard ──
// ── Automated Alerts (modules/automatedAlerts.js) ──
// The module's built-in rule-engine (window.AutomatedAlerts.checkRules) uses
// ONE cooldown timer PER RULE, not per material — so it can't correctly
// notice "material A recovered but material B just went low" without a lot
// of rework. Instead we use the module's plain AutomatedAlert data class
// directly and manage per-material dedup/resolution here, which is correct
// for this app's actual need: one active alert per (material, low/out).
let _alertsCheckRunning=false;
async function checkStockAlerts(){
  if(!window.AutomatedAlerts||_alertsCheckRunning){return;}
  _alertsCheckRunning=true;
  try{
    const active=(await gAll('automated_alerts')).filter(a=>a.status==='active'&&a.category==='stock');
    const byMat={};active.forEach(a=>{if(a.data&&a.data.materialId!=null){byMat[a.data.materialId]=a;}});
    const seenMatIds=new Set();
    for(const m of M){
      if(m.active===false){continue;}
      const isOut=Number(m.stock)<=0, isLow=!isOut&&Number(m.stock)<Number(m.lowAlert||0);
      if(!isOut&&!isLow){continue;}
      seenMatIds.add(m.id);
      const existing=byMat[m.id];
      const wantType=isOut?'stock_out':'stock_low', wantSeverity=isOut?'critical':'high';
      if(existing&&existing.data&&existing.data.alertType===wantType){continue;} // already alerted at this level
      if(existing){ // severity changed (low → out) — resolve the old one, raise a new one
        existing.status='resolved';existing.resolvedAt=new Date().toISOString();existing.resolution='Superseded — stock dropped further';
        await dPut('automated_alerts',existing);
      }
      const alert=new AutomatedAlert({type:'inventory',category:'stock',source:'rule',severity:wantSeverity,
        title:(isOut?'Stock Out: ':'Low Stock: ')+m.name,
        message:(isOut?'Stock is at zero.':'Stock ('+m.stock+' '+m.unit+') is below the required level ('+m.lowAlert+' '+m.unit+').'),
        data:{materialId:m.id,materialName:m.name,alertType:wantType,stock:m.stock,lowAlert:m.lowAlert}});
      await dPut('automated_alerts',alert);
      if(window.appLogger){window.appLogger.warn('Stock alert triggered',{material:m.name,type:wantType});}
      // Real desktop OS notification for critical (stock-out) alerts only,
      // via modules/pushNotifications.js — it genuinely checks the browser/
      // Electron Notification API + permission state (see sendNotification()
      // in that file) rather than faking it. Not used for 'low stock' to
      // avoid notification fatigue — only true stock-outs interrupt the user.
      if(isOut&&window.PushNotifications){
        window.PushNotifications.send({type:'error',category:'inventory',title:alert.title,message:'"'+m.name+'" is completely out of stock.',priority:'high'});
      }
      // In-app Notification Center (modules/notificationService.js) — bell
      // dropdown, gated by the Settings → Notification Preferences toggle.
      notifyUser(alert.title,alert.message,'inventory',isOut?'urgent':'high');
    }
    // Auto-resolve alerts for materials that recovered above their threshold
    for(const a of active){
      const mid=a.data&&a.data.materialId;
      if(mid==null||seenMatIds.has(mid)){continue;}
      a.status='resolved';a.resolvedAt=new Date().toISOString();a.resolution='Stock recovered above alert level';
      await dPut('automated_alerts',a);
    }
  }catch(e){
    if(window.errorHandler){window.errorHandler.handleError(e,{type:'stock_alerts',silent:true});}
  }finally{
    _alertsCheckRunning=false;
    renderAlertsPanel();
  }
}

async function renderAlertsPanel(){
  const el=document.getElementById('d-alerts-panel');
  if(!el){return;}
  const now=Date.now();
  const active=(await gAll('automated_alerts')).filter(a=>['active','acknowledged'].includes(a.status)&&(!a.snoozeUntil||new Date(a.snoozeUntil).getTime()<=now)).sort((a,b)=>new Date(b.triggeredAt)-new Date(a.triggeredAt));
  if(!active.length){el.innerHTML='<div data-style="padding:10px;color:var(--gn);font-size:12px">✓ No active alerts</div>';return;}
  el.innerHTML=active.slice(0,10).map(a=>{
    const sevColor=a.severity==='critical'?'var(--rd)':a.severity==='high'?'var(--am)':'var(--tx2)';
    const ackd=a.acknowledgedAt?`<span data-style="font-size:9px;color:var(--tx3)">✓ seen by ${sanitizeHTML(a.acknowledgedBy||'')}</span>`:'';
    return `<div class="alrt" data-style="border-left:3px solid ${sevColor};padding:6px 8px;margin-bottom:4px">
      <div data-style="display:flex;justify-content:space-between;gap:8px">
        <div><b>${sanitizeHTML(a.title||'')}</b><div data-style="font-size:11px;color:var(--tx2)">${sanitizeHTML(a.message||'')}</div><div data-style="font-size:10px;color:var(--tx3)">Assigned: ${sanitizeHTML(a.assignedTo||'Unassigned')} · Due: ${sanitizeHTML(a.dueAt||'Not set')}${a.escalatedAt?' · Escalated':''}</div>${ackd}</div>
        <div data-style="display:flex;gap:4px;flex-shrink:0">
          ${a.acknowledgedAt?'':`<button class="btn" data-style="font-size:10px;padding:2px 6px" data-onclick="ackAlertUI(${JSON.stringify(String(a.id)).replace(/"/g, '&quot;')})">Acknowledge</button>`}<button class="btn" data-style="font-size:10px;padding:2px 6px" data-onclick="assignAlertUI(${JSON.stringify(String(a.id)).replace(/"/g, '&quot;')})">Assign</button><button class="btn" data-style="font-size:10px;padding:2px 6px" data-onclick="snoozeAlertUI(${JSON.stringify(String(a.id)).replace(/"/g, '&quot;')})">Snooze</button><button class="btn" data-style="font-size:10px;padding:2px 6px" data-onclick="setAlertDueUI(${JSON.stringify(String(a.id)).replace(/"/g, '&quot;')})">Due date</button><button class="btn" data-style="font-size:10px;padding:2px 6px" data-onclick="escalateAlertUI(${JSON.stringify(String(a.id)).replace(/"/g, '&quot;')})">Escalate</button>
          <button class="btn" data-style="font-size:10px;padding:2px 6px" data-onclick="resolveAlertUI(${JSON.stringify(String(a.id)).replace(/"/g, '&quot;')})">Resolve</button>
        </div>
      </div></div>`;
  }).join('');
}

async function assignAlertUI(id){const a=await gOne('automated_alerts',id);if(!a){return;}const value=prompt('Assign alert to username:',a.assignedTo||cu?.username||'');if(value===null){return;}a.assignedTo=value.trim();a.updatedAt=new Date().toISOString();await dPut('automated_alerts',a);addAudit('SYSTEM','Assigned alert: '+a.title,'SYSTEM');renderAlertsPanel();}
async function snoozeAlertUI(id){const a=await gOne('automated_alerts',id);if(!a){return;}const minutes=Number(prompt('Snooze for how many minutes?','60'));if(!Number.isFinite(minutes)||minutes<1){return;}a.snoozeUntil=new Date(Date.now()+minutes*60000).toISOString();a.snoozedBy=cu?.username||'unknown';a.snoozedAt=new Date().toISOString();await dPut('automated_alerts',a);renderAlertsPanel();}
async function setAlertDueUI(id){const a=await gOne('automated_alerts',id);if(!a){return;}const due=prompt('Due date (YYYY-MM-DD):',a.dueAt||'');if(due===null||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(due)){return;}a.dueAt=due;await dPut('automated_alerts',a);renderAlertsPanel();}
async function escalateAlertUI(id){const a=await gOne('automated_alerts',id);if(!a){return;}a.escalatedAt=new Date().toISOString();a.escalatedBy=cu?.username||'unknown';a.severity='critical';a.status='active';await dPut('automated_alerts',a);addAudit('SYSTEM','Escalated alert: '+a.title,'SYSTEM');renderAlertsPanel();}
async function ackAlertUI(id){
  const a=await gOne('automated_alerts',id);if(!a){return;}
  a.acknowledgedAt=new Date().toISOString();a.acknowledgedBy=cu?cu.username:'unknown';a.status='acknowledged';
  await dPut('automated_alerts',a);renderAlertsPanel();
}
async function resolveAlertUI(id){
  const a=await gOne('automated_alerts',id);if(!a){return;}
  a.status='resolved';a.resolvedAt=new Date().toISOString();a.resolvedBy=cu?cu.username:'unknown';a.resolution='Manually resolved';
  await dPut('automated_alerts',a);addAudit('SYSTEM','Resolved alert: '+a.title,'SYSTEM');renderAlertsPanel();
}

async function renderSlowMoving(forceRecalc){
  const tb=document.getElementById('slowmoving-body');
  if(!tb){return;}
  if(!window.SmartRecommendations){tb.innerHTML='<tr><td colspan="4" data-style="text-align:center;color:var(--rd)">Recommendations module not loaded</td></tr>';return;}
  tb.innerHTML='<tr><td colspan="4" data-style="text-align:center;color:var(--tx3);padding:12px">Calculating…</td></tr>';
  try{
    // Call the optimization generator directly (not generateAllRecommendations)
    // to skip the reorder/pricing generators — reorder is already covered by
    // the real Reorder/PO page, and pricing needs material.price/cost fields
    // this app doesn't have (internal spares store, not a sales inventory).
    const recs=await window.SmartRecommendations.engine.generateOptimizationRecommendations();
    if(!recs.length){tb.innerHTML='<tr><td colspan="4" data-style="text-align:center;color:var(--gn);padding:12px">✓ No slow-moving or dead stock detected</td></tr>';return;}
    recs.sort((a,b)=>(b.actionData.daysInactive||0)-(a.actionData.daysInactive||0));
    tb.innerHTML=recs.map(r=>{
      const isDead=r.title.startsWith('Dead');
      return `<tr><td>${sanitizeHTML(r.title.replace(/^(Slow-Moving Item|Dead Stock): /,''))}</td><td class="mono">${r.actionData.currentStock}</td><td class="mono">${r.actionData.daysInactive}</td><td><span data-style="color:${isDead?'var(--rd)':'var(--am)'}">${isDead?'⚠ Dead Stock':'🐌 Slow-Moving'}</span></td></tr>`;
    }).join('');
  }catch(e){
    tb.innerHTML='<tr><td colspan="4" data-style="text-align:center;color:var(--rd)">Error: '+sanitizeHTML(e.message)+'</td></tr>';
    if(window.errorHandler){window.errorHandler.handleError(e,{type:'slow_moving_calc',silent:true});}
  }
}

// ── Notification Center (modules/notificationService.js) ──
// createNotification() already emits eventBus.emit('NOTIFICATION', ...) —
// we just needed a UI subscribed to it, which didn't exist. NOTE: the
// Notification class defaults `read: true` unless you explicitly pass
// `read:false` — easy to miss, so notifyUser() always sets it explicitly.
async function notifyUser(title,message,category,priority,eventType){
  if(!window.notificationService){return;}
  if(category==='inventory'&&_notifPrefs.stock===false){return;}
  if(category==='system'&&_notifPrefs.system===false){return;}
  const type=eventType||(/sync/i.test(String(title))?'sync_failure':/out of stock/i.test(String(title))?'stock_out':/low stock/i.test(String(title))?'stock_low':'system');
  try{
    if(window.NotificationPreferences?.init&&cu){
      await window.NotificationPreferences.init();
      const manager=window.NotificationPreferences.manager;
      const targets=[String(cu.username||cu.id||''),`role:${String(cu.role||'')}`];
      const prefs=targets.flatMap(target=>manager.getPreferencesForUser(target).filter(p=>p.eventType===type||p.eventType===category||p.eventType==='all'));
      if(prefs.some(p=>p.enabled===false)){return;}
    }
    await window.notificationService.createNotification({type:priority==='urgent'?'critical':priority==='high'?'warning':'info',
      category:category||'general',eventType:type,title,message,priority:priority||'normal',isGlobal:true,read:false});
  }catch(e){/* non-fatal */}
}
async function notifyAdmins(title,message,data={}){
  if(!window.notificationService){return;}
  try{
    await window.notificationService.createNotification({type:'warning',category:'inventory',title,message,priority:'high',isGlobal:true,audienceRoles:['admin','developer'],data,read:false});
  }catch(e){/* non-fatal */}
}
let _notifPrefs={stock:true,system:true};
async function loadNotifPrefs(){
  try{
    const saved=await gOne('config','notifPrefs').catch(()=>null);
    if(saved){_notifPrefs={stock:saved.stock!==false,system:saved.system!==false};}
  }catch(e){/* use defaults */}
  const sb=document.getElementById('notif-pref-stock'),syb=document.getElementById('notif-pref-system');
  if(sb){sb.checked=_notifPrefs.stock;}
  if(syb){syb.checked=_notifPrefs.system;}
  await renderAlertRecipientPreferences();
}
async function saveNotifPrefs(){
  _notifPrefs={stock:document.getElementById('notif-pref-stock').checked,system:document.getElementById('notif-pref-system').checked};
  await dPut('config',{id:'notifPrefs',..._notifPrefs});
  if(window.NotificationPreferences&&cu){
    window.NotificationPreferences.setUserNotificationPreference(cu.username,'in-app','inventory',_notifPrefs.stock);
    window.NotificationPreferences.setUserNotificationPreference(cu.username,'in-app','system',_notifPrefs.system);
  }
  toast('Notification preferences saved');
}
async function renderAlertRecipientPreferences(){
  const el=document.getElementById('alert-recipient-pref-list');
  if(!el)return;
  if(window.NotificationPreferences?.init)await window.NotificationPreferences.init();
  const manager=window.NotificationPreferences?.manager;
  if(!manager||!cu){el.textContent='Per-alert preferences are unavailable until the notification service is ready.';return;}
  const userKey=String(cu.username||cu.id||'');
  const prefs=[...manager.getPreferencesForUser(userKey),...manager.getPreferencesForUser(`role:${String(cu.role||'')}`)];
  if(!prefs.length){el.textContent='No per-alert preferences saved; matching rule recipients are allowed by default.';return;}
  el.innerHTML=prefs.map(p=>`<div>${sanitizeHTML(String(p.eventType||'all'))} · ${sanitizeHTML(String(p.channel||''))} · ${p.userId?.startsWith('role:')?'Role '+sanitizeHTML(String(p.userId).slice(5)):'My account'}: <strong>${p.enabled?'Enabled':'Disabled'}</strong></div>`).join('');
}
async function saveAlertRecipientPreference(){
  const manager=window.NotificationPreferences;
  const userId=String(cu?.username||cu?.id||'');
  if(!manager||!userId){toast('Sign in to save per-alert preferences.','er');return;}
  const eventType=document.getElementById('alert-pref-event')?.value||'';
  const channel=document.getElementById('alert-pref-channel')?.value||'in-app';
  const enabled=Boolean(document.getElementById('alert-pref-enabled')?.checked);
  const scope=document.getElementById('alert-pref-scope')?.value||'user';
  const role=document.getElementById('alert-pref-role')?.value||cu?.role||'viewer';
  const target=scope==='role'?`role:${role}`:userId;
  try{
    const preferenceOptions={category:eventType==='stock_low'||eventType==='stock_out'?'inventory':'system',scope,role};
    if(scope==='user'){
      await manager.setUserNotificationPreference(userId,channel,eventType,enabled,preferenceOptions);
    }else{
      await manager.setUserNotificationPreference(target,channel,eventType,enabled,preferenceOptions);
    }
    await renderAlertRecipientPreferences();
    toast(`Saved ${eventType} preference for ${channel}.`);
  }catch(error){toast(`Preference not saved. ${error.message||''}`,'er');}
}
// modules/pushNotifications.js's sendNotification() only DISPLAYS a desktop
// notification when Notification.permission is already 'granted' — it never
// requests permission itself, so without this, permission would stay
// 'default' forever and PushNotifications.send() would silently never show
// anything. This requests it once, up front, so the real feature actually
// works instead of silently doing nothing.
function requestDesktopNotificationPermission(){
  try{
    if(typeof Notification!=='undefined'&&Notification.permission==='default'){
      Notification.requestPermission();
    }
  }catch(e){/* not fatal — some environments don't support this */}
}

let _notifDropdownOpen=false;
function isNotificationVisibleToCurrentUser(n){
  if(!n||!cu){return false;}
  const roleVisible=!Array.isArray(n.audienceRoles)||n.audienceRoles.includes(cu.role);
  const userVisible=n.userId===undefined||n.userId===null||String(n.userId)===String(cu.id);
  return roleVisible&&userVisible;
}
function toggleNotifDropdown(){
  _notifDropdownOpen=!_notifDropdownOpen;
  document.getElementById('notif-dropdown').style.display=_notifDropdownOpen?'block':'none';
  if(_notifDropdownOpen){renderNotifDropdown();}
}
async function renderNotifDropdown(){
  if(!window.notificationService){document.getElementById('notif-list').innerHTML='<div data-style="padding:10px;font-size:11px;color:var(--tx3)">Not available</div>';return;}
  const all=(await gAll('notifications')).filter(isNotificationVisibleToCurrentUser).sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0)).slice(0,20);
  const list=document.getElementById('notif-list');
  if(!all.length){list.innerHTML='<div data-style="padding:14px;text-align:center;color:var(--tx3);font-size:11px">No notifications yet</div>';return;}
  list.innerHTML=all.map(n=>{
    const color=n.type==='critical'?'var(--rd)':n.type==='warning'?'var(--am)':'var(--tx2)';
    return `<div data-onclick="markNotifRead('${n.id}')" data-style="padding:8px 10px;border-bottom:1px solid var(--b2);cursor:pointer;${n.read?'opacity:0.55':''}">
      <div data-style="display:flex;gap:6px;align-items:flex-start"><span data-style="width:6px;height:6px;border-radius:50%;background:${color};margin-top:5px;flex-shrink:0"></span>
      <div><b data-style="font-size:11px">${sanitizeHTML(n.title||'')}</b><div data-style="font-size:10px;color:var(--tx2)">${sanitizeHTML(n.message||'')}</div>
      <div data-style="font-size:9px;color:var(--tx3)">${n.createdAt?new Date(n.createdAt).toLocaleString():''}</div></div></div></div>`;
  }).join('');
  updateNotifBadge(all);
}
function updateNotifBadge(all){
  const b=document.getElementById('notif-badge');if(!b){return;}
  const unread=all.filter(n=>!n.read).length;
  b.textContent=unread;b.style.display=unread?'':'none';
}
async function markNotifRead(id){
  const n=await gOne('notifications',id);if(!n){return;}
  if(!isNotificationVisibleToCurrentUser(n)){return;}
  n.read=true;n.readAt=new Date().toISOString();await dPut('notifications',n);
  renderNotifDropdown();
}
async function markAllNotifsRead(){
  const all=await gAll('notifications');
  for(const n of all){if(!n.read&&isNotificationVisibleToCurrentUser(n)){n.read=true;n.readAt=new Date().toISOString();await dPut('notifications',n);}}
  renderNotifDropdown();
}
if(window.eventBus){
  window.eventBus.on('NOTIFICATION',()=>{ if(_notifDropdownOpen){renderNotifDropdown();} else {gAll('notifications').then(all=>updateNotifBadge(all.filter(isNotificationVisibleToCurrentUser)));} });
}

async function renderSupplierPerformanceDashboard() {
  const summary = document.getElementById('supplier-performance-summary');
  const ranking = document.getElementById('supplier-performance-ranking');
  const scorecards = document.getElementById('supplier-scorecards');
  if (!summary && !ranking && !scorecards) {return;}
  try {
    if (window.SupplierPerformanceTracking?.init) {
      await window.SupplierPerformanceTracking.init();
    }
    const manager = window.SupplierPerformanceTracking?.manager;
    const calculateSupplierMetric = manager && typeof manager.calculateMetrics === 'function'
      ? supplierId => manager.calculateMetrics(supplierId)
      : window.SupplierPerformanceTracking?.calculateMetrics;
    if (typeof calculateSupplierMetric !== 'function') {return;}
    const metrics = await Promise.all(SP.map(async supplier => {
      try { return await calculateSupplierMetric(supplier.id); } catch (error) { console.error('[Supplier] Metric calculation failed:', error); return null; }
    }));
    const rows = SP.map((supplier, index) => {
      const metric = metrics[index] || {};
      const score = Number(metric.score ?? metric.overallScore ?? 0);
      const onTime = Number(metric.onTimeDeliveryRate ?? metric.onTimeRate ?? 0) * (metric.onTimeDeliveryRate <= 1 ? 100 : 1);
      const quality = Number(metric.qualityRate ?? 0) * (metric.qualityRate <= 1 ? 100 : 1);
      const fillRate = Number.isFinite(Number(metric.fillRate)) ? `${(Number(metric.fillRate) * 100).toFixed(1)}%` : 'Insufficient data';
      const responseTime = Number.isFinite(Number(metric.responseTime)) ? `${Number(metric.responseTime).toFixed(1)} h` : 'Insufficient data';
      const complaints = Number.isFinite(Number(metric.complaints)) ? String(Number(metric.complaints)) : 'Insufficient data';
      return { supplier, score, onTime, quality, fillRate, responseTime, complaints };
    }).sort((a, b) => b.score - a.score);
    if (summary) {
      const avg = rows.length ? rows.reduce((total, row) => total + row.score, 0) / rows.length : 0;
      summary.innerHTML = `<div class="g4"><div class="met"><div class="met-v" data-style="color:var(--primary)">${rows.length}</div><div class="met-l">Tracked Suppliers</div></div><div class="met"><div class="met-v" data-style="color:var(--success)">${avg.toFixed(1)}</div><div class="met-l">Average Score</div></div><div class="met"><div class="met-v" data-style="color:var(--warning)">${rows.filter(row => row.score < 60).length}</div><div class="met-l">Needs Review</div></div><div class="met"><div class="met-v" data-style="color:var(--primary)">${rows.filter(row => row.score >= 80).length}</div><div class="met-l">Top Performers</div></div></div>`;
    }
    if (ranking) {
      ranking.innerHTML = rows.length ? rows.slice(0, 10).map((row, index) => `<tr><td>${index + 1}</td><td>${sanitizeHTML(row.supplier.name || 'Unnamed supplier')}</td><td>${row.score.toFixed(1)}</td><td>${row.onTime.toFixed(1)}%</td><td>${row.quality.toFixed(1)}%</td></tr>`).join('') : '<tr><td colspan="5" data-style="text-align:center;color:var(--tx3);padding:16px">No supplier metrics available</td></tr>';
    }
    if (scorecards) {
      scorecards.innerHTML = rows.length ? rows.slice(0, 6).map(row => `<div data-style="padding:10px;border:1px solid var(--bd);border-radius:8px"><div data-style="display:flex;justify-content:space-between"><b>${sanitizeHTML(row.supplier.name || 'Unnamed supplier')}</b><b data-style="color:${row.score >= 80 ? 'var(--success)' : row.score >= 60 ? 'var(--warning)' : 'var(--danger)'}">${row.score.toFixed(1)}</b></div><div data-style="font-size:11px;color:var(--tx3);margin-top:4px">On-time ${row.onTime.toFixed(1)}% · Quality ${row.quality.toFixed(1)}% · Fill ${row.fillRate} · Response ${row.responseTime} · Complaints ${row.complaints}</div></div>`).join('') : '<div data-style="padding:16px;color:var(--tx3)">Add supplier performance records to populate scorecards.</div>';
    }
  } catch (error) {
    console.error('[Supplier] Dashboard render failed:', error);
    if (summary) {summary.innerHTML = '<div data-style="padding:12px;color:var(--danger)">Supplier performance unavailable</div>';}
  }
}

let _intelligenceRefreshPromise = null;
async function refreshIntegratedIntelligence() {
  if (_intelligenceRefreshPromise) {return _intelligenceRefreshPromise;}
  _intelligenceRefreshPromise = (async () => {
    try {
      if (window.DashboardWidgets) {
        await window.DashboardWidgets.init();
        await window.DashboardWidgets.refreshAll?.();
      }
      await renderBIDashboard();
      await renderSupplierPerformanceDashboard();
    } catch (error) {
      console.error('[Integration] Dashboard intelligence refresh failed:', error);
    } finally {
      _intelligenceRefreshPromise = null;
    }
  })();
  return _intelligenceRefreshPromise;
}

function updateDash(){
  syncAppStateSnapshot();
  checkStockAlerts();
  refreshIntegratedIntelligence();
  document.getElementById('d-tot').textContent=M.filter(m=>m.active!==false).length;
  const today=new Date().toDateString();
  const inT=T.filter(t=>isCompletedMovement(t)&&t.type==='IN'&&new Date(t.time).toDateString()===today).reduce((s,t)=>s+Number(t.qty||0),0);
  const outT=T.filter(t=>isCompletedMovement(t)&&t.type==='OUT'&&new Date(t.time).toDateString()===today).reduce((s,t)=>s+Number(t.qty||0),0);
  const low=M.filter(isLowStockMaterial);
  document.getElementById('d-in').textContent=inT;document.getElementById('d-out').textContent=outT;document.getElementById('d-low').textContent=low.length;
  document.getElementById('d-alrts').innerHTML=low.slice(0,3).map(m=>`<div class="alrt alrt-${m.stock===0?'r':'a'}">⚠ <b>${m.name}</b> — Stock: ${m.stock} ${m.unit} (Alert: ${m.lowAlert})</div>`).join('');
  const rec=sortTransactionsNewestFirst(T.filter(isCompletedMovement)).slice(0,8);
  document.getElementById('d-rec').innerHTML=rec.length?rec.map(t=>`<tr><td data-style="font-size:10px">${new Date(t.time).toLocaleTimeString()}</td><td>${t.itemName}</td><td><span class="bdg ${t.type==='IN'?'bg':'br'}">${t.type}</span></td><td class="mono">${t.type==='IN'?'+':'-'}${t.qty} ${t.unit}</td><td>${t.userName||'-'}</td></tr>`).join(''):'<tr><td colspan="5" data-style="text-align:center;color:var(--tx3);padding:16px">No transactions</td></tr>';
  const pend=AP.filter(a=>a.status==='pending');const da=document.getElementById('dash-appr');
  if(pend.length&&cu?.role==='admin'){da.style.display='';document.getElementById('dash-appr-list').innerHTML=pend.slice(0,3).map(a=>`<div class="appr-c"><h4>OUT: ${a.itemName}</h4><p>Qty: ${a.qty} | By: ${a.reqByName}</p><div data-style="display:flex;gap:5px;margin-top:6px"><button class="btn btn-s" data-onclick="approveReq(${a.id});updateDash()">✓</button><button class="btn btn-d" data-onclick="rejectReq(${a.id});updateDash()">✕</button></div></div>`).join('');}else {da.style.display='none';}
  const cnt={};T.filter(isCompletedMovement).forEach(t=>{const name=String(t.itemName||'Unknown item');cnt[name]=(cnt[name]||0)+Number(t.qty||0);});
  document.getElementById('d-top').innerHTML=Object.entries(cnt).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([n,q])=>`<div data-style="display:flex;align-items:center;gap:7px;margin-bottom:7px"><span data-style="flex:1;font-size:12px">${n}</span><span class="mono" data-style="color:var(--tx2)">${q}</span></div>`).join('')||'<p data-style="color:var(--tx3);font-size:11px">No data</p>';
}
function updateBadges(){
  const low=M.filter(isLowStockMaterial).length;
  document.getElementById('lb').textContent=low;document.getElementById('lb').style.display=low?'':'none';
  const pend=AP.filter(a=>a.status==='pending').length;
  document.getElementById('ab').textContent=pend;document.getElementById('ab').style.display=pend?'':'none';
  const top=document.getElementById('top-low-count');
  if(top){top.textContent=low;top.style.display=low?'':'none';}
  const indPend=IN_REQ.filter(x=>x.status==='pending').length;
  const inb=document.getElementById('inb');if(inb){inb.textContent=indPend;inb.style.display=indPend?'':'none';}
}

// ── CSV Export/Import ──
function downloadSampleCSV(){
  const rows=[['Barcode','Name','Category','Unit','Stock','Low Alert','Suggested Order Qty','HSN'],['AUTO','Sample Material','General','Pcs','0','10','10','']];
  const csv=rows.map(r=>r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');
  // FIX #4: Revoke object URL after download to prevent memory leak
  const _sampleUrl=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  const a=document.createElement('a');a.href=_sampleUrl;a.download='material_import_sample.csv';a.click();
  setTimeout(()=>URL.revokeObjectURL(_sampleUrl),1000);toast('Sample CSV downloaded');
}
function _exportCSVCore(type){
  const d=new Date().toISOString().slice(0,10);let rows=[],fn='';
  if(type==='master'){fn=`materials_${d}.csv`;rows=[['Barcode','Name','Category','Unit','Stock','Low Alert','Suggested Order Qty','HSN','Location','Bin Location ID','Status']];M.forEach(m=>rows.push([m.barcode,m.name,m.category,m.unit,m.stock,m.lowAlert,suggestedOrderQty(m),m.hsn||'',m.location||'',m.binLocationId||'',m.active!==false?'Active':'Inactive']));}
  else if(type==='stock'){fn=`stock_${d}.csv`;rows=[['Barcode','Name','Category','Unit','Stock','Low Alert','Status']];M.filter(m=>m.active!==false).forEach(m=>rows.push([m.barcode,m.name,m.category,m.unit,m.stock,m.lowAlert,m.stock<=0?'OUT':m.stock<m.lowAlert?'LOW':'OK']));}
  else if(type==='history'){fn=`history_${d}.csv`;rows=[['DateTime','Barcode','Item','Type','Qty','Unit','Supplier','Dept','PO','Invoice','Job No','By','Status']];historyFilteredTransactions().forEach(t=>rows.push([new Date(t.time).toLocaleString(),t.barcode,t.itemName,t.type,t.qty,t.unit,t.supplierName||'',t.deptName||'',t.po||'',t.invoice||'',t.job||'',t.userName||'',t.status||'']));}
  else if(type==='lowstock'){fn=`lowstock_${d}.csv`;rows=[['Barcode','Name','Category','Unit','Stock','Required Qty','Suggested Order Qty','Status']];lowItems().forEach(m=>{const stock=numericStockValue(m.stock)||0,alert=numericStockValue(m.lowAlert)||0;rows.push([m.barcode,m.name,m.category,m.unit,stock,alert,suggestedOrderQty(m),isZeroStockMaterial(m)?'OUT':'LOW']);});}
  else if(type==='audit'){
    if(typeof canRoleAction==='function' && (!canRoleAction('auditTrail') || !canRoleAction('pdfExcelExport'))){toast('Permission denied: audit export','er');return;}
    const matching=filteredAuditRows();
    if(!matching.length){toast('No audit entries match the current filters','inf');return;}
    const sample=matching.slice(0,3).map(a=>`${new Date(a?.time||0).toLocaleString()} | ${a?.action||''} | ${a?.userName||a?.user||''} | ${a?.details||''}`);
    const preview=`Audit CSV export preview\n\nMatching entries: ${matching.length}\nExport scope: all matching entries (the screen may show only the newest 300).\n\n${sample.join('\n')}${matching.length>3?'\n…':''}\n\nContinue with CSV download?`;
    if(!confirm(preview)){return;}
    fn=`audit_${d}.csv`;rows=[['DateTime','User','Action','Details','Module']];matching.forEach(a=>rows.push([new Date(a?.time||0).toLocaleString(),a?.userName||a?.user||'',a?.action||'',a?.details||'',a?.module||'']));
  }
  else if(type==='supp'){fn=`suppliers_${d}.csv`;rows=[['Name','Contact','Phone','Email','GST','Address']];SP.forEach(s=>rows.push([s.name,s.contact||'',s.phone||'',s.email||'',s.gst||'',s.address||'']));}
  else if(type==='report'){
    if(!rpData.length){toast('Generate a report first','er');return;}
    const reportType=document.getElementById('rp-type')?.value||'summary';
    fn=`report_${reportType}_${d}.csv`;rows=reportExportRows(reportType,rpData);
    const preview=`Report export preview\n\nType: ${reportType}\nRows in selected report: ${Math.max(0,rows.length-1)}\nFilters: ${document.getElementById('rp-site')?.value||'all sites'} · ${document.getElementById('rp-part')?.value||'all parts'} · ${document.getElementById('rp-supp')?.value||'all suppliers'}\n\nThe CSV will contain the generated report projection, not unfiltered raw records.\n\nContinue with CSV download?`;
    if(!confirm(preview)){return;}
  }
  const csv=serializeCSVRows(rows);
  // FIX #4: Revoke object URL after 1 s to prevent browser memory leak
  const _csvUrl=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  const a=document.createElement('a');a.href=_csvUrl;a.download=fn;a.click();
  setTimeout(()=>URL.revokeObjectURL(_csvUrl),1000);
  toast('Exported: '+fn);
}
function parseImportCSV(text){
  const rows=[];let row=[],cell='',quoted=false;
  for(let i=0;i<String(text).length;i++){
    const ch=String(text)[i];
    if(quoted){if(ch==='"'&&String(text)[i+1]==='"'){cell+='"';i++;}else if(ch==='"'){quoted=false;}else{cell+=ch;}continue;}
    if(ch==='"'){quoted=true;}else if(ch===','){row.push(cell);cell='';}else if(ch==='\n'||ch==='\r'){if(ch==='\r'&&String(text)[i+1]==='\n'){i++;}row.push(cell);cell='';if(row.some(value=>String(value).trim()!=='')){rows.push(row);}row=[];}else{cell+=ch;}
  }
  if(quoted){throw new Error('CSV contains an unclosed quoted field');}
  row.push(cell);if(row.some(value=>String(value).trim()!=='')){rows.push(row);}
  return rows;
}
async function importCSV(e){
  const f=e?.target?.files?.[0];if(!f){return;}
  const progress=document.getElementById('csv-import-progress');
  const label=document.getElementById('csv-import-progress-text');
  const bar=document.getElementById('csv-import-progress-bar');
  const setStatus=(text,value,max)=>{if(progress){progress.style.display='';}if(label){label.textContent=text;}if(bar){bar.max=Math.max(1,max||1);bar.value=Math.max(0,value||0);}};
  const reader=new FileReader();
  reader.onerror=()=>{setStatus('Could not read CSV file. No rows were imported.',0,1);toast('CSV read failed','er');};
  reader.onload=async ev=>{
    let rows;
    try{rows=parseImportCSV(ev.target.result);}catch(error){setStatus(`CSV preview failed: ${error.message}. No rows were imported.`,0,1);toast(error.message,'er');return;}
    if(rows.length<2){setStatus('CSV must contain a header row and at least one data row. No rows were imported.',0,1);toast('CSV has no importable rows','er');return;}
    const headers=rows[0].map(value=>String(value).trim().toLowerCase());
    const col=(record,names,fallback)=>{for(const name of names){const index=headers.indexOf(name);if(index>=0)return String(record[index]??'').trim();}return String(record[fallback]??'').trim();};
    const existing=new Set(M.map(material=>String(material.barcode||'').trim().toLowerCase()).filter(Boolean));
    const seen=new Set();const validRows=[],invalidRows=[],duplicateRows=[];
    rows.slice(1).forEach((record,index)=>{
      const line=index+2;const barcode=col(record,['barcode'],0);const name=col(record,['name','item name'],1);
      if(!barcode||!name){invalidRows.push({line,reason:'Barcode and name are required'});return;}
      const key=barcode.toLowerCase();if(existing.has(key)||seen.has(key)){duplicateRows.push({line,barcode,reason:seen.has(key)?'Duplicate barcode in CSV':'Barcode already exists'});return;}
      const rawStock=col(record,['stock'],4)||'0';const rawLow=col(record,['low alert','lowalert'],5)||'10';const rawReorder=col(record,['suggested order qty','reorder qty'],6)||'0';
      const stock=Number(rawStock),lowAlert=Number(rawLow),reorderQty=Number(rawReorder);
      if(!Number.isFinite(stock)||stock<0||!Number.isInteger(stock)||!Number.isFinite(lowAlert)||lowAlert<0||!Number.isFinite(reorderQty)||reorderQty<0){invalidRows.push({line,reason:'Stock/alert/reorder quantities must be non-negative; stock must be a whole number'});return;}
      seen.add(key);validRows.push({id:generateUUID(),barcode,name,category:col(record,['category'],2)||'General',unit:col(record,['unit'],3)||'Pcs',stock,lowAlert,reorderQty,hsn:col(record,['hsn'],7),active:true,photo:null,createdAt:new Date().toISOString()});
    });
    const rowCount=rows.length-1;const examples=[...invalidRows.slice(0,3).map(item=>`line ${item.line}: ${item.reason}`),...duplicateRows.slice(0,3).map(item=>`line ${item.line}: ${item.barcode} — ${item.reason}`)];
    const summary=`Material CSV import preview\n\nRows read: ${rowCount}\nReady to add: ${validRows.length}\nInvalid rows: ${invalidRows.length}\nDuplicate rows: ${duplicateRows.length}${examples.length?`\n\nExamples:\n${examples.join('\n')}`:''}\n\nOnly valid new rows will be added. Existing materials will not be overwritten.`;
    if(!validRows.length){setStatus(`Preview complete: 0 ready, ${invalidRows.length} invalid, ${duplicateRows.length} duplicates. No writes made.`,0,1);toast('No valid new materials to import','inf');return;}
    if(!confirm(summary+'\n\nImport the valid rows now?')){setStatus(`Preview canceled: ${validRows.length} rows ready; no writes made.`,0,validRows.length);return;}
    setStatus(`Importing 0 of ${validRows.length} materials…`,0,validRows.length);
    let count=0;
    try{
      for(let i=0;i<validRows.length;i++){
        await dPut('materials',validRows[i]);count++;
        if((i+1)%25===0){setStatus(`Importing ${i+1} of ${validRows.length} materials…`,i+1,validRows.length);await new Promise(resolve=>setTimeout(resolve,0));}
      }
      M=await gAll('materials');
      addAudit('IMPORT',`CSV import: ${count} materials added, ${invalidRows.length} invalid and ${duplicateRows.length} duplicate rows skipped`,'MATERIAL');
      renderMaster();updateBadges();setStatus(`Import complete: ${count} added, ${invalidRows.length} invalid and ${duplicateRows.length} duplicate rows skipped.`,validRows.length,validRows.length);
      toast(`${count} imported${duplicateRows.length?`, ${duplicateRows.length} duplicates skipped`:''}${invalidRows.length?`, ${invalidRows.length} invalid rows skipped`:''}`);
    }catch(error){
      M=await gAll('materials').catch(()=>M);
      setStatus(`Import stopped after ${count} of ${validRows.length} rows. Check the material list before retrying; completed rows may already be saved. Error: ${error.message}`,count,validRows.length);
      toast(`Import stopped after ${count} rows; verify saved materials before retrying.`,'er');
    }
  };
  reader.readAsText(f);e.target.value='';
}

// ── Backup / Restore ──
function snapshotLocalData(){
  return {M:[...M],T:[...T],U:[...U],A:[...A],AP:[...AP],ADJ:[...ADJ],SP:[...SP],DP:[...DP],CFG:{...CFG},IN_REQ:[...IN_REQ],RET:[...RET],CC:[...CC],GRN:[...GRN],LOCS:[...LOCS],MOVS:[...MOVS]};
}
async function restoreLocalSnapshot(snap){
  const map={materials:snap.M,transactions:snap.T,users:snap.U,audit:snap.A,approvals:snap.AP,adjustments:snap.ADJ,suppliers:snap.SP,departments:snap.DP,config:[snap.CFG].filter(x=>x&&Object.keys(x).length),indents:snap.IN_REQ,returns:snap.RET,cyclecount:snap.CC,grn:snap.GRN,locations:snap.LOCS,movements:snap.MOVS};
  for(const [store,rows] of Object.entries(map)){await dClr(store);for(const row of rows){await dPut(store,row);}}
  M=snap.M;T=snap.T;U=snap.U;A=snap.A;AP=snap.AP;ADJ=snap.ADJ;SP=snap.SP;DP=snap.DP;CFG=snap.CFG;IN_REQ=snap.IN_REQ;RET=snap.RET;CC=snap.CC;GRN=snap.GRN;LOCS=snap.LOCS;MOVS=snap.MOVS;
}
const STS = [
  'materials',
  'transactions',
  'users',
  'audit'
];
// ── System Diagnostics Panel (core/ infrastructure UI) ──
// Reads live data from window.logger, window.errorHandler, window.eventBus,
// window.configManager, window.stateManager. Admin-only, same pattern as the
// rest of the app's admin-gated sections.
let _diagEventFeedWired=false;
const _diagEventLog=[];

// ── Real DB Benchmark (honest substitute for modules/performanceTesting.js)
// That file's actual test runner is fake: simulateRequest() just does
// `await new Promise(r=>setTimeout(r, 50 + Math.random()*200))` against a
// REST endpoint ('/api/materials') this Electron app doesn't even have — no
// HTTP server exists here at all (confirmed in the full audit). Rather than
// wire a fake timer into the UI, this measures REAL IndexedDB read/write
// timing using performance.now(), on a real scratch record, and reports the
// result through modules/performanceMonitor.js (already wired elsewhere).
async function runDbBenchmark(){
  const el=document.getElementById('diag-benchmark');
  el.textContent='Running…';
  const ITER=50;
  const testStore='config'; // safe, low-risk store; uses a scratch id that won't collide with real config (id:1)
  const scratchId='__benchmark_scratch__';
  try{
    // Write benchmark
    const t0=performance.now();
    for(let i=0;i<ITER;i++){await dPut(testStore,{id:scratchId,i,ts:Date.now()});}
    const writeMs=(performance.now()-t0)/ITER;
    // Read benchmark
    const t1=performance.now();
    for(let i=0;i<ITER;i++){await gOne(testStore,scratchId);}
    const readMs=(performance.now()-t1)/ITER;
    // Bulk read benchmark (realistic — this is what most pages actually do)
    const t2=performance.now();
    await gAll('materials');
    const bulkReadMs=performance.now()-t2;
    await dDel(testStore,scratchId); // clean up scratch record
    el.innerHTML=`<div class="g4">
      <div class="met"><div class="met-v" data-style="font-size:15px">${writeMs.toFixed(2)}ms</div><div class="met-l">Avg Write</div></div>
      <div class="met"><div class="met-v" data-style="font-size:15px">${readMs.toFixed(2)}ms</div><div class="met-l">Avg Read (by id)</div></div>
      <div class="met"><div class="met-v" data-style="font-size:15px">${bulkReadMs.toFixed(2)}ms</div><div class="met-l">gAll('materials') (${M.length} rows)</div></div>
      <div class="met"><div class="met-v" data-style="font-size:15px">${ITER}</div><div class="met-l">Iterations</div></div>
    </div>`;
    if(window.performanceMonitor){
      window.performanceMonitor.recordMetric({name:'db_benchmark_write',type:'custom',value:writeMs,unit:'ms'});
      window.performanceMonitor.recordMetric({name:'db_benchmark_read',type:'custom',value:readMs,unit:'ms'});
      window.performanceMonitor.recordMetric({name:'db_benchmark_bulk_read',type:'custom',value:bulkReadMs,unit:'ms'});
    }
    if(window.appLogger){window.appLogger.info('DB benchmark run',{writeMs,readMs,bulkReadMs});}
  }catch(e){
    el.textContent='Benchmark failed: '+e.message;
    if(window.errorHandler){window.errorHandler.handleError(e,{type:'db_benchmark',silent:true});}
  }
}

function diagInit(){
  if(!cu||cu.role!=='admin'){toast('Admin access required','er');nav('dash');return;}
  if(!window.logger||!window.errorHandler||!window.eventBus||!window.configManager||!window.stateManager){
    document.getElementById('diag-stats').innerHTML='<div class="met"><div class="met-v" data-style="font-size:13px;color:var(--rd)">core/ modules not loaded</div></div>';
    return;
  }
  diagRenderStats();
  diagRenderLogs();
  diagRenderErrors();
  diagRenderConfig();
  diagRenderState();
  diagWireEventFeed();
  diagRenderEventFeed();
  refreshUnmappedStockAlerts();
  diagRenderSystemHealth();
}

/**
 * Real system health metrics — deliberately NOT using modules/diagnostics.js,
 * whose CPU/RAM/disk "collectors" call Math.random() (see comments in that
 * file: "Simulate ... in production, use actual API"). Faking these numbers
 * would be worse than not showing them. Everything below is a genuine,
 * verifiable browser/Electron API — memory usage from performance.memory
 * (Chromium-specific but real), storage estimate from the standard
 * navigator.storage.estimate(), and LAN sync status from the actual
 * storeSync bridge that's already wired to real functionality.
 */
async function diagRenderSystemHealth(){
  const el=document.getElementById('diag-health');
  if(!el){return;}
  const rows=[];
  if(performance.memory){
    const used=(performance.memory.usedJSHeapSize/1048576).toFixed(1);
    const limit=(performance.memory.jsHeapSizeLimit/1048576).toFixed(0);
    rows.push(`<div class="met"><div class="met-v" data-style="font-size:15px">${used} MB</div><div class="met-l">Renderer Memory (of ${limit} MB limit)</div></div>`);
  }
  if(navigator.storage&&navigator.storage.estimate){
    try{
      const est=await navigator.storage.estimate();
      const usedMB=((est.usage||0)/1048576).toFixed(1);
      const quotaMB=((est.quota||0)/1048576/1024).toFixed(1);
      rows.push(`<div class="met"><div class="met-v" data-style="font-size:15px">${usedMB} MB</div><div class="met-l">Local Storage Used (of ~${quotaMB} GB available)</div></div>`);
    }catch(e){/* not fatal — just skip this metric */}
  }
  if(window.storeSync){
    try{
      const h=await window.storeSync.health();
      rows.push(`<div class="met"><div class="met-v" data-style="font-size:15px;color:${h.online?'var(--gn)':'var(--rd)'}">${h.online?'✓ Online':'✗ Offline'}</div><div class="met-l">LAN Sync Folder</div></div>`);
    }catch(e){/* not fatal */}
  }
  const dbTotal=(await Promise.all(STORES_FOR_HEALTH.map(s=>gAll(s).then(a=>a.length).catch(()=>0)))).reduce((a,b)=>a+b,0);
  rows.push(`<div class="met"><div class="met-v" data-style="font-size:15px">${dbTotal}</div><div class="met-l">Total DB Records (core stores)</div></div>`);
  el.innerHTML=rows.join('')||'<div data-style="color:var(--tx3);font-size:11px">No system health APIs available in this environment</div>';
}
const STORES_FOR_HEALTH=['materials','transactions','users','audit','automated_alerts','archive_records'];

function diagRenderStats(){
  const logStats=window.logger.getStatistics?window.logger.getStatistics():{total:window.logger.getLogs().length};
  const errStats=window.errorHandler.getStatistics?window.errorHandler.getStatistics():{total:window.errorHandler.getErrorLog().length};
  const listeners=window.eventBus.getListenerStats?window.eventBus.getListenerStats():{};
  const listenerCount=Object.keys(listeners).length;
  document.getElementById('diag-stats').innerHTML=
    `<div class="met"><div class="met-v" data-style="font-size:16px">${logStats.total??window.logger.getLogs().length}</div><div class="met-l">Total Logs</div></div>`+
    `<div class="met"><div class="met-v" data-style="font-size:16px;color:${(errStats.total??0)>0?'var(--rd)':'inherit'}">${errStats.total??window.errorHandler.getErrorLog().length}</div><div class="met-l">Errors Logged</div></div>`+
    `<div class="met"><div class="met-v" data-style="font-size:16px">${listenerCount}</div><div class="met-l">Event Listeners</div></div>`+
    `<div class="met"><div class="met-v" data-style="font-size:16px">${_diagEventLog.length}</div><div class="met-l">Events Seen (session)</div></div>`;
}

function diagRenderLogs(){
  const level=document.getElementById('diag-log-level').value;
  const order=['DEBUG','INFO','WARN','ERROR','CRITICAL'];
  let logs=window.logger.getLogs();
  if(level!=='all'){
    const minIdx=order.indexOf(level);
    logs=logs.filter(l=>order.indexOf(l.level)>=minIdx);
  }
  logs=logs.slice(-150).reverse();
  const tb=document.getElementById('diag-log-body');
  if(!logs.length){tb.innerHTML='<tr><td colspan="4" data-style="text-align:center;color:var(--tx3);padding:12px">No logs yet</td></tr>';return;}
  tb.innerHTML=logs.map(l=>{
    const t=l.timestamp?new Date(l.timestamp).toLocaleTimeString():'-';
    const lvlColor=l.level==='ERROR'||l.level==='CRITICAL'?'var(--rd)':l.level==='WARN'?'var(--am)':'var(--tx2)';
    const msg=sanitizeHTML(String(l.message||''));
    return `<tr><td data-style="font-size:10px;color:var(--tx3)">${t}</td><td data-style="color:${lvlColor};font-weight:600;font-size:10px">${l.level||'-'}</td><td data-style="font-size:10px">${sanitizeHTML(l.category||'-')}</td><td data-style="font-size:11px">${msg}</td></tr>`;
  }).join('');
}

function diagRenderErrors(){
  const severity=document.getElementById('diag-error-severity')?.value||'all';
  const errorType=document.getElementById('diag-error-type')?.value||'all';
  const errors=window.errorHandler.getErrorLog().filter(e=>(severity==='all'||e.severity===severity)&&(errorType==='all'||e.context?.type===errorType)).slice(-100).reverse();
  const tb=document.getElementById('diag-error-body');
  if(!errors.length){tb.innerHTML='<tr><td colspan="3" data-style="text-align:center;color:var(--gn);padding:12px">✓ No errors logged</td></tr>';return;}
  tb.innerHTML=errors.map(e=>{
    const t=e.timestamp?new Date(e.timestamp).toLocaleTimeString():'-';
    const sevColor=e.severity==='critical'||e.severity==='high'?'var(--rd)':e.severity==='medium'?'var(--am)':'var(--tx2)';
    return `<tr><td data-style="font-size:10px;color:var(--tx3)">${t}</td><td data-style="color:${sevColor};font-weight:600;font-size:10px">${sanitizeHTML(e.severity||'-')}</td><td data-style="font-size:11px">${sanitizeHTML(e.message||e.userMessage||'')}</td></tr>`;
  }).join('');
}

function diagRenderConfig(){
  try{
    document.getElementById('diag-config-view').textContent=JSON.stringify(window.configManager.getAll(),null,2);
  }catch(e){document.getElementById('diag-config-view').textContent='(unavailable)';}
}

function diagRenderState(){
  try{
    document.getElementById('diag-state-view').textContent=JSON.stringify(window.stateManager.getState(),null,2);
  }catch(e){document.getElementById('diag-state-view').textContent='(unavailable)';}
}
function refreshDatabaseStatus(){
  const el=document.getElementById('diag-db-schema');
  if(!el){return null;}
  if(typeof window.getDatabaseStatus!=='function'){el.textContent='Local database status API is unavailable.';return null;}
  const status=window.getDatabaseStatus();
  const missing=Array.isArray(status.missingStores)?status.missingStores:[];
  const state=!status.ready?'Not ready':status.migrationPending?'Schema mismatch / missing stores':'Ready';
  el.textContent=`${state} · ${status.databaseName||'Local IndexedDB'} · Version ${status.actualVersion??'—'} / expected ${status.expectedVersion??'—'} · ${status.storeCount??0} stores${missing.length?` · Missing: ${missing.join(', ')}`:''}. This is local IndexedDB only; it does not inspect or migrate the central server.`;
  el.style.color=status.ready&&!status.migrationPending?'var(--gn)':'var(--am)';
  return status;
}
async function refreshCentralMigrationStatus(){
  const el=document.getElementById('diag-central-migrations');
  if(!el){return null;}
  if(!window.centralBridge?.getMigrationStatus){el.textContent='Central migration status is unavailable in this app build.';el.style.color='var(--am)';return null;}
  el.textContent='Checking central PostgreSQL migration history…';
  try{
    const status=await window.centralBridge.getMigrationStatus();
    const pending=Array.isArray(status.pendingVersions)?status.pendingVersions:[];
    const applied=Array.isArray(status.appliedVersions)?status.appliedVersions:[];
    const unexpected=Array.isArray(status.unexpectedVersions)?status.unexpectedVersions:[];
    const state=status.migrationTablePresent===false?'Migration table missing':status.migrationPending?'Pending / unexpected migrations':'Up to date';
    el.textContent=`${state} · Central PostgreSQL · Version ${status.currentVersion||'—'} / expected ${status.expectedVersion||'—'} · ${applied.length}/${(status.expectedVersions||[]).length} expected migrations applied${pending.length?` · Pending: ${pending.join(', ')}`:''}${unexpected.length?` · Unexpected: ${unexpected.join(', ')}`:''} · Checked ${status.checkedAt||'just now'}. Read-only; no migration was run.`;
    el.style.color=status.migrationPending?'var(--am)':'var(--gn)';
    return status;
  }catch(error){
    el.textContent=`Central migration status unavailable: ${error?.message||'request failed'}. Check HTTPS/network, central login, and admin/developer role; no migration was run.`;
    el.style.color='var(--am)';
    return null;
  }
}
function findUnmappedStockTransactions(transactions,materials){
  const ids=new Set((Array.isArray(materials)?materials:[]).map(item=>String(item?.id??'' )).filter(Boolean));
  const barcodes=new Set((Array.isArray(materials)?materials:[]).map(item=>String(item?.barcode??'').trim().toLowerCase()).filter(Boolean));
  return (Array.isArray(transactions)?transactions:[]).filter(tx=>{
    if(!tx||!['IN','OUT'].includes(String(tx.type||'').toUpperCase())||tx.status!=='confirmed')return false;
    const itemId=String(tx.itemId??tx.materialId??'');
    const barcode=String(tx.barcode??'').trim().toLowerCase();
    return !(itemId&&ids.has(itemId))&&!(barcode&&barcodes.has(barcode));
  });
}
function refreshUnmappedStockAlerts(){
  const el=document.getElementById('diag-unmapped-stock');if(!el)return [];
  const rows=findUnmappedStockTransactions(T,M);
  const body=document.getElementById('diag-unmapped-stock-body');
  const ordered=rows.slice().sort((a,b)=>{
    const at=Date.parse(a?.time||'')||0,bt=Date.parse(b?.time||'')||0;
    return bt-at;
  });
  const shown=ordered.slice(0,100);
  if(body){
    body.replaceChildren();
    if(!shown.length){
      const tr=document.createElement('tr'),td=document.createElement('td');
      td.colSpan=6;td.textContent='No unresolved confirmed movements.';tr.appendChild(td);body.appendChild(tr);
    }else shown.forEach(tx=>{
      const tr=document.createElement('tr');
      const date=tx.time?new Date(tx.time):null;
      const cells=[date&&Number.isFinite(date.getTime())?date.toLocaleString():'Unknown date',String(tx.type||'').toUpperCase(),String(tx.itemName||'Unknown item'),String(tx.barcode||'—'),String(Number(tx.qty)||0),String(tx.id||'—')];
      cells.forEach(value=>{const td=document.createElement('td');td.textContent=value;tr.appendChild(td);});
      body.appendChild(tr);
    });
  }
  if(!rows.length){el.textContent='No unmapped confirmed IN/OUT transactions found. This read-only local check compares transaction material IDs/barcodes with the current Material Master; it does not validate the central server.';el.style.color='var(--gn)';return rows;}
  el.textContent=`${rows.length} confirmed IN/OUT movement(s) have no matching current Material Master ID or barcode. Review the Material Master and transaction history; do not delete or rewrite ledger entries from this report. Showing the newest ${shown.length}${rows.length>shown.length?` of ${rows.length}`:''}. This is a read-only local check and does not validate the central server.`;
  el.style.color='var(--am)';return rows;
}
// Live event feed — real eventBus subscription (wired once), not a static list
function diagWireEventFeed(){
  if(_diagEventFeedWired){return;}
  _diagEventFeedWired=true;
  ['user:login','user:logout','material:changed','lan:sync'].forEach(evt=>{
    window.eventBus.on(evt,(data)=>{
      _diagEventLog.push({ts:Date.now(),evt,data});
      if(_diagEventLog.length>50){_diagEventLog.shift();}
      // Only touch the DOM if the Diagnostics panel is currently visible
      if(document.getElementById('s-diag')?.classList.contains('active')){
        diagRenderEventFeed();
        diagRenderStats();
      }
    });
  });
}

function diagRenderEventFeed(){
  const tb=document.getElementById('diag-event-body');
  if(!tb){return;}
  const rows=_diagEventLog.slice().reverse();
  if(!rows.length){tb.innerHTML='<tr><td colspan="3" data-style="text-align:center;color:var(--tx3);padding:10px">No events yet this session</td></tr>';return;}
  tb.innerHTML=rows.map(r=>`<tr><td data-style="font-size:10px;color:var(--tx3)">${new Date(r.ts).toLocaleTimeString()}</td><td data-style="font-size:11px;font-weight:600">${sanitizeHTML(r.evt)}</td><td data-style="font-size:10px;color:var(--tx2)">${sanitizeHTML(JSON.stringify(r.data||{}))}</td></tr>`).join('');
}

function diagExportLogs(){
  const logs=window.logger.getLogs();
  const _url=URL.createObjectURL(new Blob([JSON.stringify(logs,null,2)],{type:'application/json'}));
  const a=document.createElement('a');a.href=_url;a.download=`storetrack_logs_${new Date().toISOString().slice(0,10)}.json`;a.click();
  setTimeout(()=>URL.revokeObjectURL(_url),1000);
  toast('Logs exported!');
}

function diagClearLogs(){
  if(!confirm('Clear all stored logs? This cannot be undone.')){return;}
  window.logger.clearLogs();
  addAudit('SYSTEM','Cleared diagnostic logs','SYSTEM');
  diagRenderLogs();diagRenderStats();
  toast('Logs cleared');
}

function diagClearErrors(){
  if(!confirm('Clear all stored error records? This cannot be undone.')){return;}
  window.errorHandler.clearErrorLog();
  addAudit('SYSTEM','Cleared diagnostic error log','SYSTEM');
  diagRenderErrors();diagRenderStats();
  toast('Error log cleared');
}

async function refreshStats(){
  const counts=await Promise.all(STS.map(s=>gAll(s).then(a=>a.length)));
  document.getElementById('db-stats').innerHTML=`<div class="met"><div class="met-v" data-style="font-size:16px">${counts[0]}</div><div class="met-l">Materials</div></div><div class="met"><div class="met-v" data-style="font-size:16px">${counts[1]}</div><div class="met-l">Txns</div></div><div class="met"><div class="met-v" data-style="font-size:16px">${counts[2]}</div><div class="met-l">Users</div></div><div class="met"><div class="met-v" data-style="font-size:16px">${counts[3]}</div><div class="met-l">Audit</div></div>`;
  document.getElementById('sys-rec').textContent=counts.reduce((a,b)=>a+b,0)+' total records';
  renderArchivePanel();
  loadNotifPrefs();
}

// ── Data Archiving (modules/dataArchiving.js) ──
// The module already runs a real hourly scheduler (setInterval inside
// DataArchivingManager) once its script loads — it just never had a policy
// to run, and no UI. We seed one sensible default policy (old confirmed OUT
// transactions) on first visit to Settings, and expose a manual "Run Now"
// for visibility/testing instead of waiting up to an hour.
let _archiveDefaultPolicyChecked=false;
async function ensureDefaultArchivePolicy(){
  if(_archiveDefaultPolicyChecked||!window.DataArchiving){return;}
  _archiveDefaultPolicyChecked=true;
  const existing=window.DataArchiving.getAllPolicies();
  if(existing.length){return;}
  await window.DataArchiving.createPolicy({
    name:'Old Transactions (1yr+)',
    description:'Moves confirmed IN/OUT transactions older than 365 days out of the active transactions store, into archive_records. Restorable any time from this panel.',
    entityType:'transactions',
    criteria:{age:365},
    archiveStore:'archive_records',
    enabled:true,
    autoRun:false, // manual-only by default — flip to true in the policy if you want the hourly auto-run
    schedule:'monthly'
  });
}

async function renderArchivePanel(){
  const el=document.getElementById('archive-panel');
  if(!el){return;}
  if(!window.DataArchiving){el.innerHTML='<div data-style="color:var(--rd)">Archiving module not loaded</div>';return;}
  await ensureDefaultArchivePolicy();
  const policies=window.DataArchiving.getAllPolicies();
  const archivedCount=(await gAll('archive_records')).length;
  const policy=policies[0];
  const days=policy?.criteria?.age||365;
  const daysEl=document.getElementById('archive-retention-days');if(daysEl)daysEl.value=days;
  const autoEl=document.getElementById('archive-auto-run');if(autoEl)autoEl.checked=!!policy?.autoRun;
  const scheduleEl=document.getElementById('archive-schedule');if(scheduleEl)scheduleEl.value=policy?.schedule||'monthly';
  el.innerHTML=`<div data-style="margin-bottom:8px">Archived records currently stored: <b>${archivedCount}</b> ${archivedCount?`<button class="btn" data-style="font-size:10px;padding:2px 6px;margin-left:6px" data-onclick="nav('archive-browse')">View / Restore</button>`:''}</div>`+
    policies.map(p=>`<div data-style="padding:6px 0;border-top:1px solid var(--border)">
      <b>${sanitizeHTML(p.name)}</b> — ${sanitizeHTML(p.description||'')}<br>
      <span data-style="color:var(--tx3);font-size:11px">Target: ${sanitizeHTML(p.entityType)} · Age ≥ ${p.criteria&&p.criteria.age||'?'} days · Archived so far: ${p.archivedCount||0} · Auto-run: ${p.autoRun?'ON ('+sanitizeHTML(p.schedule||'monthly')+')':'OFF (manual only)'}</span>
    </div>`).join('');
}
async function saveArchivePolicy(){
  if(!cu||!['admin','developer'].includes(cu.role)){toast('Administrator access required','er');return;}
  await ensureDefaultArchivePolicy();const p=window.DataArchiving.getAllPolicies()[0];if(!p){toast('No archive policy configured','er');return;}
  const days=Number(document.getElementById('archive-retention-days')?.value);
  if(!Number.isInteger(days)||days<1||days>36500){toast('Retention must be a whole number from 1 to 36500 days','er');return;}
  const autoRun=!!document.getElementById('archive-auto-run')?.checked;const schedule=document.getElementById('archive-schedule')?.value||'monthly';
  p.criteria={...(p.criteria||{}),age:days};p.autoRun=autoRun;p.schedule=schedule;p.nextRun=p.calculateNextRun();
  await window.DataArchiving.updatePolicy(p.id,{criteria:p.criteria,autoRun,schedule,nextRun:p.nextRun});
  const status=document.getElementById('archive-policy-status');if(status)status.textContent=`Policy saved: records older than ${days} days; scheduled run ${autoRun?'enabled ('+schedule+')':'disabled'}.`;
  toast('Archive policy saved');renderArchivePanel();
}
async function cleanupArchivedRecords(){
  if(!cu||!['admin','developer'].includes(cu.role)){toast('Administrator access required','er');return;}
  if(!window.DataArchiving){toast('Archiving module not loaded','er');return;}
  const days=Number(document.getElementById('archive-retention-days')?.value);
  if(!Number.isInteger(days)||days<1||days>36500){toast('Retention must be a whole number from 1 to 36500 days','er');return;}
  if(!confirm(`Delete archived copies older than ${days} days? Active records are not affected. Invalid timestamps are retained.`))return;
  try{const removed=await window.DataArchiving.cleanupOldArchiveRecords(days);addAudit('SYSTEM',`Archive retention cleanup removed ${removed} record(s) older than ${days} days`,'SYSTEM');const status=document.getElementById('archive-policy-status');if(status)status.textContent=`Cleanup complete: ${removed} expired archive record(s) removed. Invalid timestamps were preserved.`;toast(`Removed ${removed} expired archive record(s)`);renderArchivePanel();}catch(e){window.errorHandler?.handleError(e,{type:'archive_retention',operation:'delete'});toast(`Cleanup failed: ${e.message||'unknown error'}`,'er');}
}

async function runArchiveNow(){
  if(!cu||!['admin','developer'].includes(cu.role)){toast('Administrator access required','er');return;}
  if(!window.DataArchiving){toast('Archiving module not loaded','er');return;}
  await ensureDefaultArchivePolicy();
  const policies=window.DataArchiving.getAllPolicies();
  if(!policies.length){toast('No archive policy configured','er');return;}
  if(!confirm('Run archiving now? Records matching each policy\'s criteria will be moved out of their active store (restorable from Settings → Data Archiving).')){return;}
  let totalArchived=0;
  for(const p of policies){
    try{
      const result=await window.DataArchiving.runArchive(p);
      totalArchived+=result.archivedCount;
      p.lastRun=new Date().toISOString();
      await window.DataArchiving.updatePolicy(p.id,{lastRun:p.lastRun,archivedCount:p.archivedCount});
    }catch(e){
      if(window.errorHandler){window.errorHandler.handleError(e,{type:'data_archiving',silent:true});}
    }
  }
  addAudit('SYSTEM','Ran data archiving — '+totalArchived+' record(s) archived','SYSTEM');
  if(window.appLogger){window.appLogger.info('Data archiving run complete',{totalArchived});}
  toast(totalArchived?`✅ Archived ${totalArchived} record(s)`:'No records matched the archive criteria');
  renderArchivePanel();
  refreshStats();
}

async function renderArchiveBrowse(){
  const tb=document.getElementById('archive-browse-body');
  if(!tb){return;}
  const records=(await gAll('archive_records')).sort((a,b)=>new Date(b.archivedAt)-new Date(a.archivedAt));
  if(!records.length){tb.innerHTML='<tr><td colspan="4" data-style="text-align:center;color:var(--tx3);padding:12px">No archived records</td></tr>';return;}
  tb.innerHTML=records.map(r=>{
    const label=r.data&&(r.data.name||r.data.materialName||('#'+r.originalId))||('#'+r.originalId);
    return `<tr><td data-style="font-size:10px;color:var(--tx3)">${r.archivedAt?new Date(r.archivedAt).toLocaleDateString():'-'}</td><td>${sanitizeHTML(r.originalStore)}</td><td>${sanitizeHTML(String(label))}</td><td><button class="btn" data-style="font-size:10px;padding:2px 6px" data-onclick="restoreArchiveRecord(${JSON.stringify(String(r.id))})">↩ Restore</button></td></tr>`;
  }).join('');
}
async function restoreArchiveRecord(id){
  if(!cu||!['admin','developer'].includes(cu.role)){toast('Administrator access required','er');return;}
  if(!confirm('Restore this record back to its original store?')){return;}
  try{
    await window.DataArchiving.restoreArchivedData(id,cu?cu.username:'unknown');
    addAudit('SYSTEM','Restored archived record #'+id,'SYSTEM');
    toast('Restored');
    renderArchiveBrowse();refreshStats();
  }catch(e){toast('Restore failed: '+e.message,'er');}
}

async function saveAlertCfg(){CFG.email=document.getElementById('cfg-em').value;CFG.wa=document.getElementById('cfg-wa').value;CFG.id=1;await dPut('config',CFG);toast('Alert config saved!');}
async function saveBarcodeCfg(){CFG.barcodePrefix=cleanBarcodePrefix(document.getElementById('cfg-bcp').value);CFG.id=1;document.getElementById('cfg-bcp').value=CFG.barcodePrefix;await dPut('config',CFG);previewMatBarcode();toast('Barcode prefix saved!');}
async function saveCoCfg(){CFG.company=document.getElementById('cfg-co').value;CFG.addr=document.getElementById('cfg-addr').value;CFG.location=document.getElementById('cfg-loc').value;CFG.gst=document.getElementById('cfg-gst').value;CFG.pin=document.getElementById('cfg-pin').value;CFG.id=1;await dPut('config',CFG);toast('Company settings saved!');}
function renderCentralSyncSummary(detail = {}) {
  const el=document.getElementById('central-sync-summary'); if(!el)return;
  const rows=Array.isArray(detail.queueDetails)?detail.queueDetails:[];
  const counts={queued:0,failed:0,conflict:0}; rows.forEach(row=>{if(counts[row.status]!==undefined)counts[row.status]++;});
  const unresolved=Math.max(Number(detail.queueCount)||0,rows.length);
  const latest=rows.find(row=>row.status==='failed'||row.status==='conflict')||rows[0];
  const reason=detail.error||latest?.error||'No failure reason recorded';
  const actionable=unresolved>0;
  el.innerHTML=`<div class="alrt ${actionable?'alrt-a':'alrt-b'}" data-style="font-size:11px"><strong>Sync resolution summary</strong> · Unresolved: <b>${unresolved}</b> · Waiting: ${counts.queued} · Failed: ${counts.failed} · Conflicts: ${counts.conflict}${actionable?`<br><span>Reason: ${sanitizeHTML(String(reason))}</span> <span>Use <b>Retry Pending Sync</b> to retry queued/failed records; conflicts require review below.</span>`:'<br>No unresolved central sync records.'}</div>`;
}
function renderCentralHealth(detail = {}) {
  if(typeof renderCentralSyncSummary==='function')renderCentralSyncSummary(detail);
  const status = document.getElementById('central-status');
  const details = document.getElementById('central-health-details');
  const deviceDetails = document.getElementById('central-device-details');
  if (status) { status.textContent = detail.state === 'online' ? `Online · ${detail.latencyMs ?? '--'} ms` : detail.state === 'degraded' ? `Degraded · ${detail.latencyMs ?? '--'} ms` : detail.configured ? 'Offline' : 'Not configured'; status.style.color = detail.state === 'online' ? 'var(--gn)' : detail.state === 'degraded' ? 'var(--am)' : 'var(--tx3)'; }
  if (details) { const checked = detail.checkedAt ? new Date(detail.checkedAt).toLocaleTimeString() : '—'; details.textContent = `Health check: ${checked} · Latency: ${detail.latencyMs ?? '—'} ms · Pending sync records: ${detail.queueCount ?? 0} · Sequence cursor: ${detail.lastSequence ?? '—'}`; }
  if (deviceDetails) { const lastSync = detail.lastSyncAt ? new Date(detail.lastSyncAt).toLocaleString() : 'No successful sync recorded'; deviceDetails.textContent = `This device · ${detail.deviceId || window.location?.hostname || 'unknown device'} · App ${detail.appVersion || window.CONST?.APP?.VERSION || 'unknown'} · Central user ${detail.user || cu?.username || cu?.name || '—'} · Last successful sync ${lastSync}`; }
}
async function refreshCentralSyncPanel(){
  try{
    const health=await window.centralSync?.checkHealth?.();
    if(health)renderCentralHealth(health);
    await renderCentralConflicts();
  }catch(error){
    const host=document.getElementById('central-conflict-list');
    if(host)host.textContent=`Could not refresh sync queue: ${error?.message||'unknown error'}`;
  }
}
async function fetchLatestCentralMaterials(){
  if(typeof window.centralBridge?.getMaterials!=='function')throw new Error('The desktop bridge does not expose the central GET /api/materials read.');
  const response=await window.centralBridge.getMaterials();
  const materials=Array.isArray(response)?response:response?.materials;
  if(!Array.isArray(materials))throw new Error('The central GET /api/materials response did not contain a material list.');
  return materials;
}
async function renderCentralConflicts(){
  const host=document.getElementById('central-conflict-list');
  if(!host||!window.centralSync?.getQueueItems){return;}
  const items=(await window.centralSync.getQueueItems()).filter(item=>['queued','conflict','failed'].includes(item.status));
  if(!items.length){host.textContent='No unsynchronized records, central conflicts, or terminal failures are waiting for review.';return;}
  const esc=value=>sanitizeHTML(String(value??''));
  const conflicts=items.filter(item=>item.status==='conflict');
  let centralMaterials=null,centralReadError='';
  if(conflicts.length){try{centralMaterials=await fetchLatestCentralMaterials();}catch(error){centralReadError=error?.message||'Central material read failed.';}}
  const rows=items.map(item=>{
    const tx=item.transaction||{};
    const materialId=String(tx.itemId??tx.materialId??'');
    const material=(Array.isArray(M)?M:[]).find(row=>String(row?.id)===materialId);
    const centralMaterial=item.status==='conflict'&&Array.isArray(centralMaterials)?centralMaterials.find(row=>String(row?.id)===materialId):null;
    const localRecord=material?`Stock ${Number.isFinite(Number(material.stock))?Number(material.stock):'—'} · version ${material.version??'not recorded'} · updated ${material.updatedAt||'unknown'}`:'Local material record unavailable';
    const centralRecord=item.status!=='conflict'?'— (not requested)':centralReadError?`Unavailable — ${centralReadError}`:!centralMaterial?'No matching material in the latest central response':`Stock ${Number.isFinite(Number(centralMaterial.stock))?Number(centralMaterial.stock):'—'} · version ${centralMaterial.version??'not supplied'} · updated ${centralMaterial.updatedAt||'unknown'}`;
    let difference='— (not a conflict)';
    if(item.status==='conflict'){
      if(centralReadError)difference='Not compared — a fresh central read failed.';
      else if(!centralMaterial)difference='Not compared — no matching central material record was returned.';
      else if(!material)difference='Not compared — local material record is unavailable.';
      else{
        const delta=Number(centralMaterial.stock)-Number(material.stock);
        const stockDelta=Number.isFinite(delta)?`stock delta (central − local): ${delta}`:'stock not comparable';
        const versionDelta=material.version!=null&&centralMaterial.version!=null?`version ${material.version} → ${centralMaterial.version}`:'version not comparable';
        difference=`${stockDelta}; ${versionDelta}`;
      }
    }
    const rejection=item.status==='conflict'?`${item.conflictBody?.error||item.lastError||'No rejection detail stored'} · recorded ${item.conflictAt?new Date(item.conflictAt).toLocaleString():'time unavailable'} (historical response, not current stock)`:`${item.lastError||'—'}`;
    const device=tx.deviceId||window.centralHealth?.deviceId||window.location?.hostname||'—';
    const state=item.status==='queued'?'Waiting to sync':item.status==='conflict'?'Conflict — review required':'Failed — manual retry available';
    const arg=esc(JSON.stringify(String(item.id)));
    const buttons=item.status==='conflict'?`${centralMaterial?`<button class="btn" data-onclick="resolveCentralConflict(${arg})">Correct qty &amp; retry</button> `:''}<button class="btn btn-d" data-onclick="discardCentralConflict(${arg})">Discard</button>`:item.status==='failed'?`<button class="btn" data-onclick="retryFailedCentral(${arg})">Retry</button>`:'—';
    return `<tr><td>${esc(item.id)}</td><td>${esc(tx.itemName||material?.name||tx.itemId||tx.materialId||'Unknown material')}</td><td>${esc(tx.qty??'—')}</td><td>${esc(localRecord)}</td><td>${esc(centralRecord)}</td><td>${esc(difference)}</td><td>${esc(rejection)}</td><td>${esc(device)}</td><td>${esc(state)}</td><td>${buttons}</td></tr>`;
  }).join('');
  host.innerHTML=`<div class="alrt alrt-b"><strong>Pending sync queue</strong><div>Conflict rows compare the local material with a fresh authenticated GET /api/materials response, including stock, version, and update time. The rejection text is historical and is not treated as the latest central record. If the fresh read fails or the material is missing, quantity correction is disabled; discard remains available. The server revalidates stock when a corrected transaction is submitted.</div></div><div class="tw"><table><thead><tr><th>Transaction</th><th>Material</th><th>Requested Qty</th><th>Local record</th><th>Latest central record</th><th>Difference</th><th>Rejection recorded at</th><th>Device</th><th>Sync status</th><th>Actions</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
async function retryFailedCentral(id){
  if(!confirm('Retry this previously failed transaction using its original transaction ID? Verify central transaction history first to avoid duplicate stock movement.'))return;
  try{const result=await window.centralSync.retryFailedQueueItem(id);await renderCentralConflicts();await window.centralSync.checkHealth();toast(result.retried?'Retry submitted':'Failed transaction not found',result.retried?'inf':'er');}
  catch(error){toast(`Retry failed: ${error.message}`,'er');}
}
async function resolveCentralConflict(id){
  const item=(await window.centralSync?.getConflictQueueItems?.()||[]).find(row=>String(row.id)===String(id));
  if(!item){toast('Conflict no longer exists','er');return;}
  const materialId=String(item.transaction?.itemId??item.transaction?.materialId??'');
  let centralMaterial;
  try{centralMaterial=(await fetchLatestCentralMaterials()).find(row=>String(row?.id)===materialId);if(!centralMaterial)throw new Error('The material was not found in the latest central response.');}
  catch(error){toast(`Cannot safely resolve conflict without the latest central material/version: ${error?.message||'central read failed'}`,'er');return;}
  const localMaterial=(Array.isArray(M)?M:[]).find(row=>String(row?.id)===materialId);
  const latest=`Latest central record: stock ${centralMaterial.stock??'—'}, version ${centralMaterial.version??'not supplied'}, updated ${centralMaterial.updatedAt||'unknown'}. Local record: stock ${localMaterial?.stock??'—'}, version ${localMaterial?.version??'not recorded'}.`;
  const raw=prompt(`Central rejected ${item.transaction?.qty} units of ${item.transaction?.itemName||item.transaction?.itemId}. ${latest} Enter a corrected quantity. The server will revalidate stock when submitted; this creates a new transaction.`,'');
  if(raw===null){return;}
  const qty=Number(raw);
  if(!Number.isFinite(qty)||qty<=0){toast('Enter a positive quantity','er');return;}
  if(!confirm(`Submit a new transaction for ${qty} units against the central record read above? The server rechecks current stock at commit time; the original conflict remains unless central accepts it.`)){return;}
  try{
    await window.centralSync.resolveConflict(id,{...item.transaction,id:generateUUID(),qty});
    await renderCentralConflicts();
    await window.centralSync.checkHealth();
    toast('Corrected transaction submitted');
  }catch(error){toast(`Conflict resolution failed: ${error.message}`,'er');}
}
async function discardCentralConflict(id){
  if(!confirm('Discard this locally queued conflicting transaction? This does not alter stock or delete the local transaction history.')){return;}
  const result=await window.centralSync?.discardConflict?.(id);
  if(result?.ok){await renderCentralConflicts();await window.centralSync.checkHealth();toast('Conflict queue entry discarded');}
  else toast('Conflict entry not found','er');
}
window.addEventListener('central-health-update', event => renderCentralHealth(event.detail));
window.addEventListener('central-sync-conflict', event => {
  toast(`Central stock conflict needs review: ${event.detail?.message||'server rejected a transaction'}`,'er');
  renderCentralConflicts().catch(error => console.warn('[central conflicts]',error));
});
window.addEventListener('central-sync-failed', event => {
  const reason=event.detail?.message||'Unknown central sync error';
  toast(`Central sync stopped after ${Number(event.detail?.attempts)||10} attempts. Review failed transactions in System Diagnostics / Settings.`,'er');
  notifyUser('Central Sync Failed',`${reason}. Retry is available in Settings → Central Server Synchronization.`,'system','high','sync_failure');
  window.centralSync?.checkHealth?.().then(health=>{renderCentralHealth(health);return renderCentralConflicts();}).catch(error=>console.warn('[central sync failure]',error));
});
async function saveCentralCfg(){
  const input=document.getElementById('cfg-central-url');
  const url=input.value.trim().replace(/\/$/,'');
  CFG.centralServerUrl=url;CFG.id=1;await dPut('config',CFG);
  const status=document.getElementById('central-status');
  if(!url){renderCentralHealth({configured:false,state:'offline',queueCount:0});toast('Central synchronization disabled','inf');return;}
  try{await window.centralBridge.configure(url);const result=await window.centralSync?.checkHealth?.() || await window.centralBridge.getStatus();renderCentralHealth({...result,state:result.online?(Number(result.latencyMs)>1000?'degraded':'online'):'offline'});toast(result.online?'Central server reachable':'Central URL saved; server currently unavailable','inf');}
  catch(error){renderCentralHealth({configured:true,state:'offline',error:error.message,queueCount:0});toast('Central URL saved; server currently unavailable','inf');}
}
async function retryCentralSync(){
  try{
    if(!window.centralSync?.flushQueue){toast('Central sync module unavailable','er');return;}
    await window.centralSync.flushQueue();
    const result=await window.centralSync.checkHealth();
    renderCentralHealth({...result,state:result.online?(Number(result.latencyMs)>1000?'degraded':'online'):'offline'});
    await renderCentralConflicts();
    renderCentralSyncSummary(result);
    toast(result.online?'Pending transactions retried':'Central server unavailable; queue retained','inf');
  }catch(error){toast(`Sync retry failed: ${error.message}`,'er');}
}
async function exportBackup(){
  if(typeof confirm==='function'&&!confirm('This Settings backup is an UNENCRYPTED JSON file containing sensitive inventory, transaction, user metadata and component records. Store it securely. Continue?')) {return;}
  // Strip password hashes from exported users for security
  const safeUsers=U.map(u=>{const s={...u};delete s.passwordHash;delete s.password;return s;});
  const appVersion=(window.CONST&&window.CONST.APP&&window.CONST.APP.VERSION)?window.CONST.APP.VERSION:'8.0.0';
  const componentData=window.componentExportBackupData?await window.componentExportBackupData():null;
  const data={M,T,ADJ,SP,DP,CFG,users_meta:safeUsers,AP,IN_REQ,RET,CC,GRN,LOCS,MOVS,componentData,exportedAt:new Date().toISOString(),v:'StoreTrack Pro v'+appVersion,_note:'Passwords are not exported. This JSON file is not encrypted; treat it as confidential.'};
  const plainText=JSON.stringify(data,null,2);
  // Settings → Backup JSON is a direct, unencrypted export. Do not use
  // prompt(): it is unavailable in the Electron/browser runtime. Users who
  // need password-protected or daily complete backups should use the
  // dedicated Backup & Restore side-menu workflow.
  const fileBody=plainText, encrypted=false;
  // FIX #4: Revoke object URL after 1 s to prevent memory leak
  const _bakUrl=URL.createObjectURL(new Blob([fileBody],{type:'application/json'}));
  const a=document.createElement('a');a.href=_bakUrl;a.download=`storetrack_backup_${new Date().toISOString().slice(0,10)}${encrypted?'_encrypted':''}.json`;a.click();
  setTimeout(()=>URL.revokeObjectURL(_bakUrl),1000);
  document.getElementById('sys-bk').textContent=new Date().toLocaleString();
  addAudit('BACKUP',encrypted?'Exported password-protected encrypted backup':'Exported unencrypted full backup JSON','SYSTEM');
  toast(encrypted?'Encrypted backup exported! Remember the password; the backup cannot be restored without it.':'Unencrypted backup exported. Store the file securely.','inf');
}
function isValidGRNRecord(g){
  if(!g || typeof g !== 'object' || Array.isArray(g) || !['string','number'].includes(typeof g.id) || String(g.id).trim()==='' || !Array.isArray(g.items)) return false;
  const scalarFields=['grnNo','time','supplierId','supplierName','po','invoice','totalQty','receivedBy'];
  if(scalarFields.some(k=>g[k]!==undefined && g[k]!==null && !['string','number','boolean'].includes(typeof g[k]))) return false;
  return g.items.every(item=>item && typeof item==='object' && !Array.isArray(item) && Object.values(item).every(v=>v===null || ['string','number','boolean'].includes(typeof v)));
}
function validGRNRowsOrWarn(rows, action){
  const bad=(Array.isArray(rows)?rows:[]).filter(row=>!isValidGRNRecord(row)).length;
  if(bad){toast(`${bad} malformed GRN record(s) were skipped during ${action}. Restore the source backup or repair these records before using them.`, 'er');return (Array.isArray(rows)?rows:[]).filter(isValidGRNRecord);}
  return Array.isArray(rows)?rows:[];
}

function validateCompleteRestoreStores(stores){
  if(!window.getStoreNames||!window.getDB){throw new Error('Atomic restore is unavailable; no stores were changed.');}
  const known=new Set(window.getStoreNames());
  const entries=Object.entries(stores||{});
  if(!entries.length){throw new Error('Backup contains no stores.');}
  for(const [store,rows] of entries){
    if(!known.has(store)){throw new Error(`Unknown backup store: ${store}`);}
    if(!Array.isArray(rows)){throw new Error(`Invalid backup rows for store: ${store}`);}
    const keys=new Set();
    for(const row of rows){
      if(!row||typeof row!=='object'||Array.isArray(row)||!Object.prototype.hasOwnProperty.call(row,'id')||!['string','number'].includes(typeof row.id)||String(row.id).trim()===''){
        throw new Error(`Invalid record in backup store: ${store}`);
      }
      const key=String(row.id);
      if(keys.has(key)){throw new Error(`Duplicate record id in backup store: ${store}`);}
      keys.add(key);
    }
  }
  return Object.fromEntries(entries);
}

async function replaceStoresAtomically(storeRows){
  const entries=Object.entries(storeRows||{});
  if(!entries.length){return;}
  const db=window.getDB?.();
  if(!db){throw new Error('Database is not ready; no stores were changed.');}
  const prepared={};
  for(const [store,rows] of entries){
    prepared[store]=await Promise.all(rows.map(row=>window.DataEncryption?.manager?.prepareForStorage
      ? window.DataEncryption.manager.prepareForStorage(store,row):row));
  }
  await new Promise((resolve,reject)=>{
    const tx=db.transaction(entries.map(([store])=>store),'readwrite');
    try{
      for(const [store] of entries){
        const objectStore=tx.objectStore(store);
        objectStore.clear();
        for(const row of prepared[store]){objectStore.put(row);}
      }
    }catch(error){
      try{tx.abort();}catch(_){/* transaction already closed */}
      reject(error);return;
    }
    tx.oncomplete=()=>resolve();
    tx.onerror=()=>reject(tx.error||new Error('Atomic backup restore failed.'));
    tx.onabort=()=>reject(tx.error||new Error('Atomic backup restore was aborted.'));
  });
}

async function importBackup(e){
  const f=e.target.files[0];if(!f){return;}
  // File size check: max 20 MB
  if(f.size>20*1024*1024){toast('Backup file too large (>20 MB)','er');e.target.value='';return;}
  const r=new FileReader();
  r.onload=async ev=>{
    try{
      let data=JSON.parse(ev.target.result);
      let isCompleteStoreTrackBackup = data && data.format === 'StoreTrackProCompleteBackup' && data.stores && typeof data.stores === 'object' && !Array.isArray(data.stores) && Object.keys(data.stores).length > 0;
      // modules/encryption.js — if this is a password-protected backup, decrypt it first.
      if(data&&data.encrypted===true){
        if(!window.Encryption){toast('Encryption module not loaded, cannot open this backup','er');return;}
        const pw=prompt('This backup is password-protected. Enter the password:');
        if(pw===null){return;}
        try{
          const plain=await window.Encryption.decryptBackup(data,pw);
          data=JSON.parse(plain);
          isCompleteStoreTrackBackup = data && data.format === 'StoreTrackProCompleteBackup' && data.stores && typeof data.stores === 'object' && !Array.isArray(data.stores) && Object.keys(data.stores).length > 0;
        }catch(ex){toast('Incorrect password or corrupted backup file','er');return;}
      }
      // Basic validation
      if(typeof data!=='object'||Array.isArray(data)){toast('Invalid backup format','er');return;}
      if((!data.v&&!isCompleteStoreTrackBackup)||(data.v&&!String(data.v).startsWith('StoreTrack')&&!isCompleteStoreTrackBackup)){if(!confirm('File does not appear to be a StoreTrack backup. Restore anyway?')){return;}}
      if(isCompleteStoreTrackBackup){
        if(Array.isArray(data.stores.grn) && data.stores.grn.some(row=>!isValidGRNRecord(row))){toast('Restore cancelled: backup contains malformed GRN records. No stores were changed. Repair the backup and retry.','er');return;}
        let storesToRestore;
        try{storesToRestore=validateCompleteRestoreStores(data.stores);}
        catch(validationError){toast(`Restore cancelled: ${validationError.message}`,'er');return;}
        const currentStoreNames = typeof getStoreNames === 'function' ? getStoreNames() : [];
        const absentStores = currentStoreNames.filter(name => !Object.prototype.hasOwnProperty.call(data.stores, name));
        if(absentStores.length && !confirm(`This backup omits ${absentStores.length} current store(s): ${absentStores.join(', ')}. Those stores will be preserved and not cleared. User account data may be absent from backups for security. Continue with this partial restore?`)){return;}
        // Snapshot every target before writing, then replace all included stores
        // in one IndexedDB transaction. This preserves omitted stores and means
        // a write/refresh failure can restore the previous data, not a partial
        // mix of old and imported rows.
        const previousStores={};
        for(const store of Object.keys(storesToRestore)){previousStores[store]=await gAll(store);}
        try{
          await replaceStoresAtomically(storesToRestore);
          if(window.componentRestoreBackupData){await window.componentRestoreBackupData(data.stores);}
        }catch(restoreError){
          try{
            await replaceStoresAtomically(previousStores);
            if(window.componentRestoreBackupData){await window.componentRestoreBackupData(previousStores);}
          }catch(rollbackError){
            console.error('[backup restore] rollback failed',rollbackError);
            toast(`Restore failed and rollback could not be verified: ${rollbackError.message}`,'er');
            return;
          }
          toast(`Restore failed; all targeted stores were rolled back. ${restoreError.message}`,'er');
          return;
        }
        invalidateStockForecast();
        [M,T,U,A,AP,ADJ,SP,DP,IN_REQ,RET,CC,GRN,LOCS,MOVS]=await Promise.all(['materials','transactions','users','audit','approvals','adjustments','suppliers','departments','indents','returns','cyclecount','grn','locations','movements'].map(gAll));
        const completeConfig=await gAll('config');CFG=completeConfig[0]||{};
        const restoredCounts = Object.fromEntries(Object.entries(data.stores).map(([store, rows]) => [store, Array.isArray(rows) ? rows.length : 0]));
        const totalRestored = Object.values(restoredCounts).reduce((sum, count) => sum + count, 0);
        addAudit('RESTORE','Restored complete StoreTrack Pro backup JSON','SYSTEM');
        // Compatibility marker retained for existing restore-contract checks: toast('Complete StoreTrack Pro backup restored!')
        toast(`Complete backup restored: ${totalRestored} records. Reloading to refresh all modules...`);updateBadges();
        setTimeout(() => window.location.reload(), 250);
        return;
      }
      if(Array.isArray(data.GRN) && data.GRN.some(row=>!isValidGRNRecord(row))){toast('Restore cancelled: backup contains malformed GRN records. No stores were changed. Repair the backup and retry.','er');return;}
      if(data.M&&!Array.isArray(data.M)){toast('Corrupted backup: invalid materials','er');return;}
      if(data.M&&data.M.length>100000){toast('Backup too large (>100k materials)','er');return;}
      // Legacy JSON restore is an exact replacement for every store present in
      // the file; otherwise records absent from an older backup remain stale.
      const legacyStores={M:'materials',SP:'suppliers',DP:'departments',T:'transactions',ADJ:'adjustments',U:'users',AP:'approvals',IN_REQ:'indents',RET:'returns',CC:'cyclecount',GRN:'grn',LOCS:'locations',MOVS:'movements'};
      for(const [key,store] of Object.entries(legacyStores)){if(Array.isArray(data[key])){await dClr(store);}}
      if(data.componentData&&window.componentRestoreBackupData){await window.componentRestoreBackupData(data.componentData);}
      if(data.M){for(const m of data.M){await dPut('materials',m);}M=await gAll('materials');}
      if(data.SP){for(const s of data.SP){await dPut('suppliers',s);}SP=await gAll('suppliers');}
      if(data.DP){for(const d of data.DP){await dPut('departments',d);}DP=await gAll('departments');}
      if(data.T){for(const t of data.T){await dPut('transactions',t);}T=await gAll('transactions');}
      if(data.ADJ){for(const a of data.ADJ){await dPut('adjustments',a);}ADJ=await gAll('adjustments');}
      if(data.U){for(const u of data.U){await dPut('users',u);}U=await gAll('users');}
      if(data.AP){for(const a of data.AP){await dPut('approvals',a);}AP=await gAll('approvals');}
      if(data.IN_REQ){for(const x of data.IN_REQ){await dPut('indents',x);}IN_REQ=await gAll('indents');}
      if(data.RET){for(const x of data.RET){await dPut('returns',x);}RET=await gAll('returns');}
      if(data.CC){for(const x of data.CC){await dPut('cyclecount',x);}CC=await gAll('cyclecount');}
      if(data.GRN){for(const x of data.GRN){await dPut('grn',x);}GRN=await gAll('grn');}
      if(data.LOCS){for(const x of data.LOCS){await dPut('locations',x);}}
      if(data.MOVS){for(const x of data.MOVS){await dPut('movements',x);}}
      LOCS=await gAll('locations');MOVS=await gAll('movements');
      const restoredTotal = Object.entries(legacyStores).reduce((sum,[key]) => sum + (Array.isArray(data[key]) ? data[key].length : 0), 0) + (data.componentData ? Object.values(data.componentData).reduce((sum, rows) => sum + (Array.isArray(rows) ? rows.length : 0), 0) : 0);
      addAudit('RESTORE','Restored data from backup JSON','SYSTEM');
      toast(`Data restored: ${restoredTotal} records. Reloading to refresh all modules...`);updateBadges();
      setTimeout(() => window.location.reload(), 250);
    }catch(ex){toast('Invalid backup file','er');}
  };r.readAsText(f);e.target.value='';
}
async function clearAllData(){if(!confirm('ALL data permanently deleted?')){return;}if(!confirm('Last chance — cannot be undone!')){return;}for(const s of STS){await dClr(s);}M=[];T=[];U=[];A=[];AP=[];ADJ=[];SP=[];DP=[];CFG={};IN_REQ=[];RET=[];CC=[];GRN=[];LOCS=[];MOVS=[];await seedData();toast('Cleared. Defaults restored.','inf');updateBadges();}

// ── Password Hashing ──────────────────────────────────────────────────────────
// Authentication helpers moved to modules/authHelpers.js
// Functions: _safeCompare, _isBcrypt, _isPbkdf2, hashPassword, verifyPassword, _sha256
// (used by seedData below — resolves fine since authHelpers.js loads before this file)

// ── Seed ──
async function seedData(){
  if(!U.length){
    // Always seed with SHA-256 — authBridge (PBKDF2) is not available yet at seed time.
    // On first login the migration block upgrades hash to PBKDF2 automatically.
    const setupPassword=()=>generateSetupSecret();
    const p1=setupPassword(),p2=setupPassword(),p3=setupPassword();
    await dPut('users',{id:1,name:'Admin User',username:'admin',passwordHash:await _sha256(p1),role:'admin',dept:'Management',active:true,mustChangePassword:true,createdAt:new Date().toISOString()});
    await dPut('users',{id:2,name:'Store Keeper',username:'store',passwordHash:await _sha256(p2),role:'store',dept:'Store',active:true,mustChangePassword:true,createdAt:new Date().toISOString()});
    await dPut('users',{id:3,name:'Developer User',username:'developer',passwordHash:await _sha256(p3),role:'developer',dept:'IT',active:true,mustChangePassword:true,createdAt:new Date().toISOString()});
    const setupHint=document.getElementById('bootstrap-hint');
    if(setupHint){setupHint.textContent=`One-time setup credentials — admin: ${p1} · store: ${p2} · developer: ${p3}. Save these now and change each password after signing in.`;setupHint.style.display='block';}
    U=await gAll('users');
  }
  if(!U.some(u=>u.role==='developer')){
    const p3=generateSetupSecret();
    await dPut('users',{id:3,name:'Developer User',username:'developer',passwordHash:await _sha256(p3),role:'developer',dept:'IT',active:true,mustChangePassword:true,createdAt:new Date().toISOString()});
    const setupHint=document.getElementById('bootstrap-hint');
    if(setupHint){setupHint.textContent=`${setupHint.textContent} One-time developer setup credential: ${p3}. Save it now and change the password after signing in.`.trim();setupHint.style.display='block';}
    U=await gAll('users');
  }
  if(!M.length){
    const demo=[{id:1001,barcode:'MAT001',name:'MS Pipe 25mm',category:'Mechanical',unit:'Mtr',stock:45,lowAlert:20,reorderQty:100,hsn:'7306',active:true,photo:null,createdAt:new Date().toISOString()},{id:1002,barcode:'MAT002',name:'Allen Bolt M8x30',category:'Fasteners',unit:'Pcs',stock:8,lowAlert:50,reorderQty:200,hsn:'7318',active:true,photo:null,createdAt:new Date().toISOString()},{id:1003,barcode:'MAT003',name:'Bearing 6205',category:'Mechanical',unit:'Pcs',stock:12,lowAlert:10,reorderQty:30,hsn:'8482',active:true,photo:null,createdAt:new Date().toISOString()},{id:1004,barcode:'MAT004',name:'Copper Wire 2.5mm',category:'Electrical',unit:'Mtr',stock:3,lowAlert:25,reorderQty:100,hsn:'8544',active:true,photo:null,createdAt:new Date().toISOString()},{id:1005,barcode:'MAT005',name:'Hydraulic Oil 68',category:'Lubricants',unit:'Ltr',stock:60,lowAlert:20,reorderQty:50,hsn:'2710',active:true,photo:null,createdAt:new Date().toISOString()},{id:1006,barcode:'MAT006',name:'Drill Bit 8mm HSS',category:'Tools',unit:'Pcs',stock:0,lowAlert:5,reorderQty:20,hsn:'8207',active:true,photo:null,createdAt:new Date().toISOString()}];
    for(const m of demo){await dPut('materials',m);}M=await gAll('materials');
  }
  if(!SP.length){await dPut('suppliers',{id:2001,name:'Raj Traders',contact:'Rajesh Shah',phone:'9876543210',email:'raj@traders.com',gst:'27AABCT1332L1ZJ',address:'Pune',createdAt:new Date().toISOString()});await dPut('suppliers',{id:2002,name:'Pune Hardware',contact:'Suresh More',phone:'9123456789',email:'',gst:'',address:'MIDC Pune',createdAt:new Date().toISOString()});SP=await gAll('suppliers');}
  if(!DP.length){await dPut('departments',{id:3001,name:'Production',code:'PROD',head:'Manager Desai',costCenter:'CC001',email:'',createdAt:new Date().toISOString()});await dPut('departments',{id:3002,name:'Maintenance',code:'MAINT',head:'Eng. Kulkarni',costCenter:'CC002',email:'',createdAt:new Date().toISOString()});DP=await gAll('departments');}
}

// ── Global Quick Search ──
_addEventListener(document, 'keydown', e=>{if((e.ctrlKey||e.metaKey)&&e.key==='k'){e.preventDefault();const gs=document.getElementById('gsearch');if(gs){gs.focus();gs.select();}}});
let globalSearchResults=[];
function doGSearch(){
  const q=String(document.getElementById('gsearch')?.value||'').toLowerCase().trim();
  const drop=document.getElementById('gsdrop');
  if(!drop)return;
  if(!q){drop.innerHTML='';drop.style.display='none';globalSearchResults=[];return;}
  drop.style.display='block';
  globalSearchResults=[];
  const searchValue=value=>String(value??'').toLowerCase();
  const includes=(row,fields)=>fields.some(field=>searchValue(row?.[field]).includes(q));
  (Array.isArray(M)?M:[]).filter(item=>includes(item,['name','barcode','category','location','binLocationId','hsn'])).slice(0,5).forEach(item=>globalSearchResults.push({kind:'material',title:item.name||'Unnamed material',sub:`${item.barcode||'No barcode'} · ${Number(item.stock)||0} ${item.unit||''}`,query:item.name||item.barcode||''}));
  (Array.isArray(SP)?SP:[]).filter(supplier=>includes(supplier,['name','contact','phone','email','gst'])).slice(0,3).forEach(supplier=>globalSearchResults.push({kind:'supplier',title:supplier.name||'Unnamed supplier',sub:supplier.phone||supplier.email||'',query:supplier.name||''}));
  (Array.isArray(LOCS)?LOCS:[]).filter(location=>includes(location,['name','code','barcode','bin','binCode','station','stationName','locationCode','description'])).slice(0,5).forEach(location=>globalSearchResults.push({kind:'location',title:location.name||location.code||location.binCode||'Location',sub:[location.stationName||location.station,location.code||location.locationCode,location.bin||location.binCode].filter(Boolean).join(' · '),query:location.code||location.name||location.binCode||''}));
  (Array.isArray(T)?T:[]).filter(tx=>includes(tx,['id','itemName','barcode','type','job','jobNo','po','invoice','remarks','deptName','station','binCode'])).slice(0,5).forEach(tx=>globalSearchResults.push({kind:'transaction',title:`${tx.type||'Transaction'} · ${tx.itemName||tx.barcode||'Unknown material'}`,sub:[tx.id,tx.job||tx.jobNo,tx.po,tx.invoice,tx.deptName].filter(Boolean).join(' · '),query:tx.barcode||tx.itemName||tx.id||''}));
  if(globalSearchResults.length){
    drop.innerHTML=globalSearchResults.map((result,index)=>`<button type="button" data-gsearch-result="${index}" data-style="display:block;width:100%;text-align:left;padding:7px 10px;cursor:pointer;font-size:11px;border:0;border-bottom:1px solid var(--b1);background:transparent;color:var(--tx)"><b>${sanitizeHTML(String(result.title))}</b> <span data-style="color:var(--tx3)">${sanitizeHTML(String(result.sub))}</span> <span class="bdg bt" data-style="font-size:9px;margin-left:4px">${sanitizeHTML(result.kind)}</span></button>`).join('');
    drop.querySelectorAll('[data-gsearch-result]').forEach(button=>button.addEventListener('click',()=>{
      const result=globalSearchResults[Number(button.dataset.gsearchResult)];if(!result)return;
      const target=result.kind==='material'?'master':result.kind==='supplier'?'supp':result.kind==='location'?'locations':'hist';
      nav(target);const searchId=result.kind==='material'?'srch-m':result.kind==='transaction'?'srch-h':result.kind==='location'?'loc-search':null;
      if(searchId){setTimeout(()=>{const input=document.getElementById(searchId);if(input){input.value=result.query;if(result.kind==='material')renderMaster();else if(result.kind==='transaction')renderHist();else renderLocs();}},0);}
      drop.style.display='none';document.getElementById('gsearch').value='';
    }));
  }else{drop.innerHTML=`<div data-style="padding:8px 10px;font-size:11px;color:var(--tx3)">No results for “${sanitizeHTML(q)}”</div>`;}
}

// ── Indent / Material Request ──
const indEditId=null;
function popIndentSelects(){
  const s=document.getElementById('ind-item');if(!s){return;}
  s.innerHTML='<option value="">— Select Material —</option>'+M.filter(m=>m.active!==false).map(m=>`<option value="${sanitizeHTML(String(m.id))}">${sanitizeHTML(String(m.name||""))} [${sanitizeHTML(String(m.barcode||""))}] — Stock: ${m.stock} ${m.unit}</option>`).join('');
  const d=document.getElementById('ind-dept');if(d){d.innerHTML='<option value="">— Select Dept —</option>'+DP.map(x=>`<option value="${sanitizeHTML(String(x.id))}">${sanitizeHTML(String(x.name||""))}</option>`).join('');}
}
async function saveIndent(){
  const mId=document.getElementById('ind-item').value;const qty=Number(document.getElementById('ind-qty').value);
  if(!mId||!Number.isInteger(qty)||qty<=0){toast('Material and Quantity required','er');return;}
  const mat=M.find(m=>m.id==mId);const dId=document.getElementById('ind-dept').value;const dObj=DP.find(d=>d.id==dId);
  const num='IND-'+Date.now().toString().slice(-6);
  const obj={id:generateUUID(),indentNo:num,time:new Date().toISOString(),materialId:mId,materialName:mat.name,barcode:mat.barcode,unit:mat.unit,qty,deptId:dId,deptName:dObj?dObj.name:'',job:sanitizeText(document.getElementById('ind-job').value),priority:sanitizeText(document.getElementById('ind-pri').value),reqDate:document.getElementById('ind-date').value,remarks:sanitizeText(document.getElementById('ind-rem').value),reqBy:cu.username,reqByName:cu.name,status:'pending'};
  await dPut('indents',obj);IN_REQ=await gAll('indents');
  addAudit('INDENT','Indent submitted: '+mat.name+' | Qty: '+qty,'MATERIAL');
  clrIndent();renderIndents();updateBadges();toast('Indent '+num+' submitted!');
}
function clrIndent(){['ind-qty','ind-job','ind-rem','ind-date'].forEach(id=>document.getElementById(id).value='');document.getElementById('ind-item').value='';document.getElementById('ind-dept').value='';document.getElementById('ind-pri').value='normal';}
async function approveIndent(id){
  const ind=IN_REQ.find(x=>x.id===id);if(!ind){return;}
  if(ind.status!=='pending'){toast('Indent is no longer pending','er');return;}
  const mat=M.find(m=>m.id==ind.materialId);
  if(!mat||mat.stock<ind.qty){toast('Insufficient stock to issue!','er');return;}
  ind.status='approved';ind.approvedBy=cu.username;ind.approvedAt=new Date().toISOString();
  await dPut('indents',ind);IN_REQ=await gAll('indents');
  addAudit('INDENT','Indent approved: '+ind.materialName+' | '+ind.indentNo,'APPROVAL');
  renderIndents();updateBadges();toast('Indent approved!');
}
async function issueIndent(id){
  const ind=IN_REQ.find(x=>x.id===id);if(!ind){return;}
  if(ind.status!=='approved'){toast('Only an approved indent can be issued','er');return;}
  if(T.some(t=>t.indentId===id||t.remarks==='Indent: '+ind.indentNo)){toast('Indent already issued','er');return;}
  const mat=M.find(m=>m.id==ind.materialId);if(!mat||mat.stock<ind.qty){toast('Insufficient stock','er');return;}
  mat.stock-=ind.qty;mat.updatedAt=new Date().toISOString();
  const tx={id:generateUUID(),indentId:id,time:new Date().toISOString(),barcode:mat.barcode,itemId:mat.id,itemName:mat.name,unit:mat.unit,type:'OUT',qty:ind.qty,deptId:ind.deptId,deptName:ind.deptName,job:ind.job,remarks:'Indent: '+ind.indentNo,user:cu.username,userName:cu.name,status:'confirmed'};
  ind.status='issued';ind.issuedBy=cu.username;ind.issuedAt=new Date().toISOString();
  if(typeof window.dPutMany==='function'){await window.dPutMany([{store:'materials',obj:mat},{store:'transactions',obj:tx},{store:'indents',obj:ind}]);}else{await dPut('materials',mat);await dPut('transactions',tx);await dPut('indents',ind);} T.push(tx);
  [M,IN_REQ,T]=await Promise.all([gAll('materials'),gAll('indents'),gAll('transactions')]);
  addAudit('INDENT','Issued via indent: '+ind.materialName+' | '+ind.qty+' '+mat.unit,'OUT');
  renderIndents();updateBadges();toast('Material issued for indent '+ind.indentNo+'!');
}
async function rejectIndent(id){
  const ind=IN_REQ.find(x=>x.id===id);if(!ind){return;}
  ind.status='rejected';ind.rejectedBy=cu.username;await dPut('indents',ind);IN_REQ=await gAll('indents');
  addAudit('INDENT','Indent rejected: '+ind.indentNo,'APPROVAL');
  renderIndents();updateBadges();toast('Indent rejected','inf');
}
function renderIndents(){
  const flt=document.getElementById('flt-ind-st')?.value||'all';
  const list=IN_REQ.filter(x=>flt==='all'||x.status===flt).slice().reverse();
  const pmap={urgent:'<span class="bdg br">🔴 Urgent</span>',normal:'<span class="bdg bb">Normal</span>',low:'<span class="bdg bt">Low</span>'};
  const smap={pending:'<span class="bdg ba">Pending</span>',approved:'<span class="bdg bg">Approved</span>',issued:'<span class="bdg bt">Issued</span>',rejected:'<span class="bdg br">Rejected</span>'};
  const tb=document.getElementById('ind-body');if(!tb){return;}
  tb.innerHTML=list.length?list.map(x=>{
    let acts='';
    if(cu.role==='admin'&&x.status==='pending'){acts=`<button class="btn btn-s" data-style="padding:3px 6px" data-onclick="approveIndent(${JSON.stringify(String(x.id))})">✓</button> <button class="btn btn-d" data-style="padding:3px 6px" data-onclick="rejectIndent(${JSON.stringify(String(x.id))})">✕</button>`;}
    if(cu.role==='admin'&&x.status==='approved'){acts=`<button class="btn btn-p" data-style="padding:3px 6px" data-onclick="issueIndent(${JSON.stringify(String(x.id))})">📤 Issue</button>`;}
    return `<tr><td data-style="font-size:10px">${sanitizeHTML(String(x.time?new Date(x.time).toLocaleDateString():'-'))}</td><td class="mono">${sanitizeHTML(String(x.indentNo||''))}</td><td data-style="font-weight:500">${sanitizeHTML(String(x.materialName||''))}</td><td class="mono">${Number(x.qty)||0} ${sanitizeHTML(String(x.unit||''))}</td><td>${sanitizeHTML(String(x.deptName||'-'))}</td><td>${pmap[x.priority]||sanitizeHTML(String(x.priority||''))}</td><td data-style="font-size:10px">${sanitizeHTML(String(x.reqDate||'-'))}</td><td>${smap[x.status]||sanitizeHTML(String(x.status||''))}</td><td>${sanitizeHTML(String(x.job||'-'))}</td><td>${sanitizeHTML(String(x.remarks||'-'))}</td><td>${acts||'-'}</td></tr>`;
  }).join(''):'<tr><td colspan="11" data-style="text-align:center;color:var(--tx3);padding:16px">No indent requests</td></tr>';
  const pend=IN_REQ.filter(x=>x.status==='pending').length;
  const inb=document.getElementById('inb');if(inb){inb.textContent=pend;inb.style.display=pend?'':'none';}
}

// ── Material Return ──
function popReturnSelects(){
  const s=document.getElementById('ret-item');if(!s){return;}
  s.innerHTML='<option value="">— Select Material —</option>'+M.filter(m=>m.active!==false).map(m=>`<option value="${sanitizeHTML(String(m.id))}">${sanitizeHTML(String(m.name||""))} [${sanitizeHTML(String(m.barcode||""))}]</option>`).join('');
  const d=document.getElementById('ret-dept');if(d){d.innerHTML='<option value="">— Select Dept —</option>'+DP.map(x=>`<option value="${sanitizeHTML(String(x.id))}">${sanitizeHTML(String(x.name||""))}</option>`).join('');}
}
async function saveReturn(){
  const mId=document.getElementById('ret-item').value;const qty=Number(document.getElementById('ret-qty').value);
  if(!mId||!Number.isFinite(qty)||qty<=0){toast('Material and Quantity required','er');return;}
  const mat=M.find(m=>m.id==mId);if(!mat){toast('Material not found','er');return;}const unit=String(mat.unit||'').trim().toLowerCase();const decimalUnits=new Set(['kg','ltr','l','mtr','m','meter','metre','litre','liter']);if(!decimalUnits.has(unit)&&!Number.isInteger(qty)){toast('Return quantity must be a whole number for this unit','er');return;}const returnRef=sanitizeText(document.getElementById('ret-job').value);const origin=T.filter(t=>t.type==='OUT'&&t.status==='confirmed'&&String(t.itemId)===String(mat.id)).find(t=>returnRef&&(String(t.id)===returnRef||String(t.job||'')===returnRef||String(t.remarks||'').includes(returnRef)));if(!origin){toast('Enter a valid originating OUT transaction/job reference','er');return;}const returnedAlready=RET.filter(r=>String(r.originTxId)===String(origin.id)).reduce((sum,r)=>sum+Number(r.qty||0),0);if(returnedAlready+qty>Number(origin.qty)){toast('Return exceeds outstanding issued quantity','er');return;}const cond=document.getElementById('ret-cond').value;const dId=document.getElementById('ret-dept').value;const dObj=DP.find(d=>d.id==dId);
  const goodReturn=cond==='good';
  if(goodReturn){mat.stock+=qty;mat.updatedAt=new Date().toISOString();}
  const obj={id:generateUUID(),time:new Date().toISOString(),materialId:mId,materialName:mat.name,barcode:mat.barcode,unit:mat.unit,qty,condition:cond,returnedBy:document.getElementById('ret-by').value,deptId:dId,deptName:dObj?dObj.name:'',job:returnRef,originTxId:origin.id,reason:document.getElementById('ret-rsn').value,stockCredited:goodReturn,user:cu.username,userName:cu.name};
  if(goodReturn){const tx={id:generateUUID(),time:new Date().toISOString(),barcode:mat.barcode,itemId:mat.id,itemName:mat.name,unit:mat.unit,type:'IN',qty,remarks:'Return: '+cond,user:cu.username,userName:cu.name,status:'confirmed'}; if(typeof window.dPutMany==='function'){await window.dPutMany([{store:'returns',obj},{store:'materials',obj:mat},{store:'transactions',obj:tx}]);}else{await dPut('returns',obj);await dPut('materials',mat);await dPut('transactions',tx);} T.push(tx); M=await gAll('materials');}else{await dPut('returns',obj);} RET=await gAll('returns');
  addAudit('RETURN','Return: '+mat.name+' | Qty: '+qty+' | Condition: '+cond,'MATERIAL');
  clrReturn();renderReturns();updateBadges();toast(goodReturn?`✓ ${qty} ${mat.unit} returned & stock credited`:`Return recorded (no stock credit — ${cond})`);
}
function clrReturn(){['ret-qty','ret-by','ret-job','ret-rsn'].forEach(id=>document.getElementById(id).value='');document.getElementById('ret-item').value='';document.getElementById('ret-dept').value='';document.getElementById('ret-cond').value='good';}
function renderReturns(){
  const tb=document.getElementById('ret-body');if(!tb){return;}
  const cmap={good:'<span class="bdg bg">Good</span>',partial:'<span class="bdg ba">Partial</span>',damaged:'<span class="bdg br">Damaged</span>'};
  tb.innerHTML=RET.length?RET.slice().reverse().map(r=>`<tr><td data-style="font-size:10px">${new Date(r.time).toLocaleString()}</td><td data-style="font-weight:500">${sanitizeHTML(String(r.materialName||""))}</td><td class="mono">${r.qty} ${sanitizeHTML(String(r.unit||""))}</td><td>${cmap[r.condition]||r.condition}</td><td>${sanitizeHTML(String(r.returnedBy||"-"))}</td><td>${sanitizeHTML(String(r.deptName||"-"))}</td><td data-style="font-size:11px">${sanitizeHTML(String(r.reason||"-"))}</td><td>${sanitizeHTML(String(r.userName||""))}</td></tr>`).join(''):'<tr><td colspan="8" data-style="text-align:center;color:var(--tx3);padding:16px">No returns recorded</td></tr>';
}

// ── Cycle Count ──
let ccItems=[];
function popCCCat(){const s=document.getElementById('cc-cat');if(!s){return;}const cats=[...new Set(M.filter(m=>m.active!==false).map(m=>m.category))].sort();s.innerHTML='<option value="">All Categories</option>'+cats.map(c=>`<option value="${sanitizeHTML(String(c))}">${sanitizeHTML(String(c))}</option>`).join('');}
function renderCCItems(){
  const cat=document.getElementById('cc-cat')?.value;
  const items=M.filter(m=>m.active!==false&&(!cat||m.category===cat));
  const counting=document.getElementById('cc-save-btn')?.style.display==='';
  const tb=document.getElementById('cc-body');if(!tb){return;}
  if(!counting){tb.innerHTML=items.length?items.map(m=>`<tr><td class="mono">${sanitizeHTML(String(m.barcode||""))}</td><td data-style="font-weight:500">${sanitizeHTML(String(m.name||""))}</td><td>${sanitizeHTML(String(m.category||""))}</td><td class="mono">${m.stock}</td><td data-style="color:var(--tx3)">—</td><td>—</td><td>—</td></tr>`).join(''):'<tr><td colspan="7" data-style="text-align:center;color:var(--tx3);padding:16px">No items</td></tr>';return;}
  tb.innerHTML=items.map(m=>{
    const prevCount=ccItems.find(c=>c.id===m.id)?.physical||'';
    const diff=prevCount!==''?parseInt(prevCount)-m.stock:null;
    const col=diff===null?'':diff===0?'var(--gn)':diff>0?'var(--bl)':'var(--rd)';
    const badge=diff===null?'—':diff===0?'<span class="bdg bg">OK</span>':diff>0?`<span class="bdg bb">+${diff}</span>`:`<span class="bdg br">${diff}</span>`;
    return `<tr><td class="mono">${sanitizeHTML(String(m.barcode||""))}</td><td data-style="font-weight:500">${sanitizeHTML(String(m.name||""))}</td><td>${sanitizeHTML(String(m.category||""))}</td><td class="mono" data-style="font-weight:600">${m.stock}</td><td><input type="number" min="0" data-style="width:70px;padding:3px 6px;background:var(--bg3);border:1px solid var(--b2);border-radius:var(--r);color:var(--tx);font-family:var(--mn);font-size:12px" value="${prevCount}" data-oninput="updateCCItem(${JSON.stringify(String(m.id))},this.value,${Number(m.stock)||0})" placeholder="—"></td><td class="mono" data-style="color:${col}" id="cc-diff-${m.id}">${diff!==null?diff:'-'}</td><td id="cc-badge-${m.id}">${badge}</td></tr>`;
  }).join('');
}
function updateCCItem(id,val,sysStock){
  const existing=ccItems.find(c=>c.id===id);
  const physical=val===''?null:Number(val);
  if(physical!==null&&(!Number.isInteger(physical)||physical<0)){toast('Physical count must be a non-negative whole number','er');return;}
  if(existing){existing.physical=physical;}else {ccItems.push({id,physical,sysStock});}
  const diff=physical!==null?physical-sysStock:null;
  const el=document.getElementById('cc-diff-'+id);const eb=document.getElementById('cc-badge-'+id);
  if(el){el.textContent=diff!==null?diff:'-';}
  if(el){el.style.color=diff===null?'':diff===0?'var(--gn)':diff>0?'var(--bl)':'var(--rd)';}
  if(eb){eb.innerHTML=diff===null?'—':diff===0?'<span class="bdg bg">OK</span>':diff>0?`<span class="bdg bb">+${diff}</span>`:`<span class="bdg br">${diff}</span>`;}
}
function startCycleCount(){ccItems=[];M.filter(m=>m.active!==false).forEach(m=>ccItems.push({id:m.id,physical:null,sysStock:Number(m.stock)||0,startedAt:new Date().toISOString()}));document.getElementById('cc-save-btn').style.display='';document.getElementById('cc-status').style.display='flex';renderCCItems();toast('Cycle count started — enter physical counts','inf');}
async function saveCycleCount(){
  const counted=ccItems.filter(c=>c.physical!==null);if(!counted.length){toast('Enter at least one physical count','er');return;}
  const stale=counted.filter(c=>{const current=M.find(m=>String(m.id)===String(c.id));return current && Number(current.stock)!==Number(c.sysStock);});
  if(stale.length){toast('Stock changed while count was in progress. Refresh and recount affected items before saving.','er');return;}
  const matched=counted.filter(c=>c.physical===c.sysStock).length;
  const variances=counted.filter(c=>c.physical!==c.sysStock);
  const rec={id:generateUUID(),time:new Date().toISOString(),user:cu.username,userName:cu.name,items:counted,matched,variances:variances.length,details:counted.map(c=>({id:c.id,sys:c.sysStock,physical:c.physical,diff:c.physical-c.sysStock}))};
  await dPut('cyclecount',rec);CC=await gAll('cyclecount');
  addAudit('CYCLECOUNT','Cycle count saved: '+counted.length+' items, '+variances.length+' variances','ADJUST');
  ccItems=[];document.getElementById('cc-save-btn').style.display='none';document.getElementById('cc-status').style.display='none';
  renderCCItems();renderCCHist();toast('Cycle count saved! '+variances.length+' variance(s) found.');
}
function renderCCHist(){
  const tb=document.getElementById('cc-hist-body');if(!tb){return;}
  const period=document.getElementById('cc-period')?.value||'all';
  const cutoff=period==='all'?0:Date.now()-Number(period)*86400000;
  const reports=CC.filter(c=>{const time=Date.parse(c?.time||'');return Number.isFinite(time)&&time>=cutoff;});
  const stats=computeStockAccuracy(reports);
  const summary=document.getElementById('cc-accuracy-summary');
  if(summary){summary.innerHTML=`<div class="met"><div class="met-v">${stats.counts}</div><div class="met-l">Count Sessions</div></div><div class="met"><div class="met-v">${stats.items}</div><div class="met-l">Items Counted</div></div><div class="met"><div class="met-v" data-style="color:${stats.accuracy>=95?'var(--gn)':'var(--am)'}">${stats.accuracy.toFixed(1)}%</div><div class="met-l">Exact Match Rate</div></div><div class="met"><div class="met-v" data-style="color:${stats.absoluteVariance?'var(--am)':'var(--gn)'}">${stats.absoluteVariance}</div><div class="met-l">Absolute Unit Variance</div></div>`;}
  tb.innerHTML=reports.length?reports.slice().reverse().map(c=>`<tr><td data-style="font-size:10px">${new Date(c.time).toLocaleString()}</td><td>${sanitizeHTML(String(c.userName||""))}</td><td>${Array.isArray(c.items)?c.items.length:0}</td><td data-style="color:var(--gn)">${Number(c.matched)||0}</td><td data-style="color:${c.variances>0?'var(--rd)':'var(--gn)'}">${Number(c.variances)||0}</td><td><button class="btn" data-style="padding:2px 6px;font-size:10px" data-onclick="showCCDetail(${JSON.stringify(String(c.id))})">Details</button></td></tr>`).join(''):'<tr><td colspan="6" data-style="text-align:center;color:var(--tx3);padding:16px">No counts in this period</td></tr>';
}
function computeStockAccuracy(counts){
  let items=0,matched=0,absoluteVariance=0;
  (Array.isArray(counts)?counts:[]).forEach(count=>{
    const details=Array.isArray(count?.details)?count.details:[];
    details.forEach(detail=>{const diff=Number(detail?.diff);if(!Number.isFinite(diff))return;items++;if(diff===0)matched++;absoluteVariance+=Math.abs(diff);});
  });
  return {counts:Array.isArray(counts)?counts.length:0,items,matched,accuracy:items?matched/items*100:0,absoluteVariance};
}
function showCCDetail(id){const r=CC.find(x=>x.id===id);if(!r){return;}const v=r.details.filter(d=>d.diff!==0);const mat=d=>M.find(m=>m.id===d.id);alert('Variances:\n'+v.map(d=>`${mat(d)?.name||d.id}: System ${d.sys} → Physical ${d.physical} (${d.diff>0?'+':''}${d.diff})`).join('\n'));}

// ── Consumption Report ──
function renderConsumption(){
  const {count:months,start:from,labels}=consumptionWindow(document.getElementById('con-months')?.value||6);
  const cat=document.getElementById('con-cat')?.value||'';
  const txs=T.filter(t=>t.type==='OUT'&&t.status==='confirmed'&&new Date(t.time)>=from&&(!cat||M.find(m=>String(m.id)===String(t.itemId)||m.barcode===t.barcode)?.category===cat));
  // Group by item
  const byItem={};txs.forEach(t=>{const mn=t.time.slice(0,7);if(!byItem[t.barcode]){byItem[t.barcode]={name:t.itemName,unit:t.unit,months:{}};}byItem[t.barcode].months[mn]=(byItem[t.barcode].months[mn]||0)+Number(t.qty||0);});
  const items=Object.entries(byItem).sort((a,b)=>Object.values(b[1].months).reduce((s,v)=>s+v,0)-Object.values(a[1].months).reduce((s,v)=>s+v,0));
  // Summary
  const totalQty=txs.reduce((s,t)=>s+Number(t.qty||0),0);const uniqueItems=[...new Set(txs.map(t=>t.barcode))].length;
  document.getElementById('con-summary').innerHTML=`<div class="met"><div class="met-v" data-style="color:var(--rd)">${totalQty}</div><div class="met-l">Total OUT</div></div><div class="met"><div class="met-v">${uniqueItems}</div><div class="met-l">Items Used</div></div><div class="met"><div class="met-v">${months}</div><div class="met-l">Months</div></div><div class="met"><div class="met-v" data-style="color:var(--am)">${Math.round(totalQty/(months||1))}</div><div class="met-l">Avg/Month</div></div>`;
  // Simple bar chart
  const monthTotals=labels.map(mn=>txs.filter(t=>t.time.startsWith(mn)).reduce((s,t)=>s+Number(t.qty||0),0));
  const maxV=Math.max(...monthTotals,1);
  document.getElementById('con-chart').innerHTML=`<div data-style="background:var(--bg3);border:1px solid var(--b1);border-radius:var(--r);padding:12px"><div data-style="font-size:11px;font-weight:600;margin-bottom:8px;color:var(--tx2)">Monthly OUT Qty</div><div data-style="display:flex;align-items:flex-end;gap:6px;height:80px">${labels.map((mn,i)=>`<div data-style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px"><div data-style="width:100%;background:var(--rd);border-radius:2px 2px 0 0;height:${Math.round((monthTotals[i]/maxV)*70)+10}px;min-height:4px" title="${monthTotals[i]}"></div><div data-style="font-size:9px;color:var(--tx3)">${mn.slice(5)}</div></div>`).join('')}</div></div>`;
  // Table
  const hd=document.getElementById('con-head');const bd=document.getElementById('con-body');
  hd.innerHTML='<th>Material</th><th>Unit</th>'+labels.map(m=>`<th>${m.slice(5)}</th>`).join('')+'<th>Total</th><th>Avg/Mo</th>';
  bd.innerHTML=items.map(([bc,it])=>{const tot=Object.values(it.months).reduce((s,v)=>s+v,0);const avg=Math.round(tot/months);return `<tr><td data-style="font-weight:500">${sanitizeHTML(String(it.name||""))}</td><td>${sanitizeHTML(String(it.unit||""))}</td>${labels.map(mn=>`<td class="mono" data-style="color:${it.months[mn]>0?'var(--rd)':'var(--tx3)'}">${it.months[mn]||'-'}</td>`).join('')}<td class="mono" data-style="font-weight:600;color:var(--rd)">${tot}</td><td class="mono" data-style="color:var(--am)">${avg}</td></tr>`;}).join('')||'<tr><td colspan="20" data-style="text-align:center;color:var(--tx3);padding:16px">No OUT transactions in this period</td></tr>';
  // Populate category filter
  const cats=[...new Set(M.map(m=>m.category))].sort();const cs=document.getElementById('con-cat');if(cs&&cs.options.length<=1){cats.forEach(c=>{const safe=escapeHTML(String(c??''));cs.innerHTML+=`<option value="${safe}">${safe}</option>`;});}
}
function popConCat(){const cats=[...new Set(M.map(m=>m.category))].sort();const cs=document.getElementById('con-cat');if(cs){cs.innerHTML='<option value="">All Categories</option>'+cats.map(c=>{const safe=escapeHTML(String(c??''));return `<option value="${safe}">${safe}</option>`;}).join('');}}

// ── Reorder / PO Draft ──
const poSelected=new Set();
// ── Stock-Out Forecast (replaces modules/predictiveAnalytics.js's fake
// Math.random() "regression" predictions with real math — see that file's
// generateRegressionPredictions(): it returns Math.random()*100 regardless
// of input. That's not usable for real inventory decisions, so this
// computes an honest days-until-stockout estimate from actual consumption:
// avgDailyDemand = confirmed OUT qty in the last 30 days ÷ 30. Same demand
// calculation smartRecommendations.js's reorder logic already uses. ──
async function renderStockForecast(){
  const el=document.getElementById('stock-forecast-panel');
  if(!el){return;}
  // modules/cacheManager.js — real usage: skip recompute within a 2-min TTL window
  const cacheKey='stock-forecast';
  let urgent=window.cacheManager?window.cacheManager.get(cacheKey):null;
  if(!urgent){
    const t0=performance.now();
    const thirtyDaysAgo=Date.now()-30*24*60*60*1000;
    const recentOut=T.filter(t=>t.type==='OUT'&&t.status==='confirmed'&&new Date(t.time).getTime()>=thirtyDaysAgo);
    const demandByMat={};recentOut.forEach(t=>{const itemId=t.itemId ?? t.matId; if(itemId!=null) demandByMat[itemId]=(demandByMat[itemId]||0)+Number(t.qty||0);});
    const forecasts=[];
    for(const m of M){
      if(m.active===false||Number(m.stock)<=0){continue;}
      const avgDaily=(demandByMat[m.id]||0)/30;
      if(avgDaily<=0){continue;} // no recent usage — nothing meaningful to forecast
      const daysLeft=Number(m.stock)/avgDaily;
      forecasts.push({id:m.id,name:m.name,stock:m.stock,unit:m.unit,avgDaily,daysLeft});
    }
    forecasts.sort((a,b)=>a.daysLeft-b.daysLeft);
    urgent=forecasts.filter(f=>f.daysLeft<=30).slice(0,15);
    if(window.cacheManager){window.cacheManager.set(cacheKey,urgent,120000);}
    // modules/performanceMonitor.js — real usage: track how long this takes
    if(window.performanceMonitor){window.performanceMonitor.recordMetric({name:'stock_forecast_calc',type:'custom',value:performance.now()-t0,unit:'ms'});}
  }
  if(!urgent.length){
    el.innerHTML='<div data-style="color:var(--gn)">✓ No materials with active consumption are projected to run out within 30 days</div>';
  }else{
    el.innerHTML='<div class="tw"><table><thead><tr><th>Material</th><th>Current Stock</th><th>Avg Daily Use (30d)</th><th>Est. Days Left</th></tr></thead><tbody>'+
      urgent.map(f=>{
        const color=f.daysLeft<=7?'var(--rd)':f.daysLeft<=14?'var(--am)':'var(--tx2)';
        return `<tr><td>${sanitizeHTML(f.name)}</td><td>${f.stock} ${sanitizeHTML(f.unit||'')}</td><td>${f.avgDaily.toFixed(2)}</td><td data-style="color:${color};font-weight:600">${Math.floor(f.daysLeft)} days</td></tr>`;
      }).join('')+'</tbody></table></div>';
  }
  // Persist a snapshot each time this is viewed — gives stock_predictions
  // store a genuine purpose (history of forecasts over time) instead of
  // sitting declared-but-empty.
  try{
    await dPut('stock_predictions',{id:'snapshot-'+new Date().toISOString().slice(0,10),date:new Date().toISOString(),forecasts:urgent.map(f=>({materialId:f.id,name:f.name,daysLeft:Math.floor(f.daysLeft)}))});
  }catch(e){/* non-fatal */}
}

function renderReorder(){
  const sf=document.getElementById('po-supp-flt');
  if(sf&&sf.options.length<=1){SP.forEach(s=>sf.add(new Option(String(s.name||''),String(s.id))));}
  const suppFlt=sf?.value||'';
  const low=reorderCandidates(M,suppFlt);
  const sum=document.getElementById('ro-summary');
  if(sum){sum.innerHTML=`<div class="g4" data-style="margin-bottom:10px"><div class="met"><div class="met-v" data-style="color:var(--rd)">${low.length}</div><div class="met-l">Items to Reorder</div></div><div class="met"><div class="met-v" data-style="color:var(--rd)">${low.filter(isZeroStockMaterial).length}</div><div class="met-l">Out of Stock</div></div></div>`;}
  const tb=document.getElementById('ro-body');if(!tb){return;}
  tb.innerHTML=low.length?low.map(m=>{const qty=suggestedOrderQty(m);return `<tr><td><input type="checkbox" ${poSelected.has(String(m.id))?'checked':''} data-onchange="togglePO(${JSON.stringify(String(m.id))},this.checked)"></td><td class="mono">${sanitizeHTML(String(m.barcode||""))}</td><td data-style="font-weight:500">${sanitizeHTML(String(m.name||""))}</td><td>${sanitizeHTML(String(m.category||""))}</td><td class="mono" data-style="color:${Number(m.stock)===0?'var(--rd)':'var(--am)'}">${Number(m.stock)||0}</td><td class="mono">${Number(m.lowAlert)||0}</td><td class="mono" data-style="color:var(--bl)">${qty}</td><td><select data-style="background:var(--bg3);border:1px solid var(--b1);border-radius:var(--r);color:var(--tx);font-size:10px;padding:2px 4px" id="po-supp-${m.id}"><option value="">— Supplier —</option>${SP.map(s=>`<option value="${sanitizeHTML(String(s.id))}" ${String(m.preferredSupplierId||m.supplierId||'')===String(s.id)?'selected':''}>${sanitizeHTML(String(s.name||""))}</option>`).join('')}</select></td><td class="mono">${Number(m.unitCost||m.unitPrice||0).toFixed(2)}</td></tr>`;}).join(''):'<tr><td colspan="9" data-style="text-align:center;color:var(--gn);padding:16px">✓ All stock is at or above the required level — no reorder needed</td></tr>';
  const selectAll=document.getElementById('po-all');if(selectAll){selectAll.checked=low.length>0&&low.every(m=>poSelected.has(String(m.id)));}
}
function togglePO(id,checked){const key=String(id);if(checked){poSelected.add(key);}else {poSelected.delete(key);}}
function toggleAllPO(cb){const supplierId=document.getElementById('po-supp-flt')?.value||'';const visible=reorderCandidates(M,supplierId);visible.forEach(m=>{const key=String(m.id);if(cb.checked){poSelected.add(key);}else {poSelected.delete(key);}});renderReorder();}
function genPODraft(){
  const supplierId=document.getElementById('po-supp-flt')?.value||'';
  const candidates=reorderCandidates(M,supplierId);
  const candidateIds=new Set(candidates.map(m=>String(m.id)));
  for(const id of [...poSelected]){if(!candidateIds.has(String(id))){poSelected.delete(id);}}
  let items=candidates.filter(m=>poSelected.has(String(m.id)));
  if(!items.length){if(!candidates.length){toast('No items below the required stock level','inf');return;}candidates.forEach(m=>poSelected.add(String(m.id)));items=candidates;}
  const co=CFG.company||'Your Company';const dt=new Date().toLocaleDateString();const poNo='PO-'+Date.now().toString().slice(-6);
  const rows=items.map((m,i)=>{const supplierId=document.getElementById(`po-supp-${m.id}`)?.value||m.preferredSupplierId||m.supplierId||'';const supplier=SP.find(x=>String(x.id)===String(supplierId));const rate=Number(m.unitCost||m.unitPrice||0);const qty=suggestedOrderQty(m);return `<tr><td>${i+1}</td><td class="mono">${sanitizeHTML(String(m.barcode||''))}</td><td>${sanitizeHTML(String(m.name||''))}</td><td>${sanitizeHTML(String(m.unit||''))}</td><td class="mono">${qty}</td><td class="mono">${sanitizeHTML(String(m.hsn||'-'))}</td><td>${rate?rate.toFixed(2):'—'}</td><td>${rate?(rate*qty).toFixed(2):'—'}</td><td>${sanitizeHTML(String(supplier?.name||'—'))}</td></tr>`;}).join('');
  document.getElementById('po-content').innerHTML=`<div data-style="background:#fff;color:#000;padding:10mm;font-family:Arial,sans-serif;font-size:10pt;border:1px solid var(--b1);border-radius:var(--r)"><div data-style="display:flex;justify-content:space-between;margin-bottom:4mm"><div><h2 data-style="margin:0;font-size:16pt">${sanitizeHTML(String(co))}</h2><p data-style="margin:2px 0;font-size:9pt">${sanitizeHTML(String(CFG.addr||''))}</p><p data-style="margin:2px 0;font-size:9pt">GSTIN: ${sanitizeHTML(String(CFG.gst||'-'))}</p></div><div data-style="text-align:right"><h3 data-style="margin:0;font-size:14pt;color:#1e55cc">PURCHASE ORDER</h3><p data-style="margin:2px 0;font-size:10pt">PO No: <b>${poNo}</b></p><p data-style="margin:2px 0;font-size:9pt">Date: ${dt}</p></div></div><hr data-style="border-top:1px solid #000;margin:2mm 0"><table data-style="width:100%;border-collapse:collapse;margin-top:4mm"><thead><tr data-style="background:#eee"><th data-style="border:1px solid #ccc;padding:2mm;text-align:left">Sr.</th><th data-style="border:1px solid #ccc;padding:2mm;text-align:left">Barcode</th><th data-style="border:1px solid #ccc;padding:2mm;text-align:left">Item Name</th><th data-style="border:1px solid #ccc;padding:2mm;text-align:left">Unit</th><th data-style="border:1px solid #ccc;padding:2mm;text-align:left">Order Qty</th><th data-style="border:1px solid #ccc;padding:2mm;text-align:left">HSN</th><th data-style="border:1px solid #ccc;padding:2mm;text-align:left">Rate</th><th data-style="border:1px solid #ccc;padding:2mm;text-align:left">Amount</th></tr></thead><tbody>${rows}</tbody></table><div data-style="display:flex;justify-content:space-between;margin-top:14mm"><div data-style="text-align:center;width:30%"><div data-style="border-top:1px solid #000;padding-top:2mm;font-size:9pt">Prepared By</div></div><div data-style="text-align:center;width:30%"><div data-style="border-top:1px solid #000;padding-top:2mm;font-size:9pt">Approved By</div></div><div data-style="text-align:center;width:30%"><div data-style="border-top:1px solid #000;padding-top:2mm;font-size:9pt">Supplier Signature</div></div></div></div>`;
  document.getElementById('po-draft-card').style.display='';
  addAudit('PO','PO Draft generated: '+poNo+' | '+items.length+' items','SYSTEM');
  toast('PO Draft '+poNo+' generated!');
}
function printPO(){const c=document.getElementById('po-content').innerHTML;const html=`<!DOCTYPE html><html><head><style>body{margin:0;padding:8mm}@media print{body{margin:0}}</style></head><body>${c}</body></html>`;window.printPopupHtml(html);}

// ── Helper: FIX #4 — safe download with automatic object URL revocation ────────
function _dlCSV(csv, filename) {
  const url = URL.createObjectURL(new Blob([csv], {type:'text/csv'}));
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000); // FIX #4: prevent memory leak
}

// ── CSV export for new types ──
function exportCSV(type){
  if(type==='stockaccuracy'){
    const period=document.getElementById('cc-period')?.value||'all';
    const cutoff=period==='all'?0:Date.now()-Number(period)*86400000;
    const reports=CC.filter(c=>{const time=Date.parse(c?.time||'');return Number.isFinite(time)&&time>=cutoff;});
    const stats=computeStockAccuracy(reports);
    if(!stats.items){toast('No cycle-count detail in this period','inf');return;}
    const d=new Date().toISOString().slice(0,10);
    const rows=[['Count Date','Counted By','Barcode','Material','System Qty','Physical Qty','Variance','Match']];
    reports.forEach(count=>(Array.isArray(count.details)?count.details:[]).forEach(detail=>{
      const material=M.find(item=>String(item.id)===String(detail.id));
      rows.push([new Date(count.time).toLocaleString(),count.userName||count.user||'',material?.barcode||'',material?.name||detail.id,detail.sys,detail.physical,detail.diff,Number(detail.diff)===0?'MATCH':'VARIANCE']);
    }));
    const preview=`Stock accuracy export preview\n\nPeriod: ${period==='all'?'All counts':`Last ${period} days`}\nCount sessions: ${stats.counts}\nItems counted: ${stats.items}\nExact match rate: ${stats.accuracy.toFixed(1)}%\nAbsolute unit variance: ${stats.absoluteVariance}\n\nContinue with CSV download?`;
    if(!confirm(preview)){return;}
    void startCSVExport(rows,`stock_accuracy_${d}.csv`);return;
  }
  if(type==='indent'){
    const d=new Date().toISOString().slice(0,10);const rows=[['Date','Indent No','Material','Barcode','Qty','Unit','Dept','Priority','Req Date','Status','Purpose / Job No.','Remarks','Req By']];
    IN_REQ.slice().reverse().forEach(x=>rows.push([new Date(x.time).toLocaleString(),x.indentNo,x.materialName,x.barcode,x.qty,x.unit,x.deptName||'',x.priority,x.reqDate||'',x.status,x.job||'',x.remarks||'',x.reqByName]));
    void startCSVExport(rows,`indents_${d}.csv`);return;
  }
  if(type==='cyclecount'){
    const d=new Date().toISOString().slice(0,10);const last=CC[CC.length-1];if(!last){toast('No cycle count data','inf');return;}
    const rows=[['Barcode','Name','System Qty','Physical Count','Variance','Status']];
    last.details.forEach(x=>{const mat=M.find(m=>m.id===x.id);rows.push([mat?.barcode||'',mat?.name||x.id,x.sys,x.physical,x.diff,x.diff===0?'OK':'VARIANCE']);});
    void startCSVExport(rows,`cyclecount_${d}.csv`);return;
  }
  if(type==='consume'){
    const {count:months,start:from}=consumptionWindow(document.getElementById('con-months')?.value||6);
    const cat=document.getElementById('con-cat')?.value||'';
    const txs=T.filter(t=>t.type==='OUT'&&t.status==='confirmed'&&new Date(t.time)>=from&&(!cat||M.find(m=>String(m.id)===String(t.itemId)||m.barcode===t.barcode)?.category===cat));
    const d=new Date().toISOString().slice(0,10);const rows=[['Material','Barcode','Unit','Total OUT','Avg/Month']];
    const byItem={};txs.forEach(t=>{if(!byItem[t.barcode]){byItem[t.barcode]={name:t.itemName,unit:t.unit,tot:0};}byItem[t.barcode].tot+=t.qty;});
    Object.entries(byItem).forEach(([bc,it])=>rows.push([it.name,bc,it.unit,it.tot,Math.round(it.tot/months)]));
    void startCSVExport(rows,`consumption_${d}.csv`);return;
  }
  if(type==='reorder'){
    const low=reorderCandidates(M,document.getElementById('po-supp-flt')?.value||'');
    const d=new Date().toISOString().slice(0,10);const rows=[['Barcode','Name','Category','Available Qty','Required Qty','Suggested Order Qty','Status']];
    low.forEach(m=>{const stock=numericStockValue(m.stock)||0,alert=numericStockValue(m.lowAlert)||0;rows.push([m.barcode,m.name,m.category,stock,alert,suggestedOrderQty(m),isZeroStockMaterial(m)?'OUT':'LOW']);});
    void startCSVExport(rows,`reorder_${d}.csv`);return;
  }
  if(type==='grn'){
    const d=new Date().toISOString().slice(0,10);
    const rows=[['GRN No','Date','Supplier','PO','Invoice','Items','Total Qty','Received By']];
    validGRNRowsOrWarn(GRN,'export').slice().reverse().forEach(g=>rows.push([g.grnNo,new Date(g.time).toLocaleString(),g.supplierName||'',g.po||'',g.invoice||'',g.items.length,g.totalQty,g.receivedBy]));
    void startCSVExport(rows,`grn_${d}.csv`);return;
  }
  // Fall back to core function for standard types
  _exportCSVCore(type);
}

// ── GRN ──
function popGRNFilters(){const s=document.getElementById('grn-flt-supp');if(!s){return;}s.innerHTML='<option value="">All Suppliers</option>'+SP.map(x=>`<option value="${sanitizeHTML(String(x.id))}">${sanitizeHTML(String(x.name||""))}</option>`).join('');}
function renderGRN(){
  const flt=document.getElementById('grn-flt-supp')?.value;
  const safeGRN=validGRNRowsOrWarn(GRN,'render');
  const list=safeGRN.filter(g=>!flt||g.supplierId==flt).slice().reverse();
  const tb=document.getElementById('grn-body');if(!tb){return;}
  tb.innerHTML=list.length?list.map(g=>`<tr>
    <td class="mono" data-style="font-weight:600;color:var(--bl)">${sanitizeHTML(String(g.grnNo||''))}</td>
    <td data-style="font-size:10px">${new Date(g.time).toLocaleString()}</td>
    <td>${sanitizeHTML(String(g.supplierName||'—'))}</td>
    <td class="mono">${sanitizeHTML(String(g.po||'—'))}</td>
    <td class="mono">${sanitizeHTML(String(g.invoice||'—'))}</td>
    <td>${g.items.length}</td>
    <td class="mono">${g.totalQty}</td>
    <td>${sanitizeHTML(String(g.receivedBy||'—'))}</td>
    <td><button class="btn" data-style="padding:3px 7px;font-size:10px" data-onclick="printGRN(${JSON.stringify(String(g.id))})">🖨 Print</button></td>
  </tr>`).join(''):'<tr><td colspan="9" data-style="text-align:center;color:var(--tx3);padding:16px">No GRNs yet — auto-created when Material IN is done</td></tr>';
}
function printGRN(id){
  const g=GRN.find(x=>x.id===id);if(!g){return;}if(!isValidGRNRecord(g)){toast('Cannot print this GRN: record is malformed. Repair or restore it first.','er');return;}
  const co=CFG.company||'Your Company';
  const rows=g.items.map((it,i)=>`<tr><td>${i+1}</td><td>${sanitizeHTML(String(it.barcode||''))}</td><td>${sanitizeHTML(String(it.materialName||''))}</td><td>${sanitizeHTML(String(it.unit||''))}</td><td>${Number(it.qty)||0}</td><td>${sanitizeHTML(String(it.batch||'—'))}</td><td></td></tr>`).join('');
  const html = `<!DOCTYPE html><html><head><style>body{font-family:Arial,sans-serif;font-size:10pt;margin:8mm}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:4px 6px;text-align:left}th{background:#eee}h2{margin:0}@media print{body{margin:0}}</style></head><body>
  <div style="display:flex;justify-content:space-between;margin-bottom:4mm"><div><h2>${sanitizeHTML(String(co))}</h2><p style="margin:2px 0">${sanitizeHTML(String(CFG.addr||''))}</p></div><div style="text-align:right"><h3 style="color:#1e55cc">GOODS RECEIPT NOTE</h3><p>GRN No: <b>${sanitizeHTML(String(g.grnNo||''))}</b></p><p>Date: ${new Date(g.time).toLocaleDateString()}</p></div></div>
  <table style="margin-bottom:4mm"><tr><th>Supplier</th><td>${sanitizeHTML(String(g.supplierName||'—'))}</td><th>PO No.</th><td>${sanitizeHTML(String(g.po||'—'))}</td></tr><tr><th>Invoice No.</th><td>${sanitizeHTML(String(g.invoice||'—'))}</td><th>Received By</th><td>${sanitizeHTML(String(g.receivedBy||'—'))}</td></tr></table>
  <table><thead><tr><th>Sr.</th><th>Barcode</th><th>Item Name</th><th>Unit</th><th>Qty Received</th><th>Batch No.</th><th>Remarks</th></tr></thead><tbody>${rows}</tbody></table>
  <div style="display:flex;justify-content:space-between;margin-top:14mm"><div style="text-align:center;width:30%"><div style="border-top:1px solid #000;padding-top:2mm">Store Keeper</div></div><div style="text-align:center;width:30%"><div style="border-top:1px solid #000;padding-top:2mm">Checked By</div></div><div style="text-align:center;width:30%"><div style="border-top:1px solid #000;padding-top:2mm">Supplier Representative</div></div></div>
  </body></html>`;
  window.printPopupHtml(html);
  addAudit('GRN','GRN printed: '+g.grnNo,'SYSTEM');
}

// ── Monthly Summary Report ──
function initMonthlySummary(){
  const ms=document.getElementById('ms-month');const ys=document.getElementById('ms-year');
  if(!ms||!ys){return;}
  if(ms.options.length===0){
    const months=['January','February','March','April','May','June','July','August','September','October','November','December'];
    months.forEach((m,i)=>ms.innerHTML+=`<option value="${i}">${m}</option>`);
    ms.value=new Date().getMonth();
  }
  if(ys.options.length===0){
    const yr=new Date().getFullYear();
    for(let y=yr;y>=yr-3;y--){ys.innerHTML+=`<option value="${y}">${y}</option>`;}
  }
  renderMonthlySummary();
}
function renderMonthlySummary(){
  const month=parseInt(document.getElementById('ms-month')?.value??new Date().getMonth(), 10);
  const year=parseInt(document.getElementById('ms-year')?.value??new Date().getFullYear(), 10);
  const from=new Date(year,month,1);const to=new Date(year,month+1,1);
  const txs=T.filter(t=>t.status==='confirmed'&&new Date(t.time)>=from&&new Date(t.time)<to);
  const inTxs=txs.filter(t=>t.type==='IN');const outTxs=txs.filter(t=>t.type==='OUT');
  const inQty=inTxs.reduce((s,t)=>s+Number(t.qty||0),0);const outQty=outTxs.reduce((s,t)=>s+Number(t.qty||0),0);
  const low=M.filter(isLowStockMaterial);
  // Top 10 consumed
  const byItem={};outTxs.forEach(t=>{if(!byItem[t.barcode]){byItem[t.barcode]={name:t.itemName,qty:0};}byItem[t.barcode].qty+=Number(t.qty||0);});
  const top10=Object.entries(byItem).sort((a,b)=>b[1].qty-a[1].qty).slice(0,10);
  const mName=['January','February','March','April','May','June','July','August','September','October','November','December'][month];
  document.getElementById('ms-content').innerHTML=`
  <div id="ms-print-area">
    <div data-style="border-bottom:2px solid var(--b2);padding-bottom:10px;margin-bottom:14px">
      <div data-style="font-size:16px;font-weight:600">${sanitizeHTML(String(CFG.company||'StoreTrack'))} — Monthly Summary</div>
      <div data-style="font-size:12px;color:var(--tx3)">${mName} ${year} &nbsp;|&nbsp; Generated: ${new Date().toLocaleString()} &nbsp;|&nbsp; By: ${sanitizeHTML(String(cu?.name||'—'))}</div>
    </div>
    <div class="g4" data-style="margin-bottom:14px">
      <div class="met"><div class="met-v" data-style="color:var(--gn)">${inTxs.length}</div><div class="met-l">IN Transactions</div></div>
      <div class="met"><div class="met-v" data-style="color:var(--gn)">${inQty}</div><div class="met-l">Total IN Qty</div></div>
      <div class="met"><div class="met-v" data-style="color:var(--rd)">${outTxs.length}</div><div class="met-l">OUT Transactions</div></div>
      <div class="met"><div class="met-v" data-style="color:var(--rd)">${outQty}</div><div class="met-l">Total OUT Qty</div></div>
      <div class="met"><div class="met-v" data-style="color:var(--am)">${low.length}</div><div class="met-l">Low Stock Now</div></div>
      <div class="met"><div class="met-v">${[...new Set(txs.map(t=>t.barcode))].length}</div><div class="met-l">Active Materials</div></div>
      <div class="met"><div class="met-v">${GRN.filter(g=>new Date(g.time)>=from&&new Date(g.time)<=to).length}</div><div class="met-l">GRNs This Month</div></div>
      <div class="met"><div class="met-v">${IN_REQ.filter(x=>new Date(x.time)>=from&&new Date(x.time)<=to).length}</div><div class="met-l">Indents Raised</div></div>
    </div>
    ${top10.length?`<div data-style="font-size:12px;font-weight:600;margin-bottom:8px">Top 10 Consumed Materials</div>
    <div class="tw"><table><thead><tr><th>Rank</th><th>Material</th><th>Total OUT Qty</th><th>% of Total</th></tr></thead><tbody>
    ${top10.map(([bc,it],i)=>`<tr><td>${i+1}</td><td data-style="font-weight:500">${sanitizeHTML(String(it.name||''))}</td><td class="mono" data-style="color:var(--rd)">${it.qty}</td><td class="mono">${outQty?Math.round(it.qty/outQty*100):0}%</td></tr>`).join('')}
    </tbody></table></div>`:''}
    ${low.length?`<div data-style="font-size:12px;font-weight:600;margin:12px 0 8px">Current Low Stock (${low.length} items)</div>
    <div class="tw"><table><thead><tr><th>Material</th><th>Barcode</th><th>Stock</th><th>Required Qty</th><th>Suggested Order Qty</th></tr></thead><tbody>
    ${low.map(m=>`<tr><td>${sanitizeHTML(String(m.name||''))}</td><td class="mono">${sanitizeHTML(String(m.barcode||''))}</td><td class="mono" data-style="color:${m.stock===0?'var(--rd)':'var(--am)'}">${m.stock}</td><td class="mono">${m.lowAlert}</td><td class="mono" data-style="color:var(--rd)">${Math.max(0,m.lowAlert-m.stock)}</td></tr>`).join('')}
    </tbody></table></div>`:''}
    <div data-style="display:flex;justify-content:space-between;margin-top:20px;padding-top:10px;border-top:1px solid var(--b1);font-size:10px;color:var(--tx3)">
      <span>StoreTrack Pro &nbsp;|&nbsp; ${sanitizeHTML(String(CFG.addr||''))}</span>
      <span>Page 1</span>
    </div>
  </div>`;
}
function printMonthlySummary(){
  const c=document.getElementById('ms-print-area');if(!c){toast('Generate report first','inf');return;}
  const html=`<!DOCTYPE html><html><head><style>body{font-family:Arial,sans-serif;font-size:10pt;margin:12mm;color:#000}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:4px 6px;text-align:left}th{background:#f0f0f0}.g4{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px}.met{background:#f9f9f9;border:1px solid #ddd;border-radius:4px;padding:8px;text-align:center}.met-v{font-size:20px;font-weight:600}.met-l{font-size:9pt;color:#666}@media print{body{margin:0}}</style></head><body>${c.innerHTML}</body></html>`;
  window.printPopupHtml(html);
}

// ── Smart Excel / PDF / Word Import ──
let siRawRows = [];
let siHeaders = [];
let siMappedData = [];
let siFileType = '';
let siMapping = {};
if (typeof window !== 'undefined') {
  Object.defineProperty(window, 'siMapping', { configurable: true, get: () => siMapping, set: value => { siMapping = value; } });
}

const SI_FIELDS = [
  { key:'partno',     label:'Part No / Barcode',  required:true,  default:null },
  { key:'name',       label:'Material Name',       required:true,  default:null },
  { key:'category',   label:'Category',            required:false, default:'General' },
  { key:'unit',       label:'Unit',                required:false, default:'Pcs' },
  { key:'stock',      label:'Opening Stock',       required:false, default:'0' },
  { key:'lowalert',   label:'Low Alert Level',     required:false, default:'10' },
  { key:'reorderqty', label:'Suggested Order Qty',         required:false, default:'0' },
  { key:'location',   label:'Rack / Location',     required:false, default:'' },
];

function autoDetectMapping(headers) {
  const mapping = {};
  const lower = headers.map(h => h.toLowerCase().replace(/[\s_\-\/\.]/g,''));
  SI_FIELDS.forEach(f => {
    let idx = -1;
    if (f.key==='partno')     {idx = lower.findIndex(h=>h.includes('partno')||h.includes('partnumber')||h.includes('part#')||h==='part'||h.includes('code')||h.includes('barcode')||h.includes('itemno')||h.includes('srno'));}
    else if(f.key==='name')   {idx = lower.findIndex(h=>h.includes('name')||h.includes('description')||h.includes('item')||h.includes('material')||h.includes('desc'));}
    else if(f.key==='category') {idx = lower.findIndex(h=>h.includes('category')||h.includes('group')||h.includes('type')||h==='cat');}
    else if(f.key==='unit')   {idx = lower.findIndex(h=>h==='unit'||h.includes('uom')||h.includes('measure'));}
    else if(f.key==='stock')  {idx = lower.findIndex(h=>h.includes('stock')||h.includes('qty')||h.includes('quantity')||h.includes('opening')||h.includes('bal'));}
    else if(f.key==='lowalert') {idx = lower.findIndex(h=>h.includes('alert')||h.includes('minstock')||h.includes('minimum'));}
    else if(f.key==='reorderqty') {idx = lower.findIndex(h=>(h.includes('reorder')&&h.includes('qty'))||h.includes('orderqty')||h.includes('moq'));}
    else if(f.key==='location') {idx = lower.findIndex(h=>h.includes('location')||h.includes('rack')||h.includes('bin')||h.includes('shelf'));}
    mapping[f.key] = idx;
  });
  return mapping;
}

async function openSmartImport(event) {
  if(typeof canRoleAction!=='function'||!canRoleAction('imports')){if(event?.target)event.target.value='';return;}
  const file = event.target.files[0];
  if (!file) {return;}
  event.target.value = '';
  siFileType = file.name.split('.').pop().toLowerCase();
  document.getElementById('si-loading').style.display = 'block';
  document.getElementById('si-step1').style.display = 'none';
  document.getElementById('si-step2').style.display = 'none';
  document.getElementById('si-next-btn').style.display = 'none';
  document.getElementById('si-import-btn').style.display = 'none';
  document.getElementById('smart-import-ov').classList.add('on');
  try {
    if (siFileType==='xlsx'||siFileType==='xls') { await parseExcelFile(file); }
    else if (siFileType==='csv') { await parseCsvFile(file); }
    else { toast('Only .csv, .xlsx or .xls files are supported', 'er'); closeSmartImport(); }
  } catch(e) {
    console.error(e);
    toast('File parse error: ' + e.message, 'er');
    closeSmartImport();
  }
}

// ── CSV parser path for the same safe preview workflow ──
async function parseCsvFile(file) {
  const text = await file.text();
  const rows = parseImportCSV(text);
  if (!rows || rows.length < 2) { toast('CSV is empty or contains no data rows', 'er'); closeSmartImport(); return; }
  siHeaders = rows[0].map(h=>String(h||'').trim());
  siRawRows = rows.slice(1).filter(r=>r.some(c=>String(c??'').trim()!=='')).map(r=>siHeaders.map((_,i)=>r[i]??''));
  document.getElementById('si-filename').textContent = file.name;
  document.getElementById('si-rowcount').textContent = siRawRows.length + ' rows detected';
  document.getElementById('si-loading').style.display = 'none';
  document.getElementById('si-step1').style.display = 'block';
  document.getElementById('si-next-btn').style.display = '';
  siMapping = autoDetectMapping(siHeaders);
  renderMappingGrid();
}
// ── Pure JS Excel (.xlsx) Parser ──
async function parseExcelFile(file) {
  const buf = await file.arrayBuffer();
  const bytes = new Uint8Array(buf);
  const zipFiles = await unzipXlsx(bytes);
  const sharedStrings = parseSharedStrings(zipFiles['xl/sharedStrings.xml'] || '');
  const sheetXml = zipFiles['xl/worksheets/sheet1.xml'] || zipFiles['xl/worksheets/Sheet1.xml'] || '';
  if (!sheetXml) { toast('sheet1 not found in Excel file', 'er'); closeSmartImport(); return; }
  const rows = parseSheetXml(sheetXml, sharedStrings);
  if (!rows || rows.length < 2) { toast('No data found in Excel file', 'er'); closeSmartImport(); return; }
  let hi = 0;
  for (let i = 0; i < Math.min(5, rows.length); i++) { if (rows[i].some(c=>c!==''&&c!==null)) { hi=i; break; } }
  siHeaders = rows[hi].map(h=>String(h||'').trim());
  siRawRows = rows.slice(hi+1).filter(r=>r.some(c=>c!==''&&c!==null));
  document.getElementById('si-filename').textContent = file.name;
  document.getElementById('si-rowcount').textContent = siRawRows.length + ' rows detected';
  document.getElementById('si-loading').style.display = 'none';
  document.getElementById('si-step1').style.display = 'block';
  document.getElementById('si-next-btn').style.display = '';
  siMapping = autoDetectMapping(siHeaders);
  renderMappingGrid();
}

function parseSharedStrings(xml) {
  if (!xml) {return [];}
  const arr = [];
  for (const m of xml.matchAll(/<si[^>]*>([\s\S]*?)<\/si>/g)) {
    arr.push(m[1].replace(/<[^>]+>/g,'').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').trim());
  }
  return arr;
}

function parseSheetXml(xml, ss) {
  const rows = [];
  const rowRegex = /<row[^>]*>([\s\S]*?)<\/row>/g;
  const cellRegex = /<c ([^>]*)>([\s\S]*?)<\/c>/g;
  let rowMatch;
  
  while ((rowMatch = rowRegex.exec(xml)) !== null) {
    const cells = {};
    let maxCol = 0;
    const rowXml = rowMatch[1];
    let cellMatch;
    
    // Reset regex for each row
    cellRegex.lastIndex = 0;
    
    while ((cellMatch = cellRegex.exec(rowXml)) !== null) {
      const rM = cellMatch[1].match(/r="([A-Z]+)\d+"/);
      if (!rM) {continue;}
      const col = rM[1].split('').reduce((n,c)=>n*26+(c.charCodeAt(0)-64),0)-1;
      const tM = cellMatch[1].match(/t="([^"]+)"/);
      const vM = cellMatch[2].match(/<v>([^<]*)<\/v>/);
      const iM = cellMatch[2].match(/<is>[\s\S]*?<t>([^<]*)<\/t>/);
      let val = '';
      if (iM) {val = iM[1];}
      else if (vM) {val = (tM&&tM[1]==='s') ? (ss[parseInt(vM[1])]||'') : vM[1];}
      cells[col] = val;
      if (col > maxCol) {maxCol = col;}
    }
    const row = [];
    for (let i=0;i<=maxCol;i++) {row.push(cells[i]!==undefined?cells[i]:'');}
    rows.push(row);
  }
  return rows;
}

async function unzipXlsx(bytes) {
  const files = {};
  const view = new DataView(bytes.buffer instanceof ArrayBuffer ? bytes.buffer : bytes.buffer);
  let i = 0;
  while (i < bytes.length - 30) {
    if (view.getUint32(i, true) !== 0x04034b50) { i++; continue; }
    const method = view.getUint16(i+8, true);
    const compSize = view.getUint32(i+18, true);
    const fnLen = view.getUint16(i+26, true);
    const exLen = view.getUint16(i+28, true);
    const fname = new TextDecoder().decode(bytes.slice(i+30, i+30+fnLen));
    const dataStart = i+30+fnLen+exLen;
    const data = bytes.slice(dataStart, dataStart+compSize);
    if (fname.endsWith('.xml')||fname.endsWith('.XML')) {
      if (method===0) {
        files[fname] = new TextDecoder('utf-8',{fatal:false}).decode(data);
      } else if (method===8) {
        try {
          const ds = new DecompressionStream('deflate-raw');
          const w = ds.writable.getWriter(); w.write(data); w.close();
          const chunks = [];
          const r = ds.readable.getReader();
          let done = false;
          while (!done) { const res = await r.read(); if(res.done) {done=true;} else {chunks.push(res.value);} }
          const total = chunks.reduce((s,c)=>s+c.length,0);
          const out = new Uint8Array(total); let off=0;
          chunks.forEach(c=>{out.set(c,off);off+=c.length;});
          files[fname] = new TextDecoder('utf-8',{fatal:false}).decode(out);
        } catch(e) { console.warn('decompress failed:', fname, e); }
      }
    }
    i = dataStart + compSize;
  }
  return files;
}

function renderMappingGrid() {
  const grid = document.getElementById('si-mapping-grid');
  if (!grid) {return;}
  
  // Limit columns to first 100 to prevent UI hang with large files
  const maxColumns = 100;
  const displayHeaders = siHeaders.slice(0, maxColumns);
  const columnCount = siHeaders.length;
  
  grid.innerHTML = SI_FIELDS.map(f => {
    const opts = displayHeaders.map((h,i)=>`<option value="${i}" ${siMapping[f.key]===i?'selected':''}>${h||'(col '+(i+1)+')'}</option>`).join('');
    const detected = siMapping[f.key]!==-1 && siMapping[f.key]!==undefined && siHeaders[siMapping[f.key]];
    
    // Show warning if columns are limited
    const warningHtml = columnCount > maxColumns && f.key === 'barcode' 
      ? `<div data-style="font-size:10px;color:var(--am);margin-top:4px">⚠ Only first ${maxColumns} of ${columnCount} columns shown for performance</div>` 
      : '';
    
    return `<div data-style="background:var(--bg3);border:1px solid var(--b1);border-radius:var(--r);padding:8px 10px">
      <div data-style="font-size:11px;font-weight:600;margin-bottom:4px;color:var(--tx2)">${f.label}${f.required?' <span data-style="color:var(--rd)">*</span>':''}</div>
      <select data-style="width:100%;background:var(--bg2);border:1px solid var(--b2);border-radius:var(--r);color:var(--tx);padding:4px 6px;font-size:11px" data-onchange="siMapping['${f.key}']=this.value==='-1'?-1:parseInt(this.value)">
        <option value="-1" ${(siMapping[f.key]===-1||siMapping[f.key]===undefined)?'selected':''}>— Skip / Default —</option>
        ${opts}
      </select>
      ${warningHtml}
      <div data-style="font-size:10px;margin-top:3px;color:${detected?'var(--gn)':'var(--tx3)'}">${detected?'✓ "'+siHeaders[siMapping[f.key]]+'" detected':'Default: '+(f.default!==null?'"'+f.default+'"':'Auto')}</div>
    </div>`;
  }).join('');
}

function siNext() {
  if (!window.StoreTrackBatch2C?.previewImportRows) { toast('Preview validator unavailable; import blocked', 'er'); return; }
  const preview = window.StoreTrackBatch2C.previewImportRows(siRawRows, siMapping, M, { updateDuplicates: false });
  siMappedData = preview.records;
  const stats = preview.stats;
  document.getElementById('si-preview-count').textContent = `${stats.total} total · ${stats.valid} valid · ${stats.invalid} invalid · ${stats.added} to add · ${stats.skipped} duplicates skipped`;
  document.getElementById('si-preview-body').innerHTML = siMappedData.map(d=>`<tr data-style="${d.rowErrors.length?'background:#fff1f2':d.status==='skipped'?'opacity:.65':''}">
    <td data-style="padding:4px 8px;border:1px solid var(--b1)">${d.row}</td>
    <td data-style="padding:4px 8px;border:1px solid var(--b1);font-family:var(--mn);font-size:10px">${sanitizeHTML(d.barcode||'—')}</td>
    <td data-style="padding:4px 8px;border:1px solid var(--b1);font-weight:500">${sanitizeHTML(d.name||'—')}</td>
    <td data-style="padding:4px 8px;border:1px solid var(--b1)">${sanitizeHTML(d.category)}</td>
    <td data-style="padding:4px 8px;border:1px solid var(--b1)">${sanitizeHTML(d.unit)}</td>
    <td data-style="padding:4px 8px;border:1px solid var(--b1);font-family:var(--mn)">${sanitizeHTML(d.stock||'0')}</td>
    <td data-style="padding:4px 8px;border:1px solid var(--b1);font-family:var(--mn)">${sanitizeHTML(d.lowAlert||'10')}</td>
    <td data-style="padding:4px 8px;border:1px solid var(--b1)"><span class="bdg ${d.status==='added'?'bg':d.status==='skipped'?'ba':'br'}" data-style="font-size:9px">${d.status.toUpperCase()}${d.rowErrors.length?': '+sanitizeHTML(d.rowErrors.join('; ')):''}</span></td>
  </tr>`).join('');
  const w=document.getElementById('si-warn');
  w.style.display='block';
  w.textContent = stats.invalid ? `Import blocked until invalid rows are corrected: ${stats.invalid} rejected row(s). ${preview.errors.slice(0,3).map(e=>`Row ${e.row}: ${e.message}`).join(' | ')}` : `Preview is read-only. ${stats.added} record(s) will be added; ${stats.skipped} duplicate(s) will be skipped. No live data was changed.`;
  document.getElementById('si-step1').style.display='none';
  document.getElementById('si-step2').style.display='block';
  document.getElementById('si-next-btn').style.display='none';
  document.getElementById('si-import-btn').style.display = stats.invalid || !stats.added ? 'none' : '';
}
async function siConfirmImport() {
  if(typeof canRoleAction!=='function'||!canRoleAction('imports')){return;}
  // modules/rateLimiter.js — real usage: cap rapid repeated bulk imports (max 5/min)
  if(window.RateLimiter){
    const rl=window.RateLimiter.checkImportLimit('local-user');
    if(!rl.allowed){window.RateLimiter.showRateLimitError(rl,'import');return;}
  }
  const toImport = siMappedData.filter(d=>d.status==='added' && (!d.rowErrors || d.rowErrors.length===0));
  if (!toImport.length) { toast('No new items to import','inf'); return; }
  
  // Show loading indicator
  const loading = showLoading('Importing ' + toImport.length + ' materials...');
  
  let count=0;
  const batchSize = 50; // Process in batches to avoid blocking UI
  
  for (let i = 0; i < toImport.length; i += batchSize) {
    const batch = toImport.slice(i, i + batchSize);
    const promises = batch.map(d => 
      dPut('materials',{
        id:generateUUID(), 
        barcode:d.barcode, 
        name:d.name, 
        category:d.category, 
        unit:d.unit, 
        stock:Number(d.stock||0), 
        lowAlert:Number(d.lowAlert||0), 
        reorderQty:d.reorderQty, 
        hsn:d.hsn, 
        location:d.location, 
        photo:null, 
        active:true, 
        createdAt:new Date().toISOString(), 
        updatedAt:new Date().toISOString() 
      })
    );
    await Promise.all(promises);
    count += batch.length;
    
    // Update progress
    if (loading && loading.update) {
      loading.update(`Importing ${Math.min(i + batchSize, toImport.length)}/${toImport.length} materials...`);
    }
    
    // Allow UI to update
    await new Promise(resolve => setTimeout(resolve, 0));
  }
  
  loading.hide();
  M = await gAll('materials');
  addAudit('IMPORT',`Smart ${siFileType.toUpperCase()} import: ${count} materials added after validated preview`,'MATERIAL');
  renderMaster(); updateBadges(); closeSmartImport();
  toast('✅ '+count+' materials imported! Sequence maintained.');
}

function closeSmartImport() {
  document.getElementById('smart-import-ov').classList.remove('on');
  siRawRows = []; siHeaders = []; siMappedData = []; siMapping = {};
}


// ── IN Scan Popup ──
function openInQtyPopup(item){
  document.getElementById('iqp-name').textContent=item.name;
  document.getElementById('iqp-detail').textContent=item.barcode+' · '+item.category+' · '+item.unit;
  const s=document.getElementById('iqp-stock');
  s.textContent=item.stock+' '+item.unit;
  s.style.color=item.stock<item.lowAlert?'var(--am)':'var(--gn)';
  ['iqp-qty','iqp-po','iqp-inv','iqp-batch','iqp-rem'].forEach(id=>document.getElementById(id).value='');
  const sel=document.getElementById('iqp-supp');
  sel.innerHTML='<option value="">— Select —</option>'+SP.map(s=>`<option value="${sanitizeHTML(String(s.id))}">${sanitizeHTML(String(s.name||''))}</option>`).join('');
  document.getElementById('in-qty-ov').classList.add('on');
  setTimeout(()=>document.getElementById('iqp-qty').focus(),100);
}
function closeInQtyPopup(){
  document.getElementById('in-qty-ov').classList.remove('on');
  resetScan('in');
}
async function confirmInQtyPopup(){
  const qty=parseInt(document.getElementById('iqp-qty').value, 10);
  if(!qty||qty<=0){toast('Valid quantity enter kara!','er');document.getElementById('iqp-qty').focus();return;}
  document.getElementById('in-qty').value=qty;
  document.getElementById('in-supp').value=document.getElementById('iqp-supp').value;
  document.getElementById('in-po').value=document.getElementById('iqp-po').value;
  document.getElementById('in-inv').value=document.getElementById('iqp-inv').value;
  document.getElementById('in-batch').value=document.getElementById('iqp-batch').value;
  document.getElementById('in-rem').value=document.getElementById('iqp-rem').value;
  document.getElementById('in-qty-ov').classList.remove('on');
  await procIn();
}

// ── Batch OUT ──
let batchCart=[];
if (typeof window !== 'undefined') {
  Object.defineProperty(window, 'batchCart', { configurable: true, get: () => batchCart, set: value => { batchCart = value; } });
}
function openBatchOut(){
  batchCart=[];
  renderBatchCart();
  const sel=document.getElementById('batch-dept');
  sel.innerHTML='<option value="">— Select Dept —</option>'+DP.map(d=>`<option value="${sanitizeHTML(String(d.id))}">${sanitizeHTML(String(d.name||''))}</option>`).join('');
  ['batch-bc','batch-person','batch-job'].forEach(id=>{const el=document.getElementById(id);if(el){el.value='';}});
  document.getElementById('batch-qty-inp').value='1';
  document.getElementById('batch-out-ov').classList.add('on');
  setTimeout(()=>document.getElementById('batch-bc').focus(),100);
}
function closeBatchOut(){
  document.getElementById('batch-out-ov').classList.remove('on');
  batchCart=[];
}
function batchScan(e){
  if(e.key!=='Enter'){return;}
  const code=document.getElementById('batch-bc').value.trim();if(!code){return;}
  const item=M.find(m=>m.barcode===code&&m.active!==false);
  if(!item){toast('"'+code+'" not found!','er');document.getElementById('batch-bc').value='';return;}
  const qty=Number(document.getElementById('batch-qty-inp').value);
  const existing=batchCart.find(x=>x.itemId===item.id);
  if(existing){
    existing.qty+=qty;
    if(existing.qty>item.stock){existing.qty=item.stock;toast('Max stock: '+item.stock+' '+item.unit,'er');}
  }else{
    if(qty>item.stock){toast('Insufficient stock: '+item.stock+' '+item.unit,'er');document.getElementById('batch-bc').value='';return;}
    batchCart.push({itemId:item.id,barcode:item.barcode,name:item.name,unit:item.unit,stock:item.stock,qty});
  }
  renderBatchCart();
  document.getElementById('batch-bc').value='';
  document.getElementById('batch-qty-inp').value='1';
  toast('✓ '+item.name+' added','inf');
  document.getElementById('batch-bc').focus();
}
function removeBatchItem(idx){batchCart.splice(idx,1);renderBatchCart();}
function renderBatchCart(){
  const tb=document.getElementById('batch-cart-body');
  if(!batchCart.length){tb.innerHTML='<tr><td colspan="5" data-style="text-align:center;padding:20px;color:var(--tx3)">Scan items to add to cart</td></tr>';document.getElementById('batch-item-count').textContent='0';document.getElementById('batch-total-qty').textContent='0';return;}
  tb.innerHTML=batchCart.map((x,i)=>`<tr>
    <td data-style="padding:5px 8px;font-weight:500">${x.name}</td>
    <td data-style="padding:5px 8px;text-align:center;font-family:var(--mn)">${x.barcode}</td>
    <td data-style="padding:5px 8px;text-align:center;color:var(--tx3)">${x.stock} ${x.unit}</td>
    <td data-style="padding:5px 8px;text-align:center"><input type="number" min="1" max="${x.stock}" value="${x.qty}" data-onchange="batchCart[${i}].qty=Math.min(parseInt(this.value)||1,${x.stock});renderBatchCart()" data-style="width:60px;padding:2px 5px;background:var(--bg3);border:1px solid var(--b1);border-radius:3px;color:var(--tx);text-align:center"></td>
    <td data-style="padding:5px 8px;text-align:center"><button data-onclick="removeBatchItem(${i})" data-style="background:none;border:none;color:var(--rd);cursor:pointer;font-size:14px">🗑</button></td>
  </tr>`).join('');
  document.getElementById('batch-item-count').textContent=batchCart.length;
  document.getElementById('batch-total-qty').textContent=batchCart.reduce((s,x)=>s+x.qty,0);
}
async function confirmBatchOut(){
  if(typeof canRoleAction!=='function'){toast('Authorization checks are unavailable','er');return;}
  if(!canRoleAction('procOut')){return;}
  if(!batchCart.length){toast('Cart is empty!','er');return;}
  lastTx=null;
  const dId=document.getElementById('batch-dept').value;
  const dObj=DP.find(d=>d.id==dId);
  const person=document.getElementById('batch-person').value;
  const job=document.getElementById('batch-job').value;
  let done=0,failed=0;
  for(const x of batchCart){
    const item=M.find(m=>m.id===x.itemId);
    if(!item||x.qty>item.stock){toast('⚠ '+x.name+' — insufficient stock, skipped','er');failed++;continue;}
    const tx={id:generateUUID(),time:new Date().toISOString(),barcode:x.barcode,itemId:item.id,itemName:item.name,unit:x.unit,type:'OUT',qty:x.qty,deptId:dId,deptName:dObj?dObj.name:'',person:sanitizeText(person),job:sanitizeText(job),user:cu.username,userName:cu.name,status:cu.role==='store'?'pending':'confirmed',batchOut:true};
    try{
      if(typeof window.dPutMany!=='function'){throw new Error('Atomic batch writes are unavailable');}
      if(cu.role==='store'){
        const ap={id:generateUUID(),txId:tx.id,time:tx.time,itemName:item.name,barcode:item.barcode,qty:x.qty,unit:item.unit,deptName:tx.deptName,person:tx.person,job:tx.job,reqBy:cu.username,reqByName:cu.name,status:'pending',batchOut:true};
        await window.dPutMany([{store:'transactions',obj:tx},{store:'approvals',obj:ap}]);
        AP.push(ap);T.push(tx);
      }else{
        
        if(window.centralSync?.submit){try{const r=await window.centralSync.submit(tx);if(r?.transaction)tx.status=r.transaction.status||tx.status;}catch(error){tx.status='pending-central';tx.centralSyncError=error.message||'Central sync failed';}}
        if(typeof window.atomicReadModifyWrite!=='function')throw new Error('Atomic stock persistence is unavailable');
        await window.atomicReadModifyWrite('materials',item.id,current=>{
          if(!current||Number(current.stock)<x.qty)throw new Error('Insufficient stock at commit time');
          const updated={...current,stock:Number(current.stock)-x.qty,updatedAt:new Date().toISOString()};
          return {record:updated,writes:[{store:'transactions',obj:tx}]};
        });
        T.push(tx);
      }
    }catch(err){failed++;continue;}
    addAudit('OUT',`BATCH OUT: ${item.name} | Qty: ${x.qty}`,'OUT');
    done++;
  }
  M=await gAll('materials');
  updateBadges();renderLiveFeed();
  toast(`✓ Batch OUT done! ${done} items issued${failed?' | '+failed+' skipped':''}`,failed?'er':'ok');
  closeBatchOut();
}

// ── PIN Lock ──
let pinBuffer='';
let pinLockTimer=null;
const PIN_TIMEOUT=10*60*1000; // 10 minutes auto-lock
function lockScreen(){
  const pin=cu&&CFG&&CFG.pin;
  if(!pin){toast('PIN not set — go to Settings to set PIN','er');return;}
  document.getElementById('pin-lock-user').textContent='Logged in as: '+cu.name;
  document.getElementById('pin-display').textContent='——';
  document.getElementById('pin-error').style.display='none';
  pinBuffer='';
  document.getElementById('pin-lock-ov').classList.add('on');
}
function pinKey(n){
  if(pinBuffer.length>=6){return;}
  pinBuffer+=String(n);
  document.getElementById('pin-display').textContent='●'.repeat(pinBuffer.length).padEnd(Math.max(pinBuffer.length,4),'—').slice(0,6);
  if(pinBuffer.length===4||pinBuffer.length===6){setTimeout(pinSubmit,200);}
}
function pinClear(){pinBuffer='';document.getElementById('pin-display').textContent='——';document.getElementById('pin-error').style.display='none';}
function pinSubmit(){
  const pin=CFG&&CFG.pin;
  if(pinBuffer===String(pin)){
    document.getElementById('pin-lock-ov').classList.remove('on');
    pinBuffer='';
    resetPinTimer();
    toast('✓ Unlocked');
  }else{
    document.getElementById('pin-error').style.display='';
    pinBuffer='';
    document.getElementById('pin-display').textContent='——';
  }
}
function resetPinTimer(){
  clearTimeout(pinLockTimer);
  if(CFG&&CFG.pin){pinLockTimer=setTimeout(lockScreen,PIN_TIMEOUT);}
}
// Reset timer on any activity
_addEventListener(document, 'click', resetPinTimer);
_addEventListener(document, 'keydown', resetPinTimer);

// ── Live Feed ──
function renderLiveFeed(){
  const feed=document.getElementById('live-feed');if(!feed){return;}
  const recent=T.slice().sort((a,b)=>new Date(b.time)-new Date(a.time)).slice(0,20);
  if(!recent.length){feed.innerHTML='<div data-style="text-align:center;padding:16px;color:var(--tx3)">No transactions yet</div>';return;}
  feed.innerHTML=recent.map(t=>{
    const isIn=t.type==='IN';
    const time=new Date(t.time).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
    const date=new Date(t.time).toLocaleDateString([],{day:'2-digit',month:'short'});
    return `<div data-style="display:flex;align-items:center;gap:8px;padding:6px 10px;border-bottom:1px solid var(--b1)">
      <span data-style="font-size:14px">${isIn?'📥':'📤'}</span>
      <div data-style="flex:1;min-width:0">
        <div data-style="font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${sanitizeHTML(String(t.itemName||''))}</div>
        <div data-style="color:var(--tx3);font-size:9px">${date} ${time} · ${sanitizeHTML(String(t.user||''))}</div>
      </div>
      <span data-style="font-weight:700;font-family:var(--mn);color:${isIn?'var(--gn)':'var(--rd)'};white-space:nowrap">${isIn?'+':'-'}${t.qty} ${t.unit}</span>
    </div>`;
  }).join('');
}

// ── Consumption Chart ──
let chartInstance=null;
function renderConsumptionChart(){
  const canvas=document.getElementById('consumption-chart');if(!canvas){return;}
  const days=parseInt(document.getElementById('chart-period')?.value||30);
  const since=new Date(Date.now()-days*86400000);
  const outTxns=T.filter(t=>t.type==='OUT'&&t.status==='confirmed'&&new Date(t.time)>=since);
  const itemTotals={};
  outTxns.forEach(t=>{itemTotals[t.itemName]=(itemTotals[t.itemName]||0)+t.qty;});
  const sorted=Object.entries(itemTotals).sort((a,b)=>b[1]-a[1]).slice(0,10);
  const labels=sorted.map(x=>x[0].length>14?x[0].slice(0,14)+'…':x[0]);
  const data=sorted.map(x=>x[1]);
  const colors=['#3b82f6','#ef4444','#10b981','#f59e0b','#8b5cf6','#06b6d4','#ec4899','#84cc16','#f97316','#6366f1'];
  if(chartInstance){chartInstance.destroy();chartInstance=null;}
  if(!data.length){
    const ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle='#6b7280';ctx.font='13px sans-serif';ctx.textAlign='center';
    ctx.fillText('No OUT transactions in this period',canvas.width/2,90);return;
  }
  // Draw simple bar chart without external lib
  const ctx=canvas.getContext('2d');
  canvas.width=canvas.offsetWidth||600;canvas.height=180;
  ctx.clearRect(0,0,canvas.width,canvas.height);
  const pad={l:40,r:10,t:10,b:50};
  const chartW=canvas.width-pad.l-pad.r;
  const chartH=canvas.height-pad.t-pad.b;
  const maxVal=Math.max(...data);
  const barW=Math.floor(chartW/data.length)-6;
  // Grid lines
  ctx.strokeStyle='#374151';ctx.lineWidth=0.5;
  for(let i=0;i<=4;i++){
    const y=pad.t+chartH-(i/4)*chartH;
    ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(pad.l+chartW,y);ctx.stroke();
    ctx.fillStyle='#9ca3af';ctx.font='9px sans-serif';ctx.textAlign='right';
    ctx.fillText(Math.round(maxVal*i/4),pad.l-4,y+3);
  }
  // Bars
  data.forEach((val,i)=>{
    const x=pad.l+i*(chartW/data.length)+3;
    const h=(val/maxVal)*chartH;
    const y=pad.t+chartH-h;
    ctx.fillStyle=colors[i%colors.length];
    ctx.beginPath();
    ctx.roundRect?ctx.roundRect(x,y,barW,h,3):ctx.rect(x,y,barW,h);
    ctx.fill();
    // Value label
    ctx.fillStyle='#f9fafb';ctx.font='bold 10px sans-serif';ctx.textAlign='center';
    if(h>16){ctx.fillText(val,x+barW/2,y+14);}
    // Item label
    ctx.fillStyle='#9ca3af';ctx.font='9px sans-serif';
    ctx.save();ctx.translate(x+barW/2,pad.t+chartH+6);ctx.rotate(-0.5);
    ctx.fillText(labels[i],0,0);ctx.restore();
  });
}

// ── Dashboard Summary ──
let summaryPeriod='week';
function switchSummary(period){
  summaryPeriod=period;
  ['day','week','month'].forEach(p=>{
    const btn=document.getElementById('sum-'+p+'-btn');
    if(btn){btn.className='btn'+(p===period?' btn-p':'');}
  });
  renderSummary();
}
function renderSummary(){
  const now=new Date();
  let since;
  if(summaryPeriod==='day'){since=new Date(now.getFullYear(),now.getMonth(),now.getDate());}
  else if(summaryPeriod==='week'){since=new Date(Date.now()-7*86400000);}
  else{since=new Date(now.getFullYear(),now.getMonth(),1);}
  const txns=T.filter(t=>t.status==='confirmed'&&new Date(t.time)>=since);
  const inTxns=txns.filter(t=>t.type==='IN');
  const outTxns=txns.filter(t=>t.type==='OUT');
  document.getElementById('sum-in').textContent=inTxns.reduce((s,t)=>s+Number(t.qty||0),0);
  document.getElementById('sum-out').textContent=outTxns.reduce((s,t)=>s+Number(t.qty||0),0);
  document.getElementById('sum-txns').textContent=txns.length;
  document.getElementById('sum-items').textContent=new Set(txns.map(t=>t.itemId)).size;
}

// ── PDF Report Export ──
function exportPDFReport(){
  const days=parseInt(document.getElementById('chart-period')?.value||30);
  const since=new Date(Date.now()-days*86400000);
  const outTxns=T.filter(t=>t.type==='OUT'&&t.status==='confirmed'&&new Date(t.time)>=since).sort((a,b)=>new Date(b.time)-new Date(a.time));
  const inTxns=T.filter(t=>t.type==='IN'&&new Date(t.time)>=since).sort((a,b)=>new Date(b.time)-new Date(a.time));
  const itemTotals={};
  outTxns.forEach(t=>{
    if(!itemTotals[t.itemName]){itemTotals[t.itemName]={name:t.itemName,unit:t.unit,outQty:0,inQty:0,txns:0};}
    itemTotals[t.itemName].outQty+=t.qty;itemTotals[t.itemName].txns++;
  });
  inTxns.forEach(t=>{
    if(!itemTotals[t.itemName]){itemTotals[t.itemName]={name:t.itemName,unit:t.unit,outQty:0,inQty:0,txns:0};}
    itemTotals[t.itemName].inQty+=t.qty;
  });
  const co=CFG.company||'Your Company';
  const rows=Object.values(itemTotals).sort((a,b)=>b.outQty-a.outQty);
  const rowsHtml=rows.map((r,i)=>`<tr data-style="background:${i%2?'#f9fafb':'#fff'}"><td data-style="border:1px solid #ddd;padding:5px 8px">${sanitizeHTML(String(r.name||''))}</td><td data-style="border:1px solid #ddd;padding:5px 8px;text-align:center">${sanitizeHTML(String(r.unit||""))}</td><td data-style="border:1px solid #ddd;padding:5px 8px;text-align:center;color:#16a34a;font-weight:600">${r.inQty||0}</td><td data-style="border:1px solid #ddd;padding:5px 8px;text-align:center;color:#dc2626;font-weight:600">${r.outQty||0}</td><td data-style="border:1px solid #ddd;padding:5px 8px;text-align:center">${r.txns}</td></tr>`).join('');
  const recentHtml=outTxns.slice(0,30).map(t=>`<tr><td data-style="border:1px solid #ddd;padding:4px 7px;font-size:9pt">${new Date(t.time).toLocaleString()}</td><td data-style="border:1px solid #ddd;padding:4px 7px">${sanitizeHTML(String(t.itemName||''))}</td><td data-style="border:1px solid #ddd;padding:4px 7px;text-align:center;color:#dc2626;font-weight:600">${t.qty} ${t.unit}</td><td data-style="border:1px solid #ddd;padding:4px 7px">${sanitizeHTML(String(t.deptName||'—'))}</td><td data-style="border:1px solid #ddd;padding:4px 7px">${sanitizeHTML(String(t.person||'—'))}</td></tr>`).join('');
  window.printPopupHtml(`<!DOCTYPE html><html><head><title>${co} — Inventory Report</title><style>body{font-family:Arial,sans-serif;font-size:10pt;margin:10mm 12mm;color:#111}h1{font-size:16pt;margin:0}h2{font-size:12pt;margin:16px 0 8px;color:#1e40af}table{width:100%;border-collapse:collapse;margin-bottom:16px}th{background:#1e40af;color:#fff;padding:6px 8px;text-align:left}@media print{.no-print{display:none}}</style></head><body>
  <div style="display:flex;justify-content:space-between;border-bottom:2px solid #1e40af;padding-bottom:8px;margin-bottom:16px">
    <div><h1>${co}</h1><p style="margin:3px 0;color:#555">Inventory Report · Last ${days} Days · Generated: ${new Date().toLocaleString()}</p></div>
  </div>
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px">
    <div style="border:1px solid #ddd;border-radius:6px;padding:10px;text-align:center"><div style="font-size:22pt;font-weight:700;color:#16a34a">${inTxns.reduce((s,t)=>s+Number(t.qty||0),0)}</div><div style="font-size:9pt;color:#555">Total IN Qty</div></div>
    <div style="border:1px solid #ddd;border-radius:6px;padding:10px;text-align:center"><div style="font-size:22pt;font-weight:700;color:#dc2626">${outTxns.reduce((s,t)=>s+Number(t.qty||0),0)}</div><div style="font-size:9pt;color:#555">Total OUT Qty</div></div>
    <div style="border:1px solid #ddd;border-radius:6px;padding:10px;text-align:center"><div style="font-size:22pt;font-weight:700;color:#1e40af">${outTxns.length+inTxns.length}</div><div style="font-size:9pt;color:#555">Transactions</div></div>
    <div style="border:1px solid #ddd;border-radius:6px;padding:10px;text-align:center"><div style="font-size:22pt;font-weight:700;color:#d97706">${M.filter(isLowStockMaterial).length}</div><div style="font-size:9pt;color:#555">Low Stock Items</div></div>
  </div>
  <h2>Item-wise Summary</h2>
  <table><thead><tr><th>Item Name</th><th style="text-align:center">Unit</th><th style="text-align:center">IN Qty</th><th style="text-align:center">OUT Qty</th><th style="text-align:center">Transactions</th></tr></thead><tbody>${rowsHtml||'<tr><td colspan="5" style="text-align:center;padding:12px;color:#999">No data</td></tr>'}</tbody></table>
  <h2>Recent OUT Transactions (last 30)</h2>
  <table><thead><tr><th>Date/Time</th><th>Item</th><th style="text-align:center">Qty</th><th>Department</th><th>Issued To</th></tr></thead><tbody>${recentHtml||'<tr><td colspan="5" style="text-align:center;padding:12px;color:#999">No data</td></tr>'}</tbody></table>
  </body></html>`);
}


// ── Barcode Print Preview — Full-screen dark UI ──────────────────────────────
let _lblZoom = 100;
let _lblDest = 'print';      // 'print' | 'pdf'
let _lblOrient = 'portrait'; // 'portrait' | 'landscape'
let _lblColorMode = 'color'; // 'color' | 'bw'
let _lblCopiesPv = 1;
let _lblCutLines = true;
let _lblGridOn = false;
let _lblRulerOn = false;

async function openLblPreview() {
  if (!lblSel.length) { toast('Select items first', 'er'); return; }
  const ov = document.getElementById('lbl-preview-ov');
  ov.style.display = 'flex';
  // Sync settings from main label panel
  const s = getLblSettings();
  const wEl = document.getElementById('lbl-w-pv');   if (wEl)  {wEl.value  = s.w;}
  const hEl = document.getElementById('lbl-h-pv');   if (hEl)  {hEl.value  = s.h;}
  const fsEl= document.getElementById('lbl-fs-pv');  if (fsEl) {fsEl.value = s.fs;}
  const perR= document.getElementById('lbl-per-range'); if(perR){perR.value=s.per;document.getElementById('lbl-per-disp').textContent=s.per;}
  _lblCopiesPv = s.copies;
  const copEl = document.getElementById('lbl-copies-val'); if(copEl) {copEl.textContent = _lblCopiesPv;}
  // Reset state
  _lblZoom = 100; _lblDest = 'print'; _lblOrient = 'portrait'; _lblColorMode = 'color';
  _lblCutLines = true; _lblGridOn = false; _lblRulerOn = false;
  _lblUpdateZoomLabel();
  _lblSyncDestUI();
  await _lblRebuildGrid();
}

async function _lblRebuildGrid() {
  const grid=document.getElementById('lbl-preview-grid');if(!grid)return;
  grid.innerHTML='<div data-style="color:#888;padding:28px;font-size:13px">⏳ Generating labels…</div>';
  const s=_lblGetPvSettings(),container=document.createDocumentFragment();
  for(const m of lblSel)for(let i=0;i<s.copies;i++){const el=await createLabelElement(m,s);if(_lblColorMode==='bw')el.style.filter='grayscale(1)';container.appendChild(el);}
  const totalLabels=lblSel.length*s.copies,prevCount=document.getElementById('lbl-prev-count');
  if(prevCount)prevCount.textContent=`${totalLabels} label${totalLabels!==1?'s':''} · ${s.w}×${s.h} mm`;
  const per=clampFiniteInt(document.getElementById('lbl-per-range')?.value,3,1,6);
  const hgap=clampFiniteInt(document.getElementById('lbl-hgap-range')?.value,15,0,30);
  const vgap=clampFiniteInt(document.getElementById('lbl-vgap-range')?.value,15,0,30);
  const mgn=clampFiniteInt(document.getElementById('lbl-margin-sel')?.value,10,0,20);
  applyCssText(grid,`background:#fff;border-radius:4px;box-shadow:0 4px 32px #0008;${lblPreviewLayoutCss(per,hgap,vgap,mgn)}`);
  grid.style.outline=_lblCutLines?'2px dashed #ccc':'none';
  grid.innerHTML='';grid.appendChild(container);_lblApplyZoom();
}

function _lblGetPvSettings() {
  const s=getLblSettings();
  const w=clampFiniteInt(document.getElementById('lbl-w-pv')?.value,s.w,20,200);
  const h=clampFiniteInt(document.getElementById('lbl-h-pv')?.value,s.h,10,200);
  const fs=clampFiniteInt(document.getElementById('lbl-fs-pv')?.value,s.fs,5,20);
  const showCat=document.getElementById('lbl-show-cat-pv')?.checked??s.showCat;
  const showUnit=document.getElementById('lbl-show-unit-pv')?.checked??s.showUnit;
  return {...s,w,h,fs,copies:clampFiniteInt(_lblCopiesPv,s.copies,1,100),showCat,showUnit};
}

function lblUpdatePreview() { _lblRebuildGrid(); }

function _lblUpdateZoomLabel() {
  const el = document.getElementById('lbl-zoom-label');
  if (el) {el.textContent = _lblZoom + '%';}
}
function _lblApplyZoom() {
  const sc = document.getElementById('lbl-canvas-scale');
  if (sc) {sc.style.transform = `scale(${_lblZoom/100})`;}
}
function lblZoomChange(delta) {
  _lblZoom = Math.max(20, Math.min(200, _lblZoom + delta));
  _lblUpdateZoomLabel(); _lblApplyZoom();
}
function lblZoomFit() {
  const wrap = document.getElementById('lbl-canvas-wrap');
  const grid = document.getElementById('lbl-preview-grid');
  if (!wrap || !grid) {return;}
  const ratio = (wrap.clientWidth - 56) / (grid.offsetWidth || 600);
  _lblZoom = Math.round(Math.min(100, ratio * 100));
  _lblUpdateZoomLabel(); _lblApplyZoom();
}
function lblZoomActual() { _lblZoom = 100; _lblUpdateZoomLabel(); _lblApplyZoom(); }

function lblSetDest(d) {
  _lblDest = d;
  _lblSyncDestUI();
}
function _lblSyncDestUI() {
  const pBtn = document.getElementById('lbl-dest-print');
  const dBtn = document.getElementById('lbl-dest-pdf');
  const lbl  = document.getElementById('lbl-print-btn-label');
  if (pBtn) {
    const on = _lblDest === 'print';
    pBtn.style.background = on ? '#6c5ce7' : '#1e1f3a';
    pBtn.style.border     = on ? '2px solid #6c5ce7' : '2px solid #2d2f50';
    pBtn.style.color      = on ? '#fff' : '#aaa';
  }
  if (dBtn) {
    const on = _lblDest === 'pdf';
    dBtn.style.background = on ? '#6c5ce7' : '#1e1f3a';
    dBtn.style.border     = on ? '2px solid #6c5ce7' : '2px solid #2d2f50';
    dBtn.style.color      = on ? '#fff' : '#aaa';
  }
  if (lbl) {lbl.textContent = _lblDest === 'pdf' ? 'Save as PDF' : 'Print / Save';}
}

function lblSetOrient(o) {
  _lblOrient = o;
  const pBtn = document.getElementById('lbl-orient-p');
  const lBtn = document.getElementById('lbl-orient-l');
  const act  = 'background:#6c5ce7;border:2px solid #6c5ce7;color:#fff';
  const inact= 'background:#1e1f3a;border:2px solid #2d2f50;color:#aaa';
  if(pBtn){pBtn.style.background=o==='portrait'?'#6c5ce7':'#1e1f3a';pBtn.style.borderColor=o==='portrait'?'#6c5ce7':'#2d2f50';pBtn.style.color=o==='portrait'?'#fff':'#aaa';}
  if(lBtn){lBtn.style.background=o==='landscape'?'#6c5ce7':'#1e1f3a';lBtn.style.borderColor=o==='landscape'?'#6c5ce7':'#2d2f50';lBtn.style.color=o==='landscape'?'#fff':'#aaa';}
}

function lblSetColor(c) {
  _lblColorMode = c;
  const cBtn = document.getElementById('lbl-color-color');
  const bBtn = document.getElementById('lbl-color-bw');
  if(cBtn){cBtn.style.background=c==='color'?'#6c5ce7':'#1e1f3a';cBtn.style.borderColor=c==='color'?'#6c5ce7':'#2d2f50';cBtn.style.color=c==='color'?'#fff':'#aaa';}
  if(bBtn){bBtn.style.background=c==='bw'?'#6c5ce7':'#1e1f3a';bBtn.style.borderColor=c==='bw'?'#6c5ce7':'#2d2f50';bBtn.style.color=c==='bw'?'#fff':'#aaa';}
  _lblRebuildGrid();
}

function lblCopiesChange(d) {
  _lblCopiesPv = Math.max(1, Math.min(20, _lblCopiesPv + d));
  const el = document.getElementById('lbl-copies-val');
  if (el) {el.textContent = _lblCopiesPv;}
  _lblRebuildGrid();
}

function lblRangeSync(type, val) {
  if (type==='per') { document.getElementById('lbl-per-disp').textContent = val; }
  if (type==='hgap') { document.getElementById('lbl-hgap-disp').textContent = val+' mm'; }
  if (type==='vgap') { document.getElementById('lbl-vgap-disp').textContent = val+' mm'; }
  _lblRebuildGrid();
}

function lblToggleSection(id) {
  const sec = document.getElementById(id);
  if (!sec) {return;}
  const open = sec.style.display !== 'none';
  sec.style.display = open ? 'none' : 'flex';
  const arrows = {'layout-sec':'lbl-layout-arrow','lbl-label-sec':'lbl-label-arrow','lbl-prev-opts':'lbl-prev-arrow'};
  const arrEl = document.getElementById(arrows[id]);
  if (arrEl) {arrEl.textContent = open ? '▼' : '▲';}
}

function lblSideNav(btn, tab) {
  document.querySelectorAll('.lbl-sidenav-btn').forEach(b => {
    b.style.background = 'transparent'; b.style.color = '#8b8fa8';
  });
  btn.style.background = '#6c5ce7'; btn.style.color = '#fff';
  const destinations = { preview: 'lbl-preview-grid', settings: 'lbl-paper-size', layout: 'layout-sec', templates: 'lbl-label-sec', history: 'lbl-preview-history', help: 'lbl-preview-help', about: 'lbl-preview-about' };
  if(tab==='templates'){const panel=document.getElementById('lbl-label-sec');if(panel&&panel.style.display==='none'){panel.style.display='flex';const arrow=document.getElementById('lbl-label-arrow');if(arrow)arrow.textContent='▲';}}
  const target = document.getElementById(destinations[tab]);
  if (target) { target.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); target.focus?.({ preventScroll: true }); }
  else if (tab !== 'preview' && tab !== 'settings' && typeof toast === 'function') { toast(`${tab[0].toUpperCase()}${tab.slice(1)} panel is not available in this build.`, 'inf'); }
}

function lblToggleGrid() {
  _lblGridOn = !_lblGridOn;
  const btn = document.getElementById('lbl-grid-btn');
  if (btn) {btn.style.color = _lblGridOn ? '#6c5ce7' : '#8b8fa8';}
  const grid = document.getElementById('lbl-preview-grid');
  if (grid) {grid.style.backgroundImage = _lblGridOn
    ? 'repeating-linear-gradient(0deg,#f0f0f0 0,#f0f0f0 1px,transparent 1px,transparent 10px),repeating-linear-gradient(90deg,#f0f0f0 0,#f0f0f0 1px,transparent 1px,transparent 10px)'
    : 'none';}
}

function lblToggleRuler() {
  _lblRulerOn = !_lblRulerOn;
  const btn = document.getElementById('lbl-ruler-btn');
  if (btn) {btn.style.color = _lblRulerOn ? '#6c5ce7' : '#8b8fa8';}
}

function lblToggleCutLines() {
  _lblCutLines = !_lblCutLines;
  const knob = document.getElementById('lbl-cutline-knob');
  const tog  = document.getElementById('lbl-cutline-toggle');
  if (knob) {knob.style.right = _lblCutLines ? '2px' : 'calc(100% - 16px)';}
  if (tog)  {tog.style.background = _lblCutLines ? '#6c5ce7' : '#444';}
  const grid = document.getElementById('lbl-preview-grid');
  if (grid) {grid.style.outline = _lblCutLines ? '2px dashed #ccc' : 'none';}
}

async function lblDoPrint() {
  if (_lblDest === 'pdf') {
    await doPrintLabels('pdf');
  } else {
    await doPrintLabels('browser');
  }
}

function closeLblPreview() {
  const ov = document.getElementById('lbl-preview-ov');
  if (ov) {ov.style.display = 'none';}
  const thermalOut = document.getElementById('lbl-thermal-out');
  if (thermalOut) {thermalOut.style.display = 'none';}
}
async function doPrintLabels(mode) {
  if (!lblSel.length) { toast('Select items first', 'er'); return; }

  // Use preview panel settings if preview is open, else fall back to main panel
  const pvOpen = document.getElementById('lbl-preview-ov')?.style.display === 'flex';
  const s = pvOpen ? _lblGetPvSettings() : getLblSettings();
  const { w, h, fs, per, showCat, showUnit } = s;
  const copies = pvOpen ? _lblCopiesPv : s.copies;

  if (mode === 'thermal') {
    const _thermalOv = document.getElementById('lbl-preview-ov');
    if (_thermalOv) {_thermalOv.style.display = 'flex';}
    let zpl = '';
    lblSel.forEach(m => {
      for (let i = 0; i < copies; i++) {zpl += buildLabelZpl(m, s);}
    });
    const zplText = document.getElementById('lbl-zpl-text');
    const thermalOut = document.getElementById('lbl-thermal-out');
    if (zplText) {zplText.value = zpl;}
    if (thermalOut) {
      thermalOut.style.display = 'block';
      thermalOut.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    toast('ZPL generated — copy to your thermal printer software', 'inf');
    return;
  }

  // Build labels HTML using correct copies count
  let labelsHtml = '';
  for (const m of lblSel) {
    for (let i = 0; i < copies; i++) {
      labelsHtml += await buildLabelPrintHtml(m, s);
    }
  }

  const hgap=pvOpen?clampFiniteInt(document.getElementById('lbl-hgap-range')?.value,2,0,30):2;
  const vgap=pvOpen?clampFiniteInt(document.getElementById('lbl-vgap-range')?.value,2,0,30):2;
  const mgn=pvOpen?clampFiniteInt(document.getElementById('lbl-margin-sel')?.value,4,0,20):4;
  const bwFilter = (pvOpen && _lblColorMode === 'bw') ? 'filter:grayscale(1);' : '';
  const orient = pvOpen ? _lblOrient : 'portrait';
  const paperChoice = pvOpen ? (document.getElementById('lbl-paper-size')?.value || 'a4') : 'a4';
  const paper = ({a4:'A4', a3:'A3', letter:'Letter'})[paperChoice] || 'A4';
  const sheetW=per*w+(per-1)*hgap+mgn*2;

  const _printTitle = mode === 'pdf'
    ? 'Barcode_Labels_' + new Date().toISOString().slice(0, 10) + '.pdf'
    : 'Print Labels';

  const _printDoc = `<!DOCTYPE html><html><head><title>${_printTitle}</title>
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      html,body{background:#fff;font-family:Arial,sans-serif;${bwFilter}}
      .grid{display:grid;grid-template-columns:repeat(${per},${w}mm);column-gap:${hgap}mm;row-gap:${vgap}mm;padding:${mgn}mm;background:#fff;justify-content:start}
      .lbl{width:${w}mm;height:${h}mm;border:1px solid #000;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden;padding:1mm;page-break-inside:avoid;background:#fff}
      .lbl-name,.lbl-sub,.lbl-bc{text-align:center;white-space:nowrap;width:92%;overflow:hidden;text-overflow:ellipsis;line-height:1.1}
      .lbl-name{font-weight:bold}
      .lbl-codes{display:flex;align-items:center;justify-content:center;gap:1mm;margin:0.5mm 0;flex:1;min-height:0;width:100%}
      .lbl-codes img{object-fit:contain}
      @media print{
        @page{size:${paper} ${orient};margin:0}
        body{margin:0}
        .no-print{display:none!important}
        .grid{padding:0;gap:0}
        .lbl{border:1px solid #000 !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
      }
    </style></head>
    <body>
      <div class="grid">${labelsHtml}</div>
    </body></html>`;

  // ── PDF mode: use printBridge.savePDF ──
  if (mode === 'pdf') {
    try {
      if (window.printBridge) {
        const result = await window.printBridge.savePDF(_printDoc, _printTitle);
        if (result && result.ok) {
          toast('✅ PDF saved: ' + (result.path || _printTitle), 'ok');
          addAudit('PRINT', 'Saved PDF: ' + lblSel.length + ' label types', 'SYSTEM');
        } else {
          toast('PDF save failed: ' + (result?.error || 'unknown'), 'er');
        }
      } else {
        // Fallback: open in new window and let browser save as PDF
        const pw = window.open('', '_blank', 'width=900,height=700');
        if (pw) {
          pw.document.write(_printDoc + '<script>window.onload=()=>window.print();<\/script>');
          pw.document.close();
          toast('Print dialog opened — choose "Save as PDF"', 'inf');
        } else {
          toast('Popup blocked. Allow popups and try again.', 'er');
        }
      }
    } catch (err) {
      console.error('[PDF Save Error]', err);
      toast('PDF save failed: ' + err.message, 'er');
    }
    if (typeof addAudit === 'function') {addAudit('PRINT', 'PDF: ' + lblSel.length + ' label types', 'SYSTEM');}
    return;
  }

  // ── Print mode: use printBridge.printContent if available ──
  if (window.printBridge) {
    try {
      const result = await window.printBridge.printContent(_printDoc);
      if (result && result.ok) {
        toast('🖨 Sent to printer', 'ok');
        addAudit('PRINT', 'Printed ' + lblSel.length + ' label types (IPC)', 'SYSTEM');
      } else {
        toast('Print failed: ' + (result?.error || 'unknown'), 'er');
      }
    } catch (err) {
      console.error('[Print IPC Error]', err);
      toast('Print failed: ' + err.message, 'er');
    }
    return;
  }
  
  if (typeof addAudit === 'function') {addAudit('PRINT', 'Printed ' + lblSel.length + ' label types (IPC)', 'SYSTEM');}
}
// ── Month-End Closing Stock ──
function populateClosingMonths(){
  const sel=document.getElementById('cls-month');if(!sel){return;}
  const monthKeys=new Set([new Date().toISOString().slice(0,7)]);
  T.concat(ADJ).forEach(row => { const raw=row.time || row.date || row.createdAt; if(raw){ const key=String(raw).slice(0,7); if(/^\d{4}-\d{2}$/.test(key)) monthKeys.add(key); } });
  const months=[...monthKeys].sort().reverse().map(val=>{const [y,m]=val.split('-').map(Number);return {val,lbl:new Date(y,m-1,1).toLocaleString('default',{month:'long',year:'numeric'})};});
  sel.innerHTML=months.map(m=>`<option value="${m.val}">${m.lbl}</option>`).join('');
  renderClosingStock();
}
function renderClosingStock(){
  const sel=document.getElementById('cls-month');if(!sel){return;}
  const [yr,mo]=sel.value.split('-').map(Number);
  const start=new Date(yr,mo-1,1);
  const end=new Date(yr,mo,1);
  // Closing stock = current stock - IN after end + OUT after end + ADJ after end
  // Opening = closing of prev month = current - all txns in month
  const candidates=M.filter(m=>m.active!==false||T.some(t=>t.itemId===m.id&&new Date(t.time)<end)||ADJ.some(a=>a.itemId===m.id&&new Date(a.time)<end));
  const rows=candidates.map(m=>{
    const txInMonth=T.filter(t=>t.itemId===m.id&&new Date(t.time)>=start&&new Date(t.time)<end);
    const inQty=txInMonth.filter(t=>t.type==='IN'&&(t.status==='confirmed'||t.status==='pending-central')).reduce((s,t)=>s+(Number(t.qty)||0),0);
    const outQty=txInMonth.filter(t=>t.type==='OUT'&&(t.status==='confirmed'||t.status==='pending-central')).reduce((s,t)=>s+(Number(t.qty)||0),0);
    const adjInMonth=ADJ.filter(a=>a.itemId===m.id&&new Date(a.time)>=start&&new Date(a.time)<end);
    const adjQty=adjInMonth.reduce((s,a)=>s+(a.newStock-a.oldStock),0);
    // Txns after end of month to calculate backwards
    const txAfter=T.filter(t=>t.itemId===m.id&&new Date(t.time)>=end);
    const inAfter=txAfter.filter(t=>t.type==='IN'&&(t.status==='confirmed'||t.status==='pending-central')).reduce((s,t)=>s+(Number(t.qty)||0),0);
    const outAfter=txAfter.filter(t=>t.type==='OUT'&&(t.status==='confirmed'||t.status==='pending-central')).reduce((s,t)=>s+(Number(t.qty)||0),0);
    const adjAfter=ADJ.filter(a=>a.itemId===m.id&&new Date(a.time)>=end).reduce((s,a)=>s+(a.newStock-a.oldStock),0);
    const closingStock=m.stock-inAfter+outAfter-adjAfter;
    const openingStock=closingStock-inQty+outQty-adjQty;
    return {m,openingStock,inQty,outQty,adjQty,closingStock};
  });
  // Summary
  const totIn=rows.reduce((s,r)=>s+r.inQty,0);
  const totOut=rows.reduce((s,r)=>s+r.outQty,0);
  const belowAlert=rows.filter(r=>r.closingStock<r.m.lowAlert).length;
  const zeroStock=rows.filter(r=>r.closingStock===0).length;
  document.getElementById('cls-summary').innerHTML=`
    <div class="met" data-style="padding:10px"><div class="met-v" data-style="color:var(--gn);font-size:20px">${totIn}</div><div class="met-l">Total IN</div></div>
    <div class="met" data-style="padding:10px"><div class="met-v" data-style="color:var(--rd);font-size:20px">${totOut}</div><div class="met-l">Total OUT</div></div>
    <div class="met" data-style="padding:10px"><div class="met-v" data-style="color:var(--am);font-size:20px">${belowAlert}</div><div class="met-l">Below Alert</div></div>
    <div class="met" data-style="padding:10px"><div class="met-v" data-style="color:var(--rd);font-size:20px">${zeroStock}</div><div class="met-l">Zero Stock</div></div>`;
  const tb=document.getElementById('cls-body');
  tb.innerHTML=rows.map(r=>{
    const status=r.closingStock===0?'<span class="bdg br">Zero</span>':r.closingStock<r.m.lowAlert?'<span class="bdg ba">Low</span>':'<span class="bdg bg">OK</span>';
    const adjStr=r.adjQty===0?'—':(r.adjQty>0?'+':'')+r.adjQty;
    return `<tr>
      <td class="mono" data-style="font-size:10px">${sanitizeHTML(String(r.m.barcode||""))}</td>
      <td data-style="font-weight:500">${sanitizeHTML(String(r.m.name||""))}</td>
      <td data-style="font-size:10px">${sanitizeHTML(String(r.m.category||""))}</td>
      <td>${sanitizeHTML(String(r.m.unit||""))}</td>
      <td class="mono" data-style="text-align:center">${r.openingStock}</td>
      <td class="mono" data-style="text-align:center;color:var(--gn)">${r.inQty||'—'}</td>
      <td class="mono" data-style="text-align:center;color:var(--rd)">${r.outQty||'—'}</td>
      <td class="mono" data-style="text-align:center;color:var(--am)">${adjStr}</td>
      <td class="mono" data-style="text-align:center;font-weight:700;color:var(--bl)">${r.closingStock}</td>
      <td class="mono" data-style="text-align:center">${r.m.lowAlert}</td>
      <td>${status}</td>
    </tr>`;
  }).join('');
  // Store rows for export
  window._closingRows=rows;
}
function exportClosingCSV(){
  const sel=document.getElementById('cls-month');
  const rows=window._closingRows||[];
  const header=['Barcode','Name','Category','Unit','Opening Stock','Total IN','Total OUT','Adjustments','Closing Stock','Low Alert','Status'];
  const data=rows.map(r=>[r.m.barcode,r.m.name,r.m.category,r.m.unit,r.openingStock,r.inQty,r.outQty,r.adjQty,r.closingStock,r.m.lowAlert,r.closingStock===0?'Zero':r.closingStock<r.m.lowAlert?'Low':'OK']);
  const csv=[header,...data].map(row=>row.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');
  // FIX #4: revoke object URL to prevent memory leak
  const _clsUrl=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
  const a=document.createElement('a');a.href=_clsUrl;
  a.download=`closing_stock_${sel?.value||'report'}.csv`;a.click();
  setTimeout(()=>URL.revokeObjectURL(_clsUrl),1000);
  toast('CSV downloaded');
}
function exportClosingXLSX(){
  const sel=document.getElementById('cls-month');
  const rows=window._closingRows||[];
  if(!rows.length){toast('No data to export','er');return;}
  const header=['Barcode','Name','Category','Unit','Opening Stock','Total IN','Total OUT','Adjustments','Closing Stock','Low Alert','Status'];
  const data=rows.map(r=>[r.m.barcode,r.m.name,r.m.category,r.m.unit,r.openingStock,r.inQty,r.outQty,r.adjQty,r.closingStock,r.m.lowAlert,r.closingStock===0?'Zero':r.closingStock<r.m.lowAlert?'Low':'OK']);
  const xmlRows=[header,...data].map(row=>`<Row>${row.map(c=>`<Cell><Data ss:Type="${typeof c==='number'?'Number':'String'}">${String(c).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</Data></Cell>`).join('')}</Row>`).join('');
  const xml=`<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="Closing Stock"><Table>${xmlRows}</Table></Worksheet></Workbook>`;
  // FIX #4: revoke object URL to prevent memory leak
  const _clsXlsUrl=URL.createObjectURL(new Blob([xml],{type:'application/vnd.ms-excel'}));
  const a=document.createElement('a');a.href=_clsXlsUrl;
  a.download=`closing_stock_${sel?.value||'report'}.xls`;a.click();
  setTimeout(()=>URL.revokeObjectURL(_clsXlsUrl),1000);
  toast('Excel downloaded!');
}
function printClosingReport(){
  const sel=document.getElementById('cls-month');
  const rows=window._closingRows||[];
  const co=CFG.company||'Your Company';
  const period=sel?.options[sel.selectedIndex]?.text||'';
  const rowsHtml=rows.map((r,i)=>{
    const bg=i%2?'#f9fafb':'#fff';
    const clr=r.closingStock===0?'#dc2626':r.closingStock<r.m.lowAlert?'#d97706':'#111';
    return `<tr data-style="background:${bg}"><td data-style="border:1px solid #ddd;padding:5px 7px;font-family:monospace;font-size:9pt">${sanitizeHTML(String(r.m.barcode||""))}</td><td data-style="border:1px solid #ddd;padding:5px 7px;font-weight:500">${sanitizeHTML(String(r.m.name||""))}</td><td data-style="border:1px solid #ddd;padding:5px 7px">${sanitizeHTML(String(r.m.category||""))}</td><td data-style="border:1px solid #ddd;padding:5px 7px;text-align:center">${sanitizeHTML(String(r.m.unit||""))}</td><td data-style="border:1px solid #ddd;padding:5px 7px;text-align:center">${r.openingStock}</td><td data-style="border:1px solid #ddd;padding:5px 7px;text-align:center;color:#16a34a;font-weight:600">${r.inQty||0}</td><td data-style="border:1px solid #ddd;padding:5px 7px;text-align:center;color:#dc2626;font-weight:600">${r.outQty||0}</td><td data-style="border:1px solid #ddd;padding:5px 7px;text-align:center">${r.adjQty||0}</td><td data-style="border:1px solid #ddd;padding:5px 7px;text-align:center;font-weight:700;color:${clr}">${r.closingStock}</td></tr>`;
  }).join('');
  window.printPopupHtml(`<!DOCTYPE html><html><head><title>Closing Stock — ${period}</title><style>body{font-family:Arial,sans-serif;font-size:10pt;margin:10mm}h1{font-size:14pt}table{width:100%;border-collapse:collapse}th{background:#1e3a8a;color:#fff;padding:6px 8px;font-size:9pt}@media print{@page{margin:8mm}}</style></head><body>
    <div style="border-bottom:2px solid #1e3a8a;padding-bottom:8px;margin-bottom:12px"><h1>${co}</h1><p>Month-End Closing Stock Report — ${period} · Generated: ${new Date().toLocaleString()}</p></div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px">
      <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="color:#16a34a;font-size:16pt">${rows.reduce((s,r)=>s+r.inQty,0)}</b><br><small>Total IN</small></div>
      <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="color:#dc2626;font-size:16pt">${rows.reduce((s,r)=>s+r.outQty,0)}</b><br><small>Total OUT</small></div>
      <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="color:#d97706;font-size:16pt">${rows.filter(r=>r.closingStock<r.m.lowAlert).length}</b><br><small>Below Alert</small></div>
      <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="color:#dc2626;font-size:16pt">${rows.filter(r=>r.closingStock===0).length}</b><br><small>Zero Stock</small></div>
    </div>
    <table><thead><tr><th>Barcode</th><th>Item Name</th><th>Category</th><th>Unit</th><th>Opening</th><th>IN</th><th>OUT</th><th>Adj</th><th>Closing</th></tr></thead><tbody>${rowsHtml}</tbody></table>
    </body></html>`);
}

// ── Dashboard Widget Toggles ──
function saveWidgets(){
  const w={summary:document.getElementById('wgt-summary')?.checked,chart:document.getElementById('wgt-chart')?.checked,recent:document.getElementById('wgt-recent')?.checked,top:document.getElementById('wgt-top')?.checked,alerts:document.getElementById('wgt-alerts')?.checked,approvals:document.getElementById('wgt-approvals')?.checked};
  CFG.widgets=w;dPut('config',{id:'cfg',...CFG});
  applyWidgets();toast('Widget settings saved','inf');
}
function applyWidgets(){
  const w=CFG.widgets||{summary:true,chart:true,recent:true,top:true,alerts:true,approvals:true};
  // Apply checkboxes
  Object.keys(w).forEach(k=>{const el=document.getElementById('wgt-'+k);if(el){el.checked=w[k];}});
  // Show/hide dashboard sections
  const summaryEl=document.querySelector('.card:has(#sum-in)');
  const chartEl=document.querySelector('.card:has(#consumption-chart)');
  const recentEl=document.querySelector('.card:has(#d-rec)');
  const topEl=document.querySelector('.card:has(#d-top)');
  if(summaryEl){summaryEl.style.display=w.summary!==false?'':'none';}
  if(chartEl){chartEl.style.display=w.chart!==false?'':'none';}
  if(recentEl){recentEl.style.display=w.recent!==false?'':'none';}
  if(topEl){topEl.style.display=w.top!==false?'':'none';}
}

// ── Excel Export (all main lists) ──
function exportXLS(type){
  let header=[],data=[],filename='export';
  const d=new Date().toISOString().slice(0,10);
  if(type==='stock'){
    header=['Barcode','Name','Category','Unit','Stock','Low Alert','Suggested Order Qty','HSN','Location','Status'];
    data=M.filter(m=>m.active!==false).map(m=>[m.barcode,m.name,m.category,m.unit,m.stock,m.lowAlert,suggestedOrderQty(m),m.hsn||'',m.location||'',m.stock<m.lowAlert?'Low':'OK']);
    filename=`stock_${d}`;
  }else if(type==='history'){
    header=['Date','Barcode','Item','Type','Qty','Unit','Supplier/Dept','Person','Job','By','Status'];
    data=historyFilteredTransactions().map(t=>[new Date(t.time).toLocaleString(),t.barcode,t.itemName,t.type,t.qty,t.unit,t.supplierName||t.deptName||'',t.person||'',t.job||'',t.userName||t.user,t.status||'']);
    filename=`history_${d}`;
  }else if(type==='lowstock'){
    header=['Barcode','Name','Category','Unit','Stock','Required Qty','Suggested Order Qty'];
    data=lowItems().map(m=>{const stock=numericStockValue(m.stock)||0,alert=numericStockValue(m.lowAlert)||0;return [m.barcode,m.name,m.category,m.unit,stock,alert,suggestedOrderQty(m)];});
    filename=`low_stock_${d}`;
  }
  // FIX #3: was [header,data] — data is already an array of arrays, so spreading
  // it with [header,...data] correctly interleaves header + rows at the same level.
  const xmlRows=[header,...data].map(row=>`<Row>${row.map(c=>`<Cell><Data ss:Type="${typeof c==='number'?'Number':'String'}">${String(c).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</Data></Cell>`).join('')}</Row>`).join('');
  const xml=`<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="${type}"><Table>${xmlRows}</Table></Worksheet></Workbook>`;
  const a=document.createElement('a');
  const _xlsUrl=URL.createObjectURL(new Blob([xml],{type:'application/vnd.ms-excel'}));
  // FIX #4: Revoke object URL after 1 s to prevent browser memory leak
  a.href=_xlsUrl;a.download=`${filename}.xls`;a.click();
  setTimeout(()=>URL.revokeObjectURL(_xlsUrl),1000);
  toast('Excel downloaded!');
}

// ── LAN Sync v4 — Real Auto-Sync via Shared Folder ────────────────────────────

// FIX #10: Update the LAN Health panel with live data
function _updateLanHealthPanel(health) {
  const set = (id, val, color) => {
    const el = document.getElementById(id);
    if (el) { el.textContent = val; if (color) {el.style.color = color;} }
  };
  if (!health) {return;}
  // LAN STATUS
  const online = health.online !== false && health.active !== false;
  set('lhp-status', online ? 'ONLINE' : 'OFFLINE', online ? 'var(--gn)' : 'var(--rd)');
  // SYNC STATUS
  const syncActive = health.active;
  set('lhp-sync', syncActive ? 'ACTIVE' : 'INACTIVE', syncActive ? 'var(--gn)' : 'var(--tx3)');
  // LAST SYNC
  if (health.lastSync) {
    const diffSec = Math.round((Date.now() - health.lastSync) / 1000);
    const ago = diffSec < 5 ? 'just now' : diffSec < 60 ? diffSec + ' sec ago' : Math.round(diffSec/60) + ' min ago';
    set('lhp-lastsync', ago, 'var(--bl)');
  } else {
    set('lhp-lastsync', 'No sync yet', 'var(--tx3)');
  }
  // CONNECTED CLIENTS
  const clients = health.clients || 0;
  set('lhp-clients', clients, clients > 0 ? 'var(--tl)' : 'var(--tx3)');
}

async function refreshLanHealth() {
  if (!window.storeSync) {return;}
  const h = await window.storeSync.health();
  _updateLanHealthPanel(h);
}

// Push all data to shared folder's master.json
async function lanExport(){
  if(!window.storeSync){toast('Auto-sync not available','er');return;}
  const health=await window.storeSync.health();
  if(!health.online){toast('❌ Shared folder not accessible. Select folder first.','er');return;}
  const appVersion=(window.CONST&&window.CONST.APP&&window.CONST.APP.VERSION)?window.CONST.APP.VERSION:'8.0.0';
  const payload={M,T,materials:M,transactions:T,ADJ,SP,DP,CFG,config:CFG,AP,IN_REQ,RET,CC,GRN,LOCS,MOVS,
    exportedAt:new Date().toISOString(),v:'StoreTrack Pro v'+appVersion,lanSync:true};
  if(window.syncLogger){window.syncLogger.info('LAN push started',{folder:health.folder});}
  const result=await window.storeSync.pushMaster(payload);
  if(result.ok){
    document.getElementById('lan-status').textContent='✅ Pushed to LAN folder @ '+new Date().toLocaleTimeString();
    toast('✅ Data pushed to shared folder!');
    addAudit('LAN','LAN Push to shared folder','SYSTEM');
    if(window.syncLogger){window.syncLogger.info('LAN push succeeded',{folder:health.folder});}
    if(window.eventBus){window.eventBus.emit('lan:sync',{direction:'push',ok:true,folder:health.folder});}
  }else{
    toast('❌ Push failed: '+(result.error||'Unknown error'),'er');
    if(window.syncLogger){window.syncLogger.error('LAN push failed',{error:result.error});}
    notifyUser('LAN Sync Failed',result.error||'Unknown error','system','high');
    if(window.errorHandler){window.errorHandler.handleError(new Error(result.error||'LAN push failed'),{type:'lan_sync',silent:true});}
    if(window.eventBus){window.eventBus.emit('lan:sync',{direction:'push',ok:false,error:result.error});}
  }
}

// Pull latest data from shared folder's master.json
async function lanImport(){
  if(!window.storeSync){toast('Auto-sync not available','er');return;}
  const health=await window.storeSync.health();
  if(!health.online){toast('❌ Shared folder not accessible. Select folder first.','er');return;}
  const result=await window.storeSync.pullMaster();
  if(!result.ok){toast('❌ Pull failed: '+(result.error||'No data in folder'),'er');return;}
  const data=result.master;
  // Patch 6: validate schema before prompting to overwrite
  if(window.storeSync){
    const check=await window.storeSync.validateImport(data);
    if(!check.ok){toast('❌ Remote data failed validation: '+(check.error||'unknown'),'er');return;}
  }
  const exportedAt=data.exportedAt?new Date(data.exportedAt).toLocaleString():'Unknown';
  const device=data.lastDevice||'Unknown PC';
  if(!confirm(`Pull data from "${device}" @ ${exportedAt}?\n\nThis will OVERWRITE current data!`)){return;}
  await _applyLanMaster(data);
  document.getElementById('lan-status').textContent='✅ Pulled from '+device+' @ '+new Date().toLocaleTimeString();
  toast('✅ Data pulled from shared folder!');
  addAudit('LAN','LAN Pull from: '+device,'SYSTEM');
}

// Internal: apply master data to local IndexedDB
// Patch 6: validates schema via main-process validator before writing anything.
function normalizeLanMaster(data){
  const src=data||{};
  return {
    M:Array.isArray(src.materials)?src.materials:(Array.isArray(src.M)?src.M:[]),
    T:Array.isArray(src.transactions)?src.transactions:(Array.isArray(src.T)?src.T:[]),
    U:Array.isArray(src.users)?src.users:(Array.isArray(src.U)?src.U:[]),
    CFG:src.config&&typeof src.config==='object'?src.config:(src.CFG||null),
    ADJ:Array.isArray(src.adjustments)?src.adjustments:(Array.isArray(src.ADJ)?src.ADJ:[]),
    SP:Array.isArray(src.suppliers)?src.suppliers:(Array.isArray(src.SP)?src.SP:[]),
    DP:Array.isArray(src.departments)?src.departments:(Array.isArray(src.DP)?src.DP:[]),
    AP:Array.isArray(src.approvals)?src.approvals:(Array.isArray(src.AP)?src.AP:[]),
    IN_REQ:Array.isArray(src.indents)?src.indents:(Array.isArray(src.IN_REQ)?src.IN_REQ:[]),
    RET:Array.isArray(src.returns)?src.returns:(Array.isArray(src.RET)?src.RET:[]),
    CC:Array.isArray(src.cyclecount)?src.cyclecount:(Array.isArray(src.CC)?src.CC:[]),
    GRN:Array.isArray(src.grn)?src.grn:(Array.isArray(src.GRN)?src.GRN:[]),
    LOCS:Array.isArray(src.locations)?src.locations:(Array.isArray(src.LOCS)?src.LOCS:[]),
    MOVS:Array.isArray(src.movements)?src.movements:(Array.isArray(src.MOVS)?src.MOVS:[])
  };
}
async function _applyLanMaster(data){
  if(window.storeSync){
    const check=await window.storeSync.validateImport(data);
    if(!check.ok){throw new Error('Import validation failed: '+(check.error||'unknown'));}
  }
  data=normalizeLanMaster(data);
  if(data.M.length){for(const m of data.M){await dPut('materials',m);}M=await gAll('materials');}
  if(data.SP.length){for(const s of data.SP){await dPut('suppliers',s);}SP=await gAll('suppliers');}
  if(data.DP.length){for(const d of data.DP){await dPut('departments',d);}DP=await gAll('departments');}
  if(data.T.length){for(const t of data.T){await dPut('transactions',t);}T=await gAll('transactions');}
  if(data.ADJ.length){for(const a of data.ADJ){await dPut('adjustments',a);}ADJ=await gAll('adjustments');}
  if(data.AP.length){for(const a of data.AP){await dPut('approvals',a);}AP=await gAll('approvals');}
  if(data.IN_REQ.length){for(const x of data.IN_REQ){await dPut('indents',x);}IN_REQ=await gAll('indents');}
  if(data.RET.length){for(const x of data.RET){await dPut('returns',x);}RET=await gAll('returns');}
  if(data.CC.length){for(const x of data.CC){await dPut('cyclecount',x);}CC=await gAll('cyclecount');}
  if(data.GRN.length){for(const x of data.GRN){await dPut('grn',x);}GRN=await gAll('grn');}
  if(data.LOCS.length){for(const x of data.LOCS){await dPut('locations',x);}LOCS=await gAll('locations');}
  if(data.MOVS.length){for(const x of data.MOVS){await dPut('movements',x);}MOVS=await gAll('movements');}
  if(data.CFG&&data.CFG.id){await dPut('config',data.CFG);CFG=data.CFG;}
  updateBadges();updateDash();
}

// ── Add Excel buttons to existing CSV exports ──
function addXlsButtons(){
  // Stock page
  const stkHd=document.querySelector('#s-stock .card-hd');
  if(stkHd&&!stkHd.querySelector('.xls-btn')){
    const b=document.createElement('button');b.className='btn xls-btn';applyCssText(b,'font-size:10px;padding:3px 8px;margin-left:4px');b.textContent='📊 Excel';b.onclick=()=>exportXLS('stock');
    stkHd.appendChild(b);
  }
  // History page
  const histHd=document.querySelector('#s-hist .card-hd');
  if(histHd&&!histHd.querySelector('.xls-btn')){
    const b=document.createElement('button');b.className='btn xls-btn';applyCssText(b,'font-size:10px;padding:3px 8px;margin-left:4px');b.textContent='📊 Excel';b.onclick=()=>exportXLS('history');
    histHd.appendChild(b);
  }
}


// ══════════════════════════════════════════════
// SHIFT MANAGEMENT
// ══════════════════════════════════════════════
const SHIFTS = [
  { id: 1, name: '1st Shift', label: 'S1', start: { h: 7,  m: 0  }, end: { h: 15, m: 30 }, color: '#3b82f6' },
  { id: 2, name: '2nd Shift', label: 'S2', start: { h: 15, m: 30 }, end: { h: 0,  m: 0  }, color: '#f59e0b' },
  { id: 3, name: '3rd Shift', label: 'S3', start: { h: 0,  m: 0  }, end: { h: 7,  m: 0  }, color: '#8b5cf6' },
];

let currentShiftId = null;
let shiftCheckInterval = null;

function getShiftForTime(date) {
  const h = date.getHours();
  const m = date.getMinutes();
  const mins = h * 60 + m;
  // 1st: 7:00–15:30  (420–930)
  if (mins >= 420 && mins < 930) {return SHIFTS[0];}
  // 2nd: 15:30–00:00 (930–1440)
  if (mins >= 930) {return SHIFTS[1];}
  // 3rd: 00:00–7:00  (0–420)
  return SHIFTS[2];
}

function getCurrentShift() {
  return getShiftForTime(new Date());
}

function getShiftStart(shift, refDate) {
  // returns Date object for shift start on refDate (or previous day for 3rd shift)
  const d = new Date(refDate);
  d.setHours(shift.start.h, shift.start.m, 0, 0);
  if (shift.id === 3) {
    // 3rd shift starts at midnight — could be today or yesterday
    const now = new Date();
    if (now.getHours() < 7) {
      // We're in early morning — shift started yesterday midnight
      d.setDate(d.getDate()); // same date midnight = correct
    }
  }
  return d;
}

function getShiftEnd(shift, refDate) {
  const d = new Date(refDate);
  if (shift.id === 1) { d.setHours(15, 30, 0, 0); return d; }
  if (shift.id === 2) { d.setDate(d.getDate() + 1); d.setHours(0, 0, 0, 0); return d; }
  // 3rd shift ends at 7:00 same day
  d.setHours(7, 0, 0, 0);
  return d;
}

function getShiftTxns(shift) {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  let start, end;
  if (shift.id === 1) {
    start = new Date(today); start.setHours(7, 0, 0, 0);
    end   = new Date(today); end.setHours(15, 30, 0, 0);
  } else if (shift.id === 2) {
    start = new Date(today); start.setHours(15, 30, 0, 0);
    const tomorrow = new Date(today); tomorrow.setDate(today.getDate()+1);
    end   = new Date(tomorrow); end.setHours(0, 0, 0, 0);
    // If currently in 2nd shift, end = now
    if (now < end) {end = now;}
  } else {
    // 3rd shift: midnight to 7:00
    start = new Date(today); start.setHours(0, 0, 0, 0);
    end   = new Date(today); end.setHours(7, 0, 0, 0);
    if (now < end) {end = now;}
  }
  return T.filter(t => { const d = new Date(t.time); return d >= start && d <= end; });
}

function updateShiftWidget() {
  const shift = getCurrentShift();
  const now = new Date();

  // Update topbar badge
  const badge = document.getElementById('shift-badge');
  if (badge) {
    badge.textContent = shift.label;
    badge.style.background = shift.color;
  }

  // Update widget
  const swName = document.getElementById('sw-name');
  const swTime = document.getElementById('sw-time');
  const swEnds = document.getElementById('sw-ends');
  const swWidget = document.getElementById('shift-widget');
  if (!swName) {return;}

  // Time strings
  const timeStr = s => `${String(s.h).padStart(2,'0')}:${String(s.m).padStart(2,'0')}`;
  const endStr = shift.id === 2 ? '00:00' : timeStr(shift.end);

  swName.textContent = shift.name;
  swName.style.color = shift.color;
  if (swWidget) {swWidget.style.borderLeftColor = shift.color;}
  swTime.textContent = `${timeStr(shift.start)} – ${endStr}`;

  // Remaining time
  let endDate;
  if (shift.id === 1) { endDate = new Date(now); endDate.setHours(15,30,0,0); }
  else if (shift.id === 2) { endDate = new Date(now); endDate.setDate(now.getDate()+1); endDate.setHours(0,0,0,0); }
  else { endDate = new Date(now); endDate.setHours(7,0,0,0); if(now.getHours()>=7) {endDate.setDate(now.getDate()+1);} }

  const remaining = endDate - now;
  const rh = Math.floor(remaining / 3600000);
  const rm = Math.floor((remaining % 3600000) / 60000);
  const swRem = document.getElementById('sw-remaining');
  if (swRem) {swRem.textContent = `${rh}h ${rm}m remaining`;}
  if (swEnds) {swEnds.textContent = `Ends at ${endStr}`;}

  // Transactions this shift
  const txns = getShiftTxns(shift).filter(isCompletedMovement);
  const inTxns  = txns.filter(t => t.type === 'IN');
  const outTxns = txns.filter(t => t.type === 'OUT' && t.status === 'confirmed');
  const uniqItems = new Set(txns.map(t => t.itemId)).size;

  const el = id => document.getElementById(id);
  if(el('sw-in'))    {el('sw-in').textContent    = inTxns.reduce((s,t)=>s+Number(t.qty||0),0);}
  if(el('sw-out'))   {el('sw-out').textContent   = outTxns.reduce((s,t)=>s+Number(t.qty||0),0);}
  if(el('sw-txn'))   {el('sw-txn').textContent   = txns.length;}
  if(el('sw-items')) {el('sw-items').textContent = uniqItems;}

  // Recent txns list
  const list = document.getElementById('sw-txn-list');
  if (list) {
    const recent = txns.slice().sort((a,b)=>new Date(b.time)-new Date(a.time)).slice(0,8);
    if (!recent.length) {
      list.innerHTML = '<div data-style="text-align:center;padding:10px;color:var(--tx3);font-size:10px">No transactions yet this shift</div>';
    } else {
      list.innerHTML = recent.map(t => {
        const isIn = t.type === 'IN';
        const time = new Date(t.time).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
        return `<div data-style="display:flex;align-items:center;gap:8px;padding:4px 0;border-bottom:1px solid var(--b1);font-size:10px">
          <span>${isIn?'📥':'📤'}</span>
          <span data-style="flex:1;font-weight:500">${t.itemName}</span>
          <span data-style="color:var(--tx3)">${t.barcode}</span>
          <span data-style="font-weight:700;font-family:var(--mn);color:${isIn?'var(--gn)':'var(--rd)'}">${isIn?'+':'-'}${t.qty} ${t.unit}</span>
          <span data-style="color:var(--tx3);min-width:36px;text-align:right">${time}</span>
        </div>`;
      }).join('');
    }
  }
}

function checkShiftChange() {
  const shift = getCurrentShift();
  if (currentShiftId === null) {
    currentShiftId = shift.id;
    return;
  }
  if (shift.id !== currentShiftId) {
    const oldShift = SHIFTS.find(s => s.id === currentShiftId);
    currentShiftId = shift.id;
    // Show shift end summary THEN lock
    showShiftEndSummary(oldShift, shift);
  }
}

function showShiftEndSummary(endedShift, newShift) {
  const txns = getShiftTxns(endedShift).filter(isCompletedMovement);
  const inTxns  = txns.filter(t => t.type === 'IN');
  const outTxns = txns.filter(t => t.type === 'OUT' && t.status === 'confirmed');
  const uniq    = new Set(txns.map(t => t.itemId)).size;

  const se = id => document.getElementById(id);
  if (!se('shift-end-ov')) {return;}

  se('se-title').textContent = `${endedShift.name} → ${newShift.name}`;
  se('se-summary').innerHTML = `
    <div class="met" data-style="padding:10px"><div class="met-v" data-style="color:var(--gn);font-size:20px">${inTxns.reduce((s,t)=>s+Number(t.qty||0),0)}</div><div class="met-l">Total IN</div></div>
    <div class="met" data-style="padding:10px"><div class="met-v" data-style="color:var(--rd);font-size:20px">${outTxns.reduce((s,t)=>s+Number(t.qty||0),0)}</div><div class="met-l">Total OUT</div></div>
    <div class="met" data-style="padding:10px"><div class="met-v" data-style="color:var(--bl);font-size:20px">${txns.length}</div><div class="met-l">Transactions</div></div>
    <div class="met" data-style="padding:10px"><div class="met-v" data-style="color:var(--am);font-size:20px">${uniq}</div><div class="met-l">Items</div></div>`;

  const sorted = txns.slice().sort((a,b)=>new Date(b.time)-new Date(a.time));
  se('se-txn-body').innerHTML = sorted.length ? sorted.map(t=>{
    const isIn = t.type==='IN';
    const time = new Date(t.time).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
    return `<tr>
      <td data-style="padding:4px 8px;font-family:var(--mn);font-size:10px">${time}</td>
      <td data-style="padding:4px 8px;font-weight:500">${t.itemName}</td>
      <td data-style="padding:4px 8px;text-align:center"><span class="bdg ${isIn?'bg':'br'}">${t.type}</span></td>
      <td data-style="padding:4px 8px;text-align:center;font-weight:700;font-family:var(--mn);color:${isIn?'var(--gn)':'var(--rd)'}">${isIn?'+':'-'}${t.qty}</td>
      <td data-style="padding:4px 8px;color:var(--tx3)">${t.userName||t.user}</td>
    </tr>`;
  }).join('') : '<tr><td colspan="5" data-style="text-align:center;padding:16px;color:var(--tx3)">No transactions this shift</td></tr>';

  // Store for print
  window._shiftEndData = { shift: endedShift, txns, inTxns, outTxns, uniq };
  se('shift-end-ov').classList.add('on');
}

function closeShiftEnd() {
  document.getElementById('shift-end-ov').classList.remove('on');
  // Auto-lock after acknowledging
  if (CFG && CFG.pin) {lockScreen();}
}

function printShiftReport(isEnd) {
  const data = isEnd ? window._shiftEndData : null;
  const shift = data ? data.shift : getCurrentShift();
  const txns  = data ? data.txns  : getShiftTxns(shift);
  const inTxns  = txns.filter(t => t.type === 'IN');
  const outTxns = txns.filter(t => t.type === 'OUT' && t.status === 'confirmed');
  const uniq    = new Set(txns.map(t => t.itemId)).size;
  const co = CFG.company || 'Your Company';

  const rowsHtml = txns.slice().sort((a,b)=>new Date(a.time)-new Date(b.time)).map((t,i) => {
    const isIn = t.type === 'IN';
    const bg = i%2 ? '#f9fafb' : '#fff';
    return `<tr data-style="background:${bg}">
      <td data-style="border:1px solid #ddd;padding:4px 7px">${new Date(t.time).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</td>
      <td data-style="border:1px solid #ddd;padding:4px 7px;font-family:monospace;font-size:9pt">${t.barcode}</td>
      <td data-style="border:1px solid #ddd;padding:4px 7px;font-weight:500">${t.itemName}</td>
      <td data-style="border:1px solid #ddd;padding:4px 7px;text-align:center;color:${isIn?'#16a34a':'#dc2626'};font-weight:700">${t.type}</td>
      <td data-style="border:1px solid #ddd;padding:4px 7px;text-align:center;font-weight:700;color:${isIn?'#16a34a':'#dc2626'}">${isIn?'+':'-'}${t.qty} ${t.unit}</td>
      <td data-style="border:1px solid #ddd;padding:4px 7px">${sanitizeHTML(String(t.deptName||t.supplierName||'—'))}</td>
      <td data-style="border:1px solid #ddd;padding:4px 7px">${t.userName||t.user}</td>
    </tr>`;
  }).join('');

  window.printPopupHtml(`<!DOCTYPE html><html><head><title>${shift.name} Report</title>
  <style>body{font-family:Arial,sans-serif;font-size:10pt;margin:10mm}h1{font-size:14pt;margin:0}table{width:100%;border-collapse:collapse}th{background:#1e3a8a;color:#fff;padding:5px 7px;font-size:9pt}@media print{@page{margin:8mm}}</style>
  </head><body>
  <div style="border-bottom:2px solid #1e3a8a;padding-bottom:8px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:flex-end">
    <div><h1>${co}</h1><p style="margin:2px 0;color:#555">${shift.name} Report · ${new Date().toLocaleDateString()}</p></div>
    <div style="text-align:right;font-size:9pt;color:#555">Printed: ${new Date().toLocaleString()}</div>
  </div>
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px">
    <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="color:#16a34a;font-size:16pt">${inTxns.reduce((s,t)=>s+Number(t.qty||0),0)}</b><br><small>Total IN Qty</small></div>
    <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="color:#dc2626;font-size:16pt">${outTxns.reduce((s,t)=>s+Number(t.qty||0),0)}</b><br><small>Total OUT Qty</small></div>
    <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="color:#1e40af;font-size:16pt">${txns.length}</b><br><small>Transactions</small></div>
    <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="color:#d97706;font-size:16pt">${uniq}</b><br><small>Unique Items</small></div>
  </div>
  <table><thead><tr><th>Time</th><th>Barcode</th><th>Item Name</th><th style="text-align:center">Type</th><th style="text-align:center">Qty</th><th>Dept/Supplier</th><th>By</th></tr></thead>
  <tbody>${rowsHtml||'<tr><td colspan="7" style="text-align:center;padding:16px;color:#999">No transactions this shift</td></tr>'}</tbody></table>
  <div style="margin-top:20px;border-top:1px solid #ddd;padding-top:10px;display:flex;justify-content:space-between">
    <div style="font-size:9pt;color:#555">Supervisor Signature: ________________________</div>
    <div style="font-size:9pt;color:#555">Date/Time: ${new Date().toLocaleString()}</div>
  </div>
  </body></html>`);
}

// Tag shift on every transaction
function getCurrentShiftLabel() {
  const s = getCurrentShift();
  return { shiftId: s.id, shiftName: s.name, shiftLabel: s.label };
}

// Start shift monitoring
function startShiftMonitor() {
  currentShiftId = getCurrentShift().id;
  updateShiftWidget();
  // Check every 30 seconds for shift change
  shiftCheckInterval = setInterval(() => {
    checkShiftChange();
    updateShiftWidget();
  }, 30000);
}


// ══════════════════════════════════════════════
// BIN LOCATION MANAGEMENT
// ══════════════════════════════════════════════

function locCode(loc){ return `${loc.zone}-${loc.rack}-${loc.bin}`; }

function popLocSelects(){
  // Populate zone filter
  const zones=[...new Set(LOCS.map(l=>l.zone))].sort();
  const zf=document.getElementById('flt-loc-zone');
  if(zf) {zf.innerHTML='<option value="">All Zones</option>'+zones.map(z=>`<option value="${z}">${z}</option>`).join('');}
  // Populate location filter for stock report
  const lr=document.getElementById('flt-loc-report');
  const reportList=document.getElementById('flt-loc-report-options');
  if(lr&&reportList) {reportList.innerHTML=LOCS.map(l=>`<option value="${sanitizeHTML(String(locCode(l)))}"></option>`).join('');}
  // Populate suggestions shared by stock movement From/To inputs.
  const movementList=document.getElementById('mov-location-options');
  if(movementList) {movementList.innerHTML=LOCS.map(l=>`<option value="${sanitizeHTML(String(locCode(l)))}" label="${sanitizeHTML(String(l.desc||''))}"></option>`).join('');}
  // Populate mov-item
  const mi=document.getElementById('mov-item');
  if(mi) {mi.innerHTML='<option value="">— Select Item —</option>'+M.filter(m=>m.active!==false).map(m=>`<option value="${sanitizeHTML(String(m.id))}">${sanitizeHTML(String(m.name||""))} (${sanitizeHTML(String(m.barcode||""))})</option>`).join('');}
  popBinLocSel();
}

function popBinLocSel(){
  // Populate typeable location suggestions in the material master.
  const input=document.getElementById('m-binloc');
  const list=document.getElementById('m-binloc-options');
  if(!input||!list) {return;}
  list.innerHTML=LOCS.map(l=>`<option value="${sanitizeHTML(String(locCode(l)))}" label="${sanitizeHTML(String(l.desc||''))}"></option>`).join('');
}

function renderLocs(){
  const srch=(document.getElementById('srch-loc')?.value||'').toLowerCase();
  const zone=document.getElementById('flt-loc-zone')?.value||'';
  const filtered=LOCS.filter(l=>(!zone||l.zone===zone)&&(!srch||locCode(l).toLowerCase().includes(srch)||(l.desc&&String(l.desc).toLowerCase().includes(srch))));
  const count=document.getElementById('loc-cnt');if(count)count.textContent=`${filtered.length} locations`;
  const tb=document.getElementById('loc-body');if(!tb)return;
  if(!filtered.length){tb.innerHTML='<tr><td colspan="8" data-style="text-align:center;padding:16px;color:var(--tx3)">No locations found</td></tr>';return;}
  tb.innerHTML=filtered.map(l=>{
    const code=locCode(l),items=M.filter(m=>identifiersMatch(m.binLocationId,l.id)&&m.active!==false);
    const totalStock=items.reduce((sum,m)=>sum+(Number(m.stock)||0),0);
    const cap=Number(l.capacity)||0,capStr=cap?`${totalStock}/${cap}`:'—',capColor=cap&&totalStock>=cap?'var(--rd)':'var(--gn)';
    return `<tr><td><input type="checkbox" class="loc-label-cb" data-id="${eventIdArg(l.id)}" aria-label="Select ${sanitizeHTML(String(code||'location'))} for label"></td><td data-style="font-weight:600;color:var(--bl)">${sanitizeHTML(String(l.zone||''))}</td><td>${sanitizeHTML(String(l.rack||''))}</td><td data-style="font-family:var(--mn);font-weight:600">${sanitizeHTML(String(l.bin||''))}</td><td><span class="bdg bb" data-style="font-family:var(--mn);font-size:10px">${sanitizeHTML(String(code||''))}</span></td><td data-style="text-align:center">${items.length} items</td><td data-style="text-align:center;color:${capColor}">${sanitizeHTML(String(capStr))}</td><td><button class="btn btn-s" data-style="font-size:10px;padding:2px 7px" data-onclick="printBinLabel(${eventIdArg(l.id)})">🏷</button> <button class="btn" data-style="font-size:10px;padding:2px 7px" data-onclick="editLoc(${eventIdArg(l.id)})">✏</button> <button class="btn btn-d" data-style="font-size:10px;padding:2px 7px" data-onclick="delLoc(${eventIdArg(l.id)})">🗑</button></td></tr>`;
  }).join('');
}

function renderLocStock(){
  const locationQuery=(document.getElementById('flt-loc-report')?.value||'').trim().toLowerCase();
  const items=M.filter(m=>{
    if(m.active===false||!locationQuery)return m.active!==false;
    const location=LOCS.find(l=>identifiersMatch(l.id,m.binLocationId));
    return Boolean((location&&String(locCode(location)).toLowerCase().includes(locationQuery))||String(m.location||'').toLowerCase().includes(locationQuery));
  });
  const tb=document.getElementById('loc-stock-body');if(!tb)return;
  if(!items.length){tb.innerHTML='<tr><td colspan="7" data-style="text-align:center;padding:16px;color:var(--tx3)">No items</td></tr>';return;}
  tb.innerHTML=items.map(m=>{
    const loc=LOCS.find(l=>identifiersMatch(l.id,m.binLocationId));
    const locStr=loc?locCode(loc):(m.location||'—'),stock=Number(m.stock)||0,alert=Number(m.lowAlert)||0;
    const status=stock===0?'<span class="bdg br">Zero</span>':stock<alert?'<span class="bdg ba">Low</span>':'<span class="bdg bg">OK</span>';
    return `<tr><td><span class="bdg bb" data-style="font-size:10px;font-family:var(--mn)">${sanitizeHTML(String(locStr||''))}</span></td><td data-style="font-family:var(--mn);font-size:10px">${sanitizeHTML(String(m.barcode||''))}</td><td data-style="font-weight:500">${sanitizeHTML(String(m.name||''))}</td><td data-style="font-size:10px">${sanitizeHTML(String(m.category||''))}</td><td>${sanitizeHTML(String(m.unit||''))}</td><td data-style="font-family:var(--mn);font-weight:700;text-align:center;color:${stock<alert?'var(--am)':'var(--bl)'}">${sanitizeHTML(String(stock))}</td><td>${status}</td></tr>`;
  }).join('');
}

function renderMovHist(){
  const tb=document.getElementById('mov-hist-body');
  if(!tb) {return;}
  const sorted=MOVS.slice().sort((a,b)=>new Date(b.time)-new Date(a.time)).slice(0,30);
  if(!sorted.length){tb.innerHTML='<tr><td colspan="6" data-style="text-align:center;padding:12px;color:var(--tx3)">No movements yet</td></tr>';return;}
  tb.innerHTML=sorted.map(mv=>`<tr>
    <td data-style="font-size:10px;font-family:var(--mn)">${new Date(mv.time).toLocaleString([],{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}</td>
    <td data-style="font-weight:500">${sanitizeHTML(String(mv.itemName||''))}</td>
    <td><span class="bdg" data-style="background:var(--bg3);font-family:var(--mn);font-size:10px">${sanitizeHTML(String(mv.fromLoc||''))}</span></td>
    <td><span class="bdg bb" data-style="font-family:var(--mn);font-size:10px">${sanitizeHTML(String(mv.toLoc||''))}</span></td>
    <td data-style="text-align:center;font-family:var(--mn);font-weight:600">${sanitizeHTML(String(mv.qty??0))}</td>
    <td data-style="color:var(--tx3)">${sanitizeHTML(String(mv.user||''))}</td>
  </tr>`).join('');
}

function _binLabelRows(ids) {
  const selected = ids && ids.length ? LOCS.filter(l=>ids.some(id=>identifiersMatch(id,l.id))) : LOCS.slice();
  const result = window.StoreTrackBatch2C?.validateBinLabels(selected);
  if (!result?.valid) { toast('Label generation blocked: '+result.errors.map(e=>e.message).join(' '), 'er'); return null; }
  return result.labels;
}
function _binLabelHtml(label) {
  const esc = value => sanitizeHTML(String(value||''));
  return `<div class="bin-label"><div class="bin-title">BIN / LOCATION</div><div class="bin-code">${esc(label.code)}</div><svg class="bin-bars" data-barcode="${esc(label.barcode)}"></svg><div class="bin-barcode-text">${esc(label.barcode)}</div>${label.description?`<div class="bin-desc">${esc(label.description)}</div>`:''}</div>`;
}
function printBinLabel(id) { printSelectedBinLabels([id]); }
function toggleAllBinLabels(checked) { document.querySelectorAll('.loc-label-cb').forEach(cb=>{cb.checked=checked;}); }
function printSelectedBinLabels(ids) {
  const selectedIds = ids || Array.from(document.querySelectorAll('.loc-label-cb:checked')).map(cb=>cb.dataset.id);
  if (!selectedIds.length) { toast('Select one or more bin locations first', 'er'); return; }
  const labels = _binLabelRows(selectedIds); if (!labels) return;
  const content = labels.map(_binLabelHtml).join('');
  const doc = `<!doctype html><html><head><title>Bin Location Labels</title><script src="${location.origin}/node_modules/jsbarcode/dist/JsBarcode.all.min.js"></script><style>body{font-family:Arial,sans-serif;margin:8mm}.grid{display:grid;grid-template-columns:repeat(3,50mm);gap:4mm}.bin-label{width:50mm;height:30mm;border:1px solid #000;padding:2mm;text-align:center;page-break-inside:avoid}.bin-title{font-size:7pt;font-weight:bold}.bin-code{font-size:14pt;font-weight:800;margin:1mm 0}.bin-bars{width:42mm;height:8mm}.bin-barcode-text{font:7pt monospace}.bin-desc{font-size:7pt;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}@media print{body{margin:0}.grid{gap:0}.bin-label{border:1px solid #000}}</style></head><body><div class="grid">${content}</div><script>document.querySelectorAll('svg[data-barcode]').forEach(e=>JsBarcode(e,e.dataset.barcode,{format:'CODE128',displayValue:false,height:28,margin:0}));</script></body></html>`;
  window.printPopupHtml(doc); addAudit('PRINT',`Printed ${labels.length} bin/location label(s)`,'LOCATION'); toast(`${labels.length} label(s) opened in print preview`);
}
// ── Serial 24: stable bin/location label functions ──
async function saveLoc(){
  const zone=(document.getElementById('loc-zone')?.value||'').trim().toUpperCase();
  const rack=(document.getElementById('loc-rack')?.value||'').trim().toUpperCase();
  const bin=(document.getElementById('loc-bin')?.value||'').trim().toUpperCase();
  if(!zone||!rack||!bin){toast('Zone, Rack, Bin required!','er');return;}
  const capResult=parseLocationCapacity(document.getElementById('loc-cap')?.value);
  if(!capResult.ok){toast('Max capacity must be a non-negative whole number','er');return;}
  const desc=(document.getElementById('loc-desc')?.value||'').trim(),eid=String(document.getElementById('loc-eid')?.value||'').trim();
  const existing=eid?LOCS.find(l=>identifiersMatch(l.id,eid)):null;
  if(eid&&!existing){toast('Location record not found; reload before editing','er');return;}
  const dup=LOCS.find(l=>l.zone===zone&&l.rack===rack&&l.bin===bin&&(!existing||!identifiersMatch(l.id,existing.id)));
  if(dup){toast('Location already exists!','er');return;}
  const loc={id:existing?existing.id:Date.now(),zone,rack,bin,desc,capacity:capResult.value,createdAt:existing?.createdAt||new Date().toISOString()};
  try{await dPut('locations',loc);}
  catch(error){console.error('[location] save failed',error);toast('Location save failed; no success was reported. '+(error.message||''),'er');return;}
  let refreshFailed=false;
  try{LOCS=await gAll('locations');}
  catch(error){refreshFailed=true;console.warn('[location] saved but list refresh failed',error);const index=LOCS.findIndex(l=>identifiersMatch(l.id,loc.id));if(index<0)LOCS.push(loc);else LOCS[index]=loc;}
  clrLoc();renderLocs();popLocSelects();
  toast(refreshFailed?'Location saved, but the list could not be refreshed.':'Location saved');
  try{await addAudit('LOC',(eid?'Updated':'Added')+' location: '+locCode(loc),'SYSTEM');}catch(error){console.warn('[location] audit write failed',error);}
}
function clrLoc(){
  ['loc-eid','loc-zone','loc-rack','loc-bin','loc-desc','loc-cap'].forEach(id=>{const el=document.getElementById(id);if(el){el.value='';}});
}
function editLoc(id){
  const l=LOCS.find(x=>String(x.id)===String(id));if(!l){return;}
  document.getElementById('loc-eid').value=l.id;
  document.getElementById('loc-zone').value=l.zone;
  document.getElementById('loc-rack').value=l.rack;
  document.getElementById('loc-bin').value=l.bin;
  document.getElementById('loc-desc').value=l.desc||'';
  document.getElementById('loc-cap').value=l.capacity||'';
  document.getElementById('loc-zone').focus();
}
async function delLoc(id){
  if(typeof canRoleAction!=='function'||!canRoleAction('mapping'))return;
  const sameId=(a,b)=>a!==null&&a!==undefined&&b!==null&&b!==undefined&&String(a)===String(b);
  const loc=LOCS.find(l=>sameId(l.id,id));if(!loc)return;
  const itemsHere=M.filter(m=>sameId(m.binLocationId,loc.id)).length;
  if(itemsHere){toast(`Cannot delete ${locCode(loc)}: ${itemsHere} item(s) still reference this Bin Location. Move or unassign them first.`,'er');return;}
  if(!confirm('Delete location '+locCode(loc)+'?'))return;
  try{await dDel('locations',loc.id);}
  catch(error){console.error('[location] delete failed',error);toast('Location delete failed; the location remains in the list. '+(error.message||''),'er');return;}
  LOCS=LOCS.filter(l=>!sameId(l.id,loc.id));renderLocs();popLocSelects();toast('Location deleted');
}

// ── Stock Movement ──
function loadMovItem(){
  const id=String(document.getElementById('mov-item')?.value||'').trim();
  const info=document.getElementById('mov-item-info');
  if(!id||!info){if(info)info.style.display='none';const from=document.getElementById('mov-from');if(from)from.value='';return;}
  const item=M.find(m=>identifiersMatch(m.id,id));if(!item){info.style.display='none';return;}
  const loc=LOCS.find(l=>identifiersMatch(l.id,item.binLocationId));
  document.getElementById('mov-item-name').textContent=item.name;
  document.getElementById('mov-item-loc').textContent='Current: '+(loc?locCode(loc):(item.location||'Not assigned'));
  document.getElementById('mov-item-stock').textContent=item.stock+' '+item.unit;info.style.display='';
  const mf=document.getElementById('mov-from');if(mf)mf.value=loc?locCode(loc):'';
}

function clrMove(){
  ['mov-item','mov-from','mov-to','mov-qty','mov-reason'].forEach(id=>{const el=document.getElementById(id);if(el){el.value='';}});
  const info=document.getElementById('mov-item-info');if(info){info.style.display='none';}
}
async function confirmMove(){
  const sameId=(a,b)=>a!==null&&a!==undefined&&b!==null&&b!==undefined&&String(a)===String(b);
  const itemId=String(document.getElementById('mov-item')?.value||'').trim();
  const toText=(document.getElementById('mov-to')?.value||'').trim();
  if(!itemId){toast('Item select kara!','er');return;}
  if(!toText){toast('To Location select kara!','er');return;}
  const item=M.find(m=>sameId(m.id,itemId));if(!item){toast('Item not found','er');return;}
  const toLoc=LOCS.find(l=>sameId(l.id,toText)||String(locCode(l)).trim().toLowerCase()===toText.toLowerCase());if(!toLoc){toast('Select an existing To Location from the suggestions.','er');return;}
  const toId=toLoc.id;
  const fromLoc=LOCS.find(l=>sameId(l.id,item.binLocationId));
  const fromText=(document.getElementById('mov-from')?.value||'').trim();
  if(fromText&&(!fromLoc||!sameId(fromLoc.id,fromText)&&String(locCode(fromLoc)).trim().toLowerCase()!==fromText.toLowerCase())){toast('From Location must match the Item’s current Bin Location.','er');return;}
  if(sameId(item.binLocationId,toId)){toast('From and To location same aahe!','er');return;}
  const rawMovQty=String(document.getElementById('mov-qty')?.value||'').trim();
  const movQty=rawMovQty===''?Number(item.stock):Number(rawMovQty);
  if(!Number.isInteger(movQty)||movQty<=0||movQty>item.stock){toast('Movement quantity must be a positive whole number within available stock','er');return;}
  if(movQty!==Number(item.stock)){toast('Partial location movement is not supported because each item currently has one Bin Location. Move the full stock quantity.','er');return;}
  const reason=(document.getElementById('mov-reason')?.value||'').trim();
  // Capacity check
  if(Number(toLoc.capacity)>0){
    const currentInTo=M.filter(m=>sameId(m.binLocationId,toId)&&m.active!==false&&!sameId(m.id,itemId)).reduce((s,m)=>s+(Number(m.stock)||0),0);
    if(currentInTo+movQty>toLoc.capacity){toast(`Location ${locCode(toLoc)} capacity exceeded! Max: ${toLoc.capacity}`,'er');return;}
  }
  // This data model stores one Bin Location per material, so movement is all-or-nothing.
  const fromLocId=item.binLocationId||0;
  const oldLocStr=fromLoc?locCode(fromLoc):(item.location||'Unassigned');
  const newLocStr=locCode(toLoc);
  const updatedItem={...item,binLocationId:toId,location:newLocStr,updatedAt:new Date().toISOString()};
  const mv={id:Date.now(),time:new Date().toISOString(),itemId:item.id,itemName:item.name,barcode:item.barcode,fromLoc:oldLocStr,toLoc:newLocStr,fromLocId,toLocId:toId,qty:movQty,reason,user:cu.username,userName:cu.name};
  if(typeof window.dPutMany!=='function'){toast('Atomic movement is unavailable; no location or history change was made.','er');return;}
  try{await window.dPutMany([{store:'materials',obj:updatedItem},{store:'movements',obj:mv}]);}
  catch(e){console.error('Atomic stock movement failed',e);toast('Movement failed; item location and movement history were not changed.','er');return;}
  const itemIndex=M.findIndex(m=>sameId(m.id,updatedItem.id));if(itemIndex>=0){M[itemIndex]=updatedItem;}else{M.push(updatedItem);}
  MOVS.push(mv);
  try{await addAudit('MOVE',`${item.name}: ${oldLocStr} → ${newLocStr} (qty: ${movQty})${reason?' | '+reason:''}`,item.barcode);}catch(e){console.error('Movement committed, but secondary audit sink failed',e);}
  clrMove();renderLocs();renderLocStock();renderMovHist();
  toast(`✅ ${item.name} moved to ${newLocStr}!`);
}

// ── Location CSV/XLS Export ──
function exportLocCSV(){
  if (typeof canRoleAction === 'function' && !canRoleAction('pdfExcelExport')) {toast('Permission denied: export', 'er'); return;}
  const header=['Location Code','Zone','Rack','Bin','Description','Capacity','Items Count','Total Stock'];
  const data=LOCS.map(l=>{
    const items=M.filter(m=>identifiersMatch(m.binLocationId,l.id)&&m.active!==false);
    return [locCode(l),l.zone,l.rack,l.bin,l.desc||'',l.capacity||'',items.length,items.reduce((sum,m)=>sum+(Number(m.stock)||0),0)];
  });
  const csv=[header,...data].map(r=>r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');
  // FIX #4: revoke object URL to prevent memory leak
  const _locCsvUrl=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
  const a=document.createElement('a');a.href=_locCsvUrl;
  a.download=`locations_${new Date().toISOString().slice(0,10)}.csv`;a.click();
  setTimeout(()=>URL.revokeObjectURL(_locCsvUrl),1000);
  toast('CSV downloaded');
}
function exportLocXLS(){
  if (typeof canRoleAction === 'function' && !canRoleAction('pdfExcelExport')) {toast('Permission denied: export', 'er'); return;}
  const header=['Location Code','Zone','Rack','Bin','Description','Capacity','Items Count','Total Stock'];
  const data=LOCS.map(l=>{
    const items=M.filter(m=>identifiersMatch(m.binLocationId,l.id)&&m.active!==false);
    return [locCode(l),l.zone,l.rack,l.bin,l.desc||'',l.capacity||0,items.length,items.reduce((sum,m)=>sum+(Number(m.stock)||0),0)];
  });
  const xmlRows=[header,...data].map(row=>`<Row>${row.map(c=>`<Cell><Data ss:Type="${typeof c==='number'?'Number':'String'}">${String(c).replace(/&/g,'&amp;').replace(/</g,'&lt;')}</Data></Cell>`).join('')}</Row>`).join('');
  const xml=`<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="Locations"><Table>${xmlRows}</Table></Worksheet></Workbook>`;
  // FIX #4: revoke object URL to prevent memory leak
  const _locXlsUrl=URL.createObjectURL(new Blob([xml],{type:'application/vnd.ms-excel'}));
  const a=document.createElement('a');a.href=_locXlsUrl;
  a.download=`locations_${new Date().toISOString().slice(0,10)}.xls`;a.click();
  setTimeout(()=>URL.revokeObjectURL(_locXlsUrl),1000);
  toast('Excel downloaded!');
}

function printLocReport(){
  if (typeof canRoleAction === 'function' && !canRoleAction('pdfExcelExport')) {toast('Permission denied: export', 'er'); return;}
  const co=CFG.company||'Your Company';
  const locationQuery=(document.getElementById('flt-loc-report')?.value||'').trim().toLowerCase();
  const rows=M.filter(m=>m.active!==false).map(m=>{
    const loc=LOCS.find(l=>identifiersMatch(l.id,m.binLocationId));
    return {...m,locStr:loc?locCode(loc):(m.location||'—'),locZone:loc?loc.zone:'—',locRack:loc?loc.rack:'—',locBin:loc?loc.bin:'—'};
  }).filter(m=>!locationQuery||String(m.locStr||'').toLowerCase().includes(locationQuery)||String(m.location||'').toLowerCase().includes(locationQuery)).sort((a,b)=>String(a.locStr||'').localeCompare(String(b.locStr||'')));
  const rowsHtml=rows.map((m,i)=>{
    const bg=i%2?'#f9fafb':'#fff';
    const clr=m.stock===0?'#dc2626':m.stock<m.lowAlert?'#d97706':'#111';
    return `<tr data-style="background:${bg}"><td data-style="border:1px solid #ddd;padding:4px 7px;font-family:monospace;background:#e0f2fe;font-weight:700">${sanitizeHTML(String(m.locStr||''))}</td><td data-style="border:1px solid #ddd;padding:4px 7px">${sanitizeHTML(String(m.locZone||''))}</td><td data-style="border:1px solid #ddd;padding:4px 7px">${sanitizeHTML(String(m.locRack||''))}</td><td data-style="border:1px solid #ddd;padding:4px 7px">${sanitizeHTML(String(m.locBin||''))}</td><td data-style="border:1px solid #ddd;padding:4px 7px;font-family:monospace;font-size:9pt">${sanitizeHTML(String(m.barcode||''))}</td><td data-style="border:1px solid #ddd;padding:4px 7px;font-weight:500">${sanitizeHTML(String(m.name||''))}</td><td data-style="border:1px solid #ddd;padding:4px 7px">${sanitizeHTML(String(m.unit||''))}</td><td data-style="border:1px solid #ddd;padding:4px 7px;text-align:center;font-weight:700;color:${clr}">${sanitizeHTML(String(m.stock??0))}</td></tr>`;
  }).join('');
  window.printPopupHtml(`<!DOCTYPE html><html><head><title>Location-wise Stock</title><style>body{font-family:Arial,sans-serif;font-size:10pt;margin:10mm}h1{font-size:14pt;margin:0}table{width:100%;border-collapse:collapse}th{background:#1e3a8a;color:#fff;padding:5px 7px;font-size:9pt}@media print{@page{margin:8mm}}</style></head><body>
    <div style="border-bottom:2px solid #1e3a8a;padding-bottom:8px;margin-bottom:12px"><h1>${sanitizeHTML(String(co))}</h1><p>Location-wise Stock Report · ${new Date().toLocaleString()}</p></div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px">
      <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="font-size:16pt">${LOCS.length}</b><br><small>Total Locations</small></div>
      <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="font-size:16pt;color:#1e40af">${M.filter(m=>m.binLocationId&&m.active!==false).length}</b><br><small>Items Assigned</small></div>
      <div style="border:1px solid #ddd;padding:8px;border-radius:4px;text-align:center"><b style="font-size:16pt;color:#dc2626">${M.filter(m=>!m.binLocationId&&m.active!==false).length}</b><br><small>Unassigned Items</small></div>
    </div>
    <table><thead><tr><th>Location</th><th>Zone</th><th>Rack</th><th>Bin</th><th>Barcode</th><th>Item Name</th><th>Unit</th><th style="text-align:center">Stock</th></tr></thead>
    <tbody>${rowsHtml||'<tr><td colspan="8" style="text-align:center;padding:16px;color:#999">No data</td></tr>'}</tbody></table>
    </body></html>`);
}

// ── Patch editMat to populate binloc select ──
function editMat(id){
  _editMatCore(id);
  const m=M.find(x=>x.id===id);
  setTimeout(()=>{
    popBinLocSel();
    const sel=document.getElementById('m-binloc');
    const bin=LOCS.find(l=>identifiersMatch(l.id,m?.binLocationId));
    if(sel&&bin) {sel.value=locCode(bin);}
  },50);
}


// ══════════════════════════════════════════════
// MATERIAL DETAIL PANEL
// ══════════════════════════════════════════════
let _mdpItem = null;

function openMatDetail(id){
  const m = M.find(x=>String(x.id)===String(id));
  if(!m){ toast('Material not found','er'); return; }
  _mdpItem = m;

  // Close search dropdown
  const drop = document.getElementById('gsdrop');
  if(drop){ drop.innerHTML=''; drop.style.display='none'; }
  const gs = document.getElementById('gsearch');
  if(gs) {gs.value='';}

  // ── Photo ──
  const ph = document.getElementById('mdp-photo');
  if(ph){
    if(m.photo) {ph.innerHTML=`<img src="${m.photo}" data-style="width:100%;height:100%;object-fit:cover">`;}
    else {ph.innerHTML='📦';}
  }

  // ── Name / Barcode ──
  document.getElementById('mdp-name').textContent = m.name;
  document.getElementById('mdp-barcode').textContent = `${m.barcode} · ${m.category} · HSN: ${m.hsn||'—'}`;

  // ── Stock ──
  const stk = document.getElementById('mdp-stock');
  stk.textContent = m.stock;
  stk.style.color = m.stock===0?'var(--rd)':m.stock<m.lowAlert?'var(--am)':'var(--gn)';
  document.getElementById('mdp-unit').textContent = m.unit;

  // ── Badges ──
  const badges = document.getElementById('mdp-badges');
  let bdg = '';
  if(m.stock===0)       {bdg += '<span class="bdg br" data-style="font-size:9px">Zero Stock</span>';}
  else if(m.stock<m.lowAlert) {bdg += '<span class="bdg ba" data-style="font-size:9px">Low Stock</span>';}
  else                  {bdg += '<span class="bdg bg" data-style="font-size:9px">In Stock</span>';}
  if(m.active===false)  {bdg += '<span class="bdg" data-style="font-size:9px;background:var(--bg3)">Inactive</span>';}
  if(m.specs&&m.specs.length) {bdg += '<span class="bdg bb" data-style="font-size:9px">'+m.specs.length+' Specs</span>';}
  badges.innerHTML = bdg;

  // ── Info Grid ──
  const grid = document.getElementById('mdp-info-grid');
  const infoItems = [
    { label:'Unit',          value: m.unit },
    { label:'Low Alert',     value: m.lowAlert+' '+m.unit },
    { label:'Suggested Order Qty',   value: (suggestedOrderQty(m))+' '+m.unit },
    { label:'Category',      value: m.category||'—' },
    { label:'HSN / Part No', value: m.hsn||'—' },
    { label:'Status',        value: m.active===false?'Inactive':'Active' },
    { label:'Created',       value: m.createdAt?new Date(m.createdAt).toLocaleDateString():'—' },
    { label:'Last Updated',  value: m.updatedAt?new Date(m.updatedAt).toLocaleString([],{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'—' },
    { label:'Opening Stock', value: m.openingStock!==undefined?m.openingStock:m.stock+' (current)' },
  ];
  grid.innerHTML = infoItems.map(i=>`
    <div data-style="background:var(--bg3);border:1px solid var(--b1);border-radius:var(--r);padding:8px 10px">
      <div data-style="font-size:9px;color:var(--tx3);font-weight:600;letter-spacing:.3px;text-transform:uppercase;margin-bottom:2px">${i.label}</div>
      <div data-style="font-size:12px;font-weight:600">${i.value}</div>
    </div>`).join('');

  // ── Location ──
  const loc = LOCS.find(l=>l.id===m.binLocationId);
  const locCard = document.getElementById('mdp-loc-card');
  if(loc||m.location){
    const locStr = loc?`${loc.zone} → ${loc.rack} → ${loc.bin}`:(m.location||'—');
    const locCode = loc?`${loc.zone}-${loc.rack}-${loc.bin}`:(m.location||'—');
    document.getElementById('mdp-loc').textContent = locCode;
    document.getElementById('mdp-loc-desc').textContent = loc?(loc.desc||`Zone: ${loc.zone} | Rack: ${loc.rack} | Bin: ${loc.bin}`):'Legacy location';
    if(locCard) {locCard.style.display='';}
  } else {
    if(locCard) {locCard.style.display='none';}
  }

  // ── Specs ──
  const specsCard = document.getElementById('mdp-specs-card');
  const specsEl   = document.getElementById('mdp-specs');
  if(m.specs&&m.specs.length&&specsCard&&specsEl){
    specsCard.style.display='';
    specsEl.innerHTML = m.specs.map(s=>`
      <div data-style="background:var(--bg3);border:1px solid var(--b1);border-radius:var(--r);padding:6px 10px">
        <div data-style="font-size:9px;color:var(--tx3);font-weight:600">${s.title||s.key||s.label||'—'}</div>
        <div data-style="font-size:11px;font-weight:500">${s.value||s.val||'—'}</div>
      </div>`).join('');
  } else if(specsCard){ specsCard.style.display='none'; }

  // ── 30-Day Activity ──
  const since30 = new Date(Date.now()-30*86400000);
  const matTxns = T.filter(t=>String(t.itemId)===String(m.id));
  const txns30  = matTxns.filter(t=>new Date(t.time)>=since30);
  const in30    = txns30.filter(t=>t.type==='IN').reduce((s,t)=>s+Number(t.qty||0),0);
  const out30   = txns30.filter(t=>t.type==='OUT'&&t.status==='confirmed').reduce((s,t)=>s+Number(t.qty||0),0);
  document.getElementById('mdp-30-in').textContent  = in30;
  document.getElementById('mdp-30-out').textContent = out30;
  document.getElementById('mdp-30-txn').textContent = txns30.length;

  // Last movement
  const lastTx = matTxns.slice().sort((a,b)=>new Date(b.time)-new Date(a.time))[0];
  const lastEl = document.getElementById('mdp-last-mv');
  if(lastTx&&lastEl){
    const d = new Date(lastTx.time);
    const diff = Date.now()-d;
    const days = Math.floor(diff/86400000);
    lastEl.style.fontSize='12px';
    lastEl.textContent = days===0?'Today':days===1?'Yesterday':days+'d ago';
    lastEl.style.color = days===0?'var(--gn)':days<=3?'var(--bl)':'var(--tx2)';
  } else if(lastEl){ lastEl.textContent='—'; }

  // ── Mini Bar Chart (last 14 days IN vs OUT) ──
  const canvas = document.getElementById('mdp-chart');
  if(canvas){
    canvas.width = canvas.offsetWidth||700;
    canvas.height=70;
    const ctx=canvas.getContext('2d');
    ctx.clearRect(0,0,canvas.width,canvas.height);
    const days14=[...Array(14)].map((_,i)=>{
      const d=new Date(); d.setDate(d.getDate()-13+i);
      const ds=d.toDateString();
      const dayTxns=matTxns.filter(t=>new Date(t.time).toDateString()===ds);
      return {
        label:d.toLocaleDateString([],{day:'2-digit',month:'short'}),
        inQ:dayTxns.filter(t=>t.type==='IN').reduce((s,t)=>s+Number(t.qty||0),0),
        outQ:dayTxns.filter(t=>t.type==='OUT').reduce((s,t)=>s+Number(t.qty||0),0),
      };
    });
    const maxV=Math.max(1,...days14.map(d=>Math.max(d.inQ,d.outQ)));
    const barW=Math.floor((canvas.width-40)/(14*2+15));
    const chartH=50;const pad={l:30,t:5};
    // Axis
    ctx.strokeStyle='#374151';ctx.lineWidth=0.5;
    ctx.beginPath();ctx.moveTo(pad.l,pad.t);ctx.lineTo(pad.l,pad.t+chartH);ctx.lineTo(canvas.width-5,pad.t+chartH);ctx.stroke();
    days14.forEach((d,i)=>{
      const x=pad.l+5+i*(barW*2+3);
      // IN bar (green)
      if(d.inQ>0){
        const h=(d.inQ/maxV)*chartH;
        ctx.fillStyle='#10b981';
        ctx.fillRect(x,pad.t+chartH-h,barW,h);
      }
      // OUT bar (red)
      if(d.outQ>0){
        const h=(d.outQ/maxV)*chartH;
        ctx.fillStyle='#ef4444';
        ctx.fillRect(x+barW+1,pad.t+chartH-h,barW,h);
      }
      // Day label every 3rd
      if(i%3===0||i===13){
        ctx.fillStyle='#9ca3af';ctx.font='8px sans-serif';ctx.textAlign='center';
        ctx.fillText(d.label,x+barW,pad.t+chartH+10);
      }
    });
    // Legend
    ctx.fillStyle='#10b981';ctx.fillRect(canvas.width-80,4,10,8);
    ctx.fillStyle='#9ca3af';ctx.font='8px sans-serif';ctx.textAlign='left';ctx.fillText('IN',canvas.width-68,11);
    ctx.fillStyle='#ef4444';ctx.fillRect(canvas.width-55,4,10,8);
    ctx.fillText('OUT',canvas.width-43,11);
  }

  // ── Recent Transactions ──
  const tb = document.getElementById('mdp-txn-body');
  if(tb){
    const recent = matTxns.slice().sort((a,b)=>new Date(b.time)-new Date(a.time)).slice(0,15);
    tb.innerHTML = recent.length?recent.map(t=>{
      const isIn=t.type==='IN';
      return `<tr>
        <td data-style="font-size:10px;font-family:var(--mn)">${new Date(t.time).toLocaleString([],{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}</td>
        <td data-style="font-size:10px"><span class="bdg" data-style="font-size:9px;background:var(--bg3)">${t.shiftLabel||'—'}</span></td>
        <td><span class="bdg ${isIn?'bg':'br'}" data-style="font-size:9px">${t.type}</span></td>
        <td data-style="font-weight:700;font-family:var(--mn);color:${isIn?'var(--gn)':'var(--rd)'}">${isIn?'+':'-'}${t.qty}</td>
        <td data-style="font-size:10px;color:var(--tx3)">${sanitizeHTML(String(t.deptName||t.supplierName||'—'))}</td>
        <td data-style="font-size:10px">${t.person||'—'}</td>
        <td data-style="font-size:10px;color:var(--tx3)">${t.userName||t.user}</td>
      </tr>`;
    }).join(''):'<tr><td colspan="7" data-style="text-align:center;padding:12px;color:var(--tx3)">No transactions yet</td></tr>';
  }

  document.getElementById('mat-detail-ov').classList.add('on');
}

function closeMatDetail(){
  document.getElementById('mat-detail-ov').classList.remove('on');
  _mdpItem=null;
}

function quickInFromDetail(){
  if(!_mdpItem) {return;}
  const item=_mdpItem;
  closeMatDetail();
  nav('in');
  setTimeout(()=>{
    inI=item;
    document.getElementById('in-nm').textContent=item.name;
    document.getElementById('in-dt').textContent=item.barcode+' · '+item.category+' · '+item.unit;
    document.getElementById('in-cs').textContent=item.stock+' '+item.unit;
    document.getElementById('in-bc').value=item.barcode;
    document.getElementById('in-sb').className='scan-box ok';
    document.getElementById('in-fb').classList.add('on');
    document.getElementById('in-st').textContent='✓ '+item.name;
    openInQtyPopup(item);
  },150);
}

function quickOutFromDetail(){
  if(!_mdpItem) {return;}
  const item=_mdpItem;
  closeMatDetail();
  nav('out');
  setTimeout(()=>{
    outI=item;
    document.getElementById('out-nm').textContent=item.name;
    document.getElementById('out-dt').textContent=item.barcode+' · '+item.category+' · '+item.unit;
    document.getElementById('out-cs').textContent=item.stock+' '+item.unit;
    document.getElementById('out-bc').value=item.barcode;
    document.getElementById('out-sb').className='scan-box ok';
    document.getElementById('out-fb').classList.add('on');
    document.getElementById('out-st').textContent='✓ '+item.name;
    openOutQtyPopup(item);
  },150);
}

function editMatFromDetail(){
  if(!_mdpItem) {return;}
  const id=_mdpItem.id;
  closeMatDetail();
  nav('master');
  setTimeout(()=>editMat(id),150);
}

function printMatCard(){
  const m=_mdpItem; if(!m) {return;}
  const loc=LOCS.find(l=>identifiersMatch(l.id,m.binLocationId));
  const locStr=loc?`${loc.zone}-${loc.rack}-${loc.bin}`:(m.location||'—');
  const co=CFG.company||'Your Company';
  const since30=new Date(Date.now()-30*86400000);
  const matTxns=T.filter(t=>String(t.itemId)===String(m.id));
  const txns30=matTxns.filter(t=>new Date(t.time)>=since30);
  const in30=txns30.filter(t=>t.type==='IN').reduce((s,t)=>s+Number(t.qty||0),0);
  const out30=txns30.filter(t=>t.type==='OUT').reduce((s,t)=>s+Number(t.qty||0),0);
  const recent=matTxns.slice().sort((a,b)=>new Date(b.time)-new Date(a.time)).slice(0,10);
  const txnRows=recent.map((t,i)=>{
    const isIn=t.type==='IN';
    return `<tr data-style="background:${i%2?'#f9fafb':'#fff'}"><td data-style="border:1px solid #ddd;padding:4px 7px">${new Date(t.time).toLocaleString([],{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}</td><td data-style="border:1px solid #ddd;padding:4px 7px">${t.shiftName||'—'}</td><td data-style="border:1px solid #ddd;padding:4px 7px;color:${isIn?'#16a34a':'#dc2626'};font-weight:700">${t.type}</td><td data-style="border:1px solid #ddd;padding:4px 7px;text-align:center;font-weight:700;color:${isIn?'#16a34a':'#dc2626'}">${isIn?'+':'-'}${t.qty} ${m.unit}</td><td data-style="border:1px solid #ddd;padding:4px 7px">${sanitizeHTML(String(t.deptName||t.supplierName||'—'))}</td><td data-style="border:1px solid #ddd;padding:4px 7px">${t.userName||t.user}</td></tr>`;
  }).join('');
  const specsHtml=m.specs&&m.specs.length?m.specs.map(s=>`<tr><td data-style="border:1px solid #ddd;padding:4px 8px;font-weight:600">${s.title||s.key||s.label||'—'}</td><td data-style="border:1px solid #ddd;padding:4px 8px">${s.value||s.val||'—'}</td></tr>`).join(''):'';
  window.printPopupHtml(`<!DOCTYPE html><html><head><title>Material Card — ${m.name}</title>
  <style>body{font-family:Arial,sans-serif;font-size:10pt;margin:10mm}h1{font-size:14pt;margin:0}table{width:100%;border-collapse:collapse;margin-bottom:10px}th{background:#1e3a8a;color:#fff;padding:5px 8px;font-size:9pt;text-align:left}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px}.card{border:1px solid #ddd;border-radius:4px;padding:8px;text-align:center}.cv{font-size:16pt;font-weight:700}.cl{font-size:8pt;color:#666}@media print{@page{margin:8mm}}</style>
  </head><body>
  <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #1e3a8a;padding-bottom:10px;margin-bottom:14px">
    <div>
      <h1>${m.name}</h1>
      <p style="margin:3px 0;color:#555;font-family:monospace;font-size:11pt">${m.barcode}</p>
      <p style="margin:2px 0;color:#666;font-size:9pt">${m.category} · ${m.unit} · HSN: ${m.hsn||'—'}</p>
    </div>
    ${m.photo?`<img src="${m.photo}" style="width:70px;height:70px;object-fit:cover;border-radius:6px;border:1px solid #ddd">`:''}
  </div>
  <div class="grid">
    <div class="card"><div class="cv" data-style="color:${m.stock===0?'#dc2626':m.stock<m.lowAlert?'#d97706':'#16a34a'}">${m.stock}</div><div class="cl">Current Stock</div></div>
    <div class="card"><div class="cv" data-style="color:#1e40af">${m.lowAlert}</div><div class="cl">Low Alert</div></div>
    <div class="card"><div class="cv" data-style="color:#16a34a">${in30}</div><div class="cl">IN (30 days)</div></div>
    <div class="card"><div class="cv" data-style="color:#dc2626">${out30}</div><div class="cl">OUT (30 days)</div></div>
  </div>
  <table><thead><tr><th>Field</th><th>Value</th></tr></thead><tbody>
    <tr><td data-style="border:1px solid #ddd;padding:4px 8px">Location</td><td data-style="border:1px solid #ddd;padding:4px 8px;font-weight:700;color:#1e40af">${locStr}</td></tr>
    <tr data-style="background:#f9fafb"><td data-style="border:1px solid #ddd;padding:4px 8px">Suggested Order Qty</td><td data-style="border:1px solid #ddd;padding:4px 8px">${suggestedOrderQty(m)} ${m.unit}</td></tr>
    <tr><td data-style="border:1px solid #ddd;padding:4px 8px">Status</td><td data-style="border:1px solid #ddd;padding:4px 8px">${m.active===false?'Inactive':'Active'}</td></tr>
    <tr data-style="background:#f9fafb"><td data-style="border:1px solid #ddd;padding:4px 8px">Last Updated</td><td data-style="border:1px solid #ddd;padding:4px 8px">${m.updatedAt?new Date(m.updatedAt).toLocaleString():'-'}</td></tr>
  </tbody></table>
  ${specsHtml?`<h3 data-style="font-size:11pt;margin:10px 0 6px">Specifications</h3><table><thead><tr><th>Property</th><th>Value</th></tr></thead><tbody>${specsHtml}</tbody></table>`:''}
  <h3 data-style="font-size:11pt;margin:10px 0 6px">Recent Transactions (last 10)</h3>
  <table><thead><tr><th>Date/Time</th><th>Shift</th><th>Type</th><th>Qty</th><th>Department</th><th>By</th></tr></thead>
  <tbody>${txnRows||'<tr><td colspan="6" data-style="text-align:center;padding:10px;color:#999">No transactions</td></tr>'}</tbody></table>
  <div data-style="margin-top:16px;border-top:1px solid #ddd;padding-top:8px;font-size:8pt;color:#999;display:flex;justify-content:space-between">
    <span>${co} · Material Card</span><span>Printed: ${new Date().toLocaleString()}</span>
  </div>
  </body></html>`);
}


// ══════════════════════════════════════════════
// MATERIAL DETAIL PANEL
// ══════════════════════════════════════════════
let _mdItem = null;

function openMaterialDetail(id){
  const m = M.find(x=>String(x.id)===String(id));
  if(!m){toast('Item not found','er');return;}
  _mdItem = m;
  // Close search dropdown
  document.getElementById('gsdrop').style.display='none';
  document.getElementById('gsearch').value='';

  // Photo
  const ph = document.getElementById('md-photo');
  if(m.photo) {ph.innerHTML=`<img src="${m.photo}" data-style="width:56px;height:56px;object-fit:cover;border-radius:8px">`;}
  else {ph.innerHTML='📦';}

  // Name / category
  document.getElementById('md-name').textContent = m.name;
  document.getElementById('md-cat').textContent = `${m.category} · ${m.barcode}`;

  // Stock
  const stockEl = document.getElementById('md-stock');
  stockEl.textContent = m.stock;
  stockEl.style.color = m.stock===0?'var(--rd)':m.stock<m.lowAlert?'var(--am)':'var(--bl)';
  document.getElementById('md-unit').textContent = m.unit;

  // Status badges
  const badges = [];
  if(m.stock===0) {badges.push('<span class="bdg br">Zero Stock</span>');}
  else if(m.stock<m.lowAlert) {badges.push('<span class="bdg ba">Low Stock</span>');}
  else {badges.push('<span class="bdg bg">In Stock</span>');}
  if(m.active===false) {badges.push('<span class="bdg" data-style="background:var(--bg3)">Inactive</span>');}
  document.getElementById('md-badges').innerHTML = badges.join('');

  document.getElementById('md-stock-status').innerHTML =
    m.stock<m.lowAlert ? `<span data-style="color:var(--am)">Alert: ${m.lowAlert} ${m.unit}</span>` :
    `<span data-style="color:var(--tx3)">Alert: ${m.lowAlert} ${m.unit}</span>`;

  // Default to info tab
  mdTab('info');
  document.getElementById('mat-detail-tabs-ov').classList.add('on');
}

function closeMaterialDetail(){
  document.getElementById('mat-detail-tabs-ov').classList.remove('on');
  _mdItem = null;
}

function mdTab(tab){
  ['info','txn','loc','spec'].forEach(t=>{
    const btn = document.getElementById('md-tab-'+t);
    const panel = document.getElementById('md-panel-'+t);
    const active = t===tab;
    if(btn){ btn.style.borderBottomColor=active?'var(--bl)':'transparent'; btn.style.color=active?'var(--bl)':'var(--tx2)'; }
    if(panel) {panel.style.display = active?'':'none';}
  });
  if(tab==='info') {renderMdInfo();}
  if(tab==='txn')  {renderMdTxns();}
  if(tab==='loc')  {renderMdLoc();}
  if(tab==='spec') {renderMdSpec();}
}

function renderMdInfo(){
  const m = _mdItem; if(!m) {return;}
  const loc = LOCS.find(l=>l.id===m.binLocationId);
  const locStr = loc?`${loc.zone} → ${loc.rack} → ${loc.bin}`:(m.location||'—');
  const lastTxn = T.filter(t=>t.itemId===m.id).sort((a,b)=>new Date(b.time)-new Date(a.time))[0];
  const totalIn  = T.filter(t=>t.itemId===m.id&&t.type==='IN').reduce((s,t)=>s+Number(t.qty||0),0);
  const totalOut = T.filter(t=>t.itemId===m.id&&t.type==='OUT'&&t.status==='confirmed').reduce((s,t)=>s+Number(t.qty||0),0);

  const fields = [
    ['Barcode / Part No.', `<span data-style="font-family:var(--mn);font-weight:700;font-size:13px">${m.barcode}</span>`],
    ['Item Name', m.name],
    ['Category', m.category||'—'],
    ['Unit', m.unit],
    ['Current Stock', `<span data-style="font-weight:700;font-size:15px;color:${m.stock<m.lowAlert?'var(--am)':'var(--gn)'}">${m.stock} ${m.unit}</span>`],
    ['Low Stock Alert', `${m.lowAlert} ${m.unit}`],
    ['Suggested Order Qty', `${suggestedOrderQty(m)} ${m.unit}`],
    ['HSN / Part No.', m.hsn||'—'],
    ['Bin Location', `<span data-style="font-weight:600;color:var(--bl)">${sanitizeHTML(String(locStr||""))}</span>`],
    ['Total IN (all time)', `<span data-style="color:var(--gn);font-weight:700">${totalIn} ${m.unit}</span>`],
    ['Total OUT (all time)', `<span data-style="color:var(--rd);font-weight:700">${totalOut} ${m.unit}</span>`],
    ['Last Transaction', lastTxn?`${lastTxn.type} · ${lastTxn.qty} ${m.unit} · ${new Date(lastTxn.time).toLocaleString([],{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}`:'—'],
    ['Added On', m.createdAt?new Date(m.createdAt).toLocaleDateString([],{day:'2-digit',month:'short',year:'numeric'}):'—'],
    ['Last Updated', m.updatedAt?new Date(m.updatedAt).toLocaleString([],{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'—'],
    ['Status', m.active===false?'<span class="bdg br">Inactive</span>':'<span class="bdg bg">Active</span>'],
  ];
  document.getElementById('md-info-grid').innerHTML = fields.map(([label,val])=>`
    <div data-style="padding:8px 10px;background:var(--bg3);border-radius:6px;border:1px solid var(--b1)">
      <div data-style="font-size:9px;color:var(--tx3);font-weight:600;letter-spacing:.4px;text-transform:uppercase;margin-bottom:3px">${label}</div>
      <div data-style="font-size:12px">${val}</div>
    </div>`).join('');
}

function renderMdTxns(){
  const m = _mdItem; if(!m) {return;}
  const filter = document.getElementById('md-txn-filter')?.value||'all';
  let txns = T.filter(t=>t.itemId===m.id);
  if(filter==='IN')  {txns=txns.filter(t=>t.type==='IN');}
  if(filter==='OUT') {txns=txns.filter(t=>t.type==='OUT');}
  txns.sort((a,b)=>new Date(b.time)-new Date(a.time));
  document.getElementById('md-txn-count').textContent = `${txns.length} transactions`;
  const allTxns = T.filter(t=>t.itemId===m.id);
  const totIn  = allTxns.filter(t=>t.type==='IN').reduce((s,t)=>s+Number(t.qty||0),0);
  const totOut = allTxns.filter(t=>t.type==='OUT'&&t.status==='confirmed').reduce((s,t)=>s+Number(t.qty||0),0);
  document.getElementById('md-txn-summary').innerHTML = `
    <div data-style="padding:8px;background:var(--bg3);border-radius:6px;text-align:center;border:1px solid var(--b1)">
      <div data-style="font-size:18px;font-weight:700;color:var(--gn)">${totIn}</div><div data-style="font-size:9px;color:var(--tx3)">Total IN</div>
    </div>
    <div data-style="padding:8px;background:var(--bg3);border-radius:6px;text-align:center;border:1px solid var(--b1)">
      <div data-style="font-size:18px;font-weight:700;color:var(--rd)">${totOut}</div><div data-style="font-size:9px;color:var(--tx3)">Total OUT</div>
    </div>
    <div data-style="padding:8px;background:var(--bg3);border-radius:6px;text-align:center;border:1px solid var(--b1)">
      <div data-style="font-size:18px;font-weight:700;color:var(--bl)">${allTxns.length}</div><div data-style="font-size:9px;color:var(--tx3)">Total Transactions</div>
    </div>`;
  const tb = document.getElementById('md-txn-body');
  tb.innerHTML = txns.length ? txns.map(t=>{
    const isIn = t.type==='IN';
    return `<tr>
      <td data-style="font-size:10px">${new Date(t.time).toLocaleString([],{day:'2-digit',month:'short',year:'2-digit',hour:'2-digit',minute:'2-digit'})}</td>
      <td data-style="font-size:10px">${t.shiftLabel||'—'}</td>
      <td><span class="bdg ${isIn?'bg':'br'}" data-style="font-size:9px">${t.type}</span></td>
      <td data-style="font-family:var(--mn);font-weight:700;text-align:center;color:${isIn?'var(--gn)':'var(--rd)'}">${isIn?'+':'-'}${t.qty}</td>
      <td data-style="font-size:10px">${sanitizeHTML(String(t.deptName||t.supplierName||'—'))}</td>
      <td data-style="font-size:10px">${t.person||'—'}</td>
      <td data-style="font-size:10px;color:var(--tx3)">${t.userName||t.user}</td>
    </tr>`;
  }).join('') : '<tr><td colspan="7" data-style="text-align:center;padding:16px;color:var(--tx3)">No transactions</td></tr>';
}

function renderMdLoc(){
  const m = _mdItem; if(!m) {return;}
  const loc = LOCS.find(l=>l.id===m.binLocationId);
  const locInfo = document.getElementById('md-loc-info');
  if(loc){
    const others = M.filter(x=>identifiersMatch(x.binLocationId,loc.id)&&x.active!==false&&!identifiersMatch(x.id,m.id));
    locInfo.innerHTML = `
      <div data-style="background:var(--bg3);border:1px solid var(--b1);border-radius:8px;padding:12px 14px">
        <div data-style="font-size:10px;color:var(--tx3);font-weight:600;margin-bottom:6px">ASSIGNED LOCATION</div>
        <div data-style="font-size:22px;font-weight:800;font-family:var(--mn);color:var(--bl)">${loc.zone} → ${loc.rack} → ${loc.bin}</div>
        ${loc.desc?`<div data-style="font-size:11px;color:var(--tx3);margin-top:4px">${loc.desc}</div>`:''}
        ${loc.capacity?`<div data-style="font-size:11px;margin-top:4px">Capacity: <strong>${loc.capacity}</strong></div>`:''}
      </div>
      ${others.length?`<div data-style="margin-top:10px"><div data-style="font-size:10px;font-weight:600;color:var(--tx3);margin-bottom:6px">OTHER ITEMS IN THIS LOCATION</div>
      ${others.map(x=>`<div data-style="display:flex;align-items:center;gap:8px;padding:5px 8px;background:var(--bg3);border-radius:4px;margin-bottom:4px;font-size:11px"><span data-style="font-family:var(--mn)">${x.barcode}</span><span data-style="flex:1">${x.name}</span><strong>${x.stock} ${x.unit}</strong></div>`).join('')}</div>`:''}`;
  } else {
    locInfo.innerHTML = `<div data-style="text-align:center;padding:24px;color:var(--tx3)">
      <div data-style="font-size:32px;margin-bottom:8px">📍</div>
      <div data-style="font-weight:600">No bin location assigned</div>
      <div data-style="font-size:11px;margin-top:4px">Go to Bin Locations → assign a location to this item</div>
      ${m.location?`<div data-style="margin-top:8px;font-size:11px;background:var(--bg3);padding:6px 10px;border-radius:4px">Legacy location: <strong>${m.location}</strong></div>`:''}
    </div>`;
  }
  // Movement history for this item
  const movs = MOVS.filter(mv=>mv.itemId===m.id).sort((a,b)=>new Date(b.time)-new Date(a.time));
  const movHist = document.getElementById('md-mov-hist');
  if(movs.length){
    movHist.innerHTML = `<div data-style="font-size:10px;font-weight:600;color:var(--tx3);margin-bottom:6px">MOVEMENT HISTORY</div>
      <div class="tw"><table data-style="width:100%"><thead><tr><th>Date</th><th>From</th><th>To</th><th>Reason</th></tr></thead><tbody>
      ${movs.map(mv=>`<tr><td data-style="font-size:10px">${new Date(mv.time).toLocaleDateString()}</td><td data-style="font-family:var(--mn);font-size:10px">${mv.fromLoc}</td><td data-style="font-family:var(--mn);font-size:10px;color:var(--bl)">${mv.toLoc}</td><td data-style="font-size:10px;color:var(--tx3)">${mv.reason||'—'}</td></tr>`).join('')}
      </tbody></table></div>`;
  } else {
    movHist.innerHTML = '';
  }
}

function renderMdSpec(){
  const m = _mdItem; if(!m) {return;}
  const specs = document.getElementById('md-specs-list');
  if(m.specs&&m.specs.length){
    specs.innerHTML = `<div data-style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      ${m.specs.map(s=>`<div data-style="padding:8px 10px;background:var(--bg3);border-radius:6px;border:1px solid var(--b1)">
        <div data-style="font-size:9px;color:var(--tx3);font-weight:600;text-transform:uppercase;margin-bottom:3px">${s.title||s.key||s.label||'—'}</div>
        <div data-style="font-size:12px;font-weight:500">${s.value||s.val||'—'}</div>
      </div>`).join('')}
    </div>`;
  } else {
    specs.innerHTML = '<div data-style="text-align:center;padding:24px;color:var(--tx3)">No extra specifications defined</div>';
  }
}

function mdGoEdit(){
  if(!_mdItem) {return;}
  const id=_mdItem.id;
  closeMaterialDetail();
  nav('master');
  setTimeout(()=>editMat(id), 200);
}
function mdGoIn(){
  if(!_mdItem) {return;}
  const barcode=_mdItem.barcode;
  closeMaterialDetail();
  nav('in');
  setTimeout(()=>{
    document.getElementById('in-bc').value=barcode;
    handleScan('in',{key:'Enter'});
  }, 200);
}
function mdGoOut(){
  if(!_mdItem) {return;}
  const barcode=_mdItem.barcode;
  closeMaterialDetail();
  nav('out');
  setTimeout(()=>{
    document.getElementById('out-bc').value=barcode;
    handleScan('out',{key:'Enter'});
  }, 200);
}

function printMaterialCard(){
  const m = _mdItem; if(!m) {return;}
  const loc = LOCS.find(l=>l.id===m.binLocationId);
  const locStr = loc?`${loc.zone} → ${loc.rack} → ${loc.bin}`:(m.location||'—');
  const allTxns = T.filter(t=>t.itemId===m.id);
  const totIn  = allTxns.filter(t=>t.type==='IN').reduce((s,t)=>s+Number(t.qty||0),0);
  const totOut = allTxns.filter(t=>t.type==='OUT'&&t.status==='confirmed').reduce((s,t)=>s+Number(t.qty||0),0);
  const recent = allTxns.sort((a,b)=>new Date(b.time)-new Date(a.time)).slice(0,10);
  const co = CFG.company||'Your Company';
  window.printPopupHtml(`<!DOCTYPE html><html><head><title>${m.name} — Material Card</title>
  <style>body{font-family:Arial,sans-serif;font-size:10pt;margin:10mm}table{width:100%;border-collapse:collapse}th{background:#1e3a8a;color:#fff;padding:5px 8px;font-size:9pt}td{border:1px solid #ddd;padding:5px 8px}@media print{@page{margin:8mm}}</style>
  </head><body>
  <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #1e3a8a;padding-bottom:10px;margin-bottom:14px">
    <div>
      <h1 style="font-size:16pt;margin:0">${m.name}</h1>
      <p style="margin:3px 0;color:#555">${co} · Material Card</p>
    </div>
    ${m.photo?`<img src="${m.photo}" style="width:70px;height:70px;object-fit:cover;border-radius:6px;border:1px solid #ddd">`:''}
  </div>
  <div data-style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px">
    <div data-style="border:1px solid #ddd;padding:8px;border-radius:4px"><small data-style="color:#666">Barcode</small><br><b data-style="font-family:monospace;font-size:13pt">${m.barcode}</b></div>
    <div data-style="border:1px solid #ddd;padding:8px;border-radius:4px"><small data-style="color:#666">Category</small><br><b>${m.category}</b></div>
    <div data-style="border:1px solid #ddd;padding:8px;border-radius:4px"><small data-style="color:#666">Current Stock</small><br><b data-style="font-size:16pt;color:${m.stock<m.lowAlert?'#dc2626':'#16a34a'}">${m.stock} ${m.unit}</b></div>
    <div data-style="border:1px solid #ddd;padding:8px;border-radius:4px"><small data-style="color:#666">Bin Location</small><br><b data-style="color:#1e40af">${locStr}</b></div>
    <div data-style="border:1px solid #ddd;padding:8px;border-radius:4px"><small data-style="color:#666">Total IN</small><br><b data-style="color:#16a34a">${totIn} ${m.unit}</b></div>
    <div data-style="border:1px solid #ddd;padding:8px;border-radius:4px"><small data-style="color:#666">Total OUT</small><br><b data-style="color:#dc2626">${totOut} ${m.unit}</b></div>
    ${m.hsn?`<div data-style="border:1px solid #ddd;padding:8px;border-radius:4px"><small data-style="color:#666">HSN / Part No.</small><br><b>${m.hsn}</b></div>`:''}
    <div data-style="border:1px solid #ddd;padding:8px;border-radius:4px"><small data-style="color:#666">Suggested Order Qty</small><br><b>${suggestedOrderQty(m)} ${m.unit}</b></div>
  </div>
  ${m.specs&&m.specs.length?`<h3 data-style="font-size:11pt;margin:12px 0 6px">Specifications</h3>
  <div data-style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:14px">
  ${m.specs.map(s=>`<div data-style="border:1px solid #ddd;padding:6px 8px;border-radius:3px"><small data-style="color:#666">${s.title||s.key||s.label||'—'}</small><br><b>${s.value||s.val||'—'}</b></div>`).join('')}
  </div>`:''}
  <h3 data-style="font-size:11pt;margin:12px 0 6px">Recent Transactions (last 10)</h3>
  <table><thead><tr><th>Date/Time</th><th>Shift</th><th>Type</th><th>Qty</th><th>Dept/Supplier</th><th>By</th></tr></thead>
  <tbody>${recent.map((t,i)=>{const bg=i%2?'#f9fafb':'#fff';const isIn=t.type==='IN';return `<tr data-style="background:${bg}"><td>${new Date(t.time).toLocaleString([],{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}</td><td>${t.shiftLabel||'—'}</td><td data-style="color:${isIn?'#16a34a':'#dc2626'};font-weight:700">${t.type}</td><td data-style="text-align:center;font-weight:700;color:${isIn?'#16a34a':'#dc2626'}">${isIn?'+':'-'}${t.qty}</td><td>${sanitizeHTML(String(t.deptName||t.supplierName||'—'))}</td><td>${t.userName||t.user}</td></tr>`}).join('')}</tbody></table>
  <div data-style="margin-top:20px;border-top:1px solid #ddd;padding-top:8px;font-size:8pt;color:#888">Generated: ${new Date().toLocaleString()} · ${co}</div>
  </body></html>`);
}

// ── Clock & Init ──
initDB().then(async()=>{
  // Recover an interrupted restore before encryption settings, authentication,
  // or renderer caches read a partially restored database.
  if (window.recoverInterruptedStoreTrackRestore) { await window.recoverInterruptedStoreTrackRestore(); }
  // Initialize infrastructure modules only after IndexedDB is ready.
  if (window.AuditTrail?.init) await window.AuditTrail.init();
  if (window.DataEncryption?.init) await window.DataEncryption.init();
  if (window.TwoFactorAuth?.init) await window.TwoFactorAuth.init();
  if (window.AutomatedAlerts?.init) await window.AutomatedAlerts.init();
  await loadAll();await seedData();popLocSelects();updateBadges();applyWidgets();addXlsButtons();startShiftMonitor();
  document.getElementById('idb-st').textContent='IndexedDB — Connected ('+DB+')';
  // Initialize PM module after DB is ready
  await pmLoadData(); if (typeof pmRenderList === 'function') { pmRenderList(); pmRenderPersonGroups(); }
  // Defensive refresh: componentManagement also listens for databaseReady;
  // this guarded call covers startup ordering differences in packaged Electron builds.
  if (typeof window.componentManagementInit === 'function') { await window.componentManagementInit(); }
  if (typeof window.startStoreTrackDailyBackup === 'function') { window.startStoreTrackDailyBackup(); }
}).catch(err=>{
  document.getElementById('idb-dot').style.background='var(--rd)';
  document.getElementById('idb-st').textContent='DB Error: '+err.message;
  document.getElementById('db-badge').textContent='● DB Error';
  document.getElementById('db-badge').className='bdg br';
});
// updateBadges is defined earlier and handles all badge updates

function updateTopLowBadge(count){
  const top=document.getElementById('top-low-count');
  if(!top){return;}
  const n=Number(count)||0;
  top.textContent=n;
  top.style.display=n?'':'none';
}

function updateTopbarClock(){
  const el=document.getElementById('clk');
  if(!el){return;}
  const d=new Date();
  const day=String(d.getDate()).padStart(2,'0');
  const mon=d.toLocaleString('en-US',{month:'short'});
  const yr=d.getFullYear();
  let hr=d.getHours();
  const ampm=hr>=12?'pm':'am';
  hr=hr%12||12;
  const min=String(d.getMinutes()).padStart(2,'0');
  const sec=String(d.getSeconds()).padStart(2,'0');
  el.textContent=`${day} ${mon} ${yr}  ${String(hr).padStart(2,'0')}:${min}:${sec} ${ampm}`;
}
updateTopbarClock();
setInterval(updateTopbarClock,1000);

function openDbPasswordReset(){
  ['dbpw-admin','dbpw-new','dbpw-cnf'].forEach(id=>{const el=document.getElementById(id);if(el){el.value='';}});
  document.getElementById('dbpwreset-ov').classList.add('on');
  setTimeout(()=>document.getElementById('dbpw-admin').focus(),100);
}

async function resetDbPassword(){
  if(!cu){toast('Please login first','er');return;}
  if(cu.role!=='admin'){toast('DB password reset is allowed only from Admin login','er');return;}
  const adminPw=document.getElementById('dbpw-admin').value;
  const nw=document.getElementById('dbpw-new').value;
  const cnf=document.getElementById('dbpw-cnf').value;
  if(!adminPw||!nw||!cnf){toast('Admin password, new DB password, and confirmation are required','er');return;}
  let adminOk=false;
  for(const u of U.filter(x=>x.role==='admin'&&x.active!==false)){
    if(u.passwordHash&&await verifyPassword(adminPw,u.passwordHash)){adminOk=true;break;}
    if(u.password&&u.password===adminPw){adminOk=true;break;}
  }
  if(!adminOk){toast('Admin password is incorrect','er');return;}
  if(!passStrong(nw)){toast('DB password must be at least 6 characters and include a letter and a number','er');return;}
  if(nw!==cnf){toast('DB password and confirmation do not match','er');return;}
  CFG.id=1;CFG.dbPasswordHash=await hashPassword(nw);delete CFG.dbPassword;CFG.dbPasswordUpdatedAt=new Date().toISOString();CFG.dbPasswordUpdatedBy=cu.username;
  await dPut('config',CFG);
  document.getElementById('dbpwreset-ov').classList.remove('on');
  addAudit('SYSTEM','Admin reset database password','SYSTEM');
  toast('Database password reset successfully!');
}


async function changePassword(){
  if(!cu){toast('Please login first','er');return;}
  const cur=document.getElementById('cp-cur').value;
  const nw=document.getElementById('cp-new').value;
  const cnf=document.getElementById('cp-cnf').value;
  if(!cur||!nw||!cnf){toast('Current password, new password, and confirmation are required','er');return;}
  const curOk=(cu.passwordHash&&await verifyPassword(cur,cu.passwordHash))||(cu.password&&_safeCompare(cu.password,cur));
  if(!curOk){toast('Current password is incorrect','er');return;}
  if(!window.passStrong(nw)){toast('New password must be at least 6 characters and include a letter and a number','er');return;}
  if(nw!==cnf){toast('New password and confirmation do not match','er');return;}
  if(window.passwordPolicy&&window.passwordPolicy.isInHistory(cu.id,nw)){toast('You already used this password recently — please choose a different one','er');return;}
  const u=U.find(x=>x.id===cu.id)||U.find(x=>x.username===cu.username);
  if(!u){toast('User not found','er');return;}
  u.passwordHash=await hashPassword(nw);delete u.password;u.mustChangePassword=false;u.updatedAt=new Date().toISOString();
  await dPut('users',u);
  U=await gAll('users');cu=u;passwordChangeRequired=false;applyRolePermissions();
  if(window.passwordPolicy){window.passwordPolicy.addToHistory(cu.id,nw);}
  ['cp-cur','cp-new','cp-cnf'].forEach(id=>document.getElementById(id).value='');
  addAudit('USER','Changed own password','USER');
  toast('Password changed successfully!');
}

function openAdminReset(id){
  const u=U.find(x=>x.id===id);if(!u){return;}
  const developerRecovery=cu?.role==='developer'&&['admin','store'].includes(u.username);
  if(!cu|| (cu.role!=='admin'&&!developerRecovery)){toast('Only Admin can reset other users password. Developer recovery is limited to admin/store bootstrap accounts.','er');return;}
  document.getElementById('ar-uid').value=id;
  document.getElementById('ar-pw').value='';document.getElementById('ar-cnf').value='';document.getElementById('ar-strength').textContent='';
  document.getElementById('ar-user-info').innerHTML=`Resetting password for: <b>${u.name}</b> &nbsp;<span class="mono" data-style="color:var(--tx3)">(${u.username})</span> &nbsp;<span class="bdg ${u.role==='admin'?'bb':'bg'}">${u.role}</span>`;
  document.getElementById('adminreset-ov').classList.add('on');
  setTimeout(()=>document.getElementById('ar-pw').focus(),100);
}
function canDeveloperBootstrapReset(){
  if(cu?.role!=='developer'){return false;}
  const id=parseInt(document.getElementById('ar-uid')?.value);
  const u=U.find(x=>x.id===id);
  return !!u&&['admin','store'].includes(u.username);
}
async function doAdminResetPw(){
  const id=parseInt(document.getElementById('ar-uid').value);
  const target=U.find(x=>x.id===id);
  const developerRecovery=cu?.role==='developer'&&['admin','store'].includes(target?.username);
  if(!cu|| (cu.role!=='admin'&&!developerRecovery)){toast('Only Admin can reset other users password. Developer recovery is limited to admin/store bootstrap accounts.','er');return;}
  const pw=document.getElementById('ar-pw').value;
  const cnf=document.getElementById('ar-cnf').value;
  if(!pw||!cnf){toast('Enter and confirm the new password','er');return;}
  if(!window.passStrong(pw)){toast('Password must be at least 6 chars with a letter and number','er');return;}
  if(pw!==cnf){toast('Passwords do not match','er');return;}
  const u=target;if(!u){toast('User not found','er');return;}
  if(window.passwordPolicy&&window.passwordPolicy.isInHistory(u.id,pw)){toast('That user already used this password recently — please choose a different one','er');return;}
  u.passwordHash=await hashPassword(pw);delete u.password;u.mustChangePassword=developerRecovery;u.updatedAt=new Date().toISOString();
  await dPut('users',u);
  U=await gAll('users');
  if(cu.id===u.id){cu=u;}
  if(window.passwordPolicy){window.passwordPolicy.addToHistory(u.id,pw);window.passwordPolicy.unlockAccount(u.username);}
  addAudit('USER',(developerRecovery?'Developer recovery reset':'Admin reset password for user')+': '+u.username,'USER');
  document.getElementById('adminreset-ov').classList.remove('on');
  toast('Password reset for "'+u.name+'"!');
}

// Reference Barcode Labels table-format override.
function setLabelSize(size){
  const presets={small:{w:38,h:20,fs:7,per:4},medium:{w:50,h:25,fs:8,per:3},large:{w:70,h:35,fs:10,per:2}};
  const p=presets[size]||presets.medium;
  [['lbl-w',p.w],['lbl-h',p.h],['lbl-fs',p.fs],['lbl-per',p.per]].forEach(([id,val])=>{const el=document.getElementById(id);if(el){el.value=val;}});
  ['small','medium','large'].forEach(k=>{
    const b=document.getElementById('lbl-size-'+k);
    if(!b){return;}
    const isOn=k===size;
    b.style.background=isOn?'var(--bl)':'var(--bg3)';
    b.style.borderColor=isOn?'var(--bl)':'var(--b1)';
    b.style.color=isOn?'#fff':'var(--tx2)';
    b.style.fontWeight=isOn?'600':'400';
  });
  renderLblLivePreview();
}
function updateLabelCount(){
  const el=document.getElementById('lbl-count');
  if(!el){return;}
  const copies=clampFiniteInt(document.getElementById('lbl-cop')?.value,1,1,100);
  el.textContent=`${lblSel.length} items selected · ${lblSel.length*copies} labels total`;
  const liveCount=document.getElementById('lbl-preview-live-count');
  if(liveCount&&lblSel.length){
    const s=getLblSettings();
    liveCount.textContent=`(${lblSel.length*s.copies} labels · ${s.w}×${s.h} mm)`;
  }else if(liveCount){liveCount.textContent='';}
}
function matchingLabelMaterials(materials,search){
  const q=String(search||'').trim().toLowerCase();
  return (Array.isArray(materials)?materials:[]).filter(m=>m&&m.active!==false&&(!q||String(m.name||'').toLowerCase().includes(q)||String(m.barcode||'').toLowerCase().includes(q)));
}
function selectAllLabels(){
  const q=document.getElementById('lbl-srch')?.value||'';
  const visible=matchingLabelMaterials(M,q);
  if(!visible.length)return;
  const allSelected=visible.every(m=>lblSel.some(s=>identifiersMatch(s.id,m.id)));
  if(allSelected){lblSel=lblSel.filter(s=>!visible.some(m=>identifiersMatch(s.id,m.id)));}
  else{visible.forEach(m=>{if(!lblSel.some(s=>identifiersMatch(s.id,m.id)))lblSel.push(m);});}
  renderLblSearch();renderLblSel();updateLabelCount();renderLblLivePreview();
}

function renderLblSearch(){
  const search=document.getElementById('lbl-srch'),res=document.getElementById('lbl-res');if(!search||!res)return;
  const visible=matchingLabelMaterials(M,search.value).slice(0,30);
  if(!visible.length){res.innerHTML='<tr><td colspan="4" data-style="text-align:center;color:var(--tx3);padding:22px">No items found</td></tr>';updateLabelCount();return;}
  res.innerHTML=visible.map(m=>{
    const sel=lblSel.some(s=>identifiersMatch(s.id,m.id)),arg=eventIdArg(m.id);
    return `<tr data-onclick="toggleLbl(${arg})" data-style="cursor:pointer"><td><input type="checkbox" ${sel?'checked':''} data-onclick="event.stopPropagation();toggleLbl(${arg})"></td><td class="mono" data-style="color:#3c83f6">${sanitizeHTML(String(m.barcode||''))}</td><td data-style="font-weight:500;color:#ebf0fa">${sanitizeHTML(String(m.name||''))}</td><td data-style="color:#8c9fba">${sanitizeHTML(String(m.category||'-'))}</td></tr>`;
  }).join('');
  updateLabelCount();
}

function renderLblSel(){updateLabelCount();}
_addEventListener(document, 'input', e=>{if(e.target&&e.target.id==='lbl-cop'){updateLabelCount();}});

// ── Live Preview (instant, right panel) ──────────────────────────────────────
async function renderLblLivePreview() {
  const grid = document.getElementById('lbl-live-grid');
  const empty = document.getElementById('lbl-empty-preview');
  if (!grid || !empty) {return;}
  if (!lblSel.length) { empty.style.display = 'block'; grid.style.display = 'none'; updateLabelCount(); return; }
  empty.style.display = 'none'; grid.style.display = 'flex'; grid.innerHTML = '';
  const s = getLblSettings();
  const container = document.createDocumentFragment();

  for (const m of lblSel) {
    for (let i = 0; i < s.copies; i++) {
      container.appendChild(await createLabelElement(m, s));
    }
  }
  grid.appendChild(container);
  updateLabelCount();
}

// ── Machine Spare Parts Module moved to modules/msp.js ──
// Variables: mspLists, mspActiveId, _mspSugIdx, _mspSaveBadgeTimer
// Constants: MSP_DEFAULT_COLS, MSP_STATUS_COL, MSP_QTY_COL, MSP_MINQTY_COL
// Functions: All MSP functions (mspSave, mspLoad, mspInit, mspRenderGrid, etc.)

// ══════════════════════════════════════════════════════════════════════════════
// SCANNER CONFIGURATION MODULE
// ══════════════════════════════════════════════════════════════════════════════

let _scMode     = 'hid';   // 'hid' | 'serial'
let _scEnrolling = false;

// ── Init ──────────────────────────────────────────────────────────────────────
async function scInit() {
  // FIX: Always render the page structure first — blank page was caused by
  // early return when scannerBridge was not yet available on first load.
  // Show the no-bridge warning if bridge is missing, but don't bail out entirely.
  const warn = document.getElementById('sc-no-bridge-warn');
  if (!window.scannerBridge) {
    if (warn) {warn.style.display = '';}
    scLog('⚠ Scanner bridge not available — check preload.js', 'sc-err');
    return;
  }
  if (warn) {warn.style.display = 'none';}

  await scLoadConfig();
  scRegisterListeners();

  // Auto-start checkbox
  const r = await window.scannerBridge.getAutoStart();
  const chk = document.getElementById('sc-autostart-chk');
  if (chk && r.ok) {chk.checked = !!r.enabled;}
}

// ── Real scanner status for Material IN/OUT pages ─────────────────────────────
// Previously this card was hardcoded HTML ("Zebra DS2200 / COM1 / Connected /
// 95% health") regardless of whether any scanner was actually configured —
// misleading. This reads the real config from the main process instead.
async function updateMatScannerStatusUI(role) {
  const nameEl = document.getElementById(role + '-scanner-name');
  const portEl = document.getElementById(role + '-scanner-port');
  const dotEl  = document.getElementById(role + '-scanner-dot');
  const textEl = document.getElementById(role + '-scanner-status-text');
  if (!nameEl || !portEl || !dotEl || !textEl) {return;}

  const setDisconnected = () => {
    nameEl.textContent = '—';
    portEl.textContent = '—';
    dotEl.className = 'scanner-status-dot disconnected';
    textEl.textContent = 'Not Connected';
  };

  if (!window.scannerBridge) { setDisconnected(); return; }

  try {
    const r = await window.scannerBridge.getConfig();
    if (!r || !r.ok) { setDisconnected(); return; }
    const cfg = r.config || {};
    const mode = cfg.scannerMode || 'hid';
    let configured = false, name = '—', port = '—';

    if (mode === 'hid') {
      const devPath = role === 'in' ? cfg.hid?.inScanner : cfg.hid?.outScanner;
      if (devPath) { configured = true; name = 'HID Scanner'; port = devPath; }
    } else {
      const p = role === 'in' ? cfg.serial?.inPort : cfg.serial?.outPort;
      if (p) { configured = true; name = 'Serial Scanner'; port = p + (cfg.serial?.baudRate ? ' @ ' + cfg.serial.baudRate : ''); }
    }

    nameEl.textContent = name;
    portEl.textContent = port;
    if (configured) {
      dotEl.className = 'scanner-status-dot connected';
      textEl.textContent = 'Configured';
    } else {
      dotEl.className = 'scanner-status-dot disconnected';
      textEl.textContent = 'Not Connected — click ⚙ Scanner Configuration to set up';
    }
  } catch (e) {
    setDisconnected();
  }
}

// ── Load and apply config to UI ───────────────────────────────────────────────
async function scLoadConfig() {
  const r = await window.scannerBridge.getConfig();
  if (!r.ok) { scLog('Config load failed: ' + (r.error || 'unknown'), 'sc-err'); return; }
  const cfg = r.config;
  _scMode = cfg.scannerMode || 'hid';

  // Mode panel toggle
  scRenderMode(_scMode);

  // HID status
  const inPath  = cfg.hid?.inScanner;
  const outPath = cfg.hid?.outScanner;
  scRenderHIDCard('in',  inPath);
  scRenderHIDCard('out', outPath);

  // Serial fields
  if (cfg.serial) {
    const inSel  = document.getElementById('sc-serial-in-port');
    const outSel = document.getElementById('sc-serial-out-port');
    const baud   = document.getElementById('sc-serial-baud');
    if (inSel  && cfg.serial.inPort)  {inSel.value  = cfg.serial.inPort;}
    if (outSel && cfg.serial.outPort) {outSel.value = cfg.serial.outPort;}
    if (baud   && cfg.serial.baudRate) {baud.value  = String(cfg.serial.baudRate);}
  }

  // Nav badge
  const anyMissing =
    (_scMode === 'hid'    && (!cfg.hid?.inScanner || !cfg.hid?.outScanner)) ||
    (_scMode === 'serial' && (!cfg.serial?.inPort  || !cfg.serial?.outPort));
  const badge = document.getElementById('sc-badge');
  if (badge) {badge.style.display = anyMissing ? 'inline-block' : 'none';}
}

function scRenderMode(mode) {
  document.getElementById('sc-panel-hid').style.display    = mode === 'hid'    ? '' : 'none';
  document.getElementById('sc-panel-serial').style.display = mode === 'serial' ? '' : 'none';
  document.getElementById('sc-mode-hid').classList.toggle('active',    mode === 'hid');
  document.getElementById('sc-mode-serial').classList.toggle('active', mode === 'serial');
}

function scRenderHIDCard(role, devicePath) {
  const dot    = document.getElementById('sc-dot-' + role);
  const sub    = document.getElementById('sc-sub-' + role);
  const status = document.getElementById('sc-status-' + role);
  const pathBox = document.getElementById('sc-path-' + role);
  const card   = document.getElementById('sc-card-' + role);

  if (devicePath) {
    if (dot)     { dot.className = 'sc-scanner-dot active'; }
    if (sub)     {sub.textContent = 'Configured';}
    if (status)  { status.className = 'bdg bg'; status.textContent = '✅ Active'; }
    if (pathBox) { pathBox.style.display = ''; pathBox.textContent = devicePath; }
    if (card)    {card.classList.add('configured');}
  } else {
    if (dot)     { dot.className = 'sc-scanner-dot'; }
    if (sub)     {sub.textContent = 'Not configured — click Configure';}
    if (status)  { status.className = 'bdg ba'; status.textContent = '⚠ Unconfigured'; }
    if (pathBox) {pathBox.style.display = 'none';}
    if (card)    {card.classList.remove('configured');}
  }
}

// ── Mode switch ───────────────────────────────────────────────────────────────
async function scSetMode(mode) {
  if (_scMode === mode) {return;}
  _scMode = mode;
  scRenderMode(mode);
  await window.scannerBridge.applyConfig({ scannerMode: mode });
  scLog(`Mode switched to ${mode === 'hid' ? 'HID' : 'Serial/COM'}`, 'sc-info');
  toast('Mode: ' + (mode === 'hid' ? 'HID' : 'Serial/COM'), 'inf');
}

// ── HID Enrollment ────────────────────────────────────────────────────────────
async function scEnrollHID(role) {
  if (_scEnrolling) { toast('Enrollment already in progress', 'inf'); return; }
  _scEnrolling = true;

  const label = role === 'in' ? 'IN (Scanner 1)' : 'OUT (Scanner 2)';
  document.getElementById('sc-enroll-title').textContent = 'Configuring ' + label + ' Scanner';
  document.getElementById('sc-enroll-sub').textContent   = 'Scan any barcode using the ' + label + ' scanner (15 seconds)';
  document.getElementById('sc-enroll-ov').style.display  = 'flex';

  try {
    const r = await window.scannerBridge.enrollHID(role);
    document.getElementById('sc-enroll-ov').style.display = 'none';
    _scEnrolling = false;

    if (r.ok) {
      const devName = r.deviceInfo?.product || r.devicePath;
      toast(`${label} scanner configured: ${devName}`, 'ok');
      scLog(`✅ Enrolled [${role.toUpperCase()}] ${devName} | Barcode: ${r.barcode}`, role === 'in' ? 'sc-in' : 'sc-out');
      await scLoadConfig();
    } else {
      toast('Enrollment failed: ' + (r.error || 'unknown'), 'er');
      scLog('❌ Enrollment error: ' + (r.error || 'unknown'), 'sc-err');
    }
  } catch (err) {
    document.getElementById('sc-enroll-ov').style.display = 'none';
    _scEnrolling = false;
    toast('Enrollment error: ' + err.message, 'er');
    scLog('❌ ' + err.message, 'sc-err');
  }
}

function scCancelEnroll() {
  document.getElementById('sc-enroll-ov').style.display = 'none';
  _scEnrolling = false;
  scLog('Enrollment cancelled', 'sc-info');
}

// ── HID Device List ───────────────────────────────────────────────────────────
async function scRefreshHID() {
  const list = document.getElementById('sc-hid-list');
  if (!list) {return;}
  list.innerHTML = '<div class="sc-dev-empty">Scanning devices...</div>';

  const r = await window.scannerBridge.listHIDDevices();
  if (!r.ok || !r.devices.length) {
    list.innerHTML = '<div class="sc-dev-empty">No HID devices found. Check scanner connections.</div>';
    return;
  }

  list.innerHTML = r.devices.map(d => `
    <div class="sc-dev-item" title="${d.path}">
      <div data-style="font-size:18px">🔌</div>
      <div class="sc-dev-info">
        <div class="sc-dev-name">${d.product || 'Unknown Device'} ${d.manufacturer ? '— ' + d.manufacturer : ''}</div>
        <div class="sc-dev-path">${d.path}</div>
        <div class="sc-dev-ids">VID: ${d.vendorId?.toString(16).padStart(4,'0').toUpperCase()} | PID: ${d.productId?.toString(16).padStart(4,'0').toUpperCase()}</div>
      </div>
    </div>
  `).join('');
  scLog(`${r.devices.length} HID device(s) found`, 'sc-info');
}

// ── Serial Port List ──────────────────────────────────────────────────────────
async function scRefreshPorts() {
  const inSel  = document.getElementById('sc-serial-in-port');
  const outSel = document.getElementById('sc-serial-out-port');
  if (!inSel || !outSel) {return;}

  const r = await window.scannerBridge.listSerialPorts();
  if (!r.ok) { toast('COM ports list failed: ' + (r.error || ''), 'er'); return; }

  const opts = '<option value="">— Select COM Port —</option>' +
    r.ports.map(p => `<option value="${p.path}">${p.path}${p.manufacturer ? ' — ' + p.manufacturer : ''}</option>`).join('');

  [inSel, outSel].forEach(sel => {
    const cur = sel.value;
    sel.innerHTML = opts;
    sel.value = cur;
  });

  scLog(`${r.ports.length} COM port(s) found`, 'sc-info');
  toast(r.ports.length + ' COM ports found', 'inf');
}

// ── Save Serial Config ────────────────────────────────────────────────────────
async function scSaveSerial() {
  const inPort  = document.getElementById('sc-serial-in-port').value;
  const outPort = document.getElementById('sc-serial-out-port').value;
  const baud    = parseInt(document.getElementById('sc-serial-baud').value) || 9600;

  if (!inPort || !outPort) { toast('Please select both COM ports', 'er'); return; }
  if (inPort === outPort)  { toast('IN and OUT ports must be different!', 'er'); return; }

  const r = await window.scannerBridge.applyConfig({
    scannerMode: 'serial',
    serial: { inPort, outPort, baudRate: baud }
  });

  if (r.ok) {
    toast('Serial config saved!', 'ok');
    scLog(`Serial config saved: IN=${inPort}, OUT=${outPort} @ ${baud}`, 'sc-info');
    await scLoadConfig();
  } else {
    toast('Save failed: ' + (r.error || ''), 'er');
  }
}

// ── Test ──────────────────────────────────────────────────────────────────────
async function scTest(role) {
  const label = role === 'in' ? 'IN' : 'OUT';
  toast(`Testing ${label} scanner — scan a barcode within 10 seconds...`, 'inf');
  scLog(`⏳ Testing [${label}] — scan a barcode now...`, 'sc-info');

  const r = await window.scannerBridge.test(role);
  if (r.ok) {
    toast(`✅ ${label} test OK — received: ${r.barcode}`, 'ok');
    scLog(`✅ Test [${label}] — Received: ${r.barcode}`, role === 'in' ? 'sc-in' : 'sc-out');
  } else {
    toast(`Test failed: ${r.error}`, 'er');
    scLog(`❌ Test [${label}] — ${r.error}`, 'sc-err');
  }
}

// ── Reset ─────────────────────────────────────────────────────────────────────
async function scResetConfig() {
  if (!confirm('Reset all scanner configuration? Both scanners will need to be configured again.')) {return;}
  const r = await window.scannerBridge.resetConfig();
  if (r.ok) {
    toast('Scanner configuration reset', 'inf');
    scLog('Configuration reset to defaults', 'sc-info');
    await scLoadConfig();
  } else {
    toast('Reset failed: ' + (r.error || ''), 'er');
  }
}

// ── Auto-start toggle ─────────────────────────────────────────────────────────
async function scToggleAutoStart(enable) {
  await window.scannerBridge.setAutoStart(enable);
  toast(enable ? 'Auto-start enabled' : 'Auto-start disabled', 'inf');
}

// ── Live log helpers ──────────────────────────────────────────────────────────
function scLog(msg, cls = 'sc-info') {
  const log = document.getElementById('sc-live-log');
  if (!log) {return;}
  // Remove empty placeholder
  const empty = log.querySelector('.sc-log-empty');
  if (empty) {empty.remove();}

  const line = document.createElement('div');
  line.className = 'sc-log-line ' + cls;
  line.textContent = '[' + new Date().toLocaleTimeString() + '] ' + msg;
  log.insertBefore(line, log.firstChild);
  while (log.children.length > 60) {log.removeChild(log.lastChild);}
}

function scClearLog() {
  const log = document.getElementById('sc-live-log');
  if (log) {log.innerHTML = '<div class="sc-log-empty">Scanner events will appear here...</div>';}
}

// ── Register live IPC event listeners ─────────────────────────────────────────
let _scListenersRegistered = false;
function scRegisterListeners() {
  if (_scListenersRegistered || !window.scannerBridge) {return;}
  _scListenersRegistered = true;

  window.scannerBridge.removeAllListeners();

  window.scannerBridge.onResult(data => {
    const scannedValue = String(data?.barcode || '').trim();
    if (/^\s*\{/.test(scannedValue) && typeof window.componentOpenStationFromQr === 'function') {
      const result = window.componentOpenStationFromQr(scannedValue);
      if (result) { toast('StoreTrack label QR opened', 'ok'); return; }
    }
    const label = data.role === 'in' ? 'Material IN' : 'Material OUT';
    if (data.result?.ok) {
      const mat = data.result.material || {};
      scLog(`✅ ${label}: ${mat.name || data.barcode} | Stock: ${data.result.newStock ?? mat.stock}`, data.role === 'in' ? 'sc-in' : 'sc-out');
      toast(`${label}: ${mat.name || data.barcode}`, 'ok');
    } else {
      const reason = data.result?.reason || 'unknown';
      scLog(`❌ ${label} failed [${data.barcode}] — ${reason}`, 'sc-err');
      toast(`${label} failed: ${reason}`, 'er');
    }
    if (typeof updateMatScannerStatusUI === 'function') {updateMatScannerStatusUI(data.role);}
  });

  // FIX: Safe IDB update from main process — replaces executeJavaScript string injection
  window.scannerBridge.onIdbUpdate(async data => {
    try {
      if (typeof dPut !== 'function' || typeof gAll !== 'function') {return;}
      if (data.tx) {await dPut('transactions', data.tx);}
      const mats = await gAll('materials');
      const m = mats.find(x => String(x.id) === String(data.materialId));
      if (m) {
        m.stock = data.newStock;
        m.updatedAt = data.updatedAt;
        await dPut('materials', m);
        M = mats;
      }
      if (data.tx && typeof T !== 'undefined') {T.push(data.tx);}
      if (data.tx && ['IN', 'MATERIAL_IN'].includes(data.tx.type)) {
        if (typeof inI !== 'undefined' && inI && String(inI.id) === String(data.materialId)) {
          inI.stock = Number(data.newStock);
          const currentStock = document.getElementById('in-cs');
          if (currentStock) { currentStock.textContent = inI.stock + ' ' + inI.unit; }
        }
        if (typeof renderInLog === 'function') { renderInLog(); }
      }
      if (typeof updateBadges === 'function') {updateBadges();}
      if (typeof updateDash   === 'function') {updateDash();}
    } catch (e) { console.warn('[Scanner IDB push]', e.message); }
  });

  window.scannerBridge.onDeviceError(data => {
    scLog(`⚠ Scanner error [${data.role}]: ${data.error}`, 'sc-err');
    scRenderHIDCard(data.role, null); // mark as inactive
    const dot = document.getElementById('sc-dot-' + data.role);
    if (dot) { dot.className = 'sc-scanner-dot error'; }
    if (typeof updateMatScannerStatusUI === 'function') {updateMatScannerStatusUI(data.role);}
  });

  // Tray "Scanner Configuration" menu click → nav to scanner
  window.scannerBridge.onNav(() => { nav('scanner'); });
}

// END SCANNER CONFIGURATION MODULE
// ══════════════════════════════════════════════════════════════════════════════

// ── Shared Folder Auto-Sync (3 sec) ──────────────────────────────────────────
function installPermissionGuards(){
  const guarded=[
    'saveMat','toggleMat','delMat','procIn','procOut','saveSupp','delSupp','saveDept','delDept','approveReq','rejectReq',
    'addUser','toggleUser','delUser','resetUserPassword','doAdminResetPw','clearAllData','importCSV',
    'importBackup','saveIndent','approveIndent','issueIndent','rejectIndent','saveReturn','saveLoc','delLoc',
    'mspSave','mspCellBlur','mspSaveListMeta','mspSaveNotes','mspDuplicateActiveList','mspDuplicateList','mspAddRow','mspDeleteRow','mspClearAll','mspDupList',
    'mspDeleteActiveList','mspDeleteList','mspImportFile','lanExport','lanImport','scSetMode','scEnrollHID',
    'scSaveSerial','scResetConfig'
  ];
  // Action-specific role policy. Search/view and navigation remain available
  // to every signed-in role; only the mutations below are capability checked.
  const roleActions={
    saveMat:'partRegister', procIn:'stockReceive', saveCycleCount:'physicalStock', delSupp:'admin', delDept:'admin', delLoc:'mapping',
    mspAddRow:'mapping', mspDeleteRow:'mapping', mspClearAll:'mapping', mspDupList:'mapping',
    exportCSV:'pdfExcelExport', exportPDFReport:'pdfExcelExport', exportXLS:'pdfExcelExport',
    componentSaveReplacement:'replacement', componentCommitReplacementImport:'consumptionImport',
    componentSaveManualHistoricalConsumption:'consumptionImport', componentDeleteHistoricalImportBatch:'consumptionImport',
    componentAddPart:'partRegister', componentSavePart:'partRegister', componentEditPart:'partRegister', componentDeletePart:'partRegister',
    componentAddMapping:'mapping', componentSaveMapping:'mapping', componentDeleteMapping:'mapping',
    componentAddBin:'mapping', componentEditBin:'mapping', componentDeleteBin:'mapping',
    componentReceiveStock:'stockReceive', componentSaveStockAdjustment:'physicalStock', componentSaveManualStockAdjustment:'physicalStock',
    componentImport:'imports', componentCommitImport:'consumptionImport', componentSavePrinterProfile:'settings',
    componentCompleteRepair:'repairScrap', componentRepairReturn:'repairScrap',
    componentSaveVerification:'physicalStock',
    componentExportReport:'pdfExcelExport', componentExportAccountability:'pdfExcelExport',
    componentExportAnalytics:'pdfExcelExport', componentExportHistoryExcel:'pdfExcelExport',
    componentExportHistoryPdf:'pdfExcelExport', componentExportLowStock:'pdfExcelExport',
    componentExportLowStockExcel:'pdfExcelExport', componentExportLowStockPdf:'pdfExcelExport',
    componentExportZeroStockExcel:'pdfExcelExport', componentExportZeroStockPdf:'pdfExcelExport',
    componentExportStockExcel:'pdfExcelExport', componentExportStockPdf:'pdfExcelExport',
    componentExportGunCountReconciliation:'pdfExcelExport',
    componentExportBIDashboard:'pdfExcelExport', componentExportProcurement:'pdfExcelExport',
    componentExportProcurementExcel:'pdfExcelExport', componentExportProcurementPdf:'pdfExcelExport',
    componentCloseMonth:'monthEndClose', componentReopenMonth:'monthEndClose',
    componentSaveMonthOpeningSnapshot:'monthEndClose',
  };
  Object.keys(roleActions).forEach(name=>{if(!guarded.includes(name)){guarded.push(name);}});
  const missing = guarded.filter(name => !roleActions[name] && !(window.ACTION_ALIASES && window.ACTION_ALIASES[name]));
  if (missing.length) console.error('[permissions] unmapped guarded actions:', missing);
  guarded.forEach(name=>{
    const fn=window[name];
    if(typeof fn!=='function'||fn._permissionGuarded){return;}
    const wrapped=function(...args){
      if(typeof window.canRoleAction!=='function' || !window.canRoleAction(roleActions[name] || (window.ACTION_ALIASES && window.ACTION_ALIASES[name]) || name)){return;}
      return fn.apply(this,args);
    };
    wrapped._permissionGuarded=true;
    window[name]=wrapped;
  });
  const adminOnly=['addUser','toggleUser','delUser','resetUserPassword','doAdminResetPw','approveReq','rejectReq','bulkApproveSelected','bulkRejectSelected','approveIndent','issueIndent','rejectIndent','clearAllData'];
  adminOnly.forEach(name=>{
    const fn=window[name];
    if(typeof fn!=='function'||fn._adminGuarded){return;}
    const wrapped=function(...args){
      if(name==='doAdminResetPw'&&typeof canDeveloperBootstrapReset==='function'&&canDeveloperBootstrapReset()){return fn.apply(this,args);}
      if(!canAdmin(name)){return;}
      return fn.apply(this,args);
    };
    wrapped._adminGuarded=true;
    window[name]=wrapped;
  });
}
installPermissionGuards();

document.addEventListener('DOMContentLoaded', function(){
(function(){
  if(!window.storeSync){return;}
  // Remove stale listeners from any previous page load
  window.storeSync.removeAllListeners();

  const bar      = document.getElementById('sync-bar');
  const pathLbl  = document.getElementById('sync-folder-path');
  const statusEl = document.getElementById('sync-status-msg');
  const changeEl = document.getElementById('sync-change-info');
  const btnPick  = document.getElementById('btn-sync-pick');
  const btnStop  = document.getElementById('btn-sync-stop');

  function fmtTime(ts){return new Date(ts).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'});}

  function setActive(folder){
    bar.className='active';
    const short=folder.split(/[\\/]/).pop()||folder;
    pathLbl.textContent='📁 '+short;
    btnStop.style.display='inline-block';
  }
  function setInactive(){
    bar.className='inactive';
    pathLbl.textContent='No folder selected';
    statusEl.textContent='Sync off';
    changeEl.textContent='';
    btnStop.style.display='none';
  }
  function flashPulse(){
    bar.classList.add('pulse');
    setTimeout(()=>bar.classList.remove('pulse'),600);
  }

  // Restore last session state
  window.storeSync.getStatus().then(({folder,active})=>{
    if(folder&&active){setActive(folder);}
  });

  // Heartbeat every 5 s — just show we're alive
  window.storeSync.onHeartbeat(({folder,ts,device,...rest})=>{
    setActive(folder);
    statusEl.textContent='🟢 Live · '+device+' · '+fmtTime(ts);
    // FIX #10: Update health dashboard panel whenever heartbeat arrives
    _updateLanHealthPanel({active:true,online:true,...rest});
  });

  // File changed in folder (any file)
  window.storeSync.onUpdate(({filename,eventType,ts})=>{
    flashPulse();
    changeEl.textContent=(eventType==='change'?'✏ ':'📄 ')+filename+' @ '+fmtTime(ts);
  });

  // master.json changed on another PC → auto-apply
  window.storeSync.onMasterUpdate(async({master,ts,device})=>{
    flashPulse();
    statusEl.textContent='⬇ Receiving from '+device+' @ '+fmtTime(ts)+'…';
    try{
      await _applyLanMaster(master);
      statusEl.textContent='✅ Auto-synced from '+device+' @ '+fmtTime(ts);
      changeEl.textContent='';
    }catch(e){
      statusEl.textContent='⚠ Sync error: '+e.message;
    }
  });

  btnPick.addEventListener('click',async()=>{
    const folder=await window.storeSync.selectFolder();
    if(folder){changeEl.textContent='';setActive(folder);statusEl.textContent='Folder selected';}
  });
  btnStop.addEventListener('click',async()=>{
    await window.storeSync.stop();
    setInactive();
  });
})();
}); // DOMContentLoaded

// ── PM Module moved to modules/pm.js ──
// Variables: pmSchedules, pmCurrentEquipment, pmCurrentChecklist
// Functions: All PM functions (pmDownloadTemplate, pmImportFile, pmRenderPersonGroups, etc.)
