@echo off
setlocal
cd /d "%~dp0"
set "TASK=StoreTrack Pro Daily Backup"
set "CMD=%~dp0run-daily-backup.bat"
schtasks /Create /SC DAILY /TN "%TASK%" /TR "\"%CMD%\"" /ST 23:59 /F
if errorlevel 1 (
  echo Failed to create the daily backup task. Run this file as Administrator.
  exit /b 1
)
echo Daily backup scheduled at 23:59.
echo Backup files are stored under the StoreTrackData\CompleteBackups folder.
pause
