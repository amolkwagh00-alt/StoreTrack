StoreTrack Pro — Full Source Project Archive
Generated: 2026-11-06

या archive मध्ये पूर्ण source project, documentation, tests, package manifests आणि maintained release files आहेत. Shank Receiving keyboard flow: Part No. dropdown मध्ये Arrow Down + Enter केल्यावर focus Total Received Quantity मध्ये जातो; valid allocation नंतर quantity-field Enter ने receipt होते; यशानंतर तोच Part No. field मध्ये restore/focus/select होतो व Qty रिकामी राहते.

Excluded: node_modules (npm ci ने install करा), Git metadata, local StoreTrackData, test-result outputs, logs, database/backup files आणि non-example credentials/certificates. Safe .env.example templates included.

हा source archive आहे; Windows installer नाही. Windows packaging व production UAT स्वतंत्रपणे करणे आवश्यक आहे.
