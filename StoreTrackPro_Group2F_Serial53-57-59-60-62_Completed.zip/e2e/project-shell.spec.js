const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');

test('renderer shell and referenced modules are present', async () => {
  const root = path.resolve(__dirname, '..');
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  expect(html).toContain('StoreTrack Pro');
  const refs = [...html.matchAll(/<script src="(modules\/[^"]+)"/g)].map(
    (match) => match[1].split('?')[0],
  );
  expect(refs.length).toBeGreaterThan(0);
  for (const ref of refs) {
    expect(fs.existsSync(path.join(root, ref))).toBe(true);
  }
});
