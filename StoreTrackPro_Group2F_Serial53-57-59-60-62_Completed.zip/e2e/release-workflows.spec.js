const fs = require('fs');
const path = require('path');
const { test, expect } = require('@playwright/test');

const root = path.resolve(__dirname, '..');

test('release contains login, stock, backup, historical import, and central-sync workflow contracts', async () => {
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
  const component = fs.readFileSync(path.join(root, 'modules/componentManagement.js'), 'utf8');
  const backup = fs.readFileSync(path.join(root, 'modules/dataBackup.js'), 'utf8');
  const central = fs.readFileSync(path.join(root, 'modules/centralSync.js'), 'utf8');
  expect(html).toContain('id="lu"');
  expect(html).toContain('id="lp"');
  expect(app).toContain('doLogin');
  expect(component).toContain('componentReceiveStock');
  expect(component).toContain('componentSaveReplacement');
  expect(component).toContain('Historical Consumption — analytics only');
  expect(component).toContain('component_historical_consumption');
  expect(backup).toContain('window.backupBridge.write');
  expect(backup).toContain('window.backupBridge.read');
  expect(central).toContain('Central server is not configured');
});

test('release excludes remote CDN OCR and permissive eval CSP', async () => {
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  const main = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
  expect(html).not.toContain('cdn.jsdelivr.net');
  expect(main).not.toContain("'unsafe-eval'");
  expect(main).not.toContain('cdn.jsdelivr.net');
});
