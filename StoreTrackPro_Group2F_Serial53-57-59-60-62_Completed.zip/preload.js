const { contextBridge, ipcRenderer } = require('electron');

// ── QR Code Bridge ────────────────────────────────────────────────────────────
// QR generation runs in main process (has node access); renderer calls this bridge.
contextBridge.exposeInMainWorld('qrBridge', {
  toDataURL: (text, options) => ipcRenderer.invoke('qr:toDataURL', text, options),
});

// ── XLSX Bridge ───────────────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('xlsxBridge', {
  parseBuffer: (uint8arr) => ipcRenderer.invoke('xlsx:parseBuffer', uint8arr),
  parseFile:   (filePath) => ipcRenderer.invoke('xlsx:parseFile', filePath)
});

// ── Auth Bridge (Patch 5: bcrypt) ─────────────────────────────────────────────
contextBridge.exposeInMainWorld('authBridge', {
  hashPassword:   (password)             => ipcRenderer.invoke('auth:hashPassword', password),
  verifyPassword: (password, storedHash) => ipcRenderer.invoke('auth:verifyPassword', password, storedHash)
});

// OS-protected encryption-key storage; key bytes are never written by the renderer.
contextBridge.exposeInMainWorld('encryptionKeyBridge', {
  getKey: () => ipcRenderer.invoke('encryptionKey:get'),
  setKey: (key) => ipcRenderer.invoke('encryptionKey:set', key)
});

// ── Scanner Bridge ────────────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('scannerBridge', {
  // Config
  getConfig:       ()        => ipcRenderer.invoke('scanner:getConfig'),
  applyConfig:     (partial) => ipcRenderer.invoke('scanner:applyConfig',     partial),
  resetConfig:     ()        => ipcRenderer.invoke('scanner:resetConfig'),

  // Device discovery
  listHIDDevices:  ()        => ipcRenderer.invoke('scanner:listHIDDevices'),
  listSerialPorts: ()        => ipcRenderer.invoke('scanner:listSerialPorts'),

  // Enrollment & test
  enrollHID:       (role)    => ipcRenderer.invoke('scanner:enrollHID',       role),
  test:            (role)    => ipcRenderer.invoke('scanner:test',            role),

  // Auto-start
  setAutoStart:    (enable)  => ipcRenderer.invoke('scanner:setAutoStart',    enable),
  getAutoStart:    ()        => ipcRenderer.invoke('scanner:getAutoStart'),

  // IPC events from main → renderer
  onResult:        (cb)  => ipcRenderer.on('scanner:result',      (_e, d) => cb(d)),
  onDeviceError:   (cb)  => ipcRenderer.on('scanner:deviceError', (_e, d) => cb(d)),
  onIdbUpdate:     (cb)  => ipcRenderer.on('scanner:idbUpdate',   (_e, d) => cb(d)), // FIX: safe IDB push replaces executeJavaScript injection
  onNav:           (cb)  => ipcRenderer.on('nav:scanner',         ()      => cb()),

  removeAllListeners: () => {
    ipcRenderer.removeAllListeners('scanner:result');
    ipcRenderer.removeAllListeners('scanner:deviceError');
    ipcRenderer.removeAllListeners('scanner:idbUpdate');
    ipcRenderer.removeAllListeners('nav:scanner');
  },
});

// ── Print Bridge ─────────────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('printBridge', {
  printContent: (html) => ipcRenderer.invoke('print:printContent', html),
  savePDF: (html, filename) => ipcRenderer.invoke('print:savePDF', html, filename)
});

// ── Central API IPC ────────────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('centralBridge', {
  configure: (baseUrl) => ipcRenderer.invoke('central:configure', baseUrl),
  login: (credentials) => ipcRenderer.invoke('central:login', credentials),
  logout: () => ipcRenderer.invoke('central:logout'),
  getMaterials: () => ipcRenderer.invoke('central:getMaterials'),
  getMigrationStatus: () => ipcRenderer.invoke('central:getMigrationStatus'),
  upsertMaterial: (material) => ipcRenderer.invoke('central:upsertMaterial', material),
  syncUsers: (users) => ipcRenderer.invoke('central:syncUsers', users),
  logAIEvent: (payload) => ipcRenderer.invoke('central:logAIEvent', payload),
  commitStock: (transaction) => ipcRenderer.invoke('central:commitStock', transaction),
  pullChanges: (afterSequence) => ipcRenderer.invoke('central:pullChanges', afterSequence),
  getStatus: () => ipcRenderer.invoke('central:getStatus'),
  onEvent: (cb) => ipcRenderer.on('central:event', (_e, d) => cb(d)),
  removeListeners: () => ipcRenderer.removeAllListeners('central:event')
});

// ── Complete Backup IPC ───────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('backupBridge', {
  write: (serialized) => ipcRenderer.invoke('backup:write', serialized),
  writeRecoveryJournal: (serialized) => ipcRenderer.invoke('backup:writeRecoveryJournal', serialized),
  readRecoveryJournal: () => ipcRenderer.invoke('backup:readRecoveryJournal'),
  clearRecoveryJournal: () => ipcRenderer.invoke('backup:clearRecoveryJournal'),
  exportPortable: (serialized) => ipcRenderer.invoke('backup:exportPortable', serialized),
  decryptPortable: (serialized) => ipcRenderer.invoke('backup:decryptPortable', serialized),
  read: () => ipcRenderer.invoke('backup:read'),
  status: () => ipcRenderer.invoke('backup:status'),
  openFolder: () => ipcRenderer.invoke('backup:openFolder')
});

// ── Sync IPC ──────────────────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('storeSync', {
  getStatus:    ()            => ipcRenderer.invoke('sync:getStatus'),
  selectFolder: ()            => ipcRenderer.invoke('sync:selectFolder'),
  stop:         ()            => ipcRenderer.invoke('sync:stop'),
  health:       ()            => ipcRenderer.invoke('sync:health'),

  // Master JSON push/pull  (full dataset sync)
  pushMaster:   (data)        => ipcRenderer.invoke('sync:pushMaster', data),
  pullMaster:   ()            => ipcRenderer.invoke('sync:pullMaster'),

  // Transaction log
  appendTx:     (tx)          => ipcRenderer.invoke('sync:appendTx', tx),
  readTxLog:    ()            => ipcRenderer.invoke('sync:readTxLog'),

  // Patch 6: Import validation
  validateImport: (data)      => ipcRenderer.invoke('sync:validateImport', data),

  // Event listeners (use removeAll before re-registering to avoid leaks)
  onUpdate:         (cb) => ipcRenderer.on('sync:update',       (_e, d) => cb(d)),
  onHeartbeat:      (cb) => ipcRenderer.on('sync:heartbeat',    (_e, d) => cb(d)),
  onMasterUpdate:   (cb) => ipcRenderer.on('sync:masterUpdate', (_e, d) => cb(d)),

  removeAllListeners: () => {
    ipcRenderer.removeAllListeners('sync:update');
    ipcRenderer.removeAllListeners('sync:heartbeat');
    ipcRenderer.removeAllListeners('sync:masterUpdate');
  }
});

// ── PM Checklists Bridge ──────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('pmBridge', {
  listChecklistFiles: () => ipcRenderer.invoke('pm:listChecklistFiles'),
  parseChecklistFile: (filePath, fileType) => ipcRenderer.invoke('pm:parseChecklistFile', filePath, fileType),
  generateTemplate: () => ipcRenderer.invoke('pm:generateTemplate'),
  printChecksheetOriginal: (filePath, fileType, title) => ipcRenderer.invoke('pm:printChecksheetOriginal', filePath, fileType, title),
  smartParseSchedule: (uint8arr) => ipcRenderer.invoke('pm:smartParseSchedule', uint8arr),
  browseChecksheet: (equipmentName) => ipcRenderer.invoke('pm:browseChecksheet', equipmentName)
});
