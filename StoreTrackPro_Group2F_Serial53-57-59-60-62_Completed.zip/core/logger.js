/**
 * Enterprise Logging System
 * Centralized logging for StoreTrack Pro
 * Supports multiple log levels, categories, and persistence
 */

class Logger {
  constructor() {
    this.logs = [];
    this.maxLogSize = 10000;
    this.logLevel = 'INFO';
    this.categories = new Set();
    this.loggers = new Map();
    this.persistenceEnabled = true;
    this.persistenceKey = 'storetrack_logs';
    this.rotationPolicy = {
      maxSize: 10 * 1024 * 1024, // 10MB
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    };
  }

  /**
   * Initialize logger
   * @param {Object} options - Configuration options
   */
  initialize(options = {}) {
    this.logLevel = options.logLevel || 'INFO';
    this.persistenceEnabled = options.persistence !== false;
    
    if (options.rotationPolicy) {
      this.rotationPolicy = { ...this.rotationPolicy, ...options.rotationPolicy };
    }
    
    // Load persisted logs
    if (this.persistenceEnabled) {
      this.loadFromPersistence();
    }
    
    // Setup log rotation
    this.setupLogRotation();
  }

  /**
   * Log levels
   */
  static LEVELS = {
    DEBUG: 0,
    INFO: 1,
    WARN: 2,
    ERROR: 3,
    CRITICAL: 4
  };

  /**
   * Log a message
   * @param {string} level - Log level
   * @param {string} message - Log message
   * @param {Object} data - Additional data
   * @param {string} category - Log category
   */
  log(level, message, data = null, category = 'default') {
    if (Logger.LEVELS[level] < Logger.LEVELS[this.logLevel]) {
      return;
    }

    const logEntry = {
      id: this.generateLogId(),
      level,
      message,
      data,
      category,
      timestamp: new Date().toISOString(),
      stack: level === 'ERROR' || level === 'CRITICAL' ? new Error().stack : null
    };

    this.logs.push(logEntry);
    
    // Trim if exceeds max size
    if (this.logs.length > this.maxLogSize) {
      this.logs.shift();
    }

    // Console output
    this.outputToConsole(logEntry);

    // Persist if enabled
    if (this.persistenceEnabled) {
      this.saveToPersistence();
    }

    // Emit log event
    if (typeof window !== 'undefined' && window.eventBus) {
      window.eventBus.emit('LOG_ENTRY', logEntry);
    }
  }

  /**
   * Debug level log
   * @param {string} message - Message
   * @param {Object} data - Data
   * @param {string} category - Category
   */
  debug(message, data = null, category = 'default') {
    this.log('DEBUG', message, data, category);
  }

  /**
   * Info level log
   * @param {string} message - Message
   * @param {Object} data - Data
   * @param {string} category - Category
   */
  info(message, data = null, category = 'default') {
    this.log('INFO', message, data, category);
  }

  /**
   * Warning level log
   * @param {string} message - Message
   * @param {Object} data - Data
   * @param {string} category - Category
   */
  warn(message, data = null, category = 'default') {
    this.log('WARN', message, data, category);
  }

  /**
   * Error level log
   * @param {string} message - Message
   * @param {Object} data - Data
   * @param {string} category - Category
   */
  error(message, data = null, category = 'default') {
    this.log('ERROR', message, data, category);
  }

  /**
   * Critical level log
   * @param {string} message - Message
   * @param {Object} data - Data
   * @param {string} category - Category
   */
  critical(message, data = null, category = 'default') {
    this.log('CRITICAL', message, data, category);
  }

  /**
   * Create category-specific logger
   * @param {string} category - Category name
   * @returns {Object} Category logger
   */
  createLogger(category) {
    if (this.loggers.has(category)) {
      return this.loggers.get(category);
    }

    const categoryLogger = {
      debug: (message, data) => this.debug(message, data, category),
      info: (message, data) => this.info(message, data, category),
      warn: (message, data) => this.warn(message, data, category),
      error: (message, data) => this.error(message, data, category),
      critical: (message, data) => this.critical(message, data, category)
    };

    this.loggers.set(category, categoryLogger);
    this.categories.add(category);

    return categoryLogger;
  }

  /**
   * Output to console
   * @param {Object} logEntry - Log entry
   */
  outputToConsole(logEntry) {
    const prefix = `[${logEntry.timestamp}] [${logEntry.level}] [${logEntry.category}]`;
    const message = `${prefix} ${logEntry.message}`;

    switch (logEntry.level) {
      case 'DEBUG':
        console.debug(message, logEntry.data || '');
        break;
      case 'INFO':
        console.info(message, logEntry.data || '');
        break;
      case 'WARN':
        console.warn(message, logEntry.data || '');
        break;
      case 'ERROR':
        console.error(message, logEntry.data || '', logEntry.stack || '');
        break;
      case 'CRITICAL':
        console.error(message, logEntry.data || '', logEntry.stack || '');
        break;
    }
  }

  /**
   * Get logs
   * @param {Object} filters - Filters
   * @returns {Array} Filtered logs
   */
  getLogs(filters = {}) {
    let logs = [...this.logs];

    if (filters.level) {
      logs = logs.filter(log => log.level === filters.level);
    }

    if (filters.category) {
      logs = logs.filter(log => log.category === filters.category);
    }

    if (filters.since) {
      logs = logs.filter(log => new Date(log.timestamp) >= new Date(filters.since));
    }

    if (filters.until) {
      logs = logs.filter(log => new Date(log.timestamp) <= new Date(filters.until));
    }

    if (filters.search) {
      const search = filters.search.toLowerCase();
      logs = logs.filter(log => 
        log.message.toLowerCase().includes(search) ||
        (log.data && JSON.stringify(log.data).toLowerCase().includes(search))
      );
    }

    if (filters.limit) {
      logs = logs.slice(-filters.limit);
    }

    return logs;
  }

  /**
   * Clear logs
   * @param {Object} filters - Optional filters for selective clearing
   */
  clearLogs(filters = {}) {
    if (Object.keys(filters).length === 0) {
      this.logs = [];
    } else {
      this.logs = this.logs.filter(log => {
        if (filters.level && log.level === filters.level) {return false;}
        if (filters.category && log.category === filters.category) {return false;}
        if (filters.before && new Date(log.timestamp) < new Date(filters.before)) {return false;}
        return true;
      });
    }

    if (this.persistenceEnabled) {
      this.saveToPersistence();
    }
  }

  /**
   * Get log statistics
   * @returns {Object} Statistics
   */
  getStatistics() {
    const stats = {
      total: this.logs.length,
      byLevel: {},
      byCategory: {},
      recent: this.logs.slice(-10),
      oldest: this.logs[0],
      newest: this.logs[this.logs.length - 1]
    };

    this.logs.forEach(log => {
      stats.byLevel[log.level] = (stats.byLevel[log.level] || 0) + 1;
      stats.byCategory[log.category] = (stats.byCategory[log.category] || 0) + 1;
    });

    return stats;
  }

  /**
   * Export logs
   * @param {string} format - Export format (json, csv)
   * @param {Object} filters - Filters
   * @returns {string} Exported data
   */
  exportLogs(format = 'json', filters = {}) {
    const logs = this.getLogs(filters);

    if (format === 'json') {
      return JSON.stringify(logs, null, 2);
    }

    if (format === 'csv') {
      const headers = ['id', 'level', 'message', 'category', 'timestamp', 'data'];
      const rows = logs.map(log => [
        log.id,
        log.level,
        `"${log.message.replace(/"/g, '""')}"`,
        log.category,
        log.timestamp,
        `"${log.data ? JSON.stringify(log.data).replace(/"/g, '""') : ''}"`
      ]);
      return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    }

    throw new Error(`Unsupported export format: ${format}`);
  }

  /**
   * Set log level
   * @param {string} level - Log level
   */
  setLogLevel(level) {
    if (Logger.LEVELS[level] !== undefined) {
      this.logLevel = level;
    }
  }

  /**
   * Setup log rotation
   */
  setupLogRotation() {
    setInterval(() => {
      this.rotateLogs();
    }, 24 * 60 * 60 * 1000); // Daily
  }

  /**
   * Rotate logs based on policy
   */
  rotateLogs() {
    const now = Date.now();
    const maxAge = this.rotationPolicy.maxAge;
    const maxSize = this.rotationPolicy.maxSize;

    // Remove old logs
    this.logs = this.logs.filter(log => {
      const logAge = now - new Date(log.timestamp).getTime();
      return logAge < maxAge;
    });

    // Check size
    let currentSize = JSON.stringify(this.logs).length;
    while (currentSize > maxSize && this.logs.length > 0) {
      this.logs.shift();
      currentSize = JSON.stringify(this.logs).length;
    }

    if (this.persistenceEnabled) {
      this.saveToPersistence();
    }
  }

  /**
   * Save to persistence
   */
  saveToPersistence() {
    try {
      const data = JSON.stringify(this.logs);
      localStorage.setItem(this.persistenceKey, data);
    } catch (error) {
      console.error('Logger: Failed to save logs:', error);
    }
  }

  /**
   * Load from persistence
   */
  loadFromPersistence() {
    try {
      const data = localStorage.getItem(this.persistenceKey);
      if (data) {
        this.logs = JSON.parse(data);
      }
    } catch (error) {
      console.error('Logger: Failed to load logs:', error);
    }
  }

  /**
   * Clear persistence
   */
  clearPersistence() {
    try {
      localStorage.removeItem(this.persistenceKey);
    } catch (error) {
      console.error('Logger: Failed to clear persistence:', error);
    }
  }

  /**
   * Generate log ID
   * @returns {string} Log ID
   */
  generateLogId() {
    return `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Global logger instance
const logger = new Logger();

// Initialize with default settings
logger.initialize({ logLevel: 'INFO' });

// Create category loggers
const appLogger = logger.createLogger('app');
const dbLogger = logger.createLogger('database');
const scannerLogger = logger.createLogger('scanner');
const rfidLogger = logger.createLogger('rfid');
const printingLogger = logger.createLogger('printing');
const syncLogger = logger.createLogger('sync');
const securityLogger = logger.createLogger('security');
const performanceLogger = logger.createLogger('performance');

// Expose to window
if (typeof window !== 'undefined') {
  window.Logger = Logger;
  window.logger = logger;
  window.appLogger = appLogger;
  window.dbLogger = dbLogger;
  window.scannerLogger = scannerLogger;
  window.rfidLogger = rfidLogger;
  window.printingLogger = printingLogger;
  window.syncLogger = syncLogger;
  window.securityLogger = securityLogger;
  window.performanceLogger = performanceLogger;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { 
    Logger, 
    logger, 
    appLogger, 
    dbLogger, 
    scannerLogger, 
    rfidLogger, 
    printingLogger, 
    syncLogger, 
    securityLogger, 
    performanceLogger 
  };
}
