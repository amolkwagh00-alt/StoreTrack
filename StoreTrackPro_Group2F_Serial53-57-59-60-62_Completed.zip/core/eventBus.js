/**
 * Enterprise Event Bus
 * Centralized event management system for StoreTrack Pro
 * Implements publish-subscribe pattern for decoupled communication
 */

class EventBus {
  constructor() {
    this.events = {};
    this.eventHistory = [];
    this.maxHistorySize = 1000;
    this.listenerStats = new Map();
  }

  /**
   * Subscribe to an event
   * @param {string} eventName - Event name to subscribe to
   * @param {Function} callback - Callback function
   * @param {Object} options - Subscription options
   * @returns {Function} Unsubscribe function
   */
  on(eventName, callback, options = {}) {
    const { once = false, priority = 0 } = options;

    if (!this.events[eventName]) {
      this.events[eventName] = [];
    }

    const listener = {
      callback,
      once,
      priority,
      id: this.generateListenerId(),
      subscribedAt: new Date().toISOString()
    };

    // Insert based on priority (higher priority first)
    const listeners = this.events[eventName];
    let insertIndex = listeners.length;
    for (let i = 0; i < listeners.length; i++) {
      if (priority > listeners[i].priority) {
        insertIndex = i;
        break;
      }
    }
    listeners.splice(insertIndex, 0, listener);

    // Track stats
    this.listenerStats.set(listener.id, {
      eventName,
      callCount: 0,
      lastCalled: null,
      subscribedAt: listener.subscribedAt
    });

    // Return unsubscribe function
    return () => this.off(eventName, listener.id);
  }

  /**
   * Subscribe to event once (auto-unsubscribe after first call)
   * @param {string} eventName - Event name
   * @param {Function} callback - Callback function
   * @returns {Function} Unsubscribe function
   */
  once(eventName, callback) {
    return this.on(eventName, callback, { once: true });
  }

  /**
   * Unsubscribe from an event
   * @param {string} eventName - Event name
   * @param {string} listenerId - Listener ID (optional, removes all if not provided)
   */
  off(eventName, listenerId = null) {
    if (!this.events[eventName]) {return;}

    if (listenerId) {
      this.events[eventName] = this.events[eventName].filter(
        listener => listener.id !== listenerId
      );
      this.listenerStats.delete(listenerId);
    } else {
      // Remove all listeners for this event
      this.events[eventName].forEach(listener => {
        this.listenerStats.delete(listener.id);
      });
      delete this.events[eventName];
    }
  }

  /**
   * Emit an event
   * @param {string} eventName - Event name
   * @param {*} data - Event data
   * @param {Object} metadata - Event metadata
   */
  emit(eventName, data = null, metadata = {}) {
    const event = {
      name: eventName,
      data,
      metadata,
      timestamp: new Date().toISOString(),
      id: this.generateEventId()
    };

    // Add to history
    this.addToHistory(event);

    // Call listeners
    if (this.events[eventName]) {
      const listenersToRemove = [];

      this.events[eventName].forEach(listener => {
        try {
          listener.callback(event.data, event);

          // Update stats
          const stats = this.listenerStats.get(listener.id);
          if (stats) {
            stats.callCount++;
            stats.lastCalled = event.timestamp;
          }

          // Mark for removal if once
          if (listener.once) {
            listenersToRemove.push(listener.id);
          }
        } catch (error) {
          console.error(`EventBus: Error in listener for ${eventName}:`, error);
          this.emit('EVENT_BUS_ERROR', {
            eventName,
            listenerId: listener.id,
            error: error.message
          });
        }
      });

      // Remove once listeners
      listenersToRemove.forEach(id => this.off(eventName, id));
    }
  }

  /**
   * Add event to history
   * @param {Object} event - Event object
   */
  addToHistory(event) {
    this.eventHistory.push(event);
    if (this.eventHistory.length > this.maxHistorySize) {
      this.eventHistory.shift();
    }
  }

  /**
   * Get event history
   * @param {string} eventName - Optional event name filter
   * @param {number} limit - Optional limit
   * @returns {Array} Event history
   */
  getHistory(eventName = null, limit = 100) {
    let history = this.eventHistory;
    if (eventName) {
      history = history.filter(e => e.name === eventName);
    }
    return history.slice(-limit);
  }

  /**
   * Clear event history
   */
  clearHistory() {
    this.eventHistory = [];
  }

  /**
   * Get listener statistics
   * @returns {Object} Listener stats
   */
  getListenerStats() {
    return Object.fromEntries(this.listenerStats);
  }

  /**
   * Get all event names
   * @returns {Array} Event names
   */
  getEventNames() {
    return Object.keys(this.events);
  }

  /**
   * Get listener count for an event
   * @param {string} eventName - Event name
   * @returns {number} Listener count
   */
  getListenerCount(eventName) {
    return this.events[eventName]?.length || 0;
  }

  /**
   * Remove all listeners
   */
  removeAllListeners() {
    this.events = {};
    this.listenerStats.clear();
  }

  /**
   * Generate unique listener ID
   * @returns {string} Listener ID
   */
  generateListenerId() {
    return `listener_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Generate unique event ID
   * @returns {string} Event ID
   */
  generateEventId() {
    return `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Global event bus instance
const eventBus = new EventBus();

// Expose to window
if (typeof window !== 'undefined') {
  window.EventBus = EventBus;
  window.eventBus = eventBus;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { EventBus, eventBus };
}
