/**
 * Enterprise State Manager
 * Centralized state management system for StoreTrack Pro
 * Implements reactive state with subscriptions and persistence
 */

class StateManager {
  constructor() {
    this.state = {};
    this.subscribers = new Map();
    this.stateHistory = [];
    this.maxHistorySize = 500;
    this.persistenceEnabled = true;
    this.persistenceKey = 'storetrack_state';
  }

  /**
   * Initialize state manager with initial state
   * @param {Object} initialState - Initial state object
   */
  initialize(initialState = {}) {
    this.state = { ...initialState };
    
    // Load from persistence if enabled
    if (this.persistenceEnabled) {
      this.loadFromPersistence();
    }
  }

  /**
   * Get state value
   * @param {string} path - Dot notation path (e.g., 'user.profile.name')
   * @param {*} defaultValue - Default value if path doesn't exist
   * @returns {*} State value
   */
  get(path, defaultValue = null) {
    if (!path) {return this.state;}

    const keys = path.split('.');
    let value = this.state;

    for (const key of keys) {
      if (value && typeof value === 'object' && key in value) {
        value = value[key];
      } else {
        return defaultValue;
      }
    }

    return value;
  }

  /**
   * Set state value
   * @param {string} path - Dot notation path
   * @param {*} value - Value to set
   * @param {Object} options - Options
   */
  set(path, value, options = {}) {
    const { persist = true, notify = true } = options;

    const oldValue = this.get(path);
    const keys = path.split('.');
    
    // Create nested objects if needed
    let current = this.state;
    for (let i = 0; i < keys.length - 1; i++) {
      const key = keys[i];
      if (!current[key] || typeof current[key] !== 'object') {
        current[key] = {};
      }
      current = current[key];
    }

    // Set value
    current[keys[keys.length - 1]] = value;

    // Add to history
    this.addToHistory({
      path,
      oldValue,
      newValue: value,
      timestamp: new Date().toISOString()
    });

    // Persist if enabled
    if (persist && this.persistenceEnabled) {
      this.saveToPersistence();
    }

    // Notify subscribers
    if (notify) {
      this.notifySubscribers(path, value, oldValue);
    }
  }

  /**
   * Merge state with object
   * @param {Object} updates - Object with updates
   * @param {Object} options - Options
   */
  merge(updates, options = {}) {
    const { persist = true, notify = true } = options;

    const oldState = JSON.parse(JSON.stringify(this.state));
    
    // Deep merge
    this.deepMerge(this.state, updates);

    // Add to history
    this.addToHistory({
      type: 'MERGE',
      oldState,
      newState: JSON.parse(JSON.stringify(this.state)),
      timestamp: new Date().toISOString()
    });

    // Persist if enabled
    if (persist && this.persistenceEnabled) {
      this.saveToPersistence();
    }

    // Notify subscribers
    if (notify) {
      this.notifyAllSubscribers(this.state, oldState);
    }
  }

  /**
   * Delete state path
   * @param {string} path - Dot notation path
   * @param {Object} options - Options
   */
  delete(path, options = {}) {
    const { persist = true, notify = true } = options;

    const oldValue = this.get(path);
    const keys = path.split('.');
    
    let current = this.state;
    for (let i = 0; i < keys.length - 1; i++) {
      if (!current[keys[i]]) {return;}
      current = current[keys[i]];
    }

    delete current[keys[keys.length - 1]];

    // Add to history
    this.addToHistory({
      type: 'DELETE',
      path,
      oldValue,
      timestamp: new Date().toISOString()
    });

    // Persist if enabled
    if (persist && this.persistenceEnabled) {
      this.saveToPersistence();
    }

    // Notify subscribers
    if (notify) {
      this.notifySubscribers(path, undefined, oldValue);
    }
  }

  /**
   * Subscribe to state changes
   * @param {string} path - Path to subscribe to (null for all changes)
   * @param {Function} callback - Callback function
   * @returns {Function} Unsubscribe function
   */
  subscribe(path, callback) {
    if (!this.subscribers.has(path)) {
      this.subscribers.set(path, []);
    }

    const subscriber = {
      callback,
      id: this.generateSubscriberId(),
      subscribedAt: new Date().toISOString()
    };

    this.subscribers.get(path).push(subscriber);

    // Return unsubscribe function
    return () => this.unsubscribe(path, subscriber.id);
  }

  /**
   * Unsubscribe from state changes
   * @param {string} path - Path
   * @param {string} subscriberId - Subscriber ID
   */
  unsubscribe(path, subscriberId) {
    if (!this.subscribers.has(path)) {return;}

    const subscribers = this.subscribers.get(path);
    const index = subscribers.findIndex(s => s.id === subscriberId);
    
    if (index !== -1) {
      subscribers.splice(index, 1);
    }

    if (subscribers.length === 0) {
      this.subscribers.delete(path);
    }
  }

  /**
   * Notify subscribers of a path change
   * @param {string} path - Path that changed
   * @param {*} newValue - New value
   * @param {*} oldValue - Old value
   */
  notifySubscribers(path, newValue, oldValue) {
    // Notify exact path subscribers
    if (this.subscribers.has(path)) {
      this.subscribers.get(path).forEach(subscriber => {
        try {
          subscriber.callback(newValue, oldValue, path);
        } catch (error) {
          console.error(`StateManager: Error in subscriber for ${path}:`, error);
        }
      });
    }

    // Notify wildcard subscribers
    if (this.subscribers.has(null)) {
      this.subscribers.get(null).forEach(subscriber => {
        try {
          subscriber.callback(newValue, oldValue, path);
        } catch (error) {
          console.error('StateManager: Error in wildcard subscriber:', error);
        }
      });
    }
  }

  /**
   * Notify all subscribers (for merge operations)
   * @param {Object} newState - New state
   * @param {Object} oldState - Old state
   */
  notifyAllSubscribers(newState, oldState) {
    this.subscribers.forEach((subscribers, path) => {
      subscribers.forEach(subscriber => {
        try {
          if (path === null) {
            subscriber.callback(newState, oldState, null);
          } else {
            const newValue = this.get(path);
            const oldValue = this.getPathValue(oldState, path);
            subscriber.callback(newValue, oldValue, path);
          }
        } catch (error) {
          console.error(`StateManager: Error in subscriber for ${path}:`, error);
        }
      });
    });
  }

  /**
   * Get value from object by path
   * @param {Object} obj - Object
   * @param {string} path - Dot notation path
   * @returns {*} Value
   */
  getPathValue(obj, path) {
    const keys = path.split('.');
    let value = obj;

    for (const key of keys) {
      if (value && typeof value === 'object' && key in value) {
        value = value[key];
      } else {
        return undefined;
      }
    }

    return value;
  }

  /**
   * Deep merge objects
   * @param {Object} target - Target object
   * @param {Object} source - Source object
   */
  deepMerge(target, source) {
    for (const key in source) {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
        if (!target[key] || typeof target[key] !== 'object') {
          target[key] = {};
        }
        this.deepMerge(target[key], source[key]);
      } else {
        target[key] = source[key];
      }
    }
  }

  /**
   * Add change to history
   * @param {Object} change - Change object
   */
  addToHistory(change) {
    this.stateHistory.push(change);
    if (this.stateHistory.length > this.maxHistorySize) {
      this.stateHistory.shift();
    }
  }

  /**
   * Get state history
   * @param {number} limit - Optional limit
   * @returns {Array} History
   */
  getHistory(limit = 100) {
    return this.stateHistory.slice(-limit);
  }

  /**
   * Clear history
   */
  clearHistory() {
    this.stateHistory = [];
  }

  /**
   * Save state to persistence (localStorage)
   */
  saveToPersistence() {
    try {
      localStorage.setItem(this.persistenceKey, JSON.stringify(this.state));
    } catch (error) {
      console.error('StateManager: Failed to save state:', error);
    }
  }

  /**
   * Load state from persistence (localStorage)
   */
  loadFromPersistence() {
    try {
      const saved = localStorage.getItem(this.persistenceKey);
      if (saved) {
        const parsedState = JSON.parse(saved);
        this.merge(parsedState, { persist: false, notify: false });
      }
    } catch (error) {
      console.error('StateManager: Failed to load state:', error);
    }
  }

  /**
   * Clear persisted state
   */
  clearPersistence() {
    try {
      localStorage.removeItem(this.persistenceKey);
    } catch (error) {
      console.error('StateManager: Failed to clear persistence:', error);
    }
  }

  /**
   * Reset state to initial value
   * @param {Object} initialState - Initial state
   */
  reset(initialState = {}) {
    const oldState = JSON.parse(JSON.stringify(this.state));
    this.state = { ...initialState };
    
    this.addToHistory({
      type: 'RESET',
      oldState,
      newState: JSON.parse(JSON.stringify(this.state)),
      timestamp: new Date().toISOString()
    });

    if (this.persistenceEnabled) {
      this.saveToPersistence();
    }

    this.notifyAllSubscribers(this.state, oldState);
  }

  /**
   * Get entire state
   * @returns {Object} Complete state
   */
  getState() {
    return JSON.parse(JSON.stringify(this.state));
  }

  /**
   * Generate subscriber ID
   * @returns {string} Subscriber ID
   */
  generateSubscriberId() {
    return `sub_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Global state manager instance
const stateManager = new StateManager();

// Expose to window
if (typeof window !== 'undefined') {
  window.StateManager = StateManager;
  window.stateManager = stateManager;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { StateManager, stateManager };
}
