/**
 * Enterprise Configuration Manager
 * Centralized configuration management for StoreTrack Pro
 * Supports environment-based configs, user overrides, and runtime updates
 */

class ConfigManager {
  constructor() {
    this.config = {};
    this.defaults = {};
    this.userOverrides = {};
    this.environment = 'production';
    this.configPath = 'storetrack_config';
    this.watchers = new Map();
  }

  /**
   * Initialize configuration manager
   * @param {Object} defaultConfig - Default configuration
   * @param {string} env - Environment (development, staging, production)
   */
  initialize(defaultConfig = {}, env = 'production') {
    this.defaults = JSON.parse(JSON.stringify(defaultConfig));
    this.environment = env;
    
    // Load user overrides
    this.loadUserOverrides();
    
    // Build final config
    this.buildConfig();
  }

  /**
   * Build final configuration by merging defaults and overrides
   */
  buildConfig() {
    this.config = this.deepMerge({}, this.defaults);
    
    // Apply environment-specific overrides
    if (this.defaults[this.environment]) {
      this.config = this.deepMerge(this.config, this.defaults[this.environment]);
    }
    
    // Apply user overrides
    this.config = this.deepMerge(this.config, this.userOverrides);
  }

  /**
   * Get configuration value
   * @param {string} path - Dot notation path
   * @param {*} defaultValue - Default value
   * @returns {*} Configuration value
   */
  get(path, defaultValue = null) {
    if (!path) {return this.config;}

    const keys = path.split('.');
    let value = this.config;

    for (const key of keys) {
      if (value && typeof value === 'object' && key in value) {
        value = value[key];
      } else {
        return defaultValue;
      }
    }

    return value;
  }

  /**
   * Set configuration value (runtime override)
   * @param {string} path - Dot notation path
   * @param {*} value - Value to set
   * @param {boolean} persist - Whether to persist to user overrides
   */
  set(path, value, persist = true) {
    const keys = path.split('.');
    
    // Create nested objects if needed
    let current = this.config;
    for (let i = 0; i < keys.length - 1; i++) {
      const key = keys[i];
      if (!current[key] || typeof current[key] !== 'object') {
        current[key] = {};
      }
      current = current[key];
    }

    // Set value
    current[keys[keys.length - 1]] = value;

    // Persist to user overrides if enabled
    if (persist) {
      this.setUserOverride(path, value);
    }

    // Notify watchers
    this.notifyWatchers(path, value);
  }

  /**
   * Set user override
   * @param {string} path - Dot notation path
   * @param {*} value - Value
   */
  setUserOverride(path, value) {
    const keys = path.split('.');
    let current = this.userOverrides;
    
    for (let i = 0; i < keys.length - 1; i++) {
      const key = keys[i];
      if (!current[key] || typeof current[key] !== 'object') {
        current[key] = {};
      }
      current = current[key];
    }

    current[keys[keys.length - 1]] = value;
    this.saveUserOverrides();
  }

  /**
   * Watch configuration changes
   * @param {string} path - Path to watch
   * @param {Function} callback - Callback function
   * @returns {Function} Unwatch function
   */
  watch(path, callback) {
    if (!this.watchers.has(path)) {
      this.watchers.set(path, []);
    }

    const watcher = {
      callback,
      id: this.generateWatcherId()
    };

    this.watchers.get(path).push(watcher);

    return () => this.unwatch(path, watcher.id);
  }

  /**
   * Unwatch configuration changes
   * @param {string} path - Path
   * @param {string} watcherId - Watcher ID
   */
  unwatch(path, watcherId) {
    if (!this.watchers.has(path)) {return;}

    const watchers = this.watchers.get(path);
    const index = watchers.findIndex(w => w.id === watcherId);
    
    if (index !== -1) {
      watchers.splice(index, 1);
    }

    if (watchers.length === 0) {
      this.watchers.delete(path);
    }
  }

  /**
   * Notify watchers of changes
   * @param {string} path - Path that changed
   * @param {*} value - New value
   */
  notifyWatchers(path, value) {
    if (this.watchers.has(path)) {
      this.watchers.get(path).forEach(watcher => {
        try {
          watcher.callback(value, path);
        } catch (error) {
          console.error(`ConfigManager: Error in watcher for ${path}:`, error);
        }
      });
    }
  }

  /**
   * Load user overrides from localStorage
   */
  loadUserOverrides() {
    try {
      const saved = localStorage.getItem(this.configPath);
      if (saved) {
        this.userOverrides = JSON.parse(saved);
      }
    } catch (error) {
      console.error('ConfigManager: Failed to load user overrides:', error);
    }
  }

  /**
   * Save user overrides to localStorage
   */
  saveUserOverrides() {
    try {
      localStorage.setItem(this.configPath, JSON.stringify(this.userOverrides));
    } catch (error) {
      console.error('ConfigManager: Failed to save user overrides:', error);
    }
  }

  /**
   * Clear user overrides
   */
  clearUserOverrides() {
    this.userOverrides = {};
    this.saveUserOverrides();
    this.buildConfig();
  }

  /**
   * Reset configuration to defaults
   */
  reset() {
    this.clearUserOverrides();
    this.buildConfig();
  }

  /**
   * Get entire configuration
   * @returns {Object} Complete configuration
   */
  getAll() {
    return JSON.parse(JSON.stringify(this.config));
  }

  /**
   * Get user overrides
   * @returns {Object} User overrides
   */
  getUserOverrides() {
    return JSON.parse(JSON.stringify(this.userOverrides));
  }

  /**
   * Set environment
   * @param {string} env - Environment name
   */
  setEnvironment(env) {
    this.environment = env;
    this.buildConfig();
  }

  /**
   * Get current environment
   * @returns {string} Environment name
   */
  getEnvironment() {
    return this.environment;
  }

  /**
   * Validate configuration against schema
   * @param {Object} schema - Configuration schema
   * @returns {Object} Validation result
   */
  validate(schema) {
    const errors = [];
    
    const validateObject = (obj, schemaObj, path = '') => {
      for (const key in schemaObj) {
        const fullPath = path ? `${path}.${key}` : key;
        const value = this.get(fullPath);
        const schemaValue = schemaObj[key];

        if (schemaValue.required && value === undefined) {
          errors.push(`${fullPath} is required`);
        }

        if (schemaValue.type && value !== undefined) {
          const actualType = Array.isArray(value) ? 'array' : typeof value;
          if (actualType !== schemaValue.type) {
            errors.push(`${fullPath} should be ${schemaValue.type}, got ${actualType}`);
          }
        }

        if (schemaValue.enum && value !== undefined) {
          if (!schemaValue.enum.includes(value)) {
            errors.push(`${fullPath} should be one of ${schemaValue.enum.join(', ')}`);
          }
        }

        if (schemaValue.min !== undefined && value !== undefined && typeof value === 'number') {
          if (value < schemaValue.min) {
            errors.push(`${fullPath} should be >= ${schemaValue.min}`);
          }
        }

        if (schemaValue.max !== undefined && value !== undefined && typeof value === 'number') {
          if (value > schemaValue.max) {
            errors.push(`${fullPath} should be <= ${schemaValue.max}`);
          }
        }

        if (typeof schemaValue === 'object' && schemaValue.type !== 'object' && !schemaValue.type) {
          validateObject(value, schemaValue, fullPath);
        }
      }
    };

    validateObject(this.config, schema);

    return {
      valid: errors.length === 0,
      errors
    };
  }

  /**
   * Deep merge objects
   * @param {Object} target - Target object
   * @param {Object} source - Source object
   * @returns {Object} Merged object
   */
  deepMerge(target, source) {
    const result = { ...target };

    for (const key in source) {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
        result[key] = this.deepMerge(result[key] || {}, source[key]);
      } else {
        result[key] = source[key];
      }
    }

    return result;
  }

  /**
   * Generate watcher ID
   * @returns {string} Watcher ID
   */
  generateWatcherId() {
    return `watcher_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Global configuration manager instance
const configManager = new ConfigManager();

// Default configuration
const defaultConfig = {
  app: {
    name: 'StoreTrack Pro',
    version: '8.0.0',
    debug: false
  },
  database: {
    name: 'StoreTrackDB',
    version: 1,
    stores: ['materials', 'transactions', 'users', 'warehouses', 'scanners', 'rfid', 'printers']
  },
  scanner: {
    autoConnect: true,
    autoReconnect: true,
    reconnectDelay: 3000,
    duplicateDelay: 500,
    bufferSize: 100
  },
  rfid: {
    enabled: false,
    autoRead: false,
    bulkRead: true,
    maxTags: 1000
  },
  printing: {
    defaultPrinter: null,
    autoPrint: false,
    queueSize: 100
  },
  backup: {
    autoBackup: true,
    backupInterval: 3600000,
    maxBackups: 10,
    compression: true
  },
  sync: {
    enabled: false,
    autoSync: true,
    syncInterval: 60000
  },
  ui: {
    theme: 'dark',
    language: 'en',
    animations: true,
    highContrast: false
  },
  performance: {
    lazyLoad: true,
    virtualScroll: true,
    cacheSize: 1000
  }
};

// Initialize
configManager.initialize(defaultConfig);

// Expose to window
if (typeof window !== 'undefined') {
  window.ConfigManager = ConfigManager;
  window.configManager = configManager;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { ConfigManager, configManager, defaultConfig };
}
