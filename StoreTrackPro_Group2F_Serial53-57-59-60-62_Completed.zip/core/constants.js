/**
 * Enterprise Constants
 * Centralized constants management for StoreTrack Pro
 * All application constants should be defined here
 *
 * FIX (StoreTrack V8 core/ integration): this file originally used ES-module
 * `export const` syntax, which throws "Unexpected token 'export'" the instant
 * it's loaded via a plain <script src="core/constants.js"> tag (this app has
 * no <script type="module"> anywhere, and no bundler). That syntax error is
 * why core/ was never wired into index.html — the first script tag added
 * would have crashed the whole app on load. Every `export const X` below is
 * unchanged in content; only the `export` keyword is removed, and everything
 * is collected into a single window.CONST object at the bottom instead.
 */

// Application Constants
const APP = {
  NAME: 'StoreTrack Pro',
  VERSION: '8.0.0',
  BUILD: '2024.07.13',
  EDITION: 'Enterprise',
  MIN_NODE_VERSION: '14.0.0',
  MIN_ELECTRON_VERSION: '20.0.0'
};

// Database Constants
const DATABASE = {
  NAME: 'StoreTrackDB',
  VERSION: 1,
  STORES: {
    MATERIALS: 'materials',
    TRANSACTIONS: 'transactions',
    USERS: 'users',
    WAREHOUSES: 'warehouses',
    SCANNERS: 'scanners',
    RFID: 'rfid',
    PRINTERS: 'printers',
    BACKUPS: 'backups',
    AUDIT_TRAIL: 'auditTrail',
    NOTIFICATIONS: 'notifications',
    REPORTS: 'reports',
    SETTINGS: 'settings',
    CACHE: 'cache'
  },
  INDEXES: {
    MATERIALS: ['barcode', 'qrCode', 'rfidEpc', 'name', 'category', 'warehouse'],
    TRANSACTIONS: ['materialId', 'type', 'date', 'warehouse', 'userId'],
    USERS: ['username', 'email', 'role', 'warehouse'],
    WAREHOUSES: ['name', 'code', 'type'],
    AUDIT_TRAIL: ['userId', 'action', 'timestamp', 'module']
  },
  MAX_SIZE: 500 * 1024 * 1024,
  CACHE_SIZE: 100 * 1024 * 1024
};

// Scanner Constants
const SCANNER = {
  TYPES: {
    BARCODE: 'barcode',
    QR: 'qr',
    RFID: 'rfid',
    USB_HID: 'usb_hid',
    SERIAL: 'serial',
    BLUETOOTH: 'bluetooth',
    NETWORK: 'network',
    CAMERA: 'camera'
  },
  BARCODE_FORMATS: {
    CODE128: 'CODE128',
    CODE39: 'CODE39',
    EAN13: 'EAN13',
    EAN8: 'EAN8',
    UPC: 'UPC',
    ITF: 'ITF',
    GS1_128: 'GS1-128'
  },
  QR_FORMATS: {
    STATIC: 'static',
    DYNAMIC: 'dynamic',
    ENCRYPTED: 'encrypted',
    INVENTORY: 'inventory',
    ASSET: 'asset',
    LOCATION: 'location',
    BATCH: 'batch',
    SERIAL: 'serial'
  },
  RFID_FREQUENCIES: {
    HF: 'HF',
    UHF: 'UHF',
    NFC: 'NFC'
  },
  DEFAULTS: {
    AUTO_CONNECT: true,
    AUTO_RECONNECT: true,
    RECONNECT_DELAY: 3000,
    DUPLICATE_DELAY: 500,
    BUFFER_SIZE: 100,
    TIMEOUT: 5000
  },
  PERFORMANCE: {
    MAX_RESPONSE_TIME: 50,
    MAX_READ_RATE: 1000,
    MAX_CONCURRENT_READERS: 10
  }
};

// RFID Constants
const RFID = {
  TAG_DATA: {
    EPC: 'epc',
    UID: 'uid',
    TAG_ID: 'tagId',
    MEMORY_BANK: 'memoryBank',
    ANTENNA: 'antenna',
    SIGNAL_STRENGTH: 'signalStrength',
    READER: 'reader',
    TIMESTAMP: 'timestamp'
  },
  BULK_READ: {
    MAX_TAGS: 1000,
    TIMEOUT: 30000,
    RETRY_COUNT: 3
  },
  DEFAULTS: {
    ENABLED: false,
    AUTO_READ: false,
    BULK_READ: true,
    MAX_TAGS: 1000
  }
};

// Printing Constants
const PRINTING = {
  TYPES: {
    BARCODE: 'barcode',
    QR: 'qr',
    RFID: 'rfid',
    ASSET: 'asset',
    LOCATION: 'location',
    SHELF: 'shelf',
    BIN: 'bin',
    WAREHOUSE: 'warehouse'
  },
  PRINTERS: {
    ZEBRA: 'zebra',
    TSC: 'tsc',
    HONEYWELL: 'honeywell',
    BROTHER: 'brother',
    CITIZEN: 'citizen',
    GODEX: 'godex',
    GENERIC_THERMAL: 'generic_thermal',
    WINDOWS: 'windows',
    PDF: 'pdf'
  },
  QUEUE: {
    MAX_SIZE: 100,
    RETRY_COUNT: 3,
    RETRY_DELAY: 1000
  },
  DEFAULTS: {
    AUTO_PRINT: false,
    QUEUE_SIZE: 100
  }
};

// Backup Constants
const BACKUP = {
  TYPES: {
    MANUAL: 'manual',
    SCHEDULED: 'scheduled',
    AUTO: 'auto',
    INCREMENTAL: 'incremental',
    FULL: 'full',
    COMPRESSED: 'compressed',
    ENCRYPTED: 'encrypted'
  },
  INTERVALS: {
    HOURLY: 3600000,
    DAILY: 86400000,
    WEEKLY: 604800000,
    MONTHLY: 2592000000
  },
  DEFAULTS: {
    AUTO_BACKUP: true,
    BACKUP_INTERVAL: 3600000,
    MAX_BACKUPS: 10,
    COMPRESSION: true,
    ENCRYPTION: false
  }
};

// Sync Constants
const SYNC = {
  MODES: {
    PEER_TO_PEER: 'peer_to_peer',
    CLIENT_SERVER: 'client_server',
    MASTER_NODE: 'master_node',
    BRANCH: 'branch',
    WAREHOUSE: 'warehouse'
  },
  TYPES: {
    OFFLINE: 'offline',
    DELTA: 'delta',
    FULL: 'full',
    BACKGROUND: 'background'
  },
  DEFAULTS: {
    ENABLED: false,
    AUTO_SYNC: true,
    SYNC_INTERVAL: 60000
  }
};

// UI Constants
const UI = {
  THEMES: {
    LIGHT: 'light',
    DARK: 'dark',
    HIGH_CONTRAST: 'high_contrast',
    BLUE: 'blue',
    CORPORATE: 'corporate'
  },
  LANGUAGES: {
    ENGLISH: 'en',
    MARATHI: 'mr',
    HINDI: 'hi'
  },
  ANIMATIONS: {
    DURATION: {
      FAST: 150,
      NORMAL: 300,
      SLOW: 500
    }
  },
  BREAKPOINTS: {
    XS: 480,
    SM: 640,
    MD: 768,
    LG: 1024,
    XL: 1280,
    XXL: 1536
  },
  DEFAULTS: {
    THEME: 'dark',
    LANGUAGE: 'en',
    ANIMATIONS: true,
    HIGH_CONTRAST: false
  }
};

// Performance Constants
const PERFORMANCE = {
  TARGETS: {
    STARTUP_TIME: 2000,
    DASHBOARD_LOAD: 500,
    PAGE_NAVIGATION: 200,
    MATERIAL_SEARCH: 100,
    BARCODE_PROCESSING: 50,
    SCANNER_RESPONSE: 50,
    RFID_READ: 100,
    DUPLICATE_DETECTION: 20,
    READER_RECOVERY: 3000
  },
  CAPACITY: {
    MAX_MATERIALS: 100000,
    MAX_TRANSACTIONS: 50000,
    MAX_DAILY_SCANS: 10000,
    MAX_USERS: 10000,
    MAX_ROLES: 100,
    MAX_PERMISSIONS: 10000,
    MAX_WAREHOUSES: 100,
    MAX_LEDGER_RECORDS: 1000000
  },
  DEFAULTS: {
    LAZY_LOAD: true,
    VIRTUAL_SCROLL: true,
    CACHE_SIZE: 1000
  }
};

// Security Constants
const SECURITY = {
  SESSION: {
    TIMEOUT: 3600000,
    WARNING_TIME: 300000,
    REMEMBER_ME_DAYS: 30
  },
  PASSWORD: {
    MIN_LENGTH: 8,
    MAX_LENGTH: 128,
    REQUIRE_UPPERCASE: true,
    REQUIRE_LOWERCASE: true,
    REQUIRE_NUMBER: true,
    REQUIRE_SPECIAL: true,
    EXPIRY_DAYS: 90
  },
  TOKEN: {
    ACCESS_TOKEN_EXPIRY: 3600,
    REFRESH_TOKEN_EXPIRY: 604800
  },
  AUDIT: {
    RETENTION_DAYS: 365,
    MAX_LOGS: 100000
  }
};

// User Roles
const ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  MANAGER: 'manager',
  SUPERVISOR: 'supervisor',
  OPERATOR: 'operator',
  VIEWER: 'viewer',
  GUEST: 'guest'
};

// Permissions
const PERMISSIONS = {
  MATERIAL_VIEW: 'material.view',
  MATERIAL_CREATE: 'material.create',
  MATERIAL_EDIT: 'material.edit',
  MATERIAL_DELETE: 'material.delete',
  MATERIAL_IMPORT: 'material.import',
  MATERIAL_EXPORT: 'material.export',
  TRANSACTION_VIEW: 'transaction.view',
  TRANSACTION_CREATE: 'transaction.create',
  TRANSACTION_EDIT: 'transaction.edit',
  TRANSACTION_DELETE: 'transaction.delete',
  WAREHOUSE_VIEW: 'warehouse.view',
  WAREHOUSE_CREATE: 'warehouse.create',
  WAREHOUSE_EDIT: 'warehouse.edit',
  WAREHOUSE_DELETE: 'warehouse.delete',
  USER_VIEW: 'user.view',
  USER_CREATE: 'user.create',
  USER_EDIT: 'user.edit',
  USER_DELETE: 'user.delete',
  REPORT_VIEW: 'report.view',
  REPORT_CREATE: 'report.create',
  REPORT_EXPORT: 'report.export',
  SYSTEM_CONFIG: 'system.config',
  SYSTEM_BACKUP: 'system.backup',
  SYSTEM_RESTORE: 'system.restore',
  SYSTEM_LOGS: 'system.logs'
};

// Transaction Types
const TRANSACTION_TYPES = {
  MATERIAL_IN: 'material_in',
  MATERIAL_OUT: 'material_out',
  TRANSFER: 'transfer',
  RETURN: 'return',
  ISSUE: 'issue',
  CONSUMPTION: 'consumption',
  ADJUSTMENT: 'adjustment',
  SCRAP: 'scrap',
  REPAIR: 'repair',
  CALIBRATION: 'calibration',
  LOAN: 'loan',
  RESERVATION: 'reservation'
};

// Material Status
const MATERIAL_STATUS = {
  AVAILABLE: 'available',
  RESERVED: 'reserved',
  ISSUED: 'issued',
  DAMAGED: 'damaged',
  EXPIRED: 'expired',
  IN_TRANSIT: 'in_transit',
  UNDER_REPAIR: 'under_repair',
  SCRAPPED: 'scrapped'
};

// ABC Classification
const ABC_CLASSIFICATION = {
  A: 'A',
  B: 'B',
  C: 'C'
};

// XYZ Classification
const XYZ_CLASSIFICATION = {
  X: 'X',
  Y: 'Y',
  Z: 'Z'
};

// Notification Types
const NOTIFICATION_TYPES = {
  INFO: 'info',
  SUCCESS: 'success',
  WARNING: 'warning',
  ERROR: 'error',
  CRITICAL: 'critical',
  APPROVAL: 'approval',
  REMINDER: 'reminder',
  TASK: 'task',
  INVENTORY_ALERT: 'inventory_alert',
  SCANNER_ALERT: 'scanner_alert',
  RFID_ALERT: 'rfid_alert',
  PRINTER_ALERT: 'printer_alert',
  DATABASE_ALERT: 'database_alert',
  BACKUP_ALERT: 'backup_alert',
  SECURITY_ALERT: 'security_alert',
  LICENSE_ALERT: 'license_alert',
  SYSTEM_ALERT: 'system_alert'
};

// Notification Priority
const NOTIFICATION_PRIORITY = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
  URGENT: 'urgent'
};

// Error Codes
const ERROR_CODES = {
  UNKNOWN_ERROR: 'ERR_0000',
  VALIDATION_ERROR: 'ERR_0001',
  PERMISSION_DENIED: 'ERR_0002',
  NOT_FOUND: 'ERR_0003',
  CONFLICT: 'ERR_0004',
  DATABASE_ERROR: 'ERR_1000',
  DATABASE_CONNECTION_ERROR: 'ERR_1001',
  DATABASE_QUERY_ERROR: 'ERR_1002',
  SCANNER_ERROR: 'ERR_2000',
  SCANNER_NOT_FOUND: 'ERR_2001',
  SCANNER_CONNECTION_ERROR: 'ERR_2002',
  RFID_ERROR: 'ERR_3000',
  RFID_NOT_FOUND: 'ERR_3001',
  RFID_CONNECTION_ERROR: 'ERR_3002',
  PRINTING_ERROR: 'ERR_4000',
  PRINTER_NOT_FOUND: 'ERR_4001',
  PRINTING_CONNECTION_ERROR: 'ERR_4002',
  BACKUP_ERROR: 'ERR_5000',
  BACKUP_CREATION_ERROR: 'ERR_5001',
  BACKUP_RESTORE_ERROR: 'ERR_5002'
};

// HTTP Status Codes
const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  INTERNAL_SERVER_ERROR: 500,
  SERVICE_UNAVAILABLE: 503
};

// File Extensions
const FILE_EXTENSIONS = {
  EXCEL: ['.xlsx', '.xls'],
  CSV: ['.csv'],
  PDF: ['.pdf'],
  JSON: ['.json'],
  IMAGES: ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg'],
  DOCUMENTS: ['.doc', '.docx', '.txt']
};

// Collect all constants into one object
const CONST = {
  APP,
  DATABASE,
  SCANNER,
  RFID,
  PRINTING,
  BACKUP,
  SYNC,
  UI,
  PERFORMANCE,
  SECURITY,
  ROLES,
  PERMISSIONS,
  TRANSACTION_TYPES,
  MATERIAL_STATUS,
  ABC_CLASSIFICATION,
  XYZ_CLASSIFICATION,
  NOTIFICATION_TYPES,
  NOTIFICATION_PRIORITY,
  ERROR_CODES,
  HTTP_STATUS,
  FILE_EXTENSIONS
};

// Expose to window (same pattern as the other core/*.js singletons)
if (typeof window !== 'undefined') {
  window.CONST = CONST;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CONST;
}
