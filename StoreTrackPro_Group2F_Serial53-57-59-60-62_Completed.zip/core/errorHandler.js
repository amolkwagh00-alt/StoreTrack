/**
 * Enterprise Error Handler
 * Centralized error handling system for StoreTrack Pro
 * Provides consistent error handling, logging, and user feedback
 */

class ErrorHandler {
  constructor() {
    this.errorLog = [];
    this.maxLogSize = 1000;
    this.errorHandlers = new Map();
    this.globalErrorHandler = null;
    this.userFeedbackEnabled = true;
  }

  /**
   * Initialize error handler
   * @param {Object} options - Configuration options
   */
  initialize(options = {}) {
    this.userFeedbackEnabled = options.userFeedback !== false;
    this.setupGlobalErrorHandlers();
  }

  /**
   * Setup global error handlers
   */
  setupGlobalErrorHandlers() {
    // Handle uncaught errors
    if (typeof window !== 'undefined') {
      window.addEventListener('error', (event) => {
        this.handleError(event.error || new Error(event.message), {
          type: 'uncaught',
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno
        });
      });

      window.addEventListener('unhandledrejection', (event) => {
        this.handleError(event.reason, {
          type: 'unhandled_rejection',
          promise: event.promise
        });
      });
    }
  }

  /**
   * Handle an error
   * @param {Error} error - Error object
   * @param {Object} context - Additional context
   * @returns {Object} Error result
   */
  handleError(error, context = {}) {
    const errorInfo = this.createErrorInfo(error, context);
    
    // Log error
    this.logError(errorInfo);
    
    // Notify handlers
    this.notifyHandlers(errorInfo);
    
    // Show user feedback if enabled (unless the caller already has its own
    // UI for this error and explicitly opts out via context.silent — e.g.
    // the login form shows its own inline error message)
    if (this.userFeedbackEnabled && !context.silent) {
      this.showUserFeedback(errorInfo);
    }
    
    return errorInfo;
  }

  /**
   * Create error info object
   * @param {Error} error - Error object
   * @param {Object} context - Additional context
   * @returns {Object} Error info
   */
  createErrorInfo(error, context = {}) {
    return {
      id: this.generateErrorId(),
      message: error?.message || 'Unknown error',
      stack: error?.stack,
      name: error?.name || 'Error',
      code: error?.code,
      context,
      timestamp: new Date().toISOString(),
      severity: this.determineSeverity(error, context),
      userMessage: this.getUserMessage(error, context)
    };
  }

  /**
   * Determine error severity
   * @param {Error} error - Error object
   * @param {Object} context - Context
   * @returns {string} Severity level
   */
  determineSeverity(error, context) {
    if (context.type === 'uncaught' || context.type === 'unhandled_rejection') {
      return 'critical';
    }
    
    if (error?.name === 'SecurityError' || error?.name === 'NetworkError') {
      return 'high';
    }
    
    if (context.severity) {
      return context.severity;
    }
    
    return 'medium';
  }

  /**
   * Get user-friendly message
   * @param {Error} error - Error object
   * @param {Object} context - Context
   * @returns {string} User message
   */
  getUserMessage(error, context) {
    if (context.userMessage) {
      return context.userMessage;
    }
    const operation = String(context.operation || context.type || '').toLowerCase();
    const operationAdvice = {
      login: 'Check your username and password, then try again. If you are locked out, ask an administrator to reset access.',
      save: 'Your changes may not have been saved. Check the record, then retry once; verify it before repeating a stock-changing action.',
      delete: 'The record was not confirmed as deleted. Refresh the list and verify its status before trying again.',
      import: 'No import success is confirmed. Review the preview and validation errors, correct the source file, then retry.',
      export: 'The export may not have completed. Check the destination and available disk space, then retry.',
      sync: 'Your local changes remain available. Check the connection and sync status, then retry the queued item when online.',
      print: 'Check that the printer is connected and available, then reopen the print preview and try again.',
      scan: 'Check scanner connection and barcode readability, then scan again; verify the item before changing stock.',
      restore: 'Restore was not confirmed as complete. Do not repeat it until the recovery status is checked; contact an administrator if it remains pending.'
    };
    if (operationAdvice[operation]) { return operationAdvice[operation]; }
    
    const errorMessages = {
      'NetworkError': 'Network connection failed. Please check your internet connection.',
      'SecurityError': 'Security error occurred. Please contact administrator.',
      'ValidationError': 'Invalid input. Please check your data.',
      'NotFoundError': 'Requested resource not found.',
      'PermissionError': 'You do not have permission to perform this action.',
      'DatabaseError': 'Database error occurred. Please try again.',
      'ScannerError': 'Scanner error occurred. Please check scanner connection.',
      'PrintingError': 'Printing error occurred. Please check printer connection.'
    };
    
    if (errorMessages[error?.name]) { return errorMessages[error.name]; }
    if (error?.name === 'NetworkError' || /network|fetch failed|failed to fetch/i.test(String(error?.message || ''))) {
      return 'The connection failed. Check your network and server status, then retry when online.';
    }
    if (/quota|disk full|not enough space/i.test(String(error?.message || ''))) {
      return 'There is not enough storage space. Free space or choose another destination, then retry.';
    }
    return 'The operation could not be confirmed. Check whether it completed before retrying; contact an administrator if the problem continues.';
  }

  /**
   * Log error
   * @param {Object} errorInfo - Error info
   */
  logError(errorInfo) {
    this.errorLog.push(errorInfo);
    
    if (this.errorLog.length > this.maxLogSize) {
      this.errorLog.shift();
    }
    
    // Log to console
    console.error(`[${errorInfo.severity.toUpperCase()}]`, errorInfo);
    
    // Emit error event if event bus is available
    if (typeof window !== 'undefined' && window.eventBus) {
      window.eventBus.emit('ERROR_OCCURRED', errorInfo);
    }
  }

  /**
   * Notify error handlers
   * @param {Object} errorInfo - Error info
   */
  notifyHandlers(errorInfo) {
    // Call global handler
    if (this.globalErrorHandler) {
      try {
        this.globalErrorHandler(errorInfo);
      } catch (e) {
        console.error('Error in global error handler:', e);
      }
    }
    
    // Call specific handlers
    this.errorHandlers.forEach((handler) => {
      try {
        handler(errorInfo);
      } catch (e) {
        console.error('Error in error handler:', e);
      }
    });
  }

  /**
   * Show user feedback
   * @param {Object} errorInfo - Error info
   */
  showUserFeedback(errorInfo) {
    if (typeof window === 'undefined') {return;}
    
    // Create toast notification
    if (window.showToast) {
      const type = this.getToastType(errorInfo.severity);
      window.showToast(errorInfo.userMessage, type);
    }
    
    // Emit notification event
    if (window.eventBus) {
      window.eventBus.emit('NOTIFICATION_SHOW', {
        type: errorInfo.severity,
        message: errorInfo.userMessage,
        errorId: errorInfo.id
      });
    }
  }

  /**
   * Get toast type from severity
   * @param {string} severity - Severity level
   * @returns {string} Toast type
   */
  getToastType(severity) {
    const types = {
      critical: 'error',
      high: 'error',
      medium: 'warning',
      low: 'info'
    };
    return types[severity] || 'error';
  }

  /**
   * Register error handler
   * @param {Function} handler - Handler function
   * @returns {Function} Unregister function
   */
  registerHandler(handler) {
    const id = this.generateHandlerId();
    this.errorHandlers.set(id, handler);
    
    return () => this.unregisterHandler(id);
  }

  /**
   * Unregister error handler
   * @param {string} id - Handler ID
   */
  unregisterHandler(id) {
    this.errorHandlers.delete(id);
  }

  /**
   * Set global error handler
   * @param {Function} handler - Handler function
   */
  setGlobalHandler(handler) {
    this.globalErrorHandler = handler;
  }

  /**
   * Get error log
   * @param {Object} filters - Optional filters
   * @returns {Array} Error log
   */
  getErrorLog(filters = {}) {
    let log = [...this.errorLog];
    
    if (filters.severity) {
      log = log.filter(e => e.severity === filters.severity);
    }
    
    if (filters.type) {
      log = log.filter(e => e.context.type === filters.type);
    }
    
    if (filters.since) {
      log = log.filter(e => new Date(e.timestamp) >= new Date(filters.since));
    }
    
    if (filters.limit) {
      log = log.slice(-filters.limit);
    }
    
    return log;
  }

  /**
   * Clear error log
   */
  clearErrorLog() {
    this.errorLog = [];
  }

  /**
   * Get error statistics
   * @returns {Object} Statistics
   */
  getStatistics() {
    const stats = {
      total: this.errorLog.length,
      bySeverity: {},
      byType: {},
      recent: this.errorLog.slice(-10)
    };
    
    this.errorLog.forEach(error => {
      stats.bySeverity[error.severity] = (stats.bySeverity[error.severity] || 0) + 1;
      stats.byType[error.context.type || 'unknown'] = (stats.byType[error.context.type || 'unknown'] || 0) + 1;
    });
    
    return stats;
  }

  /**
   * Wrap async function with error handling
   * @param {Function} fn - Async function
   * @param {Object} context - Optional context
   * @returns {Function} Wrapped function
   */
  wrapAsync(fn, context = {}) {
    return async (...args) => {
      try {
        return await fn(...args);
      } catch (error) {
        this.handleError(error, context);
        throw error;
      }
    };
  }

  /**
   * Wrap sync function with error handling
   * @param {Function} fn - Function
   * @param {Object} context - Optional context
   * @returns {Function} Wrapped function
   */
  wrap(fn, context = {}) {
    return (...args) => {
      try {
        return fn(...args);
      } catch (error) {
        this.handleError(error, context);
        throw error;
      }
    };
  }

  /**
   * Create custom error
   * @param {string} message - Error message
   * @param {string} code - Error code
   * @param {Object} context - Additional context
   * @returns {Error} Custom error
   */
  createError(message, code = null, context = {}) {
    const error = new Error(message);
    error.code = code;
    error.context = context;
    return error;
  }

  /**
   * Generate error ID
   * @returns {string} Error ID
   */
  generateErrorId() {
    return `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Generate handler ID
   * @returns {string} Handler ID
   */
  generateHandlerId() {
    return `handler_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Global error handler instance
const errorHandler = new ErrorHandler();

// Expose to window
if (typeof window !== 'undefined') {
  window.ErrorHandler = ErrorHandler;
  window.errorHandler = errorHandler;
}

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { ErrorHandler, errorHandler };
}
