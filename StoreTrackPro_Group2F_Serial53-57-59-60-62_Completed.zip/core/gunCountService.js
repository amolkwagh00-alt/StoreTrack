/* Canonical Gun Count service shared by renderer and central API. */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) {module.exports = factory();}
  else {root.GunCountService = factory();}
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  const CALCULATION_VERSION = 'gun-count-v3-source-only';
  const normalize = value => String(value == null ? '' : value).trim();
  const stableSerialize = value => {
    if (value == null || typeof value !== 'object') {return JSON.stringify(value);}
    if (Array.isArray(value)) {return '[' + value.map(stableSerialize).join(',') + ']';}
    return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stableSerialize(value[k])).join(',') + '}';
  };
  const stableHash = value => {
    const input = stableSerialize(value);
    let h = 2166136261;
    for (let i = 0; i < input.length; i += 1) { h ^= input.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(16).padStart(8, '0');
  };
  function validOccurrence(row, mapped = false) {
    if (!row || typeof row !== 'object') {return false;}
    const gun = normalize(row.gunReferenceNo);
    if (mapped) {return Boolean(normalize(row.stationNo) && normalize(row.stationNo) !== 'Station Not Assigned' && gun);}
    return Boolean(normalize(row.sourceKey) || normalize(row.sourceFile) || row.sourceRow != null || gun);
  }
  function occurrenceKey(row, index) { return normalize(row.sourceKey) || `${normalize(row.sourceFile)}:${normalize(row.sourceSheet)}:${normalize(row.sourceRow) || index}`; }
  function gunIdentityKey(row, index) {
    const station = normalize(row?.stationNo), gun = normalize(row?.gunReferenceNo);
    if (station && station !== 'Station Not Assigned' && gun) {return `gun:${station.toLowerCase()}\u001f${gun.toLowerCase()}`;}
    return `source:${occurrenceKey(row, index)}`;
  }
  function uniqueGunOccurrences(rows, mapped = false) {
    const seen = new Set(), result = [];
    (Array.isArray(rows) ? rows : []).forEach((row, index) => {
      if (!validOccurrence(row, mapped)) {return;}
      const key = gunIdentityKey(row, index);
      if (seen.has(key)) {return;}
      seen.add(key); result.push(row);
    });
    return result;
  }
  function uniqueOccurrences(rows, mapped = false) {
    const seen = new Set(), result = [];
    (Array.isArray(rows) ? rows : []).forEach((row, index) => {
      if (!validOccurrence(row, mapped)) {return;}
      const key = occurrenceKey(row, index);
      if (seen.has(key)) {return;}
      seen.add(key); result.push(row);
    });
    return result;
  }
  const COMPONENT_FIELDS = ['fixShank', 'movingShank', 'fixAdaptor', 'movingAdaptor', 'fixHolder', 'movingHolder'];
  function hasActualPart(value) {
    const text = normalize(value).toUpperCase();
    return Boolean(text && text !== 'NA' && text !== 'N/A' && text !== '-');
  }
  function isCountableSourceRow(row) {
    if (!row || typeof row !== 'object') {return false;}
    // A source-only row is still a real source Gun occurrence; blank component
    // columns must not hide it from the Unassigned / Source-only dashboard.
    if (row.sourceOnly) {return true;}
    const hasComponentSchema = COMPONENT_FIELDS.some(field => Object.prototype.hasOwnProperty.call(row, field)) || row.boldParts && typeof row.boldParts === 'object';
    if (!hasComponentSchema) {return true;}
    return COMPONENT_FIELDS.some(field => hasActualPart(row[field]) || Array.isArray(row.boldParts?.[field]) && row.boldParts[field].some(hasActualPart));
  }
  function countableSourceRows(rows) {
    return (Array.isArray(rows) ? rows : []).filter(row => validOccurrence(row, false) && isCountableSourceRow(row));
  }
  function calculateGunCount(rows, mapped = false) {
    if (typeof rows === 'number' && Number.isFinite(rows)) {return Math.max(0, Math.floor(rows));}
    if (rows instanceof Set) {return rows.size;}
    if (!mapped) {return countableSourceRows(rows).length;}
    return uniqueGunOccurrences(rows, mapped).length;
  }
  function calculationFingerprint(sourceRows, mappingRows) {
    const source = uniqueGunOccurrences(sourceRows, false).map(r => ({ stationNo: normalize(r.stationNo), gunReferenceNo: normalize(r.gunReferenceNo), sourceKey: normalize(r.sourceKey), sourceOnly: Boolean(r.sourceOnly) })).sort((a,b) => stableSerialize(a).localeCompare(stableSerialize(b)));
    const mapping = uniqueGunOccurrences(mappingRows, true).map(r => ({ stationNo: normalize(r.stationNo), gunReferenceNo: normalize(r.gunReferenceNo), binId: normalize(r.binId), sourceKey: normalize(r.sourceKey) })).sort((a,b) => stableSerialize(a).localeCompare(stableSerialize(b)));
    return { calculationVersion: CALCULATION_VERSION, sourceHash: stableHash(source), mappingHash: stableHash(mapping) };
  }
  function calculateMetrics(sourceRows, mappingRows) {
    const source = countableSourceRows(sourceRows);
    const mapped = uniqueGunOccurrences(mappingRows, true);
    const allocated = mapped.filter(row => normalize(row.binId));
    const unassigned = source.filter(row => !normalize(row.stationNo) || normalize(row.stationNo) === 'Station Not Assigned' || row.sourceOnly);
    const sourceCount = source.length, mappedCount = mapped.length, allocatedCount = allocated.length, unassignedCount = unassigned.length;
    const stations = new Map();
    source.forEach(row => { const station = normalize(row.stationNo); if (!station || station === 'Station Not Assigned') {return;} const key = station.toLowerCase(); if (!stations.has(key)) {stations.set(key, { stationNo: station, gunCount: 0 });} stations.get(key).gunCount += 1; });
    return { source: sourceCount, mapped: mappedCount, allocated: allocatedCount, unassigned: unassignedCount, total: sourceCount, stations: [...stations.values()].sort((a,b) => a.stationNo.localeCompare(b.stationNo)), reconciliation: { balanced: sourceCount === mappedCount && mappedCount === allocatedCount && unassignedCount === 0, sourceMinusMapped: sourceCount - mappedCount, mappedMinusAllocated: mappedCount - allocatedCount }, ...calculationFingerprint(sourceRows, mappingRows), calculatedAt: new Date().toISOString() };
  }
  function assertPhysicalVerificationInvariant(sourceRows, mappingRows, physicalRows, expectedGunCount) {
    const before = Number.isFinite(expectedGunCount) ? expectedGunCount : calculateMetrics(sourceRows, mappingRows).total;
    const after = calculateMetrics(sourceRows, mappingRows).total;
    if (before !== after) {throw new Error(`Gun Count changed during physical verification: ${before} -> ${after}`);}
    return { ok: true, gunCount: before, physicalRows: Array.isArray(physicalRows) ? physicalRows.length : 0 };
  }
  async function persistAggregate({ gAll, dPut, dClr, sourceRows, mappingRows, store = 'component_gun_counts', existingRows = null }) {
    if (typeof gAll !== 'function' || typeof dPut !== 'function' || typeof dClr !== 'function') {throw new Error('Gun Count persistence requires database functions');}
    const metrics = calculateMetrics(sourceRows, mappingRows);
    const previous = Array.isArray(existingRows) ? existingRows.find(x => x && x.id === 'global') : null;
    const unchanged = previous && previous.calculationVersion === metrics.calculationVersion && previous.sourceHash === metrics.sourceHash && previous.mappingHash === metrics.mappingHash && previous.gunCount === metrics.total && previous.mappedGunCount === metrics.mapped && previous.allocatedGunCount === metrics.allocated && previous.unassignedGunCount === metrics.unassigned;
    if (unchanged) {return { ...metrics, persisted: false, unchanged: true };}
    await dClr(store);
    await dPut(store, { id: 'global', scope: 'GLOBAL', gunCount: metrics.total, sourceGunCount: metrics.source, mappedGunCount: metrics.mapped, allocatedGunCount: metrics.allocated, unassignedGunCount: metrics.unassigned, reconciliation: metrics.reconciliation, calculationVersion: metrics.calculationVersion, sourceHash: metrics.sourceHash, mappingHash: metrics.mappingHash, calculatedAt: metrics.calculatedAt });
    for (const station of metrics.stations) {await dPut(store, { id: `station:${station.stationNo}`.replace(/[^A-Za-z0-9:_-]/g, '_'), scope: 'STATION', stationNo: station.stationNo, gunCount: station.gunCount, calculationVersion: metrics.calculationVersion, sourceHash: metrics.sourceHash, mappingHash: metrics.mappingHash, calculatedAt: metrics.calculatedAt });}
    return { ...metrics, persisted: true, unchanged: false };
  }
  return { CALCULATION_VERSION, calculateGunCount, calculateMetrics, calculationFingerprint, stableHash, assertPhysicalVerificationInvariant, uniqueOccurrences, uniqueGunOccurrences, validOccurrence, isCountableSourceRow, countableSourceRows, persistAggregate };
});
