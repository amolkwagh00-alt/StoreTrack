/* Shared Part Number matching/display rules. Stored values are never mutated. */
(function (global) {
  'use strict';

  function normalizePartNo(value) {
    const raw = value == null ? '' : String(value).trim();
    if (!raw) {return '';}
    return raw
      .replace(/\s+/g, '')
      .split(/([\/-])/)
      .map((segment) => /^\d+$/.test(segment) ? segment.replace(/^0+(?=\d)/, '') : segment.toUpperCase())
      .join('');
  }

  function partKey(value) {
    return normalizePartNo(value).toLowerCase();
  }

  function samePartNo(a, b) {
    const left = partKey(a);
    return Boolean(left) && left === partKey(b);
  }

  function hasDuplicatePartNo(partNo, materials, currentId) {
    const key = partKey(partNo);
    if (!key) {return false;}
    return (materials || []).some((material) =>
      String(material?.id ?? '') !== String(currentId ?? '') && partKey(material?.hsn) === key,
    );
  }

  function findVariantPairs(values) {
    const groups = new Map();
    (values || []).map((value) => String(value == null ? '' : value).trim()).filter(Boolean).forEach((value) => { const key = partKey(value); if (!groups.has(key)) {groups.set(key, []);} if (!groups.get(key).includes(value)) {groups.get(key).push(value);} });
    return [...groups.values()].filter((variants) => variants.length > 1).map((variants) => ({ key: partKey(variants[0]), variants }));
  }

  function displayPartNo(values) {
    const list = Array.isArray(values) ? values : [values];
    return [...new Set(list.map((value) => String(value == null ? '' : value).trim()).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }))
      .join(' / ');
  }

  global.PartNumberUtils = { normalizePartNo, partKey, samePartNo, hasDuplicatePartNo, displayPartNo, findVariantPairs };
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { normalizePartNo, partKey, samePartNo, hasDuplicatePartNo, displayPartNo, findVariantPairs };
  }
})(typeof window !== 'undefined' ? window : globalThis);
