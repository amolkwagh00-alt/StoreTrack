# StoreTrack — Stock status and reorder update

## Shank Mapping stock-status consolidation

Shank Mapping uses one detailed Stock Status table for Zero Stock, Below Required Qty, and OK. The separate Low Stock screen was consolidated into that table with the Below Required filter preselected. The existing Zero Stock List entry was relabeled Stock Status because it remains the full searchable table, not a duplicate.

The full Low / Zero Stock Alert table was removed from the Dashboard while summary counts and direct links were retained. The unused dashboard table filter, old grouped Low/Zero rendering path, and obsolete `stock('low')` / `stock('zero')` branches were removed. Stock receiving, imports, physical verification, calculations, transaction drill-down, and report/export helpers remain available. The old Low Stock navigation key remains as an alias to prevent stale links from breaking.

## Main Store Low Alert and reorder quantity

`Low Alert` is now the stock target. An item is Low only when available stock is below that target; stock exactly at the target is OK. Zero stock remains visible as an out-of-stock alert, including when the configured target is zero.

Suggested Order Qty is calculated as `max(0, Low Alert − Current Stock)`. The Reorder screen, generated PO draft, low-stock views, exports, and material details use this calculated gap instead of a manually stored batch quantity. The material form now explains that quantity is automatic. Legacy stored/imported reorder values remain tolerated for compatibility but no longer determine PO quantities. The supplier filter applies to Reorder candidates, Select All, PO generation, and the Reorder export.

## Verification

All 43 Jest suites passed (427 tests), including regression coverage for exact-target status, shortage calculations, zero stock, inactive materials, supplier filtering, and calculated PO quantities. JavaScript syntax checks passed for the edited source files.
