# StoreTrack Pro — Clean Database Login

## First-run credentials

When the local IndexedDB database contains no users, the application creates these two bootstrap accounts:

| Username | Bootstrap password | Role |
|---|---|---|
| `admin` | `Admin@1234` | Administrator |
| `store` | `Store@1234` | Store User |

The login screen displays these credentials once during that first initialization. Both accounts are marked `mustChangePassword`, so the user is redirected to **Settings** and must set a new password immediately after signing in.

## Clean reset procedure

1. Close every StoreTrack Pro window and process.
2. Delete the application data directory for the current Windows user, or clear the StoreTrack IndexedDB database from the application’s developer tools. Do this only for a disposable/reset environment because it removes local data.
3. Start the project with `npm start`.
4. Sign in with `admin` / `Admin@1234`.
5. Complete the mandatory password change in **Settings**.
6. Sign out and sign in again using the new password.

## Important distinction: local app vs Central Server

`npm start` launches the Electron desktop client and uses local IndexedDB. The PostgreSQL Central Server has a separate administrator bootstrap flow. For the server, create an administrator explicitly:

```bat
set ADMIN_USERNAME=admin
set ADMIN_PASSWORD=replace-with-a-strong-password
npm run central:create-admin
```

Do not use the local Electron bootstrap password for the PostgreSQL server administrator.

## What was fixed

The clean-database seed no longer generates a random password that is visible only in the developer console. It now uses the documented first-run credentials above, displays them in the login screen during initialization, and retains the mandatory first-login password change.
