/* exported detectSections */
const { app, BrowserWindow, Menu, ipcMain, dialog, Tray, Notification, nativeImage, session, shell, safeStorage } = require('electron');
const path   = require('path');
const fs     = require('fs');
const os     = require('os');
const crypto = require('crypto');
const { pathToFileURL } = require('url');
const { FORMAT: ENCRYPTED_BACKUP_FORMAT, ALGORITHM: ENCRYPTED_BACKUP_ALGORITHM, encryptBackup, decryptBackup } = require('./modules/secureBackup');
// PBKDF2-based password hashing — secure, pure JS, no Visual Studio required
function pbkdf2Hash(password) {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16).toString('hex');
    crypto.pbkdf2(password, salt, 100000, 64, 'sha512', (err, key) => {
      if (err) {reject(err);}
      else {resolve('$pbkdf2$' + salt + '$' + key.toString('hex'));}
    });
  });
}
function pbkdf2Verify(password, storedHash) {
  return new Promise((resolve, reject) => {
    if (!storedHash || !storedHash.startsWith('$pbkdf2$')) { resolve(false); return; }
    const parts = storedHash.split('$');
    const salt = parts[2]; const hash = parts[3];
    crypto.pbkdf2(password, salt, 100000, 64, 'sha512', (err, key) => {
      if (err) {reject(err);}
      else {
        const actual = key.toString('hex');
        const a = Buffer.from(actual, 'utf8');
        const b = Buffer.from(hash, 'utf8');
        resolve(a.length === b.length && crypto.timingSafeEqual(a, b));
      }
    });
  });
}
const QRCode = require('qrcode');  // QR generation in main process (node-side)
const WebSocket = require('ws');

let centralConfig = { baseUrl: '', token: '', user: null, lastSequence: 0, socket: null };
let centralReconnectTimer = null;
let centralReconnectAttempt = 0;
let centralSocketGeneration = 0;

function canonicalAppUrl() { return pathToFileURL(path.resolve(__dirname, 'index.html')).href; }
function isCanonicalAppUrl(value) {
  try { return new URL(value).href === canonicalAppUrl(); } catch (_) { return false; }
}
function shouldAllowMainNavigation(value) { return isCanonicalAppUrl(value); }
function reconnectDelay(attempt, random = Math.random) {
  const base = Math.min(60000, 3000 * (2 ** Math.min(Math.max(0, attempt), 5)));
  return Math.min(60000, Math.round(base * (0.8 + random() * 0.4)));
}
function cancelCentralReconnect() {
  if (centralReconnectTimer) { clearTimeout(centralReconnectTimer); centralReconnectTimer = null; }
}
function resetCentralStream({ clearCredentials = false } = {}) {
  cancelCentralReconnect();
  centralReconnectAttempt = 0;
  centralSocketGeneration++;
  const oldSocket = centralConfig.socket;
  centralConfig.socket = null;
  if (clearCredentials) { centralConfig.token = ''; centralConfig.user = null; }
  if (oldSocket) { try { oldSocket.close(); } catch (_) {} }
}
function isTerminalSocketAuthError(code, reason = '') {
  return [1008, 4001, 4003, 4401, 4403].includes(Number(code)) || /unauthori[sz]ed|forbidden|invalid token|token expired|authentication/i.test(String(reason));
}

function validateCentralServiceUrl(value, environment = process.env.NODE_ENV) {
  let url;
  try { url = new URL(value); } catch (_) { throw new TypeError('Central server URL must be a valid HTTP or HTTPS URL'); }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) {
    throw new TypeError('Central server URL must use HTTP or HTTPS without embedded credentials');
  }
  if (url.protocol === 'http:') {
    const hostname = url.hostname.toLowerCase().replace(/^\[|\]$/g, '');
    const loopback = hostname === 'localhost' || hostname === '::1' || /^127(?:\.\d{1,3}){3}$/.test(hostname);
    if (environment !== 'development' || !loopback) {
      throw new TypeError('Central server HTTP is permitted only for loopback development; use HTTPS');
    }
  }
  return url.href.replace(/\/$/, '');
}

function centralUrl(pathname) {
  if (!centralConfig.baseUrl) {throw new Error('Central server is not configured');}
  return `${centralConfig.baseUrl.replace(/\/$/, '')}${pathname}`;
}

async function centralRequest(pathname, options = {}) {
  validateCentralServiceUrl(centralConfig.baseUrl);
  const headers = { 'content-type': 'application/json', ...(options.headers || {}) };
  if (centralConfig.token) {headers.authorization = `Bearer ${centralConfig.token}`;}
  const response = await fetch(centralUrl(pathname), { ...options, headers });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {throw Object.assign(new Error(body.error || `Central server returned ${response.status}`), { statusCode: response.status, body });}
  return body;
}

function centralWsUrl() {
  const url = centralUrl('/api/sync/stream');
  return url.replace(/^http:/, 'ws:').replace(/^https:/, 'wss:');
}

function connectCentralStream() {
  if (!centralConfig.token || !centralConfig.baseUrl || centralConfig.socket) {return;}
  validateCentralServiceUrl(centralConfig.baseUrl);
  cancelCentralReconnect();
  const generation = centralSocketGeneration;
  const socket = new WebSocket(centralWsUrl(), { headers: { authorization: `Bearer ${centralConfig.token}` } });
  centralConfig.socket = socket;
  let stableTimer = null;
  socket.on('open', () => { stableTimer = setTimeout(() => { if (generation === centralSocketGeneration) {centralReconnectAttempt = 0;} }, 30000); });
  socket.on('message', raw => { try { const event = JSON.parse(raw.toString()); if (event.event?.sequence) {centralConfig.lastSequence = Math.max(centralConfig.lastSequence, Number(event.event.sequence));} if (mainWindow) {mainWindow.webContents.send('central:event', event);} } catch (error) { console.error('[Central sync event]', error.message); } });
  socket.on('close', (code, reasonBuffer) => {
    if (stableTimer) {clearTimeout(stableTimer);}
    if (generation !== centralSocketGeneration) {return;}
    if (centralConfig.socket === socket) {centralConfig.socket = null;}
    const reason = reasonBuffer?.toString?.() || '';
    if (!centralConfig.token || !centralConfig.baseUrl || isTerminalSocketAuthError(code, reason)) {cancelCentralReconnect(); return;}
    const delay = reconnectDelay(centralReconnectAttempt++);
    centralReconnectTimer = setTimeout(() => { centralReconnectTimer = null; if (generation === centralSocketGeneration) {connectCentralStream();} }, delay);
  });
  socket.on('unexpected-response', (_request, response) => {
    if ([401, 403].includes(Number(response?.statusCode)) && generation === centralSocketGeneration) {
      resetCentralStream({ clearCredentials: true });
      try { socket.terminate(); } catch (_) {}
    }
  });
  socket.on('error', error => console.error('[Central WebSocket]', error.message));
}

// All privileged IPC calls must originate from the application renderer.  This
// prevents future navigation/popup regressions from turning the bridge into a
// general-purpose filesystem and device-control API.
function assertTrustedSender(event) {
  const url = event?.senderFrame?.url || '';
  if (mainWindow && event.sender !== mainWindow.webContents) {
    throw new Error('IPC sender is not the primary application window');
  }
  if (!event?.senderFrame || event.senderFrame !== event.sender?.mainFrame || !isCanonicalAppUrl(url)) {
    throw new Error('Untrusted IPC sender');
  }
}

function assertString(value, name, maxLength = 10 * 1024 * 1024) {
  if (typeof value !== 'string' || value.length > maxLength) {
    throw new TypeError(`${name} must be a string under ${maxLength} characters`);
  }
  return value;
}

function assertApprovedInputPath(filePath) {
  assertString(filePath, 'filePath', 4096);
  const resolved = path.resolve(filePath);
  const roots = [dataDir, app.getPath('downloads')].map(p => path.resolve(p));
  const approved = roots.some(root => resolved === root || resolved.startsWith(root + path.sep));
  if (!approved) {throw new Error('Path is outside an approved directory');}
  return resolved;
}

function secureHandle(channel, handler) {
  return ipcMain.handle(channel, async (event, ...args) => {
    assertTrustedSender(event);
    return handler(event, ...args);
  });
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>\"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&#39;' }[char]));
}
function sanitizePrintHtml(html) {
  assertString(html, 'html', 10 * 1024 * 1024);
  return html
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<iframe\b[^>]*>[\s\S]*?<\/iframe>/gi, '')
    .replace(/<object\b[^>]*>[\s\S]*?<\/object>/gi, '')
    .replace(/\s+on[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, '')
    .replace(/(?:href|src)\s*=\s*(?:"|')\s*javascript:[^"']*(?:"|')/gi, '');
}

// ── Branding: StoreTrack Pro app icon ────────────────────────────────────────
// Resolves the icon.ico both in dev (assets/icon.ico) and packaged builds
// (electron-builder bundles the same icon into resources via extraResources).
function getAppIconPath() {
  const candidates = [
    app.isPackaged ? path.join(process.resourcesPath, 'icon.ico') : null,
    path.join(__dirname, 'assets', 'icon.ico'),
    path.join(__dirname, 'icon.ico')
  ].filter(Boolean);
  for (const p of candidates) {
    if (fs.existsSync(p)) {return p;}
  }
  return undefined;
}

// ── Scanner modules ──────────────────────────────────────────────────────────
const ScannerManager = require('./Scanner/scanner-manager');

// ─── Device Identity ──────────────────────────────────────────────────────────
const DEVICE_ID = os.hostname();

// ─── Data directory setup ─────────────────────────────────────────────────────
const appRoot        = app.isPackaged ? path.dirname(app.getPath('exe')) : __dirname;
const installDataDir = path.join(appRoot, 'StoreTrackData');
const fallbackDataDir= path.join(app.getPath('appData'), 'StoreTrack Pro', 'StoreTrackData');
const dataDir        = ensureWritableDataDir(installDataDir, fallbackDataDir);
const exportDir      = path.join(dataDir, 'Exports');
const backupDir      = path.join(dataDir, 'Backups');

// Complete application backup: encrypt at the privileged boundary, verify by
// decrypting the temporary file, then rotate old snapshots. The key is itself
// protected by the operating system's Electron safeStorage provider; if that
// provider is unavailable we fail closed rather than writing plaintext data.
function completeBackupDir() { const dir = path.join(dataDir, 'CompleteBackups'); fs.mkdirSync(dir, { recursive: true }); return dir; }
function completeBackupKeyPath() { return path.join(completeBackupDir(), '.storetrack-backup-key'); }
function backupKey() {
  if (!safeStorage?.isEncryptionAvailable?.()) { throw new Error('Secure backup storage is unavailable; refusing to write a plaintext backup'); }
  const keyPath = completeBackupKeyPath();
  if (fs.existsSync(keyPath)) {
    const protectedKey = fs.readFileSync(keyPath, 'utf8');
    const key = safeStorage.decryptString(Buffer.from(protectedKey, 'base64'));
    const decoded = Buffer.from(key, 'base64');
    if (decoded.length !== 32) { throw new Error('Stored backup key is invalid'); }
    return decoded;
  }
  const key = crypto.randomBytes(32);
  const protectedKey = safeStorage.encryptString(key.toString('base64')).toString('base64');
  fs.writeFileSync(keyPath, protectedKey, { encoding: 'utf8', mode: 0o600 });
  try { fs.chmodSync(keyPath, 0o600); } catch (_) { /* Windows ACLs are managed by safeStorage. */ }
  return key;
}
function encryptCompleteBackup(serialized) { return JSON.stringify(encryptBackup(serialized, backupKey())); }
function decryptCompleteBackup(serialized) {
  const envelope = JSON.parse(serialized);
  if (envelope?.format !== ENCRYPTED_BACKUP_FORMAT || envelope.algorithm !== ENCRYPTED_BACKUP_ALGORITHM) { throw new Error('Unsupported encrypted backup format'); }
  return decryptBackup(envelope, backupKey());
}
function decryptPortableBackup(serialized) {
  const envelope = JSON.parse(serialized);
  if (envelope?.format === ENCRYPTED_BACKUP_FORMAT && envelope.algorithm === ENCRYPTED_BACKUP_ALGORITHM && typeof envelope.portableKey !== 'string') {
    throw new Error('This backup is encrypted with the source PC’s Windows-protected key and cannot be restored on this PC. On the source PC, choose “Create Backup for Any Windows PC (portable JSON)”, then import that file here.');
  }
  if (envelope?.format !== ENCRYPTED_BACKUP_FORMAT || envelope.algorithm !== ENCRYPTED_BACKUP_ALGORITHM || typeof envelope.portableKey !== 'string') {
    throw new Error('This file is not a StoreTrack portable backup. Create a portable JSON on the source PC, then import that file here.');
  }
  const key = Buffer.from(envelope.portableKey, 'base64');
  if (key.length !== 32) { throw new Error('Portable backup recovery key is invalid'); }
  const plaintext = decryptBackup(envelope, key);
  validateCompleteBackup(plaintext);
  return plaintext;
}
function validateCompleteBackup(serialized) {
  const payload = JSON.parse(serialized);
  const stores = payload?.stores;
  const validScalar = value => value === null || ['string', 'number', 'boolean'].includes(typeof value);
  const validGRN = row => row && typeof row === 'object' && !Array.isArray(row) && ['string', 'number'].includes(typeof row.id) && String(row.id).trim() !== '' && Array.isArray(row.items) && row.items.every(item => item && typeof item === 'object' && !Array.isArray(item) && Object.values(item).every(validScalar));
  const validRows = rows => Array.isArray(rows) && rows.every(row => row && typeof row === 'object' && !Array.isArray(row));
  if (payload?.format !== 'StoreTrackProCompleteBackup' || !stores || typeof stores !== 'object' || Array.isArray(stores) || !Object.keys(stores).length || Object.values(stores).some(rows => !validRows(rows)) || (Array.isArray(stores.grn) && stores.grn.some(row => !validGRN(row)))) {
    throw new Error('Backup validation failed');
  }
  return payload;
}
secureHandle('backup:write', async (_event, serialized) => {
  assertString(serialized, 'backup', 200 * 1024 * 1024);
  const payload = validateCompleteBackup(serialized);
  const encrypted = encryptCompleteBackup(serialized);
  const dir = completeBackupDir(); const day = new Date().toISOString().slice(0, 10); const fileName = `StoreTrackPro-backup-${day}.json`; const temp = path.join(dir, `.${fileName}.tmp`); const target = path.join(dir, fileName);
  fs.writeFileSync(temp, encrypted, { encoding: 'utf8', mode: 0o600 });
  const checked = validateCompleteBackup(decryptCompleteBackup(fs.readFileSync(temp, 'utf8')));
  if (checked.format !== payload.format || !Object.keys(checked.stores || {}).length) { fs.unlinkSync(temp); throw new Error('Backup verification failed'); }
  fs.renameSync(temp, target);
  const restorePoints = fs.readdirSync(dir).filter(name => /^StoreTrackPro-backup-\d{4}-\d{2}-\d{2}\.json$/.test(name)).sort().reverse();
  for (const name of restorePoints.slice(90)) { if (name !== fileName) { try { fs.unlinkSync(path.join(dir, name)); } catch (error) { console.error('[Backup rotation]', error.message); } } }
  return { ok: true, encrypted: true, fileName, path: target, createdAt: payload.createdAt };
});
function validateRestoreJournal(serialized) {
  assertString(serialized, 'restore recovery journal', 200 * 1024 * 1024);
  const journal = JSON.parse(serialized);
  if (journal?.version !== 1 || !['prepared', 'committed'].includes(journal.phase)) { throw new Error('Restore recovery journal is invalid'); }
  if (journal.phase === 'prepared') {
    if (!journal.snapshot || typeof journal.snapshot !== 'object' || Array.isArray(journal.snapshot)) { throw new Error('Restore recovery snapshot is invalid'); }
    for (const [name, rows] of Object.entries(journal.snapshot)) {
      if (!name || name.toLowerCase() === 'users' || !Array.isArray(rows) || rows.some(row => !row || typeof row !== 'object' || Array.isArray(row))) {
        throw new Error('Restore recovery snapshot failed validation');
      }
    }
  }
  return journal;
}
function restoreJournalPath() { return path.join(completeBackupDir(), '.restore-recovery.json'); }
secureHandle('backup:writeRecoveryJournal', async (_event, serialized) => {
  validateRestoreJournal(serialized);
  const target = restoreJournalPath();
  const temp = `${target}.${process.pid}.tmp`;
  const encrypted = encryptCompleteBackup(serialized);
  let fd;
  try {
    fd = fs.openSync(temp, 'w', 0o600);
    fs.writeFileSync(fd, encrypted, 'utf8');
    fs.fsyncSync(fd);
    fs.closeSync(fd);
    fd = null;
    if (decryptCompleteBackup(fs.readFileSync(temp, 'utf8')) !== serialized) { throw new Error('Restore recovery journal verification failed'); }
    fs.renameSync(temp, target);
    return { ok: true };
  } catch (error) {
    if (fd !== null && fd !== undefined) { try { fs.closeSync(fd); } catch (_) {} }
    try { if (fs.existsSync(temp)) { fs.unlinkSync(temp); } } catch (_) {}
    throw error;
  }
});
secureHandle('backup:readRecoveryJournal', async () => {
  const target = restoreJournalPath();
  if (!fs.existsSync(target)) { return { ok: true, data: null }; }
  const serialized = decryptCompleteBackup(fs.readFileSync(target, 'utf8'));
  validateRestoreJournal(serialized);
  return { ok: true, data: serialized };
});
secureHandle('backup:clearRecoveryJournal', async () => {
  const target = restoreJournalPath();
  if (fs.existsSync(target)) { fs.unlinkSync(target); }
  return { ok: true };
});
secureHandle('backup:exportPortable', async (_event, serialized) => {
  assertString(serialized, 'backup', 200 * 1024 * 1024);
  const payload = validateCompleteBackup(serialized);
  const key = crypto.randomBytes(32);
  const envelope = { ...encryptBackup(serialized, key), portableKey: key.toString('base64') };
  const fileName = `StoreTrackPro-portable-backup-${new Date().toISOString().slice(0, 10)}.json`;
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Save Portable StoreTrack Backup',
    defaultPath: path.join(app.getPath('downloads'), fileName),
    buttonLabel: 'Save Portable Backup',
    filters: [{ name: 'StoreTrack backup JSON', extensions: ['json'] }]
  });
  if (result.canceled || !result.filePath) { return { ok: false, cancelled: true }; }
  const target = result.filePath;
  const temp = `${target}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(temp, JSON.stringify(envelope), { encoding: 'utf8', mode: 0o600, flag: 'wx' });
    const checked = validateCompleteBackup(decryptBackup(JSON.parse(fs.readFileSync(temp, 'utf8')), key));
    if (checked.format !== payload.format || !Object.keys(checked.stores || {}).length) { throw new Error('Portable backup verification failed'); }
    fs.renameSync(temp, target);
  } catch (error) {
    try { if (fs.existsSync(temp)) { fs.unlinkSync(temp); } } catch (_) { /* Keep the original export error. */ }
    throw error;
  }
  return { ok: true, portable: true, fileName: path.basename(target), path: target, createdAt: payload.createdAt };
});
secureHandle('backup:decryptPortable', async (_event, serialized) => {
  assertString(serialized, 'portable backup', 200 * 1024 * 1024);
  const data = decryptPortableBackup(serialized);
  return { ok: true, portable: true, data };
});
secureHandle('backup:read', async () => { const dir = completeBackupDir(); const files = fs.readdirSync(dir).filter(name => /^StoreTrackPro-backup-\d{4}-\d{2}-\d{2}\.json$/.test(name)).sort().reverse(); if (!files.length) { return { ok: false, error: 'No backup found' }; } const fileName = files[0]; const filePath = path.join(dir, fileName); const raw = fs.readFileSync(filePath, 'utf8'); let data; let encrypted = true; try { data = decryptCompleteBackup(raw); } catch (error) { const legacy = JSON.parse(raw); if (legacy?.format !== 'StoreTrackProCompleteBackup') { throw new Error('Backup authentication failed or file is corrupted'); } data = raw; encrypted = false; } validateCompleteBackup(data); return { ok: true, encrypted, legacy: !encrypted, warning: encrypted ? undefined : 'This legacy backup is plaintext. Restore only after confirming it is trusted, then create a new encrypted backup.', fileName, path: filePath, data }; });
function verifyRetainedBackups(dir) {
  if (!fs.existsSync(dir)) { return { checked: 0, passed: 0, failed: 0, files: [] }; }
  const files = fs.readdirSync(dir).filter(name => /^StoreTrackPro-backup-\d{4}-\d{2}-\d{2}\.json$/.test(name)).sort().reverse();
  const checks = files.map(fileName => {
    const filePath = path.join(dir, fileName);
    try {
      const raw = fs.readFileSync(filePath, 'utf8');
      const payload = validateCompleteBackup(decryptCompleteBackup(raw));
      return { fileName, ok: true, encrypted: true, createdAt: fs.statSync(filePath).mtime.toISOString(), stores: Object.keys(payload.stores).length };
    } catch (error) { return { fileName, ok: false, encrypted: false, error: error?.message || 'Backup verification failed' }; }
  });
  return { checked: checks.length, passed: checks.filter(item => item.ok).length, failed: checks.filter(item => !item.ok).length, files: checks };
}
secureHandle('backup:status', async () => {
  // Read-only: verification does not create directories, repair files, or rotate backups.
  const dir = path.join(dataDir, 'CompleteBackups');
  const verification = verifyRetainedBackups(dir);
  const fileName = verification.files[0]?.fileName;
  if (!fileName) { return { ok: true, verification }; }
  const filePath = path.join(dir, fileName);
  return { ok: true, fileName, path: filePath, createdAt: fs.statSync(filePath).mtime.toISOString(), verification };
});
secureHandle('backup:openFolder', async () => { const dir = completeBackupDir(); try { const result = await shell.openPath(dir); return result ? { ok: false, error: result } : { ok: true, path: dir }; } catch (error) { return { ok: false, error: error?.message || 'Could not open Backup Folder' }; } });
const SCANNER_CONFIG_FILE = path.join(dataDir, 'scanner-config.json');
const SCANNER_LOG_FILE    = path.join(dataDir, 'scanner.log');

// Fix: Use AppData\Local for userData (avoids space-in-path quota DB failure)
const safeUserData = path.join(app.getPath('appData'), '..', 'Local', 'StoreTrackPro');
app.setPath('userData', safeUserData);

// Disable GPU disk cache (avoids 'Access is denied' cache errors on Windows)
app.commandLine.appendSwitch('disable-gpu-shader-disk-cache');
app.commandLine.appendSwitch('disk-cache-size', '0');

function ensureWritableDataDir(preferredDir, fallbackDir) {
  for (const dir of [preferredDir, fallbackDir]) {
    try {
      fs.mkdirSync(path.join(dir, 'Exports'),  { recursive: true });
      fs.mkdirSync(path.join(dir, 'Backups'),  { recursive: true });
      fs.accessSync(path.join(dir, 'Exports'), fs.constants.W_OK);
      return dir;
    } catch (err) { console.error('[Sync Config Load Error]', err.message); }
  }
  throw new Error('No writable StoreTrack data folder is available.');
}

// ─── Sync state ───────────────────────────────────────────────────────────────
const SYNC_CONFIG_FILE  = path.join(dataDir, 'sync-config.json');
const TX_LOG_FILENAME   = 'storetrack_transactions.log';
const MASTER_FILENAME   = 'storetrack_master.json';
const MASTER_BAK_FILENAME = 'storetrack_master.json.bak'; // FIX #9: backup filename
const LOCK_FILENAME     = 'sync.lock';
// FIX #5 (Log Rotation): 10 MB threshold for transaction log rotation
const TX_LOG_MAX_BYTES  = 10 * 1024 * 1024;

let mainWindow      = null;
let syncFolderPath  = null;
let watcher         = null;       // fs.watch watcher (replaces polling)
let heartbeatTimer  = null;       // FIX #2: Track heartbeat timer separately
let recoveryTimer   = null;       // FIX #2: Track recovery timer separately
let lastMasterMtime = 0;

// ── Auto-backup every 15 minutes ─────────────────────────────────────────────
let backupTimerId = null;

// ── FIX #10: LAN health state for dashboard indicators ───────────────────────
let lanConnectedClients = 0;      // Count of detected unique devices in tx log
let lanLastSyncTs       = 0;      // Timestamp of last successful sync event

// ── Tray & Scanner state ────────────────────────────────────────────────────
let tray           = null;
let isQuitting     = false;
let scannerManager = null;
const recentScanKeys = new Map();
const currentLockOwner = `${DEVICE_ID}:${process.pid}:${crypto.randomUUID()}`;

function loadSyncConfig() {
  try {
    if (fs.existsSync(SYNC_CONFIG_FILE)) {
      const cfg = JSON.parse(fs.readFileSync(SYNC_CONFIG_FILE, 'utf8'));
      if (cfg.folder && fs.existsSync(cfg.folder)) {syncFolderPath = cfg.folder;}
    }
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }
}

function saveSyncConfig() {
  try { fs.writeFileSync(SYNC_CONFIG_FILE, JSON.stringify({ folder: syncFolderPath })); } catch (err) { console.error('[Sync Config Save Error]', err.message); }
}

// ─── Lock helpers ─────────────────────────────────────────────────────────────
// FIX #1: Stale lock timeout changed from 10s → 60s to prevent premature lock
//         deletion during slow LAN operations (heavy network or large JSON writes).
function acquireLock(folder) {
  const lockPath = path.join(folder, LOCK_FILENAME);
  try {
    // wx flag = exclusive create (atomic) — fails if file already exists
    const fd = fs.openSync(lockPath, 'wx');
    fs.writeSync(fd, JSON.stringify({ owner: currentLockOwner, device: DEVICE_ID, createdAt: Date.now() }));
    return fd;
  } catch (err) {
    if (err.code === 'EEXIST') {
      try {
        const age = Date.now() - fs.statSync(lockPath).mtimeMs;
        // FIX #1: was 10000 (10s), now 60000 (60s) — gives slow LAN ops time to finish
        if (age > 60000) {
          // Stale lock (> 60s) — remove and retry
          fs.unlinkSync(lockPath);
          const fd = fs.openSync(lockPath, 'wx');
          fs.writeSync(fd, JSON.stringify({ owner: currentLockOwner, device: DEVICE_ID, createdAt: Date.now(), recovered: true }));
          return fd;
        }
      } catch (err) { console.error('[Sync Config Load Error]', err.message); }
      return null; // Lock is fresh, another device is writing
    }
    return null;
  }
}

function releaseLock(folder, fd) {
  try { if (fd) {fs.closeSync(fd);} } catch (err) { console.error('[Lock Release Close Error]', err.message); }
  try {
    const lockPath = path.join(folder, LOCK_FILENAME);
    const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
    if (lock.owner === currentLockOwner) {fs.unlinkSync(lockPath);}
  } catch (err) { console.error('[Lock Release Unlink Error]', err.message); }
}

// ─── Master JSON helpers ──────────────────────────────────────────────────────
function readMaster(folder) {
  try {
    return JSON.parse(fs.readFileSync(path.join(folder, MASTER_FILENAME), 'utf8'));
  } catch (_) { return null; }
}

// FIX #7: Atomic file write — write to .tmp then rename, prevents JSON corruption
//         on power loss or mid-write crashes.
function writeMaster(folder, data, expectedRevision = null) {
  const masterFile = path.join(folder, MASTER_FILENAME);
  const tempFile   = path.join(folder, MASTER_FILENAME + '.tmp');
  const fd = acquireLock(folder);
  if (!fd) {return false;}
  try {
    if (expectedRevision !== null) {
      const latest = readMaster(folder);
      const actualRevision = Number(latest?.revision || 0);
      if (actualRevision !== Number(expectedRevision)) {
        console.warn('[Sync] Concurrent master update detected; refusing overwrite');
        return false;
      }
    }
    // Step 1: write to a temp file (safe — if this fails, master.json is untouched)
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf8');
    // Step 2: keep a rolling .bak in the sync folder AND a local copy for startup recovery (FIX #9)
    try {
      if (fs.existsSync(masterFile)) {
        fs.copyFileSync(masterFile, path.join(folder, MASTER_BAK_FILENAME));
        // Also write a local timestamped snapshot for recoverMasterIfNeeded
        fs.copyFileSync(masterFile, path.join(backupDir, `bak_${Date.now()}.json`));
      }
    } catch (err) { console.error('[Sync Config Load Error]', err.message); }
    // Step 3: atomic rename — on most OSes this is a single kernel syscall
    fs.renameSync(tempFile, masterFile);
    return true;
  } catch (err) {
    console.error('[Master Write Error]', err.message);
    // Clean up temp if rename failed
    try { fs.unlinkSync(tempFile); } catch (e) { console.error('[Temp Cleanup Error]', e.message); }
    return false;
  } finally {
    releaseLock(folder, fd);
  }
}

// ─── Transaction log helpers ──────────────────────────────────────────────────

// FIX #5: Rotate the transaction log if it exceeds TX_LOG_MAX_BYTES (10 MB).
//         Old log is archived with a timestamp suffix; a fresh empty log is created.
function rotateTxLog(folder) {
  const logPath = path.join(folder, TX_LOG_FILENAME);
  try {
    const archiveName = `storetrack_transactions_${Date.now()}.log`;
    const archivePath = path.join(folder, archiveName);
    fs.renameSync(logPath, archivePath);
    // Also archive locally in Backups directory so it doesn't clutter the share
    try {
      const localArchive = path.join(backupDir, archiveName);
      fs.copyFileSync(archivePath, localArchive);
    } catch (err) { console.error('[Sync Config Load Error]', err.message); }
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }
}

function appendTxLog(folder, tx) {
  try {
    // FIX #6: Ensure every tx has id, timestamp, deviceId, and type for conflict detection
    const enriched = {
      ...tx,
      id:       tx.id       || (typeof crypto !== 'undefined' ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`),
      timestamp: tx.timestamp || Date.now(),
      deviceId: DEVICE_ID,
      time:     tx.time     || new Date().toISOString(),
    };
    const line = JSON.stringify(enriched) + '\n';

    // FIX #5: Check log size before appending; rotate if > 10 MB
    const logPath = path.join(folder, TX_LOG_FILENAME);
    try {
      const stat = fs.statSync(logPath);
      if (stat.size > TX_LOG_MAX_BYTES) {
        rotateTxLog(folder);
      }
    } catch (err) { /* file may not exist yet — that's fine */ console.debug('[Tx Log Stat Skip]', err.message); }

    fs.appendFileSync(logPath, line);
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }
}

function readTxLog(folder) {
  try {
    return fs.readFileSync(path.join(folder, TX_LOG_FILENAME), 'utf8')
      .split('\n').filter(Boolean).map(l => {
        try { return JSON.parse(l); } catch (err) { console.debug('[Tx Log Parse Skip]', err.message); return null; }
      }).filter(Boolean); // FIX: skip malformed lines instead of crashing
  } catch (err) { console.error('[Tx Log Read Error]', err.message); return []; }
}

// ─── Auto-backup ──────────────────────────────────────────────────────────────
function doAutoBackup() {
  const masterPath = syncFolderPath ? path.join(syncFolderPath, MASTER_FILENAME) : null;
  if (masterPath && fs.existsSync(masterPath)) {
    try {
      const dst = path.join(backupDir, `backup_${Date.now()}.json`);
      fs.copyFileSync(masterPath, dst);
    } catch (err) { console.error('[Sync Config Load Error]', err.message); }
  }
  // FIX #8: Prune backup_* files — keep latest 100
  try {
    const backups = fs.readdirSync(backupDir)
      .filter(f => f.startsWith('backup_') && f.endsWith('.json'))
      .sort();
    if (backups.length > 100) {
      backups.slice(0, backups.length - 100).forEach(f => {
        try { fs.unlinkSync(path.join(backupDir, f)); } catch (err) { console.error('[Backup Prune Error]', err.message); }
      });
    }
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }
  // FIX #8: Also prune bak_* snapshot files written by writeMaster — keep latest 50
  try {
    const baks = fs.readdirSync(backupDir)
      .filter(f => f.startsWith('bak_') && f.endsWith('.json'))
      .sort();
    if (baks.length > 50) {
      baks.slice(0, baks.length - 50).forEach(f => {
        try { fs.unlinkSync(path.join(backupDir, f)); } catch (err) { console.error('[Snapshot Prune Error]', err.message); }
      });
    }
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }
}

// FIX #9: Startup recovery — if master.json is missing/corrupt, restore from
//         the most recent valid backup in the Backups directory.
function recoverMasterIfNeeded(folder) {
  // FIX: snapshot the folder path at entry; syncFolderPath could change mid-function on slow NAS
  const targetFolder = folder;
  if (!targetFolder) {return;}
  const masterPath = path.join(targetFolder, MASTER_FILENAME);
  const bakPath    = path.join(targetFolder, MASTER_BAK_FILENAME);

  let masterOk = false;
  try {
    JSON.parse(fs.readFileSync(masterPath, 'utf8'));
    masterOk = true;
  } catch (_) { /* missing or corrupt */ }

  if (masterOk) {return;} // Nothing to do

  // Try the rolling .bak first (most recent)
  try {
    JSON.parse(fs.readFileSync(bakPath, 'utf8'));
    fs.copyFileSync(bakPath, masterPath);
    console.log('[StoreTrack] Recovered master.json from .bak');
    return;
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }

  // Fall back to newest valid backup in Backups directory — check both backup_ and bak_ files
  try {
    const allBackups = fs.readdirSync(backupDir)
      .filter(f => (f.startsWith('backup_') || f.startsWith('bak_')) && f.endsWith('.json'))
      .map(f => ({ f, mtime: (() => { try { return fs.statSync(path.join(backupDir, f)).mtimeMs; } catch(err){ console.error('[Backup Stat Error]', err.message); return 0;} })() }))
      .sort((a, b) => b.mtime - a.mtime) // FIX: sort by actual mtime, not filename (handles clock skew)
      .map(x => x.f);
    for (const bk of allBackups) {
      try {
        const bkPath = path.join(backupDir, bk);
        JSON.parse(fs.readFileSync(bkPath, 'utf8')); // validate JSON
        fs.copyFileSync(bkPath, masterPath);
        console.log(`[StoreTrack] Recovered master.json from backup: ${bk}`);
        return;
      } catch (err) { console.error('[Sync Config Load Error]', err.message); }
    }
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }

  console.warn('[StoreTrack] Could not recover master.json — no valid backup found.');
}

// FIX #10: Count unique devices seen in the tx log (connected clients metric)
function updateConnectedClients(folder) {
  try {
    const txs = readTxLog(folder);
    const cutoff = Date.now() - 30 * 60 * 1000; // active in last 30 min (was 15)
    const devices = new Set(
      txs.filter(t => (t.timestamp || 0) > cutoff).map(t => t.deviceId).filter(Boolean)
    );
    lanConnectedClients = devices.size;
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }
}

// FIX #10: Build a health payload for the renderer's LAN dashboard widget
function buildHealthPayload() {
  return {
    folder:    syncFolderPath,
    active:    !!watcher,
    deviceId:  DEVICE_ID,
    clients:   lanConnectedClients,
    lastSync:  lanLastSyncTs,
    ts:        Date.now(),
  };
}

// ─── FIX #2: Proper sync timer cleanup ───────────────────────────────────────
// All timers are now tracked as module-level variables so stopSync() can
// reliably clear them on any code path (stop, restart, error recovery).
function stopSync() {
  // FIX #2: Clear heartbeat timer
  if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
  // FIX #2: Clear recovery timer
  if (recoveryTimer)  { clearInterval(recoveryTimer);  recoveryTimer  = null; }
  // FIX #2: Close fs.watch watcher
  if (watcher) { try { watcher.close(); } catch (_) {} watcher = null; }
  // FIX #2: Clear auto-backup timer
  if (backupTimerId) { clearInterval(backupTimerId); backupTimerId = null; }
}

// ── FIX WATCH: fs.watch is unreliable on SMB/NFS network drives.
//   Strategy:
//     1. Try fs.watch first (low-latency, event-driven).
//     2. If fs.watch throws immediately OR emits an error within 3 s, fall back
//        to pure polling mode (checkMasterPoll) so sync still works on all LAN
//        configurations without crashing.
//     3. The existing recoveryTimer (10 s poll) already covers missed events, but
//        in fallback mode we tighten it to 3 s for near-realtime feel.
// ─────────────────────────────────────────────────────────────────────────────

function checkMasterPoll() {
  if (!syncFolderPath || !mainWindow) {return;}
  try {
    const masterPath = path.join(syncFolderPath, MASTER_FILENAME);
    if (!fs.existsSync(masterPath)) {return;}
    const mtime = fs.statSync(masterPath).mtimeMs;
    if (mtime !== lastMasterMtime) {
      lastMasterMtime = mtime;
      lanLastSyncTs   = Date.now();
      const master = readMaster(syncFolderPath);
      if (master) {
        mainWindow.webContents.send('sync:masterUpdate', {
          master, ts: Date.now(), device: master.lastDevice,
          health: buildHealthPayload()
        });
      }
      mainWindow.webContents.send('sync:update', {
        folder: syncFolderPath, filename: MASTER_FILENAME, eventType: 'change', ts: Date.now()
      });
    }
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }
}

// FIX: Guard against re-entrant startSync calls (e.g. did-finish-load + selectFolder firing quickly)
let _syncStarting = false;

function startSync() {
  if (_syncStarting) {return;} // FIX: prevent race
  _syncStarting = true;
  stopSync(); // FIX #2: Always stop existing timers before creating new ones
  if (!syncFolderPath || !mainWindow) {
    _syncStarting = false; // BUG FIX: must reset flag on early return
    return;
  }

  // FIX #9: Attempt startup recovery before the watcher begins serving data
  recoverMasterIfNeeded(syncFolderPath);

  // Send initial state
  sendSyncStatus();

  try {
    watcher = fs.watch(syncFolderPath, { persistent: false }, (eventType, filename) => {
      if (!filename || !mainWindow) {return;}
      if (filename === LOCK_FILENAME) {return;} // ignore lock file changes

      // Check if master.json changed
      if (filename === MASTER_FILENAME) {
        try {
          const mtime = fs.statSync(path.join(syncFolderPath, MASTER_FILENAME)).mtimeMs;
          if (mtime === lastMasterMtime) {return;}
          lastMasterMtime = mtime;
          lanLastSyncTs   = Date.now(); // FIX #10: record last sync time
          const master = readMaster(syncFolderPath);
          if (master) {
            mainWindow.webContents.send('sync:masterUpdate', {
              master, ts: Date.now(), device: master.lastDevice,
              health: buildHealthPayload() // FIX #10: piggyback health info
            });
          }
        } catch (err) { console.error('[Sync Config Load Error]', err.message); }
      }

      // Always send a generic update so UI can refresh
      mainWindow.webContents.send('sync:update', {
        folder: syncFolderPath, filename, eventType, ts: Date.now()
      });
    });

    // FIX WATCH: If the watcher errors (common on SMB/NFS drives), fall back to
    // polling instead of silently stopping sync.
    watcher.on('error', (err) => {
      console.warn('[StoreTrack] fs.watch error — falling back to poll mode:', err.message);
      try { watcher.close(); } catch (_) {}
      watcher = null;
      // Switch recovery timer to 3 s poll for responsiveness in fallback mode
      if (recoveryTimer) { clearInterval(recoveryTimer); recoveryTimer = null; }
      recoveryTimer = setInterval(checkMasterPoll, 3000);
    });

    // FIX #2: recovery interval now stored at module level (not on watcher._recoveryTimer)
    // Catches missed LAN sync events every 10 s
    recoveryTimer = setInterval(() => {
      if (!syncFolderPath || !mainWindow) {return;}
      try {
        const masterPath = path.join(syncFolderPath, MASTER_FILENAME);
        if (!fs.existsSync(masterPath)) {return;}
        const mtime = fs.statSync(masterPath).mtimeMs;
        if (mtime !== lastMasterMtime) {
          lastMasterMtime = mtime;
          lanLastSyncTs   = Date.now(); // FIX #10
          const master = readMaster(syncFolderPath);
          if (master) {
            mainWindow.webContents.send('sync:masterUpdate', {
              master, ts: Date.now(), device: master.lastDevice,
              health: buildHealthPayload()
            });
          }
        }
        // FIX #10: Update client count periodically
        updateConnectedClients(syncFolderPath);
      } catch (err) { console.error('[Sync Config Load Error]', err.message); }
    }, 10000);

  } catch (err) { console.error('[Sync Config Load Error]', err.message); }

  // FIX #2: heartbeat timer now stored at module level
  heartbeatTimer = setInterval(() => {
    if (!mainWindow) {return;}
    // FIX #10: include online:true so renderer's _updateLanHealthPanel shows ONLINE status
    const payload = { online: !!syncFolderPath, ...buildHealthPayload() };
    mainWindow.webContents.send('sync:heartbeat', payload);
  }, 5000);

  // FIX #8: Auto-backup every 15 minutes (900 000 ms), retain up to 100 backups
  backupTimerId = setInterval(doAutoBackup, 900000);

  _syncStarting = false; // FIX: allow future startSync calls
}

function sendSyncStatus() {
  if (!mainWindow || !syncFolderPath) {return;}
  try {
    let fileCount = 0;
    try { fileCount = fs.readdirSync(syncFolderPath).length; } catch (err) { console.error('[Sync Folder Read Error]', err.message); }
    mainWindow.webContents.send('sync:heartbeat', {
      ...buildHealthPayload(), fileCount
    });
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }
}

// ─── IPC handlers ─────────────────────────────────────────────────────────────
secureHandle('central:configure', (_event, baseUrl) => {
  if (typeof baseUrl !== 'string') {throw new TypeError('Central server URL must use HTTP or HTTPS');}
  baseUrl = validateCentralServiceUrl(baseUrl);
  resetCentralStream();
  centralConfig.baseUrl = baseUrl;
  connectCentralStream();
  return { ok: true, baseUrl: centralConfig.baseUrl };
});
secureHandle('central:login', async (_event, credentials = {}) => {
  const result = await centralRequest('/api/auth/login', { method: 'POST', body: JSON.stringify({ username: credentials.username, password: credentials.password }) });
  resetCentralStream();
  centralConfig.token = result.token; centralConfig.user = result.user; centralConfig.lastSequence = 0; connectCentralStream();
  return result;
});
secureHandle('central:logout', () => { resetCentralStream({ clearCredentials: true }); centralConfig.lastSequence = 0; return { ok: true }; });
secureHandle('central:getMaterials', async () => centralRequest('/api/materials'));
secureHandle('central:getMigrationStatus', async () => centralRequest('/api/admin/migrations'));
secureHandle('central:upsertMaterial', async (_event, material) => centralRequest('/api/materials', { method: 'POST', body: JSON.stringify(material) }));
secureHandle('central:syncUsers', async (_event, users) => centralRequest('/api/users/sync', { method: 'POST', body: JSON.stringify({ users }) }));
secureHandle('central:logAIEvent', async (_event, payload = {}) => centralRequest('/api/ai/events', { method: 'POST', body: JSON.stringify(payload) }));
secureHandle('central:commitStock', async (_event, transaction) => centralRequest('/api/transactions/stock', { method: 'POST', headers: { 'idempotency-key': String(transaction.id) }, body: JSON.stringify(transaction) }));
secureHandle('central:pullChanges', async (_event, afterSequence) => {
  const result = await centralRequest(`/api/sync/changes?after=${encodeURIComponent(Number(afterSequence || centralConfig.lastSequence || 0))}`);
  if (result.changes?.length) {centralConfig.lastSequence = Math.max(centralConfig.lastSequence, ...result.changes.map(item => Number(item.sequence)));}
  return result;
});
secureHandle('central:getStatus', async () => {
  if (!centralConfig.baseUrl) {return { configured: false, online: false, user: centralConfig.user, deviceId: DEVICE_ID, appVersion: app.getVersion() };}
  const startedAt = process.hrtime.bigint();
  try { const health = await centralRequest('/health'); const latencyMs = Number(process.hrtime.bigint() - startedAt) / 1e6; return { configured: true, online: true, user: centralConfig.user, deviceId: DEVICE_ID, appVersion: app.getVersion(), lastSequence: centralConfig.lastSequence, latencyMs: Math.round(latencyMs * 100) / 100, ...health }; }
  catch (error) { const latencyMs = Number(process.hrtime.bigint() - startedAt) / 1e6; return { configured: true, online: false, error: error.message, user: centralConfig.user, deviceId: DEVICE_ID, appVersion: app.getVersion(), lastSequence: centralConfig.lastSequence, latencyMs: Math.round(latencyMs * 100) / 100 }; }
});

secureHandle('sync:getStatus', () => ({
  folder:   syncFolderPath,
  active:   !!watcher,
  online:   !!syncFolderPath,
  deviceId: DEVICE_ID,
  health:   buildHealthPayload(), // FIX #10
}));

secureHandle('sync:selectFolder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select Shared Sync Folder (Shared on LAN)',
    properties: ['openDirectory']
  });
  if (result.canceled || !result.filePaths.length) {return null;}
  syncFolderPath = result.filePaths[0];
  saveSyncConfig();
  startSync();
  return syncFolderPath;
});

secureHandle('sync:stop', () => {
  stopSync(); // FIX #2: uses the unified stopSync
  syncFolderPath = null;
  saveSyncConfig();
  return true;
});

// ── Push full master to shared folder ────────────────────────────────────────
secureHandle('sync:pushMaster', async (_event, masterData) => {
  if (!syncFolderPath) {return { ok: false, error: 'No folder' };}
  try {
    const payload = { ...masterData, lastDevice: DEVICE_ID, savedAt: Date.now() };
    const ok = writeMaster(syncFolderPath, payload); // FIX #7: atomic write
    if (ok) {
      lanLastSyncTs = Date.now(); // FIX #10
      // FIX #6: append a push transaction for conflict detection
      appendTxLog(syncFolderPath, {
        id:        (typeof crypto !== 'undefined' ? crypto.randomUUID() : `${Date.now()}-push`),
        timestamp: Date.now(),
        deviceId:  DEVICE_ID,
        type:      'MASTER_PUSH',
      });
    }
    return { ok };
  } catch (err) { return { ok: false, error: err.message }; }
});

// ── Pull master from shared folder ───────────────────────────────────────────
secureHandle('sync:pullMaster', async () => {
  if (!syncFolderPath) {return { ok: false, error: 'No folder' };}
  try {
    const master = readMaster(syncFolderPath);
    if (!master) {return { ok: false, error: 'No master.json in folder' };}
    lanLastSyncTs = Date.now(); // FIX #10
    return { ok: true, master };
  } catch (err) { return { ok: false, error: err.message }; }
});

// ── Append a transaction to shared log ───────────────────────────────────────
secureHandle('sync:appendTx', async (_event, tx) => {
  if (!syncFolderPath) {return { ok: false };}
  try {
    appendTxLog(syncFolderPath, tx); // FIX #6 + #5 handled inside appendTxLog
    return { ok: true };
  } catch (err) { return { ok: false, error: err.message }; }
});

// ── Read transaction log ──────────────────────────────────────────────────────
secureHandle('sync:readTxLog', async () => {
  if (!syncFolderPath) {return { ok: false, txs: [] };}
  try { return { ok: true, txs: readTxLog(syncFolderPath) }; }
  catch (err) { return { ok: false, txs: [], error: err.message }; }
});

// ── Network health check (FIX #10: now returns full health metrics) ───────────
secureHandle('sync:health', async () => {
  if (!syncFolderPath) {return { online: false, ...buildHealthPayload() };}
  try {
    fs.accessSync(syncFolderPath, fs.constants.R_OK);
    updateConnectedClients(syncFolderPath); // FIX #10: refresh client count
    return { online: true, device: DEVICE_ID, ...buildHealthPayload() };
  } catch (_) { return { online: false, ...buildHealthPayload() }; }
});

// ── OS-protected IndexedDB encryption-key bridge ─────────────────────────────
// The renderer never persists this key itself. safeStorage protects the key
// blob with the current OS account; unsupported platforms fail closed.
const encryptionKeyPath = () => path.join(dataDir, '.storetrack-encryption-key');
function isOSProtectedEncryptionStorageAvailable() {
  if (!safeStorage?.isEncryptionAvailable?.()) return false;
  const backend = safeStorage.getSelectedStorageBackend?.();
  return backend !== 'basic_text' && backend !== 'unknown';
}
function validateDataEncryptionKey(value) {
  assertString(value, 'encryption key', 128);
  const bytes = Buffer.from(value, 'base64');
  if (bytes.length !== 32 || bytes.toString('base64') !== value) throw new Error('Encryption key must be canonical base64 for exactly 32 bytes');
  return value;
}
secureHandle('encryptionKey:get', async () => {
  if (!isOSProtectedEncryptionStorageAvailable()) return { available: false, key: null };
  const keyPath = encryptionKeyPath();
  if (!fs.existsSync(keyPath)) return { available: true, key: null };
  const protectedValue = fs.readFileSync(keyPath, 'utf8');
  const key = safeStorage.decryptString(Buffer.from(protectedValue, 'base64'));
  validateDataEncryptionKey(key);
  return { available: true, key };
});
secureHandle('encryptionKey:set', async (_event, key) => {
  validateDataEncryptionKey(key);
  if (!isOSProtectedEncryptionStorageAvailable()) throw new Error('OS-protected key storage is unavailable');
  const keyPath = encryptionKeyPath();
  const tempPath = `${keyPath}.${process.pid}.tmp`;
  const protectedValue = safeStorage.encryptString(key).toString('base64');
  try {
    fs.writeFileSync(tempPath, protectedValue, { encoding: 'utf8', mode: 0o600, flag: 'w' });
    try { fs.chmodSync(tempPath, 0o600); } catch (_) { /* Windows ACLs are managed by safeStorage. */ }
    fs.renameSync(tempPath, keyPath);
    const check = safeStorage.decryptString(Buffer.from(fs.readFileSync(keyPath, 'utf8'), 'base64'));
    if (check !== key) throw new Error('OS-protected encryption key verification failed');
    return { ok: true };
  } catch (error) {
    try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch (_) { /* Preserve original error. */ }
    throw error;
  }
});

// ── Patch 5 (fixed): password hashing IPC — pure Node.js crypto, no native rebuild ──
secureHandle('auth:hashPassword', async (_event, password) => {
  try {
    const hash = await pbkdf2Hash(password);
    return { ok: true, hash };
  } catch (err) { return { ok: false, error: err.message }; }
});

secureHandle('auth:verifyPassword', async (_event, password, storedHash) => {
  try {
    // Support SHA-256 hashes (64 hex chars) and pbkdf2 hashes ($pbkdf2$)
    if (storedHash && storedHash.startsWith('$pbkdf2$')) {
      const valid = await pbkdf2Verify(password, storedHash);
      return { ok: true, valid };
    }
    // SHA-256 hash - verify in main process
    const enc = new TextEncoder();
    const buf = await crypto.subtle.digest('SHA-256', enc.encode(password));
    const hash = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
    return { ok: true, valid: hash === storedHash };
  } catch (err) { return { ok: false, valid: false, error: err.message }; }
});

// ── Patch 6: Import validation (enhanced schema validation) ───────────────────
// Validates that imported master JSON has the expected top-level structure and
// that critical arrays contain well-formed objects (not arbitrary data).
const IMPORT_SCHEMA = {
  // key → { required: bool, type: 'array'|'object'|'string'|'number', itemCheck? }
  materials:    { required: false, type: 'array',  itemCheck: i => typeof i.id !== 'undefined' },
  transactions: { required: false, type: 'array',  itemCheck: i => typeof i.id !== 'undefined' },
  M:            { required: false, type: 'array',  itemCheck: i => typeof i.id !== 'undefined' },
  T:            { required: false, type: 'array',  itemCheck: i => typeof i.id !== 'undefined' },
  users:        { required: false, type: 'array',  itemCheck: i => typeof i.username === 'string' },
  U:            { required: false, type: 'array',  itemCheck: i => typeof i.username === 'string' },
  config:       { required: false, type: 'object'  },
  CFG:          { required: false, type: 'object'  },
  savedAt:      { required: false, type: 'number'  },
  lastDevice:   { required: false, type: 'string'  },
};

// Maximum allowed import payload: 50 MB (serialised JSON string length)
const IMPORT_MAX_BYTES = 50 * 1024 * 1024;

function validateImport(data) {
  if (data === null || data === undefined) {throw new Error('Invalid data: empty or null');}
  if (typeof data !== 'object' || Array.isArray(data)) {throw new Error('Invalid data: expected a plain object');}

  // Size guard — prevent memory exhaustion from huge payloads
  const serialised = JSON.stringify(data);
  if (serialised.length > IMPORT_MAX_BYTES) {throw new Error('Import payload too large (>50 MB)');}

  // Schema checks — only validate keys that are actually present
  for (const [key, rule] of Object.entries(IMPORT_SCHEMA)) {
    if (!(key in data)) {
      if (rule.required) {throw new Error(`Missing required field: "${key}"`);}
      continue; // optional key absent — OK
    }
    const val = data[key];

    // Type check
    if (rule.type === 'array') {
      if (!Array.isArray(val)) {throw new Error(`Field "${key}" must be an array`);}
      // Spot-check first 20 items so we don't iterate huge arrays on every import
      if (rule.itemCheck) {
        const sample = val.slice(0, 20);
        for (let i = 0; i < sample.length; i++) {
          if (typeof sample[i] !== 'object' || sample[i] === null)
            {throw new Error(`Field "${key}[${i}]" must be an object`);}
          if (!rule.itemCheck(sample[i]))
            {throw new Error(`Field "${key}[${i}]" failed schema check`);}
        }
      }
    } else if (rule.type === 'object') {
      if (typeof val !== 'object' || Array.isArray(val) || val === null)
        {throw new Error(`Field "${key}" must be a plain object`);}
    } else {
      // primitive type check
      if (typeof val !== rule.type) {throw new Error(`Field "${key}" must be of type ${rule.type}`);}
    }
  }

  return true;
}

secureHandle('sync:validateImport', (_event, data) => {
  try {
    validateImport(data);
    return { ok: true };
  } catch (err) { return { ok: false, error: err.message }; }
});

// ── XLSX parse via main process (using ExcelJS — replaces vulnerable xlsx@0.18.5)
// ExcelJS is actively maintained, has no known CVEs, and supports .xlsx/.xls/.csv.
const ExcelJS = require('exceljs');

secureHandle('xlsx:parseBuffer', async (event, uint8arr) => {
  try {
    assertTrustedSender(event);
    if (!Array.isArray(uint8arr) || uint8arr.length > 50 * 1024 * 1024) {throw new Error('Invalid workbook buffer');}
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(Buffer.from(uint8arr));
    return parseSheetExcelJS(wb);
  } catch (err) { return { error: err.message }; }
});

secureHandle('xlsx:parseFile', async (event, filePath) => {
  try {
    assertTrustedSender(event);
    const safePath = assertApprovedInputPath(filePath);
    if (!/\.(xlsx|xls|csv)$/i.test(safePath)) {throw new Error('Unsupported workbook type');}
    // Validate file size < 50 MB
    const stat = await fs.promises.stat(safePath);
    if (stat.size > 50 * 1024 * 1024) {return { error: 'File too large (>50 MB)' };}
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.readFile(safePath);
    return parseSheetExcelJS(wb);
  } catch (err) { return { error: err.message }; }
});

function parseSheetExcelJS(wb) {
  // Use the first worksheet
  const ws = wb.worksheets[0];
  if (!ws) {return { error: 'Empty workbook' };}

  const allRows = [];
  ws.eachRow({ includeEmpty: false }, (row) => {
    allRows.push(row.values.slice(1)); // ExcelJS row.values is 1-indexed; slice(1) makes it 0-indexed
  });

  if (!allRows.length) {return { error: 'Empty sheet' };}

  // First row = headers
  const headers = allRows[0].map(h => (h !== null && h !== undefined ? String(h).trim() : '')).filter(Boolean);
  if (!headers.length) {return { error: 'No headers found in first row' };}

  const rows = [];
  for (let i = 1; i < allRows.length; i++) {
    const vals = allRows[i];
    // Skip entirely empty rows
    if (!vals || vals.every(v => v === '' || v === null || v === undefined)) {continue;}
    const row = {};
    headers.forEach((h, idx) => {
      const v = vals[idx];
      // ExcelJS returns rich objects for dates/formulas; normalise to string
      if (v instanceof Date) {
        row[h] = v.toISOString().slice(0, 10); // YYYY-MM-DD
      } else if (v !== null && v !== undefined && typeof v === 'object' && v.text) {
        row[h] = String(v.text); // rich text / hyperlink
      } else {
        row[h] = v !== undefined && v !== null ? String(v) : '';
      }
    });
    rows.push(row);
  }
  return { headers, rows };
}

// ── PM: Print original checksheet file (PDF/XLSX/DOCX) ───────────────────────
const mammoth = require('mammoth');

secureHandle('pm:printChecksheetOriginal', async (_event, filePath, fileType, title) => {
  let printWindow = null;
  try {
    if (!isPathInsidePmChecksheetDir(filePath)) {
      console.error('[PM Checksheet Print] Rejected path outside PM_Checksheet:', filePath);
      return { error: 'File must be inside the PM_Checksheet folder.' };
    }
    printWindow = new BrowserWindow({
      show: false,
      webPreferences: {
        session: printSession,
        nodeIntegration: false,
        contextIsolation: true,
        webSecurity: true
      }
    });

    let htmlContent = '';

    if (fileType === '.pdf') {
      // Load PDF directly via file:// protocol - Chromium's native PDF renderer preserves exact layout
      await printWindow.loadURL(require('url').pathToFileURL(filePath).href);
      // Wait for PDF to load
      await new Promise(resolve => setTimeout(resolve, 1500));
    } else if (fileType === '.xlsx' || fileType === '.xls') {
      // Convert Excel to HTML table via ExcelJS (preserves rows/columns, not merged cells)
      const wb = new ExcelJS.Workbook();
      await wb.xlsx.readFile(filePath);
      const ws = wb.worksheets[0];
      if (!ws) {throw new Error('Empty workbook');}

      const allRows = [];
      ws.eachRow({ includeEmpty: false }, (row) => {
        allRows.push(row.values.slice(1));
      });

      if (!allRows.length) {throw new Error('Empty sheet');}

      htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>${escapeHtml(title || 'Checksheet')}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 10mm; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #000; padding: 4px 8px; font-size: 11px; }
            th { background: #f0f0f0; font-weight: bold; }
          </style>
        </head>
        <body>
          <h2 style="text-align:center">${escapeHtml(title || 'Checksheet')}</h2>
          <table>
            ${allRows.map((row, ri) => `
              <tr>
                ${row.map(cell => `<td>${escapeHtml(cell !== null && cell !== undefined ? String(cell) : '')}</td>`).join('')}
              </tr>
            `).join('')}
          </table>
        </body>
        </html>
      `;
      await printWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(htmlContent)}`);
      await new Promise(resolve => setTimeout(resolve, 1000));
    } else if (fileType === '.docx' || fileType === '.doc') {
      // Convert DOCX to HTML via mammoth (preserves formatting better than raw text)
      const result = await mammoth.convertToHtml({ path: filePath });
      htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>${escapeHtml(title || 'Checksheet')}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 10mm; }
            table { border-collapse: collapse; width: 100%; margin: 10px 0; }
            th, td { border: 1px solid #ccc; padding: 6px; }
          </style>
        </head>
        <body>
          <h2 style="text-align:center">${escapeHtml(title || 'Checksheet')}</h2>
          ${sanitizePrintHtml(result.value)}
        </body>
        </html>
      `;
      await printWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(htmlContent)}`);
      await new Promise(resolve => setTimeout(resolve, 1000));
    } else {
      throw new Error('Unsupported file type: ' + fileType);
    }

    // Print the window - wait for the print dialog to actually finish
    // (user clicked Print or Cancel) before closing, instead of guessing
    // with a fixed timeout that can kill the dialog while it's still open.
    await new Promise((resolve) => {
      printWindow.webContents.print({
        silent: false,
        printBackground: true
      }, (success, errorType) => {
        if (!success && errorType && errorType !== 'cancelled') {
          console.error('[PM Print Checksheet Error] print() failed:', errorType);
        }
        resolve();
      });
    });

    if (printWindow && !printWindow.isDestroyed()) {
      printWindow.close();
    }

    return { ok: true };
  } catch (err) {
    console.error('[PM Print Checksheet Error]', err.message);
    if (printWindow && !printWindow.isDestroyed()) {
      try { printWindow.destroy(); } catch (_) {}
    }
    return { ok: false, error: err.message };
  }
});

// ─── Auto-start with Windows ──────────────────────────────────────────────────
function setAutoStart(enable) {
  try {
    app.setLoginItemSettings({
      openAtLogin: enable,
      name: 'StoreTrack Pro',
      args: ['--hidden'],
    });
  } catch (err) { console.error('[Sync Config Load Error]', err.message); }
}

// ── PM Checklists Import (PDF, Excel, Word) ───────────────────────────────────
const pdfParse = require('pdf-parse');

// Both pm:parseChecklistFile and pm:printChecksheetOriginal take a filePath
// straight from the renderer. In normal use that path always comes from
// pm:listChecklistFiles (a directory listing of PM_Checksheet) or the native
// file picker in pm:browseChecksheet, so there's no live exploit today -- but
// since these handlers read arbitrary files off disk based on renderer input,
// this keeps them from ever reading outside PM_Checksheet even if a future
// renderer-side bug (e.g. XSS) let something else call them.
function isPathInsidePmChecksheetDir(filePath) {
  const pmFolder = path.resolve(path.join(dataDir, 'PM_Checksheet'));
  const resolved = path.resolve(filePath);
  return resolved === pmFolder || resolved.startsWith(pmFolder + path.sep);
}

secureHandle('pm:listChecklistFiles', async () => {
  try {
    const pmFolder = path.join(dataDir, 'PM_Checksheet');
    if (!fs.existsSync(pmFolder)) {
      fs.mkdirSync(pmFolder, { recursive: true });
      return { files: [] };
    }
    
    const files = fs.readdirSync(pmFolder)
      .filter(f => {
        const ext = path.extname(f).toLowerCase();
        return ['.pdf', '.xlsx', '.xls', '.docx', '.doc'].includes(ext);
      })
      .map(f => ({
        name: f,
        path: path.join(pmFolder, f),
        equipment: f.replace(/\.[^.]+$/i, '').replace(/[_-]/g, ' '),
        type: path.extname(f).toLowerCase()
      }));
    
    return { files };
  } catch (err) {
    console.error('[PM Checklist List Error]', err.message);
    return { error: err.message, files: [] };
  }
});

secureHandle('pm:parseChecklistFile', async (_event, filePath, fileType) => {
  try {
    if (!isPathInsidePmChecksheetDir(filePath)) {
      console.error('[PM Checklist Parse] Rejected path outside PM_Checksheet:', filePath);
      return { error: 'File must be inside the PM_Checksheet folder.', items: [] };
    }
    filePath = path.resolve(filePath);
    let items = [];
    let text = '';
    
    if (fileType === '.pdf') {
      const dataBuffer = fs.readFileSync(filePath);
      const data = await pdfParse(dataBuffer);
      text = data.text;
      items = parseChecklistText(text);
    } else if (fileType === '.xlsx' || fileType === '.xls') {
      const ExcelJS = require('exceljs');
      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.readFile(filePath);
      const worksheet = workbook.worksheets[0];

      const allRows = [];
      worksheet.eachRow({ includeEmpty: false }, (row) => {
        allRows.push(row.values.slice(1)); // 0-indexed
      });

      if (!allRows.length) {
        return { error: 'Empty sheet', items: [] };
      }

      // Detect header row + map SR/Inspection Item/Standard/OK/NG/Remarks
      // columns dynamically instead of assuming fixed positions
      // (CHECKSHEET_KEYWORDS/detectHeaderRow/mapColumns already exist below,
      // previously only wired up for PM schedule import).
      const headerRowIndex = detectHeaderRow(allRows, CHECKSHEET_KEYWORDS);
      const headers = allRows[headerRowIndex].map(h =>
        (h !== null && h !== undefined ? String(h).trim() : '')
      );
      const mapping = mapColumns(headers, CHECKSHEET_KEYWORDS);

      const cellToString = (value) => {
        if (value === null || value === undefined) {return '';}
        if (value instanceof Date) {return value.toISOString().slice(0, 10);}
        if (typeof value === 'object' && value.text) {return String(value.text);}
        return String(value);
      };

      items = [];
      for (let i = headerRowIndex + 1; i < allRows.length; i++) {
        const row = allRows[i];
        if (!row || row.every(v => v === '' || v === null || v === undefined)) {continue;}

        const item = {
          sr: mapping.sr !== undefined ? cellToString(row[mapping.sr]) : String(items.length + 1),
          inspectionItem: mapping.inspectionItem !== undefined ? cellToString(row[mapping.inspectionItem]) : '',
          standard: mapping.standard !== undefined ? cellToString(row[mapping.standard]) : '',
          ok: mapping.ok !== undefined ? cellToString(row[mapping.ok]) : '',
          ng: mapping.ng !== undefined ? cellToString(row[mapping.ng]) : '',
          remarks: mapping.remarks !== undefined ? cellToString(row[mapping.remarks]) : ''
        };

        // Skip rows where we couldn't find any inspection item text at all
        if (!item.inspectionItem.trim()) {continue;}

        items.push(item);
      }

      text = items.map(it => it.inspectionItem).join('\n');
    } else if (fileType === '.docx' || fileType === '.doc') {
      const dataBuffer = fs.readFileSync(filePath);
      const result = await mammoth.extractRawText({ buffer: dataBuffer });
      text = result.value;
      items = parseChecklistText(text);
    }
    
    return { items, text };
  } catch (err) {
    console.error('[PM Checklist Parse Error]', err.message);
    return { error: err.message, items: [] };
  }
});

function parseChecklistText(text) {
  // Return raw lines as-is without modification
  const lines = text.split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0);
  
  return lines;
}

// ── PM CHECKSHEET BROWSE HANDLER ─────────────────────────────────────────────────

secureHandle('pm:browseChecksheet', async (event, equipmentName) => {
  const { dialog } = require('electron');
  const path = require('path');
  assertString(String(equipmentName || ''), 'equipmentName', 256);
  
  // PM_Checksheet folder path
  const checksheetPath = path.join(dataDir, 'PM_Checksheet');
  
  const result = await dialog.showOpenDialog({
    title: `Select Checksheet for ${equipmentName}`,
    defaultPath: checksheetPath,
    filters: [
      { name: 'Excel Files', extensions: ['xlsx', 'xls'] },
      { name: 'PDF Files', extensions: ['pdf'] },
      { name: 'Word Files', extensions: ['docx', 'doc'] },
      { name: 'All Files', extensions: ['*'] }
    ],
    properties: ['openFile']
  });
  
  return result;
});

// ── SMART EXCEL PARSER FOR PM SCHEDULES ─────────────────────────────────────────

// Schedule keywords for dynamic header detection
const SCHEDULE_KEYWORDS = {
  equipment: ['what equipment', 'equipment', 'machine', 'asset', 'device'],
  who: ['who', 'assigned to', 'person', 'responsible', 'officer', 'technician'],
  priority: ['priority', 'urgency', 'criticality', 'importance'],
  weeklyPlan: ['weekly plan', 'plan', 'schedule', 'frequency', 'period'],
  location: ['location', 'area', 'zone', 'line', 'section', 'place'],
  why: ['why', 'reason', 'purpose', 'objective', 'description'],
  how: ['how', 'method', 'procedure', 'action', 'activity'],
  serialNo: ['serial no', 'serial', 'sr no', 'sr', 'id', 'code'],
  shift: ['shift', 'time', 'timing']
};

// Checksheet keywords for dynamic header detection
const CHECKSHEET_KEYWORDS = {
  sr: ['sr', 'serial', 'no', 'item no', 'sno'],
  inspectionItem: ['inspection item', 'item', 'check', 'parameter', 'point', 'task'],
  standard: ['standard', 'spec', 'specification', 'criteria', 'limit'],
  ok: ['ok', 'pass', 'good', 'acceptable', 'yes'],
  ng: ['ng', 'fail', 'bad', 'reject', 'no', 'not ok'],
  remarks: ['remarks', 'comment', 'note', 'observation', 'finding']
};

// Calculate keyword match score for a row
function calculateKeywordScore(row, keywords) {
  let score = 0;
  const rowText = row.map(cell => String(cell || '').toLowerCase().trim()).join(' ');
  
  for (const [, fieldKeywords] of Object.entries(keywords)) {
    for (const keyword of fieldKeywords) {
      if (rowText.includes(keyword)) {
        score += 1;
      }
    }
  }
  
  return score;
}

// Detect header row by keyword scoring
function detectHeaderRow(allRows, keywords) {
  let maxScore = 0;
  let headerRowIndex = 0;
  
  for (let i = 0; i < Math.min(allRows.length, 20); i++) {
    const score = calculateKeywordScore(allRows[i], keywords);
    if (score > maxScore) {
      maxScore = score;
      headerRowIndex = i;
    }
  }
  
  // If no clear header found, default to row 0
  if (maxScore === 0) {
    return 0;
  }
  
  return headerRowIndex;
}

// Map columns dynamically using keyword similarity
function mapColumns(headers, keywords) {
  const mapping = {};
  const headerLower = headers.map(h => String(h || '').toLowerCase().trim());
  
  for (const [field, fieldKeywords] of Object.entries(keywords)) {
    for (let i = 0; i < headerLower.length; i++) {
      const header = headerLower[i];
      for (const keyword of fieldKeywords) {
        if (header.includes(keyword) || keyword.includes(header)) {
          mapping[field] = i;
          break;
        }
      }
      if (mapping[field] !== undefined) {break;}
    }
  }
  
  return mapping;
}

// Smart parse PM schedule Excel
secureHandle('pm:smartParseSchedule', async (_event, uint8arr) => {
  try {
    const ExcelJS = require('exceljs');
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(Buffer.from(uint8arr));
    
    const ws = wb.worksheets[0];
    if (!ws) {return { error: 'Empty workbook' };}
    
    // Read all rows
    const allRows = [];
    ws.eachRow({ includeEmpty: false }, (row) => {
      allRows.push(row.values.slice(1)); // Convert to 0-indexed
    });
    
    if (!allRows.length) {return { error: 'Empty sheet' };}
    
    // Validate constraints (max 500 rows, 500 columns)
    if (allRows.length > 500) {
      return { error: 'File exceeds maximum allowed rows (500)' };
    }
    if (allRows[0].length > 500) {
      return { error: 'File exceeds maximum allowed columns (500)' };
    }
    
    // Detect header row
    const headerRowIndex = detectHeaderRow(allRows, SCHEDULE_KEYWORDS);
    
    // Extract headers
    const headers = allRows[headerRowIndex].map(h =>
      (h !== null && h !== undefined ? String(h).trim() : '')
    );
    
    // Map columns
    const mapping = mapColumns(headers, SCHEDULE_KEYWORDS);
    
    // Extract data rows (skip header row and empty rows)
    const dataRows = [];
    for (let i = headerRowIndex + 1; i < allRows.length; i++) {
      const row = allRows[i];
      if (!row || row.every(v => v === '' || v === null || v === undefined)) {continue;}
      
      const rowData = {};
      for (const [field, colIndex] of Object.entries(mapping)) {
        const value = row[colIndex];
        if (value instanceof Date) {
          rowData[field] = value.toISOString().slice(0, 10);
        } else if (value !== null && value !== undefined && typeof value === 'object' && value.text) {
          rowData[field] = String(value.text);
        } else {
          rowData[field] = value !== undefined && value !== null ? String(value) : '';
        }
      }
      
      // Only include rows with equipment
      if (rowData.equipment && rowData.equipment.trim()) {
        dataRows.push(rowData);
      }
    }
    
    return {
      headers,
      mapping,
      rows: dataRows,
      headerRowIndex,
      totalRows: allRows.length,
      dataRowsCount: dataRows.length
    };
  } catch (err) {
    console.error('[PM Smart Parse Error]', err.message);
    return { error: err.message };
  }
});

// Generate PM Excel template
secureHandle('pm:generateTemplate', async () => {
  try {
    const ExcelJS = require('exceljs');
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('PM Schedule');
    
    worksheet.columns = [
      { header: 'Serial No', key: 'serialNo', width: 15 },
      { header: 'What Equipment', key: 'equipment', width: 25 },
      { header: 'Location', key: 'location', width: 20 },
      { header: 'Priority', key: 'priority', width: 12 },
      { header: 'Weekly Plan', key: 'weeklyPlan', width: 15 },
      { header: 'Why', key: 'why', width: 30 },
      { header: 'How', key: 'how', width: 30 },
      { header: 'Who', key: 'who', width: 15 },
      { header: 'Shift', key: 'shift', width: 10 },
      { header: 'Officer Responsible', key: 'officer', width: 20 }
    ];
    
    // Add sample row
    worksheet.addRow({
      serialNo: 'PM-001',
      equipment: 'Motor',
      location: 'Production Line A',
      priority: 'High',
      weeklyPlan: 'Sunday',
      why: 'Preventive maintenance',
      how: 'Check all parameters',
      who: 'Maintenance Team',
      shift: 'S1',
      officer: 'John Doe'
    });
    
    // Style header
    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };
    
    const buffer = await workbook.xlsx.writeBuffer();
    return { buffer };
  } catch (err) {
    console.error('[PM Template Error]', err.message);
    return { error: err.message };
  }
});

// ─── System Tray ─────────────────────────────────────────────────────────────
function buildTray() {
  // Look for icon in standard locations; fall back to app icon
  const iconPaths = [
    app.isPackaged ? path.join(process.resourcesPath, 'tray-icon.ico') : null,
    path.join(__dirname, 'assets', 'tray-icon.ico'),
    path.join(__dirname, 'tray-icon.ico'),
  ].filter(Boolean);

  let icon = nativeImage.createEmpty();
  for (const p of iconPaths) {
    try {
      if (fs.existsSync(p)) { icon = nativeImage.createFromPath(p); break; }
    } catch (err) { console.error('[Tray Icon Load Error]', err.message); }
  }

  // If tray-icon.ico wasn't found anywhere, fall back to the main app icon
  if (icon.isEmpty()) {
    try {
      const fallback = getAppIconPath();
      if (fallback) {icon = nativeImage.createFromPath(fallback);}
    } catch (err) {
      console.error('[Tray Icon Fallback Error]', err.message);
    }
  }

  tray = new Tray(icon);
  tray.setToolTip('StoreTrack Pro — Scanner Active');
  _refreshTrayMenu();

  tray.on('double-click', () => {
    if (mainWindow) { mainWindow.show(); mainWindow.focus(); }
  });

  // Refresh status every 30s
  setInterval(_refreshTrayMenu, 30000);
}

function _refreshTrayMenu() {
  if (!tray) {return;}
  const cfg = scannerManager ? scannerManager.getConfig() : {};
  const mode  = cfg.scannerMode || 'hid';
  const inOk  = mode === 'hid' ? !!cfg.hid?.inScanner  : !!cfg.serial?.inPort;
  const outOk = mode === 'hid' ? !!cfg.hid?.outScanner : !!cfg.serial?.outPort;
  const modeLbl = mode === 'serial' ? 'Serial/COM' : 'HID';

  const menu = Menu.buildFromTemplate([
    { label: 'Show StoreTrack Pro', click: () => { if (mainWindow) { mainWindow.show(); mainWindow.focus(); } } },
    { type: 'separator' },
    { label: `Mode: ${modeLbl}`,              enabled: false },
    { label: `IN  Scanner : ${inOk  ? '✅ Active' : '⚠ Not configured'}`, enabled: false },
    { label: `OUT Scanner : ${outOk ? '✅ Active' : '⚠ Not configured'}`, enabled: false },
    { type: 'separator' },
    { label: '⚙ Scanner Configuration', click: () => {
        if (mainWindow) { mainWindow.show(); mainWindow.focus(); mainWindow.webContents.send('nav:scanner'); }
    }},
    { type: 'separator' },
    { label: 'Exit Application', click: () => { isQuitting = true; app.quit(); } },
  ]);
  tray.setContextMenu(menu);
}

// ─── Scanner service init + background processor ──────────────────────────────
function initScanner() {
  scannerManager = new ScannerManager(SCANNER_CONFIG_FILE, SCANNER_LOG_FILE);
  scannerManager.start();

  // Subscribe to scan events on the shared event bus
  scannerManager.events.on('scanner:scan', async ({ role, barcode, mode }) => {
    const result = await _bgProcessScan(role, barcode);
    const label  = role === 'in' ? 'Material IN' : 'Material OUT';

    if (result.ok) {
      try {
        new Notification({
          title: `✅ ${label} Successful`,
          body:  `${result.material.name} | Stock: ${result.material.newStock}`,
          silent: false,
        }).show();
      } catch (err) { console.error('[Sync Config Load Error]', err.message); }
    } else {
      const bodyMsg =
        result.reason === 'barcode_not_found'  ? `Barcode "${barcode}" inventory madhe nahi` :
        result.reason === 'insufficient_stock' ? `${result.materialName || ''} — Stock zero ahe!` :
        result.reason === 'sync_folder_not_set'? 'Sync folder set kara (LAN Sync > Select Folder)' :
        result.reason || 'Processing error';
      try {
        new Notification({ title: `⚠ ${label} Failed`, body: bodyMsg, silent: false }).show();
      } catch (err) { console.error('[Sync Config Load Error]', err.message); }
    }

    // Forward to renderer if window is open
    if (mainWindow && !mainWindow.isDestroyed()) {
      try {
        mainWindow.webContents.send('scanner:result', { role, barcode, result, label });
      } catch (err) { console.error('[Sync Config Load Error]', err.message); }
    }
  });

  scannerManager.events.on('scanner:deviceError', ({ role, error, mode }) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      try { mainWindow.webContents.send('scanner:deviceError', { role, error, mode }); } catch (err) { console.error('[Scanner Device Error Send Error]', err.message); }
    }
    _refreshTrayMenu();
  });
}

// ─── Background Scan Processor ────────────────────────────────────────────────
async function _bgProcessScan(role, barcode) {
  const normalizedBarcode = String(barcode || '').trim();
  const scanKey = `${role}:${normalizedBarcode}`;
  const now = Date.now();
  for (const [key, ts] of recentScanKeys) {
    if (now - ts > 5000) {recentScanKeys.delete(key);}
  }
  if (recentScanKeys.has(scanKey) && now - recentScanKeys.get(scanKey) < 1200) {
    return { ok: false, reason: 'duplicate_scan_ignored' };
  }
  recentScanKeys.set(scanKey, now);
  // Bound the deduplication map during long-running scanner sessions.
  while (recentScanKeys.size > 1024) {recentScanKeys.delete(recentScanKeys.keys().next().value);}
  if (!syncFolderPath) {
    return { ok: false, reason: 'sync_folder_not_set' };
  }

  const masterPath = path.join(syncFolderPath, MASTER_FILENAME);
  let masterData;
  try {
    masterData = JSON.parse(fs.readFileSync(masterPath, 'utf8'));
  } catch (err) {
    return { ok: false, reason: 'master_read_error', error: err.message };
  }

  const baseRevision = Number(masterData.revision || 0);
  // Find material by barcode
  const mats     = Array.isArray(masterData.materials) ? masterData.materials : (Array.isArray(masterData.M) ? masterData.M : []);
  const material = mats.find(m =>
    m.barcode === normalizedBarcode || m.code === normalizedBarcode || String(m.id) === normalizedBarcode
  );

  if (!material) {
    return { ok: false, reason: 'barcode_not_found', barcode: normalizedBarcode };
  }

  const txType   = role === 'in' ? 'MATERIAL_IN' : 'MATERIAL_OUT';
  const prevStock = parseFloat(material.stock) || 0;

  if (txType === 'MATERIAL_OUT' && prevStock <= 0) {
    return { ok: false, reason: 'insufficient_stock', materialName: material.name };
  }

  const newStock = txType === 'MATERIAL_IN' ? prevStock + 1 : prevStock - 1;
  material.stock      = newStock;
  material.updatedAt  = new Date().toISOString();
  masterData.revision = baseRevision + 1;

  const txId = Date.now() * 1000 + Math.floor(Math.random() * 999);
  const tx = {
    id:          txId,
    timestamp:   Date.now(),
    deviceId:    DEVICE_ID,
    time:        new Date().toISOString(),
    barcode:     material.barcode,
    itemId:      material.id,
    itemName:    material.name,
    unit:        material.unit      || '',
    category:    material.category  || '',
    type:        txType,
    qty:         1,
    prevStock,
    newStock,
    source:      'auto_scanner',
    user:        'scanner_system',
    userName:    'Auto Scanner',
    status:      'confirmed',
  };

  masterData.materials = mats;
  masterData.M = mats;
  const txs = Array.isArray(masterData.transactions) ? masterData.transactions : (Array.isArray(masterData.T) ? masterData.T : []);
  txs.push(tx);
  masterData.transactions = txs;
  masterData.T = txs;
  masterData.savedAt    = Date.now();
  masterData.lastDevice = DEVICE_ID;

  // Atomic write
  const ok = writeMaster(syncFolderPath, masterData, baseRevision);
  if (!ok) {return { ok: false, reason: 'write_error' };}

  // Append to TX log
  appendTxLog(syncFolderPath, tx);

  // FIX: Use safe IPC message instead of string-interpolated executeJavaScript
  // Raw interpolation of material.updatedAt / newStock into JS string is an injection risk
  if (mainWindow && !mainWindow.isDestroyed() && mainWindow.webContents) {
    try {
      mainWindow.webContents.send('scanner:idbUpdate', { tx, materialId: material.id, newStock, updatedAt: material.updatedAt });
    } catch (err) { console.error('[Sync Config Load Error]', err.message); }
  }

  return { ok: true, tx, material, prevStock, newStock: material.stock };
}

// ─── Scanner IPC Handlers ─────────────────────────────────────────────────────

// Get full config
secureHandle('scanner:getConfig', async (event) => {
  try {
    assertTrustedSender(event); return { ok: true, config: scannerManager.getConfig() }; }
  catch (err) { return { ok: false, error: err.message }; }
});

// Apply config changes (mode, hid paths, serial ports)
secureHandle('scanner:applyConfig', async (event, partial) => {
  try {
    assertTrustedSender(event);
    const cfg = scannerManager.applyConfig(partial);
    _refreshTrayMenu();
    return { ok: true, config: cfg };
  } catch (err) { return { ok: false, error: err.message }; }
});

// Reset config
secureHandle('scanner:resetConfig', async (event) => {
  try {
    assertTrustedSender(event);
    const cfg = scannerManager.resetConfig();
    _refreshTrayMenu();
    return { ok: true, config: cfg };
  } catch (err) { return { ok: false, error: err.message }; }
});

// List HID devices
secureHandle('scanner:listHIDDevices', async (event) => {
  try {
    assertTrustedSender(event); return { ok: true, devices: scannerManager.listHIDDevices() }; }
  catch (err) { return { ok: false, devices: [], error: err.message }; }
});

// List Serial/COM ports
secureHandle('scanner:listSerialPorts', async (event) => {
  try {
    assertTrustedSender(event);
    const ports = await scannerManager.listSerialPorts();
    return { ok: true, ports };
  } catch (err) { return { ok: false, ports: [], error: err.message }; }
});

// HID Enrollment — pause service, listen for scan, save path, restart
secureHandle('scanner:enrollHID', async (event, role) => {
  try {
    assertTrustedSender(event);
    if (!['in', 'out'].includes(role)) {throw new Error('Invalid scanner role');}
    const result = await scannerManager.enrollHID(role, 15000);
    _refreshTrayMenu();
    return { ok: true, ...result };
  } catch (err) { return { ok: false, error: err.message }; }
});

// Test scanner — next scan from given role returned to UI
// FIX: Proper timeout handling with guaranteed listener cleanup
secureHandle('scanner:test', async (event, role) => {
  assertTrustedSender(event);
  if (!['in', 'out'].includes(role)) {throw new Error('Invalid scanner role');}
  return new Promise((resolve) => {
    const handler = ({ role: r, barcode }) => {
      if (r === role) {
        scannerManager.events.removeListener('scanner:scan', handler);
        clearTimeout(timeoutId);
        resolve({ ok: true, barcode });
      }
    };
    scannerManager.events.on('scanner:scan', handler);
    const timeoutId = setTimeout(() => {
      scannerManager.events.removeListener('scanner:scan', handler);
      resolve({ ok: false, error: 'Timeout — no scan received within 10 seconds' });
    }, 10000);
  });
});

// Auto-start toggle
secureHandle('scanner:setAutoStart', async (event, enable) => {
  assertTrustedSender(event);
  if (typeof enable !== 'boolean') {throw new TypeError('enable must be boolean');}
  setAutoStart(enable);
  return { ok: true, enabled: enable };
});

// Get auto-start status
secureHandle('scanner:getAutoStart', async (event) => {
  try {
    assertTrustedSender(event);
    const s = app.getLoginItemSettings();
    return { ok: true, enabled: !!s.openAtLogin };
  } catch (_) { return { ok: true, enabled: false }; }
});

// ─── QR Code IPC Handler ──────────────────────────────────────────────────────
// Renderer cannot use require() (contextIsolation: true), so we generate
// QR data-URLs here in the main process and return them via IPC.
secureHandle('qr:toDataURL', async (event, text, options) => {
  try {
    assertTrustedSender(event);
    assertString(String(text), 'text', 4096);
    const url = await QRCode.toDataURL(String(text), options || { margin: 1 });
    return { ok: true, dataURL: url };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// ─── Print IPC Handlers ───────────────────────────────────────────────────────
// Show the print content as a visible on-screen preview first. The user
// reviews it, then clicks the injected "Print" button themselves, which
// triggers the OS print dialog. (Earlier version auto-triggered the print
// dialog immediately with no preview — reverted per user preference.)
secureHandle('print:printContent', async (event, html) => {
  let printWindow = null;
  try {
    assertTrustedSender(event);
    html = sanitizePrintHtml(html);
    printWindow = new BrowserWindow({
      width: 950,
      height: 750,
      show: true,
      autoHideMenuBar: true,
      title: 'Print Preview',
      webPreferences: {
        session: printSession,
        nodeIntegration: false,
        contextIsolation: true,
        webSecurity: true
      }
    });

    // Inject a floating, non-printing control bar (Print / Close) so the
    // person can review content first. Hidden automatically when the actual
    // print/PDF output is generated via the @media print rule below.
    const controlBar = `
      <div class="__print_controls" style="position:fixed;top:0;left:0;right:0;background:#1e293b;padding:10px 16px;display:flex;gap:10px;align-items:center;z-index:99999;font-family:Arial,sans-serif;box-shadow:0 2px 6px rgba(0,0,0,0.3)">
        <button id="__print_btn" type="button" style="padding:8px 22px;background:#2563eb;color:#fff;border:none;border-radius:5px;font-size:13px;cursor:pointer;font-weight:600">🖨 Print</button>
        <button id="__close_btn" type="button" style="padding:8px 22px;background:#475569;color:#fff;border:none;border-radius:5px;font-size:13px;cursor:pointer">Close</button>
        <span id="__print_status" style="margin-left:auto;font-size:12px;color:#cbd5e1">Preview — review below, then click Print</span>
      </div>
      <div style="height:54px"></div>
      <style>@media screen{body{zoom:1.8;background:#e5e7eb;padding:12px}body.pencil-label-preview{zoom:1;background:#e5e7eb;padding:12px}body > .pencil-label{margin:0 auto;box-shadow:0 2px 10px rgba(0,0,0,.25)}}@media print{.__print_controls,.__print_controls + div{display:none !important}body{zoom:1;background:#fff;padding:0}body > .pencil-label{box-shadow:none}}</style>`;
    const htmlWithControls = html.includes('<body>')
      ? html.replace('<body>', '<body>' + controlBar)
      : controlBar + html;

    // Print button uses a hash signal so the main process can call
    // webContents.print() with an explicit paper size. window.print() uses
    // the OS/browser default paper (often Letter/Landscape), which can rotate
    // or reposition these labels even when the preview is correct.
    let printRequested = false;
    // Do not use did-navigate-in-page/hash navigation as the print trigger.
    // On Electron data: documents that event is not reliable, which can leave
    // the preview button stuck on "Opening Print…" forever. Instead, the
    // preview click emits a unique console message and the main process starts
    // the native print dialog directly.
    printWindow.webContents.on('console-message', async (_event, _level, message) => {
      if (printRequested || String(message) !== '__STORETRACK_PRINT_REQUEST__') {return;}
      printRequested = true;
      try {
        const pageSize = pdfPageSizeFromHtml(html);
        const printOptions = {
          silent: false,
          printBackground: true,
          // The custom pageSize already contains the physical orientation.
          // Do not set landscape=true for 80x40 mm labels; Chromium/Electron
          // can rotate an already-wide custom paper a second time.
          landscape: false,
          margins: { marginType: 'none' },
          pageSize
        };
        await new Promise(resolve => {
          printWindow.webContents.print(printOptions, (success, errorType) => {
            const messageText = success
              ? 'Print dialog closed — print job accepted.'
              : (errorType === 'cancelled' ? 'Print dialog closed — print was cancelled.' : `Print failed: ${errorType || 'unknown error'}`);
            printWindow.webContents.executeJavaScript(`(() => { const b=document.getElementById('__print_btn'); const s=document.getElementById('__print_status'); if(b){b.disabled=false;b.style.opacity='1';b.textContent='🖨 Print';} if(s){s.textContent=${JSON.stringify(messageText)};} })()`).catch(() => {});
            resolve();
          });
        });
      } finally {
        printRequested = false;
      }
    });

    await printWindow.loadURL(
      'data:text/html;charset=utf-8,' + encodeURIComponent(htmlWithControls)
    );

    // Wire the preview controls from the main process instead of inline
    // onclick attributes. The print HTML is intentionally sanitized and its
    // CSP blocks page scripts, so inline handlers are not a reliable way to
    // provide Print/Close behavior. Give the user visible state transitions
    // so a click is unambiguous: Opening -> dialog closed. Electron's
    // window.print() API does not expose Print-vs-Cancel to page JavaScript,
    // so the final status deliberately states that limitation.
    await printWindow.webContents.executeJavaScript(`(() => {
      const printBtn = document.getElementById('__print_btn');
      const closeBtn = document.getElementById('__close_btn');
      const status = document.getElementById('__print_status');
      if (!printBtn || !closeBtn) return;
      printBtn.addEventListener('click', () => {
        printBtn.disabled = true;
        printBtn.style.opacity = '0.7';
        printBtn.textContent = '🖨 Opening Print…';
        if (status) status.textContent = 'Print dialog opening…';
        console.log('__STORETRACK_PRINT_REQUEST__');
      });
      closeBtn.addEventListener('click', () => window.close());
    })()`);

    return { ok: true };
  } catch (err) {
    try { if (printWindow && !printWindow.isDestroyed()) {printWindow.destroy();} } catch (_) {}
    console.error('[Print Error]', err.message);
    return { ok: false, error: err.message };
  }
});

// Read the first CSS @page size so PDF/print output uses the same physical
// page size as the preview. Do not force pencil labels onto A4.
function pdfPageSizeFromHtml(html) {
  const source = String(html || '');
  const match = source.match(/@page\s*\{[^}]*size\s*:\s*([0-9.]+)mm(?:\s+([0-9.]+)mm)?/i);
  if (!match) {return 'A4';}
  const widthMm = Number(match[1]);
  const heightMm = Number(match[2] || match[1]);
  if (!Number.isFinite(widthMm) || !Number.isFinite(heightMm) || widthMm <= 0 || heightMm <= 0) {return 'A4';}
  return {
    width: Math.max(1000, Math.round(widthMm * 1000)),
    height: Math.max(1000, Math.round(heightMm * 1000))
  };
}

function isWideCustomPageSize(pageSize) {
  if (!pageSize || typeof pageSize !== 'object') {return false;}
  const width = Number(pageSize.width || 0);
  const height = Number(pageSize.height || 0);
  // A4 is 210x297 mm. Only switch orientation for genuinely custom wide
  // labels; this keeps the existing A4 component/shank output unchanged.
  return width > height && width < 200000 && height < 200000;
}

// Save HTML content as PDF
secureHandle('print:savePDF', async (event, html, filename) => {
  let printWindow = null;
  try {
    assertTrustedSender(event);
    html = sanitizePrintHtml(html);
    filename = typeof filename === 'string' ? path.basename(filename).replace(/[^\w.-]/g, '_') : 'labels.pdf';
    printWindow = new BrowserWindow({
      show: false,
      webPreferences: {
        session: printSession,
        nodeIntegration: false,
        contextIsolation: true,
        webSecurity: true
      }
    });

    await printWindow.loadURL(
      'data:text/html;charset=utf-8,' + encodeURIComponent(html)
    );

    // Give browser time to render barcode images/fonts
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log('[PDF] Starting PDF generation...');

    const pageSize = pdfPageSizeFromHtml(html);
    const pdfData = await printWindow.webContents.printToPDF({
      pageSize,
      printBackground: true,
      // pageSize carries the physical orientation; keep landscape false so
      // custom 80x40 mm pencil labels are not rotated by the PDF engine.
      landscape: false
    });

    console.log('[PDF] PDF generated successfully');

    printWindow.close();

    // Save PDF file
    const { dialog } = require('electron');
    const { filePath } = await dialog.showSaveDialog(mainWindow, {
      defaultPath: filename || 'labels.pdf',
      filters: [{ name: 'PDF Files', extensions: ['pdf'] }]
    });

    if (filePath) {
      const fs = require('fs');
      fs.writeFileSync(filePath, pdfData);
      return { ok: true, path: filePath };
    } else {
      return { ok: false, error: 'Save dialog cancelled' };
    }
  } catch (err) {
    // BUG FIX: destroy orphaned printWindow on error
    try { if (printWindow && !printWindow.isDestroyed()) {printWindow.destroy();} } catch (_) {}
    console.error('[PDF Save Error]', err.message);
    return { ok: false, error: err.message };
  }
});

// ─── App lifecycle ────────────────────────────────────────────────────────────
// ─── Print/export windows use their own isolated session ────────────────────
// These hidden BrowserWindows render HTML that main.js/renderer builds purely
// to hand off to the OS print dialog or printToPDF (checksheet previews,
// label sheets, reports). That HTML is not part of the CSP-protected app UI,
// so it intentionally keeps literal inline styles. Using a separate,
// non-default session means our strict app CSP (registered on the main
// window's session below) is never applied to these ephemeral documents.
// ─── Print/export windows use their own isolated session ────────────────────
// These hidden BrowserWindows render HTML that main.js/renderer builds purely
// to hand off to the OS print dialog or printToPDF (checksheet previews,
// label sheets, reports). That HTML is not part of the CSP-protected app UI,
// so it intentionally keeps literal inline styles. Using a separate,
// non-default session means our strict app CSP (registered on the main
// window's session below) is never applied to these ephemeral documents.
// NOTE: session.fromPartition() may only be called after the app is ready,
// so this is assigned inside app.whenReady() below, not at module load time.
let printSession = null;

app.whenReady().then(() => {
  printSession = session.fromPartition('print-preview', { cache: false });
  printSession.webRequest.onHeadersReceived((details, callback) => callback({ responseHeaders: { ...details.responseHeaders, 'Content-Security-Policy': ["default-src 'none'; style-src 'self' data: 'unsafe-inline'; img-src data: file:; font-src data: file:; script-src 'none'; object-src 'none'; base-uri 'none'"] } }));

  loadSyncConfig();

  const startHidden = process.argv.includes('--hidden');

  mainWindow = new BrowserWindow({
    width:  1300,
    height: 900,
    title:  'StoreTrack Pro v5',
    icon:   getAppIconPath(),
    show:   !startHidden,
    webPreferences: {
      nodeIntegration:  false,
      contextIsolation: true,
      webSecurity: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  mainWindow.loadFile('index.html');
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!shouldAllowMainNavigation(url)) {event.preventDefault();}
  });
  mainWindow.webContents.on('will-redirect', (event, url) => {
    if (!shouldAllowMainNavigation(url)) {event.preventDefault();}
  });
  
  // Allow window.open for print windows (required for Electron 42+).
  // IMPORTANT: Chromium inherits the *opener's* CSP for about:blank popups
  // created via window.open() — this is a deliberate security measure to
  // stop pages from using window.open('') to escape their own CSP. That
  // means these print/label/report popups were silently having every
  // <style> block and style="" attribute stripped by the strict app CSP,
  // even though they're not part of the CSP'd app UI. Routing them through
  // the isolated `printSession` (created in app.whenReady(), no CSP
  // interception registered on it) gives them a genuinely separate session
  // so their own stylesheets render correctly.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    // Allow about:blank and data URLs for print windows
    if (url === 'about:blank' || url.startsWith('data:')) {
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          webPreferences: {
            session: printSession,
            contextIsolation: true,
            nodeIntegration: false
          }
        }
      };
    }
    return { action: 'deny' };
  });
  
  mainWindow.webContents.session.webRequest.onHeadersReceived((details, callback) => {
    callback({ responseHeaders: {
      ...details.responseHeaders,
      // IMPORTANT: this must be ONE array element containing the full policy
      // string. Electron sends each array element as a *separate*
      // Content-Security-Policy header, and browsers enforce multiple CSP
      // headers as an intersection (every policy must independently allow
      // the resource) rather than merging their directives. Splitting
      // directives across array elements (as this used to do) meant the
      // lone "default-src 'self';" element was its own complete policy with
      // no img-src override, so data:/blob: images were blocked by that
      // element's fallback even though a later element allowed them.
      'Content-Security-Policy': [
        "default-src 'self'; " +
        "script-src 'self'; " +
        "worker-src 'self' blob:; " +
        "child-src 'self' blob:; " +
        "style-src 'self'; " +
        "img-src 'self' data: blob:; " +
        "font-src 'self' data:; " +
        "connect-src 'self' data:; " +
        "object-src 'none'; " +
        "base-uri 'self'; " +
        "frame-ancestors 'none';"
      ],
      'X-Content-Type-Options': ['nosniff'],
      'X-Frame-Options': ['SAMEORIGIN'],
      'X-XSS-Protection': ['1; mode=block'],
      'Referrer-Policy': ['strict-origin-when-cross-origin']
    }});
  });

  mainWindow.webContents.session.on('will-download', (_event, item) => {
    item.setSavePath(path.join(exportDir, path.basename(item.getFilename())));
  });

  mainWindow.webContents.on('before-input-event', (_event, input) => {
    const key = String(input.key || '').toLowerCase();
    if (key === 'f12' || (input.control && input.shift && key === 'i')) {
      _event.preventDefault();
      if (!app.isPackaged) {mainWindow.webContents.toggleDevTools();}
    }
  });
  if (app.isPackaged) {mainWindow.webContents.on('devtools-opened', () => mainWindow.webContents.closeDevTools());}

  mainWindow.webContents.on('did-finish-load', () => {
    startSync();
  });

  // Close button → hide to tray (do NOT destroy)
  mainWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      mainWindow.hide();
      try {
        if (tray) {tray.displayBalloon({
          title:   'StoreTrack Pro',
          content: '✅ Running in the background. Scanner monitoring active.',
          iconType: 'info',
        });}
      } catch (err) { console.error('[Sync Config Load Error]', err.message); }
    }
  });

  mainWindow.on('closed', () => {
    if (isQuitting) {
      stopSync();
      try { if (scannerManager) {scannerManager.stop();} } catch (err) { console.error('[Scanner Stop Error]', err.message); }
      mainWindow = null;
    }
  });

  Menu.setApplicationMenu(null);

  // Build tray
  buildTray();

  // Start scanner service
  initScanner();
});

// ── Health Check Endpoint ─────────────────────────────────────────────────────
// Provides system health information for diagnostics and monitoring
secureHandle('health-check', async () => {
  const health = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: app.getVersion(),
    platform: process.platform,
    arch: process.arch,
    electronVersion: process.versions.electron,
    nodeVersion: process.versions.node,
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    database: {
      connected: true,
      path: dataDir
    },
    sync: {
      enabled: !!syncFolderPath,
      folder: syncFolderPath || 'Not configured',
      connectedClients: lanConnectedClients,
      lastSync: lanLastSyncTs ? new Date(lanLastSyncTs).toISOString() : 'Never'
    },
    scanner: {
      initialized: !!scannerManager,
      status: scannerManager ? 'active' : 'inactive'
    }
  };

  // Check disk space
  try {
    fs.statSync(dataDir);
    health.diskSpace = {
      dataDir: dataDir,
      accessible: true
    };
  } catch (err) {
    health.diskSpace = {
      dataDir: dataDir,
      accessible: false,
      error: err.message
    };
    health.status = 'degraded';
  }

  return health;
});

app.on('before-quit', () => { isQuitting = true; });

app.on('window-all-closed', () => {
  // Do NOT quit on window close — only quit when isQuitting (Exit Application clicked)
  if (isQuitting && process.platform !== 'darwin') {app.quit();}
});
