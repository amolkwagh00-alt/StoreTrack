# Restored Backup Verification — 2026-10-31

The portable backup exported after installing the updated software decrypted successfully and contained the restored StoreTrack component collections.

## Verified data

- Component parts: 205
- Station/Gun mappings: 602
- Component stock rows: 295
- Historical/replacement consumption rows: 0
- Candidate-only parts: 199
- Unmapped candidate-only parts excluded from operational status: 10
- Mapped candidate-only parts retained as operational: 189

## Actual stock status under the installed rules

The operational scope is active parts that are either normal parts or candidate-only parts that are actually present in Station/Gun mappings. Required Qty is the mapped occurrence count, with the configured minimum as fallback.

- ZERO STOCK: 49
- LOW STOCK: 55
- OK STOCK: 91
- Total operational parts: 195

## Forecast behavior

The restored backup contains no replacement/consumption history. Therefore forecast status must be `NO DATA`; the primary displayed status must come from the actual stock status (`ZERO STOCK`, `LOW STOCK`, or `OK STOCK`). Lead-time and consumption forecasting remains available once history is recorded.
